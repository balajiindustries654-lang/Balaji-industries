# WhatsApp jate moklvu (Balaji Kanta) - setup guide

Aa setup ek var karvanu chhe. Pachhi darek gadi no slip, khali vajan thatij, jate WhatsApp par jay.

> WhatsApp ni normal app (ke wa.me link) kyarey app ne "jate Send" karva deti nathi. Eno ek j sacho raasto: **WhatsApp Business Platform (Meta Cloud API)**. Teno kharch: darek moklela message nu thodu (Utility category - Meta no rate card jovo). Token Supabase ma j rahe chhe, app ma nahi.

## 1. Meta ma app banavo
1. https://developers.facebook.com -> **My Apps -> Create App** -> type **Business** -> naam "Balaji Kanta".
2. Business portfolio (business.facebook.com) "Balaji Industries" jodo.
3. App ma **Add product -> WhatsApp -> Set up**.

## 2. Number
* **Navo number (saras ane saral):** WhatsApp -> API Setup -> "Add phone number". Aa number par pachhi WhatsApp Business app nahi chale.
* **Atyar no WhatsApp Business number j vaparvo hoy:** Meta ma "Connect your existing WhatsApp Business app" (coexistence) no option ave to te vaparo - app pan chalu rahe ane API pan. Option na ave to number eligible nathi -> navo number vaparo.
* **Phone number ID** (API Setup ma dekhay) copy karo -> `WA_PHONE_ID`.
* **Status "Pending" / "Not registered":** number verify thayo pan WhatsApp API par haju **register** nathi thayo. Meta ni vaat pramane [number API thi j register thay](https://developers.facebook.com/documentation/business-messaging/whatsapp/business-phone-numbers/registration.md) (WhatsApp Manager / dashboard thi nahi) - POST `PHONE_NUMBER_ID/register` ma 6 ank no PIN. Aa mate GitHub ma `whatsapp-number.yml` (section 4b) che: ek click thi status juo ane register karo.

## 3. Message template (Meta ni manjuri jaruri)
WhatsApp Manager -> **Message templates -> Create template**
* Category: **Utility**   * Name: `kanta_slip`   * Language: **English** (`en`)
* Body (ekdum aa j):

```
Balaji Industries - Kanta slip
RST: {{1}}
Gadi: {{2}}
Party: {{3}}
Material: {{4}}
Gross: {{5}} KG
Tare: {{6}} KG
Net: {{7}} KG
Date: {{8}}
Sampark: +91 94264 52158
```
* Sample values: 371 / GJ12AB1234 / Ramesh Patel / Groundnut / 30,250 / 11,385 / 18,865 / 19-10-2026 10:30
* Submit -> manjuri thay (minutes thi kalak). Status **Approved** hoy tyare aagal vadho.

## 4. Kayam no Token
business.facebook.com -> Settings -> **Users -> System users -> Add** (Admin) -> **Add assets**: app (Full control) + WhatsApp account (Full control) -> **Generate token** -> app select -> permissions `whatsapp_business_messaging` + `whatsapp_business_management` -> token copy -> `WA_TOKEN`. (Aa token expire thato nathi.)
Payment method: WhatsApp Manager -> Payment settings ma card / bank jodo.

## 4b. Number register (GitHub thi, ek var)
1. Repo ma `.github/workflows/whatsapp-number.yml` banavo (Add file -> Create new file -> naam `.github/workflows/whatsapp-number.yml` lakho -> file no text paste -> Commit).
2. Secrets: `WA_TOKEN` (section 4 no token) ane `WA_PHONE_ID` (number no Phone Number ID).
3. Actions -> **WhatsApp number (status / register)** -> Run workflow -> action **status** -> run ni niche "RESULT" line vanchho (Pending = register baki).
4. Pachhi action **register** + tamari pasand no **6 ank no PIN** (yaad rakho) -> Run. "RESULT: REGISTERED" aave to taiyar. Error aave to RESULT line ma karan ane upay lakhelo hoy chhe (jem ke PIN khotu, token expire, 72 kalak ma 10 var thi vadhu).

## 5. GitHub + Supabase
1. Repo ma `send-whatsapp.ts` (root) ane `.github/workflows/deploy-whatsapp.yml` upload karo.
2. Repo -> Settings -> Secrets and variables -> Actions -> New repository secret: `WA_TOKEN`, `WA_PHONE_ID`, `WA_TEMPLATE` (= `kanta_slip`), `WA_LANG` (= `en`).
3. Actions -> **Deploy send-whatsapp** -> Run workflow (function deploy thay ane secrets Supabase ma save thay).

## 5b. Kanta nu name / phone WhatsApp slip ma badalvu (optional)
Upar nu template ma "Balaji Industries" ane "Sampark" lakhelu j chhe - e Meta ma fix hoy chhe. Je name / phone Balaji Kanta > Settings > **Slip layout** ma lakho te WhatsApp **template** ma tyare j jay jyare template ma {{ }} hoy. Mate navu template banavo, jem ke:
```
{{1}} - Kanta slip
RST: {{2}}  Gadi: {{3}}  Party: {{4}}
Net: {{5}} KG   Date: {{6}}
Sampark: {{7}}
```
ane GitHub secret `WA_VARS` = `kanta,rst,vehicle,party,net,date,kphone` (ane `WA_TEMPLATE` nu navu name; pachhi **Deploy send-whatsapp** pharithi). App je naam aape chhe: `kanta` (name), `kaddress`, `kphone`, `kfooter`, `rst`, `vehicle`, `party`, `material`, `city`, `mobile`, `gross`, `tare`, `net`, `charges`, `date`, `day`, `time`.
(Jya sudhi aa nathi karyu tya sudhi junu template chale chhe; "Chat khule" rit ma to Slip layout nu name / address / phone / niche ni line seedhi jay chhe.)

## 5c. Slip ne PHOTO (PNG) tarike moklvi - print jevi (optional, pan saru)
App slip nu print jevu chitra (PNG) jate banave chhe. WhatsApp ma photo moklva mate Meta ma **photo-vali header** nu alag template joie.
1. WhatsApp Manager -> **Message templates -> Create template** -> Category **Utility** -> Name `kanta_slip_pic` -> Language **English** (`en`).
2. **Header: Image** -> sample tarike koi pan slip ni photo / PNG upload karo (Balaji Kanta > Settings > WhatsApp > "Show the picture" ni screenshot chale).
3. Body (ekdum aa j; chhelle ane shuru ma {{ }} na hoy te Meta no niyam):
```
Weighbridge slip (RST {{1}}) - vehicle {{2}}, net weight {{3}} KG, date {{4}}. Thank you.
```
   Sample: 371 / GJ12AB1234 / 18,865 / 19-10-2026. Submit -> **Approved** thay tyare aagal.
4. GitHub repo ma navi `send-whatsapp.ts` ane `.github/workflows/deploy-whatsapp.yml` (aa zip na `ci` folder ma) fari upload karo; repo secret **`WA_TEMPLATE_IMG`** = `kanta_slip_pic` umero; Actions -> **Deploy send-whatsapp** -> Run workflow. (Body na variable badalva hoy to secret `WA_VARS_IMG`, default `rst,vehicle,net,date`.)
5. Balaji Kanta > Settings > WhatsApp > **How the slip goes on WhatsApp = Picture (like the print)** (default). Jya sudhi template approve na hoy / secret na hoy tya sudhi slip lakhan tarike jaay chhe (junu template) - entry par "WhatsApp ગયું (ફોટો)" ke ફક્ત "ગયું" dekhay.

## 6. Balaji Kanta ma
Settings (upar jamni bajuni "Settings" button) -> WhatsApp -> **Mill vehicles** (ke All vehicles) -> **By itself (WhatsApp Business)**. App jate test kare: "WhatsApp jodayu" ane tamaro sender number dekhay. Pachhi gadi no mobile lakhi pehlu + biju vajan lo - slip jate jashe.

## Niyam
* Slip jya jay te mobile: **Mill ni gadi** -> (1) gadi par lakhelo Mobile (nahitar chitthi na kheduut no mobile) **ane** (2) Settings > WhatsApp > **Mill no fix WhatsApp number** (ek var lakho; ek karta vadhu hoy to comma thi jooda). **Bahar ni (road) gadi** -> fakt vajan vakhte lakhelo Mobile, fix number par kyarey nahi (bahar ni gadi mate "All vehicles" pasand karvu). Mobile na hoy to kai jatu nathi (entry ma "no mobile" lakhelu ave) - mill ni gadi ma fix number par to jay j.
* Net na hoy to slip laptop ma queue ma rahe ane net avta jate jay. Result: `Documents\Balaji Kanta\kanta-wa-YYYY-MM.csv`.
* Kanta no login role **waybridge** ke **admin** hovo joie.
* "Sent" no matlab WhatsApp e message swikaryo; "Delivered/Read" nu status aa version ma batavtu nathi.
* Number WhatsApp par nahoy to message jato nathi - entry par "WhatsApp ગયું નથી" ane karan dekhay; "WhatsApp" button thi chat khuli sake.
