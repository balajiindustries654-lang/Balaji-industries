@echo off
rem First run on a PC that has Flutter installed.
flutter create --platforms=android,windows --project-name balaji_pro --org com.balajiindustries .
flutter pub get
flutter run -d windows
