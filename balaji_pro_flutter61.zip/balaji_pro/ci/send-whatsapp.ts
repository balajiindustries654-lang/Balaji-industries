import { createClient } from 'npm:@supabase/supabase-js@2';

// Balaji Kanta: sends the weighing slip on WhatsApp by itself (WhatsApp Business Platform - Cloud API of Meta).
// The token never leaves the server: it lives in the function secrets (WA_TOKEN ...), the app only calls this function.
//
// Secrets:  WA_TOKEN (permanent token of a System User), WA_PHONE_ID (Phone number ID), WA_TEMPLATE (approved template name),
//           WA_LANG (template language code, default "en"), WA_VARS (optional: names of the {{1}} {{2}} ... in order),
//           WA_API (optional Graph API version, default "v21.0").
//           Slip as a PICTURE (optional): WA_TEMPLATE_IMG (name of the approved template with an IMAGE header, e.g. kanta_slip_pic),
//           WA_VARS_IMG (names of its body variables, default "rst,vehicle,net,date"). Without it, or while Meta has not approved it,
//           the slip goes as plain writing with WA_TEMPLATE (the answer then says how: "text").
// Request:  { test: true }                         -> checks the set-up, sends nothing
//           { to: "9876543210", vars: { rst, vehicle, party, material, city, mobile, gross, tare, net, charges, date, time, day,
//                                        kanta, kaddress, kphone, kfooter },           (the last four: name / address / phone / bottom line of the slip layout)
//             image: "<base64 of a PNG of the slip>" }                                   (optional: the slip drawn like the print)
// Answer:   { ok: true, id, how: "pic" | "text" }  or  { ok: false, kind: "retry" | "number" | "setup", error, code }

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization,apikey,content-type,x-client-info,x-supabase-api-version',
  'Access-Control-Allow-Methods': 'POST,OPTIONS'
};
const reply = (status: number, body: unknown) => new Response(JSON.stringify(body), {
  status, headers: { ...cors, 'Content-Type': 'application/json' }
});

const DEFAULT_VARS = 'rst,vehicle,party,material,gross,tare,net,date';
const DEFAULT_VARS_IMG = 'rst,vehicle,net,date';
const hits = new Map<string, number[]>();

// Meta error codes. "number": this phone cannot get the message (not on WhatsApp ...). "setup": something in the set-up is wrong (token,
// template name / language / number of variables, payment method, test-number list) - sending again will not help until it is fixed.
const NUMBER_CODES = new Set([131026, 131021, 131009]);
const SETUP_CODES = new Set([0, 10, 100, 190, 200, 368, 131030, 131042, 132000, 132001, 132005, 132007, 132012, 132015, 132016, 133004, 133005, 133010, 135000]);

// A template variable may not be empty, hold a new line / tab or 4 spaces in a row.
const clean = (v: unknown) => {
  const t = String(v ?? '').replace(/[\r\n\t]+/g, ' ').replace(/ {2,}/g, ' ').trim().slice(0, 120);
  return t || '-';
};
const toNumber = (v: unknown) => {
  const d = String(v ?? '').replace(/\D/g, '');
  if (d.length === 10) return '91' + d;
  if (d.length === 12 && d.startsWith('91')) return d;
  if (d.length === 11 && d.startsWith('0')) return '91' + d.slice(1);
  return d.length >= 11 && d.length <= 15 ? d : '';
};
const fail = (kind: string, error: string, code = 0, status = 200) => reply(status, { ok: false, kind, error, code });

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return reply(405, { error: 'POST required' });
  try {
    const db = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, {
      auth: { persistSession: false, autoRefreshToken: false }
    });
    const token = (req.headers.get('Authorization') || '').replace(/^Bearer\s+/i, '');
    const auth = await db.auth.getUser(token);
    if (auth.error || !auth.data.user) return reply(401, { error: 'Login again.' });
    const p = await db.from('user_profiles').select('role,approved').eq('id', auth.data.user.id).single();
    if (p.error || !p.data?.approved || !['admin', 'waybridge'].includes(p.data.role))
      return reply(403, { error: 'Only the Admin or the Kanta operator can send slips.' });

    const now = Date.now();
    const recent = (hits.get(auth.data.user.id) || []).filter((t) => now - t < 60000);
    if (recent.length >= 90) return fail('retry', 'Too many messages in a minute - waiting.', 429);
    recent.push(now);
    hits.set(auth.data.user.id, recent);
    if (hits.size > 200) hits.clear();

    const b = await req.json().catch(() => ({}));
    const waToken = (Deno.env.get('WA_TOKEN') || '').trim();
    const phoneId = (Deno.env.get('WA_PHONE_ID') || '').trim();
    const wa_template = (Deno.env.get('WA_TEMPLATE') || '').trim();
    const lang = (Deno.env.get('WA_LANG') || 'en').trim();
    const api = (Deno.env.get('WA_API') || 'v21.0').trim();
    const missing = [!waToken && 'WA_TOKEN', !phoneId && 'WA_PHONE_ID', !wa_template && 'WA_TEMPLATE'].filter(Boolean);
    if (missing.length) return fail('setup', 'Not set up yet: missing ' + missing.join(', '), 0);

    if (b.test === true) {
      const r = await fetch(`https://graph.facebook.com/${api}/${phoneId}?fields=display_phone_number,verified_name,quality_rating,code_verification_status`, {
        headers: { Authorization: 'Bearer ' + waToken }, signal: AbortSignal.timeout(15000)
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) return fail('setup', String(j?.error?.message || 'WhatsApp refused (HTTP ' + r.status + ')').slice(0, 300), Number(j?.error?.code || 0));
      return reply(200, { ok: true, configured: true, number: j.display_phone_number || '', name: j.verified_name || '', quality: j.quality_rating || '', template: wa_template, lang, picture: !!(Deno.env.get('WA_TEMPLATE_IMG') || '').trim() });
    }

    const to = toNumber(b.to);
    if (!to) return fail('number', 'The mobile number is not valid.', 0);
    const vars = (b.vars && typeof b.vars === 'object') ? b.vars as Record<string, unknown> : {};
    const names = (Deno.env.get('WA_VARS') || DEFAULT_VARS).split(',').map((s) => s.trim()).filter(Boolean);
    const parameters = names.map((n) => ({ type: 'text', text: clean(vars[n]) }));

    const headers = { Authorization: 'Bearer ' + waToken, 'Content-Type': 'application/json' };
    const send = async (body: unknown): Promise<{ r?: Response; j?: any }> => {
      try {
        const r = await fetch(`https://graph.facebook.com/${api}/${phoneId}/messages`, {
          method: 'POST', headers, body: JSON.stringify(body), signal: AbortSignal.timeout(20000)
        });
        return { r, j: await r.json().catch(() => ({})) };
      } catch {
        return {};
      }
    };
    const template = (name: string, comps: unknown[]) => ({
      messaging_product: 'whatsapp', recipient_type: 'individual', to, type: 'template',
      template: { name, language: { code: lang }, components: comps }
    });

    // 1) the slip as a picture (a template with an IMAGE header), when the app sent one and this template is set up
    const imgTemplate = (Deno.env.get('WA_TEMPLATE_IMG') || '').trim();
    if (imgTemplate && typeof b.image === 'string' && b.image.length > 100 && b.image.length < 3_000_000) {
      try {
        const bin = atob(b.image);
        const bytes = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
        if (bytes[0] === 0x89 && bytes[1] === 0x50) {
          const fd = new FormData();
          fd.append('messaging_product', 'whatsapp');
          fd.append('type', 'image/png');
          fd.append('file', new Blob([bytes], { type: 'image/png' }), 'slip.png');
          const up = await fetch(`https://graph.facebook.com/${api}/${phoneId}/media`, {
            method: 'POST', headers: { Authorization: 'Bearer ' + waToken }, body: fd, signal: AbortSignal.timeout(25000)
          });
          const uj = await up.json().catch(() => ({}));
          if (up.ok && uj?.id) {
            const inames = (Deno.env.get('WA_VARS_IMG') || DEFAULT_VARS_IMG).split(',').map((s) => s.trim()).filter(Boolean);
            const comps: unknown[] = [{ type: 'header', parameters: [{ type: 'image', image: { id: uj.id } }] }];
            if (inames.length) comps.push({ type: 'body', parameters: inames.map((n) => ({ type: 'text', text: clean(vars[n]) })) });
            const x = await send(template(imgTemplate, comps));
            if (!x.r) return fail('retry', 'WhatsApp did not answer.', 0);
            const xc = Number(x.j?.error?.code || 0);
            if (x.r.ok && x.j?.messages?.[0]?.id) return reply(200, { ok: true, id: x.j.messages[0].id, to, how: 'pic' });
            if (NUMBER_CODES.has(xc)) return fail('number', String(x.j?.error?.error_data?.details || x.j?.error?.message || 'WhatsApp HTTP ' + x.r.status).slice(0, 300), xc);
            // anything else (the picture template is not approved yet, wrong name ...): the plain writing goes instead, so no slip is lost
          }
        }
      } catch { /* the plain writing goes instead */ }
    }

    // 2) the plain writing (template with the slip in its body)
    const res = await send(template(wa_template, parameters.length ? [{ type: 'body', parameters }] : []));
    if (!res.r) return fail('retry', 'WhatsApp did not answer.', 0);
    const r = res.r;
    const j = res.j;
    if (r.ok && j?.messages?.[0]?.id) return reply(200, { ok: true, id: j.messages[0].id, to, how: 'text' });
    const code = Number(j?.error?.code || 0);
    const msg = String(j?.error?.error_data?.details || j?.error?.message || ('WhatsApp HTTP ' + r.status)).slice(0, 300);
    if (NUMBER_CODES.has(code)) return fail('number', msg, code);
    if (SETUP_CODES.has(code) || r.status === 401 || r.status === 403) return fail('setup', msg, code);
    return fail('retry', msg, code);
  } catch (e) {
    return fail('retry', String((e as Error)?.message || e).slice(0, 200), 0, 200);
  }
});
