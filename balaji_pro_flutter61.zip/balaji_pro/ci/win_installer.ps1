# Balaji Pro - makes Balaji-Pro-Setup.exe from the Windows build.
# Runs on GitHub Actions (windows-latest) right after "flutter build windows".
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$rel = Get-ChildItem -Path build/windows -Directory -Recurse -Filter Release |
  Where-Object { Test-Path (Join-Path $_.FullName 'balaji_pro.exe') } |
  Select-Object -First 1
if (-not $rel) { throw 'Release folder not found (balaji_pro.exe)' }

$ver = '1.0.0'
$m = Select-String -Path pubspec.yaml -Pattern '^version:\s*([0-9]+\.[0-9]+\.[0-9]+)' | Select-Object -First 1
if ($m) { $ver = $m.Matches[0].Groups[1].Value }

function Find-Iscc {
  foreach ($p in @("${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe", "$env:ProgramFiles\Inno Setup 6\ISCC.exe")) {
    if (Test-Path $p) { return $p }
  }
  return $null
}
$iscc = Find-Iscc
if (-not $iscc) {
  Write-Host 'Inno Setup nathi - choco thi install kari rahyo chhu...'
  choco install innosetup -y --no-progress | Out-Host
  $iscc = Find-Iscc
}
if (-not $iscc) { throw 'Inno Setup (ISCC.exe) malyu nahi' }
Write-Host "ISCC: $iscc"

$out = Join-Path $root 'installer-out'
New-Item -ItemType Directory -Force -Path $out | Out-Null
$iss = Join-Path $root 'ci/installer.iss'
$iscArgs = @("/DSrcDir=$($rel.FullName)", "/DAppVer=$ver", "/DOutDir=$out")
$icon = Join-Path $root 'windows/runner/resources/app_icon.ico'
if (Test-Path $icon) { $iscArgs += "/DIconFile=$icon" }

& $iscc @iscArgs $iss
if ($LASTEXITCODE -ne 0) { throw "ISCC failed with code $LASTEXITCODE" }
if (-not (Test-Path (Join-Path $out 'Balaji-Pro-Setup.exe'))) { throw 'Balaji-Pro-Setup.exe not created' }
Get-Item (Join-Path $out 'Balaji-Pro-Setup.exe') | Format-List Name, Length
Add-Content -Path $env:GITHUB_STEP_SUMMARY -Value "### Windows Setup.exe ready (v$ver) - Artifacts ma **balaji-pro-windows-setup**"
