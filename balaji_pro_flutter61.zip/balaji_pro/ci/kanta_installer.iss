; Balaji Kanta - Windows installer script (Inno Setup 6) for the weighbridge operator app.
; Built on GitHub Actions by ci/win_kanta.ps1, which passes:
;   /DSrcDir=<folder with balaji_kanta.exe>  /DAppVer=<x.y.z>  /DOutDir=<output folder>  [/DIconFile=<app_icon.ico>]
#ifndef AppVer
  #define AppVer "1.0.0"
#endif

[Setup]
AppId={{B7E2C4A1-3D58-4F0B-9A66-2C1E8D5F7A90}
AppName=Balaji Kanta
AppVersion={#AppVer}
AppPublisher=Balaji Industries
DefaultDirName={localappdata}\Programs\Balaji Kanta
DefaultGroupName=Balaji Kanta
DisableProgramGroupPage=yes
DisableDirPage=yes
PrivilegesRequired=lowest
OutputDir={#OutDir}
OutputBaseFilename=Balaji-Kanta-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
CloseApplications=yes
RestartApplications=no
UninstallDisplayName=Balaji Kanta
UninstallDisplayIcon={app}\balaji_kanta.exe
#ifdef IconFile
SetupIconFile={#IconFile}
#endif

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Desktop par Balaji Kanta shortcut banavo"; GroupDescription: "Shortcut:"
Name: "startup"; Description: "Windows chalu thay tyare Balaji Kanta jate chalu thay (kanta na laptop mate)"; GroupDescription: "Auto start:"

[Files]
Source: "{#SrcDir}\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion

[Icons]
Name: "{autoprograms}\Balaji Kanta"; Filename: "{app}\balaji_kanta.exe"
Name: "{autodesktop}\Balaji Kanta"; Filename: "{app}\balaji_kanta.exe"; Tasks: desktopicon
Name: "{userstartup}\Balaji Kanta"; Filename: "{app}\balaji_kanta.exe"; Tasks: startup

[Run]
Filename: "{app}\balaji_kanta.exe"; Description: "Balaji Kanta hamna kholo"; Flags: nowait postinstall skipifsilent
