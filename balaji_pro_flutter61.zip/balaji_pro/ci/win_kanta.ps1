# Balaji Kanta - builds the weighbridge operator app (lib/main_kanta.dart) and makes Balaji-Kanta-Setup.exe.
# Runs on GitHub Actions (windows-latest) right after ci/win_installer.ps1 (Balaji Pro). Never needed for Balaji Pro itself.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

if (-not (Test-Path lib/main_kanta.dart)) { throw 'lib/main_kanta.dart nathi' }

# Window title, and an app-data folder of its own (so Balaji Kanta never shares the saved login / settings with Balaji Pro)
$utf8 = New-Object System.Text.UTF8Encoding($false)
try {
  $mc = 'windows/runner/main.cpp'
  if (Test-Path $mc) {
    $t = [System.IO.File]::ReadAllText((Resolve-Path $mc).Path)
    $n = $t.Replace('L"Balaji Pro"', 'L"Balaji Kanta"')
    if ($n -ne $t) { [System.IO.File]::WriteAllText((Resolve-Path $mc).Path, $n, $utf8) }
  }
  $rc = 'windows/runner/Runner.rc'
  if (Test-Path $rc) {
    $t = [System.IO.File]::ReadAllText((Resolve-Path $rc).Path)
    $ev = [System.Text.RegularExpressions.MatchEvaluator]{ param($m) $m.Value.Replace('balaji_pro', 'balaji_kanta') }
    $n = [regex]::Replace($t, '(?m)^.*"(?:CompanyName|ProductName|FileDescription)".*$', $ev)
    if ($n -ne $t) { [System.IO.File]::WriteAllText((Resolve-Path $rc).Path, $n, $utf8) }
  }
} catch {
  Write-Host "Title / app-data change skipped: $_"
}

flutter build windows --release --no-tree-shake-icons -t lib/main_kanta.dart
if ($LASTEXITCODE -ne 0) { throw "flutter build (Balaji Kanta) failed with code $LASTEXITCODE" }

$rel = Get-ChildItem -Path build/windows -Directory -Recurse -Filter Release |
  Where-Object { Test-Path (Join-Path $_.FullName 'balaji_pro.exe') } |
  Select-Object -First 1
if (-not $rel) { throw 'Release folder not found (balaji_pro.exe)' }

# the program is called balaji_kanta.exe in the installer
$stage = Join-Path $root 'kanta-stage'
if (Test-Path $stage) { Remove-Item -Recurse -Force $stage }
Copy-Item -Recurse -Force $rel.FullName $stage
Rename-Item -Path (Join-Path $stage 'balaji_pro.exe') -NewName 'balaji_kanta.exe'

$ver = '1.0.0'
$m = Select-String -Path pubspec.yaml -Pattern '^version:\s*([0-9]+\.[0-9]+\.[0-9]+)' | Select-Object -First 1
if ($m) { $ver = $m.Matches[0].Groups[1].Value }

function Find-Iscc {
  foreach ($p in @("${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe", "$env:ProgramFiles\Inno Setup 6\ISCC.exe")) {
    if (Test-Path $p) { return $p }
  }
  return $null
}
$iscc = Find-Iscc
if (-not $iscc) {
  Write-Host 'Inno Setup nathi - choco thi install kari rahyo chhu...'
  choco install innosetup -y --no-progress | Out-Host
  $iscc = Find-Iscc
}
if (-not $iscc) { throw 'Inno Setup (ISCC.exe) malyu nahi' }

$out = Join-Path $root 'installer-out'
New-Item -ItemType Directory -Force -Path $out | Out-Null
$iss = Join-Path $root 'ci/kanta_installer.iss'
$iscArgs = @("/DSrcDir=$stage", "/DAppVer=$ver", "/DOutDir=$out")
$icon = Join-Path $root 'windows/runner/resources/app_icon.ico'
if (Test-Path $icon) { $iscArgs += "/DIconFile=$icon" }

& $iscc @iscArgs $iss
if ($LASTEXITCODE -ne 0) { throw "ISCC failed with code $LASTEXITCODE" }
if (-not (Test-Path (Join-Path $out 'Balaji-Kanta-Setup.exe'))) { throw 'Balaji-Kanta-Setup.exe not created' }
Get-Item (Join-Path $out 'Balaji-Kanta-Setup.exe') | Format-List Name, Length
if ($env:GITHUB_STEP_SUMMARY) {
  Add-Content -Path $env:GITHUB_STEP_SUMMARY -Value "### Balaji Kanta Setup.exe ready (v$ver) - Artifacts ma **balaji-kanta-windows-setup**"
}
