; Balaji Pro - Windows installer script (Inno Setup 6).
; Built on GitHub Actions by ci/win_installer.ps1, which passes:
;   /DSrcDir=<flutter Release folder>  /DAppVer=<x.y.z>  /DOutDir=<output folder>  [/DIconFile=<app_icon.ico>]
#ifndef AppVer
  #define AppVer "1.0.0"
#endif

[Setup]
AppId={{6D1F3A52-8B0E-4C7A-9E21-5B7C0A4D9F13}
AppName=Balaji Pro
AppVersion={#AppVer}
AppPublisher=Balaji Industries
DefaultDirName={localappdata}\Programs\Balaji Pro
DefaultGroupName=Balaji Pro
DisableProgramGroupPage=yes
DisableDirPage=yes
PrivilegesRequired=lowest
OutputDir={#OutDir}
OutputBaseFilename=Balaji-Pro-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
CloseApplications=yes
RestartApplications=no
UninstallDisplayName=Balaji Pro
UninstallDisplayIcon={app}\balaji_pro.exe
#ifdef IconFile
SetupIconFile={#IconFile}
#endif

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Desktop par Balaji Pro shortcut banavo"; GroupDescription: "Shortcut:"

[Files]
Source: "{#SrcDir}\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion

[Icons]
Name: "{autoprograms}\Balaji Pro"; Filename: "{app}\balaji_pro.exe"
Name: "{autodesktop}\Balaji Pro"; Filename: "{app}\balaji_pro.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\balaji_pro.exe"; Description: "Balaji Pro hamna kholo"; Flags: nowait postinstall skipifsilent
