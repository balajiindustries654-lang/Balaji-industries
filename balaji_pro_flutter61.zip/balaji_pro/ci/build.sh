#!/usr/bin/env bash
# Balaji Pro - Android build. Runs inside balaji_pro/ on GitHub Actions (called by build.yml).
# Keeping the steps here means a new zip is enough to change how the app is built.
set +e
set +o pipefail
W="$GITHUB_WORKSPACE"
: > "$W/build_log.txt"
SIGNED=0

summary() { echo "$1" >> "$GITHUB_STEP_SUMMARY"; }

report() {
  local f="$W/step.txt"
  local n
  n=$(grep -cE '^\s*error (•|-) ' "$f")
  {
    echo "## ❌ Failed at: $1"
    echo
    echo "Errors found: $n"
    echo
    grep -E '^\s*error (•|-) ' "$f" | sed -E 's/^\s*error (•|-) //' | sed -E 's/^(.*) • ([^•]+) • ([^•]+)$/\2 | \3 | \1/' | tr '`' "'" | head -60 | while IFS= read -r l; do echo "- \`$l\`"; done
    echo
    echo "### Key lines"
    echo '```'
    grep -E -A3 'What went wrong|FAILURE:|Error:|Exception|Could not|not found' "$f" | head -50
    echo '```'
    echo
    echo "### Last 30 lines"
    echo '```'
    tail -n 30 "$f"
    echo '```'
  } >> "$GITHUB_STEP_SUMMARY"
  grep -E '^\s*error (•|-) ' "$f" | sed -E 's/^\s*error (•|-) //' | sed -E 's/^(.*) • ([^•]+) • ([^•]+)$/\2 | \3 | \1/' | head -10 | while IFS= read -r l; do echo "::error::$l"; done
}

step() {
  local name="$1"; shift
  echo "::group::$name"
  "$@" > "$W/step.txt" 2>&1
  local rc=$?
  cat "$W/step.txt" | tee -a "$W/build_log.txt"
  echo "::endgroup::"
  if [ $rc -ne 0 ]; then
    report "$name"
    exit 1
  fi
}

# like step, but gives the exit code back instead of stopping the build
try() {
  local name="$1"; shift
  echo "::group::$name"
  "$@" > "$W/step.txt" 2>&1
  local rc=$?
  cat "$W/step.txt" | tee -a "$W/build_log.txt"
  echo "::endgroup::"
  return $rc
}

# USB-to-RS232 cable (weighbridge): the phone may offer to open the app when the cable is plugged in
patch_usb_manifest() {
  local M=android/app/src/main/AndroidManifest.xml
  grep -q 'android.hardware.usb.host' "$M" || sed -i '0,/<manifest[^>]*>/s//&\n    <uses-feature android:name="android.hardware.usb.host" android:required="false"\/>/' "$M"
  if ! grep -q 'USB_DEVICE_ATTACHED' "$M" && [ -f android/app/src/main/res/xml/device_filter.xml ]; then
    sed -i '0,/<\/activity>/ s|</activity>|    <intent-filter>\n                <action android:name="android.hardware.usb.action.USB_DEVICE_ATTACHED"/>\n            </intent-filter>\n            <meta-data android:name="android.hardware.usb.action.USB_DEVICE_ATTACHED" android:resource="@xml/device_filter"/>\n        </activity>|' "$M"
  fi
  grep -n 'usb' "$M"
  return 0
}

patch_manifest() {
  local M=android/app/src/main/AndroidManifest.xml
  grep -q 'android.permission.INTERNET' "$M" || sed -i '0,/<manifest[^>]*>/s//&\n    <uses-permission android:name="android.permission.INTERNET"\/>/' "$M"
  sed -i -E 's/android:label="[^"]*"/android:label="Balaji Pro"/' "$M"
  # round launcher icon (only when our icon files are in the zip)
  if ! grep -q 'android:roundIcon' "$M" && [ -f android/app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml ]; then
    sed -i 's#android:icon="@mipmap/ic_launcher"#android:icon="@mipmap/ic_launcher"\n        android:roundIcon="@mipmap/ic_launcher_round"#' "$M"
  fi
  grep -n 'INTERNET\|android:label\|android:icon\|android:roundIcon' "$M"
  patch_usb_manifest
  grep -q 'android.permission.INTERNET' "$M"
}

# "Keep the phone awake while the app is open": a tiny channel in MainActivity (the screen-on flag of the window).
# lib/core/keep_awake.dart calls it; if this patch is missing or fails, the call is ignored and the app works as before.
patch_awake() {
  local f
  f=$(find android/app/src/main -name 'MainActivity.kt' 2>/dev/null | head -1)
  [ -n "$f" ] || { echo "MainActivity.kt not found - keep-awake skipped"; return 0; }
  local pk
  pk=$(grep -m1 '^package ' "$f")
  [ -n "$pk" ] || { echo "no package line in MainActivity.kt - keep-awake skipped"; return 0; }
  cp "$f" "$W/MainActivity.orig" && echo "$f" > "$W/MainActivity.path"
  cat > "$f" <<KT
$pk

import android.view.WindowManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "balaji/awake").setMethodCallHandler { call, result ->
            if (call.method == "set") {
                val on = (call.arguments as? Boolean) ?: true
                runOnUiThread {
                    if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
                result.success(true)
            } else {
                result.notImplemented()
            }
        }
    }
}
KT
  echo "keep-awake channel added to $f"
  return 0
}
# the way back (used when the APK build fails with the patch in place)
unpatch_awake() {
  [ -f "$W/MainActivity.orig" ] && [ -f "$W/MainActivity.path" ] && cp "$W/MainActivity.orig" "$(cat "$W/MainActivity.path")" && rm -f "$W/MainActivity.orig" && echo "keep-awake patch removed"
  return 0
}

# ---- optional phone plug-ins: USB-RS232 cable (usb_serial) and the file chooser (file_picker) ----
# They are added for the Android build only. Tried in this order: both, USB cable only, file chooser only.
# If none of them builds, the app is built without them (lib/data/native_io.dart is the plain version),
# so the app is always built. Every failed try is written in the build summary with its key error lines.
PLUGINS=0
PLUG_WHY=""
VARIANT=""
use_plugins() {
  local v="$1" f add
  case "$v" in
    both) f=ci/native_io_android.src; add='  usb_serial: ^0.5.2\n  file_picker: ^8.1.2' ;;
    usb) f=ci/native_io_usb.src; add='  usb_serial: ^0.5.2' ;;
    picker) f=ci/native_io_picker.src; add='  file_picker: ^8.1.2' ;;
    *) return 1 ;;
  esac
  [ -f "$f" ] || return 1
  [ -f "$W/pubspec.orig" ] || cp pubspec.yaml "$W/pubspec.orig" || return 1
  [ -f "$W/native_io.orig" ] || cp lib/data/native_io.dart "$W/native_io.orig" || return 1
  local rg
  for rg in android/build.gradle.kts android/build.gradle; do
    [ -f "$rg" ] && [ ! -f "$W/root_$(basename "$rg").orig" ] && cp "$rg" "$W/root_$(basename "$rg").orig"
  done
  cp "$W/pubspec.orig" pubspec.yaml || return 1
  cp "$f" lib/data/native_io.dart || return 1
  sed -i "s/^  crypto: \^3.0.3\$/&\n$add/" pubspec.yaml
  grep -qE '^  (usb_serial|file_picker):' pubspec.yaml || return 1
  PLUGINS=1
  VARIANT="$v"
  return 0
}
drop_plugins() {
  local rg
  [ -f "$W/pubspec.orig" ] && cp "$W/pubspec.orig" pubspec.yaml
  [ -f "$W/native_io.orig" ] && cp "$W/native_io.orig" lib/data/native_io.dart
  for rg in android/build.gradle.kts android/build.gradle; do
    [ -f "$W/root_$(basename "$rg").orig" ] && cp "$W/root_$(basename "$rg").orig" "$rg"
  done
  PLUGINS=0
  VARIANT=""
}
# older plug-in versions miss the Gradle "namespace" (or still use jcenter): fix that in the downloaded copy
patch_plugin_gradle() {
  local d g pk
  for d in "${PUB_CACHE:-$HOME/.pub-cache}"/hosted/pub.dev/usb_serial-*/android "${PUB_CACHE:-$HOME/.pub-cache}"/hosted/pub.dev/file_picker-*/android; do
    # new Flutter libraries (flutter_plugin_android_lifecycle ...) need compileSdk 36; the plug-ins ship an older number
    for cg in "$d/build.gradle" "$d/build.gradle.kts"; do
      [ -f "$cg" ] && sed -i -E 's/^([[:space:]]*)compileSdk(Version)?[[:space:]]*=?[[:space:]]*[0-9]+([[:space:]]*(\/\/.*)?)$/\1compileSdk = 36/' "$cg"
    done
    g="$d/build.gradle"
    [ -f "$g" ] || continue
    sed -i 's/jcenter()/mavenCentral()/g; s/lintOptions *{/lint {/' "$g"
    # the very old Flutter "v1 embedding" (Registrar) is gone from new Flutter versions: drop that unused method
    if command -v perl > /dev/null 2>&1; then
      find "$d/src" -name '*.java' 2>/dev/null | while IFS= read -r j; do
        if grep -q 'Registrar' "$j"; then
          perl -0pi -e 's/(?:\@\w+(?:\([^)]*\))?\s*)*public\s+static\s+void\s+registerWith\s*\(\s*(?:PluginRegistry\.)?Registrar\s+\w+\s*\)\s*(?<b>\{(?:[^{}]++|(?&b))*\})//g; s/^\s*import\s+io\.flutter\.plugin\.common\.PluginRegistry(?:\.Registrar)?;\s*\n//mg' "$j"
          echo "patched v1 embedding in $j"
        fi
      done
    fi
    if ! grep -q 'namespace' "$g"; then
      pk=$(grep -o 'package="[^"]*"' "$d/src/main/AndroidManifest.xml" 2>/dev/null | head -1 | sed 's/package="//;s/"//')
      [ -n "$pk" ] && sed -i "0,/android *{/s//android {\n    namespace '$pk'/" "$g"
    fi
  done
  return 0
}

# The USB library (UsbSerial) is downloaded from JitPack: make sure every module may use that address.
patch_jitpack() {
  local k=android/build.gradle.kts g=android/build.gradle
  if [ -f "$k" ]; then
    grep -q 'jitpack.io' "$k" || printf '\nallprojects {\n    repositories {\n        maven { url = uri("https://jitpack.io") }\n    }\n}\n' >> "$k"
  elif [ -f "$g" ]; then
    grep -q 'jitpack.io' "$g" || printf "\nallprojects {\n    repositories {\n        maven { url 'https://jitpack.io' }\n    }\n}\n" >> "$g"
  fi
  return 0
}

# after a failed try: stop the Gradle daemon and clear its folders, so the next try starts from a clean state
fresh_gradle() {
  (cd android && [ -x ./gradlew ] && ./gradlew --stop) > /dev/null 2>&1
  rm -rf android/.gradle
  flutter clean > /dev/null 2>&1
  return 0
}

# writes the key lines of a failed plug-in try into the build summary (and keeps the whole output in build_log.txt)
plug_fail_note() {
  local x one
  x=$(grep -E -B1 -A8 'What went wrong|FAILURE:|Could not resolve|Could not find|Namespace|version solving failed|error:|cannot find symbol|^\s*error (•|-) ' "$W/step.txt" | head -60)
  [ -z "$x" ] && x=$(tail -n 25 "$W/step.txt")
  {
    echo "<details open><summary>⚠️ plug-in try <b>$1</b> failed at <b>$2</b> - key lines</summary>"
    echo
    echo '```'
    echo "$x"
    echo '```'
    echo "</details>"
    echo
  } >> "$GITHUB_STEP_SUMMARY"
  one=$(printf '%s\n' "$x" | grep -E 'error:|cannot find symbol|Could not|went wrong|Namespace|^\s*>|^\s*error' | head -3 | tr '\n' ' ' | cut -c1-300)
  echo "::warning::plug-in try $1 failed at $2: $one"
}

# Same upload key for every build: updates install over the old app, and the AAB can go to Play.
setup_signing() {
  if [ -z "$KS_B64" ] || [ -z "$KS_PASS" ]; then
    echo "Upload key secrets nathi -> APK debug key thi sign thase, AAB nahi banse."
    return 0
  fi
  local KS="$RUNNER_TEMP/upload.jks"
  printf '%s' "$KS_B64" | base64 -d > "$KS" 2>/dev/null
  if [ ! -s "$KS" ]; then
    echo "::warning::ANDROID_KEYSTORE_BASE64 vanchay tevu nathi - key vagar aagal vadhu chhu."
    return 0
  fi
  mkdir -p "$HOME/.gradle"
  {
    echo "android.injected.signing.store.file=$KS"
    echo "android.injected.signing.store.password=$KS_PASS"
    echo "android.injected.signing.key.alias=${KS_ALIAS:-upload}"
    echo "android.injected.signing.key.password=$KS_PASS"
  } >> "$HOME/.gradle/gradle.properties"
  SIGNED=1
  echo "Upload key taiyar chhe."
}

# prints who signed a file (APK or AAB)
signer_of() {
  local f="$1" o=""
  local AS
  AS=$(ls "${ANDROID_HOME:-/nonexistent}"/build-tools/*/apksigner 2>/dev/null | tail -1)
  case "$f" in
    *.apk)
      if [ -n "$AS" ]; then o=$("$AS" verify --print-certs "$f" 2>/dev/null | grep -m1 'certificate DN'); fi
      ;;
  esac
  if [ -z "$o" ]; then o=$(keytool -printcert -jarfile "$f" 2>/dev/null | grep -m1 'Owner:'); fi
  echo "$o"
}

# value Flutter itself uses for the Android target (Play Store needs 36 or more for new apps)
sdk_val() {
  local d
  d=$(dirname "$(dirname "$(readlink -f "$(command -v flutter)")")")
  grep -rhoE "val $1: Int = [0-9]+" "$d/packages/flutter_tools/gradle" 2>/dev/null | grep -oE '[0-9]+$' | head -1
}

VER=$(grep -m1 '^version:' pubspec.yaml | sed 's/version:[[:space:]]*//')
summary "### Balaji Pro $VER"
TSDK=$(sdk_val targetSdkVersion)
if [ -n "$TSDK" ]; then
  summary "Android targetSdk: $TSDK (Play Store ne 36 ke vadhu joiye)"
  if [ "$TSDK" -lt 36 ] 2>/dev/null; then
    summary "⚠️ targetSdk 36 thi ochu chhe — Play Store upload reject thai shake. Mane aa line mokli aapo."
  fi
fi

step "flutter create" flutter create --platforms=android --project-name balaji_pro --org com.balajiindustries .
step "android manifest" patch_manifest
try "keep awake (MainActivity)" patch_awake
setup_signing
BUILT=0
TRIED=0
for V in both usb picker; do
  use_plugins "$V" || continue
  TRIED=1
  if ! try "pub get ($V plug-ins)" flutter pub get; then
    plug_fail_note "$V" "pub get"
    drop_plugins
    continue
  fi
  patch_plugin_gradle
  case "$V" in both|usb) patch_jitpack ;; esac
  if ! try "analyze ($V plug-ins)" flutter analyze --no-fatal-infos --no-fatal-warnings lib test; then
    plug_fail_note "$V" "analyze"
    drop_plugins
    continue
  fi
  if try "build apk ($V plug-ins)" flutter build apk --release --no-tree-shake-icons; then
    BUILT=1
    break
  fi
  plug_fail_note "$V" "build apk"
  cp "$W/step.txt" "$W/plugin_build_fail_$V.txt" 2>/dev/null
  fresh_gradle
  drop_plugins
done

if [ "$BUILT" = 1 ]; then
  case "$VARIANT" in
    both) summary "USB-RS232 cable + file chooser: **ON** in this APK" ;;
    usb) summary "USB-RS232 cable: **ON** in this APK. File chooser: OFF (that plug-in failed - key lines above). Pendrive file import ne badle file-chooser nathi." ;;
    picker) summary "USB-RS232 cable: **OFF** in this APK (the usb_serial plug-in failed - key lines above). File chooser: ON. Mane build-log mokli aapo." ;;
  esac
else
  drop_plugins
  [ "$TRIED" = 1 ] && fresh_gradle
  step "pub get" flutter pub get
  try "analyze (plain)" flutter analyze --no-fatal-infos --no-fatal-warnings lib test
  if ! try "build apk" flutter build apk --release --no-tree-shake-icons; then
    if [ -f "$W/MainActivity.orig" ]; then
      # the keep-awake patch may be the reason: take it out and build once more
      cp "$W/step.txt" "$W/awake_build_fail.txt" 2>/dev/null
      unpatch_awake
      fresh_gradle
      summary "⚠️ keep-awake (MainActivity) patch vagar build karyu - phone screen chalu rakhvanu OFF."
      step "pub get" flutter pub get
      step "build apk (without keep-awake)" flutter build apk --release --no-tree-shake-icons
    else
      report "build apk"
      exit 1
    fi
  fi
  if [ "$TRIED" = 1 ]; then
    summary "USB-RS232 cable: **OFF** in this APK (every plug-in try failed - key lines above; the weighbridge file import still works). Mane build-log mokli aapo."
  else
    summary "USB-RS232 cable: **OFF** in this APK (plug-in files not found in the zip)."
  fi
fi

summary "Kanta USB (Live) \"Bridge app\" way (free TCPUART transparent Bridge app on the phone): **ON** in every build - no plug-in needed."

APK=build/app/outputs/flutter-apk/app-release.apk
APKSIG=$(signer_of "$APK")
echo "APK signer: $APKSIG" | tee -a "$W/build_log.txt"
summary "## ✅ APK ready — niche Artifacts ma balaji-pro-apk"
if [ "$SIGNED" = 1 ]; then
  summary "APK upload key thi sign thayu (badhi build ma same sign, etle update upar j install thase)."
else
  summary "APK debug key thi sign thayu — update karti vakhte juno app pehla uninstall karvo pade."
fi

# Play Store bundle - only with the upload key, and never allowed to spoil the APK above.
if [ "$SIGNED" = 1 ]; then
  echo "::group::build appbundle"
  flutter build appbundle --release --no-tree-shake-icons > "$W/step.txt" 2>&1
  rc=$?
  cat "$W/step.txt" | tee -a "$W/build_log.txt"
  echo "::endgroup::"
  AAB=build/app/outputs/bundle/release/app-release.aab
  if [ $rc -eq 0 ] && [ -f "$AAB" ]; then
    OWN=$(signer_of "$AAB")
    echo "AAB signer: $OWN" | tee -a "$W/build_log.txt"
    case "$OWN" in
      ""|*"Android Debug"*)
        rm -f "$AAB"
        summary "## ⚠️ AAB debug key thi sign thayu — Play Store ma nahi chale. build-log mokli aapo."
        ;;
      *)
        summary "## ✅ Play Store AAB ready — niche Artifacts ma balaji-pro-aab"
        ;;
    esac
  else
    summary "## ⚠️ AAB build fail thayu (APK to ready chhe). build-log mokli aapo."
    grep -E -A3 'What went wrong|FAILURE:|Error:|Could not' "$W/step.txt" | head -30 >> "$W/build_log.txt"
  fi
fi
exit 0
