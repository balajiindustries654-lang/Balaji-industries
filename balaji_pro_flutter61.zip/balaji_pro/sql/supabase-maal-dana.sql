-- Balaji Pro: "Dana" (kernel size / grade) of a Maal (loading / unloading) entry.
-- Supabase > SQL Editor > paste this > Run (one time). Safe to run again.
alter table public.maal_entries add column if not exists dana text;
notify pgrst, 'reload schema';
