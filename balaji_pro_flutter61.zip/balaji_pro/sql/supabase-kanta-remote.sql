-- ======================================================================
-- Balaji Kanta - PHONE THI REMOTE WEIGHING  (version 1.22.0)
-- Supabase > SQL Editor > New query > aa badhu paste karo > RUN  (ek j var; farithi chalavso to pan nuksan nathi)
-- ======================================================================

-- 0) Kona ne chhut: admin + waybridge (kanta operator) login
create or replace function public.kanta_allowed()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.user_profiles p
    where p.id = auth.uid() and p.role in ('admin', 'waybridge')
  );
$$;
revoke all on function public.kanta_allowed() from public, anon;
grant execute on function public.kanta_allowed() to authenticated;

-- 1) kanta_live: kanta laptop potanu live vajan / andar ni gadi / chhelli slip ahi mukey chhe (1 row)
create table if not exists public.kanta_live (
  id            text primary key,                       -- 'main'
  weight_kg     numeric,                                -- terminal par atyare dekhatu vajan
  stable        boolean not null default false,
  steady        boolean not null default false,         -- vajan sthir ane 100 kg thi vadhu = vajan lai shakay
  connected     boolean not null default false,         -- laptop terminal sathe joday chhe
  remote_on     boolean not null default false,         -- laptop par "Phone thi vajan" switch ON
  inside        jsonb   not null default '[]'::jsonb,   -- pehlu vajan thai gayu, bijo baki
  recent        jsonb   not null default '[]'::jsonb,   -- chhelli slip
  operator_name text,
  beat          bigint  not null default 0,             -- dar vakhte vadhe (laptop jivit chhe e jovA)
  updated_at    timestamptz not null default now()
);

-- updated_at hammesha SERVER no samay (laptop / phone nu ghadiyal khotu hoy to pan chale)
create or replace function public.kanta_touch()
returns trigger
language plpgsql
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;
drop trigger if exists kanta_live_touch on public.kanta_live;
create trigger kanta_live_touch before insert or update on public.kanta_live
  for each row execute function public.kanta_touch();

-- 2) kanta_cmd: phone na hukam ("pehlu vajan lo", "bijo vajan lo", "pachhi lo")
create table if not exists public.kanta_cmd (
  id         uuid primary key default gen_random_uuid(),
  kind       text not null check (kind in ('first', 'second', 'drop', 'undo')),
  vehicle    text not null default '',
  target     text not null default '',                  -- second/drop: andar ni gadi no id;  undo: slip (RST) number
  outside    boolean not null default false,            -- rasta ni gadi (fakt laptop ma)
  party      text not null default '',
  charges    numeric not null default 0,
  seen_kg    numeric not null default 0,                -- phone par je vajan joyu hatu (laptop par badlay to nakaare)
  by_id      uuid default auth.uid(),
  by_name    text not null default '',
  status     text not null default 'new' check (status in ('new', 'working', 'done', 'error')),
  result     text not null default '',                  -- error nu karan
  kg         numeric,
  rst        text not null default '',
  created_at timestamptz not null default now(),
  done_at    timestamptz
);
create index if not exists kanta_cmd_status_idx on public.kanta_cmd (status, created_at);

-- 3) Suraksha (RLS): fakt admin ane waybridge login
alter table public.kanta_live enable row level security;
alter table public.kanta_cmd  enable row level security;
grant select, insert, update, delete on public.kanta_live to authenticated;
grant select, insert, update, delete on public.kanta_cmd  to authenticated;

drop policy if exists "kanta_live all" on public.kanta_live;
create policy "kanta_live all" on public.kanta_live
  for all to authenticated
  using (public.kanta_allowed())
  with check (public.kanta_allowed());

drop policy if exists "kanta_cmd read" on public.kanta_cmd;
create policy "kanta_cmd read" on public.kanta_cmd
  for select to authenticated using (public.kanta_allowed());

drop policy if exists "kanta_cmd insert" on public.kanta_cmd;
create policy "kanta_cmd insert" on public.kanta_cmd
  for insert to authenticated
  with check (public.kanta_allowed() and by_id = auth.uid());

drop policy if exists "kanta_cmd update" on public.kanta_cmd;
create policy "kanta_cmd update" on public.kanta_cmd
  for update to authenticated
  using (public.kanta_allowed())
  with check (public.kanta_allowed());

drop policy if exists "kanta_cmd delete" on public.kanta_cmd;
create policy "kanta_cmd delete" on public.kanta_cmd
  for delete to authenticated using (public.kanta_allowed());

-- Pati. Have: Balaji Pro (phone) > Kanta Remote kholo; kanta laptop par Balaji Kanta ma "Phone thi vajan" switch ON karo.
