-- Balaji Kanta: extra columns on the weighbridge entries (gross, tare, supplier, mobile, material, city, charges).
-- Run ONCE in Supabase > SQL Editor > New query > paste > Run.
-- Safe to run again (add column if not exists). Nothing is deleted or changed in the old entries.
-- Until this is run, Balaji Kanta keeps these details on the laptop only (slip + CSV files) and everything else works as before.

alter table public.waybridge_entries
  add column if not exists gross_kg     numeric,
  add column if not exists tare_kg      numeric,
  add column if not exists party_name   text,
  add column if not exists party_mobile text,
  add column if not exists material     text,
  add column if not exists city         text,
  add column if not exists charges_rs   numeric;

-- let the API see the new columns at once
notify pgrst, 'reload schema';
