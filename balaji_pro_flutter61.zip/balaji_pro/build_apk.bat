@echo off
flutter create --platforms=android --project-name balaji_pro --org com.balajiindustries .
flutter pub get
flutter build apk --release
echo.
echo APK: build\app\outputs\flutter-apk\app-release.apk
pause
