import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:balaji_pro/shell/host.dart';

void main() {
  testWidgets('app starts', (WidgetTester tester) async {
    tester.view.physicalSize = const Size(1280, 800);
    tester.view.devicePixelRatio = 1.0;
    await tester.pumpWidget(const AppRoot());
    await tester.pump(const Duration(milliseconds: 400));
    expect(find.text('Balaji Pro'), findsWidgets);
  });
}
