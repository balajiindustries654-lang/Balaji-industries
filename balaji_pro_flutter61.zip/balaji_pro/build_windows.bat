@echo off
flutter create --platforms=windows --project-name balaji_pro --org com.balajiindustries .
flutter pub get
flutter build windows --release
echo.
echo EXE folder: build\windows\x64\runner\Release
pause
