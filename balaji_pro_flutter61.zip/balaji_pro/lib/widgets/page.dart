import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/device.dart';
import '../core/palette.dart';
import '../features/registry.dart' show FeatureDef, featureById;
import '../data/models.dart' show Firm, FirmX;
import 'common.dart' show IconBtn, Seg, SearchBox;

/// Scrollable screen body with device-aware padding.
class ScreenScroll extends StatelessWidget {
  final List<Widget> children;
  final double maxWidth;
  const ScreenScroll({super.key, required this.children, this.maxWidth = 1560});

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    final double pad = Pal.tally ? 14 : (pc ? 18 : 14);
    // PC zoom makes the stage wider on paper, so the column keeps the same width on screen
    final double mw = (pc && app.zoomEff > 0.5 && app.zoomEff < 1) ? maxWidth / app.zoomEff : maxWidth;
    return SingleChildScrollView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: EdgeInsets.fromLTRB(pad, Pal.tally ? 8 : (pc ? 14 : 12), pad, pad + 20),
      child: Align(
        alignment: Alignment.topCenter,
        child: ConstrainedBox(
          constraints: BoxConstraints(maxWidth: mw),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: children),
        ),
      ),
    );
  }
}

/// Big title row used at the top of PC screens (phone has the app bar).
class ScreenHeader extends StatelessWidget {
  final String title;
  final String? sub;
  final List<Widget> actions;
  final bool onPhone;

  /// true = show [title] exactly as given. Otherwise the title of the open screen is taken from the one name list
  /// (features/registry.dart), so the menu name, the top strip and this heading can never differ.
  final bool exact;
  const ScreenHeader(this.title, {super.key, this.sub, this.actions = const <Widget>[], this.onPhone = false, this.exact = false});

  String get _shown {
    if (exact) return title;
    final String id = app.current;
    if (id == 'dashboard' || id == 'hub' || id == 'biz_home') return title;
    final FeatureDef? f = featureById(id);
    return f == null ? title : f.title;
  }

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    if (!pc && !onPhone) return const SizedBox.shrink();
    if (Pal.tally && pc) {
      // TallyPrime report head: company name, report name and period, all in the middle
      final List<Widget> acts = <Widget>[
        for (final Widget a in actions)
          // Print / Excel are already on the button bar (Ctrl+P, Alt+E)
          if (!(a is IconBtn && a.tip != null && (a.tip!.contains('Ctrl+P') || a.tip!.contains('Alt+E')))) a,
      ];
      final Widget head = Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Text(app.firm?.title ?? 'Balaji Industries', textAlign: TextAlign.center, style: ts(14, w: FontWeight.w800)),
          Text(_shown, textAlign: TextAlign.center, style: ts(13, w: FontWeight.w700, c: Pal.brand)),
          if (sub != null) Text(sub!, textAlign: TextAlign.center, style: ts(12, c: Pal.muted)),
        ],
      );
      final bool wide = acts.length > 2 || acts.any((Widget a) => a is Seg || a is SearchBox);
      if (acts.isEmpty) return Padding(padding: const EdgeInsets.only(bottom: 6), child: Center(child: head));
      if (wide) {
        // many buttons: they get their own line under the title
        return Padding(
          padding: const EdgeInsets.only(bottom: 6),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Center(child: head),
              const SizedBox(height: 4),
              Wrap(alignment: WrapAlignment.end, crossAxisAlignment: WrapCrossAlignment.center, spacing: 6, runSpacing: 4, children: acts),
            ],
          ),
        );
      }
      return Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Stack(
          children: <Widget>[
            Center(child: head),
            Positioned(
              right: 0,
              top: 0,
              child: Row(mainAxisSize: MainAxisSize.min, children: <Widget>[for (final Widget a in acts) Padding(padding: const EdgeInsets.only(left: 6), child: a)]),
            ),
          ],
        ),
      );
    }
    final Widget titleBlock = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(_shown, style: ts(pc ? 21 : 20, w: FontWeight.w800, ls: -0.4)),
        if (sub != null) ...<Widget>[
          const SizedBox(height: 2),
          Text(sub!, style: ts(pc ? 12.5 : 12.5, c: Pal.muted, h: 1.35)),
        ],
      ],
    );
    return Padding(
      padding: EdgeInsets.only(bottom: pc ? 12 : 12),
      child: pc
          ? Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Expanded(child: titleBlock),
                for (final Widget a in actions) Padding(padding: const EdgeInsets.only(left: 10), child: a),
              ],
            )
          : Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
              titleBlock,
              if (actions.isNotEmpty) ...<Widget>[
                const SizedBox(height: 10),
                Wrap(spacing: 8, runSpacing: 8, children: actions),
              ],
            ]),
    );
  }
}

/// Splits [children] into columns on PC (flex weights) and stacks on phone.
class SplitPane extends StatelessWidget {
  final List<Widget> children;
  final List<int> flex;
  final double gap;
  const SplitPane({super.key, required this.children, this.flex = const <int>[], this.gap = 16});

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    if (!pc) {
      final List<Widget> col = <Widget>[];
      for (int i = 0; i < children.length; i++) {
        if (i > 0) col.add(SizedBox(height: gap));
        col.add(children[i]);
      }
      return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: col);
    }
    final List<Widget> row = <Widget>[];
    for (int i = 0; i < children.length; i++) {
      if (i > 0) row.add(SizedBox(width: gap));
      row.add(Expanded(flex: i < flex.length ? flex[i] : 1, child: children[i]));
    }
    return Row(crossAxisAlignment: CrossAxisAlignment.start, children: row);
  }
}
