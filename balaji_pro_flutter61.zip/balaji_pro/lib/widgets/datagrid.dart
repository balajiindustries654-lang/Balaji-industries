import 'package:flutter/material.dart';
import '../core/device.dart';
import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/icons.dart';
import '../core/palette.dart';
import 'common.dart';

enum CK { text, rtext, money, kg, count, pct, date, status, dec }

class Col {
  final String label;
  final CK kind;
  final double w;
  final bool bold;
  final bool main; // shown as the big amount on phone cards
  const Col(this.label, this.kind, {this.w = 120, this.bold = false, this.main = false});

  bool get right => kind == CK.rtext || kind == CK.money || kind == CK.kg || kind == CK.count || kind == CK.pct || kind == CK.dec;
}

class GridData {
  final List<Col> cols;
  final List<List<Object?>> rows;
  final List<Object?>? totals;
  const GridData(this.cols, this.rows, {this.totals});
}

String cellText(CK k, Object? v) {
  if (v == null) return '–';
  switch (k) {
    case CK.money:
      return v is num ? inr(v) : v.toString();
    case CK.kg:
      return v is num ? grp(v) : v.toString();
    case CK.count:
      return v is num ? grp(v) : v.toString();
    case CK.dec:
      return v is num ? grp(v, dec: 1) : v.toString();
    case CK.pct:
      return v is num ? pct(v) : v.toString();
    case CK.date:
      return v is DateTime ? dmy(v) : v.toString();
    case CK.status:
      return statusText(v.toString());
    case CK.text:
      return v.toString();
    case CK.rtext:
      return v.toString();
  }
}

String gridCsv(GridData d) {
  final StringBuffer b = StringBuffer();
  b.writeln(d.cols.map((Col c) => csvCell(c.label)).join(','));
  for (final List<Object?> r in d.rows) {
    final List<String> cells = <String>[];
    for (int i = 0; i < d.cols.length; i++) {
      final Object? v = r[i];
      if (v is DateTime) {
        cells.add(csvCell('${v.year}-${pad2(v.month)}-${pad2(v.day)}'));
      } else if (v is num) {
        cells.add(csvCell(v is int ? v : (v as double).toStringAsFixed(2)));
      } else {
        cells.add(csvCell(v));
      }
    }
    b.writeln(cells.join(','));
  }
  if (d.totals != null) {
    b.writeln(d.totals!.map((Object? v) => csvCell(v is num ? v.toStringAsFixed(2) : v)).join(','));
  }
  return b.toString();
}

int _cmp(Object? a, Object? b) {
  if (a == null && b == null) return 0;
  if (a == null) return -1;
  if (b == null) return 1;
  if (a is num && b is num) return a.compareTo(b);
  if (a is DateTime && b is DateTime) return a.compareTo(b);
  return a.toString().compareTo(b.toString());
}

/// Sortable, paginated data grid. Table on PC, stacked cards on phone.
class DataGridX extends StatefulWidget {
  final GridData data;
  final void Function(int rowIndex)? onRow;
  final int pageSize;
  final String? emptyTitle;
  const DataGridX({super.key, required this.data, this.onRow, this.pageSize = 14, this.emptyTitle});

  @override
  State<DataGridX> createState() => _DataGridXState();
}

class _DataGridXState extends State<DataGridX> {
  int? _sort;
  bool _asc = true;
  int _page = 0;
  int _shown = 25;

  List<int> _order() {
    final List<int> o = List<int>.generate(widget.data.rows.length, (int i) => i);
    if (_sort != null) {
      final int s = _sort!;
      o.sort((int a, int b) {
        final int c = _cmp(widget.data.rows[a][s], widget.data.rows[b][s]);
        return _asc ? c : -c;
      });
    }
    return o;
  }

  @override
  void didUpdateWidget(covariant DataGridX old) {
    super.didUpdateWidget(old);
    if (old.data.rows.length != widget.data.rows.length) {
      _page = 0;
      _shown = 25;
    }
  }

  @override
  Widget build(BuildContext context) {
    final GridData d = widget.data;
    if (d.rows.isEmpty) {
      return EmptyBox(title: widget.emptyTitle ?? bi('કોઈ ડેટા નથી', 'No data'));
    }
    return DeviceScope.isPc(context) ? _table(context, d) : _cards(context, d);
  }

  // ------------------------------------------------------------------ PC
  Widget _table(BuildContext context, GridData d) {
    final List<int> order = _order();
    final int pages = (order.length / widget.pageSize).ceil();
    if (_page >= pages) _page = pages - 1;
    final int from = _page * widget.pageSize;
    final int to = (from + widget.pageSize) > order.length ? order.length : from + widget.pageSize;
    return LayoutBuilder(builder: (BuildContext context, BoxConstraints cons) {
      double total = 0;
      for (final Col c in d.cols) {
        total += c.w;
      }
      final double scale = cons.maxWidth > total ? (cons.maxWidth - 0.5) / total : 1.0;
      final double tw = total * scale;

      Widget head = Container(
        height: 42,
        color: Pal.surface2,
        child: Row(
          children: <Widget>[
            for (int i = 0; i < d.cols.length; i++)
              SizedBox(
                width: d.cols[i].w * scale,
                child: InkWell(
                  onTap: () => setState(() {
                    if (_sort == i) {
                      _asc = !_asc;
                    } else {
                      _sort = i;
                      _asc = true;
                    }
                  }),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Row(
                      mainAxisAlignment: d.cols[i].right ? MainAxisAlignment.end : MainAxisAlignment.start,
                      children: <Widget>[
                        Flexible(
                          child: Text(d.cols[i].label,
                              maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12, w: FontWeight.w800, c: Pal.muted, ls: 0.2)),
                        ),
                        if (_sort == i) ...<Widget>[
                          const SizedBox(width: 4),
                          Icon(ic(_asc ? 'arrowup' : 'arrowdown'), size: 13, color: Pal.brand),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      );

      final List<Widget> body = <Widget>[];
      for (int k = from; k < to; k++) {
        final int ri = order[k];
        final List<Object?> r = d.rows[ri];
        body.add(InkWell(
          onTap: widget.onRow == null ? null : () => widget.onRow!(ri),
          child: Container(
            height: 48,
            decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Pal.line.withAlpha(150)))),
            child: Row(
              children: <Widget>[
                for (int i = 0; i < d.cols.length; i++)
                  SizedBox(
                    width: d.cols[i].w * scale,
                    child: Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: _cell(d.cols[i], r[i])),
                  ),
              ],
            ),
          ),
        ));
      }
      if (d.totals != null) {
        body.add(Container(
          height: 48,
          color: Pal.soft,
          child: Row(
            children: <Widget>[
              for (int i = 0; i < d.cols.length; i++)
                SizedBox(
                  width: d.cols[i].w * scale,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Align(
                      alignment: d.cols[i].right ? Alignment.centerRight : Alignment.centerLeft,
                      child: Text(
                        d.totals![i] == null ? '' : cellText(d.cols[i].kind, d.totals![i]),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: ts(13.5, w: FontWeight.w800, c: Pal.brand, tab: true),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ));
      }

      Widget table = SizedBox(width: tw, child: Column(children: <Widget>[head, ...body]));
      if (cons.maxWidth < total) {
        table = SingleChildScrollView(scrollDirection: Axis.horizontal, child: table);
      }
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          table,
          if (pages > 1) _pager(order.length, from, to, pages),
        ],
      );
    });
  }

  Widget _pager(int n, int from, int to, int pages) {
    final List<int> nums = <int>[];
    int start = _page - 2;
    if (start < 0) start = 0;
    int end = start + 5;
    if (end > pages) {
      end = pages;
      start = end - 5 < 0 ? 0 : end - 5;
    }
    for (int i = start; i < end; i++) {
      nums.add(i);
    }
    Widget pbtn(Widget child, bool on, VoidCallback? tap) {
      return GestureDetector(
        onTap: tap,
        child: Container(
          constraints: const BoxConstraints(minWidth: 36),
          height: 36,
          margin: const EdgeInsets.only(left: 6),
          padding: const EdgeInsets.symmetric(horizontal: 8),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: on ? Pal.brand : Pal.surface,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: on ? Pal.brand : Pal.line),
          ),
          child: child,
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(border: Border(top: BorderSide(color: Pal.line))),
      child: Row(
        children: <Widget>[
          Text(bi('${from + 1}–$to / $n એન્ટ્રી', '${from + 1}–$to of $n rows'), style: ts(12.5, c: Pal.muted)),
          const Spacer(),
          pbtn(Icon(ic('chevl'), size: 18, color: Pal.muted), false, _page > 0 ? () => setState(() => _page--) : null),
          for (final int i in nums)
            pbtn(Text('${i + 1}', style: ts(13, w: FontWeight.w700, c: i == _page ? Colors.white : Pal.ink)), i == _page, () => setState(() => _page = i)),
          pbtn(Icon(ic('chev'), size: 18, color: Pal.muted), false, _page < pages - 1 ? () => setState(() => _page++) : null),
        ],
      ),
    );
  }

  Widget _cell(Col c, Object? v) {
    if (c.kind == CK.status) {
      return Align(alignment: Alignment.centerLeft, child: StatusPill(v == null ? '' : v.toString(), small: true));
    }
    return Align(
      alignment: c.right ? Alignment.centerRight : Alignment.centerLeft,
      child: Text(
        cellText(c.kind, v),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: ts(13.5, w: c.bold ? FontWeight.w800 : FontWeight.w500, tab: c.right || c.kind == CK.date),
      ),
    );
  }

  // --------------------------------------------------------------- phone
  Widget _cards(BuildContext context, GridData d) {
    final List<int> order = _order();
    int titleCol = 0;
    for (int i = 0; i < d.cols.length; i++) {
      if (d.cols[i].kind == CK.text) {
        titleCol = i;
        break;
      }
    }
    int? amtCol;
    for (int i = 0; i < d.cols.length; i++) {
      if (d.cols[i].main && i != titleCol) {
        amtCol = i;
        break;
      }
    }
    if (amtCol == null) {
      for (int i = 0; i < d.cols.length; i++) {
        if (d.cols[i].kind == CK.money && i != titleCol) {
          amtCol = i;
          break;
        }
      }
    }
    if (amtCol == null) {
      for (int i = 0; i < d.cols.length; i++) {
        if ((d.cols[i].right) && i != titleCol) {
          amtCol = i;
          break;
        }
      }
    }
    int? stCol;
    for (int i = 0; i < d.cols.length; i++) {
      if (d.cols[i].kind == CK.status) {
        stCol = i;
        break;
      }
    }
    final int count = order.length > _shown ? _shown : order.length;
    final List<Widget> items = <Widget>[];
    if (d.totals != null) {
      items.add(Surface(
        color: Pal.soft,
        border: false,
        shadow: false,
        margin: const EdgeInsets.only(bottom: 10),
        child: Wrap(
          spacing: 18,
          runSpacing: 6,
          children: <Widget>[
            for (int i = 0; i < d.cols.length; i++)
              if (d.totals![i] != null && i != titleCol)
                Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(d.cols[i].label, style: ts(11.5, c: Pal.muted, w: FontWeight.w600)),
                    Text(cellText(d.cols[i].kind, d.totals![i]), style: ts(15, w: FontWeight.w800, c: Pal.brand, tab: true)),
                  ],
                ),
          ],
        ),
      ));
    }
    for (int k = 0; k < count; k++) {
      final int ri = order[k];
      final List<Object?> r = d.rows[ri];
      final List<Widget> meta = <Widget>[];
      for (int i = 0; i < d.cols.length; i++) {
        if (i == titleCol || i == amtCol || i == stCol) continue;
        if (r[i] == null) continue;
        meta.add(RichText(
          text: TextSpan(children: <InlineSpan>[
            TextSpan(text: '${d.cols[i].label}: ', style: ts(12, c: Pal.faint)),
            TextSpan(text: cellText(d.cols[i].kind, r[i]), style: ts(12, c: Pal.muted, w: FontWeight.w700, tab: true)),
          ]),
        ));
      }
      items.add(Surface(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        onTap: widget.onRow == null ? null : () => widget.onRow!(ri),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Expanded(
                  child: Text(cellText(d.cols[titleCol].kind, r[titleCol]),
                      maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(14.5, w: FontWeight.w800)),
                ),
                if (amtCol != null) ...<Widget>[
                  const SizedBox(width: 10),
                  Text(cellText(d.cols[amtCol].kind, r[amtCol]), style: ts(15, w: FontWeight.w800, tab: true)),
                ],
              ],
            ),
            if (meta.isNotEmpty || stCol != null) const SizedBox(height: 8),
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Expanded(child: Wrap(spacing: 12, runSpacing: 4, children: meta)),
                if (stCol != null) StatusPill(r[stCol] == null ? '' : r[stCol].toString(), small: true),
              ],
            ),
          ],
        ),
      ));
    }
    if (order.length > count) {
      items.add(Btn(bi('વધુ બતાવો (${order.length - count})', 'Show more (${order.length - count})'),
          kind: BtnKind.tonal, expand: true, onTap: () => setState(() => _shown += 25)));
    }
    return Column(children: items);
  }
}
