import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import '../core/palette.dart';

/// Alpha helper that works on every Flutter version.
Color alpha(Color c, double a) => c.withAlpha((a * 255).round().clamp(0, 255).toInt());

const List<double> _steps = <double>[1, 1.2, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10];

/// Returns a "nice" step so that 4 intervals cover [maxV].
double niceStep(double maxV) {
  if (maxV <= 0) return 1;
  final double raw = maxV / 4;
  final double e = math.pow(10, (math.log(raw) / math.ln10).floor()).toDouble();
  for (final double s in _steps) {
    if (s * e >= raw) return s * e;
  }
  return 10 * e;
}

String defaultAxis(double v) {
  if (v == v.roundToDouble()) return v.round().toString();
  return v.toStringAsFixed(1);
}

void _text(Canvas canvas, String s, Offset o, TextStyle st, {TextAlign align = TextAlign.left, double maxW = 120}) {
  final TextPainter tp = TextPainter(
    text: TextSpan(text: s, style: st),
    textDirection: TextDirection.ltr,
    textAlign: align,
    maxLines: 1,
    ellipsis: '…',
  )..layout(maxWidth: maxW);
  double dx = o.dx;
  if (align == TextAlign.center) dx = o.dx - tp.width / 2;
  if (align == TextAlign.right) dx = o.dx - tp.width;
  tp.paint(canvas, Offset(dx, o.dy));
}

Path _smooth(List<Offset> p) {
  final Path path = Path()..moveTo(p[0].dx, p[0].dy);
  for (int i = 0; i < p.length - 1; i++) {
    final Offset p0 = i > 0 ? p[i - 1] : p[i];
    final Offset p1 = p[i];
    final Offset p2 = p[i + 1];
    final Offset p3 = i + 2 < p.length ? p[i + 2] : p2;
    path.cubicTo(
      p1.dx + (p2.dx - p0.dx) / 6,
      p1.dy + (p2.dy - p0.dy) / 6,
      p2.dx - (p3.dx - p1.dx) / 6,
      p2.dy - (p3.dy - p1.dy) / 6,
      p2.dx,
      p2.dy,
    );
  }
  return path;
}

// ------------------------------------------------------------------- Spark
class Spark extends StatelessWidget {
  final List<double> values;
  final Color color;
  final bool fill;
  const Spark({super.key, required this.values, required this.color, this.fill = false});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(size: Size.infinite, painter: _SparkPainter(values, color, fill));
  }
}

class _SparkPainter extends CustomPainter {
  final List<double> v;
  final Color color;
  final bool fill;
  _SparkPainter(this.v, this.color, this.fill);

  @override
  void paint(Canvas canvas, Size size) {
    if (v.length < 2 || size.width <= 0 || size.height <= 0) return;
    double mx = v[0], mn = v[0];
    for (final double x in v) {
      if (x > mx) mx = x;
      if (x < mn) mn = x;
    }
    final double span = (mx - mn) == 0 ? 1 : (mx - mn);
    final List<Offset> pts = <Offset>[];
    for (int i = 0; i < v.length; i++) {
      pts.add(Offset(size.width * i / (v.length - 1), size.height - 3 - (size.height - 6) * (v[i] - mn) / span));
    }
    final Path line = _smooth(pts);
    if (fill) {
      final Path area = Path.from(line)
        ..lineTo(size.width, size.height)
        ..lineTo(0, size.height)
        ..close();
      final Paint fp = Paint()
        ..shader = ui.Gradient.linear(
          Offset.zero,
          Offset(0, size.height),
          <Color>[alpha(color, 0.28), alpha(color, 0.0)],
        );
      canvas.drawPath(area, fp);
    }
    canvas.drawPath(
      line,
      Paint()
        ..color = color
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2
        ..strokeCap = StrokeCap.round,
    );
  }

  @override
  bool shouldRepaint(covariant _SparkPainter old) => true;
}

// --------------------------------------------------------------------- Bars
class BarChartX extends StatelessWidget {
  final List<double> values;
  final List<String> labels;
  final Color color;
  final int? highlight;
  final String Function(double)? axisFmt;
  final String Function(double)? valueFmt;
  final double height;
  const BarChartX({
    super.key,
    required this.values,
    required this.labels,
    required this.color,
    this.highlight,
    this.axisFmt,
    this.valueFmt,
    this.height = 220,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      width: double.infinity,
      child: CustomPaint(
        painter: _BarPainter(values, labels, color, highlight, axisFmt ?? defaultAxis, valueFmt ?? defaultAxis, Pal.muted, Pal.line),
      ),
    );
  }
}

class _BarPainter extends CustomPainter {
  final List<double> v;
  final List<String> lb;
  final Color color;
  final int? hi;
  final String Function(double) af;
  final String Function(double) vf;
  final Color muted;
  final Color line;
  _BarPainter(this.v, this.lb, this.color, this.hi, this.af, this.vf, this.muted, this.line);

  @override
  void paint(Canvas canvas, Size size) {
    if (v.isEmpty) return;
    double mx = 0;
    for (final double x in v) {
      if (x > mx) mx = x;
    }
    final double step = niceStep(mx);
    final double top = step * 4;
    const double left = 44, right = 6, topPad = 18, bottom = 26;
    final double w = size.width - left - right;
    final double h = size.height - topPad - bottom;
    final TextStyle axis = ts(11, c: muted);
    final Paint gp = Paint()
      ..color = line
      ..strokeWidth = 1;
    for (int i = 0; i <= 4; i++) {
      final double y = topPad + h - h * i / 4;
      canvas.drawLine(Offset(left, y), Offset(size.width - right, y), gp);
      _text(canvas, af(step * i), Offset(left - 8, y - 7), axis, align: TextAlign.right, maxW: left - 10);
    }
    final double bw = w / v.length;
    for (int i = 0; i < v.length; i++) {
      final double bh = math.max(2.0, h * v[i] / top);
      final double bx = left + i * bw + bw * 0.2;
      final double bwid = bw * 0.6;
      final Rect r = Rect.fromLTWH(bx, topPad + h - bh, bwid, bh);
      final bool on = hi == null || hi == i;
      canvas.drawRRect(
        RRect.fromRectAndCorners(r, topLeft: const Radius.circular(7), topRight: const Radius.circular(7)),
        Paint()..color = on ? color : alpha(color, 0.32),
      );
      if (hi == i) {
        _text(canvas, vf(v[i]), Offset(bx + bwid / 2, topPad + h - bh - 16), ts(11.5, w: FontWeight.w800, c: color),
            align: TextAlign.center, maxW: 70);
      }
      if (i < lb.length) {
        _text(canvas, lb[i], Offset(bx + bwid / 2, size.height - 19), ts(11.5, c: muted), align: TextAlign.center, maxW: bw);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _BarPainter old) => true;
}

// -------------------------------------------------------------------- Lines
class LineSeries {
  final String name;
  final List<double> values;
  final Color color;
  const LineSeries(this.name, this.values, this.color);
}

class LineChartX extends StatelessWidget {
  final List<LineSeries> series;
  final List<String> labels;
  final String Function(double)? axisFmt;
  final double height;
  const LineChartX({super.key, required this.series, required this.labels, this.axisFmt, this.height = 220});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      width: double.infinity,
      child: CustomPaint(painter: _LinePainter(series, labels, axisFmt ?? defaultAxis, Pal.muted, Pal.line, Pal.surface)),
    );
  }
}

class _LinePainter extends CustomPainter {
  final List<LineSeries> s;
  final List<String> lb;
  final String Function(double) af;
  final Color muted;
  final Color line;
  final Color surface;
  _LinePainter(this.s, this.lb, this.af, this.muted, this.line, this.surface);

  @override
  void paint(Canvas canvas, Size size) {
    if (s.isEmpty || s[0].values.length < 2) return;
    double mx = 0;
    for (final LineSeries x in s) {
      for (final double v in x.values) {
        if (v > mx) mx = v;
      }
    }
    final double step = niceStep(mx);
    final double top = step * 4;
    const double left = 44, right = 12, topPad = 14, bottom = 26;
    final double w = size.width - left - right;
    final double h = size.height - topPad - bottom;
    final Paint gp = Paint()
      ..color = line
      ..strokeWidth = 1;
    for (int i = 0; i <= 4; i++) {
      final double y = topPad + h - h * i / 4;
      canvas.drawLine(Offset(left, y), Offset(size.width - right, y), gp);
      _text(canvas, af(step * i), Offset(left - 8, y - 7), ts(11, c: muted), align: TextAlign.right, maxW: left - 10);
    }
    final int n = s[0].values.length;
    for (int i = 0; i < lb.length && i < n; i++) {
      _text(canvas, lb[i], Offset(left + w * i / (n - 1), size.height - 19), ts(11.5, c: muted), align: TextAlign.center, maxW: 60);
    }
    for (int k = 0; k < s.length; k++) {
      final LineSeries se = s[k];
      final List<Offset> pts = <Offset>[];
      for (int i = 0; i < se.values.length; i++) {
        pts.add(Offset(left + w * i / (se.values.length - 1), topPad + h - h * se.values[i] / top));
      }
      final Path p = _smooth(pts);
      if (k == 0) {
        final Path area = Path.from(p)
          ..lineTo(pts.last.dx, topPad + h)
          ..lineTo(pts.first.dx, topPad + h)
          ..close();
        canvas.drawPath(
          area,
          Paint()
            ..shader = ui.Gradient.linear(
              Offset(0, topPad),
              Offset(0, topPad + h),
              <Color>[alpha(se.color, 0.26), alpha(se.color, 0.0)],
            ),
        );
      }
      canvas.drawPath(
        p,
        Paint()
          ..color = se.color
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.6
          ..strokeCap = StrokeCap.round,
      );
      final Offset l = pts.last;
      canvas.drawCircle(l, 5, Paint()..color = surface);
      canvas.drawCircle(
        l,
        5,
        Paint()
          ..color = se.color
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.6,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _LinePainter old) => true;
}

// ------------------------------------------------------------------- Donut
class DonutPart {
  final String label;
  final double value;
  final Color color;
  const DonutPart(this.label, this.value, this.color);
}

class DonutX extends StatelessWidget {
  final List<DonutPart> parts;
  final String center;
  final String sub;
  final double size;
  final double thickness;
  const DonutX({super.key, required this.parts, required this.center, required this.sub, this.size = 150, this.thickness = 16});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(painter: _DonutPainter(parts, center, sub, thickness, Pal.line, Pal.ink, Pal.muted)),
    );
  }
}

class _DonutPainter extends CustomPainter {
  final List<DonutPart> parts;
  final String center;
  final String sub;
  final double th;
  final Color track;
  final Color ink;
  final Color muted;
  _DonutPainter(this.parts, this.center, this.sub, this.th, this.track, this.ink, this.muted);

  @override
  void paint(Canvas canvas, Size size) {
    final Offset c = Offset(size.width / 2, size.height / 2);
    final double r = math.min(size.width, size.height) / 2 - th / 2 - 2;
    final Rect rect = Rect.fromCircle(center: c, radius: r);
    canvas.drawCircle(
      c,
      r,
      Paint()
        ..color = track
        ..style = PaintingStyle.stroke
        ..strokeWidth = th,
    );
    double total = 0;
    for (final DonutPart p in parts) {
      total += p.value;
    }
    if (total > 0) {
      double a = -math.pi / 2;
      for (final DonutPart p in parts) {
        final double sweep = 2 * math.pi * p.value / total;
        final double gap = parts.length > 1 ? 0.05 : 0.0;
        canvas.drawArc(
          rect,
          a + gap / 2,
          math.max(0.01, sweep - gap),
          false,
          Paint()
            ..color = p.color
            ..style = PaintingStyle.stroke
            ..strokeWidth = th
            ..strokeCap = StrokeCap.round,
        );
        a += sweep;
      }
    }
    _text(canvas, center, Offset(c.dx, c.dy - 13), ts(size.width * 0.15, w: FontWeight.w800, c: ink), align: TextAlign.center, maxW: size.width * 0.6);
    _text(canvas, sub, Offset(c.dx, c.dy + 8), ts(11.5, c: muted), align: TextAlign.center, maxW: size.width * 0.6);
  }

  @override
  bool shouldRepaint(covariant _DonutPainter old) => true;
}

// ----------------------------------------------------------------- Heatmap
class HeatGrid extends StatelessWidget {
  final List<List<double>> data; // rows x cols
  final List<String> rowLabels;
  final List<String> colLabels;
  final Color color;
  final double height;
  const HeatGrid({super.key, required this.data, required this.rowLabels, required this.colLabels, required this.color, this.height = 240});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      width: double.infinity,
      child: CustomPaint(painter: _HeatPainter(data, rowLabels, colLabels, color, Pal.muted, Pal.line)),
    );
  }
}

class _HeatPainter extends CustomPainter {
  final List<List<double>> d;
  final List<String> rl;
  final List<String> cl;
  final Color color;
  final Color muted;
  final Color line;
  _HeatPainter(this.d, this.rl, this.cl, this.color, this.muted, this.line);

  @override
  void paint(Canvas canvas, Size size) {
    if (d.isEmpty) return;
    double mx = 0;
    for (final List<double> r in d) {
      for (final double v in r) {
        if (v > mx) mx = v;
      }
    }
    if (mx == 0) mx = 1;
    const double left = 44, top = 20;
    final int rows = d.length;
    final int cols = d[0].length;
    final double cw = (size.width - left) / cols;
    final double ch = (size.height - top) / rows;
    for (int j = 0; j < cols && j < cl.length; j++) {
      _text(canvas, cl[j], Offset(left + cw * j + cw / 2, 2), ts(10.5, c: muted), align: TextAlign.center, maxW: cw);
    }
    for (int i = 0; i < rows; i++) {
      if (i < rl.length) _text(canvas, rl[i], Offset(left - 8, top + ch * i + ch / 2 - 7), ts(11, c: muted), align: TextAlign.right, maxW: left - 10);
      for (int j = 0; j < cols; j++) {
        final double t = d[i][j] / mx;
        final Rect r = Rect.fromLTWH(left + cw * j + 1.5, top + ch * i + 1.5, cw - 3, ch - 3);
        canvas.drawRRect(
          RRect.fromRectAndRadius(r, const Radius.circular(5)),
          Paint()..color = t <= 0.001 ? line : alpha(color, 0.12 + 0.88 * t),
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant _HeatPainter old) => true;
}

// ------------------------------------------------------------ Stacked bar
class StackBar extends StatelessWidget {
  final List<DonutPart> parts;
  final double height;
  const StackBar({super.key, required this.parts, this.height = 14});

  @override
  Widget build(BuildContext context) {
    double total = 0;
    for (final DonutPart p in parts) {
      total += p.value;
    }
    if (total <= 0) return SizedBox(height: height);
    return ClipRRect(
      borderRadius: BorderRadius.circular(99),
      child: SizedBox(
        height: height,
        child: Row(
          children: <Widget>[
            for (final DonutPart p in parts)
              if (p.value > 0) Expanded(flex: math.max(1, (p.value / total * 1000).round()), child: Container(color: p.color)),
          ],
        ),
      ),
    );
  }
}

/// Small legend row: ● label
class LegendDot extends StatelessWidget {
  final Color color;
  final String label;
  final String? value;
  const LegendDot(this.color, this.label, {super.key, this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Container(width: 10, height: 10, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(3))),
        const SizedBox(width: 6),
        Text(label, style: ts(12.5, w: FontWeight.w600, c: Pal.muted)),
        if (value != null) ...<Widget>[const SizedBox(width: 6), Text(value!, style: ts(12.5, w: FontWeight.w800, tab: true))],
      ],
    );
  }
}
