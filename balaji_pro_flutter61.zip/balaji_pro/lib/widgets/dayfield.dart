import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/app_state.dart';
import '../core/fmt.dart';
import '../core/i18n.dart';
import 'common.dart';

/// Reads a typed date the way TallyPrime does: "15" = the 15th of the month shown, "1510" = 15 Oct, "151026" or
/// "15102026" = full date, "15-10-26" / "15/10" also work, "t" = today. Returns null when it is not a real date.
DateTime? parseDayText(String text, DateTime base) {
  final String t = text.trim().toLowerCase();
  if (t.isEmpty) return null;
  if (t == 't' || t == 'today') return dateOnly(DateTime.now());
  if (t == 'y') return dateOnly(DateTime.now()).subtract(const Duration(days: 1));
  final List<String> parts = t.split(RegExp(r'[^0-9]+')).where((String x) => x.isNotEmpty).toList();
  if (parts.isEmpty) return null;
  int d = 0;
  int m = base.month;
  int y = base.year;
  try {
    if (parts.length == 1) {
      final String p = parts[0];
      if (p.length <= 2) {
        d = int.parse(p);
      } else if (p.length == 4) {
        d = int.parse(p.substring(0, 2));
        m = int.parse(p.substring(2));
      } else if (p.length == 6) {
        d = int.parse(p.substring(0, 2));
        m = int.parse(p.substring(2, 4));
        y = 2000 + int.parse(p.substring(4));
      } else if (p.length == 8) {
        d = int.parse(p.substring(0, 2));
        m = int.parse(p.substring(2, 4));
        y = int.parse(p.substring(4));
      } else {
        return null;
      }
    } else {
      if (parts[0].length > 2 || parts[1].length > 2) return null;
      d = int.parse(parts[0]);
      m = int.parse(parts[1]);
      if (parts.length >= 3) {
        if (parts[2].length > 4) return null;
        y = int.parse(parts[2]);
        if (y < 100) y += 2000;
      }
    }
  } catch (_) {
    return null;
  }
  if (m < 1 || m > 12 || d < 1 || d > 31 || y < 2000 || y > 2100) return null;
  final DateTime r = DateTime(y, m, d);
  if (r.month != m) return null; // 31 Feb and the like
  return r;
}

/// A date box. PC: type the date (see [parseDayText]), "+" / "-" move one day, "T" is today, Space (or the little
/// calendar) opens the calendar, Enter goes on to the next field. Phone: tap to open the calendar.
class DayField extends StatefulWidget {
  final String label;
  final DateTime value;
  final ValueChanged<DateTime> onChanged;
  final DateTime? first;
  final DateTime? last;
  final bool stacked;
  const DayField({super.key, required this.label, required this.value, required this.onChanged, this.first, this.last, this.stacked = false});

  @override
  State<DayField> createState() => _DayFieldState();
}

class _DayFieldState extends State<DayField> {
  final TextEditingController _c = TextEditingController();
  final FocusNode _fn = FocusNode(debugLabel: 'DayField');

  String _show(DateTime d) => '${pad2(d.day)}-${pad2(d.month)}-${d.year}';

  @override
  void initState() {
    super.initState();
    _c.text = _show(widget.value);
    _fn.addListener(_onFocus);
  }

  @override
  void didUpdateWidget(DayField old) {
    super.didUpdateWidget(old);
    if (!_fn.hasFocus && old.value != widget.value) _c.text = _show(widget.value);
  }

  @override
  void dispose() {
    _fn.removeListener(_onFocus);
    _fn.dispose();
    _c.dispose();
    super.dispose();
  }

  void _onFocus() {
    if (!_fn.hasFocus) _commit();
  }

  DateTime get _hi => dateOnly(widget.last ?? DateTime.now().add(const Duration(days: 365)));
  DateTime get _lo => dateOnly(widget.first ?? DateTime(DateTime.now().year - 3));

  DateTime _clamp(DateTime d) {
    if (d.isBefore(_lo)) return _lo;
    if (d.isAfter(_hi)) return _hi;
    return d;
  }

  void _set(DateTime d) {
    final DateTime v = _clamp(dateOnly(d));
    _c.text = _show(v);
    if (_fn.hasFocus) _c.selection = TextSelection(baseOffset: 0, extentOffset: _c.text.length);
    if (v != widget.value) widget.onChanged(v);
    if (mounted) setState(() {});
  }

  DateTime _current() => parseDayText(_c.text, widget.value) ?? widget.value;

  void _commit() {
    _set(_current());
  }

  Future<void> _pickDialog() async {
    final DateTime init = _clamp(widget.value);
    final DateTime? d = await showDatePicker(context: context, initialDate: init, firstDate: _lo, lastDate: _hi);
    if (d != null) _set(d);
  }

  KeyEventResult _key(FocusNode n, KeyEvent e) {
    final String? ch = e.character;
    final bool pristine = _c.text == _show(widget.value);
    if (ch == '+' || ch == '=') {
      _set(_current().add(const Duration(days: 1)));
      return KeyEventResult.handled;
    }
    if (ch == '-' && pristine) {
      _set(_current().subtract(const Duration(days: 1)));
      return KeyEventResult.handled;
    }
    if (ch == ' ' && pristine && e is KeyDownEvent) {
      _pickDialog();
      return KeyEventResult.handled;
    }
    return KeyEventResult.ignored;
  }

  @override
  Widget build(BuildContext context) {
    final bool pc = app.stagePc;
    return FieldX(
      label: widget.label,
      controller: _c,
      focusNode: _fn,
      stacked: widget.stacked,
      suffix: dayName(widget.value),
      keyboard: TextInputType.datetime,
      readOnly: !pc,
      onTap: pc ? null : _pickDialog,
      action: TextInputAction.next,
      onSubmitted: (String _) => _commit(),
      onKey: _key,
      trailing: pc ? ExcludeFocus(child: IconBtn('cal', size: 30, tip: bi('કૅલેન્ડર (Space)', 'Calendar (Space)'), onTap: _pickDialog)) : null,
    );
  }
}
