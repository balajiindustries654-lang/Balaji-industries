import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/app_state.dart';
import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/palette.dart';
import 'accept.dart';
import 'common.dart' show Surface;

// ======================================================================
// Keyboard layer for forms and screens (TallyPrime style)
//  - Enter = next field, Up / Down = previous / next field, Esc = close the panel
//  - the first field is active when a form opens
//  - Tab order follows the order the fields are written on the screen
// ======================================================================

/// One shared policy: fields are visited in the order they are built (top to bottom, left panel then right panel).
final WidgetOrderTraversalPolicy _screenOrder = WidgetOrderTraversalPolicy();

/// Moves the focus to the next / previous field of the form that has the focus.
void focusNextField() {
  FocusManager.instance.primaryFocus?.nextFocus();
}

void focusPrevField() {
  FocusManager.instance.primaryFocus?.previousFocus();
}

/// True when the key event is a plain Enter (Enter or numpad Enter, no Ctrl / Alt).
bool isEnterKey(KeyEvent e) {
  final LogicalKeyboardKey k = e.logicalKey;
  if (k != LogicalKeyboardKey.enter && k != LogicalKeyboardKey.numpadEnter) return false;
  final HardwareKeyboard hk = HardwareKeyboard.instance;
  return !(hk.isControlPressed || hk.isAltPressed || hk.isMetaPressed);
}

/// "Leave this form?" - asked when something was typed and not saved. Y = leave, N (or Esc) = stay.
Future<bool> askLeave(BuildContext context) async {
  final bool? r = await showDialog<bool>(
    context: context,
    builder: (BuildContext c) => CallbackShortcuts(
      bindings: <ShortcutActivator, VoidCallback>{
        const SingleActivator(LogicalKeyboardKey.keyY): () => Navigator.of(c).pop(true),
        const SingleActivator(LogicalKeyboardKey.keyN): () => Navigator.of(c).pop(false),
      },
      child: Focus(
        autofocus: true,
        child: AlertDialog(
          title: Text(bi('ફોર્મ બંધ કરવું?', 'Leave this form?'), style: ts(17, w: FontWeight.w800)),
          content: Text(bi('તમે લખેલી માહિતી સેવ થઈ નથી - જતી રહેશે.', 'What you typed is not saved - it will be lost.'), style: ts(14, h: 1.45)),
          actions: <Widget>[
            TextButton(onPressed: () => Navigator.of(c).pop(false), child: Text(bi('ના, રહો  (N)', 'No, stay  (N)'), style: ts(14, w: FontWeight.w700, c: Pal.muted))),
            TextButton(onPressed: () => Navigator.of(c).pop(true), child: Text(bi('હા, બંધ કરો  (Y)', 'Yes, leave  (Y)'), style: ts(14, w: FontWeight.w800, c: Pal.bad))),
          ],
        ),
      ),
    ),
  );
  return r == true;
}

/// Keys of a row of choices (chips / segments): Left and Right change the choice, a letter jumps to the choice that
/// starts with it, Enter or Down go to the next field, Up to the previous one.
KeyEventResult choiceKey(KeyEvent e, {required int index, required List<String> labels, required ValueChanged<int> onChanged}) {
  if (e is KeyUpEvent || !app.stagePc) return KeyEventResult.ignored;
  final int n = labels.length;
  if (n == 0) return KeyEventResult.ignored;
  final LogicalKeyboardKey k = e.logicalKey;
  if (k == LogicalKeyboardKey.arrowRight) {
    onChanged(index < 0 ? 0 : (index + 1 >= n ? n - 1 : index + 1));
    return KeyEventResult.handled;
  }
  if (k == LogicalKeyboardKey.arrowLeft) {
    onChanged(index <= 0 ? 0 : index - 1);
    return KeyEventResult.handled;
  }
  if (k == LogicalKeyboardKey.arrowDown || isEnterKey(e)) {
    focusNextField();
    return KeyEventResult.handled;
  }
  if (k == LogicalKeyboardKey.arrowUp) {
    focusPrevField();
    return KeyEventResult.handled;
  }
  final String? ch = e.character;
  if (ch != null && ch.trim().length == 1) {
    final String c = ch.toLowerCase();
    for (int step = 1; step <= n; step++) {
      final int i = (index + step) % n;
      if (labels[i].toLowerCase().startsWith(c)) {
        onChanged(i);
        return KeyEventResult.handled;
      }
    }
  }
  return KeyEventResult.ignored;
}

/// Marks a table row (a Tally style register line) so that Down / Up from the search box land on the lines of the table.
class RowMark extends StatelessWidget {
  final Widget child;
  const RowMark({super.key, required this.child});

  @override
  Widget build(BuildContext context) => child;
}

/// Down or Enter in the search box of a list: the cursor moves into the first line of the list (PC keyboard).
KeyEventResult searchBoxKey(FocusNode node, KeyEvent e) {
  if (e is KeyUpEvent || !app.stagePc) return KeyEventResult.ignored;
  final LogicalKeyboardKey k = e.logicalKey;
  if (k != LogicalKeyboardKey.arrowDown && !isEnterKey(e)) return KeyEventResult.ignored;
  final BuildContext? c = node.context;
  final KeyScopeState? ks = c?.findAncestorStateOfType<KeyScopeState>();
  if (ks == null) return KeyEventResult.ignored;
  if (e is KeyDownEvent) {
    scheduleMicrotask(() => ks.focusFirstRow());
  }
  return KeyEventResult.handled;
}

/// Groups the fields of a form: keeps them in screen order, opens on the first field and (for panels) closes with Esc.
class KeyScope extends StatefulWidget {
  final Widget child;
  final bool focusFirst;
  final bool closeOnEsc;

  /// The scope of the whole open screen (there is one at a time) - Down / Up from nowhere enter its list.
  final bool screen;
  const KeyScope({super.key, required this.child, this.focusFirst = true, this.closeOnEsc = false, this.screen = false});

  @override
  State<KeyScope> createState() => KeyScopeState();
}

class KeyScopeState extends State<KeyScope> {
  /// The scope of the screen that is open now.
  static KeyScopeState? current;

  int _tries = 0;

  /// Something was typed into a box of this form (so leaving it asks first).
  bool typed = false;

  @override
  void dispose() {
    if (identical(current, this)) current = null;
    super.dispose();
  }

  /// Down / Up when nothing in the screen has the cursor: put it on the first row (card) of the screen.
  bool focusFirstRow({bool last = false}) {
    if (!mounted) return false;
    final FocusScopeNode scope = FocusScope.of(context);
    FocusNode? row;
    FocusNode? any;
    for (final FocusNode n in scope.traversalDescendants) {
      final BuildContext? c = n.context;
      if (c == null || c.findAncestorStateOfType<KeyScopeState>() != this) continue;
      any ??= n;
      final bool isRow = c.findAncestorWidgetOfExactType<EditableText>() == null &&
          (c.findAncestorWidgetOfExactType<Surface>() != null || c.findAncestorWidgetOfExactType<RowMark>() != null);
      if (isRow) {
        row = n;
        if (!last) break;
      }
    }
    final FocusNode? t = row ?? any;
    if (t == null) return false;
    t.requestFocus();
    return true;
  }

  @override
  void initState() {
    super.initState();
    if (widget.screen) current = this;
    if (widget.focusFirst) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _auto());
    }
  }

  // the form may still be loading on the first frame, so it is tried a few times
  void _auto() {
    if (!mounted || !app.stagePc) return;
    if (_hasFocusInside()) return;
    if (_focusFirst()) return;
    _tries++;
    if (_tries < 6) Timer(const Duration(milliseconds: 160), _auto);
  }

  bool _hasFocusInside() {
    final BuildContext? c = FocusManager.instance.primaryFocus?.context;
    if (c == null) return false;
    if (c.findAncestorWidgetOfExactType<EditableText>() == null) return false;
    return c.findAncestorStateOfType<KeyScopeState>() == this;
  }

  /// Puts the cursor on the first text box of the screen (the search box of a list).
  bool focusField() => _focusFirst();

  bool _focusFirst() {
    final FocusScopeNode scope = FocusScope.of(context);
    for (final FocusNode n in scope.traversalDescendants) {
      final BuildContext? c = n.context;
      if (c == null) continue;
      if (c.findAncestorStateOfType<KeyScopeState>() != this) continue;
      final EditableText? et = c.findAncestorWidgetOfExactType<EditableText>();
      if (et != null && !et.readOnly) {
        n.requestFocus();
        return true;
      }
    }
    return false;
  }

  /// Same, from inside the form (the form is a child of the scope): `KeyScopeState.refocusFrom(context)`.
  static void refocusFrom(BuildContext context) {
    context.findAncestorStateOfType<KeyScopeState>()?.refocus();
  }

  /// Puts the cursor back on the first field of the form (after a save, ready for the next entry).
  void refocus() {
    typed = false;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && app.stagePc) _focusFirst();
    });
  }

  Future<void> _esc() async {
    if (typed) {
      final bool ok = await askLeave(context);
      if (!ok || !mounted) return;
    }
    if (mounted) Navigator.of(context).maybePop();
  }

  bool _inField() {
    final BuildContext? c = FocusManager.instance.primaryFocus?.context;
    return c != null && c.findAncestorWidgetOfExactType<EditableText>() != null;
  }

  KeyEventResult _watch(FocusNode n, KeyEvent e) {
    if (!typed && e is KeyDownEvent) {
      final String? ch = e.character;
      final bool printable = ch != null && ch.trim().isNotEmpty;
      if ((printable || e.logicalKey == LogicalKeyboardKey.backspace || e.logicalKey == LogicalKeyboardKey.delete) && _inField()) typed = true;
    }
    return KeyEventResult.ignored;
  }

  @override
  Widget build(BuildContext context) {
    Widget w = FocusTraversalGroup(policy: _screenOrder, child: widget.child);
    w = Focus(canRequestFocus: false, skipTraversal: true, onKeyEvent: _watch, child: w);
    if (widget.closeOnEsc) {
      w = CallbackShortcuts(
        bindings: <ShortcutActivator, VoidCallback>{
          const SingleActivator(LogicalKeyboardKey.escape): () {
            _esc();
          },
        },
        child: w,
      );
    }
    return w;
  }
}

/// Moves the cursor to the first text box of the open screen (Ctrl + F, "/").
bool focusSearchField() => KeyScopeState.current?.focusField() ?? false;

// ----------------------------------------------------------- voucher chrome
/// The strip at the top of a voucher form in the Tally look: voucher type tag on the left, number and date on the right.
class VoucherHead extends StatelessWidget {
  final String type;
  final String? no;
  final DateTime? date;
  final String? sub;
  const VoucherHead({super.key, required this.type, this.no, this.date, this.sub});

  @override
  Widget build(BuildContext context) {
    if (!Pal.tally) return const SizedBox.shrink();
    final DateTime? d = date;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(color: Pal.surface, border: Border.all(color: Pal.line)),
      // IntrinsicHeight: a stretched Row has no height of its own inside a scrolling form
      child: IntrinsicHeight(child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
            color: Pal.vHead,
            alignment: Alignment.center,
            child: Text(type, style: ts(15, w: FontWeight.w800, c: Colors.white)),
          ),
          if (no != null && no!.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              child: Center(child: Text('${bi('નં.', 'No.')} $no', style: ts(14, w: FontWeight.w800, c: Pal.brand, tab: true))),
            ),
          if (sub != null && sub!.isNotEmpty)
            Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 6), child: Align(alignment: Alignment.centerLeft, child: Text(sub!, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12.5, c: Pal.muted)))))
          else
            const Spacer(),
          if (d != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Text(dmy(d), style: ts(14, w: FontWeight.w800, tab: true)),
                  Text(dayName(d), style: ts(11.5, c: Pal.muted)),
                ],
              ),
            ),
        ],
      )),
    );
  }
}

/// Pairs of [key, what it does] for the strip at the bottom of a form.
List<List<String>> formKeyHints() => <List<String>>[
      <String>['Enter', bi('આગળ', 'Next')],
      <String>['↑ ↓', bi('ખાનું બદલો', 'Move')],
      <String>['Ctrl+Enter', bi('સેવ (Accept)', 'Accept')],
      <String>['Esc', bi('બંધ / પાછા', 'Close')],
    ];

/// Hints for a screen or panel that only shows things.
List<List<String>> viewKeyHints() => <List<String>>[
      <String>['↑ ↓', bi('ખસો', 'Move')],
      <String>['Enter', bi('ખોલો', 'Open')],
      <String>['Esc', bi('બંધ / પાછા', 'Close')],
    ];

/// A slim strip of key hints (Tally look only). `KeyHints.auto()` shows the form keys while a form is open and the
/// plain keys otherwise.
class KeyHints extends StatelessWidget {
  final List<List<String>>? keys;
  const KeyHints(List<List<String>> this.keys, {super.key});
  const KeyHints.auto({super.key}) : keys = null;

  Widget _strip(List<List<String>> ks) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(color: Pal.surface2, border: Border(top: BorderSide(color: Pal.line))),
      child: Wrap(
        spacing: 16,
        runSpacing: 4,
        children: <Widget>[
          for (final List<String> k in ks)
            Row(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                  decoration: BoxDecoration(color: Pal.focusFill, border: Border.all(color: Pal.focusLine, width: 0.8)),
                  child: Text(k[0], style: ts(11.5, w: FontWeight.w800)),
                ),
                const SizedBox(width: 5),
                Text(k[1], style: ts(11.5, w: FontWeight.w600, c: Pal.muted)),
              ],
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!Pal.tally) return const SizedBox.shrink();
    final List<List<String>>? fixed = keys;
    if (fixed != null) return _strip(fixed);
    return ValueListenableBuilder<int>(
      valueListenable: AcceptHub.depth,
      builder: (BuildContext c, int n, Widget? w) => _strip(n > 0 ? formKeyHints() : viewKeyHints()),
    );
  }
}
