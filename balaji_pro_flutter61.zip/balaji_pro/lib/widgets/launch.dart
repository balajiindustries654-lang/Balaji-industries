import 'package:url_launcher/url_launcher.dart';
import '../core/app_state.dart';
import '../core/i18n.dart';
import 'common.dart';

/// Opens [u] in another app (phone dialer, WhatsApp, browser).
Future<bool> _open(Uri u) async {
  try {
    return await launchUrl(u, mode: LaunchMode.externalApplication);
  } catch (_) {
    return false;
  }
}

/// 10 digit Indian mobile (or anything longer that ends with 10 digits) -> "91xxxxxxxxxx".
String waNumber(String raw) {
  final String d = raw.replaceAll(RegExp(r'[^0-9]'), '');
  if (d.length < 10) return '';
  return '91${d.substring(d.length - 10)}';
}

/// Starts a phone call to [number].
Future<void> callPhone(String number) async {
  final String d = number.replaceAll(RegExp(r'[^0-9+]'), '');
  if (d.isEmpty) {
    app.toast(bi('નંબર નથી', 'No number'));
    return;
  }
  final bool ok = await _open(Uri(scheme: 'tel', path: d));
  if (!ok) copyText(d, msg: bi('ફોન ખુલ્યો નહીં - નંબર કૉપિ થયો', 'Could not open the dialer - number copied'));
}

/// Sends [text] on WhatsApp. With [phone] the chat of that person opens,
/// without it WhatsApp asks whom to send to.
Future<void> whatsappText(String text, {String phone = ''}) async {
  final String n = waNumber(phone);
  final Uri u = Uri.parse(n.isEmpty ? 'https://wa.me/?text=${Uri.encodeComponent(text)}' : 'https://wa.me/$n?text=${Uri.encodeComponent(text)}');
  final bool ok = await _open(u);
  if (!ok) copyText(text, msg: bi('WhatsApp ખુલ્યું નહીં - લખાણ કૉપિ થયું', 'Could not open WhatsApp - text copied'));
}

/// Opens the SMS app with [text].
Future<void> smsText(String phone, String text) async {
  final String d = phone.replaceAll(RegExp(r'[^0-9+]'), '');
  final bool ok = await _open(Uri(scheme: 'sms', path: d, queryParameters: <String, String>{'body': text}));
  if (!ok) copyText(text, msg: bi('SMS ખુલ્યું નહીં - લખાણ કૉપિ થયું', 'Could not open SMS - text copied'));
}
