import 'dart:async';
import 'package:flutter/foundation.dart';
import '../core/errlog.dart';

/// "Accept" of a voucher form (Ctrl + A in the Tally look, Ctrl + Enter always).
/// An open form registers its save action here; the PC key handler runs the top-most one.
class AcceptHub {
  static final List<VoidCallback> _stack = <VoidCallback>[];

  /// How many forms are open right now (the status bar changes its key hints with it).
  static final ValueNotifier<int> depth = ValueNotifier<int>(0);

  static bool get has => _stack.isNotEmpty;

  static void _sync() {
    // forms register in initState / dispose, which can be in the middle of a build - tell the listeners after it
    scheduleMicrotask(() {
      if (depth.value != _stack.length) depth.value = _stack.length;
    });
  }

  static void push(VoidCallback f) {
    _stack.remove(f);
    _stack.add(f);
    _sync();
  }

  static void pop(VoidCallback f) {
    _stack.remove(f);
    _sync();
  }

  /// Runs the save action of the form that is open on top. Returns false when no form is open.
  static bool run() {
    if (_stack.isEmpty) return false;
    final VoidCallback f = _stack.last;
    ErrLog.guard('Accept', f);
    return true;
  }
}

/// A key-driven action of whatever is open on top (the last one that registered wins), like [AcceptHub].
/// Used for Alt+D (delete the voucher), Ctrl+P / Alt+P (print), Alt+E (export) and F2 / Alt+F2 (period).
class ActionHub {
  final List<VoidCallback> _stack = <VoidCallback>[];

  /// How many actions are registered (the Tally button bar shows or hides its button with it).
  final ValueNotifier<int> count = ValueNotifier<int>(0);

  bool get has => _stack.isNotEmpty;

  void _sync() {
    // screens register in initState / dispose, which can be in the middle of a build - tell the listeners after it
    scheduleMicrotask(() {
      if (count.value != _stack.length) count.value = _stack.length;
    });
  }

  void push(VoidCallback f) {
    _stack.remove(f);
    _stack.add(f);
    _sync();
  }

  void pop(VoidCallback f) {
    _stack.remove(f);
    _sync();
  }

  /// Runs the top-most action. Returns false when there is none.
  bool run() {
    if (_stack.isEmpty) return false;
    final VoidCallback f = _stack.last;
    ErrLog.guard('key', f);
    return true;
  }
}

final ActionHub printHub = ActionHub();
final ActionHub exportHub = ActionHub();
final ActionHub deleteHub = ActionHub();
final ActionHub periodHub = ActionHub();
