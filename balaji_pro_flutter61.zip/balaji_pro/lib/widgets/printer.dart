import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:url_launcher/url_launcher.dart';

/// Opens a file with the program the PC uses for it (browser for .html, Excel for .csv). Two ways are tried.
Future<bool> openFileOnPc(String path) async {
  try {
    if (await launchUrl(Uri.file(path), mode: LaunchMode.externalApplication)) return true;
  } catch (_) {}
  try {
    if (Platform.isWindows) {
      await Process.start('explorer.exe', <String>[path]);
      return true;
    }
    if (Platform.isMacOS) {
      await Process.start('open', <String>[path]);
      return true;
    }
    if (Platform.isLinux) {
      await Process.start('xdg-open', <String>[path]);
      return true;
    }
  } catch (_) {}
  return false;
}

/// Opens a ready page ([html]) in the browser. On the PC it is saved as a temporary file and opened;
/// on the phone it is opened as a data page. The page asks to print by itself (Save as PDF works too).
/// Returns false when nothing could be opened.
Future<bool> printHtml(String html, String name) async {
  try {
    final String safe = name.replaceAll(RegExp(r'[^A-Za-z0-9_.-]'), '_');
    if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
      final File f = File('${Directory.systemTemp.path}${Platform.pathSeparator}$safe.html');
      await f.writeAsString(html, flush: true);
      return await openFileOnPc(f.path);
    }
    final Uri u = Uri.dataFromString(html, mimeType: 'text/html', encoding: utf8);
    return await launchUrl(u, mode: LaunchMode.externalApplication);
  } catch (_) {
    return false;
  }
}

/// Saves [csv] as a file that opens in Excel: Documents\\Balaji Pro Reports\\<name>.csv (PC only), and opens it.
/// Returns the path, or '' when it could not be saved (on the phone, or the folder is locked) - then the caller copies the text instead.
Future<String> saveCsvFile(String csv, String name) async {
  try {
    if (!(Platform.isWindows || Platform.isLinux || Platform.isMacOS)) return '';
    final Directory base = await getApplicationDocumentsDirectory();
    final Directory d = Directory('${base.path}${Platform.pathSeparator}Balaji Pro Reports');
    if (!await d.exists()) await d.create(recursive: true);
    final String safe = name.replaceAll(RegExp(r'[^A-Za-z0-9_.-]'), '_');
    final File f = File('${d.path}${Platform.pathSeparator}$safe.csv');
    // the mark at the start lets Excel read Gujarati letters correctly
    await f.writeAsString('\uFEFF$csv', flush: true);
    await openFileOnPc(f.path);
    return f.path;
  } catch (_) {
    return '';
  }
}
