import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/app_state.dart';
import '../core/device.dart';
import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/icons.dart';
import '../core/palette.dart';
import 'accept.dart';
import 'charts.dart';
import 'keys.dart';

Widget vgap(double h) => SizedBox(height: h);
Widget hgap(double w) => SizedBox(width: w);

void copyText(String text, {String? msg}) {
  Clipboard.setData(ClipboardData(text: text));
  app.toast(msg ?? bi('કૉપિ થયું', 'Copied'));
}

// ------------------------------------------------------------------ Surface
class Surface extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final EdgeInsets? margin;
  final VoidCallback? onTap;
  final Color? color;
  final double radius;
  final bool border;
  final bool shadow;

  const Surface({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.margin,
    this.onTap,
    this.color,
    this.radius = 14,
    this.border = true,
    this.shadow = true,
  });

  @override
  Widget build(BuildContext context) {
    final Widget inner = onTap == null
        ? Padding(padding: padding, child: child)
        : Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(Pal.rad(radius)),
              onTap: onTap,
              focusColor: Pal.tally ? Pal.focusFill : Pal.soft,
              child: Padding(padding: padding, child: child),
            ),
          );
    return Container(
      margin: margin,
      decoration: cardDeco(color: color, r: radius, border: border, shadow: shadow),
      child: inner,
    );
  }
}

// ---------------------------------------------------------------- Buttons
enum BtnKind { primary, tonal, outline, ghost, danger, amber }

class Btn extends StatefulWidget {
  final String label;
  final String? icon;
  final VoidCallback? onTap;
  final BtnKind kind;
  final bool dense;
  final bool expand;

  /// false = the keyboard (Tab / Enter) walks past this button; helper buttons in the middle of a form use it.
  final bool tabStop;

  const Btn(this.label,
      {super.key, this.icon, this.onTap, this.kind = BtnKind.primary, this.dense = false, this.expand = false, this.tabStop = true});

  @override
  State<Btn> createState() => _BtnState();
}

class _BtnState extends State<Btn> {
  bool _f = false; // the keyboard focus is on this button

  /// TallyPrime: a flat rectangle with plain text, the dark blue one is the main action; no icons.
  Widget _tallyBtn(Color bg, Color fg, Color? bd) {
    final bool main = widget.kind == BtnKind.primary || widget.kind == BtnKind.amber;
    final bool bad = widget.kind == BtnKind.danger;
    // TallyPrime has no full-width bars: only the Save / Accept button of a form stretches
    final bool wide = widget.expand && widget.icon == 'check';
    final Color fill = _f ? const Color(0xFFFFD84D) : (main ? Pal.brand : Pal.surface);
    final Color ink = _f ? const Color(0xFF1B1400) : (main ? Colors.white : (bad ? Pal.bad : Pal.ink));
    return Align(
      alignment: Alignment.centerLeft,
      widthFactor: 1,
      heightFactor: 1,
      child: Opacity(
      opacity: widget.onTap == null ? 0.5 : 1,
      child: Material(
        color: fill,
        shape: Border.all(color: _f ? Pal.focusLine : (main ? Pal.brand : Pal.line)),
        child: InkWell(
          onTap: widget.onTap,
          canRequestFocus: widget.tabStop,
          hoverColor: main ? null : Pal.focusFill,
          onFocusChange: (bool v) {
            if (mounted && v != _f) setState(() => _f = v);
          },
          child: Container(
            constraints: BoxConstraints(minHeight: widget.dense ? 22 : 26),
            padding: EdgeInsets.symmetric(horizontal: widget.dense ? 9 : 14, vertical: 3),
            child: Row(
              mainAxisSize: wide ? MainAxisSize.max : MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Flexible(child: Text(widget.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12.5, w: FontWeight.w700, c: ink))),
                if (wide && AcceptHub.has) ...<Widget>[
                  const SizedBox(width: 8),
                  Text('Ctrl+A', style: ts(11, w: FontWeight.w600, c: ink.withAlpha(190))),
                ],
              ],
            ),
          ),
        ),
      ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final BtnKind kind = widget.kind;
    final bool dense = widget.dense;
    Color bg = Pal.brand;
    Color fg = Colors.white;
    Color? bd;
    if (kind == BtnKind.tonal) {
      bg = Pal.soft;
      fg = Pal.brand;
    } else if (kind == BtnKind.outline) {
      bg = Colors.transparent;
      fg = Pal.brand;
      bd = Pal.brand;
    } else if (kind == BtnKind.ghost) {
      bg = Colors.transparent;
      fg = Pal.muted;
    } else if (kind == BtnKind.danger) {
      bg = Pal.tone('rose').bg;
      fg = Pal.tone('rose').fg;
    } else if (kind == BtnKind.amber) {
      bg = Pal.amber;
      fg = const Color(0xFF3B2705);
    }
    final bool pc = DeviceScope.isPc(context);
    if (Pal.tally) return _tallyBtn(bg, fg, bd);
    final double h = pc ? (dense ? 32 : 38) : (dense ? 40 : 48);
    final BorderRadius br = BorderRadius.circular(Pal.rad(pc ? 9 : 12));
    return Opacity(
      opacity: widget.onTap == null ? 0.5 : 1,
      child: Material(
        color: bg,
        borderRadius: br,
        child: InkWell(
          borderRadius: br,
          onTap: widget.onTap,
          canRequestFocus: widget.tabStop,
          onFocusChange: (bool v) {
            if (mounted && v != _f) setState(() => _f = v);
          },
          child: Container(
            constraints: BoxConstraints(minHeight: h),
            padding: EdgeInsets.symmetric(horizontal: pc ? (dense ? 11 : 15) : (dense ? 14 : 18)),
            decoration: BoxDecoration(
              borderRadius: br,
              border: bd == null ? null : Border.all(color: bd, width: 1.4),
            ),
            foregroundDecoration: _f ? BoxDecoration(borderRadius: br, border: Border.all(color: Pal.focusLine, width: 2.6)) : null,
            child: Row(
              mainAxisSize: widget.expand ? MainAxisSize.max : MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                if (widget.icon != null) ...<Widget>[
                  Icon(ic(widget.icon!), size: pc ? (dense ? 16 : 18) : (dense ? 18 : 20), color: fg),
                  SizedBox(width: pc ? 6 : 8),
                ],
                Flexible(
                  child: Text(widget.label,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: ts(pc ? (dense ? 12.5 : 13.5) : (dense ? 13.5 : 15), w: FontWeight.w700, c: fg)),
                ),
                // the Save button of an open form tells its key
                if (pc && widget.expand && widget.icon == 'check' && AcceptHub.has) ...<Widget>[
                  const SizedBox(width: 10),
                  Text('Ctrl+Enter', style: ts(11, w: FontWeight.w600, c: fg.withAlpha(190))),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class IconBtn extends StatelessWidget {
  final String icon;
  final VoidCallback? onTap;
  final String? tip;
  final double size;
  final Color? color;
  final Color? bg;
  final bool badge;

  const IconBtn(this.icon, {super.key, this.onTap, this.tip, this.size = 44, this.color, this.bg, this.badge = false});

  @override
  Widget build(BuildContext context) {
    if (Pal.tally && tip != null && size >= 36) {
      // TallyPrime has no icon buttons: the action is a small text button
      final String t = tip!.replaceAll(RegExp(r'\s*\([^)]*\)\s*$'), '').trim();
      Widget tb = Material(
        color: bg ?? Pal.surface,
        shape: Border.all(color: Pal.line),
        child: InkWell(
          onTap: onTap,
          hoverColor: Pal.focusFill,
          focusColor: Pal.focusFill,
          child: Container(
            constraints: const BoxConstraints(minHeight: 22),
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
            child: Center(widthFactor: 1, child: Text(t.isEmpty ? tip! : t, maxLines: 1, style: ts(12.5, w: FontWeight.w700, c: color ?? Pal.ink))),
          ),
        ),
      );
      if (badge) tb = Stack(clipBehavior: Clip.none, children: <Widget>[tb, Positioned(right: -3, top: -3, child: Container(width: 8, height: 8, color: Pal.bad))]);
      return tb;
    }
    final BorderRadius br = BorderRadius.circular(Pal.rad(size / 3.2));
    Widget w = Material(
      color: bg ?? Colors.transparent,
      borderRadius: br,
      child: InkWell(
        borderRadius: br,
        onTap: onTap,
        focusColor: Pal.tally ? Pal.focusFill : Pal.soft,
        child: SizedBox(
          width: size,
          height: size,
          child: Center(child: Icon(ic(icon), size: size * 0.5, color: color ?? Pal.muted)),
        ),
      ),
    );
    if (badge) {
      w = Stack(children: <Widget>[
        w,
        Positioned(
          right: size * 0.2,
          top: size * 0.2,
          child: Container(
            width: 9,
            height: 9,
            decoration: BoxDecoration(color: Pal.bad, shape: BoxShape.circle, border: Border.all(color: Pal.surface, width: 1.5)),
          ),
        ),
      ]);
    }
    if (tip != null) w = Tooltip(message: tip!, child: w);
    return w;
  }
}

class IconChip extends StatelessWidget {
  final String icon;
  final String tone;
  final double size;
  const IconChip(this.icon, {super.key, this.tone = 'teal', this.size = 44});

  @override
  Widget build(BuildContext context) {
    final Tone t = Pal.tone(tone);
    if (Pal.tally && size >= 30) return const SizedBox.shrink();
    final double z = DeviceScope.isPc(context) && size >= 30 ? size * 0.78 : size; // slimmer on PC
    return Container(
      width: z,
      height: z,
      decoration: BoxDecoration(color: t.bg, borderRadius: BorderRadius.circular(Pal.rad(z * 0.3))),
      child: Icon(ic(icon), size: z * 0.5, color: t.fg),
    );
  }
}

// -------------------------------------------------------------------- Pills
class Pill extends StatelessWidget {
  final String text;
  final String tone;
  final String? icon;
  final bool small;
  const Pill(this.text, {super.key, this.tone = 'teal', this.icon, this.small = false});

  @override
  Widget build(BuildContext context) {
    final Tone t = Pal.tone(tone);
    if (Pal.tally) return Text(text, style: ts(small ? 11.5 : 12, w: FontWeight.w700, c: t.fg));
    return Container(
      padding: EdgeInsets.symmetric(horizontal: small ? 8 : 10, vertical: small ? 3 : 4),
      decoration: BoxDecoration(color: t.bg, borderRadius: BorderRadius.circular(Pal.rad(99))),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          if (icon != null) ...<Widget>[Icon(ic(icon!), size: small ? 12 : 14, color: t.fg), const SizedBox(width: 4)],
          Text(text, style: ts(small ? 11 : 12, w: FontWeight.w700, c: t.fg)),
        ],
      ),
    );
  }
}

String statusText(String s) {
  switch (s) {
    case 'paid':
      return bi('ચૂકવેલ', 'Paid');
    case 'part':
      return bi('આંશિક', 'Partial');
    case 'due':
      return bi('બાકી', 'Due');
    case 'live':
      return bi('ચાલુ', 'Live');
    case 'beta':
      return bi('બીટા', 'Beta');
    case 'soon':
      return bi('જલ્દી', 'Soon');
    case 'ok':
      return bi('બરાબર', 'OK');
    case 'warn':
      return bi('ધ્યાન', 'Check');
    case 'bad':
      return bi('ભૂલ', 'Error');
    case 'done':
      return bi('પૂર્ણ', 'Done');
    case 'over':
      return bi('લિમિટ પાર', 'Over limit');
    case 'high':
      return bi('વધારે', 'High');
    case 'low':
      return bi('ઓછું', 'Low');
    case 'match':
      return bi('મેળ', 'Match');
    case 'diff':
      return bi('ફરક', 'Mismatch');
    case 'new':
      return bi('નવું', 'New');
    case 'open':
      return bi('ખુલ્લું', 'Open');
    case 'idle':
      return bi('નિષ્ક્રિય', 'Idle');
    case 'active':
      return bi('સક્રિય', 'Active');
    case 'off':
      return bi('બંધ', 'Off');
    case 'on':
      return bi('ચાલુ', 'On');
    case 'cleared':
      return bi('જમા', 'Cleared');
    case 'pending':
      return bi('બાકી', 'Pending');
    case 'Sales':
      return bi('વેચાણ', 'Sales');
    case 'Purchase':
      return bi('ખરીદી', 'Purchase');
    case 'Receipt':
      return bi('રસીદ', 'Receipt');
    case 'Payment':
      return bi('ચૂકવણી', 'Payment');
    case 'Journal':
      return bi('જર્નલ', 'Journal');
    case 'Contra':
      return bi('કોન્ટ્રા', 'Contra');
    default:
      return s;
  }
}

class StatusPill extends StatelessWidget {
  final String status;
  final bool small;
  const StatusPill(this.status, {super.key, this.small = false});

  @override
  Widget build(BuildContext context) {
    return Pill(statusText(status), tone: Pal.statusTone(status), small: small);
  }
}

class DeltaChip extends StatelessWidget {
  final String text;
  final bool down;
  const DeltaChip(this.text, {super.key, this.down = false});

  @override
  Widget build(BuildContext context) {
    return Pill(text, tone: down ? 'rose' : 'green', icon: down ? 'arrowdown' : 'arrowup', small: true);
  }
}

class Avatar extends StatelessWidget {
  final String name;
  final double size;
  const Avatar(this.name, {super.key, this.size = 40});

  @override
  Widget build(BuildContext context) {
    if (Pal.tally) return const SizedBox.shrink(); // TallyPrime lists have no pictures
    const List<String> tones = <String>['teal', 'blue', 'violet', 'amber', 'green', 'rose'];
    int h = 0;
    for (final int r in name.runes) {
      h = (h * 31 + r) & 0x7fffffff;
    }
    final Tone t = Pal.tone(tones[h % tones.length]);
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(color: t.bg, shape: BoxShape.circle),
      child: Text(initialOf(name), style: ts(size * 0.42, w: FontWeight.w800, c: t.fg)),
    );
  }
}

// ------------------------------------------------------------------ Headers
class SectionTitle extends StatelessWidget {
  final String title;
  final String? sub;
  final Widget? action;
  const SectionTitle(this.title, {super.key, this.sub, this.action});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: <Widget>[
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(title, style: ts(Pal.tally ? 13.5 : (DeviceScope.isPc(context) ? 15 : 16.5), w: FontWeight.w800, ls: Pal.tally ? 0 : -0.2)),
              if (sub != null) Text(sub!, style: ts(DeviceScope.isPc(context) ? 12 : 12.5, c: Pal.muted)),
            ],
          ),
        ),
        if (action != null) action!,
      ],
    );
  }
}

/// Card with a header row (title / subtitle / actions) and a body.
class Panel extends StatelessWidget {
  final String? title;
  final String? sub;
  final Widget? action;
  final Widget child;
  final EdgeInsets padding;
  final bool flush; // body without padding (tables)
  const Panel({
    super.key,
    this.title,
    this.sub,
    this.action,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.flush = false,
  });

  @override
  Widget build(BuildContext context) {
    if (Pal.tally) {
      return Container(
        decoration: BoxDecoration(border: Border.all(color: Pal.line)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            if (title != null)
              Container(
                padding: const EdgeInsets.fromLTRB(10, 4, 8, 4),
                decoration: BoxDecoration(color: Pal.soft, border: Border(bottom: BorderSide(color: Pal.line))),
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: Text(sub == null ? title! : '${title!}  ·  $sub', maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12.5, w: FontWeight.w800, c: Pal.brand)),
                    ),
                    if (action != null) action!,
                  ],
                ),
              ),
            if (flush) child else Padding(padding: EdgeInsets.fromLTRB(10, title == null ? 8 : 6, 10, 8), child: child),
          ],
        ),
      );
    }
    return Surface(
      padding: EdgeInsets.zero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          if (title != null)
            Padding(
              padding: EdgeInsets.fromLTRB(padding.left, padding.top, padding.right, flush ? 10 : 8),
              child: SectionTitle(title!, sub: sub, action: action),
            ),
          if (flush) child else Padding(padding: EdgeInsets.fromLTRB(padding.left, title == null ? padding.top : 4, padding.right, padding.bottom), child: child),
        ],
      ),
    );
  }
}

// --------------------------------------------------------------------- KPIs
class KpiCard extends StatelessWidget {
  final String label;
  final String value;
  final String? unit;
  final String icon;
  final String tone;
  final String? delta;
  final bool deltaDown;
  final List<double>? spark;
  final VoidCallback? onTap;
  final bool row; // phone: horizontal stacked card

  const KpiCard({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
    this.unit,
    this.tone = 'teal',
    this.delta,
    this.deltaDown = false,
    this.spark,
    this.onTap,
    this.row = false,
  });

  Widget _value(double size) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.baseline,
      textBaseline: TextBaseline.alphabetic,
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Flexible(
          child: Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(size, w: FontWeight.w800, ls: -0.4, tab: true)),
        ),
        if (unit != null) ...<Widget>[
          const SizedBox(width: 4),
          Text(unit!, style: ts(12, w: FontWeight.w700, c: Pal.muted)),
        ],
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final Tone t = Pal.tone(tone);
    if (Pal.tally) {
      return Material(
        color: Pal.surface,
        shape: Border.all(color: Pal.line),
        child: InkWell(
          onTap: onTap,
          hoverColor: Pal.focusFill,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: <Widget>[
                Expanded(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12.5, c: Pal.ink))),
                const SizedBox(width: 8),
                Text(unit == null ? value : '$value $unit', maxLines: 1, style: ts(13.5, w: FontWeight.w800, tab: true)),
                if (delta != null) ...<Widget>[const SizedBox(width: 8), Text(delta!, style: ts(11.5, w: FontWeight.w700, c: deltaDown ? Pal.bad : Pal.ok))],
              ],
            ),
          ),
        ),
      );
    }
    if (row) {
      return Surface(
        onTap: onTap,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(
          children: <Widget>[
            IconChip(icon, tone: tone, size: 46),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(label, style: ts(12.5, c: Pal.muted, w: FontWeight.w600)),
                  const SizedBox(height: 1),
                  _value(21),
                ],
              ),
            ),
            if (spark != null) SizedBox(width: 54, height: 28, child: Spark(values: spark!, color: t.fg)),
            if (delta != null) ...<Widget>[const SizedBox(width: 8), DeltaChip(delta!, down: deltaDown)],
            if (onTap != null) Icon(ic('chev'), size: 20, color: Pal.faint),
          ],
        ),
      );
    }
    return Surface(
      onTap: onTap,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Row(
            children: <Widget>[
              IconChip(icon, tone: tone, size: 40),
              const Spacer(),
              if (delta != null) DeltaChip(delta!, down: deltaDown),
            ],
          ),
          const SizedBox(height: 12),
          Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12.5, c: Pal.muted, w: FontWeight.w600)),
          const SizedBox(height: 2),
          _value(24),
          if (spark != null) ...<Widget>[
            const SizedBox(height: 10),
            SizedBox(height: 32, child: Spark(values: spark!, color: t.fg, fill: true)),
          ],
        ],
      ),
    );
  }
}

// ------------------------------------------------------------ Controls
class Seg extends StatefulWidget {
  final List<String> labels;
  final int index;
  final ValueChanged<int> onChanged;
  final bool dense;
  final List<String>? icons;
  const Seg({super.key, required this.labels, required this.index, required this.onChanged, this.dense = false, this.icons});

  @override
  State<Seg> createState() => _SegState();
}

class _SegState extends State<Seg> {
  final FocusNode _fn = FocusNode(debugLabel: 'Seg');
  bool _f = false;

  @override
  void initState() {
    super.initState();
    _fn.addListener(_onFocus);
  }

  @override
  void dispose() {
    _fn.removeListener(_onFocus);
    _fn.dispose();
    super.dispose();
  }

  void _onFocus() {
    if (mounted && _fn.hasFocus != _f) setState(() => _f = _fn.hasFocus);
  }

  @override
  Widget build(BuildContext context) {
    final List<String> labels = widget.labels;
    final int index = widget.index;
    final bool dense = widget.dense;
    final List<String>? icons = widget.icons;
    if (Pal.tally) {
      return Align(
        alignment: Alignment.centerLeft,
        widthFactor: 1,
        child: Focus(
        focusNode: _fn,
        onKeyEvent: (FocusNode n, KeyEvent e) => choiceKey(e, index: index, labels: labels, onChanged: widget.onChanged),
        child: Container(
          decoration: BoxDecoration(border: Border.all(color: _f ? Pal.focusLine : Pal.line, width: _f ? 1.6 : 1)),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              for (int i = 0; i < labels.length; i++)
                GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () {
                    widget.onChanged(i);
                    if (app.stagePc) _fn.requestFocus();
                  },
                  child: Container(
                    height: dense ? 22 : 25,
                    padding: const EdgeInsets.symmetric(horizontal: 11),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: i == index ? const Color(0xFFFFD84D) : Pal.surface,
                      border: i == 0 ? null : Border(left: BorderSide(color: Pal.line)),
                    ),
                    child: Text(labels[i], style: ts(12.5, w: i == index ? FontWeight.w800 : FontWeight.w600, c: i == index ? const Color(0xFF1B1400) : Pal.ink)),
                  ),
                ),
            ],
          ),
        ),
        ),
      );
    }
    return Focus(
      focusNode: _fn,
      onKeyEvent: (FocusNode n, KeyEvent e) => choiceKey(e, index: index, labels: labels, onChanged: widget.onChanged),
      child: Container(
        padding: const EdgeInsets.all(3),
        decoration: BoxDecoration(
          color: Pal.dark ? Pal.surface2 : const Color(0xFFEAF1F2),
          borderRadius: BorderRadius.circular(Pal.rad(12)),
          border: Border.all(color: _f ? Pal.focusLine : Colors.transparent, width: 1.8),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            for (int i = 0; i < labels.length; i++)
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () {
                  widget.onChanged(i);
                  if (app.stagePc) _fn.requestFocus();
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 150),
                  padding: EdgeInsets.symmetric(horizontal: dense ? 12 : 16, vertical: dense ? 8 : 11),
                  decoration: BoxDecoration(
                    color: i == index ? (_f ? Pal.focusFill : Pal.surface) : Colors.transparent,
                    borderRadius: BorderRadius.circular(Pal.rad(9)),
                    boxShadow: (i == index && !Pal.dark)
                        ? const <BoxShadow>[BoxShadow(color: Color(0x1A0B2C33), blurRadius: 4, offset: Offset(0, 1))]
                        : null,
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      if (icons != null) ...<Widget>[
                        Icon(ic(icons[i]), size: 16, color: i == index ? Pal.brand : Pal.muted),
                        const SizedBox(width: 6),
                      ],
                      Text(labels[i], style: ts(dense ? 12.5 : 13.5, w: FontWeight.w700, c: i == index ? Pal.brand : Pal.muted)),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

/// A labelled line for controls that are not text boxes (choices): Tally look = "Label : control", otherwise the
/// label sits above.
class LineRow extends StatelessWidget {
  final String label;
  final Widget child;
  const LineRow({super.key, required this.label, required this.child});

  @override
  Widget build(BuildContext context) {
    if (Pal.tally) {
      return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Expanded(
            flex: 4,
            child: Padding(
              padding: const EdgeInsets.only(top: 9, right: 6),
              child: Text(label, maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(13, w: FontWeight.w600)),
            ),
          ),
          Padding(padding: const EdgeInsets.only(top: 8), child: Text(':', style: ts(14, w: FontWeight.w700, c: Pal.muted))),
          const SizedBox(width: 8),
          Expanded(flex: 6, child: child),
        ],
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(label, style: ts(12.5, w: FontWeight.w600, c: Pal.muted)),
        const SizedBox(height: 6),
        child,
      ],
    );
  }
}

/// Wrap of selectable chips (single select). On the PC keyboard: Left / Right change the choice, a letter jumps to
/// the choice that starts with it, Enter (or Down) goes to the next field, Up to the previous one.
class ChipRow extends StatefulWidget {
  final List<String> labels;
  final int index;
  final ValueChanged<int> onChanged;
  final bool scroll;
  const ChipRow({super.key, required this.labels, required this.index, required this.onChanged, this.scroll = true});

  @override
  State<ChipRow> createState() => _ChipRowState();
}

class _ChipRowState extends State<ChipRow> {
  final FocusNode _fn = FocusNode(debugLabel: 'ChipRow');
  bool _f = false;

  @override
  void initState() {
    super.initState();
    _fn.addListener(_onFocus);
  }

  @override
  void dispose() {
    _fn.removeListener(_onFocus);
    _fn.dispose();
    super.dispose();
  }

  void _onFocus() {
    if (mounted && _fn.hasFocus != _f) setState(() => _f = _fn.hasFocus);
  }

  KeyEventResult _key(FocusNode node, KeyEvent e) => choiceKey(e, index: widget.index, labels: widget.labels, onChanged: widget.onChanged);

  @override
  Widget build(BuildContext context) {
    final List<String> labels = widget.labels;
    final int index = widget.index;
    if (Pal.tally) {
      // TallyPrime: plain choices; the chosen one is the yellow one
      return Focus(
        focusNode: _fn,
        onKeyEvent: _key,
        child: Container(
          decoration: BoxDecoration(border: Border.all(color: _f ? Pal.focusLine : Colors.transparent, width: 1.4)),
          child: Wrap(
            spacing: 5,
            runSpacing: 4,
            children: <Widget>[
              for (int i = 0; i < labels.length; i++)
                GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () {
                    widget.onChanged(i);
                    if (app.stagePc) _fn.requestFocus();
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 4),
                    decoration: BoxDecoration(
                      color: i == index ? const Color(0xFFFFD84D) : Pal.surface,
                      border: Border.all(color: i == index ? Pal.focusLine : Pal.line),
                    ),
                    child: Text(labels[i], style: ts(12.5, w: i == index ? FontWeight.w800 : FontWeight.w600, c: i == index ? const Color(0xFF1B1400) : Pal.ink)),
                  ),
                ),
            ],
          ),
        ),
      );
    }
    final List<Widget> chips = <Widget>[
      for (int i = 0; i < labels.length; i++)
        Padding(
          padding: const EdgeInsets.only(right: 8),
          child: GestureDetector(
            onTap: () {
              widget.onChanged(i);
              if (app.stagePc) _fn.requestFocus();
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              height: Pal.tally ? 30 : 40,
              alignment: Alignment.center,
              padding: EdgeInsets.symmetric(horizontal: Pal.tally ? 12 : 16),
              decoration: BoxDecoration(
                color: i == index ? Pal.brand : Pal.surface,
                borderRadius: BorderRadius.circular(Pal.rad(99)),
                border: Border.all(color: i == index ? Pal.brand : Pal.line),
              ),
              child: Text(labels[i], style: ts(13, w: FontWeight.w700, c: i == index ? Colors.white : Pal.muted)),
            ),
          ),
        ),
    ];
    final Widget body = widget.scroll ? SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: chips)) : Wrap(runSpacing: 6, children: chips);
    return Focus(
      focusNode: _fn,
      onKeyEvent: _key,
      child: Container(
        padding: const EdgeInsets.all(2),
        decoration: BoxDecoration(
          color: _f ? Pal.focusFill : Colors.transparent,
          border: Border.all(color: _f ? Pal.focusLine : Colors.transparent, width: 1.6),
          borderRadius: BorderRadius.circular(Pal.rad(18)),
        ),
        child: body,
      ),
    );
  }
}

class PickX<T> extends StatelessWidget {
  final String label;
  final String? icon;
  final List<T> items;
  final String Function(T) text;
  final ValueChanged<T> onSelected;
  final bool dense;
  const PickX({
    super.key,
    required this.label,
    required this.items,
    required this.text,
    required this.onSelected,
    this.icon,
    this.dense = false,
  });

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<T>(
      onSelected: onSelected,
      color: Pal.surface,
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(Pal.rad(12)), side: BorderSide(color: Pal.line)),
      itemBuilder: (BuildContext c) => <PopupMenuEntry<T>>[
        for (final T it in items) PopupMenuItem<T>(value: it, height: Pal.tally ? 30 : 46, child: Text(text(it), style: ts(Pal.tally ? 13 : 14, w: FontWeight.w600))),
      ],
      child: Container(
        height: Pal.tally ? 26 : (dense ? 40 : 44),
        padding: EdgeInsets.symmetric(horizontal: Pal.tally ? 9 : 12),
        decoration: BoxDecoration(
          color: Pal.surface,
          borderRadius: BorderRadius.circular(Pal.rad(12)),
          border: Border.all(color: Pal.line),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            if (icon != null && !Pal.tally) ...<Widget>[Icon(ic(icon!), size: 17, color: Pal.muted), const SizedBox(width: 8)],
            Text(label, style: ts(Pal.tally ? 12.5 : 13.5, w: FontWeight.w700)),
            const SizedBox(width: 6),
            Icon(ic('down'), size: 18, color: Pal.muted),
          ],
        ),
      ),
    );
  }
}

class SearchBox extends StatelessWidget {
  final String hint;
  final ValueChanged<String>? onChanged;
  final TextEditingController? controller;
  final double? width;
  final VoidCallback? onTap;
  final bool readOnly;
  const SearchBox({super.key, required this.hint, this.onChanged, this.controller, this.width, this.onTap, this.readOnly = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: Pal.tally ? 28 : 44,
      padding: EdgeInsets.symmetric(horizontal: Pal.tally ? 8 : 12),
      decoration: BoxDecoration(
        color: Pal.surface,
        borderRadius: BorderRadius.circular(Pal.rad(12)),
        border: Border.all(color: Pal.line),
      ),
      child: Row(
        children: <Widget>[
          if (!Pal.tally) Icon(ic('search'), size: 20, color: Pal.faint),
          if (!Pal.tally) const SizedBox(width: 8),
          Expanded(
            child: Focus(
              // PC keyboard: Down / Enter leave the search box and go into the list below it
              canRequestFocus: false,
              skipTraversal: true,
              onKeyEvent: searchBoxKey,
              child: TextField(
                controller: controller,
                onChanged: onChanged,
                onTap: onTap,
                readOnly: readOnly,
                style: ts(14, w: FontWeight.w600),
                cursorColor: Pal.brand,
                decoration: InputDecoration(
                  isCollapsed: true,
                  border: InputBorder.none,
                  hintText: hint,
                  hintStyle: ts(14, c: Pal.faint),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class FieldX extends StatefulWidget {
  final String label;
  final TextEditingController? controller;
  final String? hint;
  final String? suffix;
  final String? prefix;
  final TextInputType? keyboard;
  final ValueChanged<String>? onChanged;
  final bool big;
  final bool readOnly;
  final VoidCallback? onTap;
  final int maxLines;
  final bool obscure;
  final Widget? trailing;
  final ValueChanged<String>? onSubmitted;
  final TextInputAction? action;
  final FocusNode? focusNode;
  final bool autofocus;

  /// Keep the label above the box even in the Tally look (for narrow places).
  final bool stacked;

  /// Gets the key first (the suggestion list of a SuggestField uses it).
  final KeyEventResult Function(FocusNode, KeyEvent)? onKey;
  const FieldX({
    super.key,
    required this.label,
    this.controller,
    this.hint,
    this.suffix,
    this.prefix,
    this.keyboard,
    this.onChanged,
    this.big = false,
    this.readOnly = false,
    this.onTap,
    this.maxLines = 1,
    this.obscure = false,
    this.trailing,
    this.onSubmitted,
    this.action,
    this.focusNode,
    this.autofocus = false,
    this.stacked = false,
    this.onKey,
  });

  @override
  State<FieldX> createState() => _FieldXState();
}

class _FieldXState extends State<FieldX> {
  FocusNode? _own;
  bool _focused = false;

  FocusNode get _fn => widget.focusNode ?? (_own ??= FocusNode(debugLabel: 'FieldX'));

  @override
  void initState() {
    super.initState();
    _fn.addListener(_onFocus);
  }

  @override
  void didUpdateWidget(FieldX old) {
    super.didUpdateWidget(old);
    if (old.focusNode != widget.focusNode) {
      (old.focusNode ?? _own)?.removeListener(_onFocus);
      _fn.addListener(_onFocus);
    }
  }

  @override
  void dispose() {
    (widget.focusNode ?? _own)?.removeListener(_onFocus);
    _own?.dispose();
    super.dispose();
  }

  void _onFocus() {
    final bool f = _fn.hasFocus;
    // on the PC the whole value is selected when the field is entered with the keyboard, so typing replaces it
    if (f && app.stagePc && !widget.readOnly && widget.maxLines == 1) {
      final TextEditingController? c = widget.controller;
      if (c != null && c.text.isNotEmpty) {
        c.selection = TextSelection(baseOffset: 0, extentOffset: c.text.length);
      }
    }
    if (f != _focused && mounted) setState(() => _focused = f);
  }

  KeyEventResult _key(FocusNode node, KeyEvent e) {
    if (e is KeyUpEvent) return KeyEventResult.ignored;
    if (widget.onKey != null) {
      final KeyEventResult r = widget.onKey!(node, e);
      if (r == KeyEventResult.handled) return r;
    }
    if (!app.stagePc) return KeyEventResult.ignored;
    final LogicalKeyboardKey k = e.logicalKey;
    // a field that opens a picker (date, list): Enter / Space opens it
    if (widget.readOnly && widget.onTap != null && e is KeyDownEvent && (isEnterKey(e) || k == LogicalKeyboardKey.space)) {
      widget.onTap!();
      return KeyEventResult.handled;
    }
    if (widget.maxLines != 1) return KeyEventResult.ignored;
    if (k == LogicalKeyboardKey.arrowDown) {
      focusNextField();
      return KeyEventResult.handled;
    }
    if (k == LogicalKeyboardKey.arrowUp) {
      focusPrevField();
      return KeyEventResult.handled;
    }
    return KeyEventResult.ignored;
  }

  @override
  Widget build(BuildContext context) {
    final bool tally = Pal.tally && !widget.stacked;
    final bool big = widget.big;
    final bool numeric = widget.keyboard != null && widget.keyboard!.index == TextInputType.number.index;
    // Enter goes to the next field (the last field of a form goes on to the Save button)
    final TextInputAction? act = widget.action ?? ((widget.maxLines == 1 && widget.onSubmitted == null) ? TextInputAction.next : null);
    final double fs = tally ? (big ? 18 : 14) : (big ? 20 : 15);
    final Widget input = Focus(
      canRequestFocus: false,
      skipTraversal: true,
      onKeyEvent: _key,
      child: TextField(
        controller: widget.controller,
        focusNode: _fn,
        autofocus: widget.autofocus,
        keyboardType: widget.keyboard,
        onChanged: widget.onChanged,
        readOnly: widget.readOnly,
        onTap: widget.onTap,
        maxLines: widget.maxLines,
        obscureText: widget.obscure,
        onSubmitted: widget.onSubmitted,
        textInputAction: act,
        textAlign: (tally && numeric) ? TextAlign.right : TextAlign.start,
        cursorColor: Pal.brand,
        style: ts(fs, w: big ? FontWeight.w800 : FontWeight.w600, tab: true),
        decoration: InputDecoration(
          isDense: true,
          border: InputBorder.none,
          hintText: widget.hint,
          hintStyle: ts(tally ? 14 : 15, c: Pal.faint),
          contentPadding: EdgeInsets.symmetric(vertical: tally ? 7 : 13),
        ),
      ),
    );
    final List<Widget> inner = <Widget>[
      if (widget.prefix != null) ...<Widget>[Text(widget.prefix!, style: ts(big ? (tally ? 16 : 20) : (tally ? 13 : 15), w: FontWeight.w700, c: Pal.muted)), const SizedBox(width: 6)],
      Expanded(child: input),
      if (widget.suffix != null) ...<Widget>[const SizedBox(width: 6), Text(widget.suffix!, style: ts(tally ? 12.5 : 13, w: FontWeight.w700, c: Pal.muted))],
      if (widget.trailing != null) widget.trailing!,
    ];

    if (tally) {
      // TallyPrime voucher line:  Label ........ : [value]   - the active line is yellow.
      // In a narrow place (two boxes side by side) the label goes above the box instead.
      final Widget box = Container(
        constraints: BoxConstraints(minHeight: big ? 40 : 30),
        padding: const EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
          color: _focused ? Pal.focusFill : Pal.surface,
          border: Border(bottom: BorderSide(color: _focused ? Pal.focusLine : Pal.line, width: _focused ? 2 : 1)),
        ),
        child: Row(children: inner),
      );
      if (widget.label.isEmpty) return box;
      return LayoutBuilder(
        builder: (BuildContext c, BoxConstraints cons) {
          if (cons.maxWidth < 330) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(widget.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12, w: _focused ? FontWeight.w800 : FontWeight.w600, c: _focused ? Pal.brand : Pal.muted)),
                const SizedBox(height: 2),
                box,
              ],
            );
          }
          return Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Expanded(
                flex: 4,
                child: Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: Text(widget.label, maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(13, w: _focused ? FontWeight.w800 : FontWeight.w600, c: _focused ? Pal.brand : Pal.ink)),
                ),
              ),
              Text(':', style: ts(14, w: FontWeight.w700, c: Pal.muted)),
              const SizedBox(width: 8),
              Expanded(flex: 6, child: box),
            ],
          );
        },
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        if (widget.label.isNotEmpty) ...<Widget>[
          Text(widget.label, style: ts(12.5, w: FontWeight.w600, c: _focused ? Pal.brand : Pal.muted)),
          const SizedBox(height: 6),
        ],
        Container(
          constraints: BoxConstraints(minHeight: big ? 56 : 48),
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            color: Pal.surface,
            borderRadius: BorderRadius.circular(Pal.rad(12)),
            border: Border.all(color: _focused ? Pal.brand : Pal.line, width: _focused ? 1.8 : 1.2),
          ),
          child: Row(children: inner),
        ),
      ],
    );
  }
}

class EmptyBox extends StatelessWidget {
  final String icon;
  final String title;
  final String? sub;
  const EmptyBox({super.key, this.icon = 'search', required this.title, this.sub});

  @override
  Widget build(BuildContext context) {
    if (Pal.tally) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 22, horizontal: 12),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Text(title, textAlign: TextAlign.center, style: ts(13.5, w: FontWeight.w700, c: Pal.muted)),
              if (sub != null) ...<Widget>[const SizedBox(height: 4), Text(sub!, textAlign: TextAlign.center, style: ts(12.5, c: Pal.muted, h: 1.4))],
            ],
          ),
        ),
      );
    }
    return Padding(
      padding: const EdgeInsets.all(32),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(color: Pal.soft, shape: BoxShape.circle),
              child: Icon(ic(icon), size: 30, color: Pal.brand),
            ),
            const SizedBox(height: 14),
            Text(title, textAlign: TextAlign.center, style: ts(16, w: FontWeight.w800)),
            if (sub != null) ...<Widget>[
              const SizedBox(height: 6),
              Text(sub!, textAlign: TextAlign.center, style: ts(13, c: Pal.muted, h: 1.4)),
            ],
          ],
        ),
      ),
    );
  }
}

class ProgressRow extends StatelessWidget {
  final String label;
  final double value;
  final double max;
  final Color color;
  final String trailing;
  final String? sub;
  const ProgressRow({super.key, required this.label, required this.value, required this.max, required this.color, required this.trailing, this.sub});

  @override
  Widget build(BuildContext context) {
    final double f = max <= 0 ? 0.0 : (value / max).clamp(0.0, 1.0).toDouble();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Row(
          children: <Widget>[
            Expanded(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(13.5, w: FontWeight.w700))),
            Text(trailing, style: ts(13.5, w: FontWeight.w800, tab: true)),
          ],
        ),
        const SizedBox(height: 6),
        Container(
          height: 8,
          decoration: BoxDecoration(color: Pal.line, borderRadius: BorderRadius.circular(Pal.rad(99))),
          child: FractionallySizedBox(
            alignment: Alignment.centerLeft,
            widthFactor: f,
            child: Container(decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(Pal.rad(99)))),
          ),
        ),
        if (sub != null) ...<Widget>[const SizedBox(height: 4), Text(sub!, style: ts(11.5, c: Pal.muted))],
      ],
    );
  }
}

class InfoRow extends StatelessWidget {
  final String label;
  final String value;
  final bool bold;
  final Color? color;
  const InfoRow(this.label, this.value, {super.key, this.bold = false, this.color});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Expanded(child: Text(label, style: ts(13.5, c: Pal.muted))),
          const SizedBox(width: 12),
          Flexible(
            child: Text(value,
                textAlign: TextAlign.right,
                style: ts(bold ? 15 : 13.5, w: bold ? FontWeight.w800 : FontWeight.w700, c: color, tab: true)),
          ),
        ],
      ),
    );
  }
}

Widget divider() => Container(height: 1, color: Pal.line);

/// Responsive grid of widgets with a given number of columns.
class Grid extends StatelessWidget {
  final List<Widget> children;
  final int cols;
  final double gap;
  const Grid({super.key, required this.children, required this.cols, this.gap = 12});

  @override
  Widget build(BuildContext context) {
    final List<Widget> rows = <Widget>[];
    for (int i = 0; i < children.length; i += cols) {
      final List<Widget> cells = <Widget>[];
      for (int j = 0; j < cols; j++) {
        if (j > 0) cells.add(SizedBox(width: gap));
        cells.add(Expanded(child: i + j < children.length ? children[i + j] : const SizedBox()));
      }
      if (rows.isNotEmpty) rows.add(SizedBox(height: gap));
      rows.add(IntrinsicHeight(child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: cells)));
    }
    return Column(children: rows);
  }
}

// ---------------------------------------------------------------- panels
/// Phone: bottom sheet. PC: right-hand side panel.
Future<void> openPanel(BuildContext context,
    {required String title, required Widget child, double width = 520, String? sub, List<Widget>? actions, bool page = false}) {
  final DeviceScope ds = DeviceScope.of(context);
  Widget scoped(Widget w) => DeviceScope(pc: ds.pc, width: ds.width, height: ds.height, child: w);
  if (ds.pc) {
    return showGeneralDialog<void>(
      context: context,
      useRootNavigator: false,
      barrierDismissible: !(Pal.tally && page),
      barrierLabel: 'close',
      barrierColor: Pal.tally ? (page ? const Color(0x00000000) : const Color(0x33000000)) : Pal.scrim,
      transitionDuration: Duration(milliseconds: Pal.tally ? 60 : 200),
      pageBuilder: (BuildContext c, Animation<double> a1, Animation<double> a2) {
        if (Pal.tally && page) {
          // TallyPrime: a voucher is a whole screen (title strip, then the voucher on a white page), not a small box.
          // It sits exactly where a report would: under the menu bar, left of the button bar, above the status bar.
          return scoped(Padding(
            padding: const EdgeInsets.fromLTRB(0, 52, 196, 26),
            child: Material(
              color: Pal.bg,
              child: KeyScope(
                closeOnEsc: true,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    Container(
                      height: 28,
                      color: Pal.vHead,
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: Row(
                        children: <Widget>[
                          Flexible(child: Text(sub == null ? title : '$title  ($sub)', maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14, w: FontWeight.w800, c: Colors.white))),
                          const SizedBox(width: 18),
                          Text('Balaji Industries', maxLines: 1, style: ts(13, w: FontWeight.w700, c: const Color(0xFFFFE27A))),
                          const Spacer(),
                          if (actions != null) ...actions,
                          InkWell(
                            onTap: () => Navigator.of(c).pop(),
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 2),
                              decoration: BoxDecoration(border: Border.all(color: const Color(0x99FFFFFF))),
                              child: Text('Esc: ${bi('પાછા', 'Back')}', style: ts(12, w: FontWeight.w800, c: Colors.white)),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Container(
                        margin: const EdgeInsets.all(5),
                        decoration: BoxDecoration(color: Pal.surface, border: Border.all(color: Pal.line)),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: <Widget>[
                            Expanded(
                              child: SingleChildScrollView(
                                padding: const EdgeInsets.fromLTRB(18, 14, 18, 14),
                                child: Align(
                                  alignment: Alignment.topLeft,
                                  child: ConstrainedBox(constraints: BoxConstraints(maxWidth: width < 620 ? 620 : width), child: child),
                                ),
                              ),
                            ),
                            const KeyHints.auto(),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ));
        }
        if (Pal.tally) {
          // TallyPrime: a small box in the middle with a blue title line
          final double mh = ds.height * 0.88;
          return scoped(Center(
            child: ConstrainedBox(
              constraints: BoxConstraints(maxWidth: width > 700 ? 700 : width, maxHeight: mh),
              child: Material(
                color: Pal.surface,
                elevation: 6,
                shape: Border.all(color: Pal.brand, width: 1.5),
                child: KeyScope(
                  closeOnEsc: true,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      Container(
                        height: 28,
                        padding: const EdgeInsets.only(left: 10),
                        color: Pal.vHead,
                        child: Row(
                          children: <Widget>[
                            Expanded(child: Text(sub == null ? title : '$title  ($sub)', maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(13, w: FontWeight.w800, c: Colors.white))),
                            if (actions != null) ...actions,
                            InkWell(
                              onTap: () => Navigator.of(c).pop(),
                              child: Padding(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5), child: Text('Esc', style: ts(12, w: FontWeight.w800, c: const Color(0xFFD3E5F2)))),
                            ),
                          ],
                        ),
                      ),
                      Flexible(child: SingleChildScrollView(padding: const EdgeInsets.fromLTRB(14, 12, 14, 12), child: child)),
                      const KeyHints.auto(),
                    ],
                  ),
                ),
              ),
            ),
          ));
        }
        return scoped(Align(
          alignment: Alignment.centerRight,
          child: SizedBox(
            width: width,
            height: double.infinity,
            child: Material(
              color: Pal.surface,
              elevation: 12,
              child: KeyScope(
                closeOnEsc: true,
                child: Column(
                  children: <Widget>[
                    Container(
                      padding: const EdgeInsets.fromLTRB(20, 14, 12, 14),
                      decoration: BoxDecoration(color: Pal.tally ? Pal.vHead : null, border: Border(bottom: BorderSide(color: Pal.line))),
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(title, style: ts(18, w: FontWeight.w800, c: Pal.tally ? Colors.white : Pal.ink)),
                                if (sub != null) Text(sub, style: ts(12.5, c: Pal.tally ? const Color(0xFFD3E5F2) : Pal.muted)),
                              ],
                            ),
                          ),
                          if (actions != null) ...actions,
                          IconBtn('close', color: Pal.tally ? Colors.white : null, onTap: () => Navigator.of(c).pop(), tip: bi('બંધ (Esc)', 'Close (Esc)')),
                        ],
                      ),
                    ),
                    Expanded(child: SingleChildScrollView(padding: const EdgeInsets.all(20), child: child)),
                    const KeyHints.auto(),
                  ],
                ),
              ),
            ),
          ),
        ));
      },
      transitionBuilder: (BuildContext c, Animation<double> a, Animation<double> b, Widget w) {
        if (Pal.tally) return FadeTransition(opacity: a, child: w);
        return SlideTransition(
          position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero).animate(CurvedAnimation(parent: a, curve: Curves.easeOutCubic)),
          child: w,
        );
      },
    );
  }
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (BuildContext c) {
      final double maxH = MediaQuery.of(c).size.height * 0.92;
      return scoped(Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(c).viewInsets.bottom),
        child: Container(
          constraints: BoxConstraints(maxHeight: maxH),
          decoration: BoxDecoration(
            color: Pal.surface,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(26)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              const SizedBox(height: 10),
              Container(width: 44, height: 5, decoration: BoxDecoration(color: Pal.line, borderRadius: BorderRadius.circular(Pal.rad(9)))),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 10, 8, 6),
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(title, style: ts(18, w: FontWeight.w800)),
                          if (sub != null) Text(sub, style: ts(12.5, c: Pal.muted)),
                        ],
                      ),
                    ),
                    if (actions != null) ...actions,
                    IconBtn('close', onTap: () => Navigator.of(c).pop()),
                  ],
                ),
              ),
              Flexible(child: SingleChildScrollView(padding: const EdgeInsets.fromLTRB(18, 4, 18, 22), child: child)),
            ],
          ),
        ),
      ));
    },
  );
}


/// `tExp(child: Btn(...))` on a phone; on the PC in Tally mode the buttons of a row sit next to each other at
/// their own width, like the plain buttons of TallyPrime (not stretched over the whole row).
Widget tExp({required Widget child}) {
  if (!Pal.tally) return Expanded(child: child);
  return Flexible(fit: FlexFit.loose, child: Align(alignment: Alignment.centerLeft, widthFactor: 1, child: child));
}
