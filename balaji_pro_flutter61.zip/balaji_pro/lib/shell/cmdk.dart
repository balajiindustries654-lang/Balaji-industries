import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/app_state.dart';
import '../core/i18n.dart';
import '../core/icons.dart';
import '../core/palette.dart';
import '../data/engine.dart' show Dim;
import '../data/insights.dart';
import '../data/live_models.dart';
import '../data/live_store.dart';
import '../data/vouchers.dart' show kVTypes, VType, registerName;
import '../features/live/voucher_screens.dart' show DayBookArg;
import '../core/flags.dart';
import '../features/registry.dart';
import '../widgets/common.dart';

class _Cmd {
  final String icon;
  final String tone;
  final String title;
  final String tag;
  final String hay; // lower-case search text
  final VoidCallback run;
  const _Cmd(this.icon, this.tone, this.title, this.tag, this.hay, this.run);
}

List<_Cmd> _buildAll() {
  final List<_Cmd> l = <_Cmd>[];
  final String act = bi('ક્રિયા', 'Action');

  void action(String icon, String tone, String gu, String en, VoidCallback run) {
    l.add(_Cmd(icon, tone, bi(gu, en), act, '$gu $en'.toLowerCase(), run));
  }

  action('refresh', 'teal', 'ડેટા તાજો કરો', 'Refresh data', live.refresh);
  action('moon', 'slate', 'ડાર્ક / લાઇટ', 'Dark / light mode', app.toggleDark);
  action('lang', 'slate', 'ભાષા બદલો', 'Switch language', app.toggleLang);
  action('collapse', 'slate', 'સાઇડબાર નાનો / મોટો', 'Toggle sidebar', app.toggleSidebar);

  final bool admin = live.isAdmin;
  for (final FeatureDef f in kFeatures) {
    if (!shownFor(f, admin)) continue;
    l.add(_Cmd(f.icon, f.tone, f.title, groupOf(f.group).title, '${f.gu} ${f.en} ${f.id}'.toLowerCase(), () => app.go(f.id, root: true)));
  }

  if (admin) {
    // the registers of TallyPrime: the Day Book of one voucher type
    for (final VType t in kVTypes) {
      if (!screenOn('dbk_${t.code}')) continue; // simple mode: only the day books of sales, purchase, payment, receipt, expense
      final String n = registerName(t.code);
      l.add(_Cmd('book', 'teal', n, groupOf('money').title, '${t.gu} ${t.en} register day book'.toLowerCase(), () => app.go('my_daybook', arg: DayBookArg(type: t.code), root: true)));
    }
  }

  void people(Iterable<String> names, String route, String icon, String tone, String tag) {
    final Set<String> seen = <String>{};
    for (final String n in names) {
      final String t = n.trim();
      if (t.isEmpty || !seen.add(t.toLowerCase())) continue;
      l.add(_Cmd(icon, tone, t, tag, t.toLowerCase(), () => app.go(route, arg: t, root: true)));
      if (seen.length >= 120) break;
    }
  }

  void profiles(Dim dim, String icon, String tone) {
    final List<PartySummary> ds = directoryOf(dim);
    ds.sort((PartySummary a, PartySummary b) => b.kg.compareTo(a.kg));
    final String tag = '${dimName(dim)} · ${bi('પ્રોફાઇલ', 'profile')}';
    for (final PartySummary s in ds.take(150)) {
      final String t = s.ref.label.trim();
      if (t.isEmpty) continue;
      l.add(_Cmd(icon, tone, t, tag, t.toLowerCase(), () => app.go('party', arg: s.ref, root: true)));
    }
  }

  if (admin) {
    profiles(Dim.farmer, 'agri', 'green');
    profiles(Dim.vehicle, 'truck', 'blue');
    profiles(Dim.village, 'place', 'orange');
    profiles(Dim.broker, 'handshake', 'violet');
  } else {
    people(live.chits.map((Chit c) => c.farmer), 'chithi', 'agri', 'green', bi('ખેડૂત', 'Farmer'));
    people(live.chits.map((Chit c) => c.vehicle), 'chithi', 'truck', 'blue', bi('ગાડી', 'Vehicle'));
    people(live.chits.map((Chit c) => c.village), 'chithi', 'place', 'orange', bi('ગામ', 'Village'));
  }
  return l;
}

/// Ctrl + K palette: actions, every feature and every party in one search box.
Future<void> showCommandPalette(BuildContext context) {
  return showGeneralDialog<void>(
    context: context,
    useRootNavigator: false,
    barrierDismissible: true,
    barrierLabel: 'close',
    barrierColor: Pal.scrim,
    transitionDuration: const Duration(milliseconds: 140),
    pageBuilder: (BuildContext c, Animation<double> a1, Animation<double> a2) => _Palette(),
    transitionBuilder: (BuildContext c, Animation<double> a, Animation<double> b, Widget w) {
      return FadeTransition(
        opacity: CurvedAnimation(parent: a, curve: Curves.easeOut),
        child: SlideTransition(
          position: Tween<Offset>(begin: const Offset(0, -0.02), end: Offset.zero).animate(CurvedAnimation(parent: a, curve: Curves.easeOut)),
          child: w,
        ),
      );
    },
  );
}

class _Palette extends StatefulWidget {
  _Palette();

  @override
  State<_Palette> createState() => _PaletteState();
}

class _PaletteState extends State<_Palette> {
  static const double _rowH = 54;
  final TextEditingController _c = TextEditingController();
  final ScrollController _sc = ScrollController();
  final List<_Cmd> _all = _buildAll();
  List<_Cmd> _res = <_Cmd>[];
  int _sel = 0;

  @override
  void initState() {
    super.initState();
    _res = _filter('');
  }

  @override
  void dispose() {
    _c.dispose();
    _sc.dispose();
    super.dispose();
  }

  List<_Cmd> _filter(String q) {
    final String s = q.trim().toLowerCase();
    if (s.isEmpty) {
      final List<_Cmd> out = <_Cmd>[];
      for (final _Cmd x in _all) {
        if (x.tag == bi('ક્રિયા', 'Action')) out.add(x);
      }
      for (final String id in app.recent) {
        final FeatureDef? f = shownById(id, live.isAdmin);
        if (f == null) continue;
        for (final _Cmd x in _all) {
          if (x.title == f.title && !out.contains(x)) {
            out.add(x);
            break;
          }
        }
      }
      for (final _Cmd x in _all) {
        if (out.length >= 40) break;
        if (!out.contains(x)) out.add(x);
      }
      return out;
    }
    final List<String> tokens = s.split(RegExp(r'\s+'));
    final List<_Cmd> starts = <_Cmd>[];
    final List<_Cmd> rest = <_Cmd>[];
    for (final _Cmd x in _all) {
      bool ok = true;
      for (final String t in tokens) {
        if (!x.hay.contains(t)) {
          ok = false;
          break;
        }
      }
      if (!ok) continue;
      if (x.title.toLowerCase().startsWith(s)) {
        starts.add(x);
      } else {
        rest.add(x);
      }
    }
    final List<_Cmd> out = <_Cmd>[...starts, ...rest];
    return out.length > 60 ? out.sublist(0, 60) : out;
  }

  void _changed(String q) {
    setState(() {
      _res = _filter(q);
      _sel = 0;
    });
    if (_sc.hasClients) _sc.jumpTo(0);
  }

  void _move(int d) {
    if (_res.isEmpty) return;
    setState(() => _sel = (_sel + d) % _res.length);
    if (!_sc.hasClients) return;
    final double top = _sel * _rowH;
    final double view = _sc.position.viewportDimension;
    if (top < _sc.offset) {
      _sc.jumpTo(top);
    } else if (top + _rowH > _sc.offset + view) {
      _sc.jumpTo(top + _rowH - view);
    }
  }

  void _run(_Cmd x) {
    Navigator.of(context).pop();
    x.run();
  }

  KeyEventResult _key(FocusNode node, KeyEvent e) {
    if (e is! KeyDownEvent && e is! KeyRepeatEvent) return KeyEventResult.ignored;
    if (e.logicalKey == LogicalKeyboardKey.escape) {
      Navigator.of(context).pop();
      return KeyEventResult.handled;
    }
    if (e.logicalKey == LogicalKeyboardKey.arrowDown) {
      _move(1);
      return KeyEventResult.handled;
    }
    if (e.logicalKey == LogicalKeyboardKey.arrowUp) {
      _move(-1);
      return KeyEventResult.handled;
    }
    return KeyEventResult.ignored;
  }

  @override
  Widget build(BuildContext context) {
    final bool pc = MediaQuery.of(context).size.width >= 700;
    return Align(
      alignment: Alignment.topCenter,
      child: Padding(
        padding: EdgeInsets.fromLTRB(16, pc ? 84 : 40, 16, 16),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 660),
          child: Material(
            color: Pal.surface,
            elevation: 18,
            borderRadius: BorderRadius.circular(18),
            clipBehavior: Clip.antiAlias,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: SizedBox(
                    height: 58,
                    child: Row(
                      children: <Widget>[
                        Icon(ic('search'), size: 22, color: Pal.brand),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Focus(
                            onKeyEvent: _key,
                            child: TextField(
                              controller: _c,
                              autofocus: true,
                              onChanged: _changed,
                              onSubmitted: (String v) {
                                if (_res.isNotEmpty) _run(_res[_sel]);
                              },
                              cursorColor: Pal.brand,
                              style: ts(16, w: FontWeight.w600),
                              decoration: InputDecoration(
                                isCollapsed: true,
                                border: InputBorder.none,
                                hintText: bi('ફીચર, ખેડૂત, દલાલ, ખરીદદાર…', 'Features, farmers, brokers, buyers…'),
                                hintStyle: ts(16, c: Pal.faint),
                              ),
                            ),
                          ),
                        ),
                        IconBtn('close', size: 40, onTap: () => Navigator.of(context).pop()),
                      ],
                    ),
                  ),
                ),
                divider(),
                if (_res.isEmpty)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 26),
                    child: Text(bi('કંઈ મળ્યું નથી', 'No results'), style: ts(14.5, c: Pal.muted, w: FontWeight.w600)),
                  )
                else
                  ConstrainedBox(
                    constraints: const BoxConstraints(maxHeight: _rowH * 8),
                    child: ListView.builder(
                      controller: _sc,
                      shrinkWrap: true,
                      itemExtent: _rowH,
                      itemCount: _res.length,
                      itemBuilder: (BuildContext c, int i) {
                        final _Cmd x = _res[i];
                        final bool on = i == _sel;
                        return InkWell(
                          onTap: () => _run(x),
                          child: Container(
                            color: on ? Pal.soft : Colors.transparent,
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            child: Row(
                              children: <Widget>[
                                IconChip(x.icon, tone: x.tone, size: 34),
                                const SizedBox(width: 12),
                                Expanded(child: Text(x.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14.5, w: on ? FontWeight.w800 : FontWeight.w700))),
                                const SizedBox(width: 8),
                                Pill(x.tag, tone: x.tone, small: true),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
