import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/i18n.dart';
import '../core/icons.dart';
import '../core/palette.dart';
import '../data/live_store.dart';
import '../features/live/forms.dart';
import '../features/live/hisab.dart' show openCalcSheet;
import '../features/registry.dart';
import '../features/router.dart';
import '../widgets/common.dart';
import 'cmdk.dart';
import 'widgets.dart';

/// PC layout: collapsible sidebar with every feature, top bar with breadcrumb,
/// command palette, company switch and Tally status; content on the right.
class PcShell extends StatelessWidget {
  PcShell({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Pal.bg,
      body: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          _Sidebar(),
          Expanded(
            child: Column(
              children: <Widget>[
                _TopBar(),
                Expanded(child: ClipRect(child: ScreenHost())),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

String _activeId() {
  return app.current;
}

// ------------------------------------------------------------------ sidebar
class _Sidebar extends StatefulWidget {
  _Sidebar();

  @override
  State<_Sidebar> createState() => _SidebarState();
}

class _SidebarState extends State<_Sidebar> {
  String _openGroup = 'biz';
  String _lastGroup = '';

  Widget _item(FeatureDef f, bool active) {
    final bool soon = f.status == FStatus.soon;
    return Padding(
      padding: const EdgeInsets.only(bottom: 2),
      child: Material(
        color: active ? const Color(0x24FFFFFF) : Colors.transparent,
        borderRadius: BorderRadius.circular(10),
        child: InkWell(
          borderRadius: BorderRadius.circular(10),
          hoverColor: const Color(0x14FFFFFF),
          onTap: () => app.go(f.id, root: true),
          child: Container(
            height: 40,
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Row(
              children: <Widget>[
                Icon(ic(f.icon), size: 18, color: active ? Pal.tealLight : Pal.sideText),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    f.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: ts(13.5, w: active ? FontWeight.w800 : FontWeight.w600, c: active ? Colors.white : Pal.sideText),
                  ),
                ),
                if (soon) Text(bi('જલ્દી', 'Soon'), style: ts(10.5, w: FontWeight.w600, c: Pal.faint)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _groupHeader(GroupDef g, bool open, bool hasActive, int count) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(10),
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        hoverColor: const Color(0x14FFFFFF),
        onTap: () => setState(() => _openGroup = open ? '' : g.id),
        child: Container(
          height: 46,
          padding: const EdgeInsets.symmetric(horizontal: 8),
          child: Row(
            children: <Widget>[
              Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  color: hasActive ? const Color(0x33FFFFFF) : const Color(0x14FFFFFF),
                  borderRadius: BorderRadius.circular(9),
                ),
                child: Icon(ic(g.icon), size: 17, color: hasActive ? Pal.tealLight : Pal.sideText),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(g.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: ts(13.5, w: FontWeight.w800, c: hasActive ? Colors.white : const Color(0xFFD3E3E5))),
              ),
              Text('$count', style: ts(12, w: FontWeight.w700, c: Pal.faint)),
              const SizedBox(width: 4),
              Icon(ic(open ? 'up' : 'down'), size: 19, color: Pal.faint),
            ],
          ),
        ),
      ),
    );
  }

  Widget _label(String t) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 12, 10, 6),
      child: Text(t, style: ts(11.5, w: FontWeight.w800, c: Pal.faint, ls: 0.6)),
    );
  }

  Widget _expanded(String cur, String active) {
    final List<Widget> list = <Widget>[];
    final bool admin = live.isAdmin;
    for (final GroupDef g in visibleGroups(admin)) {
      final List<FeatureDef> fs = visibleIn(g.id, admin);
      final bool open = _openGroup == g.id;
      list.add(_groupHeader(g, open, cur == g.id, fs.length));
      if (open) {
        list.add(Padding(
          padding: const EdgeInsets.fromLTRB(8, 2, 0, 8),
          child: Container(
            padding: const EdgeInsets.only(left: 8),
            decoration: const BoxDecoration(border: Border(left: BorderSide(color: Color(0x26FFFFFF)))),
            child: Column(children: <Widget>[for (final FeatureDef f in fs) _item(f, f.id == active)]),
          ),
        ));
      }
    }
    return Column(
      children: <Widget>[
        Container(
          height: 68,
          padding: const EdgeInsets.fromLTRB(16, 0, 8, 0),
          child: Row(
            children: <Widget>[
              const BrandMark(size: 38),
              const SizedBox(width: 11),
              Expanded(child: Text('Balaji Pro', style: ts(18, w: FontWeight.w800, c: Colors.white, ls: -0.3))),
              IconBtn('collapse', color: Pal.sideText, size: 40, onTap: app.toggleSidebar, tip: 'Ctrl B'),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 2, 14, 8),
          child: Btn(bi('નવી એન્ટ્રી', 'New entry'), icon: 'plus', kind: BtnKind.amber, expand: true, onTap: () => showNewMenu(context)),
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 18),
            children: list,
          ),
        ),
      ],
    );
  }

  Widget _collapsed(String cur) {
    return Column(
      children: <Widget>[
        const SizedBox(height: 14),
        const BrandMark(size: 40),
        const SizedBox(height: 8),
        IconBtn('expand', color: Pal.sideText, size: 40, onTap: app.toggleSidebar, tip: 'Ctrl B'),
        const SizedBox(height: 6),
        Tooltip(
          message: bi('નવી એન્ટ્રી', 'New entry'),
          child: Material(
            color: Pal.amber,
            borderRadius: BorderRadius.circular(14),
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () => showNewMenu(context),
              child: SizedBox(width: 48, height: 48, child: Icon(ic('plus'), size: 26, color: const Color(0xFF3B2705))),
            ),
          ),
        ),
        const SizedBox(height: 10),
        Container(height: 1, margin: const EdgeInsets.symmetric(horizontal: 16), color: const Color(0x1AFFFFFF)),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.symmetric(vertical: 10),
            children: <Widget>[
              for (final GroupDef g in visibleGroups(live.isAdmin))
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
                  child: Tooltip(
                    message: g.title,
                    child: Material(
                      color: cur == g.id ? const Color(0x2EFFFFFF) : Colors.transparent,
                      borderRadius: BorderRadius.circular(12),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(12),
                        hoverColor: const Color(0x14FFFFFF),
                        onTap: () => app.go('g_${g.id}', root: true),
                        child: SizedBox(
                          height: 48,
                          child: Icon(ic(g.icon), size: 22, color: cur == g.id ? Pal.tealLight : Pal.sideText),
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final String cur = groupOfRoute(app.current, app.arg);
    if (cur != _lastGroup) {
      _lastGroup = cur;
      _openGroup = cur;
    }
    final bool collapsed = app.sidebarCollapsed;
    return Container(
      width: collapsed ? 76 : 268,
      color: Pal.side,
      child: collapsed ? _collapsed(cur) : _expanded(cur, _activeId()),
    );
  }
}

// ------------------------------------------------------------------ top bar
class _TopBar extends StatelessWidget {
  _TopBar();

  String? _crumb() {
    final String id = app.current;
    if (id == 'dashboard' || id == 'hub' || id == 'settings' || id.startsWith('g_')) return null;
    final FeatureDef? f = featureById(id);
    if (f == null || f.group == 'core') return null;
    return groupOf(f.group).title;
  }

  Widget _search(bool wide) {
    if (!wide) {
      return Builder(builder: (BuildContext c) => IconBtn('search', tip: 'Ctrl K', onTap: () => showCommandPalette(c)));
    }
    return Builder(
      builder: (BuildContext c) => Material(
        color: Pal.surface2,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () => showCommandPalette(c),
          child: Container(
            width: 250,
            height: 42,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), border: Border.all(color: Pal.line)),
            child: Row(
              children: <Widget>[
                Icon(ic('search'), size: 19, color: Pal.faint),
                const SizedBox(width: 8),
                Expanded(child: Text(bi('શોધો…', 'Search…'), style: ts(14, c: Pal.faint))),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                  decoration: BoxDecoration(color: Pal.surface, borderRadius: BorderRadius.circular(6), border: Border.all(color: Pal.line)),
                  child: Text('Ctrl K', style: ts(11, w: FontWeight.w700, c: Pal.muted)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final String? crumb = _crumb();
    final String title = screenTitle(app.current, app.arg);
    final int alerts = alertCount();
    return Container(
      height: 64,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(color: Pal.surface, border: Border(bottom: BorderSide(color: Pal.line))),
      child: LayoutBuilder(
        builder: (BuildContext c, BoxConstraints box) {
          final bool wide = box.maxWidth >= 1120;
          final bool mid = box.maxWidth >= 780;
          return Row(
            children: <Widget>[
              if (app.canBack) ...<Widget>[
                IconBtn('back', color: Pal.ink, bg: Pal.surface2, onTap: app.back, tip: 'Esc'),
                const SizedBox(width: 10),
              ],
              Expanded(
                child: Row(
                  children: <Widget>[
                    if (crumb != null) ...<Widget>[
                      InkWell(
                        borderRadius: BorderRadius.circular(6),
                        onTap: () => app.go('g_${groupOfRoute(app.current, app.arg)}', root: true),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 4),
                          child: Text(crumb, style: ts(14, w: FontWeight.w600, c: Pal.muted)),
                        ),
                      ),
                      Icon(ic('chev'), size: 18, color: Pal.faint),
                    ],
                    Flexible(
                      child: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(15, w: FontWeight.w800)),
                    ),
                  ],
                ),
              ),
              _search(wide),
              const SizedBox(width: 10),
              const LiveChip(),
              const SizedBox(width: 10),
              if (mid)
                Btn(bi('નવી એન્ટ્રી', 'New entry'), icon: 'plus', dense: true, onTap: () => showNewMenu(c))
              else
                IconBtn('plus', color: Colors.white, bg: Pal.brand, onTap: () => showNewMenu(c), tip: bi('નવી એન્ટ્રી', 'New entry')),
              const SizedBox(width: 6),
              IconBtn('calc', onTap: () => openCalcSheet(c), tip: bi('કૅલ્ક્યુલેટર  Ctrl H', 'Calculator  Ctrl H')),
              if (live.isAdmin) IconBtn('bell', badge: alerts > 0, onTap: () => app.go('alerts'), tip: bi('ધ્યાનમાં લો', 'Attention')),
              if (app.pinOn) IconBtn('lock', onTap: app.lock, tip: bi('લોક', 'Lock')),
              IconBtn('gear', onTap: () => app.go('settings'), tip: bi('સેટિંગ્સ', 'Settings')),
            ],
          );
        },
      ),
    );
  }
}
