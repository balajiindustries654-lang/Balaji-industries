import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/fmt.dart';
import '../features/live/reauth.dart' show showReauth;
import '../core/i18n.dart';
import '../core/icons.dart';
import '../core/palette.dart';
import '../data/live_store.dart';
import '../data/models.dart';
import '../features/router.dart';
import '../widgets/common.dart';
import '../widgets/keys.dart';

/// Number of things that need the owner's attention.
int alertCount() => live.isAdmin ? live.problemCount : 0;

// -------------------------------------------------------------- brand mark
class BrandMark extends StatelessWidget {
  final double size;
  const BrandMark({super.key, this.size = 36});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(Pal.rad(size * 0.3)),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[Pal.tealLight, Pal.teal],
        ),
      ),
      child: Icon(ic('grain'), size: size * 0.56, color: Colors.white),
    );
  }
}

// ---------------------------------------------------------------- firm pick
class FirmPill extends StatelessWidget {
  final bool onDark;
  FirmPill({super.key, this.onDark = false});

  Widget _dot(Color c) => Container(width: 10, height: 10, decoration: BoxDecoration(color: c, shape: BoxShape.circle));

  Widget _row(Firm? f) {
    final bool sel = app.firm == f;
    return Row(
      children: <Widget>[
        _dot(f == null ? Pal.brand : f.color),
        const SizedBox(width: 10),
        Expanded(child: Text(f == null ? bi('બધી કંપની', 'All companies') : f.title, style: ts(14, w: sel ? FontWeight.w800 : FontWeight.w600))),
        if (sel) Icon(ic('tick'), size: 18, color: Pal.brand),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final Firm? f = app.firm;
    final Color fg = onDark ? Colors.white : Pal.ink;
    return PopupMenuButton<int>(
      tooltip: bi('કંપની', 'Company'),
      onSelected: (int i) => app.setFirm(i < 0 ? null : Firm.values[i]),
      color: Pal.surface,
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(Pal.rad(12)), side: BorderSide(color: Pal.line)),
      itemBuilder: (BuildContext c) => <PopupMenuEntry<int>>[
        PopupMenuItem<int>(value: -1, height: 48, child: _row(null)),
        for (final Firm x in Firm.values) PopupMenuItem<int>(value: x.index, height: 48, child: _row(x)),
      ],
      child: Container(
        height: 38,
        padding: const EdgeInsets.only(left: 11, right: 6),
        decoration: BoxDecoration(
          color: onDark ? const Color(0x1FFFFFFF) : Pal.soft,
          borderRadius: BorderRadius.circular(Pal.rad(99)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            _dot(f == null ? Pal.tealLight : f.color),
            const SizedBox(width: 8),
            Text(f == null ? bi('બધી', 'All') : f.short, style: ts(13, w: FontWeight.w800, c: fg)),
            Icon(ic('down'), size: 18, color: onDark ? Pal.sideText : Pal.muted),
          ],
        ),
      ),
    );
  }
}

class FirmSeg extends StatelessWidget {
  FirmSeg({super.key});

  @override
  Widget build(BuildContext context) {
    return Seg(
      dense: true,
      labels: <String>[bi('બધી', 'All'), for (final Firm f in Firm.values) f.short],
      index: app.firm == null ? 0 : app.firm!.index + 1,
      onChanged: (int i) => app.setFirm(i == 0 ? null : Firm.values[i - 1]),
    );
  }
}

// ----------------------------------------------------------- phone / pc mode
class ModeSwitch extends StatelessWidget {
  final bool compact;
  ModeSwitch({super.key, this.compact = false});

  @override
  Widget build(BuildContext context) {
    final List<ViewMode> modes = <ViewMode>[ViewMode.phone, ViewMode.pc, ViewMode.auto];
    final List<String> labels = <String>[bi('ફોન', 'Phone'), 'PC', bi('ઓટો', 'Auto')];
    final List<String> icons = <String>['phone', 'pc', 'auto'];
    return Container(
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(color: const Color(0x1FFFFFFF), borderRadius: BorderRadius.circular(Pal.rad(13))),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          for (int i = 0; i < modes.length; i++)
            Tooltip(
              message: labels[i],
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => app.setView(modes[i]),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 160),
                  height: 34,
                  padding: EdgeInsets.symmetric(horizontal: compact ? 12 : 14),
                  decoration: BoxDecoration(
                    color: app.viewMode == modes[i] ? Colors.white : Colors.transparent,
                    borderRadius: BorderRadius.circular(Pal.rad(10)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Icon(ic(icons[i]), size: 19, color: app.viewMode == modes[i] ? Pal.tealDark : Pal.sideText),
                      if (!compact) ...<Widget>[
                        const SizedBox(width: 7),
                        Text(labels[i], style: ts(13.5, w: FontWeight.w800, c: app.viewMode == modes[i] ? Pal.tealDark : Pal.sideText)),
                      ],
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// ------------------------------------------------------------- live status
/// Online / offline / waiting-to-upload indicator. Tap to refresh.
class LiveChip extends StatelessWidget {
  final bool compact;
  const LiveChip({super.key, this.compact = false});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: live,
      builder: (BuildContext c, Widget? w) {
        String tone = 'green';
        String text = bi('ઓનલાઇન', 'Online');
        if (live.offline) {
          tone = 'amber';
          text = bi('ઑફલાઇન', 'Offline');
        } else if (live.error.isNotEmpty) {
          tone = 'rose';
          text = bi('ભૂલ', 'Error');
        }
        if (live.pending.isNotEmpty) {
          tone = 'blue';
          text = bi('${live.pending.length} બાકી', '${live.pending.length} waiting');
        }
        if (live.needsReauth) {
          tone = 'amber';
          text = bi('પાસવર્ડ નાખો', 'Enter password');
        }
        final Tone t = Pal.tone(tone);
        final String ago2 = live.loadedAt == null ? '' : ago(live.loadedAt!);
        return Material(
          color: t.bg,
          borderRadius: BorderRadius.circular(Pal.rad(99)),
          child: InkWell(
            borderRadius: BorderRadius.circular(Pal.rad(99)),
            onTap: () => live.needsReauth ? showReauth(c) : (live.pending.isNotEmpty ? app.go('offline_queue') : live.refresh()),
            child: Container(
              height: 38,
              padding: EdgeInsets.symmetric(horizontal: compact ? 10 : 12),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  live.loading
                      ? SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: t.fg))
                      : Container(width: 9, height: 9, decoration: BoxDecoration(color: t.fg, shape: BoxShape.circle)),
                  const SizedBox(width: 8),
                  Text(text, style: ts(13, w: FontWeight.w800, c: t.fg)),
                  if (!compact && ago2.isNotEmpty) ...<Widget>[
                    const SizedBox(width: 6),
                    Text(ago2, style: ts(12, w: FontWeight.w600, c: t.fg)),
                  ],
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

// ------------------------------------------------------------- tally status
class TallyChip extends StatelessWidget {
  TallyChip({super.key});

  @override
  Widget build(BuildContext context) {
    final bool on = app.tallyOnline;
    final Tone t = Pal.tone(on ? 'green' : 'slate');
    return Material(
      color: t.bg,
      borderRadius: BorderRadius.circular(Pal.rad(99)),
      child: InkWell(
        borderRadius: BorderRadius.circular(Pal.rad(99)),
        onTap: () => app.go('tally_sync'),
        child: Container(
          height: 38,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              app.syncing
                  ? SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: t.fg, value: app.syncProgress))
                  : Container(width: 9, height: 9, decoration: BoxDecoration(color: t.fg, shape: BoxShape.circle)),
              const SizedBox(width: 8),
              Text('Tally', style: ts(13, w: FontWeight.w800, c: t.fg)),
              const SizedBox(width: 6),
              Text(ago(app.lastSync), style: ts(12, w: FontWeight.w600, c: t.fg)),
            ],
          ),
        ),
      ),
    );
  }
}

// ------------------------------------------------------------ screen host
/// Builds the current route's screen with a short fade-in on navigation.
class ScreenHost extends StatelessWidget {
  ScreenHost({super.key});

  @override
  Widget build(BuildContext context) {
    final String id = app.current;
    final Object? arg = app.arg;
    final String key = '$id|${arg == null ? '' : arg.hashCode}';
    return TweenAnimationBuilder<double>(
      key: ValueKey<String>(key),
      tween: Tween<double>(begin: 0, end: 1),
      duration: const Duration(milliseconds: 220),
      curve: Curves.easeOut,
      builder: (BuildContext c, double v, Widget? child) {
        return Opacity(
          opacity: v,
          child: Transform.translate(offset: Offset(0, (1 - v) * 10), child: child),
        );
      },
      child: KeyScope(focusFirst: false, screen: true, child: buildScreen(context, id, arg)),
    );
  }
}
