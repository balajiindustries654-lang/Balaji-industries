import 'dart:io' show exit;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/app_state.dart';
import '../core/errlog.dart';
import '../core/flags.dart';
import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/keep_awake.dart';
import '../core/palette.dart';
import '../core/version.dart';
import '../data/backup.dart';
import '../data/live_models.dart';
import '../data/live_store.dart';
import '../data/owner_docs.dart' show SyncDoc, prefDoc;
import '../data/trade.dart' show AgedBuyer, SaleItem, StockLine, agedBuyers, procDoc, saleDoc, saleItems, stockRows;
import '../features/live/field.dart' show confirmBox;
import '../features/live/reauth.dart' show showReauth;
import '../features/live/hisab.dart' show openCalcSheet;
import '../features/live/kanta_remote_screen.dart' show KantaRemoteCard;
import '../features/live/money_screens.dart' show DocsScope, openPayForm;
import '../features/live/trade_screens.dart' show openSaleForm;
import '../features/live/voucher_screens.dart' show DayBookArg, openExpForm;
import '../features/live/contra_screens.dart' show openContraForm;
import '../features/live/note_screens.dart' show openNoteForm;
import '../features/live/gst_screens.dart' show openGstForm;
import '../features/live/tally_data.dart' show TallyGlance, TallyStore, tallyGlance, tallyStore;
import '../features/live/trading_screens.dart' show openDealForm;
import '../features/live/bank_screens.dart' show openBankImport;
import '../features/live/trade_screens2.dart' show openProcessForm, openStockForm;
import '../features/registry.dart';
import '../features/router.dart';
import '../widgets/accept.dart';
import '../widgets/common.dart';
import '../widgets/keys.dart';
import 'cmdk.dart';
import 'widgets.dart';

// ======================================================================
// Tally Prime style PC shell
//   title bar  ·  menu bar (K Y Z G O E M P  F1)  ·  Gateway home
//   right-hand F-key button bar  ·  status line
// ======================================================================

/// Key of the shell. Its context sits inside the app navigator, so panels
/// opened from the keyboard land on the same navigator as the screens.
final GlobalKey tallyKey = GlobalKey();

class _TC {
  static Color get title => Pal.dark ? const Color(0xFF06141A) : const Color(0xFF0A3D62);
  static Color get menu => Pal.dark ? const Color(0xFF12262D) : const Color(0xFFD3E0E8);
  static Color get bar => Pal.dark ? const Color(0xFF0E2026) : const Color(0xFFC4D4DE);
  static Color get head => Pal.dark ? const Color(0xFF8CC4E8) : const Color(0xFF0B4F7A);
  static Color get text => Pal.dark ? const Color(0xFFD7E6EA) : const Color(0xFF0F2530);
  static const Color gold = Color(0xFFFFD84D);
  static const Color goldInk = Color(0xFF1B1400);
  static const Color goldSoft = Color(0x55FFD84D);
}

String _role(String r) {
  switch (r) {
    case 'admin':
      return bi('માલિક', 'Owner');
    case 'worker':
      return bi('ચિઠ્ઠી', 'Chit');
    case 'waybridge':
      return bi('કાંટો', 'Weighbridge');
    case 'maal_entry':
      return bi('માલ એન્ટ્રી', 'Maal entry');
    default:
      return r;
  }
}

String _fy() {
  final DateTime n = DateTime.now();
  final int y = n.month >= 4 ? n.year : n.year - 1;
  return '1 ${monthName(4)} $y - 31 ${monthName(3)} ${y + 1}';
}

Widget _kv(String k, String v, {VoidCallback? onTap, Color? color}) {
  return InkWell(
    onTap: onTap,
    child: Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: <Widget>[
          Expanded(child: Text(k, style: ts(13, c: _TC.text))),
          const SizedBox(width: 8),
          Text(v, style: ts(13.5, w: FontWeight.w800, c: color, tab: true)),
        ],
      ),
    ),
  );
}

// ---------------------------------------------------------------- actions
final Map<String, GlobalKey<PopupMenuButtonState<int>>> _menuKeys = <String, GlobalKey<PopupMenuButtonState<int>>>{
  'K': GlobalKey<PopupMenuButtonState<int>>(),
  'Y': GlobalKey<PopupMenuButtonState<int>>(),
  'Z': GlobalKey<PopupMenuButtonState<int>>(),
  'O': GlobalKey<PopupMenuButtonState<int>>(),
  'E': GlobalKey<PopupMenuButtonState<int>>(),
  'M': GlobalKey<PopupMenuButtonState<int>>(),
  'P': GlobalKey<PopupMenuButtonState<int>>(),
  'F1': GlobalKey<PopupMenuButtonState<int>>(),
};

final List<LogicalKeyboardKey> _fKeys = <LogicalKeyboardKey>[
  LogicalKeyboardKey.f1,
  LogicalKeyboardKey.f2,
  LogicalKeyboardKey.f3,
  LogicalKeyboardKey.f4,
  LogicalKeyboardKey.f5,
  LogicalKeyboardKey.f6,
  LogicalKeyboardKey.f7,
  LogicalKeyboardKey.f8,
  LogicalKeyboardKey.f9,
  LogicalKeyboardKey.f10,
  LogicalKeyboardKey.f11,
  LogicalKeyboardKey.f12,
];

class _Act {
  final String key;
  final String gu;
  final String en;
  final bool admin;
  final String sid; // the id simple mode looks at ('' = always shown)
  final void Function(BuildContext) run;
  const _Act(this.key, this.gu, this.en, this.run, {this.admin = false, this.sid = ''});
  String get title => bi(gu, en);
}

List<_Act> _fActs() {
  // the same keys as TallyPrime: F4 Contra, F5 Payment, F6 Receipt, F7 Journal, F8 Sales, F9 Purchase, F10 Other Vouchers
  return <_Act>[
    _Act('F1', 'મદદ', 'Help', (BuildContext c) => _menuKeys['F1']?.currentState?.showButtonMenu()),
    _Act('F2', 'પીરિયડ', 'Period', (BuildContext c) {
      // the period box of the report that is open (Day Book, Ledger, Trial Balance ...); else the day report
      if (!periodHub.run()) app.go('today');
    }, admin: true),
    _Act('F3', 'શોધો / જાઓ', 'Search / Go To', (BuildContext c) => showCommandPalette(c)),
    _Act('F4', 'કોન્ટ્રા', 'Contra', (BuildContext c) => openContraForm(c), admin: true, sid: 'v_contra'),
    _Act('F5', 'ચૂકવણી', 'Payment', (BuildContext c) => openPayForm(c), admin: true, sid: 'v_payment'),
    _Act('F6', 'રસીદ', 'Receipt', (BuildContext c) => openSaleForm(c, kind: 'recv'), admin: true, sid: 'v_receipt'),
    _Act('F7', 'જર્નલ', 'Journal', (BuildContext c) => _journalMenu(c), admin: true, sid: 'v_journal'),
    _Act('F8', 'વેચાણ', 'Sales', (BuildContext c) => openSaleForm(c), admin: true, sid: 'v_sales'),
    _Act('F9', 'ખરીદી (ચિઠ્ઠી)', 'Purchase', (BuildContext c) => app.go('chithi_new')),
    _Act('F10', 'બીજા વાઉચર', 'Other Vouchers', (BuildContext c) => _otherVouchersMenu(c)),
    _Act('F11', 'ધ્યાનમાં લો', 'Attention', (BuildContext c) => app.go('alerts'), admin: true),
    _Act('F12', 'ગોઠવણ', 'Configure', (BuildContext c) => _openConfigure(c)),
  ];
}

/// One line of a pick menu (F7 Journal, F10 Other Vouchers): a hot letter, the name and what it does.
class _PickItem {
  final String key;
  final String gu;
  final String en;
  final VoidCallback run;
  final bool admin;
  final String sid; // the id simple mode looks at ('' = always shown)
  const _PickItem(this.key, this.gu, this.en, this.run, {this.admin = false, this.sid = ''});
  String get title => bi(gu, en);
}

/// A small Tally style menu in the middle of the screen: Up / Down + Enter, or the hot letter; Esc closes.
Future<void> _pickMenu(BuildContext context, String title, List<_PickItem> all) async {
  final List<_PickItem> items = <_PickItem>[
    for (final _PickItem i in all)
      if ((!i.admin || live.isAdmin) && screenOn(i.sid)) i,
  ];
  if (items.isEmpty) return;
  final _PickItem? chosen = await showDialog<_PickItem>(
    context: context,
    useRootNavigator: false, // on the app navigator, so the global keys (Esc ...) leave it alone
    barrierColor: const Color(0x66000000),
    builder: (BuildContext c) => _PickDialog(title: title, items: items),
  );
  if (chosen != null) ErrLog.guard(chosen.title, chosen.run);
}

Future<void> _journalMenu(BuildContext c) {
  return _pickMenu(c, bi('જર્નલ વાઉચર', 'Journal Voucher'), <_PickItem>[
    _PickItem('F', 'ખેડૂત જૂનું બાકી', 'Farmer opening balance', () => openPayForm(c, kind: 'open'), admin: true),
    _PickItem('B', 'ખરીદનાર જૂનું બાકી', 'Buyer opening balance', () => openSaleForm(c, kind: 'open'), admin: true),
  ]);
}

Future<void> _otherVouchersMenu(BuildContext c) {
  return _pickMenu(c, bi('બીજા વાઉચર', 'Other Vouchers'), <_PickItem>[
    _PickItem('E', 'ખર્ચ / આવક વાઉચર', 'Expense / Income Voucher', () => openExpForm(c), admin: true, sid: 'v_expense'),
    _PickItem('K', 'કાંટા એન્ટ્રી (વજન)', 'Weighbridge Entry (Kanta)', () => app.go('kanta_new'), sid: 'kanta_new'),
    _PickItem('M', 'માલ એન્ટ્રી', 'Maal Entry', () => app.go('maal_new'), sid: 'maal_new'),
    // simple mode has no Journal key: the two opening balances (once, when the books start) are here
    if (kSimple) _PickItem('F', 'ખેડૂત જૂનું બાકી', 'Farmer opening balance', () => openPayForm(c, kind: 'open'), admin: true, sid: 'v_open_farmer'),
    if (kSimple) _PickItem('B', 'ખરીદનાર જૂનું બાકી', 'Buyer opening balance', () => openSaleForm(c, kind: 'open'), admin: true, sid: 'v_open_buyer'),
    _PickItem('O', 'ખુલતો સ્ટોક', 'Opening Stock', () => openStockForm(c), admin: true, sid: 'v_stock_open'),
    _PickItem('P', 'પ્રોસેસ વાઉચર', 'Processing Voucher', () => openProcessForm(c), admin: true, sid: 'v_process'),
    _PickItem('C', 'ક્રેડિટ નોટ (વેચાણ પરત)', 'Credit Note (sales return)', () => openNoteForm(c, credit: true), admin: true, sid: 'v_credit'),
    _PickItem('D', 'ડેબિટ નોટ (ખરીદ પરત)', 'Debit Note (purchase return)', () => openNoteForm(c, credit: false), admin: true, sid: 'v_debit'),
    if (kGstOn) _PickItem('G', 'GST બિલ', 'GST Invoice', () => openGstForm(c), admin: true, sid: 'gst_bill'),
    _PickItem('T', 'ટ્રેડિંગ સોદો', 'Trading Deal', () => openDealForm(c), admin: true, sid: 'trading'),
  ]);
}

class _PickDialog extends StatefulWidget {
  final String title;
  final List<_PickItem> items;
  const _PickDialog({required this.title, required this.items});

  @override
  State<_PickDialog> createState() => _PickDialogState();
}

class _PickDialogState extends State<_PickDialog> {
  int _sel = 0;

  void _pick(int i) {
    if (i >= 0 && i < widget.items.length) Navigator.of(context).pop(widget.items[i]);
  }

  KeyEventResult _onKey(FocusNode n, KeyEvent e) {
    if (e is KeyUpEvent) return KeyEventResult.ignored;
    final LogicalKeyboardKey k = e.logicalKey;
    if (k == LogicalKeyboardKey.escape) {
      Navigator.of(context).pop();
      return KeyEventResult.handled;
    }
    if (k == LogicalKeyboardKey.arrowDown) {
      setState(() => _sel = (_sel + 1) % widget.items.length);
      return KeyEventResult.handled;
    }
    if (k == LogicalKeyboardKey.arrowUp) {
      setState(() => _sel = (_sel - 1 + widget.items.length) % widget.items.length);
      return KeyEventResult.handled;
    }
    if (k == LogicalKeyboardKey.enter || k == LogicalKeyboardKey.numpadEnter) {
      _pick(_sel);
      return KeyEventResult.handled;
    }
    final String? ch = e.character;
    if (ch != null && ch.isNotEmpty) {
      final String c = ch.toUpperCase();
      for (int i = 0; i < widget.items.length; i++) {
        if (widget.items[i].key == c) {
          _pick(i);
          return KeyEventResult.handled;
        }
      }
    }
    return KeyEventResult.handled;
  }

  @override
  Widget build(BuildContext context) {
    return Focus(
      autofocus: true,
      onKeyEvent: _onKey,
      child: Dialog(
        backgroundColor: Pal.surface,
        shape: const RoundedRectangleBorder(),
        insetPadding: const EdgeInsets.all(24),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 380),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Container(
                color: _TC.head,
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                child: Text(widget.title, style: ts(14.5, w: FontWeight.w800, c: Colors.white)),
              ),
              for (int i = 0; i < widget.items.length; i++)
                InkWell(
                  onTap: () => _pick(i),
                  onHover: (bool h) {
                    if (h && _sel != i) setState(() => _sel = i);
                  },
                  child: Container(
                    color: i == _sel ? Pal.focusFill : null,
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                    child: Row(
                      children: <Widget>[
                        Container(
                          width: 22,
                          alignment: Alignment.center,
                          padding: const EdgeInsets.symmetric(vertical: 1),
                          decoration: BoxDecoration(border: Border.all(color: Pal.line)),
                          child: Text(widget.items[i].key, style: ts(12, w: FontWeight.w800, c: _TC.head)),
                        ),
                        const SizedBox(width: 12),
                        Expanded(child: Text(widget.items[i].title, style: ts(14, w: i == _sel ? FontWeight.w800 : FontWeight.w600))),
                      ],
                    ),
                  ),
                ),
              Container(
                color: Pal.surface2,
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                child: Text(bi('↑ ↓ Enter પસંદ કરો · અક્ષર દબાવો · Esc બંધ', '↑ ↓ Enter to select · press the letter · Esc to close'), style: ts(11.5, c: Pal.muted)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Screens where Alt + C (and the Create button) makes a new entry.
const Set<String> _createIds = <String>{
  'chithi',
  'chithi_new',
  'kanta',
  'kanta_new',
  'maal',
  'maal_new',
  'maal_stock',
  'maal_cross',
  'khedut_khata',
  'payments',
  'weight_bill',
  'sales',
  'buyer_khata',
  'collection',
  'process_grade',
  'stock_live',
  'gst_bill',
  'trading',
  'bank_match',
  'expenses',
  'cashbook',
  'day_account',
};

/// Alt + C: make a new entry for the screen that is open (like Create / Add Vch in TallyPrime).
void _createHere(BuildContext c) {
  switch (app.current) {
    case 'chithi':
    case 'chithi_new':
      app.go('chithi_new');
      return;
    case 'kanta':
    case 'kanta_new':
      app.go('kanta_new');
      return;
    case 'maal':
    case 'maal_new':
    case 'maal_stock':
    case 'maal_cross':
      app.go('maal_new');
      return;
    case 'khedut_khata':
    case 'payments':
    case 'weight_bill':
      openPayForm(c);
      return;
    case 'sales':
    case 'buyer_khata':
    case 'collection':
      openSaleForm(c);
      return;
    case 'process_grade':
      openProcessForm(c);
      return;
    case 'stock_live':
      openStockForm(c);
      return;
    case 'gst_bill':
      openGstForm(c);
      return;
    case 'trading':
      openDealForm(c);
      return;
    case 'bank_match':
      openBankImport(c);
      return;
    case 'expenses':
    case 'cashbook':
    case 'day_account':
      if (!focusSearchField()) app.go('expenses');
      return;
  }
  app.toast(bi('આ સ્ક્રીન પર નવું બનાવવાનું નથી - F4 થી F10 કી વાપરો', 'Nothing to create on this screen - use the F4 to F10 keys'));
}

/// Shows the list of Tally-mode keys (Shift + ? on the keyboard).
void tallyShowKeys() {
  final BuildContext? ctx = tallyKey.currentContext;
  if (ctx != null) _openKeys(ctx);
}

/// Keyboard layer of the Tally skin. Returns true when the key was used.
bool tallyOnKey(LogicalKeyboardKey k, {required bool editing}) {
  final BuildContext? ctx = tallyKey.currentContext;
  if (ctx == null) return false;
  // Ctrl+F8 Credit Note, Ctrl+F9 Debit Note (as in TallyPrime)
  if ((k == LogicalKeyboardKey.f8 || k == LogicalKeyboardKey.f9) && (HardwareKeyboard.instance.isControlPressed || HardwareKeyboard.instance.isMetaPressed)) {
    if (live.isAdmin && screenOn('v_credit')) ErrLog.guard('Ctrl+F8/F9', () => openNoteForm(ctx, credit: k == LogicalKeyboardKey.f8));
    return true;
  }
  final int i = _fKeys.indexOf(k);
  if (i >= 0) {
    final _Act a = _fActs()[i];
    if ((!a.admin || live.isAdmin) && screenOn(a.sid)) ErrLog.guard(a.key, () => a.run(ctx));
    return true;
  }
  final HardwareKeyboard hk = HardwareKeyboard.instance;
  final bool alt = hk.isAltPressed;
  final bool ctl = hk.isControlPressed || hk.isMetaPressed;
  if (!alt && !ctl) return false;
  if (editing && !alt) return false;
  if (alt && !ctl && k == LogicalKeyboardKey.keyC) {
    ErrLog.guard('Alt+C', () => _createHere(ctx));
    return true;
  }
  String? m;
  if (k == LogicalKeyboardKey.keyK) {
    m = 'K';
  } else if (k == LogicalKeyboardKey.keyY) {
    m = 'Y';
  } else if (k == LogicalKeyboardKey.keyZ) {
    m = 'Z';
  } else if (k == LogicalKeyboardKey.keyG) {
    m = 'G';
  } else if (k == LogicalKeyboardKey.keyO) {
    m = 'O';
  } else if (k == LogicalKeyboardKey.keyE) {
    m = 'E';
  } else if (k == LogicalKeyboardKey.keyM) {
    m = 'M';
  } else if (k == LogicalKeyboardKey.keyP) {
    m = 'P';
  } else if (k == LogicalKeyboardKey.keyN) {
    openCalcSheet(ctx);
    return true;
  }
  if (m == null) return false;
  if (m == 'G') {
    showCommandPalette(ctx);
    return true;
  }
  _menuKeys[m]?.currentState?.showButtonMenu();
  return true;
}

// ---------------------------------------------------------------- menus
class _MI {
  final String gu;
  final String en;
  final String hint;
  final bool admin;
  final void Function() run;
  final String? id; // a menu line that opens a screen is named like that screen
  const _MI(this.gu, this.en, this.run, {this.hint = '', this.admin = false, this.id});
  String get title => id == null ? bi(gu, en) : screenTitle(id!, null);
}

_MI _go(String id, {bool admin = false, String hint = ''}) {
  return _MI('', '', () => app.go(id), admin: admin, hint: hint, id: id);
}

List<_MI> _menuItems(String hot, BuildContext c) {
  switch (hot) {
    case 'K':
      return <_MI>[
        _go('settings'),
        _MI('ગોઠવણ', 'Configure', () => _openConfigure(c), hint: 'F12'),
        _MI('લોક કરો', 'Lock', () => app.lock()),
        _MI('ફોન મોડ', 'Phone mode', () => app.setView(ViewMode.phone)),
        _MI('લૉગ આઉટ', 'Sign out', () async {
          final bool ok = await confirmBox(c, title: bi('લૉગ આઉટ?', 'Sign out?'), text: bi('આ ફોન પરથી બહાર નીકળશો?', 'Sign out from this device?'), yes: bi('હા', 'Yes'), no: bi('ના', 'No'));
          if (ok) await live.logout();
        }),
      ];
    case 'Y':
      return <_MI>[
        _MI('ડેટા રિફ્રેશ', 'Refresh data', () => live.refresh()),
        _go('history', admin: true),
        _go('offline_queue'),
        _go('bad_entries', admin: true),
        _go('day_close', admin: true),
        _go('backup', admin: true),
        _go('diagnostics'),
      ];
    case 'Z':
      return <_MI>[
        _go('today', admin: true),
        _go('collection', admin: true),
        _go('tally_live', admin: true),
        _go('tally_pay', admin: true),
        _go('tally_age', admin: true),
      ];
    case 'O':
      return <_MI>[
        _go('bank_match', admin: true),
        _go('kanta_auto'),
        _go('kanta_usb'),
        _go('kanta_remote', admin: true),
        _go('kanta_khata', admin: true),
        _go('scan'),
        _go('offline_queue'),
      ];
    case 'E':
      return <_MI>[
        _go('my_daybook', admin: true),
        _go('my_trial', admin: true),
        _go('balance_sheet', admin: true),
        _go('profit_loss', admin: true),
        _go('group_summary', admin: true),
        _go('bank_book', admin: true),
        _go('outstandings', admin: true),
        _go('ratio_analysis', admin: true),
        _go('gstr1', admin: true),
        _go('export_money', admin: true),
        _go('export', admin: true),
        _go('table', admin: true),
      ];
    case 'M':
      return <_MI>[
        _go('today', admin: true),
        _go('day_account', admin: true),
        _go('collection', admin: true),
      ];
    case 'P':
      return <_MI>[
        _go('my_daybook', admin: true),
        _go('my_ledger', admin: true),
        _go('my_trial', admin: true),
        _go('balance_sheet', admin: true),
        _go('profit_loss', admin: true),
        _go('group_summary', admin: true),
        _go('bank_book', admin: true),
        _go('outstandings', admin: true),
        _go('ratio_analysis', admin: true),
        _go('gstr1', admin: true),
        _go('weight_bill', admin: true),
        _go('today', admin: true),
        _go('stock_live', admin: true),
      ];
    case 'F1':
      return <_MI>[
        _go('help'),
        _MI('કીબોર્ડ કી', 'Keyboard keys', () => _openKeys(c)),
        _MI('કેલ્ક્યુલેટર', 'Calculator', () => openCalcSheet(c), hint: 'Ctrl+N'),
      ];
  }
  return <_MI>[];
}

class _MD {
  final String hot;
  final String gu;
  final String en;
  const _MD(this.hot, this.gu, this.en);
  String get label => bi(gu, en);
}

const List<_MD> _menuDefs = <_MD>[
  _MD('K', 'કંપની', 'Company'),
  _MD('Y', 'ડેટા', 'Data'),
  _MD('Z', 'એક્સચેન્જ', 'Exchange'),
  _MD('G', 'જાઓ', 'Go To'),
  _MD('O', 'ઇમ્પોર્ટ', 'Import'),
  _MD('E', 'એક્સપોર્ટ', 'Export'),
  _MD('M', 'શેર', 'Share'),
  _MD('P', 'પ્રિન્ટ', 'Print'),
];

// ---------------------------------------------------------------- panels
Future<void> _openConfigure(BuildContext context) {
  return openPanel(
    context,
    title: bi('ગોઠવણ (F12)', 'Configure (F12)'),
    width: 440,
    child: AnimatedBuilder(
      animation: app,
      builder: (BuildContext c, Widget? w) {
        int sizeIdx = 1;
        if (app.textScale < 0.95) {
          sizeIdx = 0;
        } else if (app.textScale > 1.22) {
          sizeIdx = 3;
        } else if (app.textScale > 1.07) {
          sizeIdx = 2;
        }
        const List<double> zoomSteps = <double>[0.75, 0.85, 1.0, 1.15];
        int zoomIdx = 1;
        double zoomBest = 9;
        for (int i = 0; i < zoomSteps.length; i++) {
          final double dz = (app.pcZoom - zoomSteps[i]).abs();
          if (dz < zoomBest) {
            zoomBest = dz;
            zoomIdx = i;
          }
        }
        Widget row(String label, Widget ctl) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(label, style: ts(13, w: FontWeight.w800, c: _TC.head)),
                const SizedBox(height: 6),
                ctl,
              ],
            ),
          );
        }

        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            if (live.isAdmin)
              row(
                bi('સરળ મોડ (ફક્ત રોજનો કાચા માલનો હિસાબ)', 'Simple mode (only the daily raw-material account)'),
                Seg(labels: <String>[bi('ચાલુ', 'On'), bi('બંધ - બધું બતાવો', 'Off - show everything')], index: app.simple ? 0 : 1, onChanged: (int i) => app.setSimple(i == 0)),
              ),
            row(
              bi('એપ ચાલુ હોય ત્યારે PC / સ્ક્રીન બંધ ન થાય', 'Keep the PC / screen awake while the app is open'),
              AnimatedBuilder(
                animation: KeepAwake.tick,
                builder: (BuildContext c2, Widget? w2) => Seg(labels: <String>[bi('ચાલુ', 'On'), bi('બંધ', 'Off')], index: KeepAwake.on ? 0 : 1, onChanged: (int i) => KeepAwake.setOn(i == 0)),
              ),
            ),
            row(
              bi('દેખાવ (PC)', 'Look (PC)'),
              Seg(labels: const <String>['Tally Prime', 'Modern'], index: app.tallyMode ? 0 : 1, onChanged: (int i) => app.setTally(i == 0)),
            ),
            row(
              bi('ભાષા', 'Language'),
              Seg(
                labels: const <String>['ગુજરાતી', 'English'],
                index: L.gu ? 0 : 1,
                onChanged: (int i) {
                  if ((i == 0) != L.gu) app.toggleLang();
                },
              ),
            ),
            row(
              bi('થીમ', 'Theme'),
              Seg(labels: <String>[bi('હળવી', 'Light'), bi('ડાર્ક', 'Dark')], index: app.dark ? 1 : 0, onChanged: (int i) => app.setDark(i == 1)),
            ),
            row(
              '${bi('સ્ક્રીન ઝૂમ (PC)', 'Screen zoom (PC)')} · ${(app.pcZoom * 100).round()}% · Ctrl + / − / 0',
              Seg(
                labels: const <String>['75%', '85%', '100%', '115%'],
                index: zoomIdx,
                onChanged: (int i) => app.setPcZoom(<double>[0.75, 0.85, 1.0, 1.15][i]),
              ),
            ),
            row(
              bi('અક્ષર સાઇઝ', 'Text size'),
              Seg(
                labels: const <String>['90%', '100%', '115%', '130%'],
                index: sizeIdx,
                onChanged: (int i) => app.setTextScale(<double>[0.9, 1.0, 1.15, 1.3][i]),
              ),
            ),
          ],
        );
      },
    ),
  );
}

Future<void> _openKeys(BuildContext context) {
  final List<List<String>> rows = <List<String>>[
    <String>['F4', bi('કોન્ટ્રા વાઉચર (રોકડ ↔ બેંક)', 'Contra Voucher (Cash / Bank)')],
    <String>['F5', bi('ચૂકવણી વાઉચર', 'Payment Voucher')],
    <String>['F6', bi('રસીદ વાઉચર', 'Receipt Voucher')],
    <String>['F7', bi('જર્નલ વાઉચર (જૂનું બાકી)', 'Journal Voucher (opening balance)')],
    <String>['F8', bi('વેચાણ વાઉચર', 'Sales Voucher')],
    <String>['F9', bi('ખરીદી વાઉચર (ચિઠ્ઠી)', 'Purchase Voucher (Chit)')],
    <String>['Ctrl+F8', bi('ક્રેડિટ નોટ (વેચાણ પરત)', 'Credit Note (sales return)')],
    <String>['Ctrl+F9', bi('ડેબિટ નોટ (ખરીદ પરત)', 'Debit Note (purchase return)')],
    <String>['F10', kGstOn ? bi('બીજા વાઉચર: ખર્ચ, પ્રોસેસ, કાંટો, માલ, GST બિલ, સોદો, ક્રેડિટ / ડેબિટ નોટ', 'Other Vouchers: expense, processing, kanta, maal, GST bill, deal, credit / debit note') : bi('બીજા વાઉચર: ખર્ચ, પ્રોસેસ, કાંટો, માલ, સોદો, ક્રેડિટ / ડેબિટ નોટ', 'Other Vouchers: expense, processing, kanta, maal, deal, credit / debit note')],
    <String>['F2', bi('પીરિયડ બદલો (રિપોર્ટમાં) · નહીં તો આજનો રિપોર્ટ', 'Change period (in a report) · else Day report')],
    <String>['Ctrl+P', bi('ખુલ્લું વાઉચર / રિપોર્ટ પ્રિન્ટ', 'Print the open voucher / report')],
    <String>['Alt+E', bi('રિપોર્ટ Excel માં (CSV)', 'Export the report to Excel (CSV)')],
    <String>['Alt+D', bi('ખુલ્લું વાઉચર કાઢો (Delete)', 'Delete the open voucher')],
    <String>['Enter (વાઉચર પર)', bi('સુધારો (Alter) · પછી Ctrl+A સેવ', 'Alter the voucher · then Ctrl+A to save')],
    <String>['C / P / L / D', bi('ખુલ્લા વાઉચરમાં: નકલ / પ્રિન્ટ / ખાતું / કાઢો', 'In an open voucher: Duplicate / Print / Ledger / Delete')],
    <String>['F3 / Ctrl+G', bi('શોધો / જાઓ', 'Search / Go To')],
    <String>['F11', bi('ધ્યાનમાં લો', 'Attention')],
    <String>['F12', bi('ગોઠવણ', 'Configure')],
    <String>['Ctrl+K', bi('કંપની મેનુ', 'Company menu')],
    <String>['Ctrl+Y', bi('ડેટા મેનુ', 'Data menu')],
    <String>['Ctrl+Z', bi('એક્સચેન્જ મેનુ', 'Exchange menu')],
    <String>['Ctrl+O', bi('ઇમ્પોર્ટ મેનુ', 'Import menu')],
    <String>['Ctrl+E', bi('એક્સપોર્ટ મેનુ', 'Export menu')],
    <String>['Ctrl+M', bi('શેર મેનુ', 'Share menu')],
    <String>['Ctrl+P', bi('પ્રિન્ટ મેનુ', 'Print menu')],
    <String>['Ctrl+N', bi('કેલ્ક્યુલેટર', 'Calculator')],
    <String>['Ctrl + / − / 0', bi('સ્ક્રીન ઝૂમ (મોટું / નાનું / ઓટો)', 'Screen zoom (bigger / smaller / auto)')],
    <String>['← → Backspace', bi('ગેટવેમાં મેનુ ખોલો / પાછા', 'Open / leave a menu in the Gateway')],
    <String>['Q  /  Esc', bi('ગેટવેમાં બહાર નીકળો (Quit)', 'Quit (on the Gateway)')],
    <String>['↑ ↓  Enter', bi('ગેટવેમાં પસંદ કરો / ખોલો', 'Move / open in the Gateway')],
    <String>['Ctrl+A  /  Ctrl+Enter', bi('ખુલ્લું વાઉચર ફોર્મ સેવ (Accept)', 'Accept (save) the open voucher form')],
    <String>['Enter', bi('વાઉચરમાં આગલું ખાનું', 'Next field in a voucher')],
    <String>['↑ ↓', bi('વાઉચરમાં ખાનું બદલો · લિસ્ટમાં પસંદ કરો', 'Change field in a voucher · move in a list')],
    <String>['← →', bi('ચોઇસ બદલો (માલ, રીત, રકમ-મળી/ચૂકવણી)', 'Change a choice (material, mode, kind)')],
    <String>['અક્ષર / letter', bi('ચોઇસમાં તે અક્ષરથી શરૂ થતી ચોઇસ', 'Jump to the choice that starts with that letter')],
    <String>['+  -  T', bi('તારીખ ખાનામાં ±1 દિવસ, T = આજ, Space = કૅલેન્ડર', 'Date box: ±1 day, T = today, Space = calendar')],
    <String>['Alt+C', bi('આ સ્ક્રીન માટે નવું બનાવો (Create)', 'Create new on this screen')],
    <String>['Ctrl+F  /  /', bi('આ સ્ક્રીનનું સર્ચ બોક્સ', 'Search box of this screen')],
    <String>['Y  /  N', bi('હા / ના પ્રશ્નમાં', 'Yes / No in a question')],
    <String>['Esc', bi('પાછા / ફોર્મ બંધ', 'Back / close the form')],
  ];
  return openPanel(
    context,
    title: bi('કીબોર્ડ કી', 'Keyboard keys'),
    sub: bi('Alt + અક્ષર પણ ચાલે', 'Alt + letter works too'),
    width: 440,
    child: Column(
      children: <Widget>[for (final List<String> r in rows) _kv(r[0], r[1])],
    ),
  );
}

// ======================================================================
// Shell
// ======================================================================

class TallyShell extends StatelessWidget {
  TallyShell({super.key});

  @override
  Widget build(BuildContext context) {
    final bool gate = app.current == 'dashboard';
    return Scaffold(
      key: tallyKey,
      backgroundColor: Pal.bg,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          ExcludeFocus(child: _TitleBar()),
          ExcludeFocus(child: _MenuBar()),
          Expanded(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Expanded(child: gate ? const TallyGateway() : _TallyPage()),
                ExcludeFocus(child: _ButtonBar()),
              ],
            ),
          ),
          ExcludeFocus(child: _StatusBar()),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- title bar
class _TitleBar extends StatelessWidget {
  _TitleBar();

  @override
  Widget build(BuildContext context) {
    final Profile? me = live.me;
    final String who = me == null ? '' : '${me.name.isEmpty ? me.mobile : me.name} · ${_role(me.role)}';
    final DateTime now = DateTime.now();
    final TextStyle soft = ts(12.5, w: FontWeight.w600, c: const Color(0xFFB9D3E3));
    return Container(
      height: 26,
      color: _TC.title,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Row(
        children: <Widget>[
          Text('Balaji Pro', style: ts(14, w: FontWeight.w800, c: Colors.white, ls: 0.2)),
          const SizedBox(width: 6),
          Text('v$kAppVersion', style: ts(11.5, w: FontWeight.w600, c: const Color(0xFF8FB3C8))),
          const SizedBox(width: 10),
          Text('|', style: soft),
          const SizedBox(width: 10),
          Text('Balaji Industries', style: ts(13, w: FontWeight.w700, c: _TC.gold)),
          const Spacer(),
          if (who.isNotEmpty) Flexible(child: Text(who, maxLines: 1, overflow: TextOverflow.ellipsis, style: soft)),
          const SizedBox(width: 16),
          Text('${dayName(now)}, ${dmy(now)}', style: soft),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- menu bar
class _MenuBar extends StatelessWidget {
  _MenuBar();

  Widget _head(String hot, String label) {
    return Container(
      height: 26,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      alignment: Alignment.center,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Text('$hot: ', style: ts(13, w: FontWeight.w800, c: _TC.head)),
          Text(label, style: ts(13, w: FontWeight.w600, c: _TC.text)),
        ],
      ),
    );
  }

  Widget _plain(String hot, String label, VoidCallback onTap) {
    return InkWell(onTap: onTap, hoverColor: _TC.goldSoft, child: _head(hot, label));
  }

  Widget _popRow(_MI m) {
    return ConstrainedBox(
      constraints: const BoxConstraints(minWidth: 230),
      child: Row(
        children: <Widget>[
          Expanded(child: Text(m.title, style: ts(13.5, w: FontWeight.w600))),
          if (m.hint.isNotEmpty) Text(m.hint, style: ts(12, w: FontWeight.w700, c: _TC.head)),
        ],
      ),
    );
  }

  Widget _menu(BuildContext context, String hot, String label) {
    final List<_MI> items = _menuItems(hot, context).where((_MI m) => (!m.admin || live.isAdmin) && (m.id == null || screenOn(m.id!))).toList();
    if (items.isEmpty) return _head(hot, label);
    return PopupMenuButton<int>(
      key: _menuKeys[hot],
      tooltip: hot == 'F1' ? 'F1' : 'Ctrl+$hot',
      position: PopupMenuPosition.under,
      color: Pal.surface,
      elevation: 6,
      padding: EdgeInsets.zero,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero, side: BorderSide(color: Pal.line)),
      onSelected: (int i) => ErrLog.guard(hot, items[i].run),
      itemBuilder: (BuildContext c) => <PopupMenuEntry<int>>[
        for (int i = 0; i < items.length; i++) PopupMenuItem<int>(value: i, height: 30, child: _popRow(items[i])),
      ],
      child: _head(hot, label),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 26,
      decoration: BoxDecoration(color: _TC.menu, border: Border(bottom: BorderSide(color: Pal.line))),
      child: Row(
        children: <Widget>[
          for (final _MD d in _menuDefs)
            if (d.hot == 'G') _plain(d.hot, d.label, () => showCommandPalette(context)) else _menu(context, d.hot, d.label),
          const Spacer(),
          _menu(context, 'F1', bi('મદદ', 'Help')),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- button bar
class _ButtonBar extends StatelessWidget {
  _ButtonBar();

  /// One button of the bar. A failure inside the action is told on the screen instead of vanishing.
  Widget _btn(String key, String label, VoidCallback onTap, {bool strong = false}) {
    return InkWell(
      onTap: () => ErrLog.guard(key.isEmpty ? label : key, onTap),
      hoverColor: _TC.goldSoft,
      child: Container(
        height: 27,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        alignment: Alignment.centerLeft,
        decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Pal.line.withAlpha(140)))),
        child: Text.rich(
          TextSpan(children: <InlineSpan>[
            if (key.isNotEmpty) TextSpan(text: '$key: ', style: ts(12.5, w: FontWeight.w800, c: _TC.head)),
            TextSpan(text: label, style: ts(12.5, w: strong ? FontWeight.w800 : FontWeight.w600, c: _TC.text)),
          ]),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
      ),
    );
  }

  /// The buttons that belong to the screen that is open, like the changing button bar of TallyPrime:
  /// Accept for a form, Print / Excel / Period for a report, Delete for a voucher, Create for a list.
  List<Widget> _screenButtons(BuildContext context) {
    final List<Widget> l = <Widget>[];
    if (AcceptHub.has) {
      l.add(_btn('Ctrl+A', bi('સેવ (Accept)', 'Accept (save)'), () {
        AcceptHub.run();
      }, strong: true));
    }
    if (printHub.has) {
      l.add(_btn('Ctrl+P', bi('પ્રિન્ટ', 'Print'), () {
        printHub.run();
      }));
    }
    if (exportHub.has) {
      l.add(_btn('Alt+E', bi('Excel માં (Export)', 'Export (Excel)'), () {
        exportHub.run();
      }));
    }
    if (deleteHub.has) {
      l.add(_btn('Alt+D', bi('કાઢો (Delete)', 'Delete'), () {
        deleteHub.run();
      }));
    }
    if (_createIds.contains(app.current) && !AcceptHub.has) {
      l.add(_btn('Alt+C', bi('નવું (Create)', 'Create new'), () => _createHere(context)));
    }
    return l;
  }

  @override
  Widget build(BuildContext context) {
    final List<_Act> acts = _fActs().where((_Act a) => (!a.admin || live.isAdmin) && screenOn(a.sid)).toList();
    return Container(
      width: 196,
      decoration: BoxDecoration(color: Pal.surface, border: Border(left: BorderSide(color: Pal.line))),
      child: AnimatedBuilder(
        animation: Listenable.merge(<Listenable>[AcceptHub.depth, printHub.count, exportHub.count, deleteHub.count, periodHub.count]),
        builder: (BuildContext c, Widget? w) {
          final List<Widget> here = _screenButtons(context);
          return ListView(
            padding: EdgeInsets.zero,
            children: <Widget>[
              for (final _Act a in acts) _btn(a.key, a.title, () => a.run(context)),
              if (here.isNotEmpty) Container(height: 6, color: Pal.bg),
              ...here,
              Container(height: 6, color: Pal.bg),
              _btn('Ctrl+N', bi('કેલ્ક્યુલેટર', 'Calculator'), () => openCalcSheet(context)),
              if (app.current == 'dashboard') _btn('Q', bi('બહાર નીકળો (Quit)', 'Quit'), () => _quit(context), strong: true),
              if (app.canBack) _btn('Esc', bi('પાછા', 'Back'), () => app.back(), strong: true),
              if (!app.canBack && app.current != 'dashboard') _btn('Esc', bi('ગેટવે', 'Gateway'), () => app.go('dashboard', root: true), strong: true),
              if (app.pinOn) _btn('', bi('લોક', 'Lock'), () => app.lock()),
            ],
          );
        },
      ),
    );
  }
}

// ---------------------------------------------------------------- status bar
class _StatusBar extends StatelessWidget {
  _StatusBar();

  @override
  Widget build(BuildContext context) {
    String tone = 'green';
    String text = bi('ઓનલાઇન', 'Online');
    if (live.offline) {
      tone = 'amber';
      text = bi('ઑફલાઇન', 'Offline');
    } else if (live.error.isNotEmpty) {
      tone = 'rose';
      text = bi('ભૂલ', 'Error');
    }
    if (live.pending.isNotEmpty) {
      tone = 'blue';
      text = bi('${live.pending.length} બાકી', '${live.pending.length} waiting');
    }
    if (live.needsReauth) {
      tone = 'amber';
      text = bi('પાસવર્ડ નાખો (ઑફલાઇન લૉગિન)', 'Enter password (offline login)');
    }
    final Tone t = Pal.tone(tone);
    final String when = live.loadedAt == null ? '' : ago(live.loadedAt!);
    final int alerts = alertCount();
    return Container(
      height: 26,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(color: _TC.bar, border: Border(top: BorderSide(color: Pal.line))),
      child: Row(
        children: <Widget>[
          InkWell(
            onTap: () => live.needsReauth ? showReauth(context) : (live.pending.isNotEmpty ? app.go('offline_queue') : live.refresh()),
            child: Row(
              children: <Widget>[
                live.loading
                    ? SizedBox(width: 11, height: 11, child: CircularProgressIndicator(strokeWidth: 2, color: t.fg))
                    : Container(width: 9, height: 9, color: t.fg),
                const SizedBox(width: 7),
                Text(when.isEmpty ? text : '$text · $when', style: ts(12, w: FontWeight.w700, c: _TC.text)),
              ],
            ),
          ),
          const SizedBox(width: 16),
          if (alerts > 0)
            InkWell(
              onTap: () => app.go('alerts'),
              child: Text('${bi('ધ્યાનમાં લો', 'Attention')}: $alerts', style: ts(12, w: FontWeight.w800, c: Pal.bad)),
            ),
          if (LaptopBackup.supported && live.isAdmin)
            ValueListenableBuilder<int>(
              valueListenable: LaptopBackup.tick,
              builder: (BuildContext c, int n, Widget? w) {
                final DateTime? at = LaptopBackup.lastAt;
                return InkWell(
                  onTap: () => app.go('backup'),
                  child: Padding(
                    padding: const EdgeInsets.only(left: 16),
                    child: Text(
                      at == null ? bi('લેપટોપ કૉપી: હજી નહીં', 'Laptop copy: not yet') : '${bi('લેપટોપ કૉપી', 'Laptop copy')} ${hm(at)}',
                      style: ts(12, w: FontWeight.w700, c: at == null ? Pal.muted : Pal.ok),
                    ),
                  ),
                );
              },
            ),
          const Spacer(),
          Flexible(
            child: ValueListenableBuilder<int>(
              valueListenable: AcceptHub.depth,
              builder: (BuildContext c, int n, Widget? w) => Text(
                n > 0
                    ? bi('Enter આગળ · ↑ ↓ ખાનું · Ctrl+Enter સેવ · Esc પાછા', 'Enter next · ↑ ↓ field · Ctrl+Enter accept · Esc back')
                    : bi('↑ ↓ Enter ખોલો · Alt+C નવું · Ctrl+F શોધ · Esc પાછા · F-કી જમણી બાજુ', '↑ ↓ Enter open · Alt+C new · Ctrl+F search · Esc back · F-keys on the right'),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: ts(11.5, c: Pal.muted),
              ),
            ),
          ),
          const SizedBox(width: 16),
          Text('FY ${_fy()}', style: ts(11.5, w: FontWeight.w700, c: Pal.muted)),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- page frame
class _TallyPage extends StatelessWidget {
  _TallyPage();

  @override
  Widget build(BuildContext context) {
    final String id = app.current;
    final String title = screenTitle(id, app.arg);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        // like a TallyPrime report: dark title strip with the report name, company and period
        Container(
          height: 28,
          color: _TC.head,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            children: <Widget>[
              Flexible(child: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14, w: FontWeight.w800, c: Colors.white))),
              const SizedBox(width: 18),
              Text('Balaji Industries', maxLines: 1, style: ts(13, w: FontWeight.w700, c: const Color(0xFFFFE27A))),
              const Spacer(),
              Text(_fy(), maxLines: 1, style: ts(12, w: FontWeight.w600, c: const Color(0xFFD3E5F2))),
              const SizedBox(width: 14),
              InkWell(
                onTap: () => app.canBack ? app.back() : app.go('dashboard', root: true),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 2),
                  decoration: BoxDecoration(border: Border.all(color: const Color(0x99FFFFFF))),
                  child: Text('Esc: ${bi('પાછા', 'Back')}', style: ts(12, w: FontWeight.w800, c: Colors.white)),
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: Container(
            margin: const EdgeInsets.fromLTRB(5, 5, 5, 5),
            decoration: BoxDecoration(color: Pal.surface, border: Border.all(color: Pal.line)),
            child: ClipRect(child: ScreenHost()),
          ),
        ),
      ],
    );
  }
}

// ======================================================================
// Gateway of Tally (home)
// ======================================================================

class _G {
  final String gu;
  final String en;
  final String? id;
  final Object? arg; // given to the screen (e.g. the voucher type of a register)
  final String fk;
  final bool open; // everybody may see it (not only the owner)
  final void Function(BuildContext)? run;
  final List<_G> kids; // not empty => this opens a sub-menu
  final String key; // what simple mode looks at for a line that is not a plain screen ('' = the screen id)
  const _G(this.gu, this.en, {this.id, this.arg, this.fk = '', this.run, this.kids = const <_G>[], this.open = false, this.key = ''});

  /// A menu line that opens a screen is named exactly like that screen (one name list: features/registry.dart).
  String get title => id == null ? bi(gu, en) : screenTitle(id!, arg);

  bool get folder => kids.isNotEmpty;
  bool get ok => folder ? kids.any((_G k) => k.ok) : (screenOnFor(key.isNotEmpty ? key : (id ?? ''), live.isAdmin) && (open || live.isAdmin || (id != null && kStaffIds.contains(id))));

  /// This item with only the parts the person may open (null when nothing is left).
  _G? pruned() {
    if (!folder) return ok ? this : null;
    final List<_G> keep = <_G>[
      for (final _G k in kids)
        if (k.pruned() != null) k.pruned()!,
    ];
    if (keep.isEmpty) return null;
    return _G(gu, en, kids: keep);
  }
}

class _GS {
  final String gu;
  final String en;
  final List<_G> items;
  const _GS(this.gu, this.en, this.items);
  String get title => bi(gu, en);
}

/// Quit (like Tally): asks, then closes the app. Saved data and waiting entries are already on the disk.
Future<void> _quit(BuildContext c) async {
  final bool yes = await confirmBox(
    c,
    title: bi('બહાર નીકળવું છે?', 'Quit Balaji Pro?'),
    text: bi('એપ બંધ થશે. સેવ થયેલો ડેટા અને મોકલવાની બાકી એન્ટ્રી સુરક્ષિત રહેશે.', 'The app will close. Saved data and entries waiting to upload stay safe.'),
    yes: bi('હા, બંધ કરો', 'Yes, quit'),
    no: bi('ના', 'No'),
  );
  if (yes) exit(0);
}

/// Gateway of Balaji - the same order as the Gateway of TallyPrime:
/// Masters, Transactions, Utilities, Reports, Quit. Menus open inside menus, like Tally.
List<_GS> _gateData() {
  final List<_GS> all = <_GS>[
    _GS('માસ્ટર્સ', 'Masters', <_G>[
      _G('ખાતાવહી (ખાતા)', 'Chart of Accounts', kids: <_G>[
        const _G('', '', id: 'my_ledger'),
        const _G('', '', id: 'khedut_khata'),
        const _G('', '', id: 'buyer_khata'),
        const _G('', '', id: 'parties'),
        const _G('', '', id: 'tally_ledgers'),
      ]),
      _G('સ્ટોક આઇટમ', 'Stock Items', kids: <_G>[
        _G('ખુલતો સ્ટોક', 'Opening Stock', key: 'v_stock_open', run: (BuildContext c) => openStockForm(c)),
        const _G('', '', id: 'rates'),
        const _G('', '', id: 'stock_live'),
      ]),
    ]),
    _GS('વ્યવહાર', 'Transactions', <_G>[
      _G('વાઉચર', 'Vouchers', kids: <_G>[
        _G('કોન્ટ્રા વાઉચર · રોકડ ↔ બેંક', 'Contra Voucher · Cash / Bank', fk: 'F4', key: 'v_contra', run: (BuildContext c) => openContraForm(c)),
        _G('ચૂકવણી વાઉચર', 'Payment Voucher', fk: 'F5', key: 'v_payment', run: (BuildContext c) => openPayForm(c)),
        _G('રસીદ વાઉચર', 'Receipt Voucher', fk: 'F6', key: 'v_receipt', run: (BuildContext c) => openSaleForm(c, kind: 'recv')),
        _G('જર્નલ વાઉચર · ખેડૂત જૂનું બાકી', 'Journal Voucher · Farmer Opening Balance', fk: 'F7', key: 'v_open_farmer', run: (BuildContext c) => openPayForm(c, kind: 'open')),
        _G('જર્નલ વાઉચર · ખરીદનાર જૂનું બાકી', 'Journal Voucher · Buyer Opening Balance', key: 'v_open_buyer', run: (BuildContext c) => openSaleForm(c, kind: 'open')),
        _G('વેચાણ વાઉચર', 'Sales Voucher', fk: 'F8', key: 'v_sales', run: (BuildContext c) => openSaleForm(c)),
        const _G('', '', id: 'chithi_new', fk: 'F9'),
        _G('ક્રેડિટ નોટ · વેચાણ પરત', 'Credit Note · Sales return', fk: 'Ctrl+F8', key: 'v_credit', run: (BuildContext c) => openNoteForm(c, credit: true)),
        _G('ડેબિટ નોટ · ખરીદ પરત', 'Debit Note · Purchase return', fk: 'Ctrl+F9', key: 'v_debit', run: (BuildContext c) => openNoteForm(c, credit: false)),
        _G('ખર્ચ / આવક વાઉચર', 'Expense / Income Voucher', fk: 'F10', key: 'v_expense', run: (BuildContext c) => openExpForm(c)),
        _G('પ્રોસેસ વાઉચર', 'Processing Voucher', fk: 'F10', key: 'v_process', run: (BuildContext c) => openProcessForm(c)),
        const _G('', '', id: 'kanta_new', fk: 'F10'),
        const _G('', '', id: 'maal_new', fk: 'F10'),
        const _G('', '', id: 'gst_bill'),
        const _G('', '', id: 'trading'),
        const _G('', '', id: 'scan'),
      ]),
      const _G('', '', id: 'my_daybook'),
    ]),
    _GS('સાધનો', 'Utilities', <_G>[
      _G('બેંકિંગ', 'Banking', kids: <_G>[
        const _G('', '', id: 'bank_match'),
        const _G('', '', id: 'tally_bank'),
      ]),
      _G('ઇમ્પોર્ટ', 'Import', kids: <_G>[
        const _G('', '', id: 'scan'),
        const _G('', '', id: 'kanta_auto'),
        const _G('', '', id: 'kanta_usb'),
        const _G('', '', id: 'offline_queue'),
      ]),
      _G('એક્સપોર્ટ', 'Export', kids: <_G>[
        const _G('', '', id: 'export_money'),
        const _G('', '', id: 'export'),
        const _G('', '', id: 'table'),
      ]),
      const _G('', '', id: 'history'),
      const _G('', '', id: 'backup'),
      const _G('', '', id: 'day_close'),
      _G('કેલ્ક્યુલેટર', 'Calculator', fk: 'Ctrl+N', open: true, key: 'v_calc', run: (BuildContext c) => openCalcSheet(c)),
      const _G('', '', id: 'settings'),
      _G('ગોઠવણ', 'Configure', fk: 'F12', open: true, key: 'v_configure', run: (BuildContext c) => _openConfigure(c)),
      const _G('', '', id: 'help'),
      if (app.pinOn) _G('લોક', 'Lock', open: true, key: 'v_lock', run: (BuildContext c) => app.lock()),
    ]),
    _GS('રિપોર્ટ', 'Reports', <_G>[
      const _G('', '', id: 'balance_sheet'),
      const _G('', '', id: 'profit_loss'),
      const _G('', '', id: 'ratio_analysis'),
      const _G('', '', id: 'biz_graph'),
      const _G('', '', id: 'stock_live'),
      const _G('', '', id: 'my_trial'),
      const _G('', '', id: 'my_daybook'),
      const _G('', '', id: 'biz_home'),
      const _G('', '', id: 'alerts', fk: 'F11'),
      // what the Tally books (Patel, Shreenathji, Balaji - with GST) show, read from Tally
      _G('Tally ડેટા (GST સાથે)', 'Tally Data (with GST)', kids: <_G>[
        const _G('', '', id: 'tally_sum'),
        const _G('', '', id: 'tally_live'),
        const _G('', '', id: 'tally_gst'),
        const _G('', '', id: 'tally_ledgers'),
        const _G('', '', id: 'tally_cash'),
        const _G('', '', id: 'tally_bank'),
        const _G('', '', id: 'tally_stock'),
        const _G('', '', id: 'tally_age'),
        const _G('', '', id: 'tally_mel'),
        const _G('', '', id: 'tally_pay'),
        const _G('', '', id: 'tally_check'),
      ]),
      _G('વધુ રિપોર્ટ', 'Display More Reports', kids: <_G>[
        _G('હિસાબ ચોપડા', 'Account Books', kids: <_G>[
          const _G('', '', id: 'cashbook'),
          const _G('', '', id: 'bank_book'),
          const _G('', '', id: 'my_ledger'),
          const _G('', '', id: 'group_summary'),
          const _G('', '', id: 'my_trial'),
          const _G('', '', id: 'my_daybook'),
          const _G('', '', id: 'my_daybook', key: 'dbk_SAL', arg: DayBookArg(type: 'SAL')),
          const _G('', '', id: 'my_daybook', key: 'dbk_PUR', arg: DayBookArg(type: 'PUR')),
          const _G('', '', id: 'my_daybook', key: 'dbk_PAY', arg: DayBookArg(type: 'PAY')),
          const _G('', '', id: 'my_daybook', key: 'dbk_RCT', arg: DayBookArg(type: 'RCT')),
          const _G('', '', id: 'my_daybook', key: 'dbk_JRN', arg: DayBookArg(type: 'JRN')),
          const _G('', '', id: 'my_daybook', key: 'dbk_EXP', arg: DayBookArg(type: 'EXP')),
          const _G('', '', id: 'my_daybook', key: 'dbk_INC', arg: DayBookArg(type: 'INC')),
          const _G('', '', id: 'my_daybook', key: 'dbk_CON', arg: DayBookArg(type: 'CON')),
          const _G('', '', id: 'expenses'),
        ]),
        _G('ખાતાના નિવેદન', 'Statements of Accounts', kids: <_G>[
          const _G('', '', id: 'outstandings'),
          const _G('', '', id: 'collection'),
          const _G('', '', id: 'cash_flow'),
          const _G('', '', id: 'day_account'),
          const _G('', '', id: 'month_close'),
          const _G('', '', id: 'statement'),
          const _G('', '', id: 'brokerage'),
          const _G('', '', id: 'wages'),
          const _G('', '', id: 'weight_bill'),
        ]),
        _G('સ્ટોક બુક', 'Inventory Books', kids: <_G>[
          const _G('', '', id: 'stock_live'),
          const _G('', '', id: 'maal_stock'),
          const _G('', '', id: 'maal'),
          const _G('', '', id: 'process_grade'),
        ]),
        _G('ચિઠ્ઠી અને કાંટા', 'Chits and Kanta', kids: <_G>[
          const _G('', '', id: 'chithi'),
          const _G('', '', id: 'kanta'),
          const _G('', '', id: 'mel'),
          const _G('', '', id: 'transit'),
          const _G('', '', id: 'daily'),
          const _G('', '', id: 'vehicle_lookup'),
        ]),
        _G('વેચાણ અને નફો', 'Sales and Margin', kids: <_G>[
          const _G('', '', id: 'sales'),
          const _G('', '', id: 'gst_bill'),
          const _G('', '', id: 'trading'),
          const _G('', '', id: 'margin'),
          const _G('', '', id: 'cost_calc'),
          const _G('', '', id: 'analytics'),
        ]),
        _G('વૈધાનિક રિપોર્ટ', 'Statutory Reports', kids: <_G>[
          const _G('', '', id: 'gst_bill'),
          const _G('', '', id: 'gstr1'),
          const _G('', '', id: 'tally_gst'),
          const _G('', '', id: 'tally_check'),
        ]),
        _G('અપવાદ રિપોર્ટ', 'Exception Reports', kids: <_G>[
          const _G('', '', id: 'alerts', fk: 'F11'),
          const _G('', '', id: 'bad_entries'),
          const _G('', '', id: 'debit_check'),
          const _G('', '', id: 'history'),
        ]),
        _G('આજે', 'Today', kids: <_G>[
          const _G('', '', id: 'biz_home'),
          const _G('', '', id: 'my_day'),
          const _G('', '', id: 'today', fk: 'F2'),
          const _G('', '', id: 'day_account'),
          const _G('', '', id: 'staff'),
        ]),
        const _G('', '', id: 'hub'),
      ]),
    ]),
    _GS('', '', <_G>[
      _G('બહાર નીકળો', 'Quit', fk: 'Q', open: true, key: 'v_quit', run: (BuildContext c) => _quit(c)),
    ]),
  ];
  final List<_GS> out = <_GS>[];
  for (final _GS s in all) {
    final List<_G> keep = <_G>[
      for (final _G g in s.items)
        if (g.pruned() != null) g.pruned()!,
    ];
    if (keep.isNotEmpty) out.add(_GS(s.gu, s.en, keep));
  }
  return out;
}

class TallyGateway extends StatefulWidget {
  const TallyGateway({super.key});

  @override
  State<TallyGateway> createState() => _TallyGatewayState();
}

class _TallyGatewayState extends State<TallyGateway> {
  /// the menu the person was in last time, so Esc from a report comes back to the same menu
  static List<String> _lastPath = <String>[];
  List<String> _path = <String>[];
  String _focusAfterUp = '';
  int _sel = 0;
  List<_G> _flat = <_G>[];
  final Map<int, GlobalKey> _keys = <int, GlobalKey>{};

  @override
  void initState() {
    super.initState();
    _path = List<String>.from(_lastPath);
    // the Tally figures in the box on the left (the store keeps the last copy for 3 minutes)
    if (live.isAdmin) tallyStore.load();
  }

  /// The Gateway takes the keys through the focus tree (not a global handler): a global handler cannot stop the
  /// same Enter / arrow from also reaching a focused button (that opened the K: Company menu by itself).
  KeyEventResult _onFocusKey(FocusNode n, KeyEvent e) {
    return _onKey(e) ? KeyEventResult.handled : KeyEventResult.ignored;
  }

  bool _onKey(KeyEvent e) {
    if (e is! KeyDownEvent && e is! KeyRepeatEvent) return false;
    if (!mounted) return false;
    final ModalRoute<dynamic>? r = ModalRoute.of(context);
    if (r != null && !r.isCurrent) return false;
    final BuildContext? fc = FocusManager.instance.primaryFocus?.context;
    if (fc != null && fc.findAncestorWidgetOfExactType<EditableText>() != null) return false;
    final HardwareKeyboard hk = HardwareKeyboard.instance;
    if (hk.isControlPressed || hk.isAltPressed || hk.isMetaPressed) return false;
    final LogicalKeyboardKey k = e.logicalKey;
    if (k == LogicalKeyboardKey.arrowDown) {
      _move(_sel + 1);
    } else if (k == LogicalKeyboardKey.arrowUp) {
      _move(_sel - 1);
    } else if (k == LogicalKeyboardKey.pageDown) {
      _move(_sel + 6);
    } else if (k == LogicalKeyboardKey.pageUp) {
      _move(_sel - 6);
    } else if (k == LogicalKeyboardKey.home) {
      _move(0);
    } else if (k == LogicalKeyboardKey.end) {
      _move(_flat.length - 1);
    } else if (k == LogicalKeyboardKey.escape || k == LogicalKeyboardKey.backspace || k == LogicalKeyboardKey.arrowLeft) {
      if (e is! KeyDownEvent) return false;
      if (_path.isEmpty) {
        // Esc on the Gateway itself asks "Quit?" (like Tally)
        if (k != LogicalKeyboardKey.escape) return false;
        _quit(context);
        return true;
      }
      _up();
    } else if (k == LogicalKeyboardKey.arrowRight) {
      if (_sel < 0 || _sel >= _flat.length || !_flat[_sel].folder) return false;
      _open(_sel);
    } else if (k == LogicalKeyboardKey.enter || k == LogicalKeyboardKey.numpadEnter) {
      _open(_sel);
    } else if (k == LogicalKeyboardKey.keyQ && _path.isEmpty) {
      _quit(context);
    } else {
      return false;
    }
    return true;
  }

  void _move(int to) {
    if (_flat.isEmpty) return;
    int i = to;
    if (i < 0) i = 0;
    if (i > _flat.length - 1) i = _flat.length - 1;
    setState(() => _sel = i);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final BuildContext? c = _keys[i]?.currentContext;
      if (c != null) Scrollable.ensureVisible(c, duration: const Duration(milliseconds: 90), alignment: 0.5);
    });
  }

  void _open(int i) {
    if (i < 0 || i >= _flat.length) return;
    final _G g = _flat[i];
    if (g.folder) {
      setState(() {
        _path = <String>[..._path, g.en];
        _lastPath = List<String>.from(_path);
        _sel = 0;
      });
      return;
    }
    final void Function(BuildContext)? r = g.run;
    if (r != null) {
      ErrLog.guard(g.en, () => r(context));
      return;
    }
    final String? id = g.id;
    if (id != null) ErrLog.guard(g.title, () => app.go(id, arg: g.arg));
  }

  /// one menu up (the menu we leave stays selected)
  void _up() {
    if (_path.isEmpty) return;
    setState(() {
      _focusAfterUp = _path.last;
      _path = _path.sublist(0, _path.length - 1);
      _lastPath = List<String>.from(_path);
    });
  }

  // ------------------------------------------------------------ left info
  /// Tally style: small heading strip, then the value.
  Widget _box(String head, Widget body) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(color: Pal.surface, border: Border.all(color: Pal.line)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            color: _TC.bar,
            child: Text(head.toUpperCase(), style: ts(11, w: FontWeight.w800, c: _TC.head, ls: 0.4)),
          ),
          Padding(padding: const EdgeInsets.fromLTRB(10, 7, 10, 7), child: body),
        ],
      ),
    );
  }

  Widget _glance() {
    final DateTime now = DateTime.now();
    int cn = 0;
    double ck = 0;
    for (final Chit c in live.chits) {
      if (sameDay(c.at, now)) {
        cn++;
        ck += c.net;
      }
    }
    int kn = 0;
    double kk = 0;
    for (final Kanta k in live.kantas) {
      if (sameDay(k.at, now)) {
        kn++;
        kk += k.kg;
      }
    }
    final List<Widget> rows = <Widget>[
      _kv(bi('ચિઠ્ઠી આજે', 'Chits today'), '$cn · ${kgs(ck)}', onTap: () => app.go('chithi')),
      _kv(bi('કાંટા આજે', 'Kanta today'), '$kn · ${kgs(kk)}', onTap: () => app.go('kanta')),
    ];
    if (!live.isAdmin) return Column(children: rows);
    final int alerts = alertCount();
    rows.add(_kv(bi('ધ્યાનમાં લો', 'Attention'), '$alerts', onTap: () => app.go('alerts'), color: alerts > 0 ? Pal.bad : null));
    if (live.badCount > 0) {
      rows.add(_kv(bi('ખોટા વજનની એન્ટ્રી', 'Wrong-weight entries'), '${live.badCount}', onTap: () => app.go('bad_entries'), color: Pal.bad));
    }
    return DocsScope(
      docs: <SyncDoc>[saleDoc, procDoc, prefDoc],
      builder: (BuildContext _) {
        double sold = 0;
        for (final SaleItem x in saleItems()) {
          if (x.isSale && sameDay(x.date, dayOf(now))) sold += x.amt;
        }
        double due = 0;
        for (final AgedBuyer a in agedBuyers()) {
          due += a.due;
        }
        double raw = 0;
        for (final StockLine r in stockRows()) {
          if (r.raw) raw += r.left;
        }
        return Column(
          children: <Widget>[
            ...rows,
            _kv(bi('આજે વેચાણ', 'Sold today'), inrC(sold), onTap: () => app.go('sales')),
            _kv(bi('વસૂલ કરવાના', 'To collect'), inrC(due), onTap: () => app.go('collection')),
            _kv(bi('કાચો સ્ટોક', 'Raw stock'), kgs(raw), onTap: () => app.go('stock_live')),
          ],
        );
      },
    );
  }

  /// What Tally shows for the year (Patel, Shreenathji and Balaji together): sales, purchase, GST, dues.
  Widget _tallyGlance() {
    return ListenableBuilder(
      listenable: tallyStore,
      builder: (BuildContext c, Widget? _) {
        final DateTime now = DateTime.now();
        final TallyGlance g = tallyGlance(TallyStore.fyStart(), '${now.year}-${pad2(now.month)}-${pad2(now.day)}');
        if (!g.has) {
          return InkWell(
            onTap: () => app.go('tally_live'),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Text(
                tallyStore.loading ? bi('Tally નો ડેટા આવે છે...', 'Tally data is coming...') : bi('Tally નો ડેટા હજી આવ્યો નથી', 'No Tally data yet'),
                style: ts(13, c: Pal.muted),
              ),
            ),
          );
        }
        if (kSimple) {
          // simple mode: sales (3 firms), what the buyers owe, cash and bank (the other firm), and the purchase check
          return Column(
            children: <Widget>[
              _kv(bi('વેચાણ', 'Sales'), '${inrC(g.sales)} (${g.salesN})', onTap: () => app.go('tally_live')),
              _kv(bi('લેવાના (ખરીદનાર)', 'To receive (buyers)'), inrC(g.receivable), onTap: () => app.go('collection')),
              _kv(bi('રોકડ', 'Cash'), inrC(g.cash), onTap: () => app.go('cashbook')),
              _kv(bi('બેંક', 'Bank'), inrC(g.bank), onTap: () => app.go('bank_book')),
              _kv(bi('ખરીદી મેળ (Tally ↔ Pro)', 'Purchase check (Tally ↔ Pro)'), '${g.purchN}', onTap: () => app.go('tally_mel')),
            ],
          );
        }
        return Column(
          children: <Widget>[
            _kv(bi('વેચાણ', 'Sales'), '${inrC(g.sales)} (${g.salesN})', onTap: () => app.go('tally_live')),
            _kv(bi('ખરીદી', 'Purchase'), '${inrC(g.purchase)} (${g.purchN})', onTap: () => app.go('tally_mel')),
            _kv(bi('વેચાણ પર GST', 'GST on sales'), inrC(g.gstOut), onTap: () => app.go('tally_gst')),
            _kv(bi('ખરીદી પર GST', 'GST on purchase'), inrC(g.gstIn), onTap: () => app.go('tally_gst')),
            _kv(g.gstNet >= 0 ? bi('GST ભરવાનો', 'GST to pay') : bi('GST પાછો લેવાનો', 'GST to get back'), inrC(g.gstNet.abs()), onTap: () => app.go('tally_gst'), color: g.gstNet > 0.5 ? Pal.warn : Pal.ok),
            _kv(bi('લેવાના', 'To receive'), inrC(g.receivable), onTap: () => app.go('tally_age')),
            _kv(bi('આપવાના', 'To pay'), inrC(g.payable), onTap: () => app.go('tally_age')),
          ],
        );
      },
    );
  }

  Widget _info() {
    final DateTime now = DateTime.now();
    DateTime? last;
    for (final Chit c in live.chits) {
      if (last == null || c.at.isAfter(last)) last = c.at;
    }
    for (final Kanta k in live.kantas) {
      if (last == null || k.at.isAfter(last)) last = k.at;
    }
    for (final MaalRow m in live.maals) {
      if (last == null || m.at.isAfter(last)) last = m.at;
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        // the weighbridge from the phone / PC: always on top of the Gateway (it used to be only on the Modern home)
        if (live.isAdmin) _box(bi('કાંટો રિમોટ', 'Kanta remote'), const KantaRemoteCard(compact: true)),
        _box(bi('ચાલુ સમયગાળો', 'Current period'), Text(_fy(), style: ts(14, w: FontWeight.w800))),
        _box(bi('આજની તારીખ', 'Current date'), Text('${dayName(now)}, ${dmy(now)}', style: ts(14, w: FontWeight.w800))),
        _box(
          bi('કંપનીનું નામ', 'Name of company'),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text('Balaji Industries', style: ts(15, w: FontWeight.w800, c: _TC.head)),
              const SizedBox(height: 2),
              Text(bi('મગફળી · મગફડી પ્રોસેસિંગ અને વેપાર', 'Groundnut · magfadi processing and trade'), style: ts(12, c: Pal.muted)),
              const SizedBox(height: 6),
              _kv(bi('છેલ્લી એન્ટ્રીની તારીખ', 'Date of last entry'), last == null ? '-' : dmy(last)),
            ],
          ),
        ),
        _box(bi('આજે એક નજરમાં', 'Today at a glance'), _glance()),
        if (live.isAdmin) _box(bi('Tally ડેટા · આ વર્ષ', 'Tally data · this year'), _tallyGlance()),
      ],
    );
  }

  // ------------------------------------------------------------ menu
  Widget _secHead(_GS s) {
    if (s.gu.isEmpty) {
      return Padding(padding: const EdgeInsets.fromLTRB(14, 8, 14, 4), child: Container(height: 1, color: Pal.line));
    }
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 2),
      child: Text(s.title, style: ts(13, w: FontWeight.w800, c: _TC.head)),
    );
  }

  Widget _row(_G g, int i, {double indent = 16}) {
    final bool sel = i == _sel;
    final Color ink = sel ? _TC.goldInk : _TC.text;
    return InkWell(
      key: _keys.putIfAbsent(i, () => GlobalKey()),
      onTap: () {
        setState(() => _sel = i);
        _open(i);
      },
      hoverColor: _TC.goldSoft,
      child: Container(
        height: 28,
        color: sel ? _TC.gold : Colors.transparent,
        padding: EdgeInsets.fromLTRB(indent, 0, 14, 0),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Text(
                g.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: ts(14, w: sel ? FontWeight.w800 : FontWeight.w600, c: ink),
              ),
            ),
            if (g.fk.isNotEmpty) Text(g.fk, style: ts(11.5, w: FontWeight.w800, c: sel ? _TC.goldInk : Pal.muted)),
          ],
        ),
      ),
    );
  }

  Widget _menuCard(List<Widget> rows, List<_G> trail, double maxH) {
    final bool inside = trail.isNotEmpty;
    final String head = inside ? trail.last.title : bi('ગેટવે ઓફ બાલાજી', 'Gateway of Balaji');
    final String path = inside ? '${bi('ગેટવે', 'Gateway')}  ›  ${trail.map((_G g) => g.title).join('  ›  ')}' : '';
    return ConstrainedBox(
      constraints: BoxConstraints(maxHeight: maxH < 160 ? 160 : maxH),
      child: Container(
        decoration: BoxDecoration(color: Pal.surface, border: Border.all(color: Pal.line)),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Container(
              height: 32,
              color: _TC.head,
              padding: const EdgeInsets.symmetric(horizontal: 6),
              child: Row(
                children: <Widget>[
                  if (inside)
                    InkWell(
                      onTap: _up,
                      child: const Padding(padding: EdgeInsets.symmetric(horizontal: 6, vertical: 6), child: Icon(Icons.arrow_back_rounded, size: 18, color: Colors.white)),
                    )
                  else
                    const SizedBox(width: 8),
                  Expanded(child: Text(head, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14, w: FontWeight.w800, c: Colors.white))),
                  if (inside) Text('Esc', style: ts(11.5, w: FontWeight.w700, c: const Color(0xB3FFFFFF))),
                  const SizedBox(width: 8),
                ],
              ),
            ),
            if (inside && trail.length > 1)
              Container(
                padding: const EdgeInsets.fromLTRB(12, 5, 12, 5),
                color: _TC.bar,
                child: Text(path, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(11.5, w: FontWeight.w600, c: _TC.head)),
              ),
            Flexible(
              child: SingleChildScrollView(
                padding: const EdgeInsets.only(bottom: 8),
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: rows),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final List<_GS> secs = _gateData();
    // walk the remembered menu path (a menu that is no longer there is dropped)
    List<_G> cur = <_G>[for (final _GS s in secs) ...s.items];
    final List<_G> trail = <_G>[];
    for (final String key in _path) {
      _G? hit;
      for (final _G g in cur) {
        if (g.folder && g.en == key) {
          hit = g;
          break;
        }
      }
      if (hit == null) break;
      trail.add(hit);
      cur = hit.kids;
    }
    if (trail.length != _path.length) _path = <String>[for (final _G g in trail) g.en];
    _flat = cur;
    if (_focusAfterUp.isNotEmpty) {
      final int fi = _flat.indexWhere((_G g) => g.en == _focusAfterUp);
      _sel = fi < 0 ? 0 : fi;
      _focusAfterUp = '';
    }
    if (_sel >= _flat.length) _sel = _flat.isEmpty ? 0 : _flat.length - 1;
    final List<Widget> rows = <Widget>[];
    if (trail.isEmpty) {
      int idx = 0;
      for (final _GS s in secs) {
        rows.add(_secHead(s));
        for (final _G g in s.items) {
          rows.add(_row(g, idx, indent: s.gu.isEmpty ? 14 : 28));
          idx++;
        }
      }
    } else {
      for (int i = 0; i < _flat.length; i++) {
        rows.add(_row(_flat[i], i, indent: 16));
      }
    }
    return Focus(
      autofocus: true,
      onKeyEvent: _onFocusKey,
      child: ExcludeFocus(
        child: LayoutBuilder(
          builder: (BuildContext c, BoxConstraints box) {
            final bool wide = box.maxWidth >= 740;
            return Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  if (wide) SizedBox(width: 300, child: SingleChildScrollView(child: _info())),
                  Expanded(
                    child: Align(
                      alignment: Alignment.topCenter,
                      child: Padding(
                        padding: EdgeInsets.only(left: wide ? 12 : 0),
                        child: ConstrainedBox(
                          constraints: const BoxConstraints(maxWidth: 420),
                          child: (!wide && live.isAdmin && trail.isEmpty)
                              // narrow window: the left column is hidden, so the remote box sits above the menu
                              ? Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: <Widget>[
                                    _box(bi('કાંટો રિમોટ', 'Kanta remote'), const KantaRemoteCard(compact: true)),
                                    Flexible(child: _menuCard(rows, trail, box.maxHeight - 24 - 90)),
                                  ],
                                )
                              : _menuCard(rows, trail, box.maxHeight - 24),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
