import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/i18n.dart';
import '../core/icons.dart';
import '../core/palette.dart';
import '../data/live_store.dart';
import '../features/live/forms.dart';
import '../features/live/hisab.dart' show openCalcSheet;
import '../features/router.dart';
import '../widgets/common.dart';
import 'widgets.dart';

/// Phone layout: top app bar, scrolling body, bottom navigation with a raised
/// "+" button for a new entry.
class PhoneShell extends StatelessWidget {
  PhoneShell({super.key});

  @override
  Widget build(BuildContext context) {
    final MediaQueryData mq = MediaQuery.of(context);
    final bool keyboard = mq.viewInsets.bottom > 0;
    return Scaffold(
      backgroundColor: Pal.bg,
      body: Column(
        children: <Widget>[
          _PhoneBar(),
          Expanded(child: ScreenHost()),
          if (!keyboard) _PhoneNav(bottomPad: mq.padding.bottom),
        ],
      ),
    );
  }
}

// ------------------------------------------------------------------ app bar
class _PhoneBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final bool root = !app.canBack;
    final int alerts = alertCount();
    return Container(
      height: 60,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      decoration: BoxDecoration(
        color: Pal.surface,
        border: Border(bottom: BorderSide(color: Pal.line)),
      ),
      child: Row(
        children: <Widget>[
          if (root)
            const Padding(padding: EdgeInsets.symmetric(horizontal: 6), child: BrandMark(size: 36))
          else
            IconBtn('back', color: Pal.ink, onTap: app.back, tip: bi('પાછા', 'Back')),
          const SizedBox(width: 4),
          Expanded(
            child: Text(
              screenTitle(app.current, app.arg),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: ts(18, w: FontWeight.w800, ls: -0.3),
            ),
          ),
          const LiveChip(compact: true),
          const SizedBox(width: 2),
          if (live.isAdmin) IconBtn('bell', badge: alerts > 0, onTap: () => app.go('alerts'), tip: bi('ધ્યાનમાં લો', 'Attention')),
          IconBtn('calc', onTap: () => openCalcSheet(context), tip: bi('કૅલ્ક્યુલેટર', 'Calculator')),
          IconBtn('apps', onTap: () => app.go('hub'), tip: bi('બધા ફીચર', 'All features')),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------- bottom navigation
class _PhoneNav extends StatelessWidget {
  final double bottomPad;
  const _PhoneNav({required this.bottomPad});

  Widget _item(int i, int tab, String icon, String label, VoidCallback onTap) {
    final bool on = tab == i;
    final Color c = on ? Pal.brand : Pal.muted;
    return Expanded(
      child: InkWell(
        onTap: onTap,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              width: 56,
              height: 30,
              decoration: BoxDecoration(
                color: on ? Pal.soft : Colors.transparent,
                borderRadius: BorderRadius.circular(15),
              ),
              child: Icon(ic(icon), size: 23, color: c),
            ),
            const SizedBox(height: 3),
            Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(11, w: on ? FontWeight.w800 : FontWeight.w600, c: c)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool admin = live.isAdmin;
    final int tab = tabOf(app.current, app.arg, admin);
    return Container(
      height: 68 + bottomPad,
      padding: EdgeInsets.only(bottom: bottomPad),
      decoration: BoxDecoration(
        color: Pal.surface,
        border: Border(top: BorderSide(color: Pal.line)),
        boxShadow: const <BoxShadow>[BoxShadow(color: Color(0x14081C20), blurRadius: 16, offset: Offset(0, -4))],
      ),
      child: Row(
        children: <Widget>[
          _item(0, tab, 'home', bi('હોમ', 'Home'), () => app.go('dashboard', root: true)),
          _item(1, tab, 'receipt', bi('ચિઠ્ઠી', 'Chits'), () => app.go('chithi', root: true)),
          Expanded(
            child: Center(
              child: Transform.translate(
                offset: const Offset(0, -8),
                child: Tooltip(
                  message: bi('નવી એન્ટ્રી', 'New entry'),
                  child: GestureDetector(
                    onTap: () => showNewMenu(context),
                    child: Container(
                      width: 56,
                      height: 56,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: <Color>[Pal.tealLight, Pal.teal],
                        ),
                        boxShadow: const <BoxShadow>[BoxShadow(color: Color(0x55087F83), blurRadius: 14, offset: Offset(0, 6))],
                        border: Border.all(color: Pal.surface, width: 3),
                      ),
                      child: Icon(ic('plus'), size: 30, color: Colors.white),
                    ),
                  ),
                ),
              ),
            ),
          ),
          _item(3, tab, 'scale', bi('કાંટો', 'Kanta'), () => app.go('kanta', root: true)),
          if (admin)
            _item(4, tab, 'cmp', bi('મેળ', 'Match'), () => app.go('mel', root: true))
          else
            _item(4, tab, 'bag', bi('માલ', 'Maal'), () => app.go('maal', root: true)),
        ],
      ),
    );
  }
}
