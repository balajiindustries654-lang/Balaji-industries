import '../core/flags.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/app_state.dart';
import '../core/device.dart';
import '../core/i18n.dart';
import '../core/palette.dart';
import '../data/live_models.dart';
import '../data/live_store.dart';
import '../features/live/hisab.dart' show openCalcSheet;
import '../features/live/login.dart';
import '../features/tools.dart';
import '../widgets/accept.dart';
import '../widgets/common.dart';
import '../widgets/keys.dart';
import 'cmdk.dart';
import 'pc_shell.dart';
import 'phone_shell.dart';
import 'tally_shell.dart';
import 'widgets.dart';

/// The Tally skin is only for the PC layout; decided here so the theme is right on the first frame.
void _syncSkin() {
  final ViewMode m = app.viewMode;
  bool pc = m == ViewMode.pc;
  if (m == ViewMode.auto) {
    final views = WidgetsBinding.instance.platformDispatcher.views;
    if (views.isNotEmpty) pc = views.first.physicalSize.width / views.first.devicePixelRatio >= 1000;
  }
  Pal.tally = pc && app.tallyMode;
}

/// Root widget: theme + messenger, rebuilt whenever the global state changes.
class AppRoot extends StatelessWidget {
  const AppRoot({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: app,
      builder: (BuildContext context, Widget? child) {
        _syncSkin();
        return MaterialApp(
          title: 'Balaji Pro',
          debugShowCheckedModeBanner: false,
          theme: buildTheme(),
          scaffoldMessengerKey: app.messengerKey,
          home: Host(),
        );
      },
    );
  }
}

/// Top strip (Phone / PC / Auto switch) + the stage that hosts the app.
class Host extends StatefulWidget {
  Host({super.key});

  @override
  State<Host> createState() => _HostState();
}

class _HostState extends State<Host> {
  final GlobalKey<NavigatorState> _nav = GlobalKey<NavigatorState>();
  late final Widget _navigator = Navigator(
    key: _nav,
    onGenerateRoute: (RouteSettings s) => MaterialPageRoute<void>(settings: s, builder: (BuildContext c) => AppShell()),
  );

  @override
  void initState() {
    super.initState();
    HardwareKeyboard.instance.addHandler(_onKey);
  }

  @override
  void dispose() {
    HardwareKeyboard.instance.removeHandler(_onKey);
    super.dispose();
  }

  // ---------------------------------------------------------------- keys
  bool _editingText() {
    final BuildContext? c = FocusManager.instance.primaryFocus?.context;
    if (c == null) return false;
    return c.findAncestorWidgetOfExactType<EditableText>() != null;
  }

  /// Esc on a full-screen entry form: leave it (asks first when something was typed and not saved).
  Future<void> _leaveForm(NavigatorState nav, BuildContext ctx) async {
    final BuildContext? fc = FocusManager.instance.primaryFocus?.context;
    final KeyScopeState? ks = fc?.findAncestorStateOfType<KeyScopeState>();
    if (ks != null && ks.typed) {
      final bool ok = await askLeave(nav.overlay?.context ?? ctx);
      if (!ok) return;
    }
    if (app.canBack) {
      app.back();
    } else if (app.current != 'dashboard') {
      app.go('dashboard', root: true);
    }
  }

  bool _onKey(KeyEvent e) {
    if (e is! KeyDownEvent) return false;
    if (!app.stagePc || app.locked) return false;
    // Ctrl + A (Tally look) or Ctrl + Enter = Accept the voucher form that is open
    final HardwareKeyboard acc = HardwareKeyboard.instance;
    if (AcceptHub.has && (acc.isControlPressed || acc.isMetaPressed)) {
      final LogicalKeyboardKey ak = e.logicalKey;
      if (ak == LogicalKeyboardKey.enter || ak == LogicalKeyboardKey.numpadEnter || (Pal.tally && ak == LogicalKeyboardKey.keyA)) {
        AcceptHub.run();
        return true;
      }
    }
    // Alt + D delete the open voucher, Ctrl / Alt + P print and Alt + E export the open voucher or report
    final bool altOn = acc.isAltPressed;
    final bool ctlOn = acc.isControlPressed || acc.isMetaPressed;
    final LogicalKeyboardKey hubKey = e.logicalKey;
    if (altOn && !ctlOn && hubKey == LogicalKeyboardKey.keyD && deleteHub.run()) return true;
    if (Pal.tally && (altOn || ctlOn) && hubKey == LogicalKeyboardKey.keyP && printHub.run()) return true;
    if (Pal.tally && altOn && !ctlOn && hubKey == LogicalKeyboardKey.keyE && exportHub.run()) return true;
    final NavigatorState? nav = _nav.currentState;
    final BuildContext? ctx = _nav.currentContext;
    if (nav == null || ctx == null || nav.canPop()) return false;
    final LogicalKeyboardKey k = e.logicalKey;
    if (k == LogicalKeyboardKey.escape) {
      if (AcceptHub.has) {
        _leaveForm(nav, ctx);
        return true;
      }
      if (_editingText()) {
        FocusManager.instance.primaryFocus?.unfocus();
        return true;
      }
      if (app.canBack) {
        app.back();
        return true;
      }
      if (Pal.tally && app.current != 'dashboard') {
        app.go('dashboard', root: true);
        return true;
      }
      return false;
    }
    // Down / Up while the cursor is outside the screen: step into the first (last) row, like a Tally list
    if ((k == LogicalKeyboardKey.arrowDown || k == LogicalKeyboardKey.arrowUp) && !_editingText()) {
      final BuildContext? fc = FocusManager.instance.primaryFocus?.context;
      final bool inside = fc != null && fc.findAncestorStateOfType<KeyScopeState>() != null;
      final KeyScopeState? ks = KeyScopeState.current;
      if (!inside && ks != null) {
        // later in the same turn than the default arrow-key handling, so this choice wins
        final bool fromEnd = k == LogicalKeyboardKey.arrowUp;
        scheduleMicrotask(() => ks.focusFirstRow(last: fromEnd));
        return true;
      }
    }
    if (Pal.tally && tallyOnKey(k, editing: _editingText())) return true;
    final HardwareKeyboard hk = HardwareKeyboard.instance;
    if (!(hk.isControlPressed || hk.isMetaPressed)) {
      if (k == LogicalKeyboardKey.slash && !hk.isShiftPressed && !hk.isAltPressed && !_editingText()) {
        if (focusSearchField()) return true;
      }
      if (k == LogicalKeyboardKey.slash && hk.isShiftPressed && !_editingText()) {
        if (Pal.tally) {
          tallyShowKeys();
        } else {
          app.go('shortcuts');
        }
        return true;
      }
      return false;
    }
    if (k == LogicalKeyboardKey.keyF) {
      return focusSearchField();
    } else if (k == LogicalKeyboardKey.keyK) {
      showCommandPalette(ctx);
    } else if (k == LogicalKeyboardKey.keyN) {
      app.go('chithi_new');
    } else if (k == LogicalKeyboardKey.keyH) {
      openCalcSheet(nav.overlay?.context ?? ctx);
    } else if (k == LogicalKeyboardKey.digit4) {
      app.go('kanta', root: true);
    } else if (k == LogicalKeyboardKey.digit5) {
      app.go('alerts', root: true);
    } else if (k == LogicalKeyboardKey.digit6) {
      if (screenOn('analytics')) app.go('analytics', root: true);
    } else if (k == LogicalKeyboardKey.digit7) {
      if (screenOn('live_board')) app.go('live_board', root: true);
    } else if (k == LogicalKeyboardKey.keyT) {
      app.go('transit', root: true);
    } else if (k == LogicalKeyboardKey.keyS) {
      app.go('scan');
    } else if (k == LogicalKeyboardKey.keyP) {
      app.go('parties');
    } else if (k == LogicalKeyboardKey.keyE) {
      if (screenOn('export')) app.go('export');
    } else if (k == LogicalKeyboardKey.digit1) {
      app.go('dashboard', root: true);
    } else if (k == LogicalKeyboardKey.digit2) {
      app.go('chithi', root: true);
    } else if (k == LogicalKeyboardKey.digit3) {
      app.go('mel', root: true);
    } else if (k == LogicalKeyboardKey.equal || k == LogicalKeyboardKey.add || k == LogicalKeyboardKey.numpadAdd) {
      app.nudgeZoom(0.05);
    } else if (k == LogicalKeyboardKey.minus || k == LogicalKeyboardKey.numpadSubtract) {
      app.nudgeZoom(-0.05);
    } else if (k == LogicalKeyboardKey.digit0 || k == LogicalKeyboardKey.numpad0) {
      app.resetPcZoom();
    } else if (k == LogicalKeyboardKey.keyB) {
      app.toggleSidebar();
    } else if (k == LogicalKeyboardKey.keyD) {
      app.toggleDark();
    } else if (k == LogicalKeyboardKey.keyL) {
      app.toggleLang();
    } else {
      return false;
    }
    return true;
  }

  // ------------------------------------------------------------ back button
  void _onBack() {
    final NavigatorState? nav = _nav.currentState;
    if (nav != null && nav.canPop()) {
      nav.pop();
      return;
    }
    if (app.locked) {
      SystemNavigator.pop();
      return;
    }
    if (app.canBack) {
      app.back();
      return;
    }
    if (app.current != 'dashboard') {
      app.go('dashboard', root: true);
      return;
    }
    SystemNavigator.pop();
  }

  // ------------------------------------------------------------------ stage
  Widget _stage(MediaQueryData mq, BoxConstraints box) {
    final double w = box.maxWidth;
    final double h = box.maxHeight;
    if (w <= 0 || h <= 0) return const SizedBox.shrink();
    final ViewMode m = app.viewMode;
    bool pc;
    bool framed = false;
    bool zoomed = false;
    double zoom = 1.0;
    double lw;
    double lh;
    if (m == ViewMode.pc || (m == ViewMode.auto && w >= 1000)) {
      pc = true;
      if (w >= 1000) {
        // PC zoom: lay the app out on a bigger virtual stage and scale it down, so everything is denser.
        // The virtual stage is never narrower than 1000.
        if (app.pcZoomAuto) app.pcZoom = (!app.tallyMode && mq.devicePixelRatio >= 1.25) ? 0.85 : 1.0;
        double z = app.pcZoom;
        final double zMax = w / 1000;
        if (z > zMax) z = zMax;
        if ((z - 1).abs() < 0.005) z = 1.0;
        zoom = z;
        zoomed = z != 1.0;
        lw = w / z;
        lh = h / z;
      } else {
        lw = 1280;
        lh = h * 1280 / w;
      }
    } else {
      pc = false;
      if (m == ViewMode.phone && w > 560) {
        framed = true;
        lw = 390;
        lh = 844;
      } else {
        lw = w;
        lh = h;
      }
    }
    app.stagePc = pc;
    app.zoomEff = zoom;
    Pal.tally = pc && app.tallyMode;

    final bool real = !framed && lw == w;
    final MediaQueryData data = real
        ? mq.copyWith(
            size: Size(lw, lh),
            padding: mq.padding.copyWith(top: 0),
            viewPadding: mq.viewPadding.copyWith(top: 0),
          )
        : mq.copyWith(
            size: Size(lw, lh),
            padding: EdgeInsets.zero,
            viewPadding: EdgeInsets.zero,
            viewInsets: EdgeInsets.zero,
          );

    final Widget fitted = FittedBox(
        fit: zoomed ? BoxFit.contain : BoxFit.scaleDown,
        child: Container(
          width: framed ? lw + 24 : lw,
          height: framed ? lh + 24 : lh,
          padding: EdgeInsets.all(framed ? 12 : 0),
          decoration: BoxDecoration(
            color: framed ? const Color(0xFF0E1A1C) : Colors.transparent,
            borderRadius: BorderRadius.circular(framed ? 46 : 0),
            boxShadow: framed ? const <BoxShadow>[BoxShadow(color: Color(0x66000000), blurRadius: 30, offset: Offset(0, 12))] : null,
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(framed ? 34 : 0),
            child: MediaQuery(
              data: data.copyWith(textScaler: TextScaler.linear(app.textScale)),
              child: DeviceScope(pc: pc, width: lw, height: lh, child: _navigator),
            ),
          ),
        ),
    );
    // zoomed: the box is exactly the window size, so the FittedBox scales the virtual stage up or down to fill it
    return Center(child: zoomed ? SizedBox(width: w, height: h, child: fitted) : fitted);
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: app,
      builder: (BuildContext context, Widget? child) {
        final MediaQueryData mq = MediaQuery.of(context);
        return PopScope(
          canPop: false,
          onPopInvokedWithResult: (bool didPop, Object? result) {
            if (!didPop) _onBack();
          },
          child: Material(
            color: Pal.strip,
            child: Column(
              children: <Widget>[
                // TallyPrime has no strip of its own: the look / phone-PC / language switches sit in its menus and in Settings
                if (!Pal.tally) _TopStrip(top: mq.padding.top),
                Expanded(child: LayoutBuilder(builder: (BuildContext c, BoxConstraints box) => _stage(mq, box))),
              ],
            ),
          ),
        );
      },
    );
  }
}

// --------------------------------------------------------------- top strip
class _TopStrip extends StatelessWidget {
  final double top;
  const _TopStrip({required this.top});

  @override
  Widget build(BuildContext context) {
    // Slim bar: the brand already sits in the app's own header, so it is not repeated here.
    return Container(
      height: 44 + top,
      padding: EdgeInsets.fromLTRB(10, top, 4, 0),
      color: Pal.strip,
      child: LayoutBuilder(
        builder: (BuildContext c, BoxConstraints box) {
          final bool narrow = box.maxWidth < 520;
          return Row(
            children: <Widget>[
              ModeSwitch(compact: narrow),
              const Spacer(),
              if (app.stagePc && !narrow)
                Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(8),
                    onTap: () => app.setTally(!app.tallyMode),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                      decoration: BoxDecoration(border: Border.all(color: const Color(0x66FFFFFF)), borderRadius: BorderRadius.circular(8)),
                      child: Text(
                        app.tallyMode ? bi('દેખાવ: Tally Prime', 'Look: Tally Prime') : bi('દેખાવ: Modern → Tally', 'Look: Modern → Tally'),
                        style: ts(12.5, w: FontWeight.w800, c: Pal.sideText),
                      ),
                    ),
                  ),
                ),
              if (app.pinOn) IconBtn('lock', size: 38, color: Pal.sideText, onTap: app.lock, tip: bi('લોક', 'Lock')),
              IconBtn('lang', size: 38, color: Pal.sideText, onTap: app.toggleLang, tip: 'Ctrl L'),
              IconBtn(app.dark ? 'sun' : 'moon', size: 38, color: Pal.sideText, onTap: app.toggleDark, tip: 'Ctrl D'),
            ],
          );
        },
      ),
    );
  }
}

// ----------------------------------------------------------- app shell
/// Content of the stage: phone or PC shell, plus the PIN lock overlay.
class AppShell extends StatelessWidget {
  AppShell({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge(<Listenable>[app, live]),
      builder: (BuildContext context, Widget? child) {
        if (live.booting) return const SplashScreen();
        if (!live.signedIn) return const LoginScreen();
        final Profile? me = live.me;
        if (me == null || !me.approved || me.isFarmer) return const BlockedScreen();
        final bool pc = DeviceScope.isPc(context);
        return Stack(
          children: <Widget>[
            Positioned.fill(child: pc ? (Pal.tally ? TallyShell() : PcShell()) : PhoneShell()),
            if (app.locked) Positioned.fill(child: Material(color: Pal.bg, child: LockScreen())),
          ],
        );
      },
    );
  }
}
