import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/device.dart';
import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/palette.dart';
import '../data/mock_db.dart';
import '../data/models.dart';
import '../widgets/common.dart';
import '../widgets/datagrid.dart';
import '../widgets/page.dart';
import 'entries.dart';
import 'tally.dart';

MockDb get _db => MockDb.I;

// ------------------------------------------------------------- party picker
void showPartyPicker(BuildContext context, List<Party> list, ValueChanged<Party> onPick, {VoidCallback? allowNone}) {
  openPanel(
    context,
    title: bi('પસંદ કરો', 'Choose'),
    width: 440,
    child: _PickerBody(list: list, onPick: onPick, allowNone: allowNone),
  );
}

class _PickerBody extends StatefulWidget {
  final List<Party> list;
  final ValueChanged<Party> onPick;
  final VoidCallback? allowNone;
  const _PickerBody({required this.list, required this.onPick, this.allowNone});

  @override
  State<_PickerBody> createState() => _PickerBodyState();
}

class _PickerBodyState extends State<_PickerBody> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final String q = _q.trim().toLowerCase();
    final List<Party> l = widget.list.where((Party p) => q.isEmpty || p.name.toLowerCase().contains(q) || p.village.toLowerCase().contains(q)).toList();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        SearchBox(hint: bi('નામ કે ગામ…', 'Name or village…'), onChanged: (String v) => setState(() => _q = v)),
        const SizedBox(height: 10),
        if (widget.allowNone != null)
          _PartyTile(
            name: bi('કોઈ નહીં', 'None'),
            sub: '',
            onTap: () {
              Navigator.of(context).pop();
              widget.allowNone!();
            },
          ),
        for (final Party p in l)
          _PartyTile(
            name: p.name,
            sub: '${p.village} · ${p.phone}',
            onTap: () {
              Navigator.of(context).pop();
              widget.onPick(p);
            },
          ),
        if (l.isEmpty) EmptyBox(title: bi('કોઈ મળ્યું નથી', 'Nothing found')),
      ],
    );
  }
}

class _PartyTile extends StatelessWidget {
  final String name;
  final String sub;
  final String? trailing;
  final String? trailingSub;
  final Color? trailingColor;
  final VoidCallback onTap;
  const _PartyTile({required this.name, required this.sub, required this.onTap, this.trailing, this.trailingSub, this.trailingColor});

  @override
  Widget build(BuildContext context) {
    return Surface(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      onTap: onTap,
      child: Row(
        children: <Widget>[
          Avatar(name, size: 42),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14.5, w: FontWeight.w800)),
                if (sub.isNotEmpty) Text(sub, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12, c: Pal.muted)),
              ],
            ),
          ),
          if (trailing != null)
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Text(trailing!, style: ts(15, w: FontWeight.w800, c: trailingColor, tab: true)),
                if (trailingSub != null) Text(trailingSub!, style: ts(11.5, c: Pal.muted)),
              ],
            ),
        ],
      ),
    );
  }
}

// ----------------------------------------------------------------- reminder
void showReminder(BuildContext context, Party p, double amount) {
  final String text = bi(
    'નમસ્તે ${p.name}, તમારું ${inr(amount)} બાકી છે. કૃપા કરીને ચૂકવણી કરશો. આભાર 🙏',
    'Hello ${p.name}, ${inr(amount)} is pending from your side. Kindly arrange the payment. Thank you 🙏',
  );
  openPanel(
    context,
    title: bi('રિમાઇન્ડર', 'Reminder'),
    sub: '${p.name} · ${p.phone}',
    width: 440,
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Surface(color: Pal.soft, border: false, shadow: false, padding: const EdgeInsets.all(14), child: Text(text, style: ts(14.5, h: 1.45))),
        const SizedBox(height: 14),
        Btn(bi('લખાણ કૉપિ', 'Copy text'), icon: 'copy', expand: true, onTap: () => copyText(text)),
        const SizedBox(height: 8),
        Btn(bi('ફોન નંબર કૉપિ', 'Copy phone'), icon: 'call', kind: BtnKind.tonal, expand: true, onTap: () => copyText(p.phone, msg: bi('નંબર કૉપિ થયો', 'Number copied'))),
      ],
    ),
  );
}

// -------------------------------------------------------------- party lists
class PartiesScreen extends StatefulWidget {
  final String kind; // farmer | broker | buyer
  const PartiesScreen(this.kind, {super.key});

  @override
  State<PartiesScreen> createState() => _PartiesScreenState();
}

class _Row {
  final Party p;
  final int n;
  final double kg;
  final double value;
  final double bal;
  final DateTime? last;
  _Row(this.p, this.n, this.kg, this.value, this.bal, this.last);
}

class _PartiesScreenState extends State<PartiesScreen> {
  String _q = '';
  int _sort = 0;
  int _shown = 30;

  List<_Row> _rows() {
    final List<_Row> out = <_Row>[];
    if (widget.kind == 'farmer') {
      final Map<int, List<double>> m = <int, List<double>>{};
      final Map<int, DateTime> last = <int, DateTime>{};
      for (final Entry e in _db.entries) {
        final List<double> x = m.putIfAbsent(e.farmer.id, () => <double>[0, 0, 0, 0]);
        x[0] += 1;
        x[1] += e.net;
        x[2] += e.amount;
        x[3] += e.due;
        last.putIfAbsent(e.farmer.id, () => e.dt);
      }
      for (final Party p in _db.farmers) {
        final List<double> x = m[p.id] ?? <double>[0, 0, 0, 0];
        out.add(_Row(p, x[0].toInt(), x[1], x[2], x[3], last[p.id]));
      }
    } else if (widget.kind == 'broker') {
      final Map<int, List<double>> m = <int, List<double>>{};
      final Map<int, DateTime> last = <int, DateTime>{};
      for (final Entry e in _db.entries) {
        if (e.broker == null) continue;
        final List<double> x = m.putIfAbsent(e.broker!.id, () => <double>[0, 0, 0, 0]);
        x[0] += 1;
        x[1] += e.net;
        x[2] += e.amount;
        x[3] += e.commission;
        last.putIfAbsent(e.broker!.id, () => e.dt);
      }
      for (final Party p in _db.brokers) {
        final List<double> x = m[p.id] ?? <double>[0, 0, 0, 0];
        out.add(_Row(p, x[0].toInt(), x[1], x[2], x[3], last[p.id]));
      }
    } else {
      for (final Party p in _db.buyers) {
        double sales = 0;
        int n = 0;
        double kg = 0;
        for (final Voucher v in _db.vouchers) {
          if (v.party == p.name && v.type == 'Sales') {
            sales += v.total;
            n++;
            kg += v.kg;
          }
        }
        out.add(_Row(p, n, kg, sales, _db.buyerBalance(p), _db.lastVoucherOf(p.name, 'Sales')));
      }
    }
    return out;
  }

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    final String kind = widget.kind;
    final String title = kind == 'farmer' ? bi('ખેડૂત ખાતા', 'Farmers') : (kind == 'broker' ? bi('દલાલ ખાતા', 'Brokers') : bi('ખરીદદાર ખાતા', 'Buyers'));
    final String balLabel = kind == 'farmer' ? bi('બાકી ચૂકવવાના', 'Payable') : (kind == 'broker' ? bi('દલાલી', 'Commission') : bi('બાકી લેવાના', 'Receivable'));
    final String valLabel = kind == 'buyer' ? bi('કુલ વેચાણ', 'Total sales') : bi('કુલ રકમ', 'Total value');

    final String q = _q.trim().toLowerCase();
    final List<_Row> rows = _rows().where((_Row r) => q.isEmpty || r.p.name.toLowerCase().contains(q) || r.p.village.toLowerCase().contains(q) || r.p.phone.contains(q)).toList();
    if (_sort == 0) {
      rows.sort((_Row a, _Row b) => b.bal.compareTo(a.bal));
    } else if (_sort == 1) {
      rows.sort((_Row a, _Row b) => b.value.compareTo(a.value));
    } else {
      rows.sort((_Row a, _Row b) => a.p.name.compareTo(b.p.name));
    }
    double totBal = 0, totVal = 0;
    for (final _Row r in rows) {
      totBal += r.bal;
      totVal += r.value;
    }

    final Widget search = SearchBox(hint: bi('નામ, ગામ, ફોન…', 'Name, village, phone…'), width: pc ? 300 : null, onChanged: (String v) => setState(() {
          _q = v;
          _shown = 30;
        }));
    final Widget sort = Seg(
      dense: true,
      labels: <String>[balLabel, valLabel, bi('નામ', 'Name')],
      index: _sort,
      onChanged: (int i) => setState(() => _sort = i),
    );

    final Widget summary = pc
        ? Grid(cols: 3, gap: 12, children: <Widget>[
            KpiCard(label: bi('કુલ ખાતા', 'Accounts'), value: '${rows.length}', icon: kind == 'farmer' ? 'agri' : (kind == 'broker' ? 'handshake' : 'store'), tone: kind == 'farmer' ? 'green' : (kind == 'broker' ? 'violet' : 'blue')),
            KpiCard(label: valLabel, value: inrC(totVal), icon: 'rupee', tone: 'teal'),
            KpiCard(label: balLabel, value: inrC(totBal), icon: kind == 'buyer' ? 'ul' : 'dl', tone: kind == 'buyer' ? 'green' : 'rose'),
          ])
        : Surface(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            child: Row(
              children: <Widget>[
                _mini(bi('ખાતા', 'Accounts'), '${rows.length}', Pal.ink),
                _mini(valLabel, inrC(totVal), Pal.ink),
                _mini(balLabel, inrC(totBal), kind == 'buyer' ? Pal.ok : Pal.bad),
              ],
            ),
          );

    Widget body;
    if (rows.isEmpty) {
      body = EmptyBox(title: bi('કોઈ ખાતું નથી', 'No accounts'));
    } else if (pc) {
      final GridData g = GridData(<Col>[
        Col(bi('નામ', 'Name'), CK.text, w: 240, bold: true),
        Col(bi('ગામ', 'Village'), CK.text, w: 130),
        Col(bi('ફોન', 'Phone'), CK.text, w: 130),
        Col(kind == 'buyer' ? bi('બિલ', 'Invoices') : bi('એન્ટ્રી', 'Entries'), CK.count, w: 90),
        Col('KG', CK.kg, w: 120),
        Col(valLabel, CK.money, w: 140),
        Col(balLabel, CK.money, w: 140, main: true),
        Col(bi('છેલ્લે', 'Last'), CK.date, w: 120),
      ], <List<Object?>>[
        for (final _Row r in rows) <Object?>[r.p.name, r.p.village, r.p.phone, r.n, r.kg, r.value, r.bal, r.last],
      ]);
      body = Panel(
        flush: true,
        title: title,
        child: DataGridX(data: g, pageSize: 14, onRow: (int i) => app.go('party', arg: rows[i].p)),
      );
    } else {
      final int count = rows.length > _shown ? _shown : rows.length;
      body = Column(
        children: <Widget>[
          for (int i = 0; i < count; i++)
            _PartyTile(
              name: rows[i].p.name,
              sub: kind == 'buyer' ? '${rows[i].n} ${bi('બિલ', 'invoices')} · ${tons(rows[i].kg)}' : '${rows[i].p.village} · ${rows[i].n} ${bi('એન્ટ્રી', 'entries')}',
              trailing: rows[i].bal > 0.5 ? inrC(rows[i].bal) : '–',
              trailingSub: balLabel,
              trailingColor: rows[i].bal > 0.5 ? (kind == 'buyer' ? Pal.ok : Pal.bad) : Pal.faint,
              onTap: () => app.go('party', arg: rows[i].p),
            ),
          if (rows.length > count)
            Btn(bi('વધુ બતાવો (${rows.length - count})', 'Show more (${rows.length - count})'), kind: BtnKind.tonal, expand: true, onTap: () => setState(() => _shown += 30)),
        ],
      );
    }

    return ScreenScroll(
      children: <Widget>[
        ScreenHeader(title, actions: <Widget>[sort, search]),
        if (!pc) ...<Widget>[search, const SizedBox(height: 10), sort, const SizedBox(height: 12)],
        summary,
        const SizedBox(height: 12),
        body,
      ],
    );
  }

  Widget _mini(String l, String v, Color c) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(l, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(11.5, c: Pal.muted, w: FontWeight.w600)),
          const SizedBox(height: 2),
          FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(v, style: ts(16, w: FontWeight.w800, c: c, tab: true))),
        ],
      ),
    );
  }
}

// -------------------------------------------------------------- party detail
class PartyScreen extends StatelessWidget {
  final Object? arg;
  const PartyScreen(this.arg, {super.key});

  @override
  Widget build(BuildContext context) {
    final Object? a = arg;
    if (a is! Party) return ScreenScroll(children: <Widget>[EmptyBox(title: bi('ખાતું મળ્યું નથી', 'Account not found'))]);
    final Party p = a;
    final bool pc = DeviceScope.isPc(context);

    final String kindName = p.kind == 'farmer' ? bi('ખેડૂત', 'Farmer') : (p.kind == 'broker' ? bi('દલાલ', 'Broker') : bi('ખરીદદાર', 'Buyer'));
    final String tone = p.kind == 'farmer' ? 'green' : (p.kind == 'broker' ? 'violet' : 'blue');

    // ---- numbers
    List<KpiSpec2> kpis;
    Widget history;
    double reminderAmt = 0;
    String statement = '';
    if (p.kind == 'farmer') {
      final List<Entry> l = _db.entriesOfFarmer(p);
      double kg = 0, amt = 0, paid = 0;
      for (final Entry e in l) {
        kg += e.net;
        amt += e.amount;
        paid += e.paid;
      }
      reminderAmt = amt - paid;
      kpis = <KpiSpec2>[
        KpiSpec2(bi('કુલ ખરીદી', 'Total purchase'), inrC(amt), 'rupee', 'teal'),
        KpiSpec2(bi('ચૂકવેલ', 'Paid'), inrC(paid), 'check', 'green'),
        KpiSpec2(bi('બાકી', 'Due'), inrC(amt - paid), 'clock', 'rose'),
        KpiSpec2(bi('વજન', 'Weight'), tons(kg), 'scale', 'amber'),
      ];
      statement = <String>[
        bi('નમસ્તે ${p.name},', 'Hello ${p.name},'),
        bi('તમારો હિસાબ:', 'Your statement:'),
        for (final Entry e in l.take(8)) '${dm(e.dt)} · #${e.no} · ${grp(e.net)} KG · ${inr(e.amount)}',
        bi('કુલ: ${inr(amt)} · ચૂકવેલ: ${inr(paid)} · બાકી: ${inr(amt - paid)}', 'Total: ${inr(amt)} · Paid: ${inr(paid)} · Balance: ${inr(amt - paid)}'),
        bi('આભાર 🙏', 'Thank you 🙏'),
      ].join('\n');
      final GridData g = GridData(<Col>[
        Col(bi('ચિઠ્ઠી', 'Slip'), CK.text, w: 90, bold: true),
        Col(bi('તારીખ', 'Date'), CK.date, w: 120),
        Col(bi('ગ્રેડ', 'Grade'), CK.text, w: 90),
        Col(bi('ચોખ્ખું KG', 'Net KG'), CK.kg, w: 110),
        Col(bi('રકમ', 'Amount'), CK.money, w: 120, main: true),
        Col(bi('બાકી', 'Due'), CK.money, w: 110),
        Col(bi('સ્થિતિ', 'Status'), CK.status, w: 100),
      ], <List<Object?>>[
        for (final Entry e in l) <Object?>['#${e.no}', e.dt, gradeName(e.g, shortName: true), e.net, e.amount, e.due, e.status],
      ]);
      history = DataGridX(data: g, pageSize: 10, onRow: (int i) => showEntryDetail(context, l[i]));
    } else if (p.kind == 'broker') {
      final List<Entry> l = _db.entries.where((Entry e) => e.broker != null && e.broker!.id == p.id).toList();
      double kg = 0, comm = 0, amt = 0;
      for (final Entry e in l) {
        kg += e.net;
        comm += e.commission;
        amt += e.amount;
      }
      kpis = <KpiSpec2>[
        KpiSpec2(bi('એન્ટ્રી', 'Entries'), '${l.length}', 'list', 'blue'),
        KpiSpec2(bi('વજન', 'Weight'), tons(kg), 'scale', 'amber'),
        KpiSpec2(bi('માલની કિંમત', 'Goods value'), inrC(amt), 'rupee', 'teal'),
        KpiSpec2(bi('દલાલી', 'Commission'), inrC(comm), 'pct', 'violet'),
      ];
      final GridData g = GridData(<Col>[
        Col(bi('ખેડૂત', 'Farmer'), CK.text, w: 200, bold: true),
        Col(bi('ચિઠ્ઠી', 'Slip'), CK.text, w: 90),
        Col(bi('તારીખ', 'Date'), CK.date, w: 120),
        Col(bi('ચોખ્ખું KG', 'Net KG'), CK.kg, w: 110),
        Col(bi('દલાલી', 'Commission'), CK.money, w: 120, main: true),
      ], <List<Object?>>[
        for (final Entry e in l) <Object?>[e.farmer.name, '#${e.no}', e.dt, e.net, e.commission],
      ]);
      history = DataGridX(data: g, pageSize: 10, onRow: (int i) => showEntryDetail(context, l[i]));
    } else {
      final List<Voucher> l = _db.vouchers.where((Voucher v) => v.party == p.name).toList();
      double sales = 0, rec = 0;
      for (final Voucher v in l) {
        if (v.type == 'Sales') sales += v.total;
        if (v.type == 'Receipt') rec += v.amount;
      }
      final double bal = _db.buyerBalance(p);
      reminderAmt = bal;
      final double used = p.creditLimit > 0 ? bal / p.creditLimit * 100 : 0;
      kpis = <KpiSpec2>[
        KpiSpec2(bi('કુલ બાકી', 'Outstanding'), inrC(bal), 'ul', bal > 0 ? 'rose' : 'green'),
        KpiSpec2(bi('કુલ વેચાણ', 'Total sales'), inrC(sales), 'cart', 'teal'),
        KpiSpec2(bi('કુલ રસીદ', 'Received'), inrC(rec), 'dl', 'green'),
        KpiSpec2(bi('લિમિટ વપરાશ', 'Limit used'), pct(used, dec: 0), 'shield', used > 100 ? 'rose' : (used > 80 ? 'amber' : 'blue')),
      ];
      final GridData g = GridData(<Col>[
        Col(bi('વિગત', 'Particulars'), CK.text, w: 200, bold: true),
        Col(bi('વાઉચર', 'Voucher'), CK.text, w: 100),
        Col(bi('પ્રકાર', 'Type'), CK.status, w: 110),
        Col(bi('ફર્મ', 'Firm'), CK.text, w: 110),
        Col(bi('તારીખ', 'Date'), CK.date, w: 120),
        Col(bi('રકમ', 'Amount'), CK.money, w: 130, main: true),
      ], <List<Object?>>[
        for (final Voucher v in l) <Object?>[v.narration.isEmpty ? v.party : v.narration, v.no, v.type, v.firm.short, v.date, v.total],
      ]);
      history = DataGridX(data: g, pageSize: 10, onRow: (int i) => showVoucherDetail(context, l[i]));
    }

    final Widget head = Surface(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Avatar(p.name, size: 56),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(p.name, style: ts(pc ? 20 : 18, w: FontWeight.w800, ls: -0.3)),
                    const SizedBox(height: 4),
                    Wrap(spacing: 8, runSpacing: 4, children: <Widget>[
                      Pill(kindName, tone: tone, small: true),
                      Text('${p.village}  ·  ${p.phone}', style: ts(13, c: Pal.muted)),
                    ]),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <Widget>[
              Btn(bi('ફોન નંબર', 'Copy phone'), icon: 'call', dense: true, kind: BtnKind.tonal, onTap: () => copyText(p.phone, msg: bi('નંબર કૉપિ થયો', 'Number copied'))),
              if (p.kind == 'farmer')
                Btn(bi('હિસાબ લખાણ', 'Statement text'), icon: 'chat', dense: true, onTap: () => copyText(statement, msg: bi('હિસાબ કૉપિ થયો', 'Statement copied'))),
              if (p.kind == 'buyer' && reminderAmt > 0.5)
                Btn(bi('રિમાઇન્ડર', 'Reminder'), icon: 'alarm', dense: true, kind: BtnKind.amber, onTap: () => showReminder(context, p, reminderAmt)),
            ],
          ),
        ],
      ),
    );

    final Widget kpiGrid = Grid(
      cols: pc ? 4 : 2,
      gap: 12,
      children: <Widget>[
        for (final KpiSpec2 k in kpis)
          Surface(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: <Widget>[
                IconChip(k.icon, tone: k.tone, size: 40),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(k.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12, c: Pal.muted, w: FontWeight.w600)),
                      FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(k.value, style: ts(17, w: FontWeight.w800, tab: true, ls: -0.3))),
                    ],
                  ),
                ),
              ],
            ),
          ),
      ],
    );

    return ScreenScroll(
      maxWidth: 1200,
      children: <Widget>[
        head,
        const SizedBox(height: 12),
        kpiGrid,
        const SizedBox(height: 14),
        if (pc)
          Panel(flush: true, title: bi('વ્યવહાર', 'Transactions'), child: history)
        else ...<Widget>[SectionTitle(bi('વ્યવહાર', 'Transactions')), history],
      ],
    );
  }
}

class KpiSpec2 {
  final String label;
  final String value;
  final String icon;
  final String tone;
  const KpiSpec2(this.label, this.value, this.icon, this.tone);
}
