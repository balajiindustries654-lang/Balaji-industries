import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/device.dart';
import '../core/i18n.dart';
import '../core/icons.dart';
import '../core/palette.dart';
import '../data/live_store.dart';
import '../data/models.dart';
import '../widgets/common.dart';
import '../widgets/page.dart';
import 'registry.dart';

// ------------------------------------------------------------- feature tile
class FeatureTile extends StatelessWidget {
  final FeatureDef f;
  final bool showPin;
  const FeatureTile(this.f, {super.key, this.showPin = true});

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    final bool pinned = app.isFav(f.id);
    if (Pal.tally) {
      // TallyPrime menu line: only the name (the active line is yellow); a star shows a favourite
      return Material(
        color: Pal.surface,
        child: InkWell(
          onTap: () => app.go(f.id),
          hoverColor: Pal.soft,
          focusColor: Pal.focusFill,
          child: Container(
            padding: const EdgeInsets.fromLTRB(12, 5, 8, 5),
            decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Pal.line.withAlpha(110)))),
            child: Row(
              children: <Widget>[
                Expanded(child: Text(f.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(13.5, w: FontWeight.w700))),
                if (f.status != FStatus.live) Padding(padding: const EdgeInsets.only(right: 8), child: Text(statusText(f.statusKey), style: ts(11.5, w: FontWeight.w700, c: Pal.muted))),
                if (showPin)
                  InkWell(
                    onTap: () => app.toggleFav(f.id),
                    child: Padding(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1), child: Text(pinned ? '★' : '☆', style: ts(15, w: FontWeight.w700, c: pinned ? Pal.warn : Pal.faint))),
                  ),
              ],
            ),
          ),
        ),
      );
    }
    return Surface(
      padding: EdgeInsets.all(pc ? 14 : 12),
      onTap: () => app.go(f.id),
      child: Row(
        children: <Widget>[
          IconChip(f.icon, tone: f.tone, size: pc ? 42 : 40),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Text(f.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(pc ? 14 : 13.5, w: FontWeight.w800, h: 1.2)),
                if (f.status != FStatus.live) ...<Widget>[
                  const SizedBox(height: 4),
                  StatusPill(f.statusKey, small: true),
                ],
              ],
            ),
          ),
          if (showPin)
            InkWell(
              borderRadius: BorderRadius.circular(8),
              onTap: () => app.toggleFav(f.id),
              child: Padding(padding: const EdgeInsets.all(6), child: Icon(ic(pinned ? 'star' : 'staro'), size: 20, color: pinned ? Pal.amber : Pal.faint)),
            ),
        ],
      ),
    );
  }
}

/// The feature tiles of a group: a grid of cards, or (TallyPrime look) one ruled menu list.
Widget featureGrid(List<FeatureDef> l, bool pc, double maxWidth) {
  if (Pal.tally && pc) {
    return Align(
      alignment: Alignment.topLeft,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 560),
        child: Container(
          decoration: BoxDecoration(border: Border.all(color: Pal.line)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: <Widget>[for (final FeatureDef f in l) FeatureTile(f)]),
        ),
      ),
    );
  }
  final int cols = pc ? gridCols(maxWidth, min: 250, max: 5) : (maxWidth > 520 ? 3 : 2);
  return Grid(cols: cols, gap: 10, children: <Widget>[for (final FeatureDef f in l) FeatureTile(f)]);
}

// ---------------------------------------------------------------------- hub
class HubScreen extends StatefulWidget {
  const HubScreen({super.key});

  @override
  State<HubScreen> createState() => _HubScreenState();
}

class _HubScreenState extends State<HubScreen> {
  /// Groups left open. Kept for the whole run so coming back to the list shows it the way it was left.
  static final Set<String> _open = <String>{'biz'};
  static bool _allOpen = false;

  String _q = '';
  int _g = 0; // 0 = all
  int _st = 0; // 0 all, 1 live, 2 beta, 3 soon

  Widget _groupHead(GroupDef g, int count, bool open, bool canFold) {
    final Widget row = Row(
      children: <Widget>[
        IconChip(g.icon, tone: g.tone, size: 30),
        const SizedBox(width: 10),
        Expanded(child: Text(g.title, style: ts(15, w: FontWeight.w800))),
        Text('$count', style: ts(13, w: FontWeight.w700, c: Pal.faint)),
        if (canFold) ...<Widget>[
          const SizedBox(width: 6),
          Icon(ic(open ? 'up' : 'down'), size: 22, color: Pal.faint),
        ],
      ],
    );
    return Padding(
      padding: const EdgeInsets.fromLTRB(0, 10, 0, 6),
      child: canFold
          ? InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: () => setState(() {
                if (!_open.remove(g.id)) _open.add(g.id);
              }),
              child: Padding(padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 6), child: row),
            )
          : Padding(padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 6), child: row),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    final String q = _q.trim().toLowerCase();
    final bool admin = live.isAdmin;
    final List<GroupDef> vg = visibleGroups(admin);
    bool match(FeatureDef f) {
      if (!shownFor(f, admin)) return false;
      if (_g > 0 && f.group != vg[_g - 1].id) return false;
      if (_st == 1 && f.status != FStatus.live) return false;
      if (_st == 2 && f.status != FStatus.beta) return false;
      if (_st == 3 && f.status != FStatus.soon) return false;
      if (q.isNotEmpty && !('${f.gu} ${f.en} ${f.id}'.toLowerCase().contains(q))) return false;
      return true;
    }

    final List<Widget> body = <Widget>[];
    int total = 0;
    final List<FeatureDef> favList = <FeatureDef>[
      for (final String id in app.favs)
        if (featureById(id) != null && match(featureById(id)!)) featureById(id)!,
    ];
    if (favList.isNotEmpty && _g == 0 && q.isEmpty) {
      body.add(Padding(
        padding: const EdgeInsets.fromLTRB(2, 18, 2, 10),
        child: Row(
          children: <Widget>[
            const IconChip('star', tone: 'amber', size: 30),
            const SizedBox(width: 10),
            Text(bi('મનપસંદ', 'Favourites'), style: ts(15, w: FontWeight.w800)),
            const SizedBox(width: 8),
            Text('${favList.length}', style: ts(13, w: FontWeight.w700, c: Pal.faint)),
          ],
        ),
      ));
      body.add(LayoutBuilder(builder: (BuildContext context, BoxConstraints c) => featureGrid(favList, pc, c.maxWidth)));
    }
    // the screens used last (only when nothing is being searched or filtered)
    final bool plain = _g == 0 && q.isEmpty && _st == 0;
    final List<FeatureDef> recents = <FeatureDef>[];
    if (plain) {
      for (final String id in app.recent) {
        final FeatureDef? f = featureById(id);
        if (f != null && match(f) && !recents.contains(f)) recents.add(f);
        if (recents.length >= 6) break;
      }
    }
    if (recents.isNotEmpty) {
      body.add(Padding(
        padding: const EdgeInsets.fromLTRB(2, 16, 2, 10),
        child: Row(
          children: <Widget>[
            const IconChip('clock', tone: 'blue', size: 30),
            const SizedBox(width: 10),
            Text(bi('તાજેતરમાં વાપરેલા', 'Recently used'), style: ts(15, w: FontWeight.w800)),
          ],
        ),
      ));
      body.add(Wrap(
        spacing: 8,
        runSpacing: 8,
        children: <Widget>[
          for (final FeatureDef f in recents)
            Material(
              color: Pal.tally ? Pal.surface : Pal.soft,
              shape: Pal.tally ? Border.all(color: Pal.line) : null,
              borderRadius: Pal.tally ? null : BorderRadius.circular(99),
              child: InkWell(
                borderRadius: BorderRadius.circular(Pal.tally ? 0 : 99),
                onTap: () => app.go(f.id),
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: Pal.tally ? 4 : 9),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      if (!Pal.tally) Icon(ic(f.icon), size: 17, color: Pal.brand),
                      if (!Pal.tally) const SizedBox(width: 7),
                      Text(f.title, style: ts(13, w: FontWeight.w700, c: Pal.brand)),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ));
    }
    for (final GroupDef g in vg) {
      final List<FeatureDef> l = kFeatures.where((FeatureDef f) => f.group == g.id && match(f)).toList();
      if (l.isEmpty) continue;
      total += l.length;
      final bool canFold = plain;
      final bool open = !canFold || _allOpen || _open.contains(g.id);
      body.add(_groupHead(g, l.length, open, canFold));
      if (!open) continue;
      body.add(LayoutBuilder(builder: (BuildContext context, BoxConstraints c) => featureGrid(l, pc, c.maxWidth)));
    }

    final Widget search = SearchBox(hint: bi('ફીચર શોધો…', 'Search features…'), width: pc ? 320 : null, onChanged: (String v) => setState(() => _q = v));
    final Widget status = Seg(
      dense: true,
      labels: <String>[bi('બધા', 'All'), statusText('live'), statusText('beta'), statusText('soon')],
      index: _st,
      onChanged: (int i) => setState(() => _st = i),
    );

    return ScreenScroll(
      children: <Widget>[
        ScreenHeader(
          bi('બધા ફીચર', 'All features'),
          actions: <Widget>[status, search, Btn(bi('સેટિંગ્સ', 'Settings'), icon: 'gear', kind: BtnKind.tonal, onTap: () => app.go('settings'))],
        ),
        if (!pc) ...<Widget>[
          Row(children: <Widget>[Expanded(child: search), const SizedBox(width: 8), IconBtn('gear', bg: Pal.soft, color: Pal.brand, onTap: () => app.go('settings'))]),
          const SizedBox(height: 10),
          status,
          const SizedBox(height: 10),
        ],
        ChipRow(
          labels: <String>[bi('બધા', 'All'), for (final GroupDef g in vg) g.title],
          index: _g,
          onChanged: (int i) => setState(() => _g = i),
        ),
        if (plain)
          Align(
            alignment: Alignment.centerRight,
            child: Btn(
              _allOpen ? bi('બધા બંધ કરો', 'Collapse all') : bi('બધા ખોલો', 'Expand all'),
              icon: _allOpen ? 'up' : 'down',
              kind: BtnKind.ghost,
              dense: true,
              onTap: () => setState(() {
                _allOpen = !_allOpen;
                if (!_allOpen) _open.clear();
              }),
            ),
          ),
        if (total == 0) EmptyBox(title: bi('કોઈ ફીચર મળ્યું નથી', 'No features found')),
        ...body,
      ],
    );
  }
}

// -------------------------------------------------------------- group home
class GroupHomeScreen extends StatelessWidget {
  final String group;
  const GroupHomeScreen(this.group, {super.key});

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    final GroupDef g = groupOf(group);
    final List<FeatureDef> l = visibleIn(group, live.isAdmin);
    final List<Widget> head = <Widget>[];
    if (Pal.tally && pc) {
      return ScreenScroll(
        maxWidth: 560,
        children: <Widget>[
          ScreenHeader(g.title),
          featureGrid(l, pc, 560),
        ],
      );
    }
    return ScreenScroll(
      children: <Widget>[
        ScreenHeader(g.title),
        ...head,
        LayoutBuilder(builder: (BuildContext context, BoxConstraints c) {
          final int cols = pc ? gridCols(c.maxWidth, min: 250, max: 5) : (c.maxWidth > 520 ? 3 : 2);
          return Grid(cols: cols, gap: 10, children: <Widget>[for (final FeatureDef f in l) FeatureTile(f)]);
        }),
      ],
    );
  }
}

// ------------------------------------------------------------ roadmap card
class SoonScreen extends StatelessWidget {
  final String id;
  const SoonScreen(this.id, {super.key});

  @override
  Widget build(BuildContext context) {
    final FeatureDef? f = featureById(id);
    if (f == null) return ScreenScroll(children: <Widget>[EmptyBox(title: bi('મળ્યું નથી', 'Not found'))]);
    return ScreenScroll(
      maxWidth: 640,
      children: <Widget>[
        ScreenHeader(f.title),
        Surface(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: <Widget>[
              IconChip(f.icon, tone: f.tone, size: 72),
              const SizedBox(height: 16),
              Text(f.title, textAlign: TextAlign.center, style: ts(20, w: FontWeight.w800)),
              const SizedBox(height: 10),
              Text(f.desc, textAlign: TextAlign.center, style: ts(14, c: Pal.muted, h: 1.4)),
              const SizedBox(height: 16),
              StatusPill('soon'),
            ],
          ),
        ),
      ],
    );
  }
}

// ----------------------------------------------------------------- settings
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Widget _link(String icon, String tone, String title, String route) {
    return Surface(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      onTap: () => app.go(route),
      child: Row(
        children: <Widget>[
          IconChip(icon, tone: tone, size: 40),
          const SizedBox(width: 12),
          Expanded(child: Text(title, style: ts(14.5, w: FontWeight.w700))),
          Icon(ic('chev'), size: 20, color: Pal.faint),
        ],
      ),
    );
  }

  Widget _label(String t) => Padding(padding: const EdgeInsets.only(bottom: 8, top: 4), child: Text(t, style: ts(12.5, w: FontWeight.w700, c: Pal.muted)));

  @override
  Widget build(BuildContext context) {
    final Widget look = Panel(
      title: bi('દેખાવ', 'Appearance'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          _label(bi('થીમ', 'Theme')),
          Seg(labels: <String>[bi('લાઇટ', 'Light'), bi('ડાર્ક', 'Dark')], icons: const <String>['sun', 'moon'], index: app.dark ? 1 : 0, onChanged: (int i) => app.setDark(i == 1)),
          const SizedBox(height: 16),
          _label(bi('ભાષા', 'Language')),
          Seg(labels: const <String>['ગુજરાતી', 'English'], index: L.gu ? 0 : 1, onChanged: (int i) {
            if ((i == 0) != L.gu) app.toggleLang();
          }),
          const SizedBox(height: 16),
          _label(bi('વ્યૂ', 'View')),
          Seg(
            labels: <String>[bi('ઓટો', 'Auto'), bi('ફોન', 'Phone'), 'PC'],
            icons: const <String>['auto', 'phone', 'pc'],
            index: app.viewMode.index,
            onChanged: (int i) => app.setView(ViewMode.values[i]),
          ),
          const SizedBox(height: 16),
          _label(bi('ફર્મ', 'Company')),
          ChipRow(
            labels: <String>[bi('બધી', 'All'), for (final Firm f in Firm.values) f.short],
            index: app.firm == null ? 0 : app.firm!.index + 1,
            onChanged: (int i) => app.setFirm(i == 0 ? null : Firm.values[i - 1]),
          ),
        ],
      ),
    );
    final Widget links = Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        _link('sync', 'violet', bi('ટેલી કનેક્શન', 'Tally connection'), 'tally_sync'),
        _link('lock', 'rose', bi('PIN લોક', 'PIN lock'), 'pin_lock'),
        _link('backup', 'teal', bi('બેકઅપ', 'Backup'), 'backup'),
        _link('chat', 'green', bi('WhatsApp ટેમ્પલેટ', 'WhatsApp templates'), 'whatsapp_tpl'),
        _link('admin', 'slate', bi('યુઝર અને રોલ', 'Users & roles'), 'users'),
        _link('auto', 'slate', bi('ડિવાઇસ', 'Devices'), 'devices'),
        _link('keyboard', 'teal', bi('કીબોર્ડ શોર્ટકટ', 'Keyboard shortcuts'), 'shortcuts'),
      ],
    );
    return ScreenScroll(
      maxWidth: 1000,
      children: <Widget>[
        ScreenHeader(bi('સેટિંગ્સ', 'Settings')),
        SplitPane(children: <Widget>[look, links]),
      ],
    );
  }
}
