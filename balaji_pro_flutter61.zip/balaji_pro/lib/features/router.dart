import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/i18n.dart';
import '../core/palette.dart';
import '../data/engine.dart';
import '../data/trade.dart' show BuyerAcct, buyerAccts;
import '../widgets/common.dart';
import '../widgets/page.dart';
import 'hub.dart';
import 'live/audit.dart';
import 'live/backup_screen.dart';
import 'live/bank_screens.dart';
import 'live/debit_screens.dart';
import 'live/gst_screens.dart';
import 'live/kanta_auto_screen.dart';
import 'live/kanta_khata_screen.dart';
import 'live/kanta_remote_screen.dart';
import 'live/kanta_usb_screen.dart';
import 'live/trading_screens.dart';
import 'live/export_money.dart';
import 'live/fixes.dart';
import 'live/forms.dart';
import 'live/help.dart';
import 'live/home.dart';
import 'live/insight_screens.dart';
import 'live/lists.dart';
import 'live/mel.dart';
import 'live/money_screens.dart';
import 'live/money_screens2.dart';
import 'live/ops_screens.dart';
import 'live/settings.dart';
import 'live/graph_screens.dart';
import 'live/gstr_screens.dart';
import 'live/statement_screens.dart';
import 'live/trade_screens.dart';
import 'live/trade_screens2.dart';
import 'live/trade_screens3.dart';
import 'live/tools_screens.dart';
import 'live/biz_tools.dart';
import 'live/biz_tools2.dart';
import 'live/checks2.dart';
import 'live/insight2.dart';
import 'live/insight3.dart';
import 'live/scan.dart';
import 'live/tally_data.dart' show TallyDataScreen;
import 'live/transit.dart';
import 'live/value_screens.dart';
import 'live/voucher_screens.dart';
import 'registry.dart';
import 'tools.dart' show PinLockScreen, ShortcutsScreen;
import '../data/books.dart' show LedgerRef;
import '../data/insights.dart' show PartyRef;
import '../data/vouchers.dart' show registerName;
import '../data/scan.dart' show ScanPrefill;

/// Maps a route id to its screen. Every id of the feature list is routed.
Widget buildScreen(BuildContext context, String id, Object? arg) {
  final String? q = arg is String ? arg : null;
  switch (id) {
    case 'dashboard':
      return const BizHomeScreen();
    case 'biz_home':
      return const BizHomeScreen();
    case 'today':
      return const TodayScreen();
    case 'mel':
      return const MelScreen();
    case 'alerts':
      return const AuditScreen();
    case 'search':
      return const LiveSearchScreen();
    case 'chithi':
      return ChithiScreen(q: q);
    case 'chithi_new':
      return ChithiFormScreen(prefill: arg is ScanPrefill ? arg : null);
    case 'kanta':
      return KantaScreen(q: q);
    case 'kanta_new':
      return KantaFormScreen(prefill: arg is ScanPrefill ? arg : null, vehicle: q ?? '');
    case 'maal':
      return MaalScreen(q: q);
    case 'maal_new':
      return MaalFormScreen(prefill: arg is ScanPrefill ? arg : null);
    case 'daily':
      return const DailyScreen();
    case 'by_vehicle':
      return const GroupByScreen(Dim.vehicle);
    case 'by_farmer':
      return const GroupByScreen(Dim.farmer);
    case 'by_village':
      return const GroupByScreen(Dim.village);
    case 'by_broker':
      return const GroupByScreen(Dim.broker);
    case 'by_majur':
      return const GroupByScreen(Dim.majur);
    case 'by_commodity':
      return const GroupByScreen(Dim.commodity);
    case 'by_day':
      return const GroupByScreen(Dim.day);
    case 'missing_kanta':
      return const MelScreen(tab: 2);
    case 'missing_chit':
      return const MelScreen(tab: 3);
    case 'rst_gap':
      return const AuditScreen(rule: Rule.rstGap);
    case 'dups':
      return const AuditScreen(rule: Rule.dup);
    case 'no_photo':
      return const AuditScreen(rule: Rule.photo);
    case 'odd':
      return const AuditScreen(rule: Rule.odd);
    case 'patterns':
      return const AuditScreen(rule: Rule.pattern);
    case 'history':
      return const HistoryScreen();
    case 'settings':
      return const LiveSettingsScreen();
    case 'offline_queue':
      return const QueueScreen();
    case 'hub':
      return const HubScreen();
    case 'analytics':
      return const AnalyticsScreen();
    case 'compare':
      return const CompareScreen();
    case 'hourly':
      return const HourlyScreen();
    case 'turnaround':
      return const TurnaroundScreen();
    case 'risk':
      return const RiskScreen();
    case 'leaders':
      return const LeadersScreen();
    case 'ghat_trend':
      return const GhatTrendScreen();
    case 'range_report':
      return const RangeReportScreen();
    case 'live_board':
      return const LiveBoardScreen();
    case 'day_close':
      return const LiveDayCloseScreen();
    case 'feed':
      return const FeedScreen();
    case 'reviewed':
      return const ReviewedScreen();
    case 'staff':
      return const StaffScreen();
    case 'parties':
      return const PartyDirectoryScreen();
    case 'party':
      return PartyProfileScreen(arg is PartyRef ? arg : null);
    case 'table':
      return const TableViewScreen();
    case 'export':
      return const ExportScreen();
    case 'photo_wall':
      return const PhotoWallScreen();
    case 'calc':
      return const CalcScreen();
    case 'shortcuts':
      return const ShortcutsScreen();
    case 'pin_lock':
      return const PinLockScreen();
    case 'scan':
      return ScanScreen(kind: q ?? 'chit');
    case 'transit':
      return const TransitScreen();
    case 'arrivals':
      return const ArrivalsScreen();
    case 'weigh_check':
      return WeighCheckScreen(vehicle: q ?? '');
    case 'vehicle_lookup':
      return const VehicleLookupScreen();
    case 'my_day':
      return const MyDayScreen();
    case 'maal_stock':
      return const MaalStockScreen();
    case 'maal_cross':
      return const MaalCrossScreen();
    case 'rates':
      return const RatesScreen();
    case 'purchase':
      return const PurchaseScreen();
    case 'loss_value':
      return const LossValueScreen();
    case 'quality':
      return const QualityScreen();
    case 'bag_stats':
      return const BagStatsScreen();
    case 'deductions':
      return const DeductionsScreen();
    case 'digits':
      return const DigitsScreen();
    case 'plate_check':
      return const PlateCheckScreen();
    case 'name_check':
      return const NameCheckScreen();
    case 'chit_gaps':
      return const ChitGapsScreen();
    case 'rst_map':
      return const RstMapScreen();
    case 'late_entry':
      return const LateEntryScreen();
    case 'after_hours':
      return const AfterHoursScreen();
    case 'tolerance':
      return const ToleranceScreen();
    case 'calendar':
      return const CalendarScreen();
    case 'records':
      return const RecordsScreen();
    case 'forecast':
      return const ForecastScreen();
    case 'pace':
      return const PaceScreen();
    case 'loads':
      return const LoadsScreen();
    case 'idle_gaps':
      return const IdleGapsScreen();
    case 'cohort':
      return const CohortScreen();
    case 'farmer_due':
      return const FarmerDueScreen();
    case 'village_days':
      return const VillageDaysScreen();
    case 'fleet':
      return const FleetScreen();
    case 'majur_work':
      return const MajurWorkScreen();
    case 'party_compare':
      return const PartyCompareScreen();
    case 'movers':
      return const MoversScreen();
    case 'broker_book':
      return const PartyBookScreen(dim: 0);
    case 'village_book':
      return const PartyBookScreen(dim: 1);
    case 'monthly':
      return const MonthlyScreen();
    case 'target':
      return const TargetScreen();
    case 'day_open':
      return const DayOpenScreen();
    case 'followups':
      return FollowupsScreen(prefill: q ?? '');
    case 'notes':
      return const NotesScreen();
    case 'statement':
      return StatementScreen(party: arg is PartyRef ? arg : null);
    case 'mobiles':
      return const MobilesScreen();
    case 'converter':
      return const ConverterScreen();
    case 'recents':
      return const RecentsScreen();
    case 'diagnostics':
      return const DiagnosticsScreen();
    case 'handover':
      return const HandoverScreen();
    case 'routine':
      return const RoutineScreen();
    case 'khedut_khata':
      return const FarmerKhataScreen();
    case 'khata_party':
      return arg is PartyRef ? KhataDetailScreen(arg) : const FarmerKhataScreen();
    case 'payments':
      return const PaymentsScreen();
    case 'expenses':
      return const ExpensesScreen();
    case 'cashbook':
      // the PC (Tally) skin shows the Cash Book as a Tally table; the phone keeps the day cards
      return Pal.tally && app.stagePc ? const BankBookScreen(cash: true) : const CashBookScreen();
    case 'day_account':
      return const DayAccountScreen();
    case 'brokerage':
      return const BrokerageScreen();
    case 'wages':
      return const WagesScreen();
    case 'weight_bill':
      return const WeightBillScreen();
    case 'cost_calc':
      return const CostCalcScreen();
    case 'rate_chart':
      return const RateChartScreen();
    case 'month_close':
      return const MonthCloseScreen();
    case 'bookings':
      return const BookingsScreen();
    case 'sales':
      return const SalesScreen();
    case 'buyer_khata':
      return const BuyerKhataScreen();
    case 'buyer_party':
      return BuyerDetailScreen(q ?? '');
    case 'collection':
      return const CollectionScreen();
    case 'cash_flow':
      return const CashFlowScreen();
    case 'margin':
      return const MarginScreen();
    case 'export_money':
      return const MoneyExportScreen();
    case 'process_grade':
      return const ProcessScreen();
    case 'stock_live':
      return const StockScreen();
    case 'bad_entries':
      return const BadEntriesScreen();
    case 'help':
      return const HelpScreen();
    case 'tally_live':
      return const TallyDataScreen();
    case 'tally_ledgers':
      return const TallyDataScreen(tab: 1);
    case 'tally_cash':
      return const TallyDataScreen(tab: 2);
    case 'tally_stock':
      return const TallyDataScreen(tab: 3);
    case 'tally_sum':
      return const TallyDataScreen(tab: 4);
    case 'tally_bank':
      return const TallyDataScreen(tab: 5);
    case 'tally_gst':
      return const TallyDataScreen(tab: 9);
    case 'tally_check':
      return const TallyDataScreen(tab: 10);
    case 'tally_pay':
      return const TallyDataScreen(tab: 8);
    case 'tally_mel':
      return const TallyDataScreen(tab: 7);
    case 'tally_age':
      return const TallyDataScreen(tab: 6);
    case 'gst_bill':
      return const GstScreen();
    case 'trading':
      return const TradingScreen();
    case 'bank_match':
      return const BankScreen();
    case 'debit_check':
      return const DebitCheckScreen();
    case 'kanta_auto':
      return KantaAutoScreen(text: q ?? '');
    case 'kanta_usb':
      return const KantaUsbScreen();
    case 'kanta_remote':
      return const KantaRemoteScreen();
    case 'kanta_khata':
      return const KantaKhataScreen();
    case 'backup':
      return const LaptopBackupScreen();
    case 'my_daybook':
      return BooksDayBookScreen(arg: arg);
    case 'my_ledger':
      return BooksLedgerScreen(arg: arg);
    case 'my_trial':
      return const BooksTrialScreen();
    case 'balance_sheet':
      return const BalanceSheetScreen();
    case 'profit_loss':
      return const ProfitLossScreen();
    case 'group_summary':
      return const GroupSummaryScreen();
    case 'bank_book':
      return const BankBookScreen();
    case 'outstandings':
      return const OutstandingsScreen();
    case 'ratio_analysis':
      return const RatioScreen();
    case 'gstr1':
      return const Gstr1Screen();
    case 'biz_graph':
      return const GraphScreen();
  }
  if (id.startsWith('g_')) return GroupHomeScreen(id.substring(2));
  final FeatureDef? f = featureById(id);
  if (f != null) return SoonScreen(id);
  return ScreenScroll(children: <Widget>[EmptyBox(title: bi('સ્ક્રીન મળી નથી', 'Screen not found'))]);
}

/// Title shown in the phone app bar / PC top bar.
String screenTitle(String id, Object? arg) {
  if (id == 'dashboard') return 'Balaji Pro';
  if (id == 'hub') return bi('બધા ફીચર', 'All Features');
  if (id == 'biz_home') return bi('ધંધો · આજે', 'Business Today');
  if (id == 'my_daybook') return registerName(arg is DayBookArg ? arg.type : (arg is String ? arg : ''));
  if (id == 'my_ledger' && arg is LedgerRef) return arg.name;
  if (id == 'pin_lock') return bi('PIN લોક', 'PIN lock');
  if (id == 'party') return arg is PartyRef ? arg.label : bi('પ્રોફાઇલ', 'Profile');
  if (id == 'khata_party') return arg is PartyRef ? arg.label : bi('ખેડૂત ખાતા', 'Farmer ledger');
  if (id == 'buyer_party') {
    final BuyerAcct? a = arg is String ? buyerAccts()[arg] : null;
    return a == null ? bi('ખરીદનાર ખાતા', 'Buyer ledger') : a.label;
  }
  if (id.startsWith('g_')) return groupOf(id.substring(2)).title;
  final FeatureDef? f = featureById(id);
  return f == null ? 'Balaji Pro' : f.title;
}

/// Which bottom-nav tab is active on the phone:
/// 0 home, 1 chit, 3 kanta, 4 mel (owner) / maal (staff), -1 none.
int tabOf(String id, Object? arg, bool admin) {
  switch (id) {
    case 'dashboard':
    case 'hub':
      return 0;
    case 'chithi':
    case 'chithi_new':
      return 1;
    case 'kanta':
    case 'kanta_new':
      return 3;
    case 'maal':
    case 'maal_new':
      return admin ? -1 : 4;
  }
  if (!admin) return -1;
  final FeatureDef? f = featureById(id);
  if (f == null) return -1;
  if (f.group == 'ghat' || id == 'mel' || id == 'alerts' || id == 'today') return 4;
  return -1;
}

/// Group of the current route, used to keep the PC sidebar section open.
String groupOfRoute(String id, Object? arg) {
  if (id.startsWith('g_')) return id.substring(2);
  if (id == 'party') return 'tools';
  if (id == 'khata_party' || id == 'buyer_party') return 'money';
  final FeatureDef? f = featureById(id);
  return f == null ? 'biz' : f.group;
}
