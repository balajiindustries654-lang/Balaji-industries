import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/palette.dart';
import '../data/mock_db.dart';
import '../data/models.dart';
import '../widgets/charts.dart';
import '../widgets/datagrid.dart';
import 'entries.dart';
import 'report_screen.dart';
import 'report_util.dart';

// Reports for: stock (10), sales (3), insights (5) and admin (3).

void _openParty(BuildContext ctx, Object? nameCell) {
  final Party? p = db.partyByName(nameCell.toString());
  if (p != null) app.go('party', arg: p);
}

double _stockKgOf(int g) {
  double s = 0;
  for (final StockRow r in db.stock) {
    if (r.g == g) s += r.kg;
  }
  return s;
}

double _stockValOf(int g) {
  double s = 0;
  for (final StockRow r in db.stock) {
    if (r.g == g) s += r.value;
  }
  return s;
}

class _Lot {
  final DateTime date;
  final int g;
  double bags = 0;
  double kg = 0;
  double amt = 0;
  double rem = 0;
  _Lot(this.date, this.g);
  String get id => 'L${pad2(date.day)}${pad2(date.month)}-${<String>['B', 'J', 'K'][g]}';
  double get rate => kg > 0 ? amt / (kg / 20) : 0;
}

/// Daily purchase lots (per grade); remaining stock is allocated newest-first.
List<_Lot> _lots() {
  final Map<String, _Lot> m = <String, _Lot>{};
  for (final Entry e in db.entries) {
    final DateTime d = dateOnly(e.dt);
    final _Lot l = m.putIfAbsent('${d.millisecondsSinceEpoch}|${e.g}', () => _Lot(d, e.g));
    l.bags += e.bags;
    l.kg += e.net;
    l.amt += e.amount;
  }
  final List<_Lot> list = m.values.toList();
  list.sort((_Lot a, _Lot b) => b.date.compareTo(a.date));
  final List<double> left = <double>[_stockKgOf(0), _stockKgOf(1), _stockKgOf(2)];
  for (final _Lot l in list) {
    final double r = left[l.g] < l.kg ? left[l.g] : l.kg;
    l.rem = r;
    left[l.g] -= r;
  }
  return list;
}

// ============================================================== STOCK

ReportOut _stockSummary(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('ગ્રેડ', 'Grade'), CK.text, w: 170, bold: true),
    Col(bi('ગોડાઉન', 'Godown'), CK.text, w: 130),
    Col(bi('બેગ', 'Bags'), CK.count, w: 100),
    Col('KG', CK.kg, w: 130),
    Col(bi('ભાવ/મણ', 'Rate/mann'), CK.money, w: 120),
    Col(bi('કિંમત', 'Value'), CK.money, w: 150, main: true),
  ];
  if (noPurchase(c)) return stockNote(cols);
  final List<List<Object?>> rows = <List<Object?>>[];
  for (final StockRow s in db.stock) {
    rows.add(<Object?>[gradeName(s.g), godownName(s.godown), s.bags.round(), s.kg, s.rate, s.value]);
  }
  rows.sort((List<Object?> a, List<Object?> b) => (b[5] as double).compareTo(a[5] as double));
  final double kg = sumCol(rows, 3);
  return ReportOut(
    GridData(cols, rows, totals: <Object?>[bi('કુલ', 'Total'), null, sumCol(rows, 2), kg, null, sumCol(rows, 5)]),
    kpis: <KpiSpec>[
      KpiSpec(bi('કુલ સ્ટોક', 'Total stock'), tons(kg), 'box', 'orange'),
      KpiSpec(bi('બેગ', 'Bags'), grp(sumCol(rows, 2)), 'bag', 'amber'),
      KpiSpec(bi('સ્ટોક કિંમત', 'Stock value'), inrC(sumCol(rows, 5)), 'rupee', 'green'),
    ],
    chartTitle: bi('ગ્રેડ પ્રમાણે સ્ટોક (ટન)', 'Stock by grade (tonnes)'),
    chart: BarChartX(
      values: <double>[for (int g = 0; g < 3; g++) _stockKgOf(g)],
      labels: <String>[for (int g = 0; g < 3; g++) gradeName(g, shortName: true)],
      color: Pal.amber,
      axisFmt: axT,
      valueFmt: axT,
    ),
  );
}

ReportOut _stockGodown(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('ગોડાઉન', 'Godown'), CK.text, w: 160, bold: true),
    Col(gradeName(0, shortName: true), CK.kg, w: 120),
    Col(gradeName(1, shortName: true), CK.kg, w: 120),
    Col(gradeName(2, shortName: true), CK.kg, w: 120),
    Col(bi('કુલ KG', 'Total KG'), CK.kg, w: 130),
    Col(bi('કિંમત', 'Value'), CK.money, w: 150, main: true),
  ];
  if (noPurchase(c)) return stockNote(cols);
  final List<List<Object?>> rows = <List<Object?>>[];
  final List<DonutPart> parts = <DonutPart>[];
  for (int gd = 0; gd < 3; gd++) {
    final List<double> k = <double>[0, 0, 0];
    double v = 0;
    for (final StockRow s in db.stock) {
      if (s.godown == gd) {
        k[s.g] += s.kg;
        v += s.value;
      }
    }
    rows.add(<Object?>[godownName(gd), k[0], k[1], k[2], k[0] + k[1] + k[2], v]);
    parts.add(DonutPart(godownName(gd), v, kSeries[gd]));
  }
  return ReportOut(
    GridData(cols, rows, totals: <Object?>[bi('કુલ', 'Total'), sumCol(rows, 1), sumCol(rows, 2), sumCol(rows, 3), sumCol(rows, 4), sumCol(rows, 5)]),
    kpis: <KpiSpec>[
      for (int i = 0; i < rows.length; i++) KpiSpec(rows[i][0].toString(), tons(rows[i][4] as double), 'warehouse', i == 0 ? 'teal' : (i == 1 ? 'amber' : 'violet')),
    ],
    chartTitle: bi('ગોડાઉન પ્રમાણે કિંમત', 'Value by godown'),
    chart: donutLegend(parts, inrC(sumCol(rows, 5)), bi('સ્ટોક', 'stock'), fmt: (double v) => inrC(v)),
  );
}

ReportOut _stockGrade(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('ગ્રેડ', 'Grade'), CK.text, w: 170, bold: true),
    Col(bi('સ્ટોક KG', 'Stock KG'), CK.kg, w: 130),
    Col(bi('બેગ', 'Bags'), CK.count, w: 100),
    Col(bi('ભાવ/મણ', 'Rate/mann'), CK.money, w: 120),
    Col(bi('કિંમત', 'Value'), CK.money, w: 150, main: true),
    Col(bi('હિસ્સો', 'Share'), CK.pct, w: 90),
  ];
  if (noPurchase(c)) return stockNote(cols);
  final double total = db.stockKg(null);
  final List<List<Object?>> rows = <List<Object?>>[];
  final List<DonutPart> parts = <DonutPart>[];
  for (int g = 0; g < 3; g++) {
    final double kg = _stockKgOf(g);
    final double val = _stockValOf(g);
    rows.add(<Object?>[gradeName(g), kg, (kg / 35).round(), kg > 0 ? val / (kg / 20) : 0.0, val, total > 0 ? kg / total * 100 : 0.0]);
    parts.add(DonutPart(gradeName(g, shortName: true), kg, gradeColor(g)));
  }
  return ReportOut(
    GridData(cols, rows, totals: <Object?>[bi('કુલ', 'Total'), total, sumCol(rows, 2), null, sumCol(rows, 4), 100.0]),
    kpis: <KpiSpec>[
      for (int g = 0; g < 3; g++) KpiSpec(gradeName(g, shortName: true), tons(_stockKgOf(g)), 'grain', g == 0 ? 'teal' : (g == 1 ? 'amber' : 'violet')),
    ],
    chartTitle: bi('ગ્રેડ પ્રમાણે હિસ્સો', 'Share by grade'),
    chart: donutLegend(parts, tons(total), bi('કુલ', 'total'), fmt: (double v) => tons(v)),
  );
}

ReportOut _shortage(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('ગાડી', 'Vehicle'), CK.text, w: 170, bold: true),
    Col(bi('ફેરા', 'Trips'), CK.count, w: 80),
    Col(bi('કુલ વજન KG', 'Gross KG'), CK.kg, w: 130),
    Col(bi('હવા KG', 'Hava KG'), CK.kg, w: 120),
    Col(bi('હવા %', 'Hava %'), CK.pct, w: 100, main: true),
    Col(bi('સ્થિતિ', 'Status'), CK.status, w: 110),
  ];
  if (noPurchase(c)) return stockNote(cols);
  final Map<String, Agg> m = groupEntries(db.entriesInDays(c.days), (Entry e) => e.vehicle);
  final List<List<Object?>> rows = <List<Object?>>[];
  double gross = 0, hava = 0;
  m.forEach((String k, Agg a) {
    final double p = a.gross > 0 ? a.hava / a.gross * 100 : 0;
    gross += a.gross;
    hava += a.hava;
    rows.add(<Object?>[k, a.n, a.gross, a.hava, p, p > 1.6 ? 'high' : (p > 1.3 ? 'warn' : 'ok')]);
  });
  rows.sort((List<Object?> a, List<Object?> b) => (b[4] as double).compareTo(a[4] as double));
  final double overall = gross > 0 ? hava / gross * 100 : 0;
  return ReportOut(
    GridData(cols, rows, totals: <Object?>[bi('કુલ', 'Total'), sumCol(rows, 1), gross, hava, overall, null]),
    kpis: <KpiSpec>[
      KpiSpec(bi('કુલ હવા', 'Total hava'), '${grp(hava)} KG', 'scale', 'rose'),
      KpiSpec(bi('સરેરાશ હવા %', 'Average hava'), pct(overall), 'pct', 'amber'),
      KpiSpec(bi('વધારે હવાવાળી ગાડી', 'High-hava vehicles'), '${rows.where((List<Object?> r) => r[5] == 'high').length}', 'warn', 'rose'),
    ],
    chartTitle: bi('ગાડી પ્રમાણે હવા %', 'Hava % by vehicle'),
    chart: BarChartX(
      values: <double>[for (final List<Object?> r in rows.take(8)) r[4] as double],
      labels: <String>[for (final List<Object?> r in rows.take(8)) r[0].toString().substring(r[0].toString().length - 4)],
      color: Pal.bad,
      axisFmt: (double v) => '${v.toStringAsFixed(1)}%',
      valueFmt: (double v) => '${v.toStringAsFixed(1)}%',
    ),
  );
}

ReportOut _bagRegister(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('તારીખ', 'Date'), CK.date, w: 130, bold: true),
    Col(bi('આવેલી બેગ', 'Bags in'), CK.count, w: 120, main: true),
    Col(bi('ગયેલી બેગ (અંદાજ)', 'Bags out (est.)'), CK.count, w: 160),
    Col(bi('ફેરફાર', 'Net'), CK.count, w: 100),
  ];
  if (noPurchase(c)) return stockNote(cols);
  final Map<DateTime, List<double>> m = <DateTime, List<double>>{};
  for (final Entry e in db.entriesInDays(c.days)) {
    m.putIfAbsent(dateOnly(e.dt), () => <double>[0, 0])[0] += e.bags;
  }
  for (final Voucher v in db.vouchersIn(firm: Firm.balaji, days: c.days, type: 'Sales')) {
    m.putIfAbsent(dateOnly(v.date), () => <double>[0, 0])[1] += v.kg / 35;
  }
  final List<DateTime> days = m.keys.toList()..sort((DateTime a, DateTime b) => b.compareTo(a));
  final List<List<Object?>> rows = <List<Object?>>[
    for (final DateTime d in days) <Object?>[d, m[d]![0].round(), m[d]![1].round(), (m[d]![0] - m[d]![1]).round()],
  ];
  final List<DateTime> asc = days.take(14).toList().reversed.toList();
  return ReportOut(
    GridData(cols, rows, totals: <Object?>[bi('કુલ', 'Total'), sumCol(rows, 1), sumCol(rows, 2), sumCol(rows, 3)]),
    kpis: <KpiSpec>[
      KpiSpec(bi('આવેલી બેગ', 'Bags in'), grp(sumCol(rows, 1)), 'bag', 'green'),
      KpiSpec(bi('ગયેલી બેગ', 'Bags out'), grp(sumCol(rows, 2)), 'truck', 'amber'),
      KpiSpec(bi('ચોખ્ખો ફેરફાર', 'Net'), grp(sumCol(rows, 3)), 'swap', 'blue'),
    ],
    chartTitle: bi('આવેલી બેગ (14 દિવસ)', 'Bags in (14 days)'),
    chart: BarChartX(
      values: <double>[for (final DateTime d in asc) m[d]![0]],
      labels: <String>[for (final DateTime d in asc) '${d.day}'],
      color: Pal.amber,
    ),
  );
}

ReportOut _stockValuation(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('ગ્રેડ', 'Grade'), CK.text, w: 170, bold: true),
    Col('KG', CK.kg, w: 120),
    Col(bi('ખરીદ ભાવ/મણ', 'Cost/mann'), CK.money, w: 140),
    Col(bi('બજાર ભાવ/મણ', 'Market/mann'), CK.money, w: 140),
    Col(bi('ખરીદ કિંમત', 'Cost value'), CK.money, w: 150),
    Col(bi('બજાર કિંમત', 'Market value'), CK.money, w: 150),
    Col(bi('વધ / ઘટ', 'Gain / loss'), CK.money, w: 140, main: true),
  ];
  if (noPurchase(c)) return stockNote(cols);
  final List<List<Object?>> rows = <List<Object?>>[];
  for (int g = 0; g < 3; g++) {
    final double kg = _stockKgOf(g);
    final double cost = _stockValOf(g);
    final double mkt = kg / 20 * db.rates[g];
    rows.add(<Object?>[gradeName(g), kg, kg > 0 ? cost / (kg / 20) : 0.0, db.rates[g], cost, mkt, mkt - cost]);
  }
  return ReportOut(
    GridData(cols, rows, totals: <Object?>[bi('કુલ', 'Total'), sumCol(rows, 1), null, null, sumCol(rows, 4), sumCol(rows, 5), sumCol(rows, 6)]),
    kpis: <KpiSpec>[
      KpiSpec(bi('ખરીદ કિંમત', 'Cost value'), inrC(sumCol(rows, 4)), 'rupee', 'slate'),
      KpiSpec(bi('બજાર કિંમત', 'Market value'), inrC(sumCol(rows, 5)), 'trend', 'teal'),
      KpiSpec(bi('વધ / ઘટ', 'Unrealised'), inrC(sumCol(rows, 6)), 'balance', sumCol(rows, 6) >= 0 ? 'green' : 'rose'),
    ],
  );
}

ReportOut _reorder(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('ગ્રેડ', 'Grade'), CK.text, w: 170, bold: true),
    Col(bi('સ્ટોક KG', 'Stock KG'), CK.kg, w: 130),
    Col(bi('ન્યૂનતમ લેવલ KG', 'Reorder level KG'), CK.kg, w: 160),
    Col(bi('રોજનો ઉપાડ KG', 'Daily usage KG'), CK.kg, w: 150),
    Col(bi('કેટલા દિવસ ચાલે', 'Days cover'), CK.dec, w: 140, main: true),
    Col(bi('સ્થિતિ', 'Status'), CK.status, w: 110),
  ];
  if (noPurchase(c)) return stockNote(cols);
  const List<double> level = <double>[150000, 100000, 50000];
  final List<double> sold = <double>[0, 0, 0];
  for (final Voucher v in db.vouchersIn(firm: Firm.balaji, days: 30, type: 'Sales')) {
    if (v.grade >= 0) sold[v.grade] += v.kg;
  }
  final List<List<Object?>> rows = <List<Object?>>[];
  for (int g = 0; g < 3; g++) {
    final double kg = _stockKgOf(g);
    final double daily = sold[g] / 30;
    final double cover = daily > 0 ? kg / daily : 99;
    rows.add(<Object?>[gradeName(g), kg, level[g], daily, cover, kg < level[g] ? 'low' : 'ok']);
  }
  return ReportOut(
    GridData(cols, rows),
    kpis: <KpiSpec>[
      KpiSpec(bi('ઓછા સ્ટોકવાળા ગ્રેડ', 'Grades below level'), '${rows.where((List<Object?> r) => r[5] == 'low').length}', 'warn', 'rose'),
      KpiSpec(bi('કુલ સ્ટોક', 'Total stock'), tons(db.stockKg(null)), 'box', 'orange'),
    ],
  );
}

ReportOut _batch(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('લોટ નં.', 'Lot'), CK.text, w: 130, bold: true),
    Col(bi('તારીખ', 'Date'), CK.date, w: 120),
    Col(bi('ગ્રેડ', 'Grade'), CK.text, w: 130),
    Col(bi('બેગ', 'Bags'), CK.count, w: 90),
    Col(bi('આવ્યા KG', 'Inward KG'), CK.kg, w: 130),
    Col(bi('ભાવ/મણ', 'Rate/mann'), CK.money, w: 120),
    Col(bi('બાકી KG', 'Remaining KG'), CK.kg, w: 140, main: true),
    Col(bi('સ્થિતિ', 'Status'), CK.status, w: 110),
  ];
  if (noPurchase(c)) return stockNote(cols);
  final List<List<Object?>> rows = <List<Object?>>[];
  for (final _Lot l in _lots()) {
    if (db.today.difference(l.date).inDays >= c.days) continue;
    rows.add(<Object?>[l.id, l.date, gradeName(l.g, shortName: true), l.bags.round(), l.kg, l.rate, l.rem, l.rem <= 0.5 ? 'done' : (l.rem < l.kg - 0.5 ? 'part' : 'open')]);
  }
  return ReportOut(
    GridData(cols, rows, totals: <Object?>[bi('કુલ', 'Total'), null, null, sumCol(rows, 3), sumCol(rows, 4), null, sumCol(rows, 6), null]),
    kpis: <KpiSpec>[
      KpiSpec(bi('લોટ', 'Lots'), '${rows.length}', 'tag', 'violet'),
      KpiSpec(bi('ખુલ્લા લોટ', 'Open lots'), '${rows.where((List<Object?> r) => r[7] != 'done').length}', 'box', 'orange'),
      KpiSpec(bi('બાકી માલ', 'Remaining'), tons(sumCol(rows, 6)), 'scale', 'amber'),
    ],
  );
}

ReportOut _stockAge(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('ગ્રેડ', 'Grade'), CK.text, w: 170, bold: true),
    Col('0–15', CK.kg, w: 120),
    Col('16–30', CK.kg, w: 120),
    Col('31–60', CK.kg, w: 120),
    Col('60+', CK.kg, w: 120),
    Col(bi('કુલ KG', 'Total KG'), CK.kg, w: 140, main: true),
  ];
  if (noPurchase(c)) return stockNote(cols);
  final List<List<double>> b = <List<double>>[<double>[0, 0, 0, 0], <double>[0, 0, 0, 0], <double>[0, 0, 0, 0]];
  for (final _Lot l in _lots()) {
    final int age = db.today.difference(l.date).inDays;
    final int i = age <= 15 ? 0 : (age <= 30 ? 1 : (age <= 60 ? 2 : 3));
    b[l.g][i] += l.rem;
  }
  final List<List<Object?>> rows = <List<Object?>>[
    for (int g = 0; g < 3; g++) <Object?>[gradeName(g), b[g][0], b[g][1], b[g][2], b[g][3], b[g][0] + b[g][1] + b[g][2] + b[g][3]],
  ];
  final double t0 = sumCol(rows, 1), t1 = sumCol(rows, 2), t2 = sumCol(rows, 3), t3 = sumCol(rows, 4);
  return ReportOut(
    GridData(cols, rows, totals: <Object?>[bi('કુલ', 'Total'), t0, t1, t2, t3, t0 + t1 + t2 + t3]),
    kpis: <KpiSpec>[
      KpiSpec(bi('30+ દિવસ જૂનો', 'Older than 30d'), tons(t2 + t3), 'timeline', 'amber'),
      KpiSpec(bi('60+ દિવસ', '60+ days'), tons(t3), 'alarm', 'rose'),
    ],
    chartTitle: bi('સ્ટોક ઉંમર', 'Stock by age'),
    chart: donutLegend(
      <DonutPart>[
        DonutPart(bi('0–15 દિવસ', '0–15 days'), t0, Pal.ok),
        DonutPart(bi('16–30 દિવસ', '16–30 days'), t1, Pal.info),
        DonutPart(bi('31–60 દિવસ', '31–60 days'), t2, Pal.warn),
        DonutPart(bi('60+ દિવસ', '60+ days'), t3, Pal.bad),
      ],
      tons(t0 + t1 + t2 + t3),
      bi('કુલ', 'total'),
      fmt: (double v) => tons(v),
    ),
  );
}

ReportOut _moisture(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('તારીખ', 'Date'), CK.date, w: 130, bold: true),
    Col(bi('નમૂના', 'Samples'), CK.count, w: 100),
    Col(bi('સરેરાશ ભેજ %', 'Avg moisture %'), CK.pct, w: 150, main: true),
    Col(bi('સૌથી વધુ %', 'Max %'), CK.pct, w: 110),
    Col(bi('સ્થિતિ', 'Status'), CK.status, w: 110),
  ];
  if (noPurchase(c)) return stockNote(cols);
  final Map<DateTime, List<double>> m = <DateTime, List<double>>{};
  for (final Entry e in db.entriesInDays(c.days)) {
    final double mo = 6.0 + (e.no % 40) / 10.0;
    final List<double> x = m.putIfAbsent(dateOnly(e.dt), () => <double>[0, 0, 0]);
    x[0] += 1;
    x[1] += mo;
    if (mo > x[2]) x[2] = mo;
  }
  final List<DateTime> days = m.keys.toList()..sort((DateTime a, DateTime b) => b.compareTo(a));
  final List<List<Object?>> rows = <List<Object?>>[];
  for (final DateTime d in days) {
    final double avg = m[d]![1] / m[d]![0];
    rows.add(<Object?>[d, m[d]![0].toInt(), avg, m[d]![2], m[d]![2] > 9.5 ? 'high' : (avg > 8.2 ? 'warn' : 'ok')]);
  }
  final List<List<Object?>> asc = rows.take(20).toList().reversed.toList();
  return ReportOut(
    GridData(cols, rows),
    kpis: <KpiSpec>[
      KpiSpec(bi('સરેરાશ ભેજ', 'Average moisture'), pct(rows.isEmpty ? 0 : sumCol(rows, 2) / rows.length), 'water', 'blue'),
      KpiSpec(bi('વધારે ભેજવાળા દિવસ', 'High-moisture days'), '${rows.where((List<Object?> r) => r[4] == 'high').length}', 'warn', 'rose'),
    ],
    chartTitle: bi('સરેરાશ ભેજ % (દિવસ પ્રમાણે)', 'Average moisture % by day'),
    chart: asc.length < 2
        ? const SizedBox(height: 40)
        : LineChartX(
            series: <LineSeries>[LineSeries(bi('ભેજ %', 'Moisture %'), <double>[for (final List<Object?> r in asc) r[2] as double], Pal.info)],
            labels: <String>[for (final List<Object?> r in asc) '${(r[0] as DateTime).day}'],
            axisFmt: (double v) => '${v.toStringAsFixed(1)}%',
          ),
  );
}

// ============================================================== SALES

ReportOut _buyersBaki(RCtx c) {
  final List<List<Object?>> rows = <List<Object?>>[];
  for (final Party b in db.buyers) {
    final List<double> f = <double>[0, 0, 0];
    for (final LedgerAcc l in db.ledgers) {
      if (l.name == b.name) f[l.firm.index] = l.closing;
    }
    final double t = f[0] + f[1] + f[2];
    if (t > 0.5) rows.add(<Object?>[b.name, f[0], f[1], f[2], t]);
  }
  rows.sort((List<Object?> a, List<Object?> b) => (b[4] as double).compareTo(a[4] as double));
  final List<List<Object?>> top = rows.take(8).toList();
  return ReportOut(
    GridData(<Col>[
      Col(bi('ખરીદદાર', 'Buyer'), CK.text, w: 240, bold: true),
      Col(Firm.balaji.short, CK.money, w: 130),
      Col(Firm.patel.short, CK.money, w: 130),
      Col(Firm.shreenathji.short, CK.money, w: 140),
      Col(bi('કુલ બાકી', 'Total due'), CK.money, w: 150, main: true),
    ], rows, totals: <Object?>[bi('કુલ', 'Total'), sumCol(rows, 1), sumCol(rows, 2), sumCol(rows, 3), sumCol(rows, 4)]),
    kpis: <KpiSpec>[
      KpiSpec(bi('કુલ બાકી', 'Total due'), inrC(sumCol(rows, 4)), 'ul', 'rose'),
      KpiSpec(bi('ખરીદદાર', 'Buyers'), '${rows.length}', 'store', 'blue'),
    ],
    chartTitle: bi('ટોપ 8 બાકી', 'Top 8 outstanding'),
    chart: BarChartX(
      values: <double>[for (final List<Object?> r in top) r[4] as double],
      labels: <String>[for (final List<Object?> r in top) r[0].toString().split(' ').first],
      color: Pal.bad,
      axisFmt: axC,
      valueFmt: axC,
    ),
    onRow: (BuildContext ctx, List<Object?> r) => _openParty(ctx, r[0]),
  );
}

ReportOut _dispatch(RCtx c) {
  final List<Voucher> list = db.vouchersIn(firm: c.firm, days: c.days, type: 'Sales');
  final List<List<Object?>> rows = <List<Object?>>[
    for (final Voucher v in list)
      <Object?>[v.party, kVehicles[v.id % kVehicles.length], v.date, v.grade < 0 ? '' : gradeName(v.grade, shortName: true), (v.kg / 35).round(), v.kg, v.amount],
  ];
  final Map<DateTime, double> byDay = <DateTime, double>{};
  for (final Voucher v in list) {
    byDay[dateOnly(v.date)] = (byDay[dateOnly(v.date)] ?? 0) + v.kg;
  }
  final List<DateTime> dk = byDay.keys.toList()..sort();
  final List<DateTime> last = dk.length > 14 ? dk.sublist(dk.length - 14) : dk;
  return ReportOut(
    GridData(<Col>[
      Col(bi('ખરીદદાર', 'Buyer'), CK.text, w: 230, bold: true),
      Col(bi('ગાડી', 'Vehicle'), CK.text, w: 150),
      Col(bi('તારીખ', 'Date'), CK.date, w: 120),
      Col(bi('ગ્રેડ', 'Grade'), CK.text, w: 90),
      Col(bi('બેગ', 'Bags'), CK.count, w: 90),
      Col('KG', CK.kg, w: 120),
      Col(bi('કિંમત', 'Value'), CK.money, w: 140, main: true),
    ], rows, totals: <Object?>[bi('કુલ', 'Total'), null, null, null, sumCol(rows, 4), sumCol(rows, 5), sumCol(rows, 6)]),
    kpis: <KpiSpec>[
      KpiSpec(bi('રવાના', 'Dispatches'), '${rows.length}', 'truck', 'blue'),
      KpiSpec(bi('વજન', 'Weight'), tons(sumCol(rows, 5)), 'scale', 'amber'),
      KpiSpec(bi('કિંમત', 'Value'), inrC(sumCol(rows, 6)), 'rupee', 'green'),
    ],
    chartTitle: bi('દિવસ પ્રમાણે રવાના (ટન)', 'Dispatch by day (tonnes)'),
    chart: BarChartX(
      values: <double>[for (final DateTime d in last) byDay[d]!],
      labels: <String>[for (final DateTime d in last) '${d.day}'],
      color: Pal.info,
      axisFmt: axT,
      valueFmt: axT,
    ),
  );
}

ReportOut _rateTrend(RCtx c) {
  final Map<DateTime, List<double>> m = <DateTime, List<double>>{};
  for (final Entry e in db.entriesInDays(c.days)) {
    final List<double> x = m.putIfAbsent(dateOnly(e.dt), () => <double>[0, 0, 0, 0, 0, 0]);
    x[e.g * 2] += e.amount;
    x[e.g * 2 + 1] += e.net;
  }
  final List<DateTime> asc = m.keys.toList()..sort();
  Object? rate(List<double> x, int g) => x[g * 2 + 1] > 0 ? x[g * 2] / (x[g * 2 + 1] / 20) : null;
  final List<List<Object?>> rows = <List<Object?>>[
    for (final DateTime d in asc.reversed) <Object?>[d, rate(m[d]!, 0), rate(m[d]!, 1), rate(m[d]!, 2)],
  ];
  final List<DateTime> lastDays = asc.length > 30 ? asc.sublist(asc.length - 30) : asc;
  final List<List<double>> series = <List<double>>[<double>[], <double>[], <double>[]];
  final List<double> carry = <double>[db.rates[0], db.rates[1], db.rates[2]];
  for (final DateTime d in lastDays) {
    for (int g = 0; g < 3; g++) {
      final Object? r = rate(m[d]!, g);
      if (r != null) carry[g] = r as double;
      series[g].add(carry[g]);
    }
  }
  return ReportOut(
    GridData(<Col>[
      Col(bi('તારીખ', 'Date'), CK.date, w: 130, bold: true),
      Col(gradeName(0, shortName: true), CK.money, w: 130, main: true),
      Col(gradeName(1, shortName: true), CK.money, w: 130),
      Col(gradeName(2, shortName: true), CK.money, w: 130),
    ], rows),
    kpis: <KpiSpec>[
      for (int g = 0; g < 3; g++) KpiSpec('${gradeName(g, shortName: true)} ${bi('આજનો ભાવ', 'today')}', inr(db.rates[g]), 'tag', g == 0 ? 'teal' : (g == 1 ? 'amber' : 'violet')),
    ],
    chartTitle: bi('ભાવ ટ્રેન્ડ (પ્રતિ મણ)', 'Rate trend (per mann)'),
    chart: lastDays.length < 2
        ? const SizedBox(height: 40)
        : LineChartX(
            series: <LineSeries>[
              for (int g = 0; g < 3; g++) LineSeries(gradeName(g, shortName: true), series[g], gradeColor(g)),
            ],
            labels: <String>[for (final DateTime d in lastDays) '${d.day}'],
            axisFmt: axC,
          ),
  );
}

// ============================================================ INSIGHTS

ReportOut _anomaly(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('ખેડૂત', 'Farmer'), CK.text, w: 210, bold: true),
    Col(bi('ચિઠ્ઠી', 'Slip'), CK.text, w: 90),
    Col(bi('તારીખ', 'Date'), CK.date, w: 120),
    Col(bi('કારણ', 'Reason'), CK.text, w: 220),
    Col(bi('રકમ', 'Amount'), CK.money, w: 130, main: true),
    Col(bi('સ્થિતિ', 'Status'), CK.status, w: 100),
  ];
  if (noPurchase(c)) return purchaseNote(cols);
  final List<List<Object?>> rows = <List<Object?>>[];
  for (final Entry e in db.entriesInDays(c.days)) {
    double s = 0;
    int n = 0;
    for (final Entry o in db.entries) {
      if (o.g == e.g && o.no != e.no && o.dt.difference(e.dt).inDays.abs() <= 5) {
        s += o.rate;
        n++;
      }
    }
    final List<String> why = <String>[];
    double sev = 0;
    if (n >= 3) {
      final double dev = (e.rate - s / n) / (s / n) * 100;
      if (dev.abs() >= 1.8) {
        why.add('${bi('ભાવ', 'Rate')} ${dev >= 0 ? '+' : ''}${dev.toStringAsFixed(1)}%');
        sev += dev.abs() / 1.8;
      }
    }
    final double hp = e.gross > 0 ? e.hava / e.gross * 100 : 0;
    if (hp >= 2.1) {
      why.add('${bi('હવા', 'Hava')} ${hp.toStringAsFixed(1)}%');
      sev += hp / 2.1;
    }
    if (why.isEmpty) continue;
    rows.add(<Object?>[e.farmer.name, '#${e.no}', e.dt, why.join(' · '), e.amount, sev >= 1.4 ? 'high' : 'warn']);
  }
  return ReportOut(
    GridData(cols, rows),
    kpis: <KpiSpec>[
      KpiSpec(bi('શંકાસ્પદ એન્ટ્રી', 'Flagged entries'), '${rows.length}', 'warn', 'rose'),
      KpiSpec(bi('વધારે ગંભીર', 'High priority'), '${rows.where((List<Object?> r) => r[5] == 'high').length}', 'flag', 'amber'),
    ],
    onRow: (BuildContext ctx, List<Object?> r) {
      final Entry? e = entryByLabel(r[1]);
      if (e != null) showEntryDetail(ctx, e);
    },
  );
}

ReportOut _forecast(RCtx c) {
  final List<double> kg = List<double>.filled(8, 0);
  final List<double> n = List<double>.filled(8, 0);
  for (final Entry e in db.entriesInDays(56)) {
    kg[e.dt.weekday] += e.net;
    n[e.dt.weekday] += 1;
  }
  final double avgRate = (db.rates[0] + db.rates[1] + db.rates[2]) / 3;
  final List<List<Object?>> rows = <List<Object?>>[];
  for (int i = 1; i <= 7; i++) {
    final DateTime d = db.today.add(Duration(days: i));
    final double k = kg[d.weekday] / 8;
    rows.add(<Object?>[d, dayName(d), (n[d.weekday] / 8).round(), k, k / 20 * avgRate]);
  }
  return ReportOut(
    GridData(<Col>[
      Col(bi('તારીખ', 'Date'), CK.date, w: 130, bold: true),
      Col(bi('વાર', 'Day'), CK.text, w: 120),
      Col(bi('અંદાજિત એન્ટ્રી', 'Est. entries'), CK.count, w: 130),
      Col(bi('અંદાજિત KG', 'Est. KG'), CK.kg, w: 140, main: true),
      Col(bi('અંદાજિત કિંમત', 'Est. value'), CK.money, w: 150),
    ], rows, totals: <Object?>[bi('કુલ', 'Total'), null, sumCol(rows, 2), sumCol(rows, 3), sumCol(rows, 4)]),
    kpis: <KpiSpec>[
      KpiSpec(bi('આવતા 7 દિવસ', 'Next 7 days'), tons(sumCol(rows, 3)), 'query', 'blue'),
      KpiSpec(bi('અંદાજિત કિંમત', 'Est. value'), inrC(sumCol(rows, 4)), 'rupee', 'green'),
    ],
    chartTitle: bi('આવતા 7 દિવસનો અંદાજ (ટન)', 'Next 7 days (tonnes)'),
    chart: BarChartX(
      values: <double>[for (final List<Object?> r in rows) r[3] as double],
      labels: <String>[for (final List<Object?> r in rows) '${(r[0] as DateTime).day}'],
      color: Pal.info,
      axisFmt: axT,
      valueFmt: axT,
    ),
  );
}

ReportOut _seasonality(RCtx c) {
  final int span = c.days >= 100000 ? 80 : c.days;
  final List<double> kg = List<double>.filled(8, 0);
  final List<double> n = List<double>.filled(8, 0);
  final List<double> occ = List<double>.filled(8, 0);
  for (int i = 0; i < span; i++) {
    occ[db.today.subtract(Duration(days: i)).weekday] += 1;
  }
  for (final Entry e in db.entriesInDays(span)) {
    kg[e.dt.weekday] += e.net;
    n[e.dt.weekday] += 1;
  }
  double total = 0;
  for (int w = 1; w <= 7; w++) {
    total += occ[w] > 0 ? kg[w] / occ[w] : 0;
  }
  final List<List<Object?>> rows = <List<Object?>>[];
  for (int w = 1; w <= 7; w++) {
    final double a = occ[w] > 0 ? kg[w] / occ[w] : 0;
    rows.add(<Object?>[(L.gu ? kDayGu : kDayEn)[w - 1], occ[w] > 0 ? n[w] / occ[w] : 0.0, a, total > 0 ? a / total * 100 : 0.0]);
  }
  return ReportOut(
    GridData(<Col>[
      Col(bi('વાર', 'Weekday'), CK.text, w: 140, bold: true),
      Col(bi('સરેરાશ એન્ટ્રી/દિવસ', 'Avg entries/day'), CK.dec, w: 160),
      Col(bi('સરેરાશ KG/દિવસ', 'Avg KG/day'), CK.kg, w: 150, main: true),
      Col(bi('હિસ્સો', 'Share'), CK.pct, w: 90),
    ], rows),
    kpis: <KpiSpec>[
      KpiSpec(bi('સૌથી વ્યસ્ત વાર', 'Busiest day'), () {
        int best = 0;
        for (int i = 1; i < rows.length; i++) {
          if ((rows[i][2] as double) > (rows[best][2] as double)) best = i;
        }
        return rows[best][0].toString();
      }(), 'star', 'amber'),
    ],
    chartTitle: bi('વાર પ્રમાણે સરેરાશ આવક (ટન)', 'Average arrival by weekday (tonnes)'),
    chart: BarChartX(
      values: <double>[for (final List<Object?> r in rows) r[2] as double],
      labels: <String>[for (final List<Object?> r in rows) r[0].toString()],
      color: Pal.teal,
      axisFmt: axT,
      valueFmt: axT,
    ),
  );
}

ReportOut _comparePeriod(RCtx c) {
  final int n = c.days >= 100000 ? 40 : c.days;
  final List<Entry> cur = db.entriesInDays(n);
  final List<Entry> prev = db.entriesInDays(n * 2).where((Entry e) => db.today.difference(dateOnly(e.dt)).inDays >= n).toList();
  final Agg a = Agg();
  final Agg b = Agg();
  for (final Entry e in cur) {
    a.add(e);
  }
  for (final Entry e in prev) {
    b.add(e);
  }
  double chg(double x, double y) => y > 0 ? (x - y) / y * 100 : 0;
  final List<List<Object?>> rows = <List<Object?>>[
    <Object?>[bi('એન્ટ્રી', 'Entries'), grp(a.n), grp(b.n), chg(a.n.toDouble(), b.n.toDouble())],
    <Object?>[bi('બેગ', 'Bags'), grp(a.bags), grp(b.bags), chg(a.bags, b.bags)],
    <Object?>[bi('ચોખ્ખું વજન', 'Net weight'), tons(a.kg), tons(b.kg), chg(a.kg, b.kg)],
    <Object?>[bi('કુલ રકમ', 'Total value'), inrC(a.amt), inrC(b.amt), chg(a.amt, b.amt)],
    <Object?>[bi('સરેરાશ ભાવ/મણ', 'Avg rate/mann'), inr(a.avgRate), inr(b.avgRate), chg(a.avgRate, b.avgRate)],
    <Object?>[bi('સરેરાશ રકમ/એન્ટ્રી', 'Avg value/entry'), inrC(a.n > 0 ? a.amt / a.n : 0), inrC(b.n > 0 ? b.amt / b.n : 0), chg(a.n > 0 ? a.amt / a.n : 0, b.n > 0 ? b.amt / b.n : 0)],
    <Object?>[bi('બાકી ચૂકવણી', 'Unpaid'), inrC(a.due), inrC(b.due), chg(a.due, b.due)],
  ];
  return ReportOut(
    GridData(<Col>[
      Col(bi('માપ', 'Metric'), CK.text, w: 220, bold: true),
      Col(bi('આ સમયગાળો', 'This period'), CK.rtext, w: 150),
      Col(bi('પાછલો સમયગાળો', 'Previous'), CK.rtext, w: 150),
      Col(bi('ફેરફાર', 'Change'), CK.pct, w: 110, main: true),
    ], rows),
    kpis: <KpiSpec>[
      KpiSpec(bi('વજન ફેરફાર', 'Weight change'), pct(chg(a.kg, b.kg)), 'trend', chg(a.kg, b.kg) >= 0 ? 'green' : 'rose'),
      KpiSpec(bi('રકમ ફેરફાર', 'Value change'), pct(chg(a.amt, b.amt)), 'rupee', chg(a.amt, b.amt) >= 0 ? 'green' : 'rose'),
    ],
  );
}

ReportOut _leaderboard(RCtx c) {
  final List<List<Object?>> rows = <List<Object?>>[];
  if (!noPurchase(c)) {
    final List<Entry> list = db.entriesInDays(c.days);
    void add(String cat, List<MapEntry<String, Agg>> l, String Function(Agg) show) {
      for (int i = 0; i < l.length && i < 5; i++) {
        rows.add(<Object?>[l[i].key, cat, i + 1, show(l[i].value)]);
      }
    }

    add(bi('ખેડૂત', 'Farmer'), sortedAgg(groupEntries(list, (Entry e) => e.farmer.name), (Agg a) => a.kg), (Agg a) => tons(a.kg));
    add(bi('ગાડી', 'Vehicle'), sortedAgg(groupEntries(list, (Entry e) => e.vehicle), (Agg a) => a.n.toDouble()), (Agg a) => '${a.n} ${bi('ફેરા', 'trips')}');
    add(bi('દલાલ', 'Broker'), sortedAgg(groupEntries(list.where((Entry e) => e.broker != null).toList(), (Entry e) => e.broker!.name), (Agg a) => a.kg), (Agg a) => tons(a.kg));
    add(bi('ગામ', 'Village'), sortedAgg(groupEntries(list, (Entry e) => e.village), (Agg a) => a.kg), (Agg a) => tons(a.kg));
  }
  final Map<String, double> buy = <String, double>{};
  for (final Voucher v in db.vouchersIn(firm: c.firm, days: c.days, type: 'Sales')) {
    buy[v.party] = (buy[v.party] ?? 0) + v.total;
  }
  final List<MapEntry<String, double>> bl = buy.entries.toList();
  bl.sort((MapEntry<String, double> a, MapEntry<String, double> b) => b.value.compareTo(a.value));
  for (int i = 0; i < bl.length && i < 5; i++) {
    rows.add(<Object?>[bl[i].key, bi('ખરીદદાર', 'Buyer'), i + 1, inrC(bl[i].value)]);
  }
  return ReportOut(
    GridData(<Col>[
      Col(bi('નામ', 'Name'), CK.text, w: 250, bold: true),
      Col(bi('વિભાગ', 'Category'), CK.text, w: 130),
      Col(bi('ક્રમ', 'Rank'), CK.count, w: 80),
      Col(bi('કુલ', 'Total'), CK.rtext, w: 150, main: true),
    ], rows),
    onRow: (BuildContext ctx, List<Object?> r) => _openParty(ctx, r[0]),
  );
}

// ============================================================== ADMIN

ReportOut _users(RCtx c) {
  final List<List<Object?>> rows = <List<Object?>>[
    <Object?>[bi('માલિક', 'Owner'), bi('બધું', 'Everything'), bi('બધું', 'Everything'), ago(DateTime.now().subtract(const Duration(minutes: 3))), 'active'],
    <Object?>[bi('મુનીમ', 'Munim'), bi('એન્ટ્રી, ખાતા, ટેલી', 'Entries, parties, Tally'), bi('એન્ટ્રી, ચૂકવણી', 'Entries, payments'), ago(DateTime.now().subtract(const Duration(minutes: 25))), 'active'],
    <Object?>[bi('ઓપરેટર', 'Operator'), bi('એન્ટ્રી, સ્ટોક', 'Entries, stock'), bi('નવી એન્ટ્રી', 'New entries'), ago(DateTime.now().subtract(const Duration(hours: 2))), 'active'],
    <Object?>[bi('એકાઉન્ટન્ટ', 'Accountant'), bi('ટેલી, રિપોર્ટ', 'Tally, reports'), bi('કંઈ નહીં', 'None'), ago(DateTime.now().subtract(const Duration(days: 3))), 'idle'],
  ];
  return ReportOut(
    GridData(<Col>[
      Col(bi('રોલ', 'Role'), CK.text, w: 170, bold: true),
      Col(bi('શું જોઈ શકે', 'Can view'), CK.text, w: 220),
      Col(bi('શું બદલી શકે', 'Can edit'), CK.text, w: 200),
      Col(bi('છેલ્લે', 'Last active'), CK.text, w: 140),
      Col(bi('સ્થિતિ', 'Status'), CK.status, w: 110),
    ], rows),
  );
}

ReportOut _audit(RCtx c) {
  final List<List<Object?>> ev = <List<Object?>>[];
  const List<String> by = <String>['Owner', 'Munim', 'Operator'];
  for (final Entry e in db.entries.take(30)) {
    ev.add(<Object?>[bi('નવી એન્ટ્રી', 'New entry'), '#${e.no} · ${e.farmer.name}', e.dt, by[e.no % 3]]);
  }
  for (final Voucher v in db.vouchersIn(firm: Firm.balaji, days: 14, type: 'Payment').take(20)) {
    ev.add(<Object?>[bi('ચૂકવણી', 'Payment'), '${v.no} · ${v.party} · ${inr(v.amount)}', v.date, by[v.id % 3]]);
  }
  ev.sort((List<Object?> a, List<Object?> b) => (b[2] as DateTime).compareTo(a[2] as DateTime));
  final List<List<Object?>> rows = <List<Object?>>[
    for (final List<Object?> e in ev) <Object?>[e[0], e[1], '${dm(e[2] as DateTime)} ${hm(e[2] as DateTime)}', e[3]],
  ];
  return ReportOut(
    GridData(<Col>[
      Col(bi('ક્રિયા', 'Action'), CK.text, w: 150, bold: true),
      Col(bi('વિગત', 'Detail'), CK.text, w: 340),
      Col(bi('ક્યારે', 'When'), CK.text, w: 150),
      Col(bi('કોણે', 'By'), CK.text, w: 110),
    ], rows),
  );
}

ReportOut _devices(RCtx c) {
  final List<List<Object?>> rows = <List<Object?>>[
    <Object?>[bi('Android ફોન (એપ)', 'Android phone (app)'), bi('મોબાઇલ', 'Mobile'), ago(DateTime.now().subtract(const Duration(minutes: 1))), 'active'],
    <Object?>[bi('Windows PC (એપ)', 'Windows PC (app)'), bi('ડેસ્કટોપ', 'Desktop'), ago(DateTime.now().subtract(const Duration(minutes: 12))), 'active'],
    <Object?>[bi('Tally PC એજન્ટ', 'Tally PC agent'), bi('બેકગ્રાઉન્ડ', 'Background'), ago(app.lastSync), app.tallyOnline ? 'active' : 'off'],
    <Object?>[bi('બ્રાઉઝર', 'Web browser'), bi('વેબ', 'Web'), ago(DateTime.now().subtract(const Duration(days: 2))), 'idle'],
  ];
  return ReportOut(
    GridData(<Col>[
      Col(bi('ડિવાઇસ', 'Device'), CK.text, w: 240, bold: true),
      Col(bi('પ્રકાર', 'Type'), CK.text, w: 150),
      Col(bi('છેલ્લે સક્રિય', 'Last active'), CK.text, w: 160),
      Col(bi('સ્થિતિ', 'Status'), CK.status, w: 110),
    ], rows),
  );
}

final Map<String, ReportSpec> kReportsC = <String, ReportSpec>{
  'stock_summary': ReportSpec(_stockSummary, useDays: false),
  'stock_godown': ReportSpec(_stockGodown, useDays: false),
  'stock_grade': ReportSpec(_stockGrade, useDays: false),
  'shortage': ReportSpec(_shortage),
  'bag_register': ReportSpec(_bagRegister, defaultDays: 30),
  'stock_valuation': ReportSpec(_stockValuation, useDays: false),
  'reorder': ReportSpec(_reorder, useDays: false),
  'batch': ReportSpec(_batch, defaultDays: 30),
  'stock_age': ReportSpec(_stockAge, useDays: false),
  'moisture': ReportSpec(_moisture, defaultDays: 30),
  'buyers_baki': ReportSpec(_buyersBaki, useDays: false, useFirm: false),
  'dispatch': ReportSpec(_dispatch),
  'rate_trend': ReportSpec(_rateTrend, useFirm: false, defaultDays: 30),
  'anomaly': ReportSpec(_anomaly),
  'forecast': ReportSpec(_forecast, useDays: false, useFirm: false),
  'seasonality': ReportSpec(_seasonality, defaultDays: 90),
  'compare_period': ReportSpec(_comparePeriod, useFirm: false),
  'leaderboard': ReportSpec(_leaderboard),
  'users': ReportSpec(_users, useDays: false, useFirm: false),
  'audit': ReportSpec(_audit, useDays: false, useFirm: false),
  'devices': ReportSpec(_devices, useDays: false, useFirm: false),
};
