import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/device.dart';
import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/icons.dart';
import '../core/palette.dart';
import '../data/mock_db.dart';
import '../data/models.dart';
import '../widgets/charts.dart';
import '../widgets/common.dart';
import '../widgets/datagrid.dart';
import '../widgets/page.dart';

MockDb get _db => MockDb.I;

String voucherIcon(String t) {
  switch (t) {
    case 'Sales':
      return 'cart';
    case 'Purchase':
      return 'bag';
    case 'Receipt':
      return 'dl';
    case 'Payment':
      return 'pay';
    case 'Journal':
      return 'book';
    default:
      return 'swap';
  }
}

String voucherTone(String t) => Pal.statusTone(t);

String drcrText(double v) => v.abs() < 0.5 ? '₹0' : '${inr(v.abs())} ${v >= 0 ? 'Dr' : 'Cr'}';

// ------------------------------------------------------------ voucher sheet
void showVoucherDetail(BuildContext context, Voucher v) {
  openPanel(context, title: '${statusText(v.type)} · ${v.no}', sub: '${dmy(v.date)} · ${v.firm.title}', child: _VoucherBody(v));
}

class _VoucherBody extends StatelessWidget {
  final Voucher v;
  const _VoucherBody(this.v);

  Widget _line(String side, String name, double amt) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 9),
      child: Row(
        children: <Widget>[
          Container(
            width: 36,
            alignment: Alignment.center,
            padding: const EdgeInsets.symmetric(vertical: 3),
            decoration: BoxDecoration(color: side == 'Dr' ? Pal.tone('violet').bg : Pal.tone('green').bg, borderRadius: BorderRadius.circular(6)),
            child: Text(side, style: ts(12, w: FontWeight.w800, c: side == 'Dr' ? Pal.tone('violet').fg : Pal.tone('green').fg)),
          ),
          const SizedBox(width: 12),
          Expanded(child: Text(name, style: ts(14.5, w: FontWeight.w700))),
          Text(inr(amt), style: ts(14.5, w: FontWeight.w800, tab: true)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool sales = v.type == 'Sales';
    final Party? party = _db.partyByName(v.party);
    LedgerAcc? led;
    for (final LedgerAcc l in _db.ledgers) {
      if (l.firm == v.firm && l.name == v.dr) {
        led = l;
        break;
      }
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Row(
          children: <Widget>[
            IconChip(voucherIcon(v.type), tone: voucherTone(v.type), size: 48),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(v.party, style: ts(16.5, w: FontWeight.w800)),
                  const SizedBox(height: 2),
                  Text(inr(v.total), style: ts(22, w: FontWeight.w800, tab: true, ls: -0.5)),
                ],
              ),
            ),
            StatusPill(v.type),
          ],
        ),
        const SizedBox(height: 14),
        Surface(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
          color: Pal.surface2,
          shadow: false,
          child: Column(
            children: <Widget>[
              _line('Dr', v.dr, sales ? v.total : v.amount),
              divider(),
              _line('Cr', v.cr, v.amount),
              if (sales && v.gst > 0) ...<Widget>[divider(), _line('Cr', 'GST Output', v.gst)],
            ],
          ),
        ),
        const SizedBox(height: 8),
        InfoRow(bi('ફર્મ', 'Firm'), v.firm.title),
        InfoRow(bi('તારીખ', 'Date'), '${dmy(v.date)} ${hm(v.date)}'),
        if (v.narration.isNotEmpty) InfoRow(bi('નોંધ', 'Narration'), v.narration),
        if (v.ref != null) InfoRow(bi('સંદર્ભ', 'Reference'), v.ref!),
        if (v.kg > 0) InfoRow(bi('વજન', 'Weight'), '${grp(v.kg)} KG'),
        if (v.grade >= 0) InfoRow(bi('ગ્રેડ', 'Grade'), gradeName(v.grade)),
        if (v.gst > 0) InfoRow('GST', inr(v.gst)),
        const SizedBox(height: 14),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: <Widget>[
            if (party != null)
              Btn(bi('પાર્ટી ખાતું', 'Party account'), icon: 'user', onTap: () {
                Navigator.of(context).pop();
                app.go('party', arg: party);
              }),
            if (led != null)
              Btn(bi('લેજર', 'Ledger'), icon: 'ledger', kind: BtnKind.tonal, onTap: () {
                Navigator.of(context).pop();
                app.go('ledger', arg: led);
              }),
          ],
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------- Tally sync
class TallySyncScreen extends StatelessWidget {
  const TallySyncScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    final bool on = app.tallyOnline;

    final Widget status = Surface(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              IconChip('sync', tone: on ? 'violet' : 'slate', size: 52),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text('Tally PC Agent', style: ts(17, w: FontWeight.w800)),
                    const SizedBox(height: 4),
                    Row(
                      children: <Widget>[
                        Container(width: 9, height: 9, decoration: BoxDecoration(color: on ? Pal.ok : Pal.faint, shape: BoxShape.circle)),
                        const SizedBox(width: 6),
                        Text(on ? bi('ઓનલાઇન', 'Online') : bi('ઓફલાઇન', 'Offline'), style: ts(13.5, w: FontWeight.w700, c: on ? Pal.ok : Pal.muted)),
                        const SizedBox(width: 10),
                        Flexible(child: Text(ago(app.lastSync), overflow: TextOverflow.ellipsis, style: ts(13, c: Pal.muted))),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          if (app.syncing) ...<Widget>[
            const SizedBox(height: 16),
            ClipRRect(
              borderRadius: BorderRadius.circular(99),
              child: LinearProgressIndicator(value: app.syncProgress, minHeight: 8, color: Pal.brand, backgroundColor: Pal.line),
            ),
            const SizedBox(height: 6),
            Text('${(app.syncProgress * 100).round()}%', style: ts(12.5, c: Pal.muted, tab: true)),
          ],
          const SizedBox(height: 16),
          Row(
            children: <Widget>[
              tExp(
                child: Btn(app.syncing ? bi('સિંક ચાલુ છે…', 'Syncing…') : bi('હમણાં સિંક કરો', 'Sync now'), icon: 'refresh', onTap: app.syncing ? null : () => app.syncNow()),
              ),
              const SizedBox(width: 8),
              Pill('Tally → App', tone: 'violet', icon: 'arrowdown'),
            ],
          ),
        ],
      ),
    );

    final List<Widget> firms = <Widget>[];
    for (final Firm f in Firm.values) {
      final List<Voucher> vs = _db.vouchersIn(firm: f);
      final int led = _db.ledgersOf(f).length;
      firms.add(Surface(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: <Widget>[
            IconChip('store', tone: f.tone, size: 44),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(f.title, style: ts(15, w: FontWeight.w800)),
                  const SizedBox(height: 2),
                  Text('${grp(vs.length)} ${bi('વાઉચર', 'vouchers')} · $led ${bi('લેજર', 'ledgers')}', style: ts(12.5, c: Pal.muted)),
                ],
              ),
            ),
            StatusPill(on ? 'ok' : 'off', small: true),
          ],
        ),
      ));
    }

    final List<List<String>> log = <List<String>>[];
    for (int i = 0; i < 6; i++) {
      final DateTime t = app.lastSync.subtract(Duration(minutes: 30 * i));
      log.add(<String>['${dm(t)} ${hm(t)}', i == 0 ? bi('હમણાનું સિંક', 'Latest sync') : bi('આપોઆપ સિંક', 'Auto sync'), '${(i * 7 + 4) % 19 + 3}']);
    }
    final Widget history = Panel(
      title: bi('સિંક ઇતિહાસ', 'Sync history'),
      child: Column(
        children: <Widget>[
          for (final List<String> r in log)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Row(
                children: <Widget>[
                  Icon(ic('check'), size: 17, color: Pal.ok),
                  const SizedBox(width: 10),
                  Expanded(child: Text(r[1], style: ts(13.5, w: FontWeight.w600))),
                  Text('${r[2]} ${bi('નવા', 'new')}', style: ts(13, c: Pal.muted, tab: true)),
                  const SizedBox(width: 12),
                  Text(r[0], style: ts(12.5, c: Pal.faint, tab: true)),
                ],
              ),
            ),
        ],
      ),
    );

    final Widget firmCol = Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        for (int i = 0; i < firms.length; i++) ...<Widget>[if (i > 0) const SizedBox(height: 10), firms[i]],
      ],
    );

    return ScreenScroll(
      maxWidth: 1100,
      children: <Widget>[
        ScreenHeader(bi('ટેલી કનેક્શન', 'Tally connection')),
        if (pc)
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Expanded(flex: 5, child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: <Widget>[status, const SizedBox(height: 14), history])),
              const SizedBox(width: 16),
              Expanded(flex: 4, child: firmCol),
            ],
          )
        else ...<Widget>[status, const SizedBox(height: 12), firmCol, const SizedBox(height: 12), history],
      ],
    );
  }
}

// ------------------------------------------------------------------ Day Book
class DaybookScreen extends StatefulWidget {
  const DaybookScreen({super.key});

  @override
  State<DaybookScreen> createState() => _DaybookScreenState();
}

class _DaybookScreenState extends State<DaybookScreen> {
  int _period = 1;
  int _type = 0;
  String _q = '';
  int _shown = 40;

  static const List<int> _days = <int>[1, 7, 30, 100000];
  static const List<String> _types = <String>['', 'Sales', 'Purchase', 'Receipt', 'Payment', 'Journal', 'Contra'];

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    final String q = _q.trim().toLowerCase();
    final List<Voucher> base = _db.vouchersIn(firm: app.firm, days: _days[_period]).where((Voucher v) {
      if (q.isEmpty) return true;
      return '${v.party} ${v.no} ${v.narration} ${v.dr} ${v.cr}'.toLowerCase().contains(q);
    }).toList();
    final List<int> counts = <int>[
      for (final String t in _types) t.isEmpty ? base.length : base.where((Voucher v) => v.type == t).length,
    ];
    final List<Voucher> list = _type == 0 ? base : base.where((Voucher v) => v.type == _types[_type]).toList();

    double sales = 0, rec = 0, pay = 0;
    for (final Voucher v in list) {
      if (v.type == 'Sales') sales += v.total;
      if (v.type == 'Receipt') rec += v.amount;
      if (v.type == 'Payment') pay += v.amount;
    }

    final Widget period = Seg(
      dense: true,
      labels: <String>[bi('આજે', 'Today'), bi('7 દિવસ', '7d'), bi('30 દિવસ', '30d'), bi('બધું', 'All')],
      index: _period,
      onChanged: (int i) => setState(() {
        _period = i;
        _shown = 40;
      }),
    );
    final Widget search = SearchBox(
      hint: bi('નામ, વાઉચર, નોંધ…', 'Name, voucher, narration…'),
      width: pc ? 300 : null,
      onChanged: (String v) => setState(() {
        _q = v;
        _shown = 40;
      }),
    );
    final Widget chips = ChipRow(
      labels: <String>[
        for (int i = 0; i < _types.length; i++) '${i == 0 ? bi('બધા', 'All') : statusText(_types[i])} ${counts[i]}',
      ],
      index: _type,
      onChanged: (int i) => setState(() {
        _type = i;
        _shown = 40;
      }),
    );

    final Widget summary = pc
        ? Grid(cols: 4, gap: 12, children: <Widget>[
            KpiCard(label: bi('વાઉચર', 'Vouchers'), value: grp(list.length), icon: 'ledger', tone: 'violet'),
            KpiCard(label: bi('વેચાણ', 'Sales'), value: inrC(sales), icon: 'cart', tone: 'green'),
            KpiCard(label: bi('રસીદ', 'Receipts'), value: inrC(rec), icon: 'dl', tone: 'teal'),
            KpiCard(label: bi('ચૂકવણી', 'Payments'), value: inrC(pay), icon: 'pay', tone: 'rose'),
          ])
        : Surface(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            child: Row(
              children: <Widget>[
                _s(bi('વેચાણ', 'Sales'), inrC(sales), Pal.ok),
                _s(bi('રસીદ', 'Receipts'), inrC(rec), Pal.brand),
                _s(bi('ચૂકવણી', 'Payments'), inrC(pay), Pal.bad),
              ],
            ),
          );

    Widget body;
    if (list.isEmpty) {
      body = EmptyBox(icon: 'book', title: bi('કોઈ વાઉચર નથી', 'No vouchers'));
    } else if (pc) {
      final GridData g = GridData(<Col>[
        Col(bi('તારીખ', 'Date'), CK.date, w: 120),
        Col(bi('પ્રકાર', 'Type'), CK.status, w: 105),
        Col(bi('વાઉચર', 'Voucher'), CK.text, w: 95),
        Col(bi('વિગત', 'Particulars'), CK.text, w: 220, bold: true),
        Col(bi('ફર્મ', 'Firm'), CK.text, w: 105),
        Col(bi('ઉધાર (Dr)', 'Debit'), CK.text, w: 150),
        Col(bi('જમા (Cr)', 'Credit'), CK.text, w: 150),
        Col(bi('રકમ', 'Amount'), CK.money, w: 130, main: true),
      ], <List<Object?>>[
        for (final Voucher v in list) <Object?>[v.date, v.type, v.no, v.party, v.firm.short, v.dr, v.cr, v.total],
      ]);
      body = Panel(
        flush: true,
        title: bi('ડે બુક', 'Day Book'),
        child: DataGridX(data: g, pageSize: 16, onRow: (int i) => showVoucherDetail(context, list[i])),
      );
    } else {
      body = _phone(list);
    }

    return ScreenScroll(
      children: <Widget>[
        ScreenHeader(bi('ડે બુક', 'Day Book'), actions: <Widget>[period, search]),
        if (!pc) ...<Widget>[period, const SizedBox(height: 10), search, const SizedBox(height: 10)],
        summary,
        const SizedBox(height: 12),
        chips,
        const SizedBox(height: 12),
        body,
      ],
    );
  }

  Widget _s(String l, String v, Color c) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(l, style: ts(11.5, c: Pal.muted, w: FontWeight.w600)),
          const SizedBox(height: 2),
          FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(v, style: ts(16, w: FontWeight.w800, c: c, tab: true))),
        ],
      ),
    );
  }

  Widget _phone(List<Voucher> list) {
    final List<Widget> out = <Widget>[];
    final int count = list.length > _shown ? _shown : list.length;
    DateTime? day;
    for (int i = 0; i < count; i++) {
      final Voucher v = list[i];
      final DateTime d = dateOnly(v.date);
      if (day == null || !sameDay(day, d)) {
        day = d;
        int n = 0;
        for (final Voucher x in list) {
          if (sameDay(x.date, d)) n++;
        }
        out.add(Padding(
          padding: const EdgeInsets.fromLTRB(4, 8, 4, 8),
          child: Row(
            children: <Widget>[
              Text(dayLabel(d), style: ts(13.5, w: FontWeight.w800, c: Pal.muted)),
              const Spacer(),
              Text('$n ${bi('વાઉચર', 'vouchers')}', style: ts(12.5, w: FontWeight.w700, c: Pal.faint)),
            ],
          ),
        ));
      }
      final Tone t = Pal.tone(voucherTone(v.type));
      out.add(Surface(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(12),
        onTap: () => showVoucherDetail(context, v),
        child: Row(
          children: <Widget>[
            IconChip(voucherIcon(v.type), tone: voucherTone(v.type), size: 42),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(v.party, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14.5, w: FontWeight.w800)),
                  const SizedBox(height: 2),
                  Text('${v.no} · ${v.firm.short}${v.narration.isEmpty ? '' : ' · ${v.narration}'}', maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12, c: Pal.muted)),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Text(inr(v.total), style: ts(15, w: FontWeight.w800, c: t.fg, tab: true)),
                Text(statusText(v.type), style: ts(11.5, c: Pal.muted)),
              ],
            ),
          ],
        ),
      ));
    }
    if (list.length > count) {
      out.add(Btn(bi('વધુ બતાવો (${list.length - count})', 'Show more (${list.length - count})'),
          kind: BtnKind.tonal, expand: true, onTap: () => setState(() => _shown += 40)));
    }
    return Column(children: out);
  }
}

// ------------------------------------------------------------------ Ledgers
class TallyLedgersScreen extends StatefulWidget {
  final Object? arg;
  const TallyLedgersScreen({super.key, this.arg});

  @override
  State<TallyLedgersScreen> createState() => _TallyLedgersScreenState();
}

class _TallyLedgersScreenState extends State<TallyLedgersScreen> {
  String _group = '';
  String _q = '';

  @override
  void initState() {
    super.initState();
    if (widget.arg is String) _group = widget.arg as String;
  }

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    final List<LedgerAcc> all = _db.ledgersOf(app.firm);
    final String q = _q.trim().toLowerCase();
    final List<LedgerAcc> list = all.where((LedgerAcc l) {
      if (_group.isNotEmpty && l.group != _group) return false;
      if (q.isNotEmpty && !l.name.toLowerCase().contains(q)) return false;
      return true;
    }).toList();

    final Map<String, double> gt = <String, double>{};
    final Map<String, int> gn = <String, int>{};
    for (final LedgerAcc l in all) {
      gt[l.group] = (gt[l.group] ?? 0) + l.closing;
      gn[l.group] = (gn[l.group] ?? 0) + 1;
    }

    final Widget search = SearchBox(hint: bi('લેજર શોધો…', 'Search ledgers…'), width: pc ? 300 : null, onChanged: (String v) => setState(() => _q = v));

    final Widget groupList = Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        _groupTile(bi('બધા ગ્રુપ', 'All groups'), '', all.length, null),
        for (final String g in kGroupOrder)
          if (gn.containsKey(g)) _groupTile(g, g, gn[g]!, gt[g]),
      ],
    );

    final Widget table = list.isEmpty
        ? EmptyBox(title: bi('કોઈ લેજર નથી', 'No ledgers'))
        : (pc
            ? Panel(
                flush: true,
                title: _group.isEmpty ? bi('લેજર', 'Ledgers') : _group,
                child: DataGridX(
                  pageSize: 14,
                  data: GridData(<Col>[
                    Col(bi('લેજર', 'Ledger'), CK.text, w: 240, bold: true),
                    Col(bi('ગ્રુપ', 'Group'), CK.text, w: 170),
                    Col(bi('ફર્મ', 'Firm'), CK.text, w: 110),
                    Col(bi('ઉધાર', 'Debit'), CK.money, w: 130),
                    Col(bi('જમા', 'Credit'), CK.money, w: 130),
                    Col(bi('બાકી', 'Closing'), CK.rtext, w: 150, main: true),
                  ], <List<Object?>>[
                    for (final LedgerAcc l in list) <Object?>[l.name, l.group, l.firm.short, l.dr, l.cr, drcrText(l.closing)],
                  ]),
                  onRow: (int i) => app.go('ledger', arg: list[i]),
                ),
              )
            : Column(
                children: <Widget>[
                  for (final LedgerAcc l in list)
                    Surface(
                      margin: const EdgeInsets.only(bottom: 8),
                      padding: const EdgeInsets.all(12),
                      onTap: () => app.go('ledger', arg: l),
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(l.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14.5, w: FontWeight.w800)),
                                Text('${l.group}${app.firm == null ? ' · ${l.firm.short}' : ''}', maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12, c: Pal.muted)),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(drcrText(l.closing), style: ts(14.5, w: FontWeight.w800, tab: true)),
                        ],
                      ),
                    ),
                ],
              ));

    return ScreenScroll(
      children: <Widget>[
        ScreenHeader(bi('લેજર યાદી', 'Ledgers'), actions: <Widget>[search]),
        if (pc)
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SizedBox(width: 280, child: groupList),
              const SizedBox(width: 16),
              Expanded(child: table),
            ],
          )
        else ...<Widget>[
          search,
          const SizedBox(height: 10),
          ChipRow(
            labels: <String>[bi('બધા', 'All'), for (final String g in kGroupOrder) if (gn.containsKey(g)) g],
            index: _group.isEmpty ? 0 : (<String>[for (final String g in kGroupOrder) if (gn.containsKey(g)) g].indexOf(_group) + 1),
            onChanged: (int i) => setState(() => _group = i == 0 ? '' : <String>[for (final String g in kGroupOrder) if (gn.containsKey(g)) g][i - 1]),
          ),
          const SizedBox(height: 12),
          table,
        ],
      ],
    );
  }

  Widget _groupTile(String label, String key, int n, double? total) {
    final bool on = _group == key;
    return Surface(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      color: on ? Pal.soft : null,
      onTap: () => setState(() => _group = key),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(label, style: ts(14, w: FontWeight.w800, c: on ? Pal.brand : Pal.ink)),
                Text('$n ${bi('લેજર', 'ledgers')}', style: ts(12, c: Pal.muted)),
              ],
            ),
          ),
          if (total != null) Text(inrC(total.abs()), style: ts(13, w: FontWeight.w700, c: Pal.muted, tab: true)),
        ],
      ),
    );
  }
}

// ------------------------------------------------------------- single ledger
class LedgerScreen extends StatelessWidget {
  final Object? arg;
  const LedgerScreen(this.arg, {super.key});

  @override
  Widget build(BuildContext context) {
    final Object? a = arg;
    if (a is! LedgerAcc) return ScreenScroll(children: <Widget>[EmptyBox(title: bi('લેજર મળ્યું નથી', 'Ledger not found'))]);
    final LedgerAcc l = a;
    final bool pc = DeviceScope.isPc(context);

    final List<Voucher> vs = _db.vouchersIn(firm: l.firm).where((Voucher v) {
      if (v.dr == l.name || v.cr == l.name) return true;
      return l.name == 'GST Output' && v.type == 'Sales' && v.gst > 0;
    }).toList();
    vs.sort((Voucher x, Voucher y) {
      final int c = x.date.compareTo(y.date);
      return c != 0 ? c : x.id.compareTo(y.id);
    });
    double bal = l.opening;
    final List<List<Object?>> asc = <List<Object?>>[];
    for (final Voucher v in vs) {
      double dr = 0, cr = 0;
      if (v.type == 'Sales') {
        if (v.dr == l.name) dr = v.total;
        if (v.cr == l.name) cr = v.amount;
        if (l.name == 'GST Output') cr = v.gst;
      } else {
        if (v.dr == l.name) dr = v.amount;
        if (v.cr == l.name) cr = v.amount;
      }
      bal += dr - cr;
      final String counter = (v.dr == l.name) ? v.cr : v.dr;
      asc.add(<Object?>[l.name == 'GST Output' ? v.party : counter, v.date, v.no, v.type, dr == 0 ? null : dr, cr == 0 ? null : cr, bal]);
    }
    final List<List<Object?>> rows = asc.reversed.toList();

    final Widget head = Surface(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: <Widget>[
          IconChip('ledger', tone: l.firm.tone, size: 52),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(l.name, style: ts(pc ? 20 : 18, w: FontWeight.w800, ls: -0.3)),
                const SizedBox(height: 4),
                Wrap(spacing: 8, runSpacing: 4, crossAxisAlignment: WrapCrossAlignment.center, children: <Widget>[
                  Pill(l.group, tone: 'violet', small: true),
                  Pill(l.firm.short, tone: l.firm.tone, small: true),
                ]),
              ],
            ),
          ),
        ],
      ),
    );

    final Widget kpi = Grid(
      cols: pc ? 4 : 2,
      gap: 12,
      children: <Widget>[
        KpiCard(label: bi('શરૂઆત', 'Opening'), value: drcrText(l.opening), icon: 'book', tone: 'slate'),
        KpiCard(label: bi('કુલ ઉધાર', 'Total debit'), value: inrC(l.dr), icon: 'up', tone: 'violet'),
        KpiCard(label: bi('કુલ જમા', 'Total credit'), value: inrC(l.cr), icon: 'down', tone: 'teal'),
        KpiCard(label: bi('બાકી', 'Closing'), value: drcrText(l.closing), icon: 'balance', tone: 'amber'),
      ],
    );

    final GridData g = GridData(<Col>[
      Col(bi('વિગત', 'Particulars'), CK.text, w: 230, bold: true),
      Col(bi('તારીખ', 'Date'), CK.date, w: 120),
      Col(bi('વાઉચર', 'Voucher'), CK.text, w: 100),
      Col(bi('પ્રકાર', 'Type'), CK.status, w: 110),
      Col(bi('ઉધાર', 'Debit'), CK.money, w: 130),
      Col(bi('જમા', 'Credit'), CK.money, w: 130),
      Col(bi('બેલેન્સ', 'Balance'), CK.money, w: 140, main: true),
    ], rows);

    void open(int i) {
      for (final Voucher v in vs) {
        if (v.no == rows[i][2]) {
          showVoucherDetail(context, v);
          return;
        }
      }
    }

    return ScreenScroll(
      maxWidth: 1200,
      children: <Widget>[
        head,
        const SizedBox(height: 12),
        kpi,
        const SizedBox(height: 14),
        if (pc)
          Panel(flush: true, title: bi('ખાતાવહી', 'Ledger account'), child: DataGridX(data: g, pageSize: 14, onRow: open))
        else ...<Widget>[SectionTitle(bi('ખાતાવહી', 'Ledger account')), DataGridX(data: g, onRow: open)],
      ],
    );
  }
}

// ----------------------------------------------------------------------- P&L
class Pnl {
  double sales = 0;
  double stock = 0;
  double purchases = 0;
  double direct = 0;
  double indirect = 0;
  final Map<String, double> directHeads = <String, double>{};
  final Map<String, double> indirectHeads = <String, double>{};
  double get income => sales + stock;
  double get cost => purchases + direct;
  double get gross => income - cost;
  double get net => gross - indirect;
}

Pnl computePnl(Firm? f, int days) {
  final Map<String, String> grpOf = <String, String>{for (final LedgerAcc l in _db.ledgers) l.name: l.group};
  final Pnl p = Pnl();
  for (final Voucher v in _db.vouchersIn(firm: f, days: days)) {
    if (v.type == 'Sales') p.sales += v.amount;
    if (v.type == 'Purchase') p.purchases += v.amount;
    final String? g = grpOf[v.dr];
    if (v.type == 'Payment' && g == 'Direct Expenses') {
      p.direct += v.amount;
      p.directHeads[v.dr] = (p.directHeads[v.dr] ?? 0) + v.amount;
    }
    if (v.type != 'Sales' && g == 'Indirect Expenses') {
      p.indirect += v.amount;
      p.indirectHeads[v.dr] = (p.indirectHeads[v.dr] ?? 0) + v.amount;
    }
  }
  p.stock = days >= 100000 ? _db.stockValue(f) : 0;
  return p;
}

class StLine {
  final String label;
  final double? amount;
  final int level; // 0 = section header, 1 = item, 2 = total
  final Color? color;
  const StLine(this.label, this.amount, {this.level = 1, this.color});
}

Widget statementBlock(List<StLine> lines) {
  return Column(
    children: <Widget>[
      for (final StLine l in lines)
        Container(
          padding: EdgeInsets.fromLTRB(l.level == 1 ? 14 : 0, l.level == 0 ? 14 : 9, 0, 9),
          decoration: BoxDecoration(border: l.level == 2 ? Border(top: BorderSide(color: Pal.line, width: 1.2)) : null),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Text(
                  l.label,
                  style: ts(l.level == 0 ? 12.5 : 14, w: l.level == 1 ? FontWeight.w500 : FontWeight.w800, c: l.level == 0 ? Pal.muted : (l.color ?? Pal.ink), ls: l.level == 0 ? 0.6 : null),
                ),
              ),
              if (l.amount != null) Text(inr(l.amount!), style: ts(l.level == 2 ? 15.5 : 14, w: l.level == 1 ? FontWeight.w600 : FontWeight.w800, c: l.color, tab: true)),
            ],
          ),
        ),
    ],
  );
}

class PnlScreen extends StatefulWidget {
  const PnlScreen({super.key});

  @override
  State<PnlScreen> createState() => _PnlScreenState();
}

class _PnlScreenState extends State<PnlScreen> {
  int _p = 2;
  static const List<int> _days = <int>[7, 30, 90, 100000];

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    final Pnl p = computePnl(app.firm, _days[_p]);
    final bool profit = p.net >= 0;

    final Widget period = Seg(
      dense: true,
      labels: <String>[bi('7 દિવસ', '7d'), bi('30 દિવસ', '30d'), bi('90 દિવસ', '90d'), bi('બધું', 'All')],
      index: _p,
      onChanged: (int i) => setState(() => _p = i),
    );

    final List<StLine> lines = <StLine>[
      StLine(bi('આવક', 'INCOME'), null, level: 0),
      StLine(bi('વેચાણ', 'Sales'), p.sales),
      if (p.stock > 0) StLine(bi('બંધ સ્ટોક', 'Closing stock'), p.stock),
      StLine(bi('કુલ આવક', 'Total income'), p.income, level: 2),
      StLine(bi('સીધો ખર્ચ', 'DIRECT COST'), null, level: 0),
      if (p.purchases > 0) StLine(bi('ખરીદી', 'Purchases'), p.purchases),
      for (final MapEntry<String, double> e in p.directHeads.entries) StLine(e.key, e.value),
      StLine(bi('કુલ સીધો ખર્ચ', 'Total direct cost'), p.cost, level: 2),
      StLine(bi('ગ્રોસ નફો', 'Gross profit'), p.gross, level: 2, color: p.gross >= 0 ? Pal.ok : Pal.bad),
      StLine(bi('આડકતરો ખર્ચ', 'INDIRECT EXPENSES'), null, level: 0),
      for (final MapEntry<String, double> e in p.indirectHeads.entries) StLine(e.key, e.value),
      StLine(bi('કુલ આડકતરો ખર્ચ', 'Total indirect'), p.indirect, level: 2),
      StLine(profit ? bi('ચોખ્ખો નફો', 'Net profit') : bi('ચોખ્ખી ખોટ', 'Net loss'), p.net.abs(), level: 2, color: profit ? Pal.ok : Pal.bad),
    ];

    final List<DonutPart> parts = <DonutPart>[];
    int ci = 0;
    if (p.purchases > 0) parts.add(DonutPart(bi('ખરીદી', 'Purchases'), p.purchases, kSeriesColors[ci++]));
    if (p.direct > 0) parts.add(DonutPart(bi('સીધો ખર્ચ', 'Direct'), p.direct, kSeriesColors[ci++]));
    if (p.indirect > 0) parts.add(DonutPart(bi('આડકતરો ખર્ચ', 'Indirect'), p.indirect, kSeriesColors[ci++]));
    if (profit && p.net > 0) parts.add(DonutPart(bi('નફો', 'Profit'), p.net, Pal.ok));
    final double total = p.income > 0 ? p.income : 1;

    final Widget kpis = Grid(
      cols: pc ? 4 : 2,
      gap: 12,
      children: <Widget>[
        KpiCard(label: bi('કુલ આવક', 'Income'), value: inrC(p.income), icon: 'cart', tone: 'teal'),
        KpiCard(label: bi('ગ્રોસ નફો', 'Gross profit'), value: inrC(p.gross), icon: 'trend', tone: 'green'),
        KpiCard(label: bi('આડકતરો ખર્ચ', 'Indirect'), value: inrC(p.indirect), icon: 'wallet', tone: 'amber'),
        KpiCard(label: profit ? bi('ચોખ્ખો નફો', 'Net profit') : bi('ચોખ્ખી ખોટ', 'Net loss'), value: inrC(p.net.abs()), icon: 'rupee', tone: profit ? 'green' : 'rose'),
      ],
    );

    final Widget statement = Panel(title: bi('નફા-નુકસાન ખાતું', 'Profit & Loss account'), child: statementBlock(lines));
    final Widget chart = Panel(
      title: bi('આવકની વહેંચણી', 'Where income goes'),
      child: parts.isEmpty
          ? EmptyBox(title: bi('કોઈ ડેટા નથી', 'No data'))
          : Wrap(
              spacing: 26,
              runSpacing: 14,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: <Widget>[
                DonutX(parts: parts, center: pct(p.net / total * 100, dec: 0), sub: bi('માર્જિન', 'margin')),
                Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    for (final DonutPart d in parts) Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: LegendDot(d.color, d.label, value: inrC(d.value))),
                  ],
                ),
              ],
            ),
    );

    return ScreenScroll(
      maxWidth: 1200,
      children: <Widget>[
        ScreenHeader(bi('નફા-નુકસાન', 'Profit & Loss'), actions: <Widget>[period]),
        if (!pc) ...<Widget>[period, const SizedBox(height: 12)],
        kpis,
        const SizedBox(height: 14),
        SplitPane(flex: const <int>[3, 2], children: <Widget>[statement, chart]),
      ],
    );
  }
}

const List<Color> kSeriesColors = <Color>[Pal.teal, Pal.amber, Pal.info, Pal.violet, Pal.ok, Pal.bad];

// ------------------------------------------------------------ Balance sheet
class BalanceSheetScreen extends StatelessWidget {
  const BalanceSheetScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    final Firm? f = app.firm;
    final Pnl p = computePnl(f, 100000);

    double capital = 0, gst = 0, credLiab = 0, credAsset = 0, debAsset = 0, debLiab = 0;
    for (final LedgerAcc l in _db.ledgersOf(f)) {
      if (l.group == 'Capital Account') capital -= l.closing;
      if (l.group == 'Duties & Taxes') gst -= l.closing;
      if (l.group == 'Sundry Creditors') {
        if (l.closing < 0) {
          credLiab -= l.closing;
        } else {
          credAsset += l.closing;
        }
      }
      if (l.group == 'Sundry Debtors') {
        if (l.closing > 0) {
          debAsset += l.closing;
        } else {
          debLiab -= l.closing;
        }
      }
    }
    final double cash = _db.cashBalance(f);
    final double bank = _db.bankBalance(f);
    final double stock = _db.stockValue(f);
    final double assets = cash + bank + debAsset + credAsset + stock;
    final double liab = capital + gst + credLiab + debLiab + p.net;
    final bool ok = (assets - liab).abs() < 2;

    final Widget liabP = Panel(
      title: bi('જવાબદારી', 'Liabilities'),
      child: Column(
        children: <Widget>[
          statementBlock(<StLine>[
            StLine(bi('મૂડી ખાતું', 'Capital account'), capital),
            StLine(bi('નફા-નુકસાન ખાતું', 'Profit & Loss a/c'), p.net, color: p.net >= 0 ? Pal.ok : Pal.bad),
            StLine(bi('ખેડૂતોને ચૂકવવાના', 'Sundry creditors'), credLiab),
            if (debLiab > 0) StLine(bi('ખરીદદારનું એડવાન્સ', 'Buyer advances'), debLiab),
            StLine(bi('GST / ટેક્સ', 'Duties & taxes'), gst),
            StLine(bi('કુલ જવાબદારી', 'Total'), liab, level: 2),
          ]),
        ],
      ),
    );
    final Widget assetP = Panel(
      title: bi('મિલકત', 'Assets'),
      child: statementBlock(<StLine>[
        StLine(bi('રોકડ', 'Cash-in-hand'), cash),
        StLine(bi('બેંક', 'Bank accounts'), bank),
        StLine(bi('ખરીદદારના લેણાં', 'Sundry debtors'), debAsset),
        if (credAsset > 0) StLine(bi('ખેડૂતોને એડવાન્સ', 'Farmer advances'), credAsset),
        if (stock > 0) StLine(bi('સ્ટોક', 'Stock-in-hand'), stock),
        StLine(bi('કુલ મિલકત', 'Total'), assets, level: 2),
      ]),
    );

    return ScreenScroll(
      maxWidth: 1200,
      children: <Widget>[
        ScreenHeader(bi('સરવૈયું', 'Balance sheet'), actions: <Widget>[Pill(ok ? bi('મેળ ખાય છે ✓', 'Balanced ✓') : bi('ફરક', 'Difference'), tone: ok ? 'green' : 'rose')]),
        if (!pc) ...<Widget>[Align(alignment: Alignment.centerLeft, child: Pill(ok ? bi('મેળ ખાય છે ✓', 'Balanced ✓') : bi('ફરક', 'Difference'), tone: ok ? 'green' : 'rose')), const SizedBox(height: 12)],
        Grid(cols: pc ? 3 : 1, gap: 12, children: <Widget>[
          KpiCard(label: bi('કુલ મિલકત', 'Total assets'), value: inrC(assets), icon: 'assess', tone: 'blue', row: !pc),
          KpiCard(label: bi('કુલ જવાબદારી', 'Total liabilities'), value: inrC(liab), icon: 'balance', tone: 'violet', row: !pc),
          KpiCard(label: bi('રોકડ + બેંક', 'Cash + Bank'), value: inrC(cash + bank), icon: 'wallet', tone: 'amber', row: !pc),
        ]),
        const SizedBox(height: 14),
        SplitPane(children: <Widget>[liabP, assetP]),
      ],
    );
  }
}
