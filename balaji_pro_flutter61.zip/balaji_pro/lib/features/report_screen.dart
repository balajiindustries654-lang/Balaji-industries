import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/device.dart';
import '../core/i18n.dart';
import '../core/palette.dart';
import '../data/models.dart';
import '../widgets/common.dart';
import '../widgets/datagrid.dart';
import '../widgets/page.dart';
import 'registry.dart';

/// Filter context passed to every report builder.
class RCtx {
  final Firm? firm;
  final int days;
  const RCtx(this.firm, this.days);
}

class KpiSpec {
  final String label;
  final String value;
  final String icon;
  final String tone;
  const KpiSpec(this.label, this.value, this.icon, [this.tone = 'teal']);
}

class ReportOut {
  final GridData grid;
  final List<KpiSpec> kpis;
  final Widget? chart;
  final String? chartTitle;
  final Widget? chartExtra; // legend etc.
  final String? note;
  final void Function(BuildContext, List<Object?>)? onRow;
  const ReportOut(this.grid,
      {this.kpis = const <KpiSpec>[], this.chart, this.chartTitle, this.chartExtra, this.note, this.onRow});
}

class ReportSpec {
  final ReportOut Function(RCtx) build;
  final bool useDays;
  final int defaultDays;
  final bool useFirm;
  const ReportSpec(this.build, {this.useDays = true, this.defaultDays = 30, this.useFirm = true});
}

const List<int> _dayOpts = <int>[7, 30, 90, 100000];

/// Generic report page: header, filters, KPI strip, optional chart, data grid.
class ReportScreen extends StatefulWidget {
  final String id;
  final ReportSpec spec;
  const ReportScreen({super.key, required this.id, required this.spec});

  @override
  State<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {
  late int _days;
  String _q = '';
  final TextEditingController _qc = TextEditingController();

  @override
  void initState() {
    super.initState();
    _days = widget.spec.defaultDays;
  }

  @override
  void dispose() {
    _qc.dispose();
    super.dispose();
  }

  GridData _filter(GridData g) {
    final String q = _q.trim().toLowerCase();
    if (q.isEmpty) return g;
    final List<List<Object?>> rows = g.rows.where((List<Object?> r) {
      for (int i = 0; i < r.length; i++) {
        if (cellText(g.cols[i].kind, r[i]).toLowerCase().contains(q)) return true;
      }
      return false;
    }).toList();
    return GridData(g.cols, rows);
  }

  String _dayLabel(int d) {
    if (d >= 100000) return bi('બધું', 'All');
    return bi('$d દિવસ', '${d}d');
  }

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    final FeatureDef? f = featureById(widget.id);
    final RCtx ctx = RCtx(widget.spec.useFirm ? app.firm : null, _days);
    final ReportOut out = widget.spec.build(ctx);
    final GridData shown = _filter(out.grid);

    final Widget daySeg = Seg(
      dense: true,
      labels: _dayOpts.map(_dayLabel).toList(),
      index: _dayOpts.indexOf(_days) < 0 ? 1 : _dayOpts.indexOf(_days),
      onChanged: (int i) => setState(() => _days = _dayOpts[i]),
    );

    final Widget search = SearchBox(
      hint: bi('શોધો…', 'Search…'),
      controller: _qc,
      width: pc ? 280 : null,
      onChanged: (String v) => setState(() => _q = v),
    );

    final Widget csv = Btn(
      bi('CSV કૉપિ', 'Copy CSV'),
      icon: 'copy',
      kind: BtnKind.tonal,
      dense: true,
      onTap: () => copyText(gridCsv(shown), msg: bi('${shown.rows.length} પંક્તિ CSV તરીકે કૉપિ થઈ', '${shown.rows.length} rows copied as CSV')),
    );

    final List<Widget> controls = <Widget>[
      if (widget.spec.useDays) daySeg,
      if (app.firm != null && widget.spec.useFirm) Pill(app.firm!.short, tone: app.firm!.tone, icon: 'store'),
    ];

    final List<Widget> kp = out.kpis.map((KpiSpec k) {
      return Surface(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: <Widget>[
            IconChip(k.icon, tone: k.tone, size: 40),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(k.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12, c: Pal.muted, w: FontWeight.w600)),
                  Text(k.value, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(17, w: FontWeight.w800, tab: true, ls: -0.3)),
                ],
              ),
            ),
          ],
        ),
      );
    }).toList();

    return ScreenScroll(
      children: <Widget>[
        ScreenHeader(
          f?.title ?? '',
          actions: <Widget>[if (widget.spec.useDays) daySeg, search, csv],
        ),
        if (!pc) ...<Widget>[
          if (controls.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: <Widget>[...controls])),
            ),
          Row(children: <Widget>[Expanded(child: search), const SizedBox(width: 8), csv]),
          const SizedBox(height: 12),
        ],
        if (pc && app.firm != null && widget.spec.useFirm)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Row(children: <Widget>[Pill(bi('ફર્મ: ${app.firm!.title}', 'Firm: ${app.firm!.title}'), tone: app.firm!.tone, icon: 'store')]),
          ),
        if (out.note != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Surface(
              color: Pal.tone('amber').bg,
              border: false,
              shadow: false,
              padding: const EdgeInsets.all(12),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Icon(Icons.info_outline_rounded, size: 18, color: Pal.tone('amber').fg),
                  const SizedBox(width: 10),
                  Expanded(child: Text(out.note!, style: ts(13, c: Pal.tone('amber').fg, w: FontWeight.w600, h: 1.4))),
                ],
              ),
            ),
          ),
        if (kp.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 14),
            child: Grid(children: kp, cols: pc ? (kp.length > 4 ? 4 : kp.length) : 2, gap: 12),
          ),
        if (out.chart != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 14),
            child: Panel(
              title: out.chartTitle,
              child: out.chartExtra == null
                  ? out.chart!
                  : Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[out.chart!, const SizedBox(height: 10), out.chartExtra!]),
            ),
          ),
        if (pc)
          Panel(
            flush: true,
            title: f?.title,
            child: DataGridX(
              data: shown,
              pageSize: 16,
              onRow: out.onRow == null ? null : (int i) => out.onRow!(context, shown.rows[i]),
            ),
          )
        else
          DataGridX(
            data: shown,
            onRow: out.onRow == null ? null : (int i) => out.onRow!(context, shown.rows[i]),
          ),
      ],
    );
  }
}
