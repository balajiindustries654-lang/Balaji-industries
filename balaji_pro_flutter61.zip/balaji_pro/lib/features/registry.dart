import '../core/flags.dart';
import '../core/i18n.dart';

/// live  = working screen on the real data
/// beta  = working but still being tuned
/// soon  = roadmap card (planned feature)
enum FStatus { live, beta, soon }

class GroupDef {
  final String id;
  final String gu;
  final String en;
  final String icon;
  final String tone;
  const GroupDef(this.id, this.gu, this.en, this.icon, this.tone);
  String get title => bi(gu, en);
}

const List<GroupDef> kGroups = <GroupDef>[
  GroupDef('biz', 'ધંધો', 'Business', 'dash', 'teal'),
  GroupDef('money', 'હિસાબ / વેપાર', 'Accounts & trade', 'wallet', 'green'),
  GroupDef('tally', 'ટેલી ડેટા', 'Tally data', 'book', 'violet'),
  GroupDef('entries', 'એન્ટ્રી', 'Entries', 'list', 'blue'),
  GroupDef('ghat', 'ઘટ / તપાસ', 'Checks', 'scale', 'rose'),
  GroupDef('insight', 'વિશ્લેષણ', 'Insights', 'insights', 'violet'),
  GroupDef('ops', 'ઑપરેશન', 'Operations', 'monitor', 'amber'),
  GroupDef('tools', 'સાધનો', 'Tools', 'tune', 'blue'),
  GroupDef('admin', 'સેટિંગ', 'Settings', 'gear', 'slate'),
  GroupDef('soon', 'આવનાર', 'Coming next', 'bolt', 'amber'),
];

GroupDef groupOf(String id) => kGroups.firstWhere((GroupDef g) => g.id == id, orElse: () => kGroups[0]);

class FeatureDef {
  final String id;
  final String group;
  final String gu;
  final String en;
  final String icon;
  final String tone;
  final String dgu;
  final String den;
  final FStatus status;
  final bool side; // show in the PC sidebar
  const FeatureDef(this.id, this.group, this.gu, this.en, this.icon, this.tone, this.dgu, this.den,
      {this.status = FStatus.live, this.side = false});

  String get title => bi(gu, en);
  String get desc => bi(dgu, den);
  String get statusKey => status == FStatus.live ? 'live' : (status == FStatus.beta ? 'beta' : 'soon');
}

const FStatus _b = FStatus.beta;

/// Every screen of the app. All of them work on the real Supabase data.
const List<FeatureDef> _kAllFeatures = <FeatureDef>[

  // ------------------------------------------------------------ business
  FeatureDef('dashboard', 'biz', 'ધંધો · આજે', 'Business Today', 'dash', 'teal', 'આજની ચિઠ્ઠી, કાંટો, ફરક અને તપાસ', 'Today\'s chits, kanta, difference and checks', side: true),
  FeatureDef('today', 'biz', 'આજનો રિપોર્ટ', 'Day Report', 'bolt', 'amber', 'દિવસનો રિપોર્ટ - WhatsApp પર મોકલો', 'Day report you can send on WhatsApp', side: true),
  FeatureDef('mel', 'biz', 'ચિઠ્ઠી vs કાંટા મેળ', 'Chit vs Kanta Match', 'cmp', 'violet', 'દરેક ગાડીનું ચિઠ્ઠી અને કાંટાનું વજન મેળવો', 'Compare chit and weighbridge weight per vehicle', side: true),
  FeatureDef('alerts', 'biz', 'ધ્યાનમાં લો', 'Attention', 'bell', 'rose', 'ફરક, ગુમ એન્ટ્રી, ડુપ્લિકેટ, શંકાસ્પદ બાબતો', 'Differences, missing entries, duplicates, suspicious items', side: true),
  FeatureDef('search', 'biz', 'બધે શોધો', 'Search Everything', 'search', 'blue', 'ખેડૂત, ગાડી, ગામ, RST - બધું એક સર્ચમાં', 'Farmer, vehicle, village, RST in one box', side: true),
  FeatureDef('transit', 'biz', 'રસ્તામાં માલ', 'Goods in Transit', 'route', 'amber', 'ચિઠ્ઠી બની ગઈ છે પણ કાંટો બાકી - શું ક્યાં છે', 'Chit made, kanta pending - what is on which truck', side: true),
  FeatureDef('target', 'biz', 'રોજનો ટાર્ગેટ', 'Daily Target', 'target', 'green', 'ટાર્ગેટ સામે આજનો માલ, સતત દિવસ અને 14 દિવસનો ચાર્ટ', 'Today against the goal, streak and 14-day chart', side: true),
  FeatureDef('day_open', 'biz', 'દિવસ શરૂ ચેક', 'Start-of-Day Check', 'sun', 'amber', 'સવારે બધું તૈયાર છે કે નહીં - ડેટા પરથી આપોઆપ', 'Is everything ready this morning - from the real data'),
  FeatureDef('rates', 'biz', 'ભાવ યાદી (રેટ)', 'Price List (Rates)', 'rupee', 'green', 'માલ મુજબ ₹ પ્રતિ 20 KG, ઇતિહાસ અને ચાર્ટ', 'Rs per 20 KG by material, history and chart', side: true),
  FeatureDef('purchase', 'biz', 'ખરીદ રકમ', 'Purchase Value', 'pay', 'teal', 'વજન × ભાવ = રકમ - ખેડૂત, દલાલ, ગામ મુજબ', 'Weight × rate = amount - by farmer, broker, village', side: true),
  FeatureDef('followups', 'biz', 'ફોલો-અપ યાદી', 'Follow-ups', 'todo', 'rose', 'કોને ફોન કરવો, શું તપાસવું - તારીખ સાથે યાદી', 'Who to call, what to check - a list with dates'),

  // -------------------------------------------------------------- accounts
  FeatureDef('khedut_khata', 'money', 'ખેડૂત ખાતા', 'Farmer Ledgers', 'agri', 'green', 'ખેડૂત મુજબ બાકી, ચૂકવણી અને ઉપાડ - ખરીદ રકમ ચિઠ્ઠી પરથી આપોઆપ', 'Dues, payments and advances per farmer - purchase value straight from the chits', side: true),
  FeatureDef('payments', 'money', 'ખેડૂતને ચૂકવણી', 'Payments to Farmers', 'pay', 'teal', 'ખેડૂતને આપેલા પૈસા - રોકડ, બેંક, ઉપાડ', 'Money paid to farmers - cash, bank, advance', side: true),
  FeatureDef('expenses', 'money', 'ખર્ચ / આવક યાદી', 'Expense / Income List', 'wallet', 'rose', 'રોજના ખર્ચ હેડ મુજબ - મજૂરી, ભાડું, ડીઝલ', 'Daily costs by head - labour, freight, diesel', side: true),
  FeatureDef('cashbook', 'money', 'રોજમેળ', 'Cash Book', 'book', 'blue', 'ચૂકવણી અને ખર્ચ તારીખ મુજબ એક જ યાદીમાં', 'Payments and expenses together by date', side: true),
  FeatureDef('day_account', 'money', 'આજનો હિસાબ', 'Day Account', 'calc', 'amber', 'આજની ખરીદ, ચૂકવણી, ખર્ચ અને રોકડ - WhatsApp પર મોકલો', 'Today\'s purchase, payments, expenses and cash - send on WhatsApp', side: true),
  FeatureDef('weight_bill', 'money', 'ખરીદ બિલ (વજન બિલ)', 'Purchase Bill (Weight Bill)', 'receipt', 'teal', 'ખેડૂત અને સમય પસંદ કરો - ભાવ, કપાત સાથે ખરીદ બિલ', 'Pick farmer and period - a purchase bill with rate and deductions'),
  FeatureDef('brokerage', 'money', 'દલાલી હિસાબ', 'Brokerage Account', 'handshake', 'violet', 'દલાલ મુજબ બેગ કે વજન પર દલાલીની રકમ', 'Broker commission on bags or weight'),
  FeatureDef('wages', 'money', 'મજૂરી હિસાબ', 'Labour Wages', 'users', 'teal', 'ચડાવવા-ઉતારવાની બેગ પર મજૂરીનો હિસાબ', 'Wages on bags loaded and unloaded'),
  FeatureDef('cost_calc', 'money', 'કિંમત અને નફાની ગણતરી', 'Cost & Profit Calculator', 'balance', 'orange', 'ભાવ, ભાડું, ખર્ચ નાખો - નફો કે ખોટ તરત દેખાય', 'Enter rate, freight and costs - see profit or loss'),
  FeatureDef('rate_chart', 'money', 'ભાવનો ચાર્ટ', 'Rate Chart', 'chart', 'green', 'માલ મુજબ ભાવ કેમ બદલાયો - ચાર્ટ અને યાદી', 'How each material\'s rate moved - chart and list'),
  FeatureDef('month_close', 'money', 'મહિનો બંધ', 'Month Closing', 'month', 'teal', 'આખા મહિનાની ખરીદ, ચૂકવણી, ખર્ચ અને બાકી', 'Month purchase, payments, expenses and dues'),
  FeatureDef('bookings', 'money', 'આવનારી ગાડી', 'Expected Vehicles', 'truck', 'amber', 'અગાઉથી નોંધેલી ગાડી આવી કે નહીં', 'Vehicles noted in advance - arrived or not'),
  FeatureDef('sales', 'money', 'વેચાણ વાઉચર', 'Sales Vouchers', 'cart', 'teal', 'ખરીદનારને વેચેલો માલ, રકમ મળી અને બાકી - WhatsApp બિલ', 'Goods sold to buyers, money received and dues - WhatsApp bill', side: true),
  FeatureDef('buyer_khata', 'money', 'ખરીદનાર ખાતા', 'Buyer Ledgers', 'users', 'amber', 'ખરીદનાર પાસેથી કેટલા લેવાના - ખાતું અને યાદી મોકલો', 'What each buyer owes - ledger and a list to send', side: true),
  FeatureDef('my_daybook', 'money', 'ડે બુક', 'Day Book', 'book', 'violet', 'બધા વાઉચર તારીખ મુજબ - ઉધાર / જમા, સુધારો, કાઢવું, પ્રિન્ટ, Excel', 'Every voucher by date - Dr / Cr, alter, delete, print, Excel', side: true),
  FeatureDef('my_ledger', 'money', 'ખાતાવહી (Ledger)', 'Ledger', 'ledger', 'teal', 'ખેડૂત, ખરીદનાર, ખર્ચના ખાતા - શરૂઆતનું બાકી, ઉધાર, જમા, આખરી બાકી', 'Farmer, buyer and expense ledgers - opening, debit, credit, closing', side: true),
  FeatureDef('my_trial', 'money', 'ટ્રાયલ બેલેન્સ', 'Trial Balance', 'balance', 'slate', 'બધા ખાતાના ઉધાર અને જમા બાકી - મેળ કેટલો છે', 'Debit and credit balances of all accounts - and whether they tally', side: true),
  FeatureDef('balance_sheet', 'money', 'બેલેન્સ શીટ', 'Balance Sheet', 'balance', 'blue', 'જવાબદારી અને મિલકત - Tally ની જેમ બે બાજુ', 'Liabilities and assets - two sided like Tally'),
  FeatureDef('profit_loss', 'money', 'નફો-નુકસાન ખાતું', 'Profit & Loss A/c', 'trend', 'green', 'ખરીદ, વેચાણ, ખર્ચ, આવક અને ચોખ્ખો નફો', 'Purchases, sales, expenses, incomes and the net profit'),
  FeatureDef('group_summary', 'money', 'ગ્રુપ સમરી', 'Group Summary', 'list', 'teal', 'લેણદાર, દેવાદાર, રોકડ, બેંક - શરૂઆતનું, ઉધાર, જમા, આખરી', 'Creditors, debtors, cash, bank - opening, debit, credit, closing'),
  FeatureDef('bank_book', 'money', 'બેંક બુક', 'Bank Book', 'bank', 'blue', 'બેંક, UPI અને ચેકથી મળેલી અને ચૂકવેલી રકમ', 'Money received and paid by bank, UPI and cheque'),
  FeatureDef('outstandings', 'money', 'બાકી લેણું / દેવું (Outstandings)', 'Outstandings', 'rupee', 'amber', 'લેવાના અને આપવાના - 0-30, 31-60, 61-90, 90+ દિવસ', 'Receivables and payables with 0-30, 31-60, 61-90, 90+ days ageing'),
  FeatureDef('ratio_analysis', 'money', 'રેશિયો વિશ્લેષણ', 'Ratio Analysis', 'chart', 'violet', 'કરન્ટ રેશિયો, નફા %, ઉઘરાણી દિવસ, વર્કિંગ કેપિટલ', 'Current ratio, profit %, receivable days and working capital'),
  FeatureDef('biz_graph', 'money', 'ગ્રાફ (માસિક)', 'Graphs', 'chart', 'blue', 'મહિના મુજબ વેચાણ, ખરીદી, ખર્ચ અને નફો - ગ્રાફ અને ટેબલ', 'Month by month sales, purchase, expenses and result - graphs and table'),
  FeatureDef('gstr1', 'money', 'GSTR-1 રિટર્ન સરવાળો', 'GSTR-1 Return', 'percentbox', 'amber', 'B2B, B2C, નિલ રેટેડ, HSN અને બિલ નંબર - CA માટે મહિનાનો સરવાળો', 'B2B, B2C, nil rated, HSN and documents - the month summary for the CA'),
  FeatureDef('process_grade', 'money', 'પ્રોસેસ વાઉચર', 'Processing Vouchers', 'grain', 'amber', 'કાચો માલ ગયો, કયા ગ્રેડ નીકળ્યા અને ઘટ કેટલી', 'Raw material used, grades obtained and the loss', side: true),
  FeatureDef('stock_live', 'money', 'સ્ટોક સમરી', 'Stock Summary', 'warehouse', 'orange', 'આવ્યું − પ્રોસેસ − વેચ્યું = ગોડાઉનમાં કેટલું', 'Received − processed − sold = what is in the godown', side: true),
  FeatureDef('collection', 'money', 'ઉઘરાણી યાદી', 'Collection List', 'bell', 'rose', 'કોની પાસે કેટલા દિવસથી બાકી - રીમાઈન્ડર WhatsApp પર', 'Who owes and since when - reminders on WhatsApp', side: true),
  FeatureDef('cash_flow', 'money', 'રોકડ પ્રવાહ', 'Cash Flow', 'chart', 'green', 'ખરીદનાર, ખેડૂત અને ખર્ચ મળીને કેટલી આવી અને ગઈ', 'Money in and out - buyers, farmers and expenses', side: true),
  FeatureDef('margin', 'money', 'માર્જિન વિશ્લેષણ', 'Margin Analysis', 'pct', 'violet', 'ખરીદ ભાવ સામે વેચાણ ભાવ અને પ્રોસેસનો આશરે નફો', 'Buy rate against sale rate and a rough processing result', side: true),
  FeatureDef('tally_live', 'tally', 'ડે બુક (Tally ડેટા)', 'Day Book (Tally Data)', 'book', 'violet', 'ખરો Tally ડેટા - ડે બુક, ખાતા, રોજમેળ, સ્ટોક (Tally માં કંઈ બદલાતું નથી)', 'Real Tally data - day book, ledgers, cash book, stock (nothing is changed in Tally)', side: true),
  FeatureDef('tally_pay', 'tally', 'Tally ચૂકવણી → ખેડૂત ખાતા', 'Tally Payments → Farmer Ledgers', 'pay', 'rose', 'Tally માં ખેડૂતને આપેલા પૈસા ઓળખીને ખેડૂત ખાતામાં એક ટેપથી ઉમેરો (ડુપ્લિકેટ બચાવ સાથે)', 'Spot farmer payments made in Tally and add them to the farmer khata in one tap (duplicates are guarded)', side: true),
  FeatureDef('tally_mel', 'tally', 'ખરીદી મેળ (Tally)', 'Purchase Check (Tally)', 'cmp', 'violet', 'Pro ની ચિઠ્ઠીની રકમ vs Tally ખરીદી વાઉચર - ફરક તરત દેખાય', 'Pro chit amounts vs Tally purchase vouchers - differences show at once'),
  FeatureDef('tally_age', 'tally', 'ઉઘરાણી / દેવા ઉંમર (Tally)', 'Receivable / payable ageing (Tally)', 'hist', 'amber', 'કોનું કેટલા દિવસથી બાકી - 30/60/90 દિવસ, WhatsApp રીમાઈન્ડર સાથે', 'Who owes for how many days - 30/60/90 buckets with WhatsApp reminders'),
  FeatureDef('tally_ledgers', 'tally', 'Tally ખાતા (લેજર)', 'Tally Ledgers', 'book', 'teal', 'બધા ખાતા - લેવાના, દેવાના, બેંક, રોકડ - બાકી સાથે', 'All ledgers - receivable, payable, bank, cash - with balances'),
  FeatureDef('tally_cash', 'tally', 'Tally રોજમેળ', 'Tally Cash Book', 'wallet', 'green', 'Tally નો રોકડ ચોપડો - દિવસ મુજબ આવક-જાવક', 'Tally cash book - receipts and payments day by day'),
  FeatureDef('tally_stock', 'tally', 'Tally સ્ટોક સમરી', 'Tally Stock Summary', 'warehouse', 'orange', 'Tally મુજબ સ્ટોક આઇટમ અને કિંમત', 'Stock items and value as in Tally'),
  FeatureDef('tally_sum', 'tally', 'Tally સારાંશ', 'Tally Summary', 'chart', 'blue', 'ખરીદી, વેચાણ, ચૂકવણી, આવકનો સારાંશ - WhatsApp પર મોકલો', 'Purchase, sales, payments, receipts summary - send on WhatsApp'),
  FeatureDef('tally_bank', 'tally', 'Tally બેંક બુક (UTR)', 'Tally Bank Book (UTR)', 'bank', 'blue', 'બેંક મુજબ આવક-જાવક, UTR સાથે, CSV કૉપિ', 'Bank-wise in and out with UTR, copy as CSV'),
  FeatureDef('tally_gst', 'tally', 'Tally GST અંદાજ', 'Tally GST Estimate', 'pct', 'amber', 'મહિના મુજબ Output / Input ટેક્સ (અંદાજ)', 'Month-wise output / input tax (estimate)'),
  FeatureDef('tally_check', 'tally', 'Tally ચેક્સ', 'Tally Checks', 'warn', 'rose', 'રોકડ મર્યાદા, 194Q અને સરખા વાઉચર - ધ્યાન દોરતી યાદી', 'Cash limits, 194Q and look-alike vouchers - a list to draw attention'),
  FeatureDef('export_money', 'money', 'હિસાબ એક્સપોર્ટ', 'Accounts Export', 'dl', 'blue', 'ચૂકવણી, ખર્ચ, વેચાણ, પ્રોસેસ, સ્ટોક, બાકી - Excel / Sheets માં', 'Payments, expenses, sales, processing, stock, balances - into Excel / Sheets'),

  // ------------------------------------------------------------- entries
  FeatureDef('chithi', 'entries', 'ચિઠ્ઠી યાદી', 'Chit List', 'receipt', 'teal', 'ખેતરેથી મજૂરે મોકલેલી બધી ચિઠ્ઠી', 'All chits sent from the field', side: true),
  FeatureDef('chithi_new', 'entries', 'ખરીદી વાઉચર (ચિઠ્ઠી)', 'Purchase Voucher (Chit)', 'plus', 'teal', 'ફોટો અને વજન સાથે નવી ચિઠ્ઠી', 'New chit with photo and weight', side: true),
  FeatureDef('kanta', 'entries', 'કાંટા યાદી', 'Kanta List', 'scale', 'blue', 'RST મુજબ કાંટા એન્ટ્રી', 'Weighbridge entries by RST', side: true),
  FeatureDef('kanta_new', 'entries', 'કાંટા એન્ટ્રી (વજન)', 'Weighbridge Entry (Kanta)', 'plus', 'blue', 'RST, ગાડી અને વજન', 'RST, vehicle and weight', side: true),
  FeatureDef('maal', 'entries', 'માલ યાદી', 'Maal List', 'bag', 'amber', 'બેગ મુજબ આવક-જાવક', 'Bags in and out', side: true),
  FeatureDef('maal_new', 'entries', 'માલ એન્ટ્રી', 'Maal Entry (Loading / Unloading)', 'plus', 'amber', 'લોડિંગ / અનલોડિંગ નોંધો', 'Record loading / unloading', side: true),
  FeatureDef('daily', 'entries', 'દૈનિક રજિસ્ટર', 'Daily Register', 'doc', 'teal', 'દિવસ મુજબ ચિઠ્ઠી, કાંટો, ફરક અને બેગ', 'Day-wise chits, kanta, difference and bags', side: true),
  FeatureDef('scan', 'entries', 'સ્લિપ સ્કેન', 'Scan Slip', 'scan', 'violet', 'સ્લિપનો ફોટો પાડો - વિગત આપોઆપ ભરાશે', 'Photograph a slip - the fields fill themselves', side: true),
  FeatureDef('weigh_check', 'entries', 'કાંટા ચેક', 'Weigh Check', 'balance', 'blue', 'ગાડી નંબર અને વજન લખો - ચિઠ્ઠી સાથે મેળ તરત દેખાય', 'Type vehicle and weight - see the match with chits at once'),
  FeatureDef('vehicle_lookup', 'entries', 'ગાડી શોધો', 'Vehicle Lookup', 'truck', 'teal', 'ગાડીનો પૂરો ઇતિહાસ એક જ જગ્યાએ', 'Full history of a vehicle in one place'),
  FeatureDef('my_day', 'entries', 'મારો દિવસ', 'My Day', 'user', 'teal', 'આજે મેં કરેલી એન્ટ્રી અને હિસાબ', 'The entries I made today and their total'),
  FeatureDef('maal_stock', 'entries', 'માલ સ્ટોક (ગોડાઉન)', 'Maal Stock (Godown)', 'warehouse', 'amber', 'ગોડાઉનમાં હાલ કેટલી બેગ - માલ, માલિક, ગોડાઉન મુજબ', 'Bags in the godown now - by material, owner, godown'),
  FeatureDef('maal_cross', 'entries', 'માલ ક્રોસ ટેબલ', 'Maal Cross Table', 'table', 'amber', 'માલિક × માલ નું બેગ ટેબલ', 'Owner × material table of bags'),

  // --------------------------------------------------------------- checks
  FeatureDef('bad_entries', 'ghat', 'ખોટા વજનની એન્ટ્રી', 'Wrong-weight entries', 'warn', 'rose', 'ટાઈપ ભૂલવાળા મોટા વજન - કુલ આંકડામાંથી બહાર, અહીંથી કાઢો', 'Impossible weights from typing mistakes - kept out of totals, delete them here'),
  FeatureDef('by_vehicle', 'ghat', 'ગાડી પ્રમાણે', 'By vehicle', 'truck', 'blue', 'કઈ ગાડીમાં વજન ઘટે છે', 'Which vehicle loses weight', side: true),
  FeatureDef('by_farmer', 'ghat', 'ખેડૂત પ્રમાણે', 'By farmer', 'agri', 'green', 'ખેડૂત મુજબ માલ અને ઘટ', 'Weight and loss per farmer', side: true),
  FeatureDef('by_village', 'ghat', 'ગામ પ્રમાણે', 'By village', 'place', 'orange', 'ગામ મુજબ માલ અને ઘટ', 'Weight and loss per village', side: true),
  FeatureDef('by_broker', 'ghat', 'દલાલ પ્રમાણે', 'By broker', 'handshake', 'violet', 'દલાલ મુજબ માલ અને ઘટ', 'Weight and loss per broker', side: true),
  FeatureDef('by_majur', 'ghat', 'મજૂર પ્રમાણે', 'By labour', 'users', 'teal', 'કયા મજૂરની ચિઠ્ઠીમાં ફરક આવે છે', 'Whose chits show a difference', side: true),
  FeatureDef('by_commodity', 'ghat', 'માલ પ્રમાણે', 'By material', 'grain', 'amber', 'મગફળી, એરંડા વગેરે મુજબ', 'Groundnut, castor and others'),
  FeatureDef('by_day', 'ghat', 'દિવસ પ્રમાણે', 'By day', 'cal', 'violet', 'કયા દિવસે કેટલો ફરક', 'Difference per day'),
  FeatureDef('missing_kanta', 'ghat', 'કાંટો બાકી', 'Chit without kanta', 'scale', 'rose', 'ચિઠ્ઠી છે પણ કાંટો નથી', 'Chit exists but no weighbridge entry', side: true),
  FeatureDef('missing_chit', 'ghat', 'ચિઠ્ઠી બની નથી', 'Kanta without chit', 'receipt', 'rose', 'કાંટાનું વજન છે પણ ચિઠ્ઠી નથી', 'Weighbridge entry without a chit', side: true),
  FeatureDef('rst_gap', 'ghat', 'RST ગુમ', 'RST missing', 'rule', 'rose', 'RST નંબરની શ્રેણીમાં ખૂટતા નંબર', 'Missing numbers in the RST series'),
  FeatureDef('dups', 'ghat', 'ડુપ્લિકેટ', 'Duplicates', 'copy', 'amber', 'બે વાર નોંધાયેલી ચિઠ્ઠી / RST', 'Chits or RST entered twice'),
  FeatureDef('no_photo', 'ghat', 'ફોટો વગરની એન્ટ્રી', 'Entries without photo', 'img', 'amber', 'સ્લિપનો ફોટો ન હોય તેવી એન્ટ્રી', 'Entries with no slip photo'),
  FeatureDef('odd', 'ghat', 'અજુગતી વિગત', 'Odd values', 'warn', 'amber', 'ખોટું લાગતું વજન કે ખાલી ગાડી નંબર', 'Wrong-looking weight or empty vehicle number'),
  FeatureDef('patterns', 'ghat', 'શંકાસ્પદ પેટર્ન', 'Suspicious patterns', 'query', 'rose', 'વારંવાર ઘટ, ગોળ વજન, એક જ વજન', 'Repeated loss, round or identical weights'),
  FeatureDef('history', 'ghat', 'ફેરફાર ઇતિહાસ', 'Edit History', 'hist', 'slate', 'કોણે શું સુધાર્યું કે કાઢ્યું - પાછું લાવો', 'Who edited or deleted what - restore it'),
  FeatureDef('loss_value', 'ghat', 'ઘટની કિંમત', 'Value of loss', 'pay', 'rose', 'ગુમ થયેલા વજનની ₹ માં કિંમત - મજૂર, ગાડી મુજબ', 'Rupee value of the lost weight - by labour, vehicle'),
  FeatureDef('tolerance', 'ghat', 'મર્યાદા અજમાવો', 'Try the limit', 'balance', 'violet', 'ઘટની મર્યાદા બદલો તો કેટલી ગાડી ફરકમાં આવે', 'How many trips fall outside if the limit changes'),
  FeatureDef('quality', 'ghat', 'ડેટા ગુણવત્તા', 'Data quality', 'verified', 'green', 'ફોટા, મોબાઇલ, ગાડી નંબર કેટલા ભરાયા - 0-100 સ્કોર', 'How well photos, mobiles and numbers are filled - 0-100'),
  FeatureDef('bag_stats', 'ghat', 'બેગનું વજન', 'Bag weights', 'bag', 'blue', 'KG પ્રતિ બેગ - અજુગતી ચિઠ્ઠી પકડો', 'KG per bag - catch odd chits'),
  FeatureDef('deductions', 'ghat', 'બારદાન / કરદો', 'Bardan / kardo', 'down', 'amber', 'કોણ કેટલી કપાત કરે છે', 'Who takes how much off the gross'),
  FeatureDef('digits', 'ghat', 'અંકની તપાસ', 'Digit check', 'query', 'rose', 'છેલ્લો અંક અને વારંવાર આવતા વજન - બનાવટી વજન પકડો', 'Last digits and repeated weights - spot made-up weights'),
  FeatureDef('plate_check', 'ghat', 'ગાડી નંબર તપાસ', 'Vehicle number check', 'truck', 'rose', 'ખોટા દેખાતા અને એક જેવા નંબર', 'Wrong-looking and look-alike numbers'),
  FeatureDef('name_check', 'ghat', 'નામ / મોબાઇલ તપાસ', 'Name / mobile check', 'users', 'amber', 'એક મોબાઇલ બે નામે, મળતા નામ, ખોટા મોબાઇલ', 'One mobile two names, look-alike names, bad mobiles'),
  FeatureDef('chit_gaps', 'ghat', 'ચિઠ્ઠી નંબર શ્રેણી', 'Chit number series', 'rule', 'rose', 'દરેક મજૂરની ચિઠ્ઠી શ્રેણીમાં ખૂટતા નંબર', 'Missing numbers in each person\'s chit series'),
  FeatureDef('rst_map', 'ghat', 'RST નકશો', 'RST map', 'grid', 'blue', 'દરેક RST એક ચોરસ - ખૂટતા અને બે વાર', 'Every RST as a square - missing and repeated'),
  FeatureDef('late_entry', 'ghat', 'મોડી ચિઠ્ઠી', 'Late chits', 'clock', 'amber', 'કાંટા પછી લખાયેલી ચિઠ્ઠી', 'Chits written after the truck was weighed'),
  FeatureDef('after_hours', 'ghat', 'રાતની એન્ટ્રી', 'Night entries', 'night', 'slate', 'રાત્રે થયેલી અજુગતી એન્ટ્રી', 'Entries made at night'),

  // ------------------------------------------------------------- insights
  FeatureDef('analytics', 'insight', 'વિશ્લેષણ', 'Analytics', 'insights', 'violet', 'કોઈ પણ સમયનું વજન, ફરક, ટોપ પાર્ટી - અગાઉના સમય સાથે સરખામણી', 'Weight, difference and top parties for any period - against the one before', side: true),
  FeatureDef('compare', 'insight', 'સરખામણી', 'Compare periods', 'swap', 'blue', 'આ અઠવાડિયું vs ગયું, આ મહિનો vs ગયો - બે સમય સામસામે', 'This week vs last, this month vs last - side by side', side: true),
  FeatureDef('hourly', 'insight', 'કયા કલાકે ભીડ', 'Peak hours', 'clock', 'amber', 'કયા કલાક અને વારે કાંટા પર ભીડ વધારે હોય છે', 'Which hours and weekdays are busiest at the weighbridge', side: true),
  FeatureDef('turnaround', 'insight', 'ગાડી કેટલી વાર', 'Turnaround time', 'speed', 'teal', 'ચિઠ્ઠીથી કાંટા સુધી ગાડીને કેટલા કલાક લાગે છે', 'Hours from chit to weighbridge', side: false),
  FeatureDef('risk', 'insight', 'જોખમ સ્કોર', 'Risk score', 'rank', 'rose', 'ખેડૂત / ગાડી / મજૂર / દલાલનો 0-100 સ્કોર - કોને પહેલા તપાસવો', 'A 0-100 score per farmer / vehicle / labour / broker - who to check first', side: true),
  FeatureDef('leaders', 'insight', 'ટોપ પાર્ટી', 'Top parties', 'chart', 'green', 'સૌથી વધુ માલ આપનાર અને 80/20 નો હિસાબ', 'Biggest suppliers and the 80/20 split', side: true),
  FeatureDef('ghat_trend', 'insight', 'ઘટ ટ્રેન્ડ', 'Loss trend', 'trenddown', 'orange', 'દિવસ અને અઠવાડિયા મુજબ ઘટ વધે છે કે ઘટે છે', 'Is the loss going up or down, by day and week'),
  FeatureDef('range_report', 'insight', 'રિપોર્ટ', 'Report', 'doc', 'slate', 'કોઈ પણ સમયનો WhatsApp રિપોર્ટ', 'A WhatsApp-ready report for any period'),
  FeatureDef('calendar', 'insight', 'કેલેન્ડર', 'Calendar', 'cal', 'violet', 'મહિનાનો દરેક દિવસ - માલ અને ફરક રંગથી', 'Every day of the month - weight and differences by colour'),
  FeatureDef('records', 'insight', 'રેકોર્ડ', 'Records', 'trophy', 'amber', 'સૌથી સારો / ખરાબ / મોટો - બધા ડેટામાંથી', 'Best, worst and biggest of everything loaded'),
  FeatureDef('forecast', 'insight', 'અંદાજ', 'Forecast', 'trend', 'blue', 'મહિનો ક્યાં પૂરો થશે - દરેક વારની સામાન્ય પેટર્ન પરથી', 'Where the month will end, from each weekday\'s usual pattern'),
  FeatureDef('pace', 'insight', 'આજની ઝડપ', 'Today\'s pace', 'speed', 'teal', 'આજ સુધી અને ગયા અઠવાડિયાનો એ જ વાર - કોણ આગળ', 'Today so far against the same weekday in past weeks'),
  FeatureDef('loads', 'insight', 'ગાડીનો ભાર', 'Load sizes', 'weight', 'orange', 'ગાડી કેટલી ભારે - ફેલાવો, સૌથી ભારે અને મર્યાદા ઉપર', 'How heavy the trucks are - spread, heaviest, over the limit'),
  FeatureDef('idle_gaps', 'insight', 'કાંટો ખાલી રહ્યો', 'Idle kanta gaps', 'hourglass', 'slate', 'કાંટા પર લાંબા ખાલી સમય', 'Long idle gaps on the weighbridge'),
  FeatureDef('cohort', 'insight', 'નવા અને જૂના ખેડૂત', 'New vs returning', 'users', 'green', 'નવા, ફરી આવનાર અને આવવાના બંધ થયેલા ખેડૂત', 'New farmers, returning farmers and the ones who stopped'),
  FeatureDef('farmer_due', 'insight', 'ક્યારે આવશે', 'Due to return', 'repeat', 'amber', 'જે ખેડૂત થોડા દિવસે આવતા અને હવે મોડા છે - ફોન કરો', 'Farmers who come every few days and are now late - call them'),
  FeatureDef('village_days', 'insight', 'ગામ × વાર', 'Village × weekday', 'place', 'orange', 'કયા ગામનો માલ કયા વારે આવે છે', 'Which village sends on which weekday'),
  FeatureDef('fleet', 'insight', 'ગાડીનો કાફલો', 'Fleet', 'truck', 'blue', 'ગાડી: ચાલુ, નવી, શાંત થયેલી અને ધીમી', 'Vehicles: active, new, gone quiet and slow'),
  FeatureDef('majur_work', 'insight', 'મજૂરનું કામ', 'Labour workload', 'badge', 'violet', 'કોણે કયા દિવસે કામ કર્યું - મજૂર × દિવસ ગ્રીડ', 'Who worked on which day - labour × day grid'),
  FeatureDef('party_compare', 'insight', 'બે પાર્ટી સામસામે', 'Compare two parties', 'swap', 'blue', 'બે ખેડૂત / દલાલ / ગામ / ગાડીની સરખામણી', 'Compare two farmers, brokers, villages or vehicles'),
  FeatureDef('movers', 'insight', 'વધ-ઘટ', 'Movers', 'trenddown', 'rose', 'પહેલાના સમય કરતાં કોણ વધુ કે ઓછો માલ મોકલે છે', 'Who sends more or less than in the period before'),
  FeatureDef('broker_book', 'insight', 'દલાલ ખાતાવહી', 'Broker book', 'handshake', 'violet', 'દલાલ મુજબ વધુ વિગત - ખેડૂત, ગામ, ઘટ', 'Brokers in more detail - farmers, villages, loss'),
  FeatureDef('village_book', 'insight', 'ગામ ખાતાવહી', 'Village book', 'place', 'orange', 'ગામ મુજબ વધુ વિગત - ખેડૂત, દલાલ, ઘટ', 'Villages in more detail - farmers, brokers, loss'),
  FeatureDef('monthly', 'insight', 'મહિના મુજબ', 'Month by month', 'month', 'teal', 'મહિના (કે અઠવાડિયા) મુજબ કુલ માલ, ગાડી અને ઘટ', 'Totals month by month (or week by week)'),

  // ----------------------------------------------------------- operations
  FeatureDef('live_board', 'ops', 'લાઇવ બોર્ડ', 'Live board', 'monitor', 'teal', 'ઑફિસ PC પર ખુલ્લું રાખો - આજે શું ચાલે છે તે એક નજરમાં', 'Leave it open on the office PC - today at a glance', side: true),
  FeatureDef('day_close', 'ops', 'દિવસ બંધ', 'Day Close', 'lock', 'rose', 'સાંજે દિવસ બંધ કરતા પહેલા બધું તપાસો', 'Check everything before you close the day', side: true),
  FeatureDef('feed', 'ops', 'ફીડ · બધી એન્ટ્રી', 'Feed', 'timeline', 'blue', 'કોણે શું ક્યારે નોંધ્યું - નવી એન્ટ્રી પર નિશાન', 'Who entered what and when - new entries are marked', side: true),
  FeatureDef('reviewed', 'ops', 'જોઈ લીધેલા', 'Checked alerts', 'verified', 'green', 'તમે "જોઈ લીધું" કરેલી શંકાઓ - પાછી લાવી શકાય', 'Alerts you marked as checked - bring back any time'),
  FeatureDef('staff', 'ops', 'સ્ટાફ પરફોર્મન્સ', 'Staff Performance', 'badge', 'violet', 'કોણે કેટલી એન્ટ્રી કરી, ફોટા કેટલા, ફરક કેટલા', 'Entries, photos and differences per person', side: true),
  FeatureDef('arrivals', 'ops', 'આવનાર ગાડી', 'Expected arrivals', 'hourglass', 'amber', 'રસ્તામાંની ગાડી કલાક મુજબ ક્યારે પહોંચશે', 'When the trucks on the way will reach, hour by hour'),
  FeatureDef('handover', 'ops', 'હૅન્ડઓવર', 'Handover', 'share', 'blue', 'આગળના માણસને શું ચાલે છે તેનો સંદેશ', 'A message telling the next person what is going on'),
  FeatureDef('routine', 'ops', 'રોજનું લિસ્ટ', 'Daily routine', 'todo', 'green', 'રોજના કામનું ટિક-લિસ્ટ', 'A tick-list of the daily jobs'),

  // ---------------------------------------------------------------- tools
  FeatureDef('parties', 'tools', 'પાર્ટી ડિરેક્ટરી', 'Party Directory', 'users', 'green', 'ખેડૂત, ગામ, દલાલ, ગાડી, મજૂરની પ્રોફાઇલ અને પિન', 'Profiles and pins for farmers, villages, brokers, vehicles, labour', side: true),
  FeatureDef('table', 'tools', 'ટેબલ વ્યૂ', 'Table View', 'table', 'slate', 'Excel જેવું ટેબલ - સોર્ટ, સર્ચ અને CSV', 'Spreadsheet view - sort, search and CSV', side: true),
  FeatureDef('export', 'tools', 'ડેટા એક્સપોર્ટ', 'Data Export', 'dl', 'blue', 'ચિઠ્ઠી, કાંટો, માલ, ગાડી - Excel / Sheets માં', 'Chits, kanta, maal, vehicles - into Excel / Sheets', side: true),
  FeatureDef('photo_wall', 'tools', 'સ્લિપ ફોટા', 'Slip photos', 'img', 'amber', 'બધી સ્લિપના ફોટા એક દીવાલ પર', 'All slip photos on one wall', side: true),
  FeatureDef('calc', 'tools', 'કેલ્ક્યુલેટર', 'Calculator', 'calc', 'teal', 'સેમ્પલ હિસાબ (દાણા, ઉતારો, હવા, ભાવ), કૅલ્ક્યુલેટર અને ઘટ તપાસ', 'Sample hisab (daana, utaro, hava, rate), calculator and loss check', side: true),
  FeatureDef('shortcuts', 'tools', 'કીબોર્ડ શોર્ટકટ', 'Keyboard shortcuts', 'keyboard', 'slate', 'PC પર ઝડપથી કામ કરવાની ચાવીઓ', 'Keys for working fast on the PC'),
  FeatureDef('statement', 'tools', 'સ્ટેટમેન્ટ', 'Statement', 'doc', 'teal', 'કોઈ પણ પાર્ટીનો હિસાબ - WhatsApp માટે', 'Any party\'s statement - for WhatsApp'),
  FeatureDef('mobiles', 'tools', 'ખેડૂતના મોબાઇલ', 'Farmer mobiles', 'phone', 'green', 'ચિઠ્ઠી પરથી બનેલી મોબાઇલ ડાયરી', 'A phone book built from the chits'),
  FeatureDef('notes', 'tools', 'નોંધો', 'Notes', 'note', 'amber', 'ખેડૂત / ગાડી / દલાલ વિશેની તમારી નોંધ', 'Your notes on farmers, vehicles and brokers'),
  FeatureDef('converter', 'tools', 'વજન કન્વર્ટર', 'Weight converter', 'weight', 'blue', 'KG · મણ · ક્વિન્ટલ · ટન · બેગ અને કિંમત', 'KG · mann · quintal · ton · bags and cost'),
  FeatureDef('recents', 'tools', 'હમણાં ખોલેલા', 'Recent', 'hist', 'slate', 'છેલ્લે ખોલેલી સ્ક્રીન અને પિન કરેલી પાર્ટી', 'Last screens opened and pinned parties'),
  FeatureDef('help', 'tools', 'મદદ', 'Help', 'bulb', 'teal', 'કામ કેવી રીતે કરવું - તમારા રોલ મુજબ સ્ટેપ', 'How to do each job - steps for your role', side: true),
  FeatureDef('diagnostics', 'tools', 'એપ તપાસ', 'App diagnostics', 'health', 'slate', 'સર્વર, સ્કેનર અને ડેટાની સ્થિતિ', 'Server, scanner and data status'),

  // ------------------------------------------------------------ settings
  FeatureDef('settings', 'admin', 'સેટિંગ', 'Settings', 'gear', 'slate', 'ખાતું, ઘટની મર્યાદા, દેખાવ', 'Account, difference limits, appearance', side: true),
  FeatureDef('offline_queue', 'admin', 'ઑફલાઇન કતાર (મોકલવાની બાકી)', 'Offline Queue (Waiting to Upload)', 'cloudup', 'blue', 'ઇન્ટરનેટ વગર સેવ કરેલી એન્ટ્રી', 'Entries saved without internet'),

  // ------------------------------------------------- new in 1.12 (beta)
  FeatureDef('gst_bill', 'money', 'GST બિલ', 'GST Invoices', 'percentbox', 'amber', 'Tally જેવા GST બિલ - નંબર, HSN, CGST/SGST/IGST, પ્રિન્ટ', 'Tally-like GST bills - numbering, HSN, CGST/SGST/IGST, print', status: _b),
  FeatureDef('trading', 'money', 'મિલ ગાડી (ટ્રેડિંગ)', 'Mill Trucks (Trading)', 'truck', 'blue', 'ગાડી સીધી મિલ - વજન, ભાવ, નફો અને GST બિલ', 'Direct mill trucks - weight, rates, profit and GST bill', status: _b),
  FeatureDef('bank_match', 'money', 'બેંક રિકન્સિલિએશન (UPI મેચ)', 'Bank Reconciliation (UPI Match)', 'bank', 'blue', 'બેંક statement paste કરો - ખેડૂત / ખરીદદાર / મિલ સાથે ઑટો મેળ', 'Paste the bank statement - matched with farmers, buyers and mills', status: _b),
  FeatureDef('debit_check', 'ghat', 'ડેબિટ નોટ તપાસ (ઘટ)', 'Debit-note Check (Short Weight)', 'fact', 'rose', 'ઘટવાળી ગાડીમાં ડેબિટ નોટ બાકી છે? Tally સાથે મેળ', 'Short trucks that still need a debit note - checked with Tally', status: _b),
  FeatureDef('backup', 'admin', 'બેકઅપ · લેપટોપ કૉપી', 'Backup · Laptop Copy', 'backup', 'blue', 'બધો હિસાબ ઑનલાઇન અને લેપટોપના ફોલ્ડરમાં - પાછો મૂકવાનું પણ', 'All accounts online and in a laptop folder - and restore', side: true),
  FeatureDef('kanta_auto', 'ops', 'કાંટો ઑટો (ફાઇલથી)', 'Auto Weighbridge (from File)', 'sync', 'slate', 'કાંટા ટર્મિનલ / સોફ્ટવેરની ફાઇલ (Matrix report) થી વજન એપમાં', 'Weights from the terminal / software file (Matrix report) into the app', status: _b),
  FeatureDef('kanta_usb', 'ops', 'કાંટો USB (લાઇવ)', 'Weighbridge USB (Live)', 'scale', 'blue', 'USB-RS232 કેબલથી કાંટાનું લાઇવ વજન અને સ્લિપ સીધી એપમાં', 'Live weight and slips from the weighbridge terminal over the USB-RS232 cable', status: _b),
  FeatureDef('kanta_remote', 'ops', 'કાંટો રિમોટ (ફોનથી)', 'Remote Weighing (from phone)', 'scale', 'violet', 'ફોનથી ગાડીનું વજન લો - કાંટા લેપટોપ પર થાય છે (કેમેરાથી ખાતરી કરીને)', 'Take a vehicle\'s weight from your phone - done by the weighbridge laptop (after checking on the camera)', status: _b),
  FeatureDef('kanta_khata', 'ops', 'કાંટા ખાતું (બાકી)', 'Weighbridge Khata (Baki)', 'ledger', 'rose', 'નામ મુજબ વજનના ચાર્જનું બાકી, જમા લખો, WhatsApp યાદ - કાંટા લેપટોપથી આપોઆપ', 'Weighing-charge baki per name, write jama, WhatsApp reminder - built by the weighbridge laptop', status: _b),
];

/// The screens that are shown in menus, lists and search (the GST ones are left out while GST is off).
/// Simple mode (core/flags.dart) is applied per person in [shownFor]: it hides things only from the owner's menus.
final List<FeatureDef> kFeatures = <FeatureDef>[for (final FeatureDef f in _kAllFeatures) if (screenOnFor(f.id, false)) f];

final Map<String, FeatureDef> _byId = <String, FeatureDef>{for (final FeatureDef f in _kAllFeatures) f.id: f};

FeatureDef? featureById(String id) => _byId[id];

List<FeatureDef> featuresIn(String group) => kFeatures.where((FeatureDef f) => f.group == group && shownFor(f, true)).toList();

/// Screens a worker (not the owner) may open.
const Set<String> kStaffIds = <String>{
  'dashboard', 'chithi', 'chithi_new', 'kanta', 'kanta_new', 'maal', 'maal_new', 'search', 'settings', 'offline_queue', 'calc',
  'scan', 'my_day', 'converter', 'recents', 'diagnostics', 'help', 'kanta_auto', 'kanta_usb',
};

bool allowedFor(FeatureDef f, bool admin) => admin || kStaffIds.contains(f.id);

/// May this person see the screen in a menu / list / search? (role + GST switch + the owner's simple mode)
bool shownFor(FeatureDef f, bool admin) => allowedFor(f, admin) && screenOnFor(f.id, admin);

/// The screen of an id for a menu / list: null when it is hidden (simple mode, GST, not allowed for this person) or unknown.
FeatureDef? shownById(String id, bool admin) {
  final FeatureDef? f = _byId[id];
  return (f != null && shownFor(f, admin)) ? f : null;
}

List<FeatureDef> visibleIn(String group, bool admin) =>
    kFeatures.where((FeatureDef f) => f.group == group && shownFor(f, admin)).toList();

List<GroupDef> visibleGroups(bool admin) =>
    kGroups.where((GroupDef g) => visibleIn(g.id, admin).isNotEmpty).toList();
