import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/device.dart';
import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/icons.dart';
import '../core/palette.dart';
import '../data/mock_db.dart';
import '../data/models.dart';
import '../widgets/charts.dart';
import '../widgets/common.dart';
import '../widgets/datagrid.dart';
import '../widgets/page.dart';
import 'entries.dart';
import 'tally.dart';

MockDb get _db => MockDb.I;

List<double> _dailyKg(int n) {
  final List<double> out = <double>[];
  for (int back = n - 1; back >= 0; back--) {
    final DateTime d = _db.today.subtract(Duration(days: back));
    double s = 0;
    for (final Entry e in _db.entries) {
      if (sameDay(e.dt, d)) s += e.net;
    }
    out.add(s);
  }
  return out;
}

List<double> _dailySales(int n, Firm? f) {
  final List<double> out = <double>[];
  for (int back = n - 1; back >= 0; back--) {
    final DateTime d = _db.today.subtract(Duration(days: back));
    double s = 0;
    for (final Voucher v in _db.vouchers) {
      if (v.type == 'Sales' && (f == null || v.firm == f) && sameDay(v.date, d)) s += v.amount;
    }
    out.add(s);
  }
  return out;
}

String _greeting() {
  final int h = DateTime.now().hour;
  if (h < 12) return bi('શુભ પ્રભાત', 'Good morning');
  if (h < 17) return bi('નમસ્તે', 'Good afternoon');
  return bi('શુભ સંધ્યા', 'Good evening');
}

class _Quick extends StatelessWidget {
  final String icon;
  final String label;
  final String tone;
  final VoidCallback onTap;
  const _Quick(this.icon, this.label, this.tone, this.onTap);

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    if (pc) {
      return Surface(
        onTap: onTap,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            IconChip(icon, tone: tone, size: 36),
            const SizedBox(width: 10),
            Text(label, style: ts(14, w: FontWeight.w700)),
          ],
        ),
      );
    }
    return Surface(
      onTap: onTap,
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 12),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          IconChip(icon, tone: tone, size: 46),
          const SizedBox(height: 8),
          Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: ts(12, w: FontWeight.w700)),
        ],
      ),
    );
  }
}

Widget alertTile(AlertItem a) {
  return Surface(
    margin: const EdgeInsets.only(bottom: 8),
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
    onTap: () => app.go(a.route, arg: a.arg),
    child: Row(
      children: <Widget>[
        IconChip(a.icon, tone: a.tone, size: 42),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(a.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(14, w: FontWeight.w800, h: 1.25)),
              const SizedBox(height: 2),
              Text(a.sub, maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(12.5, c: Pal.muted)),
            ],
          ),
        ),
        Icon(ic('chev'), size: 20, color: Pal.faint),
      ],
    ),
  );
}

Widget entryTile(BuildContext context, Entry e) {
  return Surface(
    margin: const EdgeInsets.only(bottom: 8),
    padding: const EdgeInsets.all(12),
    onTap: () => showEntryDetail(context, e),
    child: Row(
      children: <Widget>[
        Avatar(e.farmer.name, size: 42),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(e.farmer.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14.5, w: FontWeight.w800)),
              Text('#${e.no} · ${dayLabel(e.dt)} ${hm(e.dt)} · ${grp(e.net)} KG', maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12, c: Pal.muted)),
            ],
          ),
        ),
        const SizedBox(width: 8),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[
            Text(inr(e.amount), style: ts(15, w: FontWeight.w800, tab: true)),
            const SizedBox(height: 4),
            StatusPill(e.status, small: true),
          ],
        ),
      ],
    ),
  );
}

// ---------------------------------------------------------------- Dashboard
class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    final Firm? f = app.firm;
    final bool buy = f == null || !f.paka;

    final List<Entry> todayE = _db.entriesOn(_db.today);
    double tAmt = 0, tKg = 0;
    for (final Entry e in todayE) {
      tAmt += e.amount;
      tKg += e.net;
    }
    final List<double> kg14 = _dailyKg(14);
    final List<double> sales14 = _dailySales(14, f);
    final List<double> spark = buy ? kg14 : sales14;
    double s7 = 0;
    for (int i = sales14.length - 7; i < sales14.length; i++) {
      s7 += sales14[i];
    }

    final double cashBank = _db.cashBalance(f) + _db.bankBalance(f);
    final double rec = _db.receivable(f);
    final double pay = _db.payable(f);
    final double stock = _db.stockValue(f);
    final double profit = _db.netProfit(f, days: 30);

    final List<Widget> kpis = <Widget>[
      KpiCard(
        label: buy ? bi('આજની ખરીદી', 'Today purchase') : bi('7 દિવસનું વેચાણ', '7-day sales'),
        value: buy ? inrC(tAmt) : inrC(s7),
        icon: 'bag',
        tone: 'teal',
        row: !pc,
        spark: spark,
        onTap: () => app.go(buy ? 'entries' : 'sales_register'),
        delta: buy ? '${todayE.length} ${bi('એન્ટ્રી', 'entries')}' : null,
      ),
      KpiCard(label: bi('રોકડ + બેંક', 'Cash + Bank'), value: inrC(cashBank), icon: 'wallet', tone: 'amber', row: !pc, onTap: () => app.go('cash_book')),
      KpiCard(label: bi('લેણાં (ખરીદદાર)', 'Receivable'), value: inrC(rec), icon: 'ul', tone: 'green', row: !pc, onTap: () => app.go('receivables')),
      KpiCard(label: bi('દેવાં (ખેડૂત)', 'Payable'), value: inrC(pay), icon: 'dl', tone: 'rose', row: !pc, onTap: () => app.go('payables')),
      KpiCard(label: bi('સ્ટોક કિંમત', 'Stock value'), value: buy ? inrC(stock) : '–', icon: 'box', tone: 'orange', row: !pc, onTap: () => app.go('stock_summary')),
      KpiCard(label: bi('નફો (30 દિવસ)', 'Profit (30d)'), value: inrC(profit), icon: 'trend', tone: profit >= 0 ? 'green' : 'rose', row: !pc, onTap: () => app.go('pnl')),
    ];

    final Widget quick = Grid(
      cols: pc ? 5 : 4,
      gap: 10,
      children: <Widget>[
        _Quick('plus', bi('નવી એન્ટ્રી', 'New entry'), 'teal', () => app.go('new_entry')),
        _Quick('calc', bi('હિસાબ', 'Hisab'), 'amber', () => app.go('hisab')),
        _Quick('book', bi('ડે બુક', 'Day Book'), 'violet', () => app.go('daybook')),
        _Quick('search', bi('શોધો', 'Search'), 'blue', () => app.go('search')),
        if (pc) _Quick('apps', bi('બધા ફીચર', 'All features'), 'slate', () => app.go('hub')),
      ],
    );

    // ---- charts
    final List<String> labels14 = <String>[for (int i = 13; i >= 0; i--) '${_db.today.subtract(Duration(days: i)).day}'];
    final Widget trend = Panel(
      title: buy ? bi('છેલ્લા 14 દિવસની આવક (ટન)', 'Arrivals, last 14 days (tonnes)') : bi('છેલ્લા 14 દિવસનું વેચાણ', 'Sales, last 14 days'),
      child: BarChartX(
        values: spark,
        labels: labels14,
        color: Pal.teal,
        highlight: 13,
        height: pc ? 250 : 200,
        axisFmt: buy ? (double v) => '${(v / 1000).round()}T' : (double v) => inrC(v),
        valueFmt: buy ? (double v) => '${(v / 1000).round()}T' : (double v) => inrC(v),
      ),
    );

    final List<DonutPart> gp = <DonutPart>[];
    double gTotal = 0;
    for (final Entry e in _db.entriesInDays(30)) {
      gTotal += e.net;
    }
    for (int g = 0; g < 3; g++) {
      double k = 0;
      for (final Entry e in _db.entriesInDays(30)) {
        if (e.g == g) k += e.net;
      }
      gp.add(DonutPart(gradeName(g, shortName: true), k, gradeColor3(g)));
    }
    final Widget grades = Panel(
      title: bi('ગ્રેડ પ્રમાણે (30 દિવસ)', 'By grade (30 days)'),
      child: buy
          ? Wrap(
              spacing: 22,
              runSpacing: 14,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: <Widget>[
                DonutX(parts: gp, center: tons(gTotal), sub: bi('કુલ', 'total')),
                Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[for (final DonutPart d in gp) Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: LegendDot(d.color, d.label, value: tons(d.value)))],
                ),
              ],
            )
          : EmptyBox(icon: 'store', title: bi('ખરીદી ફક્ત Balaji New માં', 'Purchases only in Balaji New')),
    );

    // ---- lists
    final List<AlertItem> alerts = _db.alerts();
    final Widget alertsP = Panel(
      title: bi('ધ્યાનમાં લો', 'Attention'),
      action: GestureDetector(onTap: () => app.go('alerts'), child: Text(bi('બધું', 'All'), style: ts(13, w: FontWeight.w700, c: Pal.brand))),
      child: Column(children: <Widget>[for (final AlertItem a in alerts.take(4)) alertTile(a)]),
    );

    final List<Entry> recent = _db.entries.take(6).toList();
    final Widget recentP = pc
        ? Panel(
            flush: true,
            title: bi('તાજેતરની એન્ટ્રી', 'Recent entries'),
            action: GestureDetector(onTap: () => app.go('entries'), child: Text(bi('બધી', 'All'), style: ts(13, w: FontWeight.w700, c: Pal.brand))),
            child: DataGridX(
              pageSize: 6,
              onRow: (int i) => showEntryDetail(context, recent[i]),
              data: GridData(<Col>[
                Col(bi('ચિઠ્ઠી', 'Slip'), CK.text, w: 80),
                Col(bi('ખેડૂત', 'Farmer'), CK.text, w: 200, bold: true),
                Col(bi('સમય', 'When'), CK.text, w: 110),
                Col(bi('ગ્રેડ', 'Grade'), CK.text, w: 80),
                Col(bi('ચોખ્ખું KG', 'Net KG'), CK.kg, w: 110),
                Col(bi('રકમ', 'Amount'), CK.money, w: 120, main: true),
                Col(bi('સ્થિતિ', 'Status'), CK.status, w: 100),
              ], <List<Object?>>[
                for (final Entry e in recent) <Object?>['#${e.no}', e.farmer.name, '${dayLabel(e.dt)} ${hm(e.dt)}', gradeName(e.g, shortName: true), e.net, e.amount, e.status],
              ]),
            ),
          )
        : Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              SectionTitle(bi('તાજેતરની એન્ટ્રી', 'Recent entries'), action: GestureDetector(onTap: () => app.go('entries'), child: Text(bi('બધી', 'All'), style: ts(13, w: FontWeight.w700, c: Pal.brand)))),
              for (final Entry e in recent.take(5)) entryTile(context, e),
            ],
          );

    final Widget tallyP = Surface(
      onTap: () => app.go('tally_sync'),
      padding: const EdgeInsets.all(14),
      child: Row(
        children: <Widget>[
          IconChip('sync', tone: app.tallyOnline ? 'violet' : 'slate', size: 42),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text('Tally', style: ts(14.5, w: FontWeight.w800)),
                Text('${app.tallyOnline ? bi('ઓનલાઇન', 'Online') : bi('ઓફલાઇન', 'Offline')} · ${ago(app.lastSync)}', style: ts(12.5, c: Pal.muted)),
              ],
            ),
          ),
          Icon(ic('chev'), size: 20, color: Pal.faint),
        ],
      ),
    );

    // ---- ageing bars
    final Map<String, AgeBuckets> ag = _db.receivableAging();
    double a0 = 0, a1 = 0, a2 = 0, a3 = 0;
    ag.forEach((String k, AgeBuckets b) {
      a0 += b.b0;
      a1 += b.b1;
      a2 += b.b2;
      a3 += b.b3;
    });
    final Widget aging = Panel(
      title: bi('ખરીદદારનું બાકી — ઉંમર', 'Receivable ageing'),
      action: GestureDetector(onTap: () => app.go('aging'), child: Text(bi('વિગત', 'Details'), style: ts(13, w: FontWeight.w700, c: Pal.brand))),
      child: Column(
        children: <Widget>[
          StackBar(parts: <DonutPart>[
            DonutPart('0–30', a0, Pal.ok),
            DonutPart('31–60', a1, Pal.info),
            DonutPart('61–90', a2, Pal.warn),
            DonutPart('90+', a3, Pal.bad),
          ]),
          const SizedBox(height: 12),
          Wrap(spacing: 16, runSpacing: 6, children: <Widget>[
            LegendDot(Pal.ok, '0–30', value: inrC(a0)),
            LegendDot(Pal.info, '31–60', value: inrC(a1)),
            LegendDot(Pal.warn, '61–90', value: inrC(a2)),
            LegendDot(Pal.bad, '90+', value: inrC(a3)),
          ]),
        ],
      ),
    );

    final Widget head = pc
        ? Padding(
            padding: const EdgeInsets.only(bottom: 18),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text('${_greeting()} 👋', style: ts(26, w: FontWeight.w800, ls: -0.5)),
                      const SizedBox(height: 2),
                      Text('${dayName(_db.today)}, ${dmy(_db.today)}${f == null ? '' : ' · ${f.title}'}', style: ts(14, c: Pal.muted)),
                    ],
                  ),
                ),
                Btn(bi('નવી એન્ટ્રી', 'New entry'), icon: 'plus', onTap: () => app.go('new_entry')),
              ],
            ),
          )
        : Surface(
            color: Pal.side,
            border: false,
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text('${_greeting()} 👋', style: ts(13.5, c: Pal.sideText, w: FontWeight.w600)),
                const SizedBox(height: 6),
                Text(buy ? bi('આજની ખરીદી', 'Today purchase') : bi('7 દિવસનું વેચાણ', '7-day sales'), style: ts(12.5, c: Pal.sideText)),
                FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(buy ? inr(tAmt) : inr(s7), style: ts(34, w: FontWeight.w800, c: Colors.white, tab: true, ls: -1))),
                const SizedBox(height: 4),
                Text(buy ? '${todayE.length} ${bi('એન્ટ્રી', 'entries')} · ${grp(tKg)} KG' : dmy(_db.today), style: ts(13, c: Pal.amber, w: FontWeight.w700)),
                const SizedBox(height: 12),
                SizedBox(height: 40, width: double.infinity, child: Spark(values: spark, color: Pal.tealLight, fill: true)),
              ],
            ),
          );

    if (pc) {
      return ScreenScroll(
        children: <Widget>[
          head,
          Grid(cols: 3, gap: 14, children: kpis),
          const SizedBox(height: 14),
          quick,
          const SizedBox(height: 16),
          SplitPane(flex: const <int>[3, 2], children: <Widget>[trend, grades]),
          const SizedBox(height: 16),
          SplitPane(flex: const <int>[3, 2], children: <Widget>[
            recentP,
            Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: <Widget>[alertsP, const SizedBox(height: 16), aging, const SizedBox(height: 16), tallyP]),
          ]),
        ],
      );
    }
    return ScreenScroll(
      children: <Widget>[
        head,
        const SizedBox(height: 14),
        quick,
        const SizedBox(height: 14),
        for (int i = 0; i < kpis.length; i++) ...<Widget>[kpis[i], const SizedBox(height: 10)],
        const SizedBox(height: 4),
        alertsP,
        const SizedBox(height: 14),
        trend,
        const SizedBox(height: 14),
        grades,
        const SizedBox(height: 14),
        aging,
        const SizedBox(height: 14),
        recentP,
        const SizedBox(height: 6),
        tallyP,
      ],
    );
  }
}

Color gradeColor3(int g) => g == 0 ? Pal.teal : (g == 1 ? Pal.amber : Pal.violet);

// -------------------------------------------------------------------- Today
class TodayScreen extends StatelessWidget {
  const TodayScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    if (purchaseBlocked) {
      return ScreenScroll(children: <Widget>[ScreenHeader(bi('આજનો સારાંશ', 'Today summary')), purchaseGuard()]);
    }
    final List<Entry> l = _db.entriesOn(_db.today);
    double kg = 0, amt = 0, paid = 0, bags = 0;
    final List<double> gk = <double>[0, 0, 0];
    for (final Entry e in l) {
      kg += e.net;
      amt += e.amount;
      paid += e.paid;
      bags += e.bags;
      gk[e.g] += e.net;
    }
    double cashOut = 0;
    for (final Voucher v in _db.vouchersIn(firm: Firm.balaji, days: 1, type: 'Payment')) {
      if (v.cash) cashOut += v.amount;
    }
    final String text = <String>[
      '${bi('આજનો સારાંશ', 'Today summary')} · ${dmy(_db.today)}',
      '${bi('એન્ટ્રી', 'Entries')}: ${l.length}',
      '${bi('બેગ', 'Bags')}: ${grp(bags)}',
      '${bi('વજન', 'Weight')}: ${grp(kg)} KG',
      '${bi('કુલ રકમ', 'Total')}: ${inr(amt)}',
      '${bi('ચૂકવેલ', 'Paid')}: ${inr(paid)}',
      '${bi('બાકી', 'Due')}: ${inr(amt - paid)}',
    ].join('\n');

    final Widget kpis = Grid(
      cols: pc ? 4 : 2,
      gap: 12,
      children: <Widget>[
        KpiCard(label: bi('એન્ટ્રી', 'Entries'), value: '${l.length}', icon: 'list', tone: 'blue'),
        KpiCard(label: bi('વજન', 'Weight'), value: tons(kg), icon: 'scale', tone: 'amber'),
        KpiCard(label: bi('કુલ રકમ', 'Total'), value: inrC(amt), icon: 'rupee', tone: 'teal'),
        KpiCard(label: bi('બાકી', 'Due'), value: inrC(amt - paid), icon: 'clock', tone: 'rose'),
      ],
    );

    final Widget detail = Panel(
      title: bi('વિગત', 'Breakdown'),
      child: Column(
        children: <Widget>[
          InfoRow(bi('બેગ', 'Bags'), grp(bags)),
          InfoRow(bi('ચૂકવેલ', 'Paid'), inr(paid)),
          InfoRow(bi('આજની રોકડ જાવક', 'Cash paid out today'), inr(cashOut)),
          InfoRow(bi('સરેરાશ ભાવ / મણ', 'Avg rate / mann'), kg > 0 ? inr(amt / (kg / 20)) : '–'),
          const SizedBox(height: 10),
          for (int g = 0; g < 3; g++)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: ProgressRow(label: gradeName(g, shortName: true), value: gk[g], max: kg > 0 ? kg : 1, color: gradeColor3(g), trailing: '${grp(gk[g])} KG'),
            ),
          const SizedBox(height: 6),
          Btn(bi('WhatsApp લખાણ કૉપિ', 'Copy WhatsApp text'), icon: 'chat', expand: true, onTap: () => copyText(text)),
        ],
      ),
    );

    final Widget list = l.isEmpty
        ? EmptyBox(title: bi('આજે હજી એન્ટ્રી નથી', 'No entries yet today'))
        : Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: <Widget>[for (final Entry e in l) entryTile(context, e)]);

    return ScreenScroll(
      maxWidth: 1200,
      children: <Widget>[
        ScreenHeader(bi('આજનો સારાંશ', 'Today summary'), sub: dmy(_db.today)),
        if (!pc) Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(dmy(_db.today), style: ts(14, w: FontWeight.w700, c: Pal.muted))),
        kpis,
        const SizedBox(height: 14),
        SplitPane(flex: const <int>[2, 3], children: <Widget>[detail, Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: <Widget>[SectionTitle(bi('આજની એન્ટ્રી', "Today's entries")), list])]),
      ],
    );
  }
}

// ------------------------------------------------------------------- Alerts
class AlertsScreen extends StatelessWidget {
  const AlertsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    final List<AlertItem> a = _db.alerts();
    final Widget grid = pc
        ? Grid(cols: 2, gap: 12, children: <Widget>[for (final AlertItem x in a) alertTile(x)])
        : Column(children: <Widget>[for (final AlertItem x in a) alertTile(x)]);
    return ScreenScroll(
      maxWidth: 1100,
      children: <Widget>[
        ScreenHeader(bi('ધ્યાનમાં લો', 'Attention')),
        grid,
      ],
    );
  }
}

// ------------------------------------------------------------------ Search
class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final String q = _q.trim().toLowerCase();
    final List<Widget> out = <Widget>[];
    if (q.length >= 2) {
      final List<Party> parties = <Party>[..._db.farmers, ..._db.brokers, ..._db.buyers].where((Party p) => p.name.toLowerCase().contains(q) || p.phone.contains(q) || p.village.toLowerCase().contains(q)).take(8).toList();
      if (parties.isNotEmpty) {
        out.add(SectionTitle(bi('પાર્ટી', 'Parties')));
        for (final Party p in parties) {
          out.add(Surface(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(12),
            onTap: () => app.go('party', arg: p),
            child: Row(children: <Widget>[
              Avatar(p.name, size: 40),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[Text(p.name, style: ts(14.5, w: FontWeight.w800)), Text('${p.village} · ${p.phone}', style: ts(12, c: Pal.muted))])),
              Icon(ic('chev'), size: 20, color: Pal.faint),
            ]),
          ));
        }
      }
      final List<Entry> es = _db.entries.where((Entry e) => '${e.no} ${e.vehicle}'.toLowerCase().contains(q) || e.farmer.name.toLowerCase().contains(q)).take(8).toList();
      if (es.isNotEmpty) {
        out.add(SectionTitle(bi('એન્ટ્રી', 'Entries')));
        for (final Entry e in es) {
          out.add(entryTile(context, e));
        }
      }
      final List<Voucher> vs = _db.vouchers.where((Voucher v) => '${v.no} ${v.party} ${v.narration}'.toLowerCase().contains(q)).take(8).toList();
      if (vs.isNotEmpty) {
        out.add(SectionTitle(bi('વાઉચર', 'Vouchers')));
        for (final Voucher v in vs) {
          out.add(Surface(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(12),
            onTap: () => showVoucherDetail(context, v),
            child: Row(children: <Widget>[
              IconChip(voucherIcon(v.type), tone: voucherTone(v.type), size: 40),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[Text(v.party, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14.5, w: FontWeight.w800)), Text('${v.no} · ${v.firm.short} · ${dm(v.date)}', style: ts(12, c: Pal.muted))])),
              Text(inr(v.total), style: ts(14.5, w: FontWeight.w800, tab: true)),
            ]),
          ));
        }
      }
      if (out.isEmpty) out.add(EmptyBox(title: bi('કંઈ મળ્યું નથી', 'Nothing found')));
    }
    return ScreenScroll(
      maxWidth: 900,
      children: <Widget>[
        ScreenHeader(bi('બધે શોધો', 'Global search')),
        SearchBox(hint: bi('ખેડૂત, ગાડી, ચિઠ્ઠી, વાઉચર…', 'Farmer, vehicle, slip, voucher…'), onChanged: (String v) => setState(() => _q = v)),
        const SizedBox(height: 14),
        ...out,
      ],
    );
  }
}

// ----------------------------------------------------------------- Calendar
class CalendarScreen extends StatefulWidget {
  const CalendarScreen({super.key});

  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  late DateTime _month = DateTime(_db.today.year, _db.today.month, 1);
  DateTime? _sel;

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    final int days = DateTime(_month.year, _month.month + 1, 0).day;
    final int lead = _month.weekday - 1;
    final Map<int, double> kgBy = <int, double>{};
    final Map<int, int> nBy = <int, int>{};
    for (final Entry e in _db.entries) {
      if (e.dt.year == _month.year && e.dt.month == _month.month) {
        kgBy[e.dt.day] = (kgBy[e.dt.day] ?? 0) + e.net;
        nBy[e.dt.day] = (nBy[e.dt.day] ?? 0) + 1;
      }
    }
    double maxKg = 1;
    kgBy.forEach((int k, double v) {
      if (v > maxKg) maxKg = v;
    });

    final List<Widget> cells = <Widget>[];
    for (int i = 0; i < lead; i++) {
      cells.add(const SizedBox());
    }
    for (int d = 1; d <= days; d++) {
      final DateTime dt = DateTime(_month.year, _month.month, d);
      final double k = kgBy[d] ?? 0;
      final bool isToday = sameDay(dt, _db.today);
      final bool isSel = _sel != null && sameDay(dt, _sel!);
      cells.add(InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: () => setState(() => _sel = dt),
        child: Container(
          margin: const EdgeInsets.all(2),
          height: pc ? 74 : 54,
          padding: const EdgeInsets.all(5),
          decoration: BoxDecoration(
            color: k > 0 ? Pal.brand.withAlpha((30 + 120 * (k / maxKg)).round().clamp(0, 255).toInt()) : Pal.surface2,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: isSel ? Pal.brand : (isToday ? Pal.amber : Pal.line), width: isSel || isToday ? 1.8 : 1),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text('$d', style: ts(12.5, w: FontWeight.w800, c: isToday ? Pal.warn : Pal.ink)),
              if (k > 0) ...<Widget>[
                const Spacer(),
                Text(pc ? tons(k) : '${(k / 1000).round()}T', style: ts(pc ? 12 : 10.5, w: FontWeight.w700, c: Pal.muted, tab: true)),
              ],
            ],
          ),
        ),
      ));
    }
    final List<Widget> rows = <Widget>[];
    for (int i = 0; i < cells.length; i += 7) {
      final List<Widget> r = <Widget>[];
      for (int j = 0; j < 7; j++) {
        r.add(Expanded(child: i + j < cells.length ? cells[i + j] : const SizedBox()));
      }
      rows.add(Row(children: r));
    }

    final Widget header = Row(
      children: <Widget>[
        IconBtn('chevl', onTap: () => setState(() => _month = DateTime(_month.year, _month.month - 1, 1))),
        Expanded(child: Center(child: Text(monthYear(_month), style: ts(17, w: FontWeight.w800)))),
        IconBtn('chev', onTap: () => setState(() => _month = DateTime(_month.year, _month.month + 1, 1))),
      ],
    );
    final Widget week = Row(
      children: <Widget>[for (int i = 0; i < 7; i++) Expanded(child: Center(child: Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Text((L.gu ? kDayGu : kDayEn)[i], style: ts(12, w: FontWeight.w700, c: Pal.muted)))))],
    );

    final Widget cal = Panel(child: Column(children: <Widget>[header, const SizedBox(height: 6), week, ...rows]));

    final DateTime? sel = _sel;
    final List<Entry> selE = sel == null ? <Entry>[] : _db.entriesOn(sel);
    final Widget side = Panel(
      title: sel == null ? bi('તારીખ પસંદ કરો', 'Pick a date') : '${dayName(sel)}, ${dmy(sel)}',
      child: sel == null
          ? EmptyBox(icon: 'cal', title: bi('તારીખ દબાવો', 'Tap a date'))
          : (selE.isEmpty ? EmptyBox(title: bi('આ દિવસે એન્ટ્રી નથી', 'No entries that day')) : Column(children: <Widget>[for (final Entry e in selE) entryTile(context, e)])),
    );

    return ScreenScroll(
      maxWidth: 1200,
      children: <Widget>[
        ScreenHeader(bi('મહિના કેલેન્ડર', 'Month calendar')),
        SplitPane(flex: const <int>[3, 2], children: <Widget>[cal, side]),
      ],
    );
  }
}
