import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/device.dart';
import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/icons.dart';
import '../core/palette.dart';
import '../data/mock_db.dart';
import '../data/models.dart';
import '../widgets/common.dart';
import '../widgets/datagrid.dart';
import '../widgets/page.dart';
import 'parties.dart';

MockDb get _db => MockDb.I;

String modeName(String m) => m == 'cash' ? bi('રોકડ', 'Cash') : (m == 'bank' ? bi('બેંક', 'Bank') : 'UPI');

double numOf(String s) => double.tryParse(s.trim().replaceAll(',', '')) ?? 0;

/// Message for the farmer. Deliberately carries NO company name.
String farmerMessage(Entry e) {
  return <String>[
    bi('નમસ્તે ${e.farmer.name},', 'Hello ${e.farmer.name},'),
    bi('ચિઠ્ઠી #${e.no} · ${dmy(e.dt)}', 'Slip #${e.no} · ${dmy(e.dt)}'),
    bi('ગ્રેડ: ${gradeName(e.g)}', 'Grade: ${gradeName(e.g)}'),
    bi('ચોખ્ખું વજન: ${grp(e.net)} KG (${grp(e.mann, dec: 1)} મણ)', 'Net weight: ${grp(e.net)} KG (${grp(e.mann, dec: 1)} mann)'),
    bi('ભાવ: ${inr(e.rate)} / મણ', 'Rate: ${inr(e.rate)} / mann'),
    bi('કુલ રકમ: ${inr(e.amount)}', 'Total: ${inr(e.amount)}'),
    bi('ચૂકવેલ: ${inr(e.paid)}', 'Paid: ${inr(e.paid)}'),
    bi('બાકી: ${inr(e.due)}', 'Balance: ${inr(e.due)}'),
    bi('આભાર 🙏', 'Thank you 🙏'),
  ].join('\n');
}

/// Shown instead of a purchase screen when a paka (GST) firm is selected.
Widget purchaseGuard() {
  return Padding(
    padding: const EdgeInsets.only(top: 30),
    child: Column(
      children: <Widget>[
        EmptyBox(icon: 'store', title: bi('ખરીદી ફક્ત Balaji New માં લેવાય છે', 'Purchases are taken only in Balaji New')),
        const SizedBox(height: 12),
        Btn('Balaji New', icon: 'store', onTap: () => app.setFirm(Firm.balaji)),
      ],
    ),
  );
}

bool get purchaseBlocked => app.firm != null && app.firm!.paka;

// ------------------------------------------------------------ entry detail
void showEntryDetail(BuildContext context, Entry e) {
  openPanel(context, title: '#${e.no}', sub: '${dmy(e.dt)} · ${hm(e.dt)}', child: _EntryDetail(e));
}

class _EntryDetail extends StatelessWidget {
  final Entry e;
  const _EntryDetail(this.e);

  @override
  Widget build(BuildContext context) {
    Widget big(String label, String value, Color c) {
      return Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(label, style: ts(12, c: Pal.muted, w: FontWeight.w600)),
            const SizedBox(height: 2),
            Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(18, w: FontWeight.w800, c: c, tab: true, ls: -0.3)),
          ],
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Row(
          children: <Widget>[
            Avatar(e.farmer.name, size: 48),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(e.farmer.name, style: ts(16.5, w: FontWeight.w800)),
                  Text('${e.village} · ${e.farmer.phone}', style: ts(13, c: Pal.muted)),
                ],
              ),
            ),
            StatusPill(e.status),
          ],
        ),
        const SizedBox(height: 14),
        Surface(
          color: Pal.soft,
          border: false,
          shadow: false,
          padding: const EdgeInsets.all(14),
          child: Row(
            children: <Widget>[
              big(bi('કુલ રકમ', 'Total'), inr(e.amount), Pal.ink),
              big(bi('ચૂકવેલ', 'Paid'), inr(e.paid), Pal.ok),
              big(bi('બાકી', 'Due'), inr(e.due), e.due > 0.5 ? Pal.bad : Pal.muted),
            ],
          ),
        ),
        const SizedBox(height: 8),
        InfoRow(bi('ગાડી', 'Vehicle'), e.vehicle),
        InfoRow(bi('ગ્રેડ', 'Grade'), gradeName(e.g)),
        InfoRow(bi('ગોડાઉન', 'Godown'), godownName(e.godown)),
        InfoRow(bi('બેગ', 'Bags'), '${e.bags}'),
        InfoRow(bi('કુલ વજન', 'Gross weight'), '${grp(e.gross)} KG'),
        InfoRow(bi('હવા', 'Hava'), '${grp(e.hava)} KG'),
        InfoRow(bi('ચોખ્ખું વજન', 'Net weight'), '${grp(e.net)} KG', bold: true),
        InfoRow(bi('મણ (20 KG)', 'Mann (20 KG)'), grp(e.mann, dec: 2)),
        InfoRow(bi('ભાવ / મણ', 'Rate / mann'), inr(e.rate)),
        InfoRow(bi('ચૂકવણી રીત', 'Payment mode'), modeName(e.mode)),
        if (e.broker != null) InfoRow(bi('દલાલ', 'Broker'), '${e.broker!.name} · ${inr(e.commission)}'),
        const SizedBox(height: 14),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: <Widget>[
            Btn(bi('બિલ', 'Bill'), icon: 'receipt', onTap: () {
              Navigator.of(context).pop();
              app.go('bill_preview', arg: e);
            }),
            Btn(bi('WhatsApp લખાણ', 'WhatsApp text'), icon: 'chat', kind: BtnKind.tonal, onTap: () => copyText(farmerMessage(e), msg: bi('લખાણ કૉપિ થયું', 'Text copied'))),
            if (e.due > 0.5)
              Btn(bi('ચૂકવણી નોંધો', 'Record payment'), icon: 'pay', kind: BtnKind.amber, onTap: () {
                Navigator.of(context).pop();
                showPayPanel(context, e);
              }),
            Btn(bi('ખાતું', 'Account'), icon: 'user', kind: BtnKind.outline, onTap: () {
              Navigator.of(context).pop();
              app.go('party', arg: e.farmer);
            }),
          ],
        ),
      ],
    );
  }
}

// ----------------------------------------------------------------- payment
void showPayPanel(BuildContext context, Entry e) {
  openPanel(context, title: bi('ચૂકવણી નોંધો', 'Record payment'), sub: '#${e.no} · ${e.farmer.name}', width: 460, child: _PayForm(e));
}

class _PayForm extends StatefulWidget {
  final Entry e;
  const _PayForm(this.e);

  @override
  State<_PayForm> createState() => _PayFormState();
}

class _PayFormState extends State<_PayForm> {
  late final TextEditingController _amt = TextEditingController(text: widget.e.due.round().toString());
  int _mode = 0;

  @override
  void dispose() {
    _amt.dispose();
    super.dispose();
  }

  void _save() {
    final double a = numOf(_amt.text);
    if (a <= 0) {
      app.toast(bi('રકમ લખો', 'Enter an amount'));
      return;
    }
    final Entry e = widget.e;
    final double add = a > e.due ? e.due : a;
    final int i = _db.entries.indexWhere((Entry x) => x.no == e.no);
    if (i >= 0) {
      _db.entries[i] = Entry(
        no: e.no,
        dt: e.dt,
        farmer: e.farmer,
        broker: e.broker,
        vehicle: e.vehicle,
        village: e.village,
        g: e.g,
        godown: e.godown,
        bags: e.bags,
        gross: e.gross,
        hava: e.hava,
        rate: e.rate,
        amount: e.amount,
        paid: e.paid + add,
        mode: <String>['cash', 'bank', 'upi'][_mode],
      );
    }
    app.bump();
    Navigator.of(context).pop();
    app.toast(bi('${inr(add)} ચૂકવણી નોંધાઈ', '${inr(add)} payment recorded'));
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        InfoRow(bi('બાકી', 'Due'), inr(widget.e.due), bold: true, color: Pal.bad),
        const SizedBox(height: 10),
        FieldX(label: bi('ચૂકવેલ રકમ', 'Amount paid'), controller: _amt, prefix: '₹', big: true, keyboard: TextInputType.number),
        const SizedBox(height: 12),
        Seg(labels: <String>[modeName('cash'), modeName('bank'), modeName('upi')], index: _mode, onChanged: (int i) => setState(() => _mode = i)),
        const SizedBox(height: 16),
        Btn(bi('સાચવો', 'Save'), icon: 'check', expand: true, onTap: _save),
      ],
    );
  }
}

// ---------------------------------------------------------------- list page
class EntriesScreen extends StatefulWidget {
  const EntriesScreen({super.key});

  @override
  State<EntriesScreen> createState() => _EntriesScreenState();
}

class _EntriesScreenState extends State<EntriesScreen> {
  int _period = 1;
  int _grade = 0;
  int _stat = 0;
  String _q = '';
  int _shown = 30;
  final TextEditingController _qc = TextEditingController();

  static const List<int> _days = <int>[1, 7, 30, 100000];

  @override
  void dispose() {
    _qc.dispose();
    super.dispose();
  }

  List<Entry> _filtered() {
    final String q = _q.trim().toLowerCase();
    return _db.entriesInDays(_days[_period]).where((Entry e) {
      if (_grade > 0 && e.g != _grade - 1) return false;
      if (_stat == 1 && e.status != 'paid') return false;
      if (_stat == 2 && e.status != 'part') return false;
      if (_stat == 3 && e.status != 'due') return false;
      if (q.isNotEmpty) {
        final String hay = '${e.farmer.name} ${e.vehicle} ${e.no} ${e.village}'.toLowerCase();
        if (!hay.contains(q)) return false;
      }
      return true;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    if (purchaseBlocked) {
      return ScreenScroll(children: <Widget>[ScreenHeader(bi('એન્ટ્રીઓ', 'Entries')), purchaseGuard()]);
    }
    final List<Entry> list = _filtered();
    double kg = 0, amt = 0, due = 0;
    for (final Entry e in list) {
      kg += e.net;
      amt += e.amount;
      due += e.due;
    }

    final Widget period = Seg(
      dense: true,
      labels: <String>[bi('આજે', 'Today'), bi('7 દિવસ', '7d'), bi('30 દિવસ', '30d'), bi('બધું', 'All')],
      index: _period,
      onChanged: (int i) => setState(() {
        _period = i;
        _shown = 30;
      }),
    );
    final Widget search = SearchBox(
      hint: bi('ખેડૂત, ગાડી, ચિઠ્ઠી…', 'Farmer, vehicle, slip…'),
      controller: _qc,
      width: pc ? 300 : null,
      onChanged: (String v) => setState(() {
        _q = v;
        _shown = 30;
      }),
    );
    final Widget chips = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        ChipRow(
          labels: <String>[bi('બધા ગ્રેડ', 'All grades'), gradeName(0, shortName: true), gradeName(1, shortName: true), gradeName(2, shortName: true)],
          index: _grade,
          onChanged: (int i) => setState(() => _grade = i),
        ),
        const SizedBox(height: 8),
        ChipRow(
          labels: <String>[bi('બધા', 'All'), statusText('paid'), statusText('part'), statusText('due')],
          index: _stat,
          onChanged: (int i) => setState(() => _stat = i),
        ),
      ],
    );

    final Widget summary = pc
        ? Grid(cols: 4, gap: 12, children: <Widget>[
            KpiCard(label: bi('એન્ટ્રી', 'Entries'), value: grp(list.length), icon: 'list', tone: 'blue'),
            KpiCard(label: bi('ચોખ્ખું વજન', 'Net weight'), value: tons(kg), icon: 'scale', tone: 'amber'),
            KpiCard(label: bi('કુલ રકમ', 'Total value'), value: inrC(amt), icon: 'rupee', tone: 'teal'),
            KpiCard(label: bi('બાકી', 'Due'), value: inrC(due), icon: 'clock', tone: 'rose'),
          ])
        : Surface(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            child: Row(
              children: <Widget>[
                _stat3(bi('એન્ટ્રી', 'Entries'), grp(list.length), Pal.ink),
                _stat3(bi('વજન', 'Weight'), tons(kg), Pal.ink),
                _stat3(bi('રકમ', 'Value'), inrC(amt), Pal.brand),
                _stat3(bi('બાકી', 'Due'), inrC(due), Pal.bad),
              ],
            ),
          );

    Widget body;
    if (list.isEmpty) {
      body = EmptyBox(title: bi('કોઈ એન્ટ્રી નથી', 'No entries'));
    } else if (pc) {
      final GridData g = GridData(<Col>[
        Col(bi('ચિઠ્ઠી', 'Slip'), CK.text, w: 90),
        Col(bi('તારીખ', 'Date'), CK.date, w: 120),
        Col(bi('ખેડૂત', 'Farmer'), CK.text, w: 210, bold: true),
        Col(bi('ગામ', 'Village'), CK.text, w: 120),
        Col(bi('ગાડી', 'Vehicle'), CK.text, w: 140),
        Col(bi('ગ્રેડ', 'Grade'), CK.text, w: 90),
        Col(bi('બેગ', 'Bags'), CK.count, w: 70),
        Col(bi('ચોખ્ખું KG', 'Net KG'), CK.kg, w: 110),
        Col(bi('ભાવ/મણ', 'Rate'), CK.money, w: 100),
        Col(bi('રકમ', 'Amount'), CK.money, w: 120, main: true),
        Col(bi('ચૂકવેલ', 'Paid'), CK.money, w: 110),
        Col(bi('બાકી', 'Due'), CK.money, w: 110),
        Col(bi('સ્થિતિ', 'Status'), CK.status, w: 100),
      ], <List<Object?>>[
        for (final Entry e in list)
          <Object?>['#${e.no}', e.dt, e.farmer.name, e.village, e.vehicle, gradeName(e.g, shortName: true), e.bags, e.net, e.rate, e.amount, e.paid, e.due, e.status],
      ]);
      body = Panel(
        flush: true,
        title: bi('બધી એન્ટ્રી', 'All entries'),
        child: DataGridX(data: g, pageSize: 15, onRow: (int i) => showEntryDetail(context, list[i])),
      );
    } else {
      body = _phoneList(list);
    }

    return ScreenScroll(
      children: <Widget>[
        ScreenHeader(
          bi('એન્ટ્રીઓ', 'Entries'),
          actions: <Widget>[period, search, Btn(bi('નવી એન્ટ્રી', 'New entry'), icon: 'plus', onTap: () => app.go('new_entry'))],
        ),
        if (!pc) ...<Widget>[
          Row(children: <Widget>[Expanded(child: period)]),
          const SizedBox(height: 10),
          search,
          const SizedBox(height: 10),
        ],
        summary,
        const SizedBox(height: 12),
        Align(alignment: Alignment.centerLeft, child: chips),
        const SizedBox(height: 12),
        body,
      ],
    );
  }

  Widget _stat3(String label, String value, Color c) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(label, style: ts(11.5, c: Pal.muted, w: FontWeight.w600)),
          const SizedBox(height: 2),
          FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(value, style: ts(16, w: FontWeight.w800, c: c, tab: true))),
        ],
      ),
    );
  }

  Widget _phoneList(List<Entry> list) {
    final List<Widget> out = <Widget>[];
    DateTime? day;
    final int count = list.length > _shown ? _shown : list.length;
    for (int i = 0; i < count; i++) {
      final Entry e = list[i];
      final DateTime d = dateOnly(e.dt);
      if (day == null || !sameDay(day, d)) {
        day = d;
        double t = 0;
        for (final Entry x in list) {
          if (sameDay(x.dt, d)) t += x.amount;
        }
        out.add(Padding(
          padding: const EdgeInsets.fromLTRB(4, 8, 4, 8),
          child: Row(
            children: <Widget>[
              Text(dayLabel(d), style: ts(13.5, w: FontWeight.w800, c: Pal.muted)),
              const Spacer(),
              Text(inrC(t), style: ts(13.5, w: FontWeight.w800, c: Pal.muted, tab: true)),
            ],
          ),
        ));
      }
      out.add(Surface(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(12),
        onTap: () => showEntryDetail(context, e),
        child: Row(
          children: <Widget>[
            Avatar(e.farmer.name, size: 44),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(e.farmer.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14.5, w: FontWeight.w800)),
                  const SizedBox(height: 2),
                  Text('#${e.no} · ${hm(e.dt)} · ${e.vehicle.substring(e.vehicle.length - 4)}', style: ts(12, c: Pal.muted)),
                  const SizedBox(height: 6),
                  Row(
                    children: <Widget>[
                      Pill(gradeName(e.g, shortName: true), tone: e.g == 0 ? 'teal' : (e.g == 1 ? 'amber' : 'violet'), small: true),
                      const SizedBox(width: 8),
                      Text('${grp(e.net)} KG', style: ts(12.5, w: FontWeight.w700, c: Pal.muted, tab: true)),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Text(inr(e.amount), style: ts(15.5, w: FontWeight.w800, tab: true)),
                const SizedBox(height: 6),
                StatusPill(e.status, small: true),
              ],
            ),
          ],
        ),
      ));
    }
    if (list.length > count) {
      out.add(Btn(bi('વધુ બતાવો (${list.length - count})', 'Show more (${list.length - count})'),
          kind: BtnKind.tonal, expand: true, onTap: () => setState(() => _shown += 30)));
    }
    return Column(children: out);
  }
}

// ---------------------------------------------------------------- new entry
class NewEntryScreen extends StatefulWidget {
  final Object? arg;
  const NewEntryScreen({super.key, this.arg});

  @override
  State<NewEntryScreen> createState() => _NewEntryScreenState();
}

class _NewEntryScreenState extends State<NewEntryScreen> {
  Party? _farmer;
  Party? _broker;
  String _vehicle = kVehicles[0];
  int _g = 0;
  int _godown = 0;
  int _mode = 0;
  final TextEditingController _bags = TextEditingController();
  final TextEditingController _gross = TextEditingController();
  final TextEditingController _hava = TextEditingController();
  late final TextEditingController _rate = TextEditingController(text: _db.rates[0].round().toString());
  final TextEditingController _paid = TextEditingController();

  @override
  void initState() {
    super.initState();
    final Object? a = widget.arg;
    if (a is Map<String, double>) {
      if (a['bags'] != null) _bags.text = a['bags']!.round().toString();
      if (a['gross'] != null) _gross.text = a['gross']!.round().toString();
      if (a['hava'] != null) _hava.text = a['hava']!.round().toString();
      if (a['rate'] != null) _rate.text = a['rate']!.round().toString();
    }
  }

  @override
  void dispose() {
    _bags.dispose();
    _gross.dispose();
    _hava.dispose();
    _rate.dispose();
    _paid.dispose();
    super.dispose();
  }

  double get _net => numOf(_gross.text) - numOf(_hava.text);
  double get _amount => (_net / 20 * numOf(_rate.text)).roundToDouble();
  double get _paidN => numOf(_paid.text) > _amount ? _amount : numOf(_paid.text);
  double get _commission => _broker == null ? 0 : (_net / 20 * 2).roundToDouble();

  void _refresh([String? _]) => setState(() {});

  void _save() {
    if (_farmer == null) {
      app.toast(bi('ખેડૂત પસંદ કરો', 'Choose a farmer'));
      return;
    }
    if (numOf(_gross.text) <= 0 || numOf(_rate.text) <= 0 || _net <= 0) {
      app.toast(bi('વજન અને ભાવ લખો', 'Enter weight and rate'));
      return;
    }
    final Entry e = Entry(
      no: _db.nextEntryNo,
      dt: DateTime.now(),
      farmer: _farmer!,
      broker: _broker,
      vehicle: _vehicle,
      village: _farmer!.village,
      g: _g,
      godown: _godown,
      bags: numOf(_bags.text).round(),
      gross: numOf(_gross.text),
      hava: numOf(_hava.text),
      rate: numOf(_rate.text),
      amount: _amount,
      paid: _paidN,
      mode: <String>['cash', 'bank', 'upi'][_mode],
    );
    _db.addEntry(e);
    app.bump();
    setState(() {
      _farmer = null;
      _broker = null;
      _bags.clear();
      _gross.clear();
      _hava.clear();
      _paid.clear();
    });
    app.toast(bi('એન્ટ્રી #${e.no} સાચવાઈ', 'Entry #${e.no} saved'));
    showEntryDetail(context, e);
  }

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    if (purchaseBlocked) {
      return ScreenScroll(children: <Widget>[ScreenHeader(bi('નવી એન્ટ્રી', 'New entry')), purchaseGuard()]);
    }

    final Widget farmerPick = _PartyField(
      label: bi('ખેડૂત', 'Farmer'),
      value: _farmer?.name,
      hint: bi('ખેડૂત પસંદ કરો', 'Choose farmer'),
      icon: 'agri',
      onTap: () => showPartyPicker(context, _db.farmers, (Party p) => setState(() => _farmer = p)),
    );
    final Widget brokerPick = _PartyField(
      label: bi('દલાલ (વૈકલ્પિક)', 'Broker (optional)'),
      value: _broker?.name,
      hint: bi('દલાલ વગર', 'No broker'),
      icon: 'handshake',
      onTap: () => showPartyPicker(context, _db.brokers, (Party p) => setState(() => _broker = p), allowNone: () => setState(() => _broker = null)),
    );
    final Widget vehicle = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(bi('ગાડી', 'Vehicle'), style: ts(12.5, w: FontWeight.w600, c: Pal.muted)),
        const SizedBox(height: 6),
        PickX<String>(label: _vehicle, icon: 'truck', items: kVehicles, text: (String s) => s, onSelected: (String s) => setState(() => _vehicle = s)),
      ],
    );
    final Widget grade = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(bi('ગ્રેડ', 'Grade'), style: ts(12.5, w: FontWeight.w600, c: Pal.muted)),
        const SizedBox(height: 6),
        Seg(
          labels: <String>[for (int g = 0; g < 3; g++) gradeName(g, shortName: true)],
          index: _g,
          onChanged: (int i) => setState(() {
            _g = i;
            _rate.text = _db.rates[i].round().toString();
          }),
        ),
      ],
    );
    final Widget godown = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(bi('ગોડાઉન', 'Godown'), style: ts(12.5, w: FontWeight.w600, c: Pal.muted)),
        const SizedBox(height: 6),
        Seg(labels: <String>[for (int g = 0; g < 3; g++) godownName(g)], index: _godown, onChanged: (int i) => setState(() => _godown = i)),
      ],
    );
    final Widget mode = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(bi('ચૂકવણી રીત', 'Payment mode'), style: ts(12.5, w: FontWeight.w600, c: Pal.muted)),
        const SizedBox(height: 6),
        Seg(labels: <String>[modeName('cash'), modeName('bank'), modeName('upi')], index: _mode, onChanged: (int i) => setState(() => _mode = i)),
      ],
    );

    final Widget form = Panel(
      title: pc ? bi('ચિઠ્ઠીની વિગત', 'Slip details') : null,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          SplitPane(gap: 14, children: <Widget>[farmerPick, brokerPick]),
          const SizedBox(height: 14),
          SplitPane(gap: 14, children: <Widget>[vehicle, godown]),
          const SizedBox(height: 14),
          grade,
          const SizedBox(height: 14),
          SplitPane(gap: 14, children: <Widget>[
            FieldX(label: bi('બેગ', 'Bags'), controller: _bags, keyboard: TextInputType.number, suffix: bi('બેગ', 'bags'), onChanged: _refresh),
            FieldX(label: bi('કુલ વજન', 'Gross weight'), controller: _gross, keyboard: TextInputType.number, suffix: 'KG', onChanged: _refresh),
          ]),
          const SizedBox(height: 14),
          SplitPane(gap: 14, children: <Widget>[
            FieldX(label: bi('હવા / ઘટ', 'Hava'), controller: _hava, keyboard: TextInputType.number, suffix: 'KG', onChanged: _refresh),
            FieldX(label: bi('ભાવ (20 KG)', 'Rate (20 KG)'), controller: _rate, keyboard: TextInputType.number, prefix: '₹', onChanged: _refresh),
          ]),
          const SizedBox(height: 14),
          SplitPane(gap: 14, children: <Widget>[
            FieldX(label: bi('આપેલ રકમ', 'Paid now'), controller: _paid, keyboard: TextInputType.number, prefix: '₹', onChanged: _refresh),
            mode,
          ]),
        ],
      ),
    );

    final Widget sum = Surface(
      color: Pal.side,
      border: false,
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(bi('કુલ રકમ', 'Total amount'), style: ts(13, c: Pal.sideText, w: FontWeight.w600)),
          const SizedBox(height: 2),
          FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(inr(_amount), style: ts(34, w: FontWeight.w800, c: Colors.white, tab: true, ls: -1))),
          const SizedBox(height: 14),
          _sumLine(bi('ચોખ્ખું વજન', 'Net weight'), '${grp(_net < 0 ? 0 : _net)} KG'),
          _sumLine(bi('મણ', 'Mann'), grp(_net < 0 ? 0 : _net / 20, dec: 2)),
          _sumLine(bi('ચૂકવેલ', 'Paid'), inr(_paidN)),
          _sumLine(bi('બાકી', 'Due'), inr(_amount - _paidN), strong: true),
          if (_broker != null) _sumLine(bi('દલાલી', 'Brokerage'), inr(_commission)),
          const SizedBox(height: 14),
          Btn(bi('સાચવો', 'Save entry'), icon: 'check', expand: true, kind: BtnKind.amber, onTap: _save),
        ],
      ),
    );

    return ScreenScroll(
      maxWidth: 1180,
      children: <Widget>[
        ScreenHeader(bi('નવી એન્ટ્રી', 'New entry')),
        if (pc)
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[Expanded(flex: 3, child: form), const SizedBox(width: 16), Expanded(flex: 2, child: sum)],
          )
        else ...<Widget>[form, const SizedBox(height: 14), sum],
      ],
    );
  }

  Widget _sumLine(String l, String v, {bool strong = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: <Widget>[
          Expanded(child: Text(l, style: ts(13.5, c: Pal.sideText))),
          Text(v, style: ts(strong ? 17 : 14, w: strong ? FontWeight.w800 : FontWeight.w700, c: strong ? Pal.amber : Colors.white, tab: true)),
        ],
      ),
    );
  }
}

class _PartyField extends StatelessWidget {
  final String label;
  final String? value;
  final String hint;
  final String icon;
  final VoidCallback onTap;
  const _PartyField({required this.label, required this.value, required this.hint, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(label, style: ts(12.5, w: FontWeight.w600, c: Pal.muted)),
        const SizedBox(height: 6),
        InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onTap,
          child: Container(
            height: 48,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(color: Pal.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: Pal.line, width: 1.2)),
            child: Row(
              children: <Widget>[
                Icon(ic(icon), size: 19, color: Pal.muted),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(value ?? hint, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(15, w: value == null ? FontWeight.w500 : FontWeight.w700, c: value == null ? Pal.faint : Pal.ink)),
                ),
                Icon(ic('down'), size: 20, color: Pal.muted),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

// ------------------------------------------------------------ hisab calc
class HisabScreen extends StatefulWidget {
  const HisabScreen({super.key});

  @override
  State<HisabScreen> createState() => _HisabScreenState();
}

class _HisabScreenState extends State<HisabScreen> {
  final TextEditingController _gross = TextEditingController();
  final TextEditingController _hava = TextEditingController();
  final TextEditingController _rate = TextEditingController(text: MockDb.I.rates[0].round().toString());
  final TextEditingController _bags = TextEditingController();
  final TextEditingController _hamali = TextEditingController();
  final TextEditingController _adv = TextEditingController();

  @override
  void dispose() {
    _gross.dispose();
    _hava.dispose();
    _rate.dispose();
    _bags.dispose();
    _hamali.dispose();
    _adv.dispose();
    super.dispose();
  }

  void _r([String? _]) => setState(() {});

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    final double net = numOf(_gross.text) - numOf(_hava.text);
    final double mann = net < 0 ? 0 : net / 20;
    final double amount = (mann * numOf(_rate.text)).roundToDouble();
    final double ham = numOf(_bags.text) * numOf(_hamali.text);
    final double pay = amount - ham - numOf(_adv.text);

    final Widget inputs = Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text(bi('આજનો ભાવ (20 KG)', 'Today rate (20 KG)'), style: ts(12.5, w: FontWeight.w600, c: Pal.muted)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <Widget>[
              for (int g = 0; g < 3; g++)
                InkWell(
                  borderRadius: BorderRadius.circular(99),
                  onTap: () => setState(() => _rate.text = MockDb.I.rates[g].round().toString()),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(color: Pal.soft, borderRadius: BorderRadius.circular(99)),
                    child: Text('${gradeName(g, shortName: true)}  ${inr(MockDb.I.rates[g])}', style: ts(13.5, w: FontWeight.w800, c: Pal.brand, tab: true)),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 14),
          SplitPane(gap: 14, children: <Widget>[
            FieldX(label: bi('કુલ વજન', 'Gross weight'), controller: _gross, keyboard: TextInputType.number, suffix: 'KG', big: true, onChanged: _r),
            FieldX(label: bi('હવા / ઘટ', 'Hava'), controller: _hava, keyboard: TextInputType.number, suffix: 'KG', big: true, onChanged: _r),
          ]),
          const SizedBox(height: 14),
          SplitPane(gap: 14, children: <Widget>[
            FieldX(label: bi('ભાવ (20 KG)', 'Rate (20 KG)'), controller: _rate, keyboard: TextInputType.number, prefix: '₹', onChanged: _r),
            FieldX(label: bi('બેગ', 'Bags'), controller: _bags, keyboard: TextInputType.number, suffix: bi('બેગ', 'bags'), onChanged: _r),
          ]),
          const SizedBox(height: 14),
          SplitPane(gap: 14, children: <Widget>[
            FieldX(label: bi('હમાલી / બેગ', 'Hamali / bag'), controller: _hamali, keyboard: TextInputType.number, prefix: '₹', onChanged: _r),
            FieldX(label: bi('એડવાન્સ કપાત', 'Advance deduction'), controller: _adv, keyboard: TextInputType.number, prefix: '₹', onChanged: _r),
          ]),
        ],
      ),
    );

    final Widget result = Surface(
      color: Pal.side,
      border: false,
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(bi('ચૂકવવાની રકમ', 'Net payable'), style: ts(13, c: Pal.sideText, w: FontWeight.w600)),
          FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(inr(pay), style: ts(36, w: FontWeight.w800, c: Colors.white, tab: true, ls: -1))),
          const SizedBox(height: 12),
          _line(bi('ચોખ્ખું વજન', 'Net weight'), '${grp(net < 0 ? 0 : net)} KG'),
          _line(bi('મણ', 'Mann'), grp(mann, dec: 2)),
          _line(bi('કુલ રકમ', 'Gross amount'), inr(amount)),
          _line(bi('હમાલી', 'Hamali'), '- ${inr(ham)}'),
          _line(bi('એડવાન્સ', 'Advance'), '- ${inr(numOf(_adv.text))}'),
          _line(bi('પ્રતિ KG ભાવ', 'Rate per KG'), net > 0 ? inr(amount / net, dec: 2) : '–'),
          const SizedBox(height: 14),
          Row(
            children: <Widget>[
              tExp(
                child: Btn(bi('નવી એન્ટ્રી', 'Make entry'), icon: 'plus', kind: BtnKind.amber, onTap: () {
                  app.go('new_entry', arg: <String, double>{
                    'gross': numOf(_gross.text),
                    'hava': numOf(_hava.text),
                    'rate': numOf(_rate.text),
                    'bags': numOf(_bags.text),
                  });
                }),
              ),
              const SizedBox(width: 8),
              IconBtn('undo', tip: bi('સાફ', 'Clear'), bg: const Color(0x22FFFFFF), color: Colors.white, onTap: () {
                setState(() {
                  _gross.clear();
                  _hava.clear();
                  _bags.clear();
                  _hamali.clear();
                  _adv.clear();
                });
              }),
            ],
          ),
        ],
      ),
    );

    return ScreenScroll(
      maxWidth: 1100,
      children: <Widget>[
        ScreenHeader(bi('હિસાબ કેલ્ક્યુલેટર', 'Hisab calculator')),
        if (pc)
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[Expanded(flex: 3, child: inputs), const SizedBox(width: 16), Expanded(flex: 2, child: result)],
          )
        else ...<Widget>[result, const SizedBox(height: 14), inputs],
      ],
    );
  }

  Widget _line(String l, String v) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: <Widget>[
          Expanded(child: Text(l, style: ts(13.5, c: Pal.sideText))),
          Text(v, style: ts(14, w: FontWeight.w700, c: Colors.white, tab: true)),
        ],
      ),
    );
  }
}

// ------------------------------------------------------------ bill preview
class BillPreviewScreen extends StatefulWidget {
  final Object? arg;
  const BillPreviewScreen({super.key, this.arg});

  @override
  State<BillPreviewScreen> createState() => _BillPreviewScreenState();
}

class _BillPreviewScreenState extends State<BillPreviewScreen> {
  Entry? _e;

  @override
  void initState() {
    super.initState();
    final Object? a = widget.arg;
    _e = a is Entry ? a : (_db.entries.isEmpty ? null : _db.entries.first);
  }

  static const Color _ink = Color(0xFF14262A);
  static const Color _mut = Color(0xFF6B7C80);

  Widget _row(String l, String v, {bool bold = false, Color c = _ink}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: <Widget>[
          Expanded(child: Text(l, style: ts(13.5, c: _mut))),
          Text(v, style: ts(bold ? 16 : 13.5, w: bold ? FontWeight.w800 : FontWeight.w700, c: c, tab: true)),
        ],
      ),
    );
  }

  Widget _paper(Entry e) {
    return Container(
      constraints: const BoxConstraints(maxWidth: 440),
      padding: const EdgeInsets.fromLTRB(22, 22, 22, 20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFFDDE5E6)),
        boxShadow: const <BoxShadow>[BoxShadow(color: Color(0x14000000), blurRadius: 18, offset: Offset(0, 6))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Center(child: Text(bi('ખરીદ ચિઠ્ઠી', 'PURCHASE SLIP'), style: ts(16, w: FontWeight.w800, c: _ink, ls: 1))),
          const SizedBox(height: 4),
          Center(child: Text('#${e.no}  ·  ${dmy(e.dt)}  ${hm(e.dt)}', style: ts(12.5, c: _mut, tab: true))),
          const SizedBox(height: 14),
          Container(height: 1, color: const Color(0xFFDDE5E6)),
          const SizedBox(height: 10),
          _row(bi('ખેડૂત', 'Farmer'), e.farmer.name),
          _row(bi('ગામ', 'Village'), e.village),
          _row(bi('ગાડી', 'Vehicle'), e.vehicle),
          _row(bi('ગ્રેડ', 'Grade'), gradeName(e.g)),
          const SizedBox(height: 6),
          Container(height: 1, color: const Color(0xFFDDE5E6)),
          const SizedBox(height: 6),
          _row(bi('બેગ', 'Bags'), '${e.bags}'),
          _row(bi('કુલ વજન', 'Gross weight'), '${grp(e.gross)} KG'),
          _row(bi('હવા / ઘટ', 'Hava'), '- ${grp(e.hava)} KG'),
          _row(bi('ચોખ્ખું વજન', 'Net weight'), '${grp(e.net)} KG', bold: true),
          _row(bi('મણ (20 KG)', 'Mann (20 KG)'), grp(e.mann, dec: 2)),
          _row(bi('ભાવ / મણ', 'Rate / mann'), inr(e.rate)),
          const SizedBox(height: 6),
          Container(height: 1, color: const Color(0xFFDDE5E6)),
          const SizedBox(height: 6),
          _row(bi('કુલ રકમ', 'Total amount'), inr(e.amount), bold: true),
          _row(bi('ચૂકવેલ', 'Paid'), inr(e.paid), c: const Color(0xFF1E8A4E)),
          _row(bi('બાકી', 'Balance'), inr(e.due), bold: true, c: e.due > 0.5 ? const Color(0xFFC2394B) : _mut),
          const SizedBox(height: 14),
          Center(child: Text(bi('આભાર 🙏', 'Thank you 🙏'), style: ts(14, w: FontWeight.w700, c: _mut))),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    final Entry? e = _e;
    if (e == null) {
      return ScreenScroll(children: <Widget>[EmptyBox(title: bi('કોઈ એન્ટ્રી નથી', 'No entries'))]);
    }
    final List<Entry> recent = _db.entries.take(12).toList();
    final Widget actions = Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Text(bi('ચિઠ્ઠી પસંદ કરો', 'Choose slip'), style: ts(12.5, w: FontWeight.w600, c: Pal.muted)),
        const SizedBox(height: 6),
        PickX<Entry>(
          label: '#${e.no} · ${e.farmer.name.split(' ').first}',
          icon: 'receipt',
          items: recent,
          text: (Entry x) => '#${x.no} · ${x.farmer.name}',
          onSelected: (Entry x) => setState(() => _e = x),
        ),
        const SizedBox(height: 14),
        Btn(bi('WhatsApp લખાણ કૉપિ', 'Copy WhatsApp text'), icon: 'chat', expand: true, onTap: () => copyText(farmerMessage(e), msg: bi('લખાણ કૉપિ થયું', 'Text copied'))),
        const SizedBox(height: 8),
        Btn(bi('પ્રિન્ટ', 'Print'), icon: 'print', kind: BtnKind.tonal, expand: true, onTap: () => app.toast(bi('પ્રિન્ટર પસંદ કરો', 'Choose a printer'))),
        const SizedBox(height: 8),
        Btn(bi('ખેડૂતનું ખાતું', 'Farmer account'), icon: 'user', kind: BtnKind.outline, expand: true, onTap: () => app.go('party', arg: e.farmer)),
      ],
    );
    return ScreenScroll(
      maxWidth: 980,
      children: <Widget>[
        ScreenHeader(bi('બિલ પ્રિવ્યુ', 'Bill preview')),
        if (pc)
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Expanded(child: Align(alignment: Alignment.topCenter, child: _paper(e))),
              const SizedBox(width: 20),
              SizedBox(width: 300, child: Panel(child: actions)),
            ],
          )
        else ...<Widget>[
          actions,
          const SizedBox(height: 16),
          Center(child: _paper(e)),
        ],
      ],
    );
  }
}
