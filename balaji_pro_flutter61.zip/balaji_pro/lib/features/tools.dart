import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/device.dart';
import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/palette.dart';
import '../data/mock_db.dart';
import '../data/models.dart';
import '../data/live_store.dart' show live;
import '../widgets/common.dart';
import '../widgets/page.dart';
import 'entries.dart';

MockDb get _db => MockDb.I;

// ------------------------------------------------------- interest calculator
class InterestScreen extends StatefulWidget {
  const InterestScreen({super.key});

  @override
  State<InterestScreen> createState() => _InterestScreenState();
}

class _InterestScreenState extends State<InterestScreen> {
  final TextEditingController _p = TextEditingController();
  final TextEditingController _r = TextEditingController(text: '1.5');
  final TextEditingController _d = TextEditingController(text: '30');

  @override
  void dispose() {
    _p.dispose();
    _r.dispose();
    _d.dispose();
    super.dispose();
  }

  void _refresh([String? _]) => setState(() {});

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    final double p = numOf(_p.text), r = numOf(_r.text), d = numOf(_d.text);
    final double interest = p * r / 100 * (d / 30);

    final List<MapEntry<String, AgeBuckets>> top = _db.receivableAging().entries.toList();
    top.sort((MapEntry<String, AgeBuckets> a, MapEntry<String, AgeBuckets> b) => (b.value.b1 + b.value.b2 + b.value.b3).compareTo(a.value.b1 + a.value.b2 + a.value.b3));

    final Widget inputs = Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          if (top.isNotEmpty) ...<Widget>[
            Text(bi('જૂના બાકીમાંથી ભરો', 'Fill from overdue'), style: ts(12.5, w: FontWeight.w600, c: Pal.muted)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: <Widget>[
                for (final MapEntry<String, AgeBuckets> e in top.take(3))
                  InkWell(
                    borderRadius: BorderRadius.circular(99),
                    onTap: () => setState(() {
                      _p.text = (e.value.b1 + e.value.b2 + e.value.b3).round().toString();
                      _d.text = e.value.b3 > 0.5 ? '100' : (e.value.b2 > 0.5 ? '75' : '45');
                    }),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      decoration: BoxDecoration(color: Pal.soft, borderRadius: BorderRadius.circular(99)),
                      child: Text(e.key.split(' ').first, style: ts(13.5, w: FontWeight.w800, c: Pal.brand)),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 14),
          ],
          FieldX(label: bi('મુદ્દલ', 'Principal'), controller: _p, prefix: '₹', big: true, keyboard: TextInputType.number, onChanged: _refresh),
          const SizedBox(height: 14),
          SplitPane(gap: 14, children: <Widget>[
            FieldX(label: bi('વ્યાજ દર (મહિને)', 'Rate (per month)'), controller: _r, suffix: '%', keyboard: TextInputType.number, onChanged: _refresh),
            FieldX(label: bi('દિવસ', 'Days'), controller: _d, suffix: bi('દિવસ', 'days'), keyboard: TextInputType.number, onChanged: _refresh),
          ]),
        ],
      ),
    );
    final Widget result = Surface(
      color: Pal.side,
      border: false,
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(bi('વ્યાજ', 'Interest'), style: ts(13, c: Pal.sideText, w: FontWeight.w600)),
          FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(inr(interest), style: ts(36, w: FontWeight.w800, c: Colors.white, tab: true, ls: -1))),
          const SizedBox(height: 12),
          _row(bi('મુદ્દલ', 'Principal'), inr(p)),
          _row(bi('કુલ (મુદ્દલ + વ્યાજ)', 'Total'), inr(p + interest)),
          _row(bi('રોજનું વ્યાજ', 'Per day'), inr(p * r / 100 / 30, dec: 2)),
          _row(bi('વાર્ષિક દર', 'Yearly rate'), pct(r * 12)),
        ],
      ),
    );
    return ScreenScroll(
      maxWidth: 1000,
      children: <Widget>[
        ScreenHeader(bi('વ્યાજ ગણતરી', 'Interest calculator')),
        SplitPane(flex: const <int>[3, 2], children: pc ? <Widget>[inputs, result] : <Widget>[result, inputs]),
      ],
    );
  }

  Widget _row(String l, String v) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: <Widget>[
          Expanded(child: Text(l, style: ts(13.5, c: Pal.sideText))),
          Text(v, style: ts(14, w: FontWeight.w700, c: Colors.white, tab: true)),
        ],
      ),
    );
  }
}

// ----------------------------------------------------------------- day close
class DayCloseScreen extends StatefulWidget {
  const DayCloseScreen({super.key});

  @override
  State<DayCloseScreen> createState() => _DayCloseScreenState();
}

class _DayCloseScreenState extends State<DayCloseScreen> {
  final TextEditingController _count = TextEditingController();

  @override
  void dispose() {
    _count.dispose();
    super.dispose();
  }

  void _refresh([String? _]) => setState(() {});

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    double cin = 0, cout = 0;
    for (final Voucher v in _db.vouchersIn(firm: Firm.balaji, days: 1)) {
      if (v.dr == 'Cash') cin += v.amount;
      if (v.cr == 'Cash') cout += v.amount;
    }
    final double closing = _db.cashBalance(Firm.balaji);
    final double opening = closing - cin + cout;
    final List<Entry> te = _db.entriesOn(_db.today);
    double amt = 0, due = 0;
    for (final Entry e in te) {
      amt += e.amount;
      due += e.due;
    }
    final bool counted = _count.text.trim().isNotEmpty;
    final double diff = numOf(_count.text) - closing;

    final Widget summary = Panel(
      title: bi('રોજમેળ', 'Cash summary'),
      child: Column(
        children: <Widget>[
          InfoRow(bi('સવારની રોકડ', 'Opening cash'), inr(opening)),
          InfoRow(bi('આવક', 'Cash in'), inr(cin), color: Pal.ok),
          InfoRow(bi('જાવક', 'Cash out'), inr(cout), color: Pal.bad),
          divider(),
          InfoRow(bi('સાંજની રોકડ (ચોપડે)', 'Closing cash (books)'), inr(closing), bold: true),
        ],
      ),
    );
    final Widget count = Panel(
      title: bi('રોકડ ગણતરી', 'Cash count'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          FieldX(label: bi('ગલ્લામાં કુલ રોકડ', 'Cash in drawer'), controller: _count, prefix: '₹', big: true, keyboard: TextInputType.number, onChanged: _refresh),
          if (counted) ...<Widget>[
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                Expanded(child: Text(bi('ફરક', 'Difference'), style: ts(14, w: FontWeight.w700, c: Pal.muted))),
                Pill(diff.abs() < 1 ? bi('બરાબર ✓', 'Matches ✓') : '${diff > 0 ? '+' : '-'}${inr(diff.abs())}', tone: diff.abs() < 1 ? 'green' : 'rose'),
              ],
            ),
          ],
        ],
      ),
    );
    final Widget day = Panel(
      title: bi('આજનો દિવસ', 'Today'),
      child: Column(
        children: <Widget>[
          InfoRow(bi('એન્ટ્રી', 'Entries'), '${te.length}'),
          InfoRow(bi('આજની ખરીદી', 'Purchase value'), inr(amt)),
          InfoRow(bi('બાકી ચૂકવણી', 'Unpaid today'), inr(due), color: due > 0 ? Pal.bad : null),
          const SizedBox(height: 14),
          if (app.dayClosed)
            Row(children: <Widget>[
              Expanded(child: Pill(bi('દિવસ બંધ ✓', 'Day closed ✓'), tone: 'green')),
              const SizedBox(width: 8),
              Btn(bi('ફરી ખોલો', 'Reopen'), kind: BtnKind.outline, onTap: () => app.setDayClosed(false)),
            ])
          else
            Btn(bi('દિવસ બંધ કરો', 'Close the day'), icon: 'check', expand: true, onTap: () {
              app.setDayClosed(true);
              app.toast(bi('દિવસ બંધ થયો', 'Day closed'));
            }),
        ],
      ),
    );
    return ScreenScroll(
      maxWidth: 1100,
      children: <Widget>[
        ScreenHeader(bi('દિવસ બંધ', 'Day close'), sub: dmy(_db.today)),
        if (!pc) Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(dmy(_db.today), style: ts(14, w: FontWeight.w700, c: Pal.muted))),
        if (pc)
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
            Expanded(child: summary),
            const SizedBox(width: 16),
            Expanded(child: Column(children: <Widget>[count, const SizedBox(height: 16), day])),
          ])
        else ...<Widget>[summary, const SizedBox(height: 12), count, const SizedBox(height: 12), day],
      ],
    );
  }
}

// -------------------------------------------------------------------- backup
class BackupScreen extends StatefulWidget {
  const BackupScreen({super.key});

  @override
  State<BackupScreen> createState() => _BackupScreenState();
}

class _BackupScreenState extends State<BackupScreen> {
  bool _busy = false;
  double _prog = 0;

  Future<void> _run() async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _prog = 0;
    });
    for (int i = 1; i <= 10; i++) {
      await Future<void>.delayed(const Duration(milliseconds: 140));
      if (!mounted) return;
      setState(() => _prog = i / 10);
    }
    app.markBackup();
    if (!mounted) return;
    setState(() => _busy = false);
    app.toast(bi('બેકઅપ પૂર્ણ', 'Backup complete'));
  }

  String _entriesCsv() {
    final StringBuffer b = StringBuffer('no,date,farmer,village,vehicle,grade,bags,gross,hava,net,rate,amount,paid,due,mode\n');
    for (final Entry e in _db.entries) {
      b.writeln(<Object>[
        e.no,
        '${e.dt.year}-${pad2(e.dt.month)}-${pad2(e.dt.day)}',
        csvCell(e.farmer.name),
        csvCell(e.village),
        e.vehicle,
        e.g,
        e.bags,
        e.gross,
        e.hava,
        e.net,
        e.rate,
        e.amount,
        e.paid,
        e.due,
        e.mode,
      ].join(','));
    }
    return b.toString();
  }

  String _vouchersCsv() {
    final StringBuffer b = StringBuffer('date,firm,type,no,party,dr,cr,amount,gst\n');
    for (final Voucher v in _db.vouchers) {
      b.writeln('${v.date.year}-${pad2(v.date.month)}-${pad2(v.date.day)},${v.firm.short},${v.type},${v.no},${csvCell(v.party)},${csvCell(v.dr)},${csvCell(v.cr)},${v.amount},${v.gst}');
    }
    return b.toString();
  }

  String _ledgersCsv() {
    final StringBuffer b = StringBuffer('firm,group,ledger,opening,debit,credit,closing\n');
    for (final LedgerAcc l in _db.ledgers) {
      b.writeln('${l.firm.short},${csvCell(l.group)},${csvCell(l.name)},${l.opening},${l.dr},${l.cr},${l.closing}');
    }
    return b.toString();
  }

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    final Widget status = Surface(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Row(
            children: <Widget>[
              IconChip('cloud', tone: 'teal', size: 52),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(bi('છેલ્લો બેકઅપ', 'Last backup'), style: ts(12.5, c: Pal.muted, w: FontWeight.w600)),
                    Text(ago(app.lastBackup), style: ts(18, w: FontWeight.w800)),
                  ],
                ),
              ),
            ],
          ),
          if (_busy) ...<Widget>[
            const SizedBox(height: 14),
            ClipRRect(borderRadius: BorderRadius.circular(99), child: LinearProgressIndicator(value: _prog, minHeight: 8, color: Pal.brand, backgroundColor: Pal.line)),
          ],
          const SizedBox(height: 14),
          Btn(_busy ? bi('બેકઅપ ચાલુ…', 'Backing up…') : bi('હમણાં બેકઅપ લો', 'Back up now'), icon: 'cloudup', onTap: _busy ? null : _run),
          const SizedBox(height: 10),
          Row(
            children: <Widget>[
              Expanded(child: Text(bi('આપોઆપ બેકઅપ (રોજ)', 'Automatic daily backup'), style: ts(14, w: FontWeight.w700))),
              Switch(value: app.autoBackup, onChanged: (bool v) => app.setAutoBackup(v)),
            ],
          ),
        ],
      ),
    );
    final Widget export = Panel(
      title: bi('ડેટા નિકાસ (CSV)', 'Export data (CSV)'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Btn('${bi('એન્ટ્રી', 'Entries')} · ${_db.entries.length}', icon: 'copy', kind: BtnKind.tonal, onTap: () => copyText(_entriesCsv(), msg: bi('એન્ટ્રી CSV કૉપિ થઈ', 'Entries CSV copied'))),
          const SizedBox(height: 8),
          Btn('${bi('વાઉચર', 'Vouchers')} · ${_db.vouchers.length}', icon: 'copy', kind: BtnKind.tonal, onTap: () => copyText(_vouchersCsv(), msg: bi('વાઉચર CSV કૉપિ થઈ', 'Vouchers CSV copied'))),
          const SizedBox(height: 8),
          Btn('${bi('લેજર', 'Ledgers')} · ${_db.ledgers.length}', icon: 'copy', kind: BtnKind.tonal, onTap: () => copyText(_ledgersCsv(), msg: bi('લેજર CSV કૉપિ થઈ', 'Ledgers CSV copied'))),
        ],
      ),
    );
    return ScreenScroll(
      maxWidth: 1000,
      children: <Widget>[
        ScreenHeader(bi('બેકઅપ', 'Backup')),
        SplitPane(children: <Widget>[status, export]),
        if (!pc) const SizedBox(height: 4),
      ],
    );
  }
}

// ------------------------------------------------------- WhatsApp templates
class TplDef {
  final String id;
  final String gu;
  final String en;
  final bool farmer;
  const TplDef(this.id, this.gu, this.en, this.farmer);
}

const List<TplDef> kTplDefs = <TplDef>[
  TplDef('bill', 'ખેડૂત બિલ', 'Farmer bill', true),
  TplDef('paid', 'ચૂકવણી મળ્યાની નોંધ', 'Payment note', true),
  TplDef('rate', 'આજનો ભાવ', "Today's rate", true),
  TplDef('remind', 'ખરીદદાર રિમાઇન્ડર', 'Buyer reminder', false),
];

final Map<String, String> kTplText = <String, String>{
  'bill': 'નમસ્તે {name},\nચિઠ્ઠી #{slip} · {date}\nચોખ્ખું વજન: {kg} KG\nભાવ: ₹{rate} / મણ\nકુલ રકમ: ₹{amount}\nચૂકવેલ: ₹{paid}\nબાકી: ₹{due}\nઆભાર 🙏',
  'paid': 'નમસ્તે {name},\n₹{paid} તમારા ખાતે જમા થયા છે.\nબાકી રકમ: ₹{due}\nઆભાર 🙏',
  'rate': 'આજનો ભાવ · {date}\nજાડી: ₹{rate} / 20 KG\nઆવો અને માલ લાવો 🙏',
  'remind': 'નમસ્તે {name}, તમારું ₹{due} બાકી છે. કૃપા કરીને ચૂકવણી કરશો. આભાર 🙏',
};

const List<String> _companyWords = <String>[
  'balaji', 'patel', 'shreenathji', 'enterprise', 'industries', 'kacha', 'paka', 'બાલાજી', 'પટેલ', 'શ્રીનાથજી', 'એન્ટરપ્રાઇઝ', 'ઇન્ડસ્ટ્રીઝ', 'કાચું', 'પાકું',
];

bool hasCompanyWord(String t) {
  final String s = t.toLowerCase();
  for (final String w in _companyWords) {
    if (s.contains(w)) return true;
  }
  return false;
}

class WhatsappTplScreen extends StatefulWidget {
  const WhatsappTplScreen({super.key});

  @override
  State<WhatsappTplScreen> createState() => _WhatsappTplScreenState();
}

class _WhatsappTplScreenState extends State<WhatsappTplScreen> {
  int _i = 0;
  late TextEditingController _c = TextEditingController(text: kTplText[kTplDefs[0].id]);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  void _select(int i) {
    setState(() {
      _i = i;
      _c.text = kTplText[kTplDefs[i].id] ?? '';
    });
  }

  String _sample(String t) {
    return t
        .replaceAll('{name}', 'રમેશભાઈ')
        .replaceAll('{slip}', '1024')
        .replaceAll('{date}', dmy(_db.today))
        .replaceAll('{kg}', '3,420')
        .replaceAll('{rate}', grp(_db.rates[0]))
        .replaceAll('{amount}', '2,08,155')
        .replaceAll('{paid}', '1,50,000')
        .replaceAll('{due}', '58,155');
  }

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    final TplDef d = kTplDefs[_i];
    final bool bad = d.farmer && hasCompanyWord(_c.text);

    final Widget picker = pc
        ? Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              for (int i = 0; i < kTplDefs.length; i++)
                Surface(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                  color: i == _i ? Pal.soft : null,
                  onTap: () => _select(i),
                  child: Row(
                    children: <Widget>[
                      Expanded(child: Text(bi(kTplDefs[i].gu, kTplDefs[i].en), style: ts(14.5, w: FontWeight.w800, c: i == _i ? Pal.brand : Pal.ink))),
                      Pill(kTplDefs[i].farmer ? bi('ખેડૂત', 'Farmer') : bi('ખરીદદાર', 'Buyer'), tone: kTplDefs[i].farmer ? 'green' : 'blue', small: true),
                    ],
                  ),
                ),
            ],
          )
        : ChipRow(labels: <String>[for (final TplDef t in kTplDefs) bi(t.gu, t.en)], index: _i, onChanged: _select);

    final Widget editor = Panel(
      title: bi(d.gu, d.en),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          FieldX(
            label: bi('લખાણ', 'Message'),
            controller: _c,
            maxLines: 8,
            onChanged: (String v) => setState(() => kTplText[d.id] = v),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: <Widget>[
              for (final String k in <String>['{name}', '{slip}', '{date}', '{kg}', '{rate}', '{amount}', '{paid}', '{due}'])
                InkWell(
                  borderRadius: BorderRadius.circular(8),
                  onTap: () => setState(() {
                    _c.text = '${_c.text}$k';
                    _c.selection = TextSelection.collapsed(offset: _c.text.length);
                    kTplText[d.id] = _c.text;
                  }),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    decoration: BoxDecoration(color: Pal.surface2, borderRadius: BorderRadius.circular(8), border: Border.all(color: Pal.line)),
                    child: Text(k, style: ts(12.5, w: FontWeight.w700, c: Pal.muted)),
                  ),
                ),
            ],
          ),
          if (bad) ...<Widget>[
            const SizedBox(height: 12),
            Pill(bi('ખેડૂતના લખાણમાં કંપનીનું નામ ન રાખો', 'Farmer text must not carry a company name'), tone: 'rose', icon: 'warn'),
          ],
        ],
      ),
    );

    final Widget preview = Panel(
      title: bi('પ્રિવ્યુ', 'Preview'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: Pal.tone('green').bg, borderRadius: const BorderRadius.only(topLeft: Radius.circular(4), topRight: Radius.circular(16), bottomLeft: Radius.circular(16), bottomRight: Radius.circular(16))),
            child: Text(_sample(_c.text), style: ts(14.5, h: 1.45)),
          ),
          const SizedBox(height: 12),
          Btn(bi('કૉપિ', 'Copy'), icon: 'copy', expand: true, onTap: () => copyText(_sample(_c.text))),
        ],
      ),
    );

    return ScreenScroll(
      maxWidth: 1200,
      children: <Widget>[
        ScreenHeader(bi('WhatsApp ટેમ્પલેટ', 'WhatsApp templates')),
        if (pc)
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
            SizedBox(width: 280, child: picker),
            const SizedBox(width: 16),
            Expanded(flex: 3, child: editor),
            const SizedBox(width: 16),
            Expanded(flex: 2, child: preview),
          ])
        else ...<Widget>[picker, const SizedBox(height: 12), editor, const SizedBox(height: 12), preview],
      ],
    );
  }
}

// ----------------------------------------------------------------- PIN lock
class PinPad extends StatefulWidget {
  final String title;
  final String? Function(String) onDone;
  const PinPad({super.key, required this.title, required this.onDone});

  @override
  State<PinPad> createState() => _PinPadState();
}

class _PinPadState extends State<PinPad> {
  String _v = '';
  String? _err;

  void _tap(String d) {
    if (_v.length >= 4) return;
    setState(() {
      _v += d;
      _err = null;
    });
    if (_v.length == 4) {
      final String? e = widget.onDone(_v);
      setState(() {
        _v = '';
        _err = e;
      });
    }
  }

  Widget _key(String label, {VoidCallback? onTap}) {
    return SizedBox(
      width: 74,
      height: 62,
      child: onTap == null
          ? const SizedBox()
          : Material(
              color: Pal.surface,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: BorderSide(color: Pal.line)),
              child: InkWell(
                borderRadius: BorderRadius.circular(18),
                onTap: onTap,
                child: Center(child: Text(label, style: ts(24, w: FontWeight.w700))),
              ),
            ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Widget row(List<String> k) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[for (final String x in k) Padding(padding: const EdgeInsets.symmetric(horizontal: 5), child: _key(x, onTap: () => _tap(x)))]),
      );
    }

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Text(widget.title, style: ts(17, w: FontWeight.w800)),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            for (int i = 0; i < 4; i++)
              Container(
                width: 16,
                height: 16,
                margin: const EdgeInsets.symmetric(horizontal: 7),
                decoration: BoxDecoration(shape: BoxShape.circle, color: i < _v.length ? Pal.brand : Colors.transparent, border: Border.all(color: i < _v.length ? Pal.brand : Pal.faint, width: 2)),
              ),
          ],
        ),
        SizedBox(height: 22, child: _err == null ? null : Center(child: Text(_err!, style: ts(13, c: Pal.bad, w: FontWeight.w700)))),
        const SizedBox(height: 8),
        row(<String>['1', '2', '3']),
        row(<String>['4', '5', '6']),
        row(<String>['7', '8', '9']),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Padding(padding: const EdgeInsets.symmetric(horizontal: 5), child: _key('')),
            Padding(padding: const EdgeInsets.symmetric(horizontal: 5), child: _key('0', onTap: () => _tap('0'))),
            Padding(padding: const EdgeInsets.symmetric(horizontal: 5), child: _key('⌫', onTap: () => setState(() {
                  if (_v.isNotEmpty) _v = _v.substring(0, _v.length - 1);
                }))),
          ],
        ),
      ],
    );
  }
}

class LockScreen extends StatelessWidget {
  const LockScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Pal.bg,
      alignment: Alignment.center,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            IconChip('lock', tone: 'teal', size: 64),
            const SizedBox(height: 18),
            PinPad(
              title: bi('PIN નાખો', 'Enter PIN'),
              onDone: (String p) => app.unlock(p) ? null : bi('PIN ખોટો છે', 'Wrong PIN'),
            ),
            const SizedBox(height: 10),
            Btn(bi('PIN ભૂલી ગયા? લૉગ આઉટ', 'Forgot PIN? Log out'), kind: BtnKind.ghost, onTap: () {
              app.clearPin();
              live.logout();
            }),
          ],
        ),
      ),
    );
  }
}

class PinLockScreen extends StatefulWidget {
  const PinLockScreen({super.key});

  @override
  State<PinLockScreen> createState() => _PinLockScreenState();
}

class _PinLockScreenState extends State<PinLockScreen> {
  bool _setting = false;
  String _first = '';

  static const List<int> _graceSecs = <int>[60, 300, 900, 3600, 28800];

  int _graceIdx() {
    int best = 2;
    int d = 1 << 30;
    for (int i = 0; i < _graceSecs.length; i++) {
      final int x = (app.lockAfterSec - _graceSecs[i]).abs();
      if (x < d) {
        d = x;
        best = i;
      }
    }
    return best;
  }

  @override
  Widget build(BuildContext context) {
    final bool on = app.pinOn;
    Widget body;
    if (_setting) {
      body = Panel(
        child: Center(
          child: PinPad(
            title: _first.isEmpty ? bi('નવો PIN (4 આંકડા)', 'New PIN (4 digits)') : bi('ફરી એ જ PIN નાખો', 'Enter the PIN again'),
            onDone: (String p) {
              if (_first.isEmpty) {
                setState(() => _first = p);
                return null;
              }
              if (p != _first) {
                setState(() => _first = '');
                return bi('PIN મેળ ખાતા નથી', 'PINs do not match');
              }
              app.setPin(p);
              setState(() {
                _setting = false;
                _first = '';
              });
              app.toast(bi('PIN સેટ થયો', 'PIN set'));
              return null;
            },
          ),
        ),
      );
    } else {
      body = Panel(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Row(
              children: <Widget>[
                IconChip('lock', tone: on ? 'green' : 'slate', size: 48),
                const SizedBox(width: 14),
                Expanded(child: Text(on ? bi('PIN લોક ચાલુ છે', 'PIN lock is on') : bi('PIN લોક બંધ છે', 'PIN lock is off'), style: ts(16, w: FontWeight.w800))),
              ],
            ),
            const SizedBox(height: 18),
            Btn(on ? bi('PIN બદલો', 'Change PIN') : bi('PIN સેટ કરો', 'Set PIN'), icon: 'key', onTap: () => setState(() => _setting = true)),
            if (on) ...<Widget>[
              const SizedBox(height: 14),
              Text(bi('PIN ક્યારે માંગે?', 'Ask the PIN after'), style: ts(13, w: FontWeight.w800)),
              const SizedBox(height: 6),
              ChipRow(
                labels: <String>[bi('1 મિનિટ', '1 min'), bi('5 મિનિટ', '5 min'), bi('15 મિનિટ', '15 min'), bi('1 કલાક', '1 hour'), bi('8 કલાક', '8 hours')],
                index: _graceIdx(),
                onChanged: (int i) {
                  app.setLockAfter(_graceSecs[i]);
                  setState(() {});
                },
              ),
              const SizedBox(height: 4),
              Text(bi('એપ આટલી વાર સુધી બહાર રહે તો જ PIN માંગે. બેક દબાવીને તરત ફરી ખોલો તો PIN નહીં માંગે.', 'The PIN is asked only if the app was away for this long. Back and straight in again: no PIN.'), style: ts(12, c: Pal.muted)),
              const SizedBox(height: 12),
              Btn(bi('હમણાં લોક કરો', 'Lock now'), icon: 'lock', kind: BtnKind.amber, onTap: () => app.lock()),
              const SizedBox(height: 8),
              Btn(bi('PIN બંધ કરો', 'Turn off PIN'), kind: BtnKind.outline, onTap: () {
                app.clearPin();
                app.toast(bi('PIN લોક બંધ', 'PIN lock off'));
              }),
            ],
          ],
        ),
      );
    }
    return ScreenScroll(
      maxWidth: 560,
      children: <Widget>[
        ScreenHeader(bi('PIN લોક', 'PIN lock')),
        body,
        if (_setting) ...<Widget>[const SizedBox(height: 12), Btn(bi('રદ', 'Cancel'), kind: BtnKind.ghost, expand: true, onTap: () => setState(() {
              _setting = false;
              _first = '';
            }))],
      ],
    );
  }
}

// ---------------------------------------------------------------- shortcuts
class ShortcutDef {
  final String keys;
  final String gu;
  final String en;
  const ShortcutDef(this.keys, this.gu, this.en);
}

const List<ShortcutDef> kShortcutList = <ShortcutDef>[
  ShortcutDef('Ctrl + K', 'શોધ / કમાન્ડ (ખેડૂત, ગાડી, ફીચર)', 'Command palette (parties, features)'),
  ShortcutDef('Ctrl + N', 'નવી ચિઠ્ઠી', 'New chit'),
  ShortcutDef('Ctrl + H', 'હિસાબ કૅલ્ક્યુલેટર', 'Calculator'),
  ShortcutDef('Ctrl + 1', 'ધંધો · આજે', 'Business today'),
  ShortcutDef('Ctrl + 2', 'ચિઠ્ઠી', 'Chits'),
  ShortcutDef('Ctrl + 3', 'મેળ', 'Match'),
  ShortcutDef('Ctrl + 4', 'કાંટો', 'Weighbridge'),
  ShortcutDef('Ctrl + 5', 'ધ્યાનમાં લો', 'Attention'),
  ShortcutDef('Ctrl + 6', 'વિશ્લેષણ', 'Analytics'),
  ShortcutDef('Ctrl + 7', 'લાઇવ બોર્ડ', 'Live board'),
  ShortcutDef('Ctrl + T', 'રસ્તામાં (Transit)', 'On the way'),
  ShortcutDef('Ctrl + S', 'સ્લિપ સ્કેન', 'Scan slip'),
  ShortcutDef('Ctrl + P', 'પાર્ટી ડિરેક્ટરી', 'Parties'),
  ShortcutDef('Ctrl + E', 'એક્સપોર્ટ (CSV)', 'Export (CSV)'),
  ShortcutDef('Ctrl + B', 'સાઇડબાર નાનો / મોટો', 'Toggle sidebar'),
  ShortcutDef('Ctrl + D', 'ડાર્ક મોડ', 'Dark mode'),
  ShortcutDef('Ctrl + L', 'ભાષા બદલો', 'Switch language'),
  ShortcutDef('?', 'આ યાદી', 'This list'),
  ShortcutDef('Esc', 'પાછા / ફોર્મ બંધ', 'Back / close the form'),
  ShortcutDef('Enter', 'ફોર્મમાં આગલું ખાનું', 'Next field in a form'),
  ShortcutDef('↑  ↓', 'ખાનું બદલો · લિસ્ટમાં પસંદ કરો', 'Change field · move in a list'),
  ShortcutDef('Ctrl + Enter', 'ફોર્મ સેવ (Accept)', 'Save (accept) the form'),
  ShortcutDef('Ctrl + A', 'ફોર્મ સેવ (Tally લુકમાં)', 'Accept the form (Tally look)'),
  ShortcutDef('Alt + C', 'આ સ્ક્રીનની નવી એન્ટ્રી (Create)', 'Create a new entry for this screen'),
  ShortcutDef('F2', 'પીરિયડ બદલો (From / To)', 'Change the period (From / To)'),
  ShortcutDef('Ctrl + P', 'વાઉચર / રિપોર્ટ પ્રિન્ટ (Tally લુકમાં)', 'Print the voucher / report (Tally look)'),
  ShortcutDef('Alt + E', 'રિપોર્ટ Excel માં (CSV)', 'Export the report to Excel (CSV)'),
  ShortcutDef('Alt + D', 'ખુલ્લું વાઉચર કાઢો', 'Delete the open voucher'),
  ShortcutDef('Ctrl + F  /  /', 'આ સ્ક્રીનમાં શોધ', 'Search on this screen'),
  ShortcutDef('←  →', 'ચોઇસ (માલ, રીત) બદલો', 'Change a choice (material, mode)'),
  ShortcutDef('+  -  T', 'તારીખ ખાનામાં: ±1 દિવસ, T = આજ', 'Date box: ±1 day, T = today'),
  ShortcutDef('Y  /  N', 'પ્રશ્નમાં હા / ના', 'Yes / No in a question'),
];

class ShortcutsScreen extends StatelessWidget {
  const ShortcutsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    final List<Widget> tiles = <Widget>[
      for (final ShortcutDef s in kShortcutList)
        Surface(
          padding: EdgeInsets.symmetric(horizontal: 14, vertical: Pal.tally ? 6 : 14),
          child: Row(
            children: <Widget>[
              Expanded(child: Text(bi(s.gu, s.en), style: ts(Pal.tally ? 13.5 : 14.5, w: FontWeight.w700))),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(color: Pal.surface2, borderRadius: BorderRadius.circular(Pal.rad(8)), border: Border.all(color: Pal.line, width: 1.2)),
                child: Text(s.keys, style: ts(13, w: FontWeight.w800, c: Pal.muted)),
              ),
            ],
          ),
        ),
    ];
    return ScreenScroll(
      maxWidth: 1000,
      children: <Widget>[
        ScreenHeader(bi('કીબોર્ડ શોર્ટકટ', 'Keyboard shortcuts')),
        if (pc)
          Grid(cols: 2, gap: 12, children: tiles)
        else
          Column(children: <Widget>[for (final Widget t in tiles) Padding(padding: const EdgeInsets.only(bottom: 8), child: t)]),
      ],
    );
  }
}
