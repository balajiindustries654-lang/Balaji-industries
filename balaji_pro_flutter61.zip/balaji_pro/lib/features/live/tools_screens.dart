import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/device.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/icons.dart';
import '../../core/palette.dart';
import '../../data/engine.dart';
import '../../data/insights.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../data/money.dart' show farmerMobile;
import '../../widgets/charts.dart';
import '../../widgets/common.dart';
import '../../widgets/launch.dart';
import '../../widgets/page.dart';
import 'kit.dart';
import 'money_screens.dart' show openPayForm;
import 'ui.dart';
import 'biz_tools.dart' show PartyNoteCard;
import 'hisab.dart' show HisabCalc;

double _num(String s) => double.tryParse(s.trim().replaceAll(',', '')) ?? 0;

Color _bandColor(String b) => b == 'rose' ? Pal.bad : (b == 'amber' ? Pal.warn : Pal.ok);

PartyRef? _refOfPin(String id, String label) {
  final int i = id.indexOf('|');
  if (i < 1) return null;
  final int? di = int.tryParse(id.substring(0, i));
  if (di == null || di < 0 || di >= Dim.values.length) return null;
  return PartyRef(Dim.values[di], id.substring(i + 1), label);
}

PartyRef _relatedRef(Dim d, String label) {
  final String key = d == Dim.vehicle ? vehicleKey(label) : nameKey(label);
  return PartyRef(d, key, label);
}

// =================================================================== profile
/// Everything about one farmer / vehicle / village / broker / labour.
class PartyProfileScreen extends StatelessWidget {
  final PartyRef? party;
  const PartyProfileScreen(this.party, {super.key});

  Widget _related(String title, Dim dim, Map<String, int> m) {
    final List<MapEntry<String, int>> l = topCounts(m, n: 6);
    if (l.isEmpty) return const SizedBox.shrink();
    return Panel(
      title: title,
      child: RankList(<RankItem>[
        for (final MapEntry<String, int> e in l)
          RankItem(e.key, e.value.toDouble(), '${e.value}', Pal.info, onTap: () => openParty(_relatedRef(dim, e.key))),
      ]),
    );
  }

  String _summary(PartyRef r, PartyData d) {
    final StringBuffer b = StringBuffer();
    b.writeln('${dimName(r.dim)}: ${r.label}');
    if (d.first != null && d.last != null) b.writeln('${dmy(d.first!)} - ${dmy(d.last!)}');
    b.writeln('-----------------------');
    b.writeln('${bi('ચિઠ્ઠી', 'Chits')}: ${d.chits.length} | ${grp(d.kg)} KG');
    if (d.kantas.isNotEmpty) b.writeln('${bi('કાંટો', 'Kanta')}: ${d.kantas.length} | ${grp(d.kantaKg)} KG');
    b.writeln('${bi('ગાડી', 'Trips')}: ${d.trips.length}');
    final GroupRow? g = d.row;
    if (g != null && g.matchedKg > 0) {
      b.writeln('${bi('ઘટ/વધ', 'Loss/gain')}: ${sk(g.ghat)} KG (${g.ghatPct.toStringAsFixed(2)}%)');
    }
    return b.toString().trim();
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 1200,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final PartyRef? r = party;
        if (r == null) return <Widget>[EmptyBox(icon: 'user', title: bi('પ્રોફાઇલ મળી નથી', 'Profile not found'))];
        final bool pc = DeviceScope.isPc(ctx);
        final PartyData d = partyData(r, trendDays: 30);
        final GroupRow? g = d.row;
        final DateTime today = dayOf(DateTime.now());
        Risk? risk;
        for (final Risk x in riskOf(r.dim, Period(addDays(today, -89), addDays(today, 1)), minTrips: 1)) {
          if (x.key == r.key) {
            risk = x;
            break;
          }
        }
        final bool pinned = live.isPinned(r.id);
        final bool isVeh = r.dim == Dim.vehicle;
        final double mainKg = isVeh && d.chits.isEmpty ? d.kantaKg : d.kg;
        final bool lossOk = g == null || g.matchedKg <= 0 || g.ghat.abs() <= live.cfg.tol(g.matchedKg);

        final Widget head = Surface(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: <Widget>[
              Avatar(r.label.isEmpty ? '?' : r.label, size: pc ? 64 : 54),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(children: <Widget>[Pill(dimName(r.dim), tone: 'teal', small: true, icon: dimIcon(r.dim))]),
                    const SizedBox(height: 6),
                    Text(r.label.isEmpty ? '—' : r.label, maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(pc ? 24 : 20, w: FontWeight.w800, ls: -0.4)),
                    const SizedBox(height: 2),
                    Text(
                      d.first == null ? '' : '${bi('પહેલી એન્ટ્રી', 'First entry')} ${dmy(d.first!)} · ${bi('છેલ્લી', 'last')} ${ago(d.last!)}',
                      style: ts(12.5, c: Pal.muted),
                    ),
                  ],
                ),
              ),
              IconBtn(
                pinned ? 'star' : 'staro',
                color: pinned ? Pal.amber : Pal.muted,
                tip: pinned ? bi('હોમ પરથી કાઢો', 'Unpin from home') : bi('હોમ પર પિન કરો', 'Pin to home'),
                onTap: () {
                  live.togglePinned(r.id, r.label);
                  app.toast(live.isPinned(r.id) ? bi('હોમ પર પિન થયું', 'Pinned to home') : bi('પિન કાઢ્યું', 'Unpinned'));
                },
              ),
            ],
          ),
        );

        final Widget tiles = metricGrid(ctx, <Widget>[
          MetricTile(label: bi('કુલ માલ', 'Total weight'), value: kgShort(mainKg), icon: 'scale', tone: 'blue', sub: '${d.chits.length} ${bi('ચિઠ્ઠી', 'chits')}${d.kantas.isEmpty ? '' : ' · ${d.kantas.length} ${bi('કાંટો', 'kanta')}'}'),
          MetricTile(label: bi('ગાડી', 'Trips'), value: '${d.trips.length}', icon: 'truck', tone: 'violet', sub: d.trips.isEmpty ? null : '${bi('સરેરાશ', 'avg')} ${kgShort(mainKg / math.max(1, d.trips.length))}'),
          MetricTile(
            label: bi('ઘટ / વધ', 'Loss / gain'),
            value: (g == null || g.matchedKg <= 0) ? '—' : '${g.ghatPct.toStringAsFixed(2)}%',
            icon: 'cmp',
            tone: (g == null || g.matchedKg <= 0) ? 'slate' : (lossOk ? 'green' : 'rose'),
            sub: (g == null || g.matchedKg <= 0) ? bi('મેળ થયેલ ગાડી નથી', 'no matched trips') : '${sk(g.ghat)} KG · ${g.mtrips.length} ${bi('ગાડી', 'trips')}',
          ),
          MetricTile(
            label: bi('ફરક વાળી ગાડી', 'Trips with difference'),
            value: '${d.trips.where((Trip t) => t.state == TripState.diff).length}',
            icon: 'warn',
            tone: d.trips.any((Trip t) => t.state == TripState.diff) ? 'rose' : 'green',
            sub: '${d.trips.where((Trip t) => t.state == TripState.noKanta).length} ${bi('કાંટા વગર', 'without kanta')}',
          ),
        ]);

        final Widget riskBox = Panel(
          title: bi('જોખમ સ્કોર (90 દિવસ)', 'Risk score (90 days)'),
          child: risk == null
              ? EmptyBox(icon: 'rank', title: bi('સ્કોર માટે પૂરતો ડેટા નથી', 'Not enough data for a score'))
              : Row(
                  children: <Widget>[
                    ScoreRing(value: risk.score / 100, center: '${risk.score}', color: _bandColor(risk.band), sub: '/100', size: 84),
                    const SizedBox(width: 14),
                    Expanded(
                      child: risk.why.isEmpty
                          ? Text(bi('કોઈ શંકા નથી - બધું બરાબર.', 'Nothing suspicious - all fine.'), style: ts(13.5, c: Pal.ok, w: FontWeight.w700))
                          : Wrap(spacing: 6, runSpacing: 6, children: <Widget>[for (final String w in risk.why) Pill(w, tone: risk!.band, small: true)]),
                    ),
                  ],
                ),
        );

        final List<double> vals = <double>[for (final double v in d.daily) v / 1000];
        final Widget trend = Panel(
          title: bi('છેલ્લા 30 દિવસ (ટન)', 'Last 30 days (tons)'),
          child: BarChartX(
            values: vals,
            labels: <String>[for (int i = 0; i < vals.length; i++) (i % 5 == 0 || i == vals.length - 1) ? '${addDays(today, -(vals.length - 1 - i)).day}' : ''],
            color: Pal.brand,
            axisFmt: (double v) => v.toStringAsFixed(v < 10 ? 1 : 0),
            valueFmt: (double v) => '${v.toStringAsFixed(2)} T',
            height: 180,
          ),
        );

        final List<Widget> rel = <Widget>[
          if (r.dim != Dim.farmer) _related(bi('ખેડૂત', 'Farmers'), Dim.farmer, d.farmers),
          if (r.dim != Dim.village) _related(bi('ગામ', 'Villages'), Dim.village, d.villages),
          if (r.dim != Dim.broker) _related(bi('દલાલ', 'Brokers'), Dim.broker, d.brokers),
          if (r.dim != Dim.vehicle) _related(bi('ગાડી', 'Vehicles'), Dim.vehicle, d.vehicles),
          _related(bi('માલ', 'Material'), Dim.commodity, d.commodities),
        ];

        final Widget trips = Panel(
          title: bi('છેલ્લી ગાડીઓ', 'Recent trips'),
          sub: '${d.trips.length}',
          child: d.trips.isEmpty ? EmptyBox(icon: 'truck', title: bi('ગાડી નથી', 'No trips')) : Column(children: <Widget>[for (final Trip t in d.trips.take(8)) tripTile(ctx, t)]),
        );

        return <Widget>[
          ScreenHeader(bi('પ્રોફાઇલ', 'Profile'), sub: '${dimName(r.dim)} · ${r.label}', actions: <Widget>[refreshBtn()]),
          statusBanner(),
          head,
          const SizedBox(height: 14),
          tiles,
          const SizedBox(height: 16),
          SplitPane(flex: const <int>[3, 2], children: <Widget>[trend, riskBox]),
          const SizedBox(height: 16),
          SplitPane(flex: const <int>[3, 2], children: <Widget>[trips, Column(children: <Widget>[for (final Widget w in rel) Padding(padding: const EdgeInsets.only(bottom: 12), child: w)])]),
          if (r.dim == Dim.farmer) ...<Widget>[
            const SizedBox(height: 4),
            Row(
              children: <Widget>[
                tExp(child: Btn(bi('ખાતું', 'Ledger'), icon: 'agri', onTap: () => app.go('khata_party', arg: r))),
                const SizedBox(width: 10),
                tExp(child: Btn(bi('ચૂકવણી', 'Payment'), icon: 'pay', kind: BtnKind.amber, onTap: () => openPayForm(ctx, farmer: r))),
                if (farmerMobile(r.key).isNotEmpty) ...<Widget>[
                  const SizedBox(width: 10),
                  tExp(child: Btn(bi('ફોન', 'Call'), icon: 'phone', kind: BtnKind.tonal, onTap: () => callPhone(farmerMobile(r.key)))),
                ],
              ],
            ),
            const SizedBox(height: 10),
          ],
          const SizedBox(height: 4),
          Row(
            children: <Widget>[
              tExp(child: Btn(bi('સારાંશ કૉપિ', 'Copy summary'), icon: 'copy', kind: BtnKind.tonal, onTap: () => copyText(_summary(r, d)))),
              const SizedBox(width: 10),
              tExp(
                child: Btn(
                  bi('ચિઠ્ઠી CSV', 'Chits CSV'),
                  icon: 'table',
                  kind: BtnKind.tonal,
                  onTap: () => copyText(csvOf(chitHeader(), <List<Object?>>[for (final Chit c in d.chits) chitRow(c)]), msg: bi('CSV કૉપિ થયું', 'CSV copied')),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          PartyNoteCard(r),
          if (d.chits.isNotEmpty) ...<Widget>[
            const SizedBox(height: 16),
            SectionTitle(bi('છેલ્લી ચિઠ્ઠી', 'Recent chits'), sub: '${d.chits.length}'),
            const SizedBox(height: 10),
            for (final Chit c in d.chits.take(10)) chitTile(ctx, c),
          ],
        ];
      },
    );
  }
}

// ================================================================== directory
/// Phone-book of all farmers / villages / brokers / vehicles / labour.
class PartyDirectoryScreen extends StatefulWidget {
  const PartyDirectoryScreen({super.key});

  @override
  State<PartyDirectoryScreen> createState() => _PartyDirState();
}

class _PartyDirState extends State<PartyDirectoryScreen> {
  static const List<Dim> _dims = <Dim>[Dim.farmer, Dim.village, Dim.broker, Dim.vehicle, Dim.majur];
  final TextEditingController _c = TextEditingController();
  int _d = 0;
  int _sort = 0;
  int _n = 40;
  String _q = '';

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 900,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final bool pc = DeviceScope.isPc(ctx);
        final Dim dim = _dims[_d];
        final String q = _q.trim().toLowerCase();
        List<PartySummary> l = directoryOf(dim).where((PartySummary s) => q.isEmpty || s.ref.label.toLowerCase().contains(q)).toList();
        l.sort((PartySummary a, PartySummary b) {
          if (_sort == 1) return b.last.compareTo(a.last);
          if (_sort == 2) return a.ref.label.toLowerCase().compareTo(b.ref.label.toLowerCase());
          return b.kg.compareTo(a.kg);
        });
        final List<PartyRef> pins = <PartyRef>[];
        live.pins.forEach((String id, String label) {
          final PartyRef? p = _refOfPin(id, label);
          if (p != null) pins.add(p);
        });

        Widget tile(PartySummary s) {
          final bool pinned = live.isPinned(s.ref.id);
          return rowShell(
            onTap: () => openParty(s.ref),
            child: Row(
              children: <Widget>[
                Avatar(s.ref.label.isEmpty ? '?' : s.ref.label, size: 40),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(s.ref.label.isEmpty ? '—' : s.ref.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14.5, w: FontWeight.w800)),
                      const SizedBox(height: 2),
                      Text('${s.chits} ${bi('ચિઠ્ઠી', 'chits')} · ${bi('છેલ્લી', 'last')} ${dayLabel(s.last)}', style: ts(12, c: Pal.muted)),
                    ],
                  ),
                ),
                Text(kgShort(s.kg), style: ts(14, w: FontWeight.w800, tab: true)),
                IconBtn(pinned ? 'star' : 'staro', size: 38, color: pinned ? Pal.amber : Pal.faint, onTap: () => live.togglePinned(s.ref.id, s.ref.label)),
              ],
            ),
          );
        }

        return <Widget>[
          ScreenHeader(bi('પાર્ટી ડિરેક્ટરી', 'Parties'), sub: '${l.length} ${dimName(dim)}', actions: <Widget>[refreshBtn()]),
          statusBanner(),
          ChipRow(
            labels: <String>[for (final Dim x in _dims) dimName(x)],
            index: _d,
            onChanged: (int i) => setState(() {
              _d = i;
              _n = 40;
            }),
          ),
          const SizedBox(height: 10),
          SearchBox(hint: bi('નામ શોધો…', 'Search name…'), controller: _c, width: pc ? 360 : null, onChanged: (String v) => setState(() {
                _q = v;
                _n = 40;
              })),
          const SizedBox(height: 10),
          Seg(dense: true, labels: <String>[bi('વધુ માલ', 'Most weight'), bi('તાજેતરના', 'Recent'), bi('નામ', 'Name')], index: _sort, onChanged: (int i) => setState(() => _sort = i)),
          if (pins.isNotEmpty) ...<Widget>[
            const SizedBox(height: 14),
            SectionTitle(bi('પિન કરેલા', 'Pinned'), sub: '${pins.length}'),
            const SizedBox(height: 8),
            Wrap(spacing: 8, runSpacing: 8, children: <Widget>[for (final PartyRef p in pins) partyChip(p, extra: dimName(p.dim))]),
          ],
          const SizedBox(height: 14),
          if (l.isEmpty) EmptyBox(icon: 'users', title: bi('કોઈ મળ્યું નથી', 'Nobody found')) else for (final PartySummary s in l.take(_n)) tile(s),
          if (_n < l.length) Btn(bi('વધુ બતાવો (${l.length - _n})', 'Show more (${l.length - _n})'), kind: BtnKind.tonal, expand: true, onTap: () => setState(() => _n += 40)),
        ];
      },
    );
  }
}

// ================================================================== table view
class _Table {
  final List<String> header;
  final List<List<Object?>> rows;
  final List<Object> objs;
  const _Table(this.header, this.rows, this.objs);
}

/// Spreadsheet-like view with sorting, search and CSV copy.
class TableViewScreen extends StatefulWidget {
  const TableViewScreen({super.key});

  @override
  State<TableViewScreen> createState() => _TableViewState();
}

class _TableViewState extends State<TableViewScreen> {
  RangeSel _sel = RangeSel(2);
  int _set = 0;
  int _col = -1;
  bool _asc = true;
  String _q = '';
  final TextEditingController _c = TextEditingController();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  _Table _build(Period p) {
    final List<List<Object?>> rows = <List<Object?>>[];
    final List<Object> objs = <Object>[];
    List<String> header;
    if (_set == 0) {
      header = chitHeader();
      for (final Chit c in live.chits) {
        if (p.has(c.at)) {
          rows.add(chitRow(c));
          objs.add(c);
        }
      }
    } else if (_set == 1) {
      header = kantaHeader();
      for (final Kanta k in live.kantas) {
        if (p.has(k.at)) {
          rows.add(kantaRow(k));
          objs.add(k);
        }
      }
    } else if (_set == 2) {
      header = maalHeader();
      for (final MaalRow m in live.maals) {
        if (p.has(m.date)) {
          rows.add(maalRow(m));
          objs.add(m);
        }
      }
    } else {
      header = tripHeader();
      for (final Trip t in live.trips) {
        if (p.has(t.at)) {
          rows.add(tripRow(t));
          objs.add(t);
        }
      }
    }
    final String q = _q.trim().toLowerCase();
    List<int> idx = <int>[for (int i = 0; i < rows.length; i++) i];
    if (q.isNotEmpty) {
      idx = idx.where((int i) => rows[i].map((Object? v) => '$v').join(' ').toLowerCase().contains(q)).toList();
    }
    if (_col >= 0 && _col < header.length) {
      idx.sort((int a, int b) {
        final Object? x = rows[a][_col];
        final Object? y = rows[b][_col];
        int r;
        if (x is num && y is num) {
          r = x.compareTo(y);
        } else {
          r = '$x'.toLowerCase().compareTo('$y'.toLowerCase());
        }
        return _asc ? r : -r;
      });
    }
    return _Table(header, <List<Object?>>[for (final int i in idx) rows[i]], <Object>[for (final int i in idx) objs[i]]);
  }

  void _openObj(BuildContext ctx, Object o) {
    if (o is Chit) {
      showChitDetail(ctx, o);
    } else if (o is Kanta) {
      showKantaDetail(ctx, o);
    } else if (o is MaalRow) {
      showMaalDetail(ctx, o);
    } else if (o is Trip) {
      showTripDetail(ctx, o);
    }
  }

  String _cell(String h, Object? v) {
    if (v is num && (h.endsWith('_kg') || h == 'kg')) return grp(v);
    return v == null ? '' : '$v';
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 1560,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final bool pc = DeviceScope.isPc(ctx);
        final Period p = _sel.period;
        final _Table t = _build(p);
        const int cap = 300;
        final int shown = math.min(cap, t.rows.length);
        final List<DataColumn> cols = <DataColumn>[
          for (int i = 0; i < t.header.length; i++)
            DataColumn(
              label: Text(t.header[i], style: ts(12, w: FontWeight.w800, c: Pal.muted)),
              numeric: t.rows.isNotEmpty && t.rows.first[i] is num,
              onSort: (int ci, bool asc) => setState(() {
                _col = ci;
                _asc = asc;
              }),
            ),
        ];
        final List<DataRow> drows = <DataRow>[
          for (int r = 0; r < shown; r++)
            DataRow(
              onSelectChanged: (bool? _) => _openObj(ctx, t.objs[r]),
              cells: <DataCell>[for (int i = 0; i < t.header.length; i++) DataCell(Text(_cell(t.header[i], t.rows[r][i]), style: ts(12.5, tab: true)))],
            ),
        ];
        return <Widget>[
          ScreenHeader(bi('ટેબલ વ્યુ', 'Table view'), sub: '${t.rows.length} ${bi('લાઇન', 'rows')} · ${p.label}', actions: <Widget>[
            Btn(bi('CSV કૉપિ', 'Copy CSV'), icon: 'copy', dense: true, kind: BtnKind.tonal, onTap: () => copyText(csvOf(t.header, t.rows), msg: bi('CSV કૉપિ થયું (${t.rows.length} લાઇન)', 'CSV copied (${t.rows.length} rows)'))),
            refreshBtn(),
          ]),
          statusBanner(),
          RangeBar(sel: _sel, onChanged: (RangeSel r) => setState(() => _sel = r)),
          const SizedBox(height: 10),
          Wrap(
            spacing: 12,
            runSpacing: 10,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: <Widget>[
              Seg(
                dense: true,
                labels: <String>[bi('ચિઠ્ઠી', 'Chits'), bi('કાંટો', 'Kanta'), bi('માલ', 'Maal'), bi('ગાડી', 'Trips')],
                index: _set,
                onChanged: (int i) => setState(() {
                  _set = i;
                  _col = -1;
                }),
              ),
              SearchBox(hint: bi('ટેબલમાં શોધો…', 'Search the table…'), controller: _c, width: pc ? 320 : 240, onChanged: (String v) => setState(() => _q = v)),
            ],
          ),
          const SizedBox(height: 12),
          if (t.rows.isEmpty)
            EmptyBox(icon: 'table', title: bi('આ સમયમાં કોઈ લાઇન નથી', 'No rows in this period'))
          else
            Surface(
              padding: EdgeInsets.zero,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: ConstrainedBox(
                    constraints: BoxConstraints(minWidth: pc ? 900 : 0),
                    child: DataTable(
                      sortColumnIndex: _col >= 0 ? _col : null,
                      sortAscending: _asc,
                      showCheckboxColumn: false,
                      columnSpacing: 22,
                      headingRowHeight: 42,
                      dataRowMinHeight: 38,
                      dataRowMaxHeight: 46,
                      columns: cols,
                      rows: drows,
                    ),
                  ),
                ),
              ),
            ),
          if (t.rows.length > cap)
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Text(bi('પહેલી $cap લાઇન બતાવી છે. બધી માટે CSV કૉપિ કરો અથવા તારીખ ઘટાડો.', 'Showing the first $cap rows. Copy CSV for all rows or narrow the dates.'), style: ts(12.5, c: Pal.muted)),
            ),
        ];
      },
    );
  }
}

// ================================================================= export hub
class _Exp {
  final String icon;
  final String tone;
  final String title;
  final int count;
  final String Function() csv;
  const _Exp(this.icon, this.tone, this.title, this.count, this.csv);
}

/// Copy any list as CSV (paste into Excel / Google Sheets / WhatsApp).
class ExportScreen extends StatefulWidget {
  const ExportScreen({super.key});

  @override
  State<ExportScreen> createState() => _ExportState();
}

class _ExportState extends State<ExportScreen> {
  RangeSel _sel = RangeSel(3);

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 800,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = _sel.period;
        final List<Chit> cs = live.chits.where((Chit c) => p.has(c.at)).toList();
        final List<Kanta> ks = live.kantas.where((Kanta c) => p.has(c.at)).toList();
        final List<MaalRow> ms = live.maals.where((MaalRow c) => p.has(c.date)).toList();
        final List<Trip> tl = live.trips.where((Trip c) => p.has(c.at)).toList();
        final List<Finding> fs = live.findings.where((Finding c) => p.has(c.at)).toList();
        final List<_Exp> items = <_Exp>[
          _Exp('receipt', 'teal', bi('ચિઠ્ઠી', 'Chits'), cs.length, () => csvOf(chitHeader(), <List<Object?>>[for (final Chit c in cs) chitRow(c)])),
          _Exp('scale', 'blue', bi('કાંટો', 'Weighbridge'), ks.length, () => csvOf(kantaHeader(), <List<Object?>>[for (final Kanta c in ks) kantaRow(c)])),
          _Exp('bag', 'amber', bi('માલ', 'Maal'), ms.length, () => csvOf(maalHeader(), <List<Object?>>[for (final MaalRow c in ms) maalRow(c)])),
          _Exp('truck', 'violet', bi('ગાડી (મેળ)', 'Vehicles (match)'), tl.length, () => csvOf(tripHeader(), <List<Object?>>[for (final Trip c in tl) tripRow(c)])),
          _Exp('warn', 'rose', bi('ધ્યાનમાં લો યાદી', 'Alerts'), fs.length, () => csvOf(findingHeader(), <List<Object?>>[for (final Finding c in fs) findingRow(c)])),
        ];
        return <Widget>[
          ScreenHeader(bi('એક્સપોર્ટ', 'Export'), sub: p.label, actions: <Widget>[refreshBtn()]),
          statusBanner(),
          RangeBar(sel: _sel, onChanged: (RangeSel r) => setState(() => _sel = r)),
          const SizedBox(height: 12),
          Text(bi('"CSV કૉપિ" દબાવો, પછી Excel / Google Sheets / WhatsApp માં પેસ્ટ કરો.', 'Tap "Copy CSV", then paste into Excel / Google Sheets / WhatsApp.'), style: ts(12.5, c: Pal.muted, h: 1.4)),
          const SizedBox(height: 12),
          for (final _Exp e in items)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Surface(
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: <Widget>[
                    IconChip(e.icon, tone: e.tone, size: 42),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(e.title, style: ts(14.5, w: FontWeight.w800)),
                          Text('${e.count} ${bi('લાઇન', 'rows')}', style: ts(12.5, c: Pal.muted)),
                        ],
                      ),
                    ),
                    Btn(bi('CSV કૉપિ', 'Copy CSV'), icon: 'copy', dense: true, kind: BtnKind.tonal, onTap: e.count == 0 ? null : () => copyText(e.csv(), msg: bi('${e.title} CSV કૉપિ થયું', '${e.title} CSV copied'))),
                  ],
                ),
              ),
            ),
          Surface(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: <Widget>[
                const IconChip('doc', tone: 'green', size: 42),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(bi('પૂરો રિપોર્ટ (લખાણ)', 'Full report (text)'), style: ts(14.5, w: FontWeight.w800)),
                      Text(bi('WhatsApp માટે તૈયાર', 'Ready for WhatsApp'), style: ts(12.5, c: Pal.muted)),
                    ],
                  ),
                ),
                Btn(bi('કૉપિ', 'Copy'), icon: 'copy', dense: true, kind: BtnKind.tonal, onTap: () => copyText(buildReport(p))),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Btn(bi('ટેબલ વ્યુ ખોલો', 'Open table view'), icon: 'table', kind: BtnKind.outline, expand: true, onTap: () => app.go('table')),
        ];
      },
    );
  }
}

// ================================================================== photo wall
class _Ph {
  final String url;
  final String title;
  final String sub;
  final DateTime at;
  final VoidCallback open;
  const _Ph(this.url, this.title, this.sub, this.at, this.open);
}

/// All slip photos as a wall of thumbnails.
class PhotoWallScreen extends StatefulWidget {
  const PhotoWallScreen({super.key});

  @override
  State<PhotoWallScreen> createState() => _PhotoWallState();
}

class _PhotoWallState extends State<PhotoWallScreen> {
  RangeSel _sel = RangeSel(2);
  int _kind = 0;
  int _n = 48;

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 1300,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final bool pc = DeviceScope.isPc(ctx);
        final Period p = _sel.period;
        final List<_Ph> l = <_Ph>[];
        int missing = 0;
        if (_kind == 0 || _kind == 1) {
          for (final Chit c in live.chits) {
            if (!p.has(c.at)) continue;
            if (c.photo.isEmpty) {
              missing++;
            } else {
              l.add(_Ph(c.photo, '#${vtxt(c.no)} ${c.farmer}', '${grp(c.cmpKg)} KG', c.at, () => showChitDetail(ctx, c)));
            }
          }
        }
        if (_kind == 0 || _kind == 2) {
          for (final Kanta k in live.kantas) {
            if (!p.has(k.at)) continue;
            if (k.slip.isEmpty) {
              missing++;
            } else {
              l.add(_Ph(k.slip, 'RST ${vtxt(k.rst)}', '${vtxt(k.vehicle)} · ${grp(k.kg)} KG', k.at, () => showKantaDetail(ctx, k)));
            }
          }
        }
        if (_kind == 0 || _kind == 3) {
          for (final MaalRow m in live.maals) {
            if (!p.has(m.date)) continue;
            if (m.slip.isEmpty) {
              missing++;
            } else {
              l.add(_Ph(m.slip, vtxt(m.vehicle), '${m.bags} ${bi('બેગ', 'bags')}', m.at, () => showMaalDetail(ctx, m)));
            }
          }
        }
        l.sort((_Ph a, _Ph b) => b.at.compareTo(a.at));
        return <Widget>[
          ScreenHeader(bi('સ્લિપ ફોટા', 'Slip photos'), sub: '${l.length} ${bi('ફોટા', 'photos')} · ${p.label}', actions: <Widget>[refreshBtn()]),
          statusBanner(),
          RangeBar(sel: _sel, presets: const <int>[0, 1, 2, 3, 4], onChanged: (RangeSel r) => setState(() {
                _sel = r;
                _n = 48;
              })),
          const SizedBox(height: 10),
          Seg(
            dense: true,
            labels: <String>[bi('બધા', 'All'), bi('ચિઠ્ઠી', 'Chit'), bi('કાંટો', 'Kanta'), bi('માલ', 'Maal')],
            index: _kind,
            onChanged: (int i) => setState(() {
              _kind = i;
              _n = 48;
            }),
          ),
          if (missing > 0) ...<Widget>[
            const SizedBox(height: 10),
            Pill('$missing ${bi('એન્ટ્રીમાં ફોટો નથી', 'entries have no photo')}', tone: 'amber', icon: 'warn'),
          ],
          const SizedBox(height: 12),
          if (l.isEmpty)
            EmptyBox(icon: 'img', title: bi('આ સમયમાં કોઈ ફોટો નથી', 'No photos in this period'))
          else
            LayoutBuilder(builder: (BuildContext c, BoxConstraints box) {
              final int cols = pc ? gridCols(box.maxWidth, min: 190, max: 6) : 3;
              const double gap = 8;
              final double w = (box.maxWidth - gap * (cols - 1)) / cols;
              return Wrap(
                spacing: gap,
                runSpacing: gap,
                children: <Widget>[for (final _Ph x in l.take(_n)) _thumb(x, w)],
              );
            }),
          const SizedBox(height: 12),
          if (_n < l.length) Btn(bi('વધુ ફોટા (${l.length - _n})', 'More photos (${l.length - _n})'), kind: BtnKind.tonal, expand: true, onTap: () => setState(() => _n += 48)),
        ];
      },
    );
  }

  Widget _thumb(_Ph x, double w) {
    return SizedBox(
      width: w,
      height: w * 1.1,
      child: Material(
        color: Pal.surface2,
        borderRadius: BorderRadius.circular(12),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: x.open,
          child: Stack(
            fit: StackFit.expand,
            children: <Widget>[
              Image.network(
                x.url,
                fit: BoxFit.cover,
                cacheWidth: 360,
                errorBuilder: (BuildContext c, Object e, StackTrace? s) => Center(child: Icon(ic('img'), color: Pal.faint)),
                loadingBuilder: (BuildContext c, Widget child, ImageChunkEvent? prog) => prog == null ? child : const Center(child: SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))),
              ),
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: Container(
                  padding: const EdgeInsets.fromLTRB(8, 14, 8, 6),
                  decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: <Color>[Color(0x00000000), Color(0xB3000000)])),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(x.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(11.5, w: FontWeight.w800, c: Colors.white)),
                      Text('${x.sub} · ${dm(x.at)}', maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(10.5, c: const Color(0xCCFFFFFF))),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ==================================================================== calculator
/// Full Hisab calculator (same as the web app) + the weighbridge loss check as an extra tab.
class CalcScreen extends StatelessWidget {
  const CalcScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ScreenScroll(
      maxWidth: 640,
      children: <Widget>[
        ScreenHeader(bi('હિસાબ કૅલ્ક્યુલેટર', 'Calculator')),
        HisabCalc(extraLabel: bi('ઘટ તપાસ', 'Loss check'), extra: const _LossCheck()),
      ],
    );
  }
}

/// Chit weight vs weighbridge weight against the allowed difference.
class _LossCheck extends StatefulWidget {
  const _LossCheck();

  @override
  State<_LossCheck> createState() => _LossCheckState();
}

class _LossCheckState extends State<_LossCheck> {
  final TextEditingController _chit = TextEditingController();
  final TextEditingController _kanta = TextEditingController();

  @override
  void dispose() {
    _chit.dispose();
    _kanta.dispose();
    super.dispose();
  }

  void _r([String? _]) => setState(() {});

  @override
  Widget build(BuildContext context) {
    final double chit = _num(_chit.text);
    final double kanta = _num(_kanta.text);
    final bool ready = chit > 0 && kanta > 0;
    final double diff = kanta - chit;
    final double pc = chit > 0 ? diff / chit * 100 : 0;
    final double tol = live.cfg.tol(chit);
    final bool ok = diff.abs() <= tol;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              FieldX(label: bi('ચિઠ્ઠીનું વજન', 'Chit weight'), controller: _chit, suffix: 'KG', big: true, keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: _r),
              const SizedBox(height: 12),
              FieldX(label: bi('કાંટાનું વજન', 'Weighbridge weight'), controller: _kanta, suffix: 'KG', big: true, keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: _r),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Surface(
          padding: const EdgeInsets.all(18),
          child: !ready
              ? Text(bi('બંને વજન લખો', 'Enter both weights'), style: ts(14, c: Pal.muted))
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(children: <Widget>[Pill(ok ? bi('બરાબર', 'Within limit') : bi('ફરક વધારે', 'Over the limit'), tone: ok ? 'green' : 'rose', icon: ok ? 'check' : 'warn')]),
                    const SizedBox(height: 10),
                    Text('${sk(diff)} KG', style: ts(34, w: FontWeight.w800, c: ok ? Pal.ok : (diff < 0 ? Pal.bad : Pal.warn), tab: true, ls: -1)),
                    Text('${pc.toStringAsFixed(2)}%', style: ts(15, w: FontWeight.w700, c: Pal.muted)),
                    const SizedBox(height: 10),
                    divider(),
                    InfoRow(bi('માન્ય ફરક', 'Allowed'), '± ${grp(tol)} KG'),
                    InfoRow(bi('નિયમ', 'Rule'), '${live.cfg.pct}% ${bi('અથવા ઓછામાં ઓછા', 'or at least')} ${grp(live.cfg.floorKg)} KG'),
                  ],
                ),
        ),
      ],
    );
  }
}
