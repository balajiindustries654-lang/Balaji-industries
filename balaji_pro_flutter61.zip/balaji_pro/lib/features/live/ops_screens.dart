import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/device.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/icons.dart';
import '../../core/palette.dart';
import '../../data/engine.dart';
import '../../data/insights.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../widgets/charts.dart';
import '../../widgets/common.dart';
import '../../widgets/page.dart';
import 'audit.dart';
import 'kit.dart';
import 'ui.dart';

// ================================================================ live board
/// One screen that shows "what is happening right now" - made to be left open
/// on the office PC.
class LiveBoardScreen extends StatelessWidget {
  const LiveBoardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 1500,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final bool pc = DeviceScope.isPc(ctx);
        final DateTime now = DateTime.now();
        final DateTime today = dayOf(now);
        final Period p = Period(today, addDays(today, 1));
        final Stats s = statsFor(p);
        final List<Trip> tt = live.trips.where((Trip t) => p.has(t.at)).toList();
        final List<Trip> onWay = tt.where((Trip t) => t.state == TripState.wait).toList();
        final List<Trip> noK = tt.where((Trip t) => t.state == TripState.noKanta).toList();
        final List<Finding> hot = live.openFindings.where((Finding f) => f.sev >= 2 && p.has(f.at)).toList();
        final Hourly h = hourlyOf(p, 2);
        final Hourly hc = hourlyOf(p, 1);
        int lo = 6;
        int hi = 21;
        for (int i = 0; i < 24; i++) {
          if ((h.byHour[i] > 0 || hc.byHour[i] > 0) && i < lo) lo = i;
          if ((h.byHour[i] > 0 || hc.byHour[i] > 0) && i > hi) hi = i;
        }
        final List<double> vals = <double>[for (int i = lo; i <= hi; i++) h.byHour[i] / 1000];
        final List<String> labs = <String>[for (int i = lo; i <= hi; i++) (i % 2 == 0 ? '$i' : '')];
        final int curIdx = now.hour - lo;

        // last 7 days sparkline (kanta tons)
        final List<DayPoint> week = dailySeries(Period(addDays(today, -6), addDays(today, 1)));

        final Widget hero = HeroCard(
          title: bi('આજે કાંટા પર આવ્યો માલ', 'Weighed in today'),
          value: s.kantaKg >= 10000 ? (s.kantaKg / 1000).toStringAsFixed(2) : grp(s.kantaKg),
          unit: s.kantaKg >= 10000 ? bi('ટન', 'tons') : 'KG',
          sub: '${s.kantas} ${bi('કાંટા એન્ટ્રી', 'weighbridge entries')} · ${s.chits} ${bi('ચિઠ્ઠી', 'chits')} (${kgShort(s.chitKg)})',
          spark: <double>[for (final DayPoint d in week) d.kantaKg / 1000],
          chips: <HeroChip>[
            HeroChip('truck', '${s.trips} ${bi('ગાડી', 'vehicles')}'),
            HeroChip('check', '${s.okTrips} ${bi('બરાબર', 'ok')}'),
            HeroChip('warn', '${s.diffTrips} ${bi('ફરક', 'differ')}'),
            HeroChip('clock', hm(now)),
          ],
          onTap: () => app.go('kanta'),
        );

        final Widget tiles = metricGrid(ctx, <Widget>[
          MetricTile(
            label: bi('રસ્તામાં', 'On the way'),
            value: '${onWay.length}',
            icon: 'route',
            tone: 'amber',
            sub: bi('ચિઠ્ઠી બની, કાંટો બાકી', 'chit made, kanta pending'),
            onTap: () => app.go('missing_kanta'),
          ),
          MetricTile(
            label: bi('કાંટો ભૂલાયો?', 'Kanta overdue'),
            value: '${noK.length}',
            icon: 'scale',
            tone: noK.isEmpty ? 'green' : 'rose',
            sub: bi('રાહ જોવાનો સમય પૂરો', 'waiting time is over'),
            onTap: () => app.go('missing_kanta'),
          ),
          MetricTile(
            label: bi('તપાસ માંગે છે', 'Needs checking'),
            value: '${hot.length}',
            icon: 'warn',
            tone: hot.isEmpty ? 'green' : 'rose',
            onTap: () => app.go('alerts'),
          ),
          MetricTile(
            label: bi('ફરક (મેળ થયેલ)', 'Difference (matched)'),
            value: s.compared == 0 ? '—' : '${sk(s.ghat)} KG',
            icon: 'cmp',
            tone: s.compared == 0 ? 'slate' : (s.ghat.abs() <= live.cfg.tol(s.mChit) ? 'green' : 'rose'),
            sub: s.compared == 0 ? null : '${s.ghatPct.toStringAsFixed(2)}% · ${s.compared} ${bi('ગાડી', 'trips')}',
            onTap: () => app.go('mel'),
          ),
        ]);

        final Widget chart = Panel(
          title: bi('કલાક મુજબ કાંટો (ટન)', 'Weighed per hour (tons)'),
          sub: s.kantas == 0 ? bi('આજે હજી કાંટો થયો નથી', 'No weighing yet today') : '${bi('સૌથી વ્યસ્ત', 'Busiest')}: ${h.peakHour}:00',
          child: BarChartX(
            values: vals,
            labels: labs,
            color: Pal.info,
            highlight: (curIdx >= 0 && curIdx < vals.length) ? curIdx : null,
            axisFmt: (double v) => v.toStringAsFixed(v < 10 ? 1 : 0),
            valueFmt: (double v) => '${v.toStringAsFixed(1)} T',
            height: pc ? 230 : 190,
          ),
        );

        final List<Trip> wait = <Trip>[...onWay, ...noK];
        final Widget waiting = Panel(
          title: bi('કાંટાની રાહમાં ગાડી', 'Vehicles waiting for kanta'),
          sub: '${wait.length}',
          child: wait.isEmpty
              ? EmptyBox(icon: 'check', title: bi('કોઈ ગાડી બાકી નથી', 'Nothing pending'))
              : Column(children: <Widget>[for (final Trip t in wait.take(8)) tripTile(ctx, t)]),
        );

        // latest entries from everybody
        final List<MapEntry<DateTime, Widget>> ev = <MapEntry<DateTime, Widget>>[];
        for (final Chit x in live.chits.take(12)) {
          ev.add(MapEntry<DateTime, Widget>(x.at, chitTile(ctx, x)));
        }
        for (final Kanta x in live.kantas.take(12)) {
          ev.add(MapEntry<DateTime, Widget>(x.at, kantaTile(ctx, x)));
        }
        for (final MaalRow x in live.maals.take(12)) {
          ev.add(MapEntry<DateTime, Widget>(x.at, maalTile(ctx, x)));
        }
        ev.sort((MapEntry<DateTime, Widget> a, MapEntry<DateTime, Widget> b) => b.key.compareTo(a.key));
        final Widget latest = Panel(
          title: bi('હમણાંની એન્ટ્રી', 'Latest entries'),
          action: Btn(bi('ફીડ', 'Feed'), dense: true, kind: BtnKind.tonal, onTap: () => app.go('feed')),
          child: ev.isEmpty ? EmptyBox(icon: 'list', title: bi('હજી કોઈ એન્ટ્રી નથી', 'No entries yet')) : Column(children: <Widget>[for (final MapEntry<DateTime, Widget> e in ev.take(7)) e.value]),
        );

        final Widget attention = Panel(
          title: bi('આજની શંકા', 'Today\'s alerts'),
          sub: '${hot.length}',
          action: Btn(bi('બધા', 'All'), dense: true, kind: BtnKind.tonal, onTap: () => app.go('alerts')),
          child: hot.isEmpty ? EmptyBox(icon: 'check', title: bi('બધું બરાબર છે', 'All clear')) : Column(children: <Widget>[for (final Finding f in hot.take(5)) findingTile(ctx, f)]),
        );

        return <Widget>[
          ScreenHeader(
            bi('લાઇવ બોર્ડ', 'Live board'),
            sub: '${dmy(now)} · ${live.loadedAt == null ? '' : '${bi('અપડેટ', 'updated')} ${hm(live.loadedAt!)}'}',
            actions: <Widget>[refreshBtn()],
          ),
          statusBanner(),
          hero,
          const SizedBox(height: 14),
          tiles,
          const SizedBox(height: 16),
          SplitPane(flex: const <int>[3, 2], children: <Widget>[chart, waiting]),
          const SizedBox(height: 16),
          SplitPane(flex: const <int>[3, 2], children: <Widget>[latest, attention]),
        ];
      },
    );
  }
}

// ============================================================== day-close list
class _Check {
  final String icon;
  final String title;
  final String detail;
  final int count;
  final String level; // ok | warn | bad
  final String? route;
  const _Check(this.icon, this.title, this.detail, this.count, this.level, this.route);
}

/// Evening checklist: is everything of the day entered and checked?
class LiveDayCloseScreen extends StatefulWidget {
  const LiveDayCloseScreen({super.key});

  @override
  State<LiveDayCloseScreen> createState() => _DayCloseState();
}

class _DayCloseState extends State<LiveDayCloseScreen> {
  int _i = 0;

  List<_Check> _checks(DateTime d) {
    final Period p = Period(d, addDays(d, 1));
    final List<Trip> tt = live.trips.where((Trip t) => p.has(t.at)).toList();
    int cnt(TripState s) => tt.where((Trip t) => t.state == s).length;
    final int nk = cnt(TripState.noKanta);
    final int nc = cnt(TripState.noChit);
    final int wait = cnt(TripState.wait);
    final List<Finding> open = live.openFindings.where((Finding f) => p.has(f.at)).toList();
    final int diff = open.where((Finding f) => f.rule == Rule.mismatch).length;
    final int other = open.where((Finding f) => f.sev >= 2 && (f.rule == Rule.dup || f.rule == Rule.odd || f.rule == Rule.rstGap)).length;
    final int photo = open.where((Finding f) => f.rule == Rule.photo && f.sev >= 1).length;
    final int maal = live.maals.where((MaalRow m) => p.has(m.date)).length;
    final bool isToday = sameDay(d, DateTime.now());
    return <_Check>[
      _Check('scale', bi('દરેક ચિઠ્ઠીનો કાંટો થયો', 'Every chit has a kanta entry'), nk == 0 ? bi('બધી ગાડીનો કાંટો છે', 'All vehicles weighed') : bi('$nk ગાડીનો કાંટો બાકી', '$nk vehicles not weighed'), nk, nk == 0 ? 'ok' : 'bad', 'missing_kanta'),
      _Check('receipt', bi('દરેક કાંટાની ચિઠ્ઠી છે', 'Every kanta has a chit'), nc == 0 ? bi('કાંટા વગર ચિઠ્ઠી નથી', 'No orphan kanta') : bi('$nc કાંટાની ચિઠ્ઠી નથી', '$nc kanta entries without chit'), nc, nc == 0 ? 'ok' : 'bad', 'missing_chit'),
      _Check('cmp', bi('વજન ફરક તપાસ્યા', 'Weight differences checked'), diff == 0 ? bi('કોઈ ફરક બાકી નથી', 'No open difference') : bi('$diff ફરક જોવાના બાકી', '$diff differences to look at'), diff, diff == 0 ? 'ok' : 'bad', 'alerts'),
      _Check('warn', bi('બીજી શંકા', 'Other alerts'), other == 0 ? bi('ડુપ્લિકેટ / અજુગતી વિગત નથી', 'No duplicate / odd values') : bi('$other બાબત જોવાની', '$other items to look at'), other, other == 0 ? 'ok' : 'warn', 'alerts'),
      _Check('img', bi('સ્લિપના ફોટા', 'Slip photos'), photo == 0 ? bi('બધી એન્ટ્રીમાં ફોટો છે', 'All entries have photos') : bi('$photo એન્ટ્રીમાં ફોટો નથી', '$photo entries without photo'), photo, photo == 0 ? 'ok' : 'warn', 'no_photo'),
      _Check('bag', bi('માલ એન્ટ્રી નોંધાઈ', 'Maal entries recorded'), maal > 0 ? bi('$maal માલ એન્ટ્રી', '$maal maal entries') : (tt.isEmpty ? bi('આજે ગાડી નથી', 'No vehicles') : bi('ગાડી આવી પણ માલ એન્ટ્રી નથી', 'Vehicles came but no maal entry')), maal, (maal > 0 || tt.isEmpty) ? 'ok' : 'warn', 'maal'),
      _Check('cloudup', bi('મોકલવાની બાકી એન્ટ્રી', 'Entries waiting to upload'), live.pending.isEmpty ? bi('કંઈ બાકી નથી', 'Nothing waiting') : bi('${live.pending.length} એન્ટ્રી ફોનમાં છે', '${live.pending.length} entries still on a phone'), live.pending.length, live.pending.isEmpty ? 'ok' : 'warn', 'offline_queue'),
      if (isToday && wait > 0) _Check('route', bi('રસ્તામાં ગાડી', 'Vehicles on the way'), bi('$wait ગાડીનો કાંટો હજી થવાનો છે', '$wait vehicles still to be weighed'), wait, 'warn', 'missing_kanta'),
    ];
  }

  String _who(String info) {
    final int i = info.indexOf('|');
    if (i < 0) return info;
    final String name = info.substring(0, i);
    final DateTime? t = DateTime.tryParse(info.substring(i + 1));
    return '${name.isEmpty ? '' : '$name · '}${t == null ? '' : whenTxt(t)}';
  }

  Future<void> _close(DateTime d, int bad) async {
    if (bad > 0) {
      final bool? ok = await showDialog<bool>(
        context: context,
        builder: (BuildContext c) => AlertDialog(
          title: Text(bi('હજી $bad બાબત બાકી છે', '$bad items are still open')),
          content: Text(bi('છતાં દિવસ બંધ કરવો છે?', 'Close the day anyway?')),
          actions: <Widget>[
            TextButton(onPressed: () => Navigator.of(c).pop(false), child: Text(bi('ના', 'No'))),
            TextButton(onPressed: () => Navigator.of(c).pop(true), child: Text(bi('હા, બંધ કરો', 'Yes, close'))),
          ],
        ),
      );
      if (ok != true) return;
    }
    live.closeDay(d, true);
    app.toast(bi('દિવસ બંધ થયો', 'Day closed'));
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 900,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final DateTime today = dayOf(DateTime.now());
        final List<DateTime> days = <DateTime>[for (int i = 0; i < 7; i++) addDays(today, -i)];
        final DateTime d = days[_i];
        final List<_Check> cs = _checks(d);
        final int okN = cs.where((_Check c) => c.level == 'ok').length;
        final int badN = cs.length - okN;
        final bool closed = live.isClosed(d);
        final Color ringC = badN == 0 ? Pal.ok : (cs.any((_Check c) => c.level == 'bad') ? Pal.bad : Pal.warn);

        Widget row(_Check c) {
          final String tone = c.level == 'ok' ? 'green' : (c.level == 'warn' ? 'amber' : 'rose');
          return rowShell(
            onTap: c.route == null ? null : () => app.go(c.route!),
            bar: Pal.tone(tone).fg,
            child: Row(
              children: <Widget>[
                IconChip(c.level == 'ok' ? 'check' : c.icon, tone: tone, size: 40),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(c.title, style: ts(14, w: FontWeight.w800)),
                      const SizedBox(height: 2),
                      Text(c.detail, style: ts(12.5, c: Pal.muted)),
                    ],
                  ),
                ),
                if (c.level != 'ok') ...<Widget>[const SizedBox(width: 8), Pill('${c.count}', tone: tone), Icon(ic('chev'), size: 18, color: Pal.faint)],
              ],
            ),
          );
        }

        // last 14 days overview
        final List<Widget> history = <Widget>[];
        for (int i = 0; i < 14; i++) {
          final DateTime x = addDays(today, -i);
          final bool cl = live.isClosed(x);
          history.add(
            InkWell(
              onTap: i < 7 ? () => setState(() => _i = i) : null,
              borderRadius: BorderRadius.circular(10),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
                child: Row(
                  children: <Widget>[
                    Icon(ic(cl ? 'lock' : 'lockopen'), size: 18, color: cl ? Pal.ok : Pal.faint),
                    const SizedBox(width: 10),
                    Expanded(child: Text('${dayLabel(x)} · ${dayName(x)}', style: ts(13.5, w: FontWeight.w700))),
                    Text(cl ? _who(live.closedInfo(x)) : bi('ખુલ્લો', 'Open'), style: ts(12, c: cl ? Pal.ok : Pal.faint, w: FontWeight.w700)),
                  ],
                ),
              ),
            ),
          );
          if (i < 13) history.add(divider());
        }

        return <Widget>[
          ScreenHeader(bi('દિવસ બંધ ચેકલિસ્ટ', 'Day-close checklist'), sub: '${dmy(d)} · ${dayName(d)}', actions: <Widget>[refreshBtn()]),
          statusBanner(),
          ChipRow(labels: <String>[for (final DateTime x in days) dayLabel(x)], index: _i, onChanged: (int i) => setState(() => _i = i)),
          const SizedBox(height: 14),
          Surface(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: <Widget>[
                ScoreRing(value: cs.isEmpty ? 0 : okN / cs.length, center: '$okN/${cs.length}', color: ringC, sub: bi('બરાબર', 'ok'), size: 92),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(closed ? bi('દિવસ બંધ છે', 'Day is closed') : (badN == 0 ? bi('બધું તૈયાર છે', 'Everything is ready') : bi('$badN બાબત બાકી', '$badN items open')), style: ts(17, w: FontWeight.w800)),
                      const SizedBox(height: 4),
                      Text(closed ? _who(live.closedInfo(d)) : bi('નીચેની યાદી જોઈને દિવસ બંધ કરો', 'Go through the list, then close the day'), style: ts(12.5, c: Pal.muted)),
                      const SizedBox(height: 12),
                      closed
                          ? Btn(bi('ફરી ખોલો', 'Re-open'), icon: 'lockopen', dense: true, kind: BtnKind.outline, onTap: () => live.closeDay(d, false))
                          : Btn(bi('દિવસ બંધ કરો', 'Close the day'), icon: 'lock', dense: true, onTap: () => _close(d, badN)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          for (final _Check c in cs) row(c),
          const SizedBox(height: 10),
          Btn(bi('આ દિવસનો રિપોર્ટ', 'Report of this day'), icon: 'doc', kind: BtnKind.tonal, expand: true, onTap: () => app.go('today')),
          const SizedBox(height: 16),
          Panel(title: bi('છેલ્લા 14 દિવસ', 'Last 14 days'), child: Column(children: history)),
        ];
      },
    );
  }
}

// ================================================================== reviewed
/// Alerts the owner has already looked at. They stop counting as "needs
/// checking", but can be brought back.
class ReviewedScreen extends StatelessWidget {
  const ReviewedScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 900,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final List<Finding> l = live.findings.where((Finding f) => live.isReviewed(f)).toList();
        l.sort((Finding a, Finding b) {
          final DateTime x = DateTime.tryParse(live.reviewed[findingKey(a)] ?? '') ?? a.at;
          final DateTime y = DateTime.tryParse(live.reviewed[findingKey(b)] ?? '') ?? b.at;
          return y.compareTo(x);
        });
        return <Widget>[
          ScreenHeader(bi('જોઈ લીધેલા', 'Checked alerts'), sub: '${l.length}', actions: <Widget>[refreshBtn()]),
          statusBanner(),
          Text(bi('જે બાબત તમે "જોઈ લીધી" કરી હોય તે અહીં આવે છે. તે "તપાસ માંગે છે" માં ગણાતી નથી. બધા ફોનમાં આ સરખું દેખાય છે.', 'Alerts you marked as checked are listed here. They no longer count under "needs checking" - on every phone.'),
              style: ts(12.5, c: Pal.muted, h: 1.4)),
          const SizedBox(height: 12),
          if (l.isEmpty)
            EmptyBox(icon: 'check', title: bi('હજી કશું જોઈ લીધેલું નથી', 'Nothing checked yet'))
          else ...<Widget>[
            Btn(bi('બધા પાછા લાવો (${l.length})', 'Bring all back (${l.length})'), icon: 'undo', kind: BtnKind.tonal, expand: true, onTap: () {
              live.setReviewed(l, false);
              app.toast(bi('પાછા લાવ્યા', 'Restored'));
            }),
            const SizedBox(height: 12),
            for (final Finding f in l.take(100))
              rowShell(
                onTap: () => openFinding(ctx, f),
                bar: Pal.faint,
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(f.title(), maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(13.5, w: FontWeight.w800, h: 1.25)),
                          const SizedBox(height: 3),
                          Text(f.detail(), maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(12, c: Pal.muted, h: 1.3)),
                          const SizedBox(height: 3),
                          Text('${bi('જોયું', 'Checked')}: ${_when(live.reviewed[findingKey(f)])}', style: ts(11.5, c: Pal.faint)),
                        ],
                      ),
                    ),
                    IconBtn('undo', tip: bi('પાછું લાવો', 'Bring back'), onTap: () => live.setReviewed(<Finding>[f], false)),
                  ],
                ),
              ),
          ],
        ];
      },
    );
  }

  static String _when(String? iso) {
    final DateTime? t = DateTime.tryParse(iso ?? '');
    return t == null ? '—' : whenTxt(t);
  }
}

// ===================================================================== feed
/// Every entry of every person, newest first, with "new" marks.
class FeedScreen extends StatefulWidget {
  const FeedScreen({super.key});

  @override
  State<FeedScreen> createState() => _FeedState();
}

class _FeedState extends State<FeedScreen> {
  int _kind = 0;
  String _who = '';
  int _n = 40;
  late final Set<String> _new = Set<String>.from(live.fresh);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((Duration _) => live.markSeen());
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 900,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final List<_Ev> ev = <_Ev>[];
        final Map<String, int> by = <String, int>{};
        if (_kind == 0 || _kind == 1) {
          for (final Chit x in live.chits) {
            by[x.by] = (by[x.by] ?? 0) + 1;
            if (_who.isEmpty || x.by == _who) ev.add(_Ev(x.at, 'c${x.id}', chitTile(ctx, x)));
          }
        }
        if (_kind == 0 || _kind == 2) {
          for (final Kanta x in live.kantas) {
            by[x.by] = (by[x.by] ?? 0) + 1;
            if (_who.isEmpty || x.by == _who) ev.add(_Ev(x.at, 'k${x.id}', kantaTile(ctx, x)));
          }
        }
        if (_kind == 0 || _kind == 3) {
          for (final MaalRow x in live.maals) {
            by[x.by] = (by[x.by] ?? 0) + 1;
            if (_who.isEmpty || x.by == _who) ev.add(_Ev(x.at, 'm${x.id}', maalTile(ctx, x)));
          }
        }
        ev.sort((_Ev a, _Ev b) => b.at.compareTo(a.at));
        final List<MapEntry<String, int>> people = by.entries.where((MapEntry<String, int> e) => e.key.isNotEmpty).toList()
          ..sort((MapEntry<String, int> a, MapEntry<String, int> b) => b.value.compareTo(a.value));
        final List<String> pl = <String>[bi('બધા', 'Everyone'), for (final MapEntry<String, int> e in people.take(8)) majurName(live.names, e.key)];
        final int pi = _who.isEmpty ? 0 : 1 + people.take(8).toList().indexWhere((MapEntry<String, int> e) => e.key == _who);

        final List<Widget> out = <Widget>[];
        DateTime? last;
        for (final _Ev e in ev.take(_n)) {
          final DateTime dd = dayOf(e.at);
          if (last == null || last != dd) {
            out.add(Padding(padding: const EdgeInsets.only(top: 6, bottom: 8), child: SectionTitle(dayLabel(e.at), sub: dayName(e.at))));
            last = dd;
          }
          if (_new.contains(e.id)) {
            out.add(Stack(children: <Widget>[e.w, Positioned(right: 10, top: 8, child: Pill(bi('નવું', 'New'), tone: 'green', small: true, icon: 'bolt'))]));
          } else {
            out.add(e.w);
          }
        }
        return <Widget>[
          ScreenHeader(bi('ફીડ · બધી એન્ટ્રી', 'Feed · all entries'), sub: '${ev.length}', actions: <Widget>[refreshBtn()]),
          statusBanner(),
          if (_new.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Pill('${_new.length} ${bi('નવી એન્ટ્રી આવી', 'new entries arrived')}', tone: 'green', icon: 'bolt'),
            ),
          ChipRow(
            labels: <String>[bi('બધું', 'All'), bi('ચિઠ્ઠી', 'Chits'), bi('કાંટો', 'Kanta'), bi('માલ', 'Maal')],
            index: _kind,
            onChanged: (int i) => setState(() {
              _kind = i;
              _n = 40;
            }),
          ),
          const SizedBox(height: 8),
          ChipRow(
            labels: pl,
            index: pi < 0 ? 0 : pi,
            onChanged: (int i) => setState(() {
              _who = i == 0 ? '' : people[i - 1].key;
              _n = 40;
            }),
          ),
          const SizedBox(height: 12),
          if (ev.isEmpty) EmptyBox(icon: 'list', title: bi('કોઈ એન્ટ્રી નથી', 'No entries')) else ...out,
          if (_n < ev.length) Btn(bi('વધુ બતાવો (${ev.length - _n})', 'Show more (${ev.length - _n})'), kind: BtnKind.tonal, expand: true, onTap: () => setState(() => _n += 40)),
        ];
      },
    );
  }
}

class _Ev {
  final DateTime at;
  final String id;
  final Widget w;
  const _Ev(this.at, this.id, this.w);
}

// ==================================================================== staff
class _Person {
  final String id;
  String name;
  String role = '';
  int chits = 0;
  int kantas = 0;
  int maals = 0;
  int noPhoto = 0;
  int round = 0;
  int diffTrips = 0;
  double kg = 0;
  DateTime? last;
  _Person(this.id, this.name);

  int get total => chits + kantas + maals;
  double get photoPct => total == 0 ? 100 : (total - noPhoto) / total * 100;
}

String _roleName(String r) {
  switch (r) {
    case 'admin':
      return bi('માલિક', 'Owner');
    case 'worker':
      return bi('મજૂર', 'Labour');
    case 'waybridge':
      return bi('કાંટો', 'Weighbridge');
    case 'maal_entry':
      return bi('માલ એન્ટ્રી', 'Maal entry');
  }
  return r;
}

/// Who entered how much, and how clean their entries are.
class StaffScreen extends StatefulWidget {
  const StaffScreen({super.key});

  @override
  State<StaffScreen> createState() => _StaffState();
}

class _StaffState extends State<StaffScreen> {
  RangeSel _sel = RangeSel(2);
  int _sort = 0;

  List<_Person> _people(Period p) {
    final Map<String, _Person> m = <String, _Person>{};
    _Person of(String id) {
      return m.putIfAbsent(id, () => _Person(id, majurName(live.names, id)));
    }

    void seen(_Person x, DateTime at) {
      if (x.last == null || at.isAfter(x.last!)) x.last = at;
    }

    for (final Chit c in live.chits) {
      if (!p.has(c.at) || c.by.isEmpty) continue;
      final _Person x = of(c.by);
      x.chits++;
      x.kg += c.cmpKg;
      if (c.photo.isEmpty) x.noPhoto++;
      if (c.gross > 0 && c.gross % 50 == 0) x.round++;
      final Trip? t = live.chitTrip[c];
      if (t != null && t.state == TripState.diff) x.diffTrips++;
      seen(x, c.at);
    }
    for (final Kanta k in live.kantas) {
      if (!p.has(k.at) || k.by.isEmpty) continue;
      final _Person x = of(k.by);
      x.kantas++;
      if (k.slip.isEmpty) x.noPhoto++;
      seen(x, k.at);
    }
    for (final MaalRow k in live.maals) {
      if (!p.has(k.date) || k.by.isEmpty) continue;
      final _Person x = of(k.by);
      x.maals++;
      if (k.slip.isEmpty) x.noPhoto++;
      seen(x, k.at);
    }
    for (final Profile pr in live.profiles) {
      final _Person? x = m[pr.id];
      if (x != null) x.role = pr.role;
    }
    final List<_Person> l = m.values.toList();
    l.sort((_Person a, _Person b) {
      if (_sort == 1) return a.photoPct.compareTo(b.photoPct);
      if (_sort == 2) return b.diffTrips.compareTo(a.diffTrips);
      return b.total.compareTo(a.total);
    });
    return l;
  }

  void _open(BuildContext ctx, _Person x) {
    openPanel(
      ctx,
      title: x.name,
      sub: _roleName(x.role),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          InfoRow(bi('ચિઠ્ઠી', 'Chits'), '${x.chits}'),
          InfoRow(bi('કાંટો', 'Kanta'), '${x.kantas}'),
          InfoRow(bi('માલ', 'Maal'), '${x.maals}'),
          InfoRow(bi('કુલ', 'Total'), '${x.total}', bold: true),
          divider(),
          InfoRow(bi('ચિઠ્ઠીનું વજન', 'Chit weight'), kgShort(x.kg)),
          InfoRow(bi('ફોટા સાથે', 'With photo'), '${x.photoPct.round()}%', color: x.photoPct >= 90 ? Pal.ok : Pal.warn),
          InfoRow(bi('ફરક વાળી ગાડીની ચિઠ્ઠી', 'Chits in differing trips'), '${x.diffTrips}', color: x.diffTrips == 0 ? Pal.ok : Pal.bad),
          InfoRow(bi('ગોળ વજન (50 ના ગુણાંક)', 'Round weights'), x.chits == 0 ? '—' : '${x.round} (${(x.round / x.chits * 100).round()}%)'),
          InfoRow(bi('છેલ્લી એન્ટ્રી', 'Last entry'), x.last == null ? '—' : whenTxt(x.last!)),
          const SizedBox(height: 14),
          if (x.chits > 0)
            Btn(bi('આખી પ્રોફાઇલ જુઓ', 'Open full profile'), icon: 'user', kind: BtnKind.tonal, expand: true, onTap: () {
              Navigator.of(ctx).pop();
              openParty(PartyRef(Dim.majur, x.id, x.name));
            }),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 1000,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = _sel.period;
        final List<_Person> l = _people(p);
        int tot = 0;
        for (final _Person x in l) {
          tot += x.total;
        }
        return <Widget>[
          ScreenHeader(bi('સ્ટાફ પરફોર્મન્સ', 'Staff performance'), sub: '${p.label} · $tot ${bi('એન્ટ્રી', 'entries')}', actions: <Widget>[refreshBtn()]),
          statusBanner(),
          RangeBar(sel: _sel, onChanged: (RangeSel r) => setState(() => _sel = r)),
          const SizedBox(height: 10),
          Seg(
            dense: true,
            labels: <String>[bi('વધુ એન્ટ્રી', 'Most entries'), bi('ફોટો ઓછા', 'Fewest photos'), bi('વધુ ફરક', 'Most differences')],
            index: _sort,
            onChanged: (int i) => setState(() => _sort = i),
          ),
          const SizedBox(height: 14),
          if (l.isEmpty)
            EmptyBox(icon: 'users', title: bi('આ સમયમાં કોઈ એન્ટ્રી નથી', 'No entries in this period'))
          else
            for (final _Person x in l)
              rowShell(
                onTap: () => _open(ctx, x),
                bar: x.photoPct >= 90 && x.diffTrips == 0 ? Pal.ok : (x.diffTrips > 0 ? Pal.bad : Pal.warn),
                child: Row(
                  children: <Widget>[
                    Avatar(x.name, size: 42),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(x.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14.5, w: FontWeight.w800)),
                          const SizedBox(height: 2),
                          Text('${_roleName(x.role)} · ${x.last == null ? '' : ago(x.last!)}', style: ts(12, c: Pal.muted)),
                          const SizedBox(height: 6),
                          Wrap(spacing: 6, runSpacing: 4, children: <Widget>[
                            if (x.chits > 0) Pill('${x.chits} ${bi('ચિઠ્ઠી', 'chits')}', tone: 'teal', small: true),
                            if (x.kantas > 0) Pill('${x.kantas} ${bi('કાંટો', 'kanta')}', tone: 'blue', small: true),
                            if (x.maals > 0) Pill('${x.maals} ${bi('માલ', 'maal')}', tone: 'amber', small: true),
                            Pill('${bi('ફોટો', 'Photo')} ${x.photoPct.round()}%', tone: x.photoPct >= 90 ? 'green' : 'amber', small: true),
                            if (x.diffTrips > 0) Pill('${x.diffTrips} ${bi('ફરક', 'diff')}', tone: 'rose', small: true),
                          ]),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: <Widget>[
                        Text('${x.total}', style: ts(20, w: FontWeight.w800, tab: true)),
                        Text(bi('એન્ટ્રી', 'entries'), style: ts(11, c: Pal.muted)),
                      ],
                    ),
                  ],
                ),
              ),
          if (l.isNotEmpty && l.length > 1) ...<Widget>[
            const SizedBox(height: 10),
            Panel(
              title: bi('એન્ટ્રીનો હિસ્સો', 'Share of entries'),
              child: RankList(<RankItem>[
                for (final _Person x in l.take(8)) RankItem(x.name, x.total.toDouble(), '${x.total}', Pal.brand, sub: tot == 0 ? null : '${(x.total / math.max(1, tot) * 100).round()}%'),
              ]),
            ),
          ],
        ];
      },
    );
  }
}
