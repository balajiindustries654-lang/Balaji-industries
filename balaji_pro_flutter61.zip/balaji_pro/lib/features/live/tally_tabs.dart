part of 'tally_data.dart';

// ======================================================================
// New Tally tabs (part 1): common bits, farmer picker, payments -> khata,
// purchase check (mel).  Logic is in tally_logic.dart
// ======================================================================

Widget _emptyNote(String t) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 24),
    child: Text(t, textAlign: TextAlign.center, style: ts(14, c: Pal.muted)),
  );
}

Widget _moreBtn(int left, VoidCallback onTap) {
  return Padding(
    padding: const EdgeInsets.only(top: 6),
    child: Btn(bi('વધુ બતાવો ($left)', 'Show more ($left)'), icon: 'plus', kind: BtnKind.outline, dense: true, onTap: onTap),
  );
}

String _sgn(double d) => '${d < 0 ? '−' : '+'}${_rs(d.abs())}';

Widget _darkHead(String label, String value, String sub) {
  return Surface(
    color: Pal.side,
    border: false,
    padding: const EdgeInsets.all(18),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(label, style: ts(13, c: Pal.sideText, w: FontWeight.w600)),
        FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(value, style: ts(34, w: FontWeight.w800, c: Colors.white, tab: true, ls: -1))),
        if (sub.isNotEmpty) Text(sub, maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(13, c: Pal.sideText, w: FontWeight.w600)),
      ],
    ),
  );
}

// ------------------------------------------------- Tally-style table (PC)
// Slim table rows like the Tally lists: head, rows (tap = open), day rows and a total row at the end.
class _Col {
  final String label;
  final double w; // 0 = takes the rest of the width
  final bool right;
  const _Col(this.label, this.w, {this.right = false});
}

Widget _th(String t) => Text(t, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(11.5, w: FontWeight.w800, c: Pal.muted));

Text _td(String t, {bool bold = false, Color? c, bool num = false, TextDecoration? deco}) {
  return Text(t, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(num ? 13 : 12.5, w: bold ? FontWeight.w800 : FontWeight.w600, c: c, tab: num, deco: deco));
}

Widget _tcell(_Col c, Widget child) {
  final Widget a = Align(alignment: c.right ? Alignment.centerRight : Alignment.centerLeft, child: child);
  return c.w <= 0 ? Expanded(child: a) : SizedBox(width: c.w, child: a);
}

Widget _tblHead(List<_Col> cols) {
  return Container(
    height: 28,
    padding: const EdgeInsets.symmetric(horizontal: 10),
    decoration: BoxDecoration(color: Pal.soft, border: Border.all(color: Pal.line)),
    child: Row(children: <Widget>[for (final _Col c in cols) _tcell(c, _th(c.label))]),
  );
}

Widget _tblRow(List<_Col> cols, List<Widget> cells, {VoidCallback? onTap, Color? bg, double h = 30}) {
  return Material(
    color: bg ?? Pal.surface,
    child: InkWell(
      onTap: onTap,
      hoverColor: Pal.soft,
      child: Container(
        height: h,
        padding: const EdgeInsets.symmetric(horizontal: 10),
        decoration: BoxDecoration(border: Border(left: BorderSide(color: Pal.line), right: BorderSide(color: Pal.line), bottom: BorderSide(color: Pal.line))),
        child: Row(children: <Widget>[for (int i = 0; i < cols.length && i < cells.length; i++) _tcell(cols[i], cells[i])]),
      ),
    ),
  );
}

/// Day heading row; [a] and [b] (when given) sit over the last two columns (width [w] each).
Widget _tDay(String text, {String? a, String? b, double w = 110}) {
  return Material(
    color: Pal.soft,
    child: Container(
      height: 26,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(border: Border(left: BorderSide(color: Pal.line), right: BorderSide(color: Pal.line), bottom: BorderSide(color: Pal.line))),
      child: Row(
        children: <Widget>[
          Expanded(child: Text(text, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12, w: FontWeight.w800, c: Pal.brand))),
          if (a != null) SizedBox(width: w, child: Text(a, textAlign: TextAlign.right, style: ts(12, w: FontWeight.w800, c: Pal.ok, tab: true))),
          if (b != null) SizedBox(width: w, child: Text(b, textAlign: TextAlign.right, style: ts(12, w: FontWeight.w800, c: Pal.bad, tab: true))),
        ],
      ),
    ),
  );
}

List<_Col> _dayCols(bool showFirm) => <_Col>[
      _Col(bi('તારીખ', 'Date'), 56),
      _Col(bi('વિગત (પાર્ટી)', 'Particulars'), 0),
      _Col(bi('વાઉચર પ્રકાર', 'Voucher type'), 130),
      _Col(bi('નંબર', 'No'), 70),
      if (showFirm) _Col(bi('ફર્મ', 'Firm'), 80),
      _Col(bi('રકમ', 'Amount'), 120, right: true),
    ];

Widget _tHead(bool showFirm) => _tblHead(_dayCols(showFirm));

/// One voucher as a slim table row (many fit on the screen, like the Tally Day Book).
Widget _tRow(BuildContext context, TVoucher v, bool showFirm) {
  final _BT t = _bt(v.base);
  final Color tc = v.cancelled ? Pal.faint : Pal.tone(t.tone).fg;
  final TextDecoration? deco = v.cancelled ? TextDecoration.lineThrough : null;
  final Color? dim = v.cancelled ? Pal.faint : null;
  return _tblRow(
    _dayCols(showFirm),
    <Widget>[
      _td('${pad2(v.dt.day)}-${pad2(v.dt.month)}', c: Pal.muted, num: true),
      _td(v.title, bold: true, deco: deco, c: dim),
      _td(v.type, c: tc),
      _td(v.no.isEmpty ? '' : '#${v.no}', c: Pal.muted),
      if (showFirm) _td(_firmShort(v.firm), c: Pal.muted),
      _td(_rs(v.amount), bold: true, num: true, deco: deco, c: dim),
    ],
    onTap: () => openTallyVoucher(context, v),
  );
}

// ------------------------------------------------------------ farmer picker
Future<void> _pickFarmer(BuildContext context, String title, void Function(_Fm) onPick) {
  return openPanel(
    context,
    title: title,
    sub: bi('Pro ના ખેડૂતમાંથી પસંદ કરો', 'Pick from the Pro farmers'),
    width: 460,
    child: _FarmerPick(_farmerIndex(), onPick),
  );
}

class _FarmerPick extends StatefulWidget {
  final List<_Fm> list;
  final void Function(_Fm) onPick;
  const _FarmerPick(this.list, this.onPick);

  @override
  State<_FarmerPick> createState() => _FarmerPickState();
}

class _FarmerPickState extends State<_FarmerPick> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final String q = _q.trim().toLowerCase();
    final String qk = _nk(_q);
    final List<_Fm> hits = <_Fm>[];
    for (final _Fm f in widget.list) {
      if (q.isEmpty || f.label.toLowerCase().contains(q) || (qk.isNotEmpty && f.uk.contains(qk))) hits.add(f);
      if (hits.length >= 40) break;
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        FieldX(
          label: bi('નામ શોધો', 'Search name'),
          hint: bi('ખેડૂતનું નામ', 'Farmer name'),
          onChanged: (String s) => setState(() => _q = s),
        ),
        const SizedBox(height: 10),
        if (hits.isEmpty) _emptyNote(bi('આ નામનો ખેડૂત Pro માં નથી', 'No farmer with this name in Pro')),
        for (final _Fm f in hits)
          lineItem(
            icon: 'user',
            tone: 'teal',
            title: f.label,
            onTap: () {
              Navigator.of(context).pop();
              widget.onPick(f);
            },
          ),
      ],
    );
  }
}

// ======================================================= payments -> khata
String _planStateLabel(String s) {
  switch (s) {
    case 'ready':
      return bi('તૈયાર', 'Ready');
    case 'review':
      return bi('ચકાસો', 'Check');
    case 'unknown':
      return bi('ખેડૂત ઓળખાયો નથી', 'Farmer not recognised');
    case 'dup':
      return bi('Pro માં પહેલેથી છે', 'Already in Pro');
    case 'done':
      return bi('ઉમેરાઈ ગયું', 'Added');
    default:
      return bi('છોડેલી', 'Skipped');
  }
}

String _planTone(String s) {
  switch (s) {
    case 'ready':
      return 'green';
    case 'review':
      return 'amber';
    case 'unknown':
      return 'rose';
    case 'done':
      return 'blue';
    default:
      return 'slate';
  }
}

Future<void> _openPlan(BuildContext context, _Plan p) {
  return openPanel(
    context,
    title: p.ledger,
    sub: '${dmy(p.v.dt)} · ${firmName(p.v.firm)}',
    width: 480,
    child: _PlanPanel(p),
  );
}

class _PlanPanel extends StatelessWidget {
  final _Plan p;
  const _PlanPanel(this.p);

  Future<void> _add(BuildContext context) async {
    final NavigatorState nav = Navigator.of(context);
    final int n = await _importPlans(<_Plan>[p]);
    app.toast(n > 0 ? bi('ખેડૂત ખાતામાં ઉમેર્યું', 'Added to the farmer khata') : bi('આ પહેલેથી ઉમેરેલું છે', 'Already added'));
    nav.pop();
  }

  void _choose(BuildContext context) {
    _pickFarmer(context, bi('ખેડૂત પસંદ કરો', 'Pick the farmer'), (_Fm f) async {
      final NavigatorState nav = Navigator.of(context);
      p.key = f.key;
      p.name = f.label;
      await _setAlias(p.ledger, f.key);
      final int n = await _importPlans(<_Plan>[p]);
      app.toast(n > 0 ? bi('${f.label} ના ખાતામાં ઉમેર્યું', 'Added to ${f.label}') : bi('આ પહેલેથી ઉમેરેલું છે', 'Already added'));
      nav.pop();
    });
  }

  Future<void> _ignore(BuildContext context, bool on) async {
    final NavigatorState nav = Navigator.of(context);
    await _setIgnore(p.ledger, on);
    app.toast(on ? bi('આ પાર્ટી છોડી દીધી', 'Party skipped') : bi('ફરી ગણતરીમાં લીધી', 'Counted again'));
    nav.pop();
  }

  Future<void> _remove(BuildContext context) async {
    final NavigatorState nav = Navigator.of(context);
    String id = '';
    for (final Map<String, dynamic> m in payDoc.list('items')) {
      if ('${m['tref'] ?? ''}' == p.ref) id = '${m['id'] ?? ''}';
    }
    if (id.isNotEmpty) await removePayItem(id);
    app.toast(bi('ખેડૂત ખાતામાંથી કાઢ્યું', 'Removed from the farmer khata'));
    nav.pop();
  }

  @override
  Widget build(BuildContext context) {
    final TVoucher v = p.v;
    final bool canAdd = p.key.isNotEmpty && (p.state == 'ready' || p.state == 'review' || p.state == 'dup');
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        _darkHead(bi('Tally ચૂકવણી', 'Tally payment'), _rs(p.amount), p.ledger),
        const SizedBox(height: 10),
        Wrap(
          spacing: 6,
          runSpacing: 6,
          children: <Widget>[
            Pill(_planStateLabel(p.state), tone: _planTone(p.state), small: true),
            if (_modeLabel(v.mode).isNotEmpty) Pill(_modeLabel(v.mode), tone: 'blue', small: true),
          ],
        ),
        const SizedBox(height: 12),
        Panel(
          child: Column(
            children: <Widget>[
              InfoRow(bi('તારીખ', 'Date'), dmy(v.dt)),
              InfoRow(bi('ફર્મ', 'Firm'), firmName(v.firm)),
              InfoRow(bi('વાઉચર', 'Voucher'), '${v.type}${v.no.isEmpty ? '' : ' · ${v.no}'}'),
              if (v.bank.isNotEmpty) InfoRow(bi('બેંક / રોકડ', 'Bank / cash'), v.bank),
              if (v.utr.isNotEmpty) InfoRow('UTR', v.utr),
              if (p.key.isNotEmpty) InfoRow(bi('ખેડૂત (Pro)', 'Farmer (Pro)'), '${p.name} · ${(p.score * 100).round()}%'),
            ],
          ),
        ),
        if (v.narr.isNotEmpty) ...<Widget>[
          const SizedBox(height: 10),
          noteBox('note', 'slate', v.narr),
        ],
        if (p.why == 'twice') ...<Widget>[
          const SizedBox(height: 10),
          noteBox('warn', 'amber', bi('આ જ ખેડૂત, તારીખ અને રકમની બીજી ચૂકવણી પહેલેથી છે - બે વાર તો નથી ને?', 'Another payment with the same farmer, day and amount exists - is it twice?')),
        ],
        if (p.state == 'dup') ...<Widget>[
          const SizedBox(height: 10),
          noteBox('check', 'green', bi('Pro માં આ જ ખેડૂત, તારીખ અને રકમ હાથે લખેલી છે. ફરી ઉમેરશો નહીં.', 'Pro already has this farmer, day and amount entered by hand. Do not add it again.')),
        ],
        if (p.state == 'unknown') ...<Widget>[
          const SizedBox(height: 10),
          noteBox('warn', 'rose', bi('આ નામનો ખેડૂત Pro માં મળ્યો નથી. નીચેથી ખેડૂત પસંદ કરો - આગળ થી આપોઆપ ઓળખાશે.', 'No farmer with this name in Pro. Pick the farmer below - next time it is recognised by itself.')),
        ],
        const SizedBox(height: 14),
        if (canAdd && p.state != 'dup') Btn(bi('ખેડૂત ખાતામાં ઉમેરો', 'Add to farmer khata'), icon: 'plus', onTap: () => _add(context)),
        if (canAdd && p.state == 'dup') Btn(bi('છતાં ઉમેરો', 'Add anyway'), icon: 'plus', kind: BtnKind.outline, dense: true, onTap: () => _add(context)),
        if (p.state != 'done' && p.state != 'ignored') ...<Widget>[
          const SizedBox(height: 8),
          Btn(bi('બીજો ખેડૂત પસંદ કરો', 'Pick another farmer'), icon: 'users', kind: BtnKind.tonal, dense: true, onTap: () => _choose(context)),
          const SizedBox(height: 8),
          Btn(bi('આ ખેડૂત નથી - છોડી દો', 'Not a farmer - skip'), icon: 'trash', kind: BtnKind.outline, dense: true, onTap: () => _ignore(context, true)),
        ],
        if (p.state == 'ignored') Btn(bi('ફરી ગણતરીમાં લો', 'Count again'), icon: 'refresh', kind: BtnKind.tonal, dense: true, onTap: () => _ignore(context, false)),
        if (p.state == 'done') Btn(bi('ખેડૂત ખાતામાંથી કાઢો', 'Remove from farmer khata'), icon: 'trash', kind: BtnKind.outline, dense: true, onTap: () => _remove(context)),
      ],
    );
  }
}

Future<void> _openOrphan(BuildContext context, _Orphan o) {
  return openPanel(
    context,
    title: o.label,
    sub: bi('Tally માં બદલાયેલી ચૂકવણી', 'Payment changed in Tally'),
    width: 460,
    child: _OrphanPanel(o),
  );
}

class _OrphanPanel extends StatelessWidget {
  final _Orphan o;
  const _OrphanPanel(this.o);

  String get _why {
    if (o.why == 'cancelled') return bi('Tally માં આ વાઉચર રદ થયું છે.', 'This voucher is cancelled in Tally.');
    if (o.why == 'missing') return bi('Tally માં આ વાઉચર હવે મળતું નથી (કાઢી નાખ્યું હશે).', 'This voucher is not in Tally any more (probably deleted).');
    return bi('Tally માં રકમ કે તારીખ બદલાઈ છે.', 'The amount or the date was changed in Tally.');
  }

  Future<void> _remove(BuildContext context) async {
    final NavigatorState nav = Navigator.of(context);
    await removePayItem(o.id);
    app.toast(bi('ખેડૂત ખાતામાંથી કાઢ્યું', 'Removed from the farmer khata'));
    nav.pop();
  }

  Future<void> _sync(BuildContext context) async {
    final NavigatorState nav = Navigator.of(context);
    await _syncOrphan(o);
    app.toast(bi('Tally મુજબ સુધાર્યું', 'Updated as in Tally'));
    nav.pop();
  }

  Future<void> _keep(BuildContext context) async {
    final NavigatorState nav = Navigator.of(context);
    await _unlinkOrphan(o.id);
    app.toast(bi('હવે Tally સાથે જોડાણ નથી', 'No longer linked to Tally'));
    nav.pop();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        _darkHead(bi('Pro માં છે', 'In Pro'), _rs(o.amt), dmy(DateTime.tryParse(o.date) ?? DateTime.now())),
        const SizedBox(height: 10),
        noteBox('warn', 'amber', _why),
        if (o.why == 'changed')
          Panel(
            child: Column(
              children: <Widget>[
                InfoRow(bi('Pro માં', 'In Pro'), '${_rs(o.amt)} · ${o.date}'),
                InfoRow(bi('Tally માં', 'In Tally'), '${_rs(o.tallyAmt)} · ${o.tallyDate}'),
              ],
            ),
          ),
        const SizedBox(height: 12),
        if (o.why == 'changed') Btn(bi('Tally મુજબ સુધારો', 'Update as in Tally'), icon: 'refresh', onTap: () => _sync(context)),
        if (o.why != 'changed') Btn(bi('ખેડૂત ખાતામાંથી કાઢો', 'Remove from farmer khata'), icon: 'trash', onTap: () => _remove(context)),
        const SizedBox(height: 8),
        Btn(bi('આમ જ રહેવા દો', 'Keep it as it is'), icon: 'check', kind: BtnKind.outline, dense: true, onTap: () => _keep(context)),
      ],
    );
  }
}

class _PayTab extends StatefulWidget {
  final String firm;
  const _PayTab({required this.firm});

  @override
  State<_PayTab> createState() => _PayTabState();
}

class _PayTabState extends State<_PayTab> {
  int _f = 0;
  int _limit = 60;

  Future<void> _addAll(BuildContext context, List<_Plan> ready) async {
    final bool go = await confirmBox(
      context,
      title: bi('બધી ચૂકવણી ઉમેરવી?', 'Add all payments?'),
      text: bi('${ready.length} Tally ચૂકવણી ખેડૂતના ખાતામાં "ચૂકવ્યા" તરીકે ઉમેરાશે. ખોટું લાગે તો દરેકને પછી કાઢી શકાશે.', '${ready.length} Tally payments will be added to the farmer khata as "Paid". Each can be removed later.'),
      yes: bi('હા, ઉમેરો', 'Yes, add'),
      no: bi('ના', 'No'),
    );
    if (!go) return;
    final int n = await _importPlans(ready);
    app.toast(bi('$n ચૂકવણી ખેડૂત ખાતામાં ઉમેરી', '$n payments added to the farmer khata'));
  }

  @override
  Widget build(BuildContext context) {
    final _Matcher mt = _matcher();
    final List<_Plan> all = <_Plan>[
      for (final _Plan p in _buildPlan(mt))
        if (widget.firm.isEmpty || p.v.firm == widget.firm) p,
    ];
    final List<_Plan> ready = <_Plan>[];
    final List<_Plan> toAdd = <_Plan>[];
    final List<_Plan> unk = <_Plan>[];
    final List<_Plan> have = <_Plan>[];
    final List<_Plan> ign = <_Plan>[];
    for (final _Plan p in all) {
      if (p.state == 'ready') {
        ready.add(p);
        toAdd.add(p);
      } else if (p.state == 'review') {
        toAdd.add(p);
      } else if (p.state == 'unknown') {
        unk.add(p);
      } else if (p.state == 'dup' || p.state == 'done') {
        have.add(p);
      } else {
        ign.add(p);
      }
    }
    final List<_Plan> shown = _f == 0 ? toAdd : (_f == 1 ? unk : (_f == 2 ? have : ign));
    final List<_Orphan> orph = _orphans();
    final List<Widget> out = <Widget>[
      metricGrid(context, <Widget>[
        MetricTile(label: bi('ઉમેરવા તૈયાર', 'Ready to add'), value: '${ready.length}', icon: 'check', tone: 'green'),
        MetricTile(label: bi('ચકાસો', 'To check'), value: '${toAdd.length - ready.length}', icon: 'warn', tone: 'amber'),
        MetricTile(label: bi('ખેડૂત ઓળખાયો નથી', 'Not recognised'), value: '${unk.length}', icon: 'users', tone: 'rose'),
        MetricTile(label: bi('Pro માં છે', 'Already in Pro'), value: '${have.length}', icon: 'pay', tone: 'blue'),
      ], pcCols: 4),
      const SizedBox(height: 10),
      noteBox('info', 'blue', bi('Tally માં ખેડૂતને આપેલી ચૂકવણી (Payment વાઉચર) અહીં દેખાય છે. એક ટેપથી તે Pro ના ખેડૂત ખાતામાં "ચૂકવ્યા" તરીકે જાય છે - બે વાર લખવાની જરૂર નથી. Tally માં કંઈ બદલાતું નથી.', 'Farmer payments made in Tally (Payment vouchers) show here. One tap puts them in the Pro farmer khata as "Paid" - no need to write twice. Nothing changes in Tally.')),
      ChipRow(
        labels: <String>[
          '${bi('ઉમેરવાના', 'To add')} ${toAdd.length}',
          '${bi('ઓળખાયા નથી', 'Unknown')} ${unk.length}',
          '${bi('Pro માં છે', 'In Pro')} ${have.length}',
          '${bi('છોડેલી', 'Skipped')} ${ign.length}',
        ],
        index: _f,
        onChanged: (int i) => setState(() {
          _f = i;
          _limit = 60;
        }),
      ),
      const SizedBox(height: 10),
    ];
    if (_f == 0 && ready.isNotEmpty) {
      out.add(Btn(bi('બધા તૈયાર ઉમેરો (${ready.length})', 'Add all ready (${ready.length})'), icon: 'plus', onTap: () => _addAll(context, ready)));
      out.add(const SizedBox(height: 10));
    }
    if (shown.isEmpty) {
      out.add(_emptyNote(_f == 0
          ? (all.isEmpty ? bi('Tally માં ખેડૂતને ચૂકવણીનું કોઈ વાઉચર નથી', 'No farmer payment vouchers in Tally') : bi('ઉમેરવા જેવી કોઈ ચૂકવણી નથી - બધું બરાબર છે 🎉', 'Nothing left to add - all in order 🎉'))
          : bi('અહીં કંઈ નથી', 'Nothing here')));
    }
    for (final _Plan p in shown.take(_limit)) {
      final String sub = '${dmy(p.v.dt)} · ${_firmShort(p.v.firm)}${p.key.isNotEmpty ? '\n→ ${p.name} (${(p.score * 100).round()}%)' : ''}${p.why == 'twice' ? '\n${bi('આ જ રકમ બે વાર?', 'Same amount twice?')}' : ''}';
      out.add(lineItem(
        icon: p.state == 'done' ? 'check' : 'pay',
        tone: _planTone(p.state),
        title: p.ledger,
        sub: sub,
        trailing: _rs(p.amount),
        trailingSub: _modeLabel(p.v.mode).isEmpty ? _planStateLabel(p.state) : '${_modeLabel(p.v.mode)} · ${_planStateLabel(p.state)}',
        onTap: () => _openPlan(context, p),
      ));
    }
    if (shown.length > _limit) out.add(_moreBtn(shown.length - _limit, () => setState(() => _limit += 100)));
    if (orph.isNotEmpty) {
      out.add(const SizedBox(height: 12));
      out.add(caption('${bi('Tally માં બદલાયેલી (Pro માં બાકી)', 'Changed in Tally (still in Pro)')} · ${orph.length}'));
      for (final _Orphan o in orph.take(30)) {
        out.add(lineItem(
          icon: 'warn',
          tone: 'amber',
          title: o.label,
          sub: '${o.date} · ${o.why == 'cancelled' ? bi('Tally માં રદ', 'Cancelled in Tally') : (o.why == 'missing' ? bi('Tally માં નથી', 'Not in Tally') : bi('રકમ / તારીખ બદલાઈ', 'Changed in Tally'))}',
          trailing: _rs(o.amt),
          onTap: () => _openOrphan(context, o),
        ));
      }
    }
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: out);
  }
}

// ============================================================ purchase check
String _melState(String s, bool unknown) {
  switch (s) {
    case 'ok':
      return bi('✔ બરાબર', '✔ Matches');
    case 'tally_only':
      return unknown ? bi('❓ Tally માં છે, ખેડૂત ઓળખાયો નથી', '❓ In Tally, farmer not recognised') : bi('➕ Tally માં છે, Pro માં હિસાબ નથી', '➕ In Tally, no Pro hisab');
    case 'app_only':
      return bi('⚠ Pro માં છે, Tally માં ચડાવ્યું નથી', '⚠ In Pro, not booked in Tally');
    default:
      return bi('⚠ રકમમાં ફરક', '⚠ Amount differs');
  }
}

Future<void> _openMel(BuildContext context, _MelRow r) {
  return openPanel(
    context,
    title: r.name,
    sub: bi('Pro હિસાબ vs Tally ખરીદી', 'Pro hisab vs Tally purchase'),
    width: 520,
    child: _MelPanel(r),
  );
}

class _MelPanel extends StatelessWidget {
  final _MelRow r;
  const _MelPanel(this.r);

  void _link(BuildContext context) {
    final String party = r.vs.isNotEmpty ? r.vs.first.party : r.name;
    _pickFarmer(context, bi('આ પાર્ટી કયો ખેડૂત?', 'Which farmer is this party?'), (_Fm f) async {
      final NavigatorState nav = Navigator.of(context);
      await _setAlias(party, f.key);
      app.toast(bi('જોડ્યું: $party → ${f.label}', 'Linked: $party → ${f.label}'));
      nav.pop();
    });
  }

  @override
  Widget build(BuildContext context) {
    final String st = r.state;
    final List<Chit> cs = List<Chit>.from(r.chits);
    cs.sort((Chit a, Chit b) => b.at.compareTo(a.at));
    final List<TVoucher> vs = List<TVoucher>.from(r.vs);
    vs.sort((TVoucher a, TVoucher b) => b.date.compareTo(a.date));
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        _darkHead(bi('ફરક (Tally − Pro)', 'Difference (Tally − Pro)'), st == 'ok' ? '✔' : _sgn(r.diff), _melState(st, r.unknown)),
        const SizedBox(height: 12),
        Panel(
          child: Column(
            children: <Widget>[
              InfoRow(bi('Pro હિસાબ', 'Pro hisab'), '${_rs(r.app)} · ${r.napp} ${bi('ચિઠ્ઠી', 'chits')}'),
              InfoRow('Tally', '${_rs(r.tally)} · ${r.ntally} ${bi('વાઉચર', 'vouchers')}'),
            ],
          ),
        ),
        if (r.unknown) ...<Widget>[
          const SizedBox(height: 10),
          noteBox('warn', 'rose', bi('આ Tally પાર્ટી Pro ના કોઈ ખેડૂત સાથે મળી નથી. જોડી દો - પછી આપોઆપ મળશે.', 'This Tally party did not match any Pro farmer. Link it once - it is matched by itself afterwards.')),
          Btn(bi('ખેડૂત જોડો', 'Link to a farmer'), icon: 'users', kind: BtnKind.tonal, dense: true, onTap: () => _link(context)),
        ],
        const SizedBox(height: 10),
        caption('${bi('Pro હિસાબ (ચિઠ્ઠી)', 'Pro hisab (chits)')} · ${cs.length}'),
        if (cs.isEmpty) Text(bi('Pro માં આ સમયમાં આ ખેડૂતની ચિઠ્ઠી નથી', 'No chit of this farmer in Pro for this period'), style: ts(13, c: Pal.muted)),
        for (final Chit c in cs.take(60))
          lineItem(
            icon: 'receipt',
            tone: 'teal',
            title: '${dmy(c.at)} · #${c.no}',
            sub: '${c.commodity} · ${grp(payKg(c), dec: 0)} KG',
            trailing: chitAmount(c) == null ? bi('ભાવ નથી', 'No rate') : _rs(chitAmount(c) ?? 0),
          ),
        const SizedBox(height: 10),
        caption('Tally · ${vs.length}'),
        if (vs.isEmpty) Text(bi('Tally માં આ સમયમાં ખરીદીનું વાઉચર નથી', 'No purchase voucher in Tally for this period'), style: ts(13, c: Pal.muted)),
        for (final TVoucher v in vs.take(60)) _vTile(context, v),
      ],
    );
  }
}

class _MelTab extends StatefulWidget {
  final String firm;
  final String from;
  final String to;
  const _MelTab({required this.firm, required this.from, required this.to});

  @override
  State<_MelTab> createState() => _MelTabState();
}

class _MelTabState extends State<_MelTab> {
  int _view = 0;
  int _f = 0;
  int _limit = 60;

  @override
  Widget build(BuildContext context) {
    final _Mel m = _buildMel(widget.firm, widget.from, widget.to, _matcher());
    final List<_MelRow> bad = <_MelRow>[];
    final List<_MelRow> good = <_MelRow>[];
    for (final _MelRow r in m.rows) {
      if (r.state == 'ok') {
        good.add(r);
      } else {
        bad.add(r);
      }
    }
    final List<Widget> out = <Widget>[
      metricGrid(context, <Widget>[
        MetricTile(label: bi('Pro હિસાબ (ખરીદી)', 'Pro hisab (purchase)'), value: inrC(m.app), icon: 'calc', tone: 'teal', sub: m.noRate > 0 ? bi('${m.noRate} ચિઠ્ઠીમાં ભાવ નથી', '${m.noRate} chits have no rate') : null),
        MetricTile(label: bi('Tally ખરીદી', 'Tally purchase'), value: inrC(m.tally), icon: 'book', tone: 'violet', sub: '${m.nTally} ${bi('વાઉચર', 'vouchers')}'),
        MetricTile(label: bi('ફરક (Tally − Pro)', 'Difference (Tally − Pro)'), value: inrC(m.diff.abs()), icon: 'swap', tone: m.diff.abs() <= 2 ? 'green' : 'rose', sub: m.diff.abs() <= 2 ? bi('બરાબર', 'Matches') : (m.diff > 0 ? bi('Tally માં વધારે', 'More in Tally') : bi('Pro માં વધારે', 'More in Pro'))),
      ], pcCols: 3),
      const SizedBox(height: 10),
    ];
    if (m.nTally == 0) {
      out.add(noteBox('warn', 'amber', bi('આ સમય / ફર્મમાં Tally માં ખરીદીનું એક પણ વાઉચર નથી. કાચી કંપની (Balaji New) પસંદ કરી છે? Tally સિંક થયું છે?', 'No purchase voucher in Tally for this period / firm. Is the kacha company (Balaji New) selected? Has Tally synced?')));
    }
    out.add(ChipRow(
      labels: <String>[bi('ખેડૂત મુજબ', 'By farmer'), bi('દિવસ મુજબ', 'By day')],
      index: _view,
      onChanged: (int i) => setState(() {
        _view = i;
        _limit = 60;
      }),
    ));
    out.add(const SizedBox(height: 8));
    if (_view == 1) {
      if (m.days.isEmpty) out.add(_emptyNote(bi('આ સમયમાં કંઈ નથી', 'Nothing in this period')));
      for (final _MelDay d in m.days.take(_limit)) {
        final DateTime dt = DateTime.tryParse(d.date) ?? DateTime(2000);
        final bool ok = d.state == 'ok';
        out.add(lineItem(
          icon: ok ? 'check' : 'warn',
          tone: ok ? 'green' : 'amber',
          title: '${dayName(dt)} · ${dmy(dt)}',
          sub: 'Pro ${_rs(d.app)} · Tally ${_rs(d.tally)}',
          trailing: ok ? '✔' : _sgn(d.diff),
          trailingColor: ok ? Pal.ok : Pal.bad,
        ));
      }
      if (m.days.length > _limit) out.add(_moreBtn(m.days.length - _limit, () => setState(() => _limit += 100)));
    } else {
      out.add(ChipRow(
        labels: <String>['⚠ ${bi('ફરક', 'Differences')} ${bad.length}', '✔ ${bi('બરાબર', 'Matches')} ${good.length}', '${bi('બધા', 'All')} ${m.rows.length}'],
        index: _f,
        onChanged: (int i) => setState(() {
          _f = i;
          _limit = 60;
        }),
      ));
      out.add(const SizedBox(height: 8));
      final List<_MelRow> list = _f == 0 ? bad : (_f == 1 ? good : m.rows);
      if (list.isEmpty) {
        out.add(_emptyNote(_f == 0 ? bi('કોઈ ફરક નથી - બધું બરાબર મળે છે 🎉', 'No differences - everything matches 🎉') : bi('અહીં કંઈ નથી', 'Nothing here')));
      }
      for (final _MelRow r in list.take(_limit)) {
        final bool ok = r.state == 'ok';
        out.add(lineItem(
          icon: ok ? 'check' : (r.unknown ? 'users' : 'warn'),
          tone: ok ? 'green' : (r.unknown ? 'rose' : 'amber'),
          title: r.name,
          sub: 'Pro ${_rs(r.app)} · Tally ${_rs(r.tally)}\n${_melState(r.state, r.unknown)}',
          trailing: ok ? '✔' : _sgn(r.diff),
          trailingColor: ok ? Pal.ok : Pal.bad,
          onTap: () => _openMel(context, r),
        ));
      }
      if (list.length > _limit) out.add(_moreBtn(list.length - _limit, () => setState(() => _limit += 100)));
    }
    out.add(const SizedBox(height: 8));
    out.add(Text(
      bi('ખેડૂત મુજબ: Pro ના ભાવ × વજનની રકમ અને Tally ના ખરીદી વાઉચરનો સરવાળો સરખાવ્યો છે (₹2 સુધીનો ફરક ગણાતો નથી). ખેડૂત પર દબાવો તો બંનેની યાદી દેખાશે.', 'By farmer: the Pro amount (rate × weight) is compared with the total of the Tally purchase vouchers (a difference up to Rs 2 is ignored). Tap a farmer to see both lists.'),
      style: ts(12, c: Pal.faint),
    ));
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: out);
  }
}
