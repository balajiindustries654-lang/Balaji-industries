import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/errlog.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/insights.dart';
import '../../data/lists.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../data/owner_docs.dart';
import '../../data/statements.dart' show stockLineValue, stockRateEff, stockRateOf, setStockRates, suggestedStockValue;
import '../../data/trade.dart';
import '../../data/vouchers.dart' show reportHtml;
import '../../widgets/common.dart';
import '../../widgets/dayfield.dart';
import '../../widgets/launch.dart';
import '../../widgets/printer.dart';
import '../../widgets/page.dart';
import 'field.dart';
import 'kit.dart';
import 'kit2.dart';
import 'money_screens.dart';
import 'trade_screens.dart';
import 'ui.dart';

import '../../widgets/accept.dart';
import 'tally_data.dart' show TallyWhat, tallyStrip;
// ======================================================================
// Processing (raw material -> grades) and the stock worked out from it
// ======================================================================

double _num(TextEditingController c) => dbl(c.text.replaceAll(',', ''));

String _rawName(String code) => matLabel(code);

String _rowName(StockLine r) => r.raw ? _rawName(r.label) : r.label;

String _outsText(ProcBatch b) {
  final List<String> p = <String>[];
  for (final ProcOut o in b.outs) {
    if (o.kg > 0) p.add('${o.grade} ${grp(o.kg, dec: 0)}');
  }
  return p.join(' · ');
}

String procText(ProcBatch b) {
  final StringBuffer s = StringBuffer();
  s.writeln('Balaji Industries');
  s.writeln('${bi('પ્રોસેસ', 'Processing')} - ${dmy(b.date)}');
  s.writeln('${bi('કાચો માલ', 'Raw')}: ${_rawName(b.material)} ${grp(b.inKg, dec: 2)} KG');
  for (final ProcOut o in b.outs) {
    if (o.kg <= 0) continue;
    final double pc = b.inKg > 0 ? o.kg / b.inKg * 100 : 0;
    s.writeln('${o.grade}: ${grp(o.kg, dec: 2)} KG${o.bags > 0 ? ' (${o.bags} ${bi('બેગ', 'bags')})' : ''} - ${pc.toStringAsFixed(1)}%');
  }
  s.writeln('${bi('ઘટ', 'Loss')}: ${grp(b.loss, dec: 2)} KG (${b.lossPct.toStringAsFixed(1)}%)');
  return s.toString().trim();
}

Color _gradeColor(int i) {
  const List<Color> c = <Color>[Pal.teal, Pal.amber, Pal.info, Pal.violet, Pal.ok, Pal.bad];
  return c[i % c.length];
}

// ---------------------------------------------------------------- the form
Future<void> openProcessForm(BuildContext context, {String material = ''}) {
  return openPanel(
    context,
    title: bi('પ્રોસેસ વાઉચર', 'Processing Voucher'),
    sub: bi('કાચો માલ ગયો અને કયા ગ્રેડ નીકળ્યા', 'Raw material used and the grades obtained'),
    width: 520,
    child: ProcessForm(material: material),
  );
}

class _OutRow {
  final TextEditingController grade = TextEditingController();
  final TextEditingController kg = TextEditingController();
  final TextEditingController bags = TextEditingController();
  void dispose() {
    grade.dispose();
    kg.dispose();
    bags.dispose();
  }
}

class ProcessForm extends StatefulWidget {
  final String material;
  const ProcessForm({super.key, this.material = ''});

  @override
  State<ProcessForm> createState() => _ProcessFormState();
}

class _ProcessFormState extends State<ProcessForm> {
  late final VoidCallback _accept = () {
    _save();
  };

  final TextEditingController _in = TextEditingController();
  final TextEditingController _note = TextEditingController();
  final List<_OutRow> _rows = <_OutRow>[];
  late String _mat = widget.material.isNotEmpty ? widget.material : (kCommodities.isNotEmpty ? kCommodities[0][0] : '');
  DateTime _day = dateOnly(DateTime.now());
  bool _busy = false;
  String _err = '';

  @override
  void initState() {
    super.initState();
    AcceptHub.push(_accept);
    final List<String> g = knownGrades();
    for (int i = 0; i < 2; i++) {
      final _OutRow r = _OutRow();
      if (i < g.length) r.grade.text = g[i];
      _rows.add(r);
    }
  }

  @override
  void dispose() {
    _in.dispose();
    _note.dispose();
    for (final _OutRow r in _rows) {
      r.dispose();
    }
    AcceptHub.pop(_accept);
    super.dispose();
  }

  double get _outKg {
    double t = 0;
    for (final _OutRow r in _rows) {
      t += _num(r.kg);
    }
    return t;
  }

  Future<void> _pickDay() async {
    final DateTime? d = await pickDay(context, _day, last: dateOnly(DateTime.now()));
    if (d != null && mounted) setState(() => _day = d);
  }

  Future<void> _save() async {
    final double inKg = _num(_in);
    final List<ProcOut> outs = <ProcOut>[];
    for (final _OutRow r in _rows) {
      final double kg = _num(r.kg);
      final String g = r.grade.text.trim();
      if (kg <= 0) continue;
      if (g.isEmpty) {
        setState(() => _err = bi('દરેક જથ્થા સામે ગ્રેડનું નામ લખો', 'Give every quantity a grade name'));
        return;
      }
      outs.add(ProcOut(g, kg, _num(r.bags).round()));
    }
    String err = '';
    if (_mat.isEmpty) {
      err = bi('કાચો માલ પસંદ કરો', 'Choose the raw material');
    } else if (inKg <= 0) {
      err = bi('કાચા માલનું વજન લખો', 'Enter the raw material weight');
    } else if (outs.isEmpty) {
      err = bi('ઓછામાં ઓછો એક ગ્રેડ અને તેનું વજન લખો', 'Enter at least one grade with its weight');
    } else if (_outKg > inKg + 0.5) {
      err = bi('નીકળેલો માલ વપરાયેલા માલ કરતાં વધારે છે', 'Output is more than the input');
    }
    if (err.isNotEmpty) {
      setState(() => _err = err);
      return;
    }
    final double? left = stockLeftOf(true, _mat);
    if (left != null && inKg > left + 0.5) {
      final bool go = await confirmBox(
        context,
        title: bi('સ્ટોક કરતાં વધારે', 'More than the stock'),
        text: bi('કાચા માલનો સ્ટોક ${grp(left, dec: 0)} KG છે અને તમે ${grp(inKg, dec: 0)} KG વાપર્યો. છતાં સેવ કરવું?', 'Raw stock is ${grp(left, dec: 0)} KG but you used ${grp(inKg, dec: 0)} KG. Save anyway?'),
        yes: bi('હા, સેવ કરો', 'Yes, save'),
        no: bi('ના', 'No'),
      );
      if (!go || !mounted) return;
    }
    setState(() {
      _busy = true;
      _err = '';
    });
    await addProc(date: _day, material: _mat, inKg: inKg, outs: outs, note: _note.text);
    final double loss = inKg - _outKg;
    app.toast('${bi('પ્રોસેસ સેવ', 'Processing saved')} · ${bi('ઘટ', 'loss')} ${(inKg > 0 ? loss / inKg * 100 : 0).toStringAsFixed(1)}%');
    if (mounted) Navigator.of(context).pop();
  }

  Widget _summary() {
    final double inKg = _num(_in);
    final double outKg = _outKg;
    if (inKg <= 0 && outKg <= 0) return const SizedBox.shrink();
    final double loss = inKg - outKg;
    final double pc = inKg > 0 ? loss / inKg * 100 : 0;
    final bool bad = loss < -0.5;
    return Padding(
      padding: const EdgeInsets.only(top: 4, bottom: 12),
      child: noteBox(
        bad ? 'warn' : 'chart',
        bad ? 'rose' : 'teal',
        bad
            ? bi('નીકળેલો માલ ${grp(-loss, dec: 1)} KG વધારે છે', 'Output is ${grp(-loss, dec: 1)} KG too much')
            : '${bi('નીકળ્યો', 'Output')} ${grp(outKg, dec: 1)} KG · ${bi('ઘટ', 'Loss')} ${grp(loss, dec: 1)} KG (${pc.toStringAsFixed(1)}%)',
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final List<String> grades = knownGrades();
    final double? left = _mat.isEmpty ? null : stockLeftOf(true, _mat);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        LineRow(label: bi('કાચો માલ', 'Raw material'), child: ChipRow(
          labels: <String>[for (final List<String> x in kCommodities) bi(x[1], x[2])],
          index: kCommodities.indexWhere((List<String> x) => x[0] == _mat),
          onChanged: (int i) => setState(() => _mat = kCommodities[i][0]),
        )),
        const SizedBox(height: 14),
        FieldX(
          label: '${bi('વપરાયેલો માલ', 'Input weight')} *',
          controller: _in,
          suffix: 'KG',
          big: true,
          keyboard: const TextInputType.numberWithOptions(decimal: true),
          onChanged: (String v) => setState(() {}),
        ),
        if (left != null)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text('${bi('સ્ટોકમાં', 'In stock')}: ${grp(left, dec: 0)} KG', style: ts(12.5, w: FontWeight.w700, c: _num(_in) > left + 0.5 ? Pal.bad : Pal.muted)),
          ),
        const SizedBox(height: 18),
        Text(bi('નીકળેલો માલ (ગ્રેડ પ્રમાણે)', 'Output (by grade)'), style: ts(13.5, w: FontWeight.w800)),
        const SizedBox(height: 10),
        for (int i = 0; i < _rows.length; i++)
          Padding(
            key: ObjectKey(_rows[i]),
            padding: const EdgeInsets.only(bottom: 12),
            child: Surface(
              shadow: false,
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Expanded(child: SuggestField(label: '${bi('ગ્રેડ', 'Grade')} ${i + 1}', controller: _rows[i].grade, options: grades, onChanged: (String v) => setState(() {}), onPick: (String v) => setState(() {}))),
                      if (_rows.length > 1)
                        Padding(
                          padding: const EdgeInsets.only(left: 6, top: 22),
                          child: IconBtn(
                            'trash',
                            tip: bi('કાઢો', 'Remove'),
                            onTap: () => setState(() {
                              final _OutRow r = _rows.removeAt(i);
                              r.dispose();
                            }),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: <Widget>[
                      Expanded(flex: 3, child: FieldX(label: bi('વજન', 'Weight'), controller: _rows[i].kg, suffix: 'KG', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {}))),
                      const SizedBox(width: 10),
                      Expanded(flex: 2, child: FieldX(label: bi('બેગ', 'Bags'), controller: _rows[i].bags, keyboard: TextInputType.number)),
                    ],
                  ),
                ],
              ),
            ),
          ),
        Btn(bi('બીજો ગ્રેડ ઉમેરો', 'Add another grade'), icon: 'plus', kind: BtnKind.tonal, expand: true, onTap: () => setState(() => _rows.add(_OutRow()))),
        const SizedBox(height: 12),
        _summary(),
        DayField(label: bi('તારીખ', 'Date'), value: _day, last: dateOnly(DateTime.now()), onChanged: (DateTime d) => setState(() => _day = d)),
        const SizedBox(height: 14),
        FieldX(label: bi('નોંધ (ઇચ્છા મુજબ)', 'Note (optional)'), controller: _note),
        const SizedBox(height: 14),
        if (_err.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(_err, style: ts(13, w: FontWeight.w700, c: Pal.bad))),
        _busy
            ? SizedBox(height: 52, child: Center(child: SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 2.6, color: Pal.brand))))
            : Btn(bi('સેવ કરો', 'Save'), icon: 'check', expand: true, onTap: _save),
      ],
    );
  }
}

// ------------------------------------------------------------ one batch
Future<void> openProcDetail(BuildContext context, ProcBatch b) {
  return openPanel(
    context,
    title: '${_rawName(b.material)} · ${grp(b.inKg, dec: 0)} KG',
    sub: dmy(b.date),
    width: 460,
    child: _ProcDetail(b),
  );
}

class _ProcDetail extends StatelessWidget {
  final ProcBatch b;
  const _ProcDetail(this.b);

  Future<void> _remove(BuildContext context) async {
    final bool go = await confirmBox(
      context,
      title: bi('આ પ્રોસેસ કાઢી નાખવી?', 'Delete this processing entry?'),
      text: bi('આ નોંધ કાઢતાં સ્ટોક બદલાશે.', 'Removing it changes the stock.'),
      yes: bi('હા, કાઢો', 'Yes, delete'),
      no: bi('ના', 'No'),
    );
    if (!go) return;
    await removeProc(b.id);
    if (context.mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        InfoRow(bi('કાચો માલ', 'Raw material'), '${_rawName(b.material)} · ${grp(b.inKg, dec: 2)} KG'),
        const Divider(height: 22),
        for (final ProcOut o in b.outs)
          InfoRow(
            o.grade,
            '${grp(o.kg, dec: 2)} KG${o.bags > 0 ? ' · ${o.bags} ${bi('બેગ', 'bags')}' : ''} · ${(b.inKg > 0 ? o.kg / b.inKg * 100 : 0).toStringAsFixed(1)}%',
          ),
        const Divider(height: 22),
        InfoRow(bi('કુલ નીકળ્યું', 'Total output'), '${grp(b.outKg, dec: 2)} KG', bold: true),
        InfoRow(bi('ઘટ', 'Loss'), '${grp(b.loss, dec: 2)} KG (${b.lossPct.toStringAsFixed(1)}%)', bold: true, color: b.lossPct > 12 ? Pal.bad : Pal.brand),
        if (b.note.isNotEmpty) InfoRow(bi('નોંધ', 'Note'), b.note),
        const SizedBox(height: 14),
        Row(
          children: <Widget>[
            tExp(child: Btn('WhatsApp', icon: 'chat', onTap: () => whatsappText(procText(b)))),
            const SizedBox(width: 8),
            tExp(child: Btn(bi('કાઢો', 'Delete'), icon: 'trash', kind: BtnKind.danger, onTap: () => _remove(context))),
          ],
        ),
      ],
    );
  }
}

// -------------------------------------------------------- process screen
class ProcessScreen extends StatefulWidget {
  const ProcessScreen({super.key});

  @override
  State<ProcessScreen> createState() => _ProcessState();
}

class _ProcessState extends State<ProcessScreen> {
  RangeSel _sel = RangeSel(4);

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[procDoc, saleDoc, prefDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 820,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final Period p = _sel.period;
          final List<ProcBatch> l = procBatches().where((ProcBatch b) => p.has(b.date)).toList();
          double inKg = 0;
          double outKg = 0;
          final Map<String, double> byGrade = <String, double>{};
          for (final ProcBatch b in l) {
            inKg += b.inKg;
            outKg += b.outKg;
            for (final ProcOut o in b.outs) {
              final String g = o.grade.trim();
              if (g.isEmpty) continue;
              byGrade[g] = (byGrade[g] ?? 0) + o.kg;
            }
          }
          final double loss = inKg - outKg;
          final double lossPc = inKg > 0 ? loss / inKg * 100 : 0;
          final List<MapEntry<String, double>> gl = byGrade.entries.toList();
          gl.sort((MapEntry<String, double> a, MapEntry<String, double> b) => b.value.compareTo(a.value));
          return <Widget>[
            ScreenHeader(bi('પ્રોસેસ / ગ્રેડ', 'Processing / grades'), sub: p.label, actions: <Widget>[
              IconBtn('plus', tip: bi('નવી પ્રોસેસ', 'New processing'), onTap: () => openProcessForm(ctx)),
            ]),
            statusBanner(),
            RangeBar(sel: _sel, presets: const <int>[0, 2, 3, 4, 5, 6], onChanged: (RangeSel s) => setState(() => _sel = s)),
            const SizedBox(height: 12),
            HeroCard(
              title: bi('કાચો માલ વપરાયો', 'Raw material used'),
              value: kgTxt(inKg),
              unit: '',
              sub: '${l.length} ${bi('પ્રોસેસ', 'batches')} · ${bi('નીકળ્યું', 'output')} ${kgTxt(outKg)}',
              chips: <HeroChip>[
                HeroChip('pct', '${bi('ઉતાર', 'Yield')} ${inKg > 0 ? (outKg / inKg * 100).toStringAsFixed(1) : '0'}%'),
                HeroChip('down', '${bi('ઘટ', 'Loss')} ${lossPc.toStringAsFixed(1)}%'),
              ],
            ),
            const SizedBox(height: 12),
            Btn(bi('નવી પ્રોસેસ નાખો', 'Add a processing batch'), icon: 'plus', expand: true, onTap: () => openProcessForm(ctx)),
            const SizedBox(height: 8),
            Btn(bi('સ્ટોક જુઓ', 'See the stock'), icon: 'warehouse', kind: BtnKind.tonal, expand: true, onTap: () => app.go('stock_live')),
            const SizedBox(height: 14),
            if (gl.isNotEmpty)
              Panel(
                title: bi('ગ્રેડ પ્રમાણે ઉતાર', 'Yield by grade'),
                sub: bi('વપરાયેલા માલના % માં', 'as % of the input'),
                child: RankList(<RankItem>[
                  for (int i = 0; i < gl.length; i++)
                    RankItem(
                      gl[i].key,
                      gl[i].value,
                      '${kgTxt(gl[i].value)} · ${inKg > 0 ? (gl[i].value / inKg * 100).toStringAsFixed(1) : '0'}%',
                      _gradeColor(i),
                    ),
                ]),
              ),
            if (gl.isNotEmpty) const SizedBox(height: 14),
            if (l.isEmpty) EmptyBox(icon: 'grain', title: bi('આ સમયમાં કોઈ પ્રોસેસ નથી', 'No processing in this period'), sub: bi('ઉપર "નવી પ્રોસેસ" દબાવો', 'Tap "Add a processing batch" above')),
            for (final ProcBatch b in l.take(120))
              lineItem(
                icon: 'grain',
                tone: 'amber',
                title: '${_rawName(b.material)} · ${kgTxt(b.inKg)}',
                sub: '${dayLabel(b.date)} · ${_outsText(b)}',
                trailing: '${b.lossPct.toStringAsFixed(1)}%',
                trailingSub: bi('ઘટ', 'loss'),
                trailingColor: b.lossPct > 12 || b.loss < -0.5 ? Pal.bad : Pal.ok,
                onTap: () => openProcDetail(ctx, b),
              ),
          ];
        },
      ),
    );
  }
}

// ================================================================== stock
Future<void> openStockForm(BuildContext context, {StockLine? row}) {
  return openPanel(
    context,
    title: bi('ખુલતો સ્ટોક', 'Opening Stock'),
    sub: row == null ? bi('નવો માલ સ્ટોકમાં ઉમેરો', 'Add an item to the stock') : _rowName(row),
    width: 440,
    child: OpenStockForm(row: row),
  );
}

class OpenStockForm extends StatefulWidget {
  final StockLine? row;
  const OpenStockForm({super.key, this.row});

  @override
  State<OpenStockForm> createState() => _OpenStockFormState();
}

class _OpenStockFormState extends State<OpenStockForm> {
  late final VoidCallback _accept = () {
    _save();
  };

  final TextEditingController _kg = TextEditingController();
  final TextEditingController _grade = TextEditingController();
  bool _raw = false;
  String _code = '';
  bool _busy = false;
  String _err = '';

  bool get _isNew => widget.row == null;

  @override
  void initState() {
    super.initState();
    AcceptHub.push(_accept);
    final StockLine? r = widget.row;
    if (r != null) {
      _raw = r.raw;
      if (r.open != 0) _kg.text = plainNum(r.open);
    } else {
      _raw = true;
    }
  }

  @override
  void dispose() {
    _kg.dispose();
    _grade.dispose();
    AcceptHub.pop(_accept);
    super.dispose();
  }

  Future<void> _save() async {
    final double kg = _num(_kg);
    String key;
    String label;
    final StockLine? r = widget.row;
    if (r != null) {
      key = r.key;
      label = r.label;
    } else if (_raw) {
      if (_code.isEmpty) {
        setState(() => _err = bi('કયો કાચો માલ તે પસંદ કરો', 'Choose the raw material'));
        return;
      }
      key = stockKey(true, _code);
      label = _code;
    } else {
      label = _grade.text.trim();
      if (label.isEmpty) {
        setState(() => _err = bi('ગ્રેડનું નામ લખો', 'Enter the grade name'));
        return;
      }
      key = stockKey(false, label);
    }
    if (kg < 0) {
      setState(() => _err = bi('વજન ઓછું ન હોઈ શકે', 'Weight cannot be negative'));
      return;
    }
    setState(() {
      _busy = true;
      _err = '';
    });
    await setStockOpen(key, kg, label: label);
    app.toast('${bi('ઓપનિંગ સ્ટોક', 'Opening stock')} · ${grp(kg, dec: 0)} KG');
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final StockLine? r = widget.row;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        if (r != null) ...<Widget>[
          InfoRow(bi('આવ્યું', 'Received'), '${grp(r.got, dec: 0)} KG'),
          if (r.raw) InfoRow(bi('પ્રોસેસમાં ગયું', 'Processed'), '${grp(r.used, dec: 0)} KG'),
          InfoRow(bi('વેચ્યું', 'Sold'), '${grp(r.sold, dec: 0)} KG'),
          InfoRow(bi('હાલ સ્ટોક', 'In stock now'), '${grp(r.left, dec: 0)} KG', bold: true, color: r.left < -0.5 ? Pal.bad : Pal.brand),
          const SizedBox(height: 14),
        ] else ...<Widget>[
          Seg(
            labels: <String>[bi('કાચો માલ', 'Raw material'), bi('તૈયાર માલ (ગ્રેડ)', 'Finished (grade)')],
            index: _raw ? 0 : 1,
            onChanged: (int i) => setState(() => _raw = i == 0),
            dense: true,
          ),
          const SizedBox(height: 12),
          if (_raw)
            ChipRow(
              labels: <String>[for (final List<String> x in kCommodities) bi(x[1], x[2])],
              index: kCommodities.indexWhere((List<String> x) => x[0] == _code),
              onChanged: (int i) => setState(() => _code = kCommodities[i][0]),
            )
          else
            SuggestField(label: '${bi('ગ્રેડ / માલનું નામ', 'Grade / item')} *', controller: _grade, options: knownGrades()),
          const SizedBox(height: 14),
        ],
        FieldX(
          label: bi('શરૂઆતનો સ્ટોક', 'Opening stock'),
          controller: _kg,
          suffix: 'KG',
          big: true,
          keyboard: const TextInputType.numberWithOptions(decimal: true),
        ),
        const SizedBox(height: 6),
        Text(
          bi('ગણતરી શરૂ કરવાની તારીખે ગોડાઉનમાં જે માલ પડ્યો હતો તે લખો. 0 લખો તો ઓપનિંગ કાઢી નંખાશે.', 'Enter what was already in the godown on the counting start date. Enter 0 to clear it.'),
          style: ts(12, c: Pal.muted),
        ),
        const SizedBox(height: 14),
        if (_err.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(_err, style: ts(13, w: FontWeight.w700, c: Pal.bad))),
        _busy
            ? SizedBox(height: 52, child: Center(child: SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 2.6, color: Pal.brand))))
            : Btn(_isNew ? bi('ઉમેરો', 'Add') : bi('સેવ કરો', 'Save'), icon: 'check', expand: true, onTap: _save),
      ],
    );
  }
}

// ---------------------------------------------------------- stock rates
/// Valuation rate (Rs per 20 KG) of every stock item - the Rate and Value of the Stock Summary and the closing stock of the
/// Profit & Loss A/c / Balance Sheet come from it. Left empty = the latest rate of the Price List is used.
Future<void> openStockRatesForm(BuildContext context) {
  return openPanel(
    context,
    title: bi('સ્ટોકનો ભાવ (Rates)', 'Stock Rates'),
    sub: bi('₹ પ્રતિ 20 KG (મણ) - સ્ટોકની કિંમત માટે', 'Rs per 20 KG - to value the stock'),
    width: 460,
    child: const _StockRatesForm(),
  );
}

class _StockRatesForm extends StatefulWidget {
  const _StockRatesForm();

  @override
  State<_StockRatesForm> createState() => _StockRatesFormState();
}

class _StockRatesFormState extends State<_StockRatesForm> {
  late final List<StockLine> _rows = stockRows();
  late final Map<String, TextEditingController> _c = <String, TextEditingController>{
    for (final StockLine r in _rows) r.key: TextEditingController(text: stockRateOf(r.key) <= 0 ? '' : plainNum(stockRateOf(r.key))),
  };
  bool _busy = false;

  @override
  void dispose() {
    for (final TextEditingController c in _c.values) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    if (_busy) return;
    setState(() => _busy = true);
    final Map<String, double> m = <String, double>{
      for (final MapEntry<String, TextEditingController> e in _c.entries) e.key: dbl(e.value.text.replaceAll(',', '')),
    };
    final bool ok = await ErrLog.attempt('Stock rates', () => setStockRates(m));
    if (!mounted) return;
    if (ok) {
      Navigator.of(context).pop();
    } else {
      setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final DateTime today = dateOnly(DateTime.now());
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Text(
          bi('દરેક માલનો હિસાબ માટેનો ભાવ લખો. ખાલી રાખશો તો "ભાવ યાદી" નો છેલ્લો ભાવ વપરાશે.', 'Enter the rate used to value each item. If left empty the latest rate of the Price List is used.'),
          style: ts(13.5, h: 1.4),
        ),
        const SizedBox(height: 12),
        if (_rows.isEmpty) Text(bi('હજી કોઈ માલ નથી', 'No stock items yet'), style: ts(13, c: Pal.muted)),
        for (final StockLine r in _rows) ...<Widget>[
          FieldX(
            label: _rowName(r),
            controller: _c[r.key],
            prefix: '₹',
            suffix: '/20 KG',
            hint: rateFor(r.label, today) == null ? null : '${bi('ભાવ યાદી', 'Price List')} ${plainNum(rateFor(r.label, today)!)}',
            keyboard: const TextInputType.numberWithOptions(decimal: true),
          ),
          const SizedBox(height: 10),
        ],
        const SizedBox(height: 6),
        Btn(bi('સેવ કરો', 'Save'), icon: 'check', expand: true, onTap: _busy ? null : _save),
      ],
    );
  }
}

// ---------------------------------------------------------- stock screen
class StockScreen extends StatefulWidget {
  const StockScreen({super.key});

  @override
  State<StockScreen> createState() => _StockState();
}

class _StockState extends State<StockScreen> {
  late final VoidCallback _prn = () {
    _print();
  };
  late final VoidCallback _exp = () {
    _export();
  };

  @override
  void initState() {
    super.initState();
    printHub.push(_prn);
    exportHub.push(_exp);
  }

  @override
  void dispose() {
    printHub.pop(_prn);
    exportHub.pop(_exp);
    super.dispose();
  }

  /// KG as the Stock Summary of TallyPrime writes a quantity (blank when nothing).
  String _q(double v) => v.abs() < 0.5 ? '' : '${grp(v)} KG';

  String _rate(double v) => v <= 0 ? '' : grp(v, dec: 2);

  String _val(double v) => v.abs() < 0.5 ? '' : grp(v, dec: 2);

  /// Particulars | Opening Balance | Inwards | Outwards | Closing Balance (Quantity, Rate, Value), raw material and finished goods as groups.
  /// [grand] gets opening, inwards, outwards, closing quantity and closing value.
  List<List<String>> _rows(List<StockLine> raw, List<StockLine> out, List<int> bold, List<double> grand) {
    final List<List<String>> rows = <List<String>>[];
    final DateTime today = dateOnly(DateTime.now());
    void group(String name, List<StockLine> l) {
      if (l.isEmpty) return;
      double o = 0;
      double i = 0;
      double x = 0;
      double c = 0;
      double v = 0;
      for (final StockLine r in l) {
        o += r.open;
        i += r.got;
        x += r.used + r.sold;
        c += r.left;
        v += stockLineValue(r, today);
      }
      bold.add(rows.length);
      rows.add(<String>[name, _q(o), _q(i), _q(x), _q(c), '', _val(v)]);
      for (final StockLine r in l) {
        rows.add(<String>['     ${_rowName(r)}', _q(r.open), _q(r.got), _q(r.used + r.sold), _q(r.left), _rate(stockRateEff(r, today)), _val(stockLineValue(r, today))]);
      }
      grand[0] += o;
      grand[1] += i;
      grand[2] += x;
      grand[3] += c;
      grand[4] += v;
    }

    group('Raw Material', raw);
    group('Finished Goods', out);
    return rows;
  }

  Future<void> _print() async {
    final List<StockLine> all = stockRows();
    final List<int> bold = <int>[];
    final List<double> g = <double>[0, 0, 0, 0, 0];
    final List<List<String>> rows = _rows(all.where((StockLine r) => r.raw).toList(), all.where((StockLine r) => !r.raw).toList(), bold, g);
    final bool ok = await printHtml(
      reportHtml(
        title: 'Stock Summary',
        period: '${tDateFull(stockFrom())} to ${tDateFull(DateTime.now())}',
        heads: const <String>['Particulars', 'Opening Balance', 'Inwards', 'Outwards', 'Closing Quantity', 'Rate (per 20 KG)', 'Closing Value'],
        right: const <bool>[false, true, true, true, true, true, true],
        rows: rows,
        total: <String>['Grand Total', _q(g[0]), _q(g[1]), _q(g[2]), _q(g[3]), '', _val(g[4])],
        bold: bold.toSet(),
      ),
      'stock-summary',
    );
    if (!ok) app.toast(bi('પ્રિન્ટ પેજ ખૂલ્યું નહીં', 'Could not open the print page'));
  }

  Future<void> _export() async {
    final List<StockLine> all = stockRows();
    final List<List<String>> rows = _rows(all.where((StockLine r) => r.raw).toList(), all.where((StockLine r) => !r.raw).toList(), <int>[], <double>[0, 0, 0, 0, 0]);
    final StringBuffer b = StringBuffer();
    b.writeln('Particulars,Opening Balance,Inwards,Outwards,Closing Quantity,Rate (per 20 KG),Closing Value');
    for (final List<String> row in rows) {
      b.writeln(row.map(csvCell).join(','));
    }
    final String path = await saveCsvFile(b.toString(), 'stock-summary-${dayKey(DateTime.now())}');
    if (path.isNotEmpty) {
      app.toast('${bi('Excel ફાઇલ બની', 'Excel file saved')}: $path');
    } else {
      copyText(b.toString(), msg: bi('કૉપિ થયું - Excel માં પેસ્ટ કરો', 'Copied - paste into Excel'));
    }
  }

  List<Widget> _table(BuildContext ctx, List<StockLine> raw, List<StockLine> out) {
    final List<PcCol> cols = <PcCol>[
      PcCol(bi('વિગત (Particulars)', 'Particulars'), 0),
      PcCol(bi('શરૂઆતનું બાકી', 'Opening Balance'), 112, right: true),
      PcCol(bi('આવક (Inwards)', 'Inwards'), 112, right: true),
      PcCol(bi('જાવક (Outwards)', 'Outwards'), 112, right: true),
      PcCol(bi('આખરી જથ્થો', 'Closing Quantity'), 120, right: true),
      PcCol(bi('ભાવ /20 KG', 'Rate /20 KG'), 100, right: true),
      PcCol(bi('કિંમત (Value)', 'Value'), 130, right: true),
    ];
    final DateTime today = dateOnly(DateTime.now());
    final List<Widget> w = <Widget>[pcHead(cols)];
    final List<double> g = <double>[0, 0, 0, 0, 0];
    void group(String name, List<StockLine> l) {
      if (l.isEmpty) return;
      double o = 0;
      double i = 0;
      double x = 0;
      double c = 0;
      double v = 0;
      for (final StockLine r in l) {
        o += r.open;
        i += r.got;
        x += r.used + r.sold;
        c += r.left;
        v += stockLineValue(r, today);
      }
      w.add(pcRow(cols, <Widget>[pcTd(name, bold: true), pcTd(_q(o), num: true, bold: true), pcTd(_q(i), num: true, bold: true), pcTd(_q(x), num: true, bold: true), pcTd(_q(c), num: true, bold: true), pcTd(''), pcTd(_val(v), num: true, bold: true)], bg: Pal.soft));
      for (final StockLine r in l) {
        w.add(pcRow(
          cols,
          <Widget>[
            Padding(padding: const EdgeInsets.only(left: 18), child: pcTd(_rowName(r))),
            pcTd(_q(r.open), num: true),
            pcTd(_q(r.got), num: true),
            pcTd(_q(r.used + r.sold), num: true),
            pcTd(_q(r.left), num: true, bold: true, c: r.left < -0.5 ? Pal.bad : null),
            pcTd(_rate(stockRateEff(r, today)), num: true),
            pcTd(_val(stockLineValue(r, today)), num: true),
          ],
          onTap: () => openStockForm(ctx, row: r),
        ));
      }
      g[0] += o;
      g[1] += i;
      g[2] += x;
      g[3] += c;
      g[4] += v;
    }

    group(bi('કાચો માલ', 'Raw Material'), raw);
    group(bi('તૈયાર માલ', 'Finished Goods'), out);
    w.add(pcTotal(cols, bi('કુલ (Grand Total)', 'Grand Total'), vals: <int, String>{1: _q(g[0]), 2: _q(g[1]), 3: _q(g[2]), 4: _q(g[3]), 6: _val(g[4])}));
    return w;
  }

  Future<void> _pickFrom() async {
    final DateTime? d = await pickDay(context, stockFrom(), last: dateOnly(DateTime.now()));
    if (d == null) return;
    await setStockFrom(d);
    if (mounted) setState(() {});
  }

  String _text(List<StockLine> l) {
    final StringBuffer b = StringBuffer();
    b.writeln('Balaji Industries');
    b.writeln('${bi('સ્ટોક', 'Stock')} (${dmy(DateTime.now())})');
    b.writeln('------------------------');
    final List<StockLine> raw = l.where((StockLine r) => r.raw).toList();
    final List<StockLine> out = l.where((StockLine r) => !r.raw).toList();
    if (raw.isNotEmpty) {
      b.writeln(bi('કાચો માલ', 'Raw material'));
      for (final StockLine r in raw) {
        b.writeln('${_rowName(r)}: ${grp(r.left, dec: 0)} KG');
      }
    }
    if (out.isNotEmpty) {
      b.writeln(bi('તૈયાર માલ', 'Finished goods'));
      for (final StockLine r in out) {
        b.writeln('${_rowName(r)}: ${grp(r.left, dec: 0)} KG');
      }
    }
    return b.toString().trim();
  }

  Widget _row(BuildContext ctx, StockLine r) {
    final String parts = '${r.open != 0 ? '${bi('ઓપનિંગ', 'Open')} ${grp(r.open, dec: 0)} + ' : ''}${bi('આવ્યું', 'In')} ${grp(r.got, dec: 0)}'
        '${r.used > 0 ? ' − ${bi('પ્રોસેસ', 'Used')} ${grp(r.used, dec: 0)}' : ''}'
        '${r.sold > 0 ? ' − ${bi('વેચ્યું', 'Sold')} ${grp(r.sold, dec: 0)}' : ''}';
    final bool neg = r.left < -0.5;
    return lineItem(
      icon: r.raw ? 'grain' : 'box',
      tone: neg ? 'rose' : (r.raw ? 'amber' : 'teal'),
      title: _rowName(r),
      sub: parts,
      trailing: kgTxt(r.left),
      trailingSub: neg ? bi('ઓછો / ભૂલ?', 'negative?') : 'KG',
      trailingColor: neg ? Pal.bad : null,
      onTap: () => openStockForm(ctx, row: r),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[procDoc, saleDoc, prefDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 1100,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final List<StockLine> all = stockRows();
          final List<StockLine> raw = all.where((StockLine r) => r.raw).toList();
          final List<StockLine> out = all.where((StockLine r) => !r.raw).toList();
          double rawKg = 0;
          double outKg = 0;
          for (final StockLine r in raw) {
            rawKg += r.left;
          }
          for (final StockLine r in out) {
            outKg += r.left;
          }
          final DateTime from = stockFrom();
          final double stockVal = suggestedStockValue(dateOnly(DateTime.now()));
          return <Widget>[
            ScreenHeader(bi('સ્ટોક સમરી', 'Stock Summary'), sub: '${bi('ગણતરી શરૂ', 'Counted from')} ${dmy(from)}', actions: <Widget>[
              IconBtn('plus', tip: bi('માલ ઉમેરો', 'Add item'), onTap: () => openStockForm(ctx)),
              IconBtn('rupee', tip: bi('સ્ટોકનો ભાવ (Rates)', 'Stock Rates'), onTap: () => openStockRatesForm(ctx)),
              IconBtn('print', tip: bi('પ્રિન્ટ (Ctrl+P)', 'Print (Ctrl+P)'), onTap: _print),
              IconBtn('table', tip: bi('Excel (Alt+E)', 'Export to Excel (Alt+E)'), onTap: _export),
            ]),
            statusBanner(),
            tallyStrip(TallyWhat.stock),
            HeroCard(
              title: bi('કાચો માલ સ્ટોકમાં', 'Raw material in stock'),
              value: kgTxt(rawKg),
              unit: '',
              sub: '${raw.length + out.length} ${bi('પ્રકારનો માલ', 'items tracked')}',
              chips: <HeroChip>[
                HeroChip('box', '${bi('તૈયાર માલ', 'Finished')} ${kgTxt(outKg)}'),
                if (stockVal > 0.5) HeroChip('rupee', '${bi('કિંમત', 'Value')} ₹${grp(stockVal)}'),
                HeroChip('cal', dmy(from)),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                Expanded(child: dayButton(from, _pickFrom)),
                const SizedBox(width: 8),
                tExp(child: Btn(bi('સ્ટોક મોકલો', 'Send stock'), icon: 'chat', kind: BtnKind.tonal, onTap: () => whatsappText(_text(all)))),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: <Widget>[
                tExp(child: Btn(bi('નવી પ્રોસેસ', 'New processing'), icon: 'grain', kind: BtnKind.outline, onTap: () => openProcessForm(ctx))),
                const SizedBox(width: 8),
                tExp(child: Btn(bi('નવું વેચાણ', 'New sale'), icon: 'receipt', kind: BtnKind.outline, onTap: () => openSaleForm(ctx))),
              ],
            ),
            const SizedBox(height: 14),
            if (!stockFromSet()) noteBox('bulb', 'amber', bi('ગણતરી આ મહિનાની 1 તારીખથી શરૂ છે. ઉપર તારીખ દબાવીને બદલો અને દરેક માલ પર દબાવીને ઓપનિંગ સ્ટોક લખો.', 'Counting starts on the 1st of this month. Tap the date above to change it, then tap an item to set its opening stock.')),
            if (all.isEmpty) EmptyBox(icon: 'warehouse', title: bi('હજી સ્ટોકનો કોઈ માલ નથી', 'No stock yet'), sub: bi('કાંટાની ગાડી આવે એટલે કાચો માલ આપમેળે દેખાશે. જૂનો માલ "+" થી ઉમેરો.', 'Raw material appears by itself from the weighbridge. Add old stock with "+".')),
            if (app.stagePc && all.isNotEmpty) ...<Widget>[
              ..._table(ctx, raw, out),
            ] else ...<Widget>[
              if (raw.isNotEmpty) caption(bi('કાચો માલ', 'RAW MATERIAL')),
              for (final StockLine r in raw) _row(ctx, r),
              if (out.isNotEmpty) caption(bi('તૈયાર માલ', 'FINISHED GOODS')),
              for (final StockLine r in out) _row(ctx, r),
            ],
            const SizedBox(height: 10),
            noteBox('chart', 'teal', bi('સ્ટોક = ઓપનિંગ + કાંટા/પ્રોસેસથી આવ્યું − પ્રોસેસમાં ગયું − વેચ્યું. કોઈ માલ પર દબાવી ઓપનિંગ સુધારો.', 'Stock = opening + received (weighbridge / processing) − processed − sold. Tap an item to fix its opening.')),
          ];
        },
      ),
    );
  }
}
