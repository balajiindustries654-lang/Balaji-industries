import 'package:flutter/material.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/insights.dart';
import '../../data/live_store.dart';
import '../../data/money.dart';
import '../../data/owner_docs.dart';
import '../../data/trade.dart';
import '../../widgets/common.dart';
import '../../widgets/page.dart';
import 'kit.dart';
import 'kit2.dart';
import 'money_screens.dart';
import 'ui.dart';

class _MoneyExp {
  final String icon;
  final String tone;
  final String title;
  final int count;
  final String Function() csv;
  const _MoneyExp(this.icon, this.tone, this.title, this.count, this.csv);
}

/// Copy the accounts as CSV (paste into Excel / Google Sheets).
class MoneyExportScreen extends StatefulWidget {
  const MoneyExportScreen({super.key});

  @override
  State<MoneyExportScreen> createState() => _MoneyExportState();
}

class _MoneyExportState extends State<MoneyExportScreen> {
  RangeSel _sel = RangeSel(4);

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[payDoc, expDoc, saleDoc, procDoc, prefDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 800,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final Period p = _sel.period;
          final List<PayItem> pays = payItems().where((PayItem x) => p.has(x.date)).toList();
          final List<ExpItem> exps = expItems().where((ExpItem x) => p.has(x.date)).toList();
          final List<SaleItem> sales = saleItems().where((SaleItem x) => p.has(x.date)).toList();
          final List<ProcBatch> procs = procBatches().where((ProcBatch x) => p.has(x.date)).toList();
          final List<StockLine> stock = stockRows();
          final List<BuyerAcct> buyers = buyerAccts().values.toList();
          final List<FarmerAcct> farmers = farmerAccts().values.toList();
          final List<_MoneyExp> items = <_MoneyExp>[
            _MoneyExp(
              'pay',
              'teal',
              bi('ખેડૂત ચૂકવણી', 'Farmer payments'),
              pays.length,
              () => csvOf(
                <String>['date', 'farmer', 'type', 'mode', 'amount', 'note'],
                <List<Object?>>[for (final PayItem x in pays) <Object?>[dayKey(x.date), x.label, payKindLabel(x.kind), payModeLabel(x.mode), x.amt, x.note]],
              ),
            ),
            _MoneyExp(
              'wallet',
              'rose',
              bi('ખર્ચ અને આવક', 'Expenses and income'),
              exps.length,
              () => csvOf(
                <String>['date', 'direction', 'head', 'mode', 'amount', 'note'],
                <List<Object?>>[for (final ExpItem x in exps) <Object?>[dayKey(x.date), x.isIn ? 'in' : 'out', expCatLabel(x.cat), payModeLabel(x.mode), x.amt, x.note]],
              ),
            ),
            _MoneyExp(
              'cart',
              'teal',
              bi('વેચાણ અને રકમ મળી', 'Sales and receipts'),
              sales.length,
              () => csvOf(
                <String>['date', 'buyer', 'type', 'item', 'kg', 'bags', 'rate_per_20kg', 'amount', 'vehicle', 'bill_no', 'mode', 'note'],
                <List<Object?>>[
                  for (final SaleItem x in sales) <Object?>[dayKey(x.date), x.buyer, x.kind, x.src == 'raw' ? matLabel(x.item) : x.item, x.kg, x.bags, x.rate, x.amt, x.vehicle, x.bill, payModeLabel(x.mode), x.note],
                ],
              ),
            ),
            _MoneyExp(
              'grain',
              'amber',
              bi('પ્રોસેસ', 'Processing'),
              procs.length,
              () => csvOf(
                <String>['date', 'material', 'input_kg', 'grade', 'output_kg', 'bags', 'note'],
                <List<Object?>>[
                  for (final ProcBatch b in procs)
                    for (final ProcOut o in b.outs) <Object?>[dayKey(b.date), matLabel(b.material), b.inKg, o.grade, o.kg, o.bags, b.note],
                ],
              ),
            ),
            _MoneyExp(
              'warehouse',
              'orange',
              bi('સ્ટોક (હાલ)', 'Stock (now)'),
              stock.length,
              () => csvOf(
                <String>['item', 'kind', 'opening_kg', 'received_kg', 'processed_kg', 'sold_kg', 'in_stock_kg'],
                <List<Object?>>[for (final StockLine r in stock) <Object?>[r.raw ? matLabel(r.label) : r.label, r.raw ? 'raw' : 'finished', r.open, r.got, r.used, r.sold, r.left]],
              ),
            ),
            _MoneyExp(
              'users',
              'violet',
              bi('ખરીદનાર બાકી', 'Buyer balances'),
              buyers.length,
              () => csvOf(
                <String>['buyer', 'sold', 'received', 'opening', 'balance_to_get', 'last_entry'],
                <List<Object?>>[for (final BuyerAcct a in buyers) <Object?>[a.label, a.sales, a.recv, a.open, a.balance, a.last == null ? '' : dayKey(a.last!)]],
              ),
            ),
            _MoneyExp(
              'agri',
              'green',
              bi('ખેડૂત ખાતા (બાકી)', 'Farmer balances'),
              farmers.length,
              () => csvOf(
                <String>['farmer', 'purchase', 'opening', 'paid', 'advance', 'taken_back', 'balance_to_pay'],
                <List<Object?>>[for (final FarmerAcct a in farmers) <Object?>[a.label, a.purchase, a.open, a.paid, a.adv, a.recv, a.balance]],
              ),
            ),
          ];
          return <Widget>[
            ScreenHeader(bi('હિસાબ એક્સપોર્ટ', 'Accounts export'), sub: p.label),
            statusBanner(),
            RangeBar(sel: _sel, presets: const <int>[2, 3, 4, 5, 6], onChanged: (RangeSel r) => setState(() => _sel = r)),
            const SizedBox(height: 12),
            Text(bi('"CSV કૉપિ" દબાવો, પછી Excel / Google Sheets / WhatsApp માં પેસ્ટ કરો. સ્ટોક અને બાકીની યાદી હાલની સ્થિતિની હોય છે.', 'Tap "Copy CSV", then paste into Excel / Google Sheets / WhatsApp. Stock and balance lists are as of now.'), style: ts(12.5, c: Pal.muted, h: 1.4)),
            const SizedBox(height: 12),
            for (final _MoneyExp e in items)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Surface(
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    children: <Widget>[
                      IconChip(e.icon, tone: e.tone, size: 42),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(e.title, style: ts(14.5, w: FontWeight.w800)),
                            Text('${e.count} ${bi('લાઇન', 'rows')}', style: ts(12.5, c: Pal.muted)),
                          ],
                        ),
                      ),
                      Btn(bi('CSV કૉપિ', 'Copy CSV'), icon: 'copy', dense: true, kind: BtnKind.tonal, onTap: e.count == 0 ? null : () => copyText(e.csv(), msg: bi('${e.title} CSV કૉપિ થયું', '${e.title} CSV copied'))),
                    ],
                  ),
                ),
              ),
          ];
        },
      ),
    );
  }
}
