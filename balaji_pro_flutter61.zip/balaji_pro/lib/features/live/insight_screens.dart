import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/device.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/engine.dart';
import '../../data/insights.dart';
import '../../data/live_store.dart';
import '../../widgets/charts.dart';
import '../../widgets/common.dart';
import '../../widgets/page.dart';
import 'kit.dart';
import 'ui.dart';

String _dayLabel(int i, int n, DateTime d) {
  final int step = math.max(1, (n / 8).ceil());
  return (i % step == 0 || i == n - 1) ? '${d.day}' : '';
}

String _pct1(double v) => '${v.toStringAsFixed(2)}%';

// =================================================================== analytics
/// Whole-business numbers for any period, compared with the period before.
class AnalyticsScreen extends StatefulWidget {
  const AnalyticsScreen({super.key});

  @override
  State<AnalyticsScreen> createState() => _AnalyticsState();
}

class _AnalyticsState extends State<AnalyticsScreen> {
  RangeSel _sel = RangeSel(2);
  int _dim = 0;
  int _series = 0;
  static const List<Dim> _dims = <Dim>[Dim.farmer, Dim.village, Dim.broker, Dim.vehicle];

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 1300,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final bool pc = DeviceScope.isPc(ctx);
        final Period p = _sel.period;
        final Stats s = statsFor(p);
        final Stats q = statsFor(p.previous);
        final List<DayPoint> ds = dailySeries(p);
        final int n = ds.length;

        final List<Widget> tiles = <Widget>[
          MetricTile(
            label: bi('કાંટાનું વજન', 'Kanta weight'),
            value: kgShort(s.kantaKg),
            icon: 'scale',
            tone: 'blue',
            delta: deltaOf(s.kantaKg, q.kantaKg),
            sub: '${s.kantas} ${bi('એન્ટ્રી', 'entries')}',
            onTap: () => app.go('kanta'),
          ),
          MetricTile(
            label: bi('ચિઠ્ઠીનું વજન', 'Chit weight'),
            value: kgShort(s.chitKg),
            icon: 'receipt',
            tone: 'teal',
            delta: deltaOf(s.chitKg, q.chitKg),
            sub: '${s.chits} ${bi('ચિઠ્ઠી', 'chits')}',
            onTap: () => app.go('chithi'),
          ),
          MetricTile(
            label: bi('ગાડી', 'Vehicles'),
            value: '${s.trips}',
            icon: 'truck',
            tone: 'violet',
            delta: deltaOf(s.trips.toDouble(), q.trips.toDouble()),
            sub: '${bi('સરેરાશ', 'avg')} ${kgShort(s.avgLoad)}',
            onTap: () => app.go('mel'),
          ),
          MetricTile(
            label: bi('ઘટ / વધ (મેળ થયેલ)', 'Loss / gain (matched)'),
            value: _pct1(s.ghatPct),
            icon: 'cmp',
            tone: s.compared == 0 ? 'slate' : (s.ghat.abs() <= live.cfg.tol(s.mChit) ? 'green' : 'rose'),
            sub: '${sk(s.ghat)} KG · ${s.compared} ${bi('ગાડી', 'trips')}',
          ),
          MetricTile(
            label: bi('બરાબર મેળ', 'Matched OK'),
            value: s.compared == 0 ? '—' : '${(s.okTrips / math.max(1, s.okTrips + s.diffTrips) * 100).round()}%',
            icon: 'check',
            tone: 'green',
            sub: '${s.okTrips} ${bi('બરાબર', 'ok')} · ${s.diffTrips} ${bi('ફરક', 'differ')}',
          ),
          MetricTile(
            label: bi('તપાસ માંગે છે', 'Needs checking'),
            value: '${s.problems}',
            icon: 'warn',
            tone: s.problems == 0 ? 'green' : 'rose',
            delta: deltaOf(s.problems.toDouble(), q.problems.toDouble()),
            upIsGood: false,
            onTap: () => app.go('alerts'),
          ),
          MetricTile(
            label: bi('કાંટો બાકી', 'No kanta'),
            value: '${s.noKanta}',
            icon: 'scale',
            tone: s.noKanta == 0 ? 'green' : 'amber',
            sub: '${s.noChit} ${bi('ચિઠ્ઠી વગર', 'without chit')}',
            onTap: () => app.go('missing_kanta'),
          ),
          MetricTile(
            label: bi('માલ બેગ', 'Maal bags'),
            value: '${s.bagsIn + s.bagsOut}',
            icon: 'bag',
            tone: 'amber',
            sub: '${bi('અંદર', 'in')} ${s.bagsIn} · ${bi('બહાર', 'out')} ${s.bagsOut}',
            onTap: () => app.go('maal'),
          ),
        ];

        // ---- daily bars
        final List<double> vals = <double>[for (final DayPoint d in ds) (_series == 0 ? d.kantaKg : d.chitKg) / 1000];
        int hi = 0;
        for (int i = 1; i < vals.length; i++) {
          if (vals[i] > vals[hi]) hi = i;
        }
        final Widget chart = Panel(
          title: bi('દિવસ મુજબ વજન (ટન)', 'Weight per day (tons)'),
          sub: p.label,
          action: Seg(
            dense: true,
            labels: <String>[bi('કાંટો', 'Kanta'), bi('ચિઠ્ઠી', 'Chit')],
            index: _series,
            onChanged: (int i) => setState(() => _series = i),
          ),
          child: BarChartX(
            values: vals,
            labels: <String>[for (int i = 0; i < n; i++) _dayLabel(i, n, ds[i].day)],
            color: _series == 0 ? Pal.info : Pal.brand,
            highlight: vals.isEmpty ? null : hi,
            axisFmt: (double v) => v.toStringAsFixed(v < 10 ? 1 : 0),
            valueFmt: (double v) => '${v.toStringAsFixed(1)} T',
            height: 220,
          ),
        );

        // ---- commodity donut
        final List<KV> cm = commoditySplit(p);
        double ctotal = 0;
        for (final KV k in cm) {
          ctotal += k.v;
        }
        final List<Color> cc = chartColors();
        final List<DonutPart> parts = <DonutPart>[];
        double other = 0;
        for (int i = 0; i < cm.length; i++) {
          if (i < 5) {
            parts.add(DonutPart(cm[i].label, cm[i].v, cc[i % cc.length]));
          } else {
            other += cm[i].v;
          }
        }
        if (other > 0) parts.add(DonutPart(bi('બીજા', 'Others'), other, Pal.faint));
        final Widget donut = Panel(
          title: bi('માલ પ્રમાણે', 'By material'),
          child: cm.isEmpty
              ? EmptyBox(icon: 'grain', title: bi('ડેટા નથી', 'No data'))
              : Column(
                  children: <Widget>[
                    DonutX(parts: parts, center: kgShort(ctotal), sub: bi('કુલ', 'total'), size: 160, thickness: 18),
                    const SizedBox(height: 14),
                    for (final DonutPart d in parts)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: Row(
                          children: <Widget>[
                            Expanded(child: LegendDot(d.color, d.label)),
                            Text('${kgShort(d.value)}  ·  ${ctotal > 0 ? (d.value / ctotal * 100).round() : 0}%', style: ts(12.5, w: FontWeight.w800, tab: true)),
                          ],
                        ),
                      ),
                  ],
                ),
        );

        // ---- top list
        final Dim dim = _dims[_dim];
        final List<GroupRow> rows = topBy(dim, p);
        double tk = 0;
        for (final GroupRow r in rows) {
          tk += r.kg;
        }
        final Widget top = Panel(
          title: bi('સૌથી વધુ માલ', 'Biggest suppliers'),
          action: Seg(
            dense: true,
            labels: <String>[for (final Dim d in _dims) dimName(d)],
            index: _dim,
            onChanged: (int i) => setState(() => _dim = i),
          ),
          child: rows.isEmpty
              ? EmptyBox(icon: 'bar', title: bi('ડેટા નથી', 'No data'))
              : RankList(<RankItem>[
                  for (final GroupRow r in rows.take(8))
                    RankItem(
                      r.label.isEmpty ? '—' : r.label,
                      r.kg,
                      kgShort(r.kg),
                      Pal.brand,
                      sub: '${r.trips.length} ${bi('ગાડી', 'trips')} · ${tk > 0 ? (r.kg / tk * 100).toStringAsFixed(1) : '0'}%',
                      onTap: () => openParty(PartyRef(dim, r.key, r.label)),
                    ),
                ]),
        );

        return <Widget>[
          ScreenHeader(bi('વિશ્લેષણ', 'Analytics'), sub: '${p.label} · ${bi('સરખામણી: અગાઉના', 'vs previous')} ${p.days} ${bi('દિવસ', 'days')}', actions: <Widget>[refreshBtn()]),
          statusBanner(),
          RangeBar(sel: _sel, onChanged: (RangeSel r) => setState(() => _sel = r)),
          const SizedBox(height: 14),
          metricGrid(ctx, tiles),
          const SizedBox(height: 16),
          SplitPane(flex: const <int>[3, 2], children: <Widget>[chart, donut]),
          const SizedBox(height: 16),
          top,
          if (!pc) const SizedBox(height: 8),
        ];
      },
    );
  }
}

// ===================================================================== compare
class CompareScreen extends StatefulWidget {
  const CompareScreen({super.key});

  @override
  State<CompareScreen> createState() => _CompareState();
}

class _CompareState extends State<CompareScreen> {
  RangeSel _a = RangeSel(2);
  late RangeSel _b = _before(_a);

  RangeSel _before(RangeSel a) {
    final Period pp = a.period.previous;
    final RangeSel r = RangeSel(6);
    r.cFrom = pp.from;
    r.cTo = pp.lastDay;
    return r;
  }

  void _quick(int a, int b) {
    setState(() {
      _a = RangeSel(a);
      _b = RangeSel(b);
    });
  }

  Widget _row(String label, String a, String b, Delta? d, bool upIsGood) {
    String tone = 'slate';
    if (d != null && !d.flat) tone = (d.up == upIsGood) ? 'green' : 'rose';
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 9),
      child: Row(
        children: <Widget>[
          Expanded(flex: 4, child: Text(label, style: ts(13.5, w: FontWeight.w700))),
          Expanded(flex: 3, child: Text(a, textAlign: TextAlign.right, style: ts(13.5, w: FontWeight.w800, tab: true))),
          Expanded(flex: 3, child: Text(b, textAlign: TextAlign.right, style: ts(13.5, c: Pal.muted, w: FontWeight.w700, tab: true))),
          Expanded(flex: 3, child: Align(alignment: Alignment.centerRight, child: d == null ? Text('—', style: ts(13, c: Pal.faint)) : Pill(d.text, tone: tone, small: true))),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 1100,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period pa = _a.period;
        final Period pb = _b.period;
        final Stats sa = statsFor(pa);
        final Stats sb = statsFor(pb);

        Widget metric(String label, double a, double b, String Function(double) f, {bool upIsGood = true}) {
          return _row(label, f(a), f(b), deltaOf(a, b), upIsGood);
        }

        String kgf(double v) => kgShort(v);
        String nf(double v) => '${v.round()}';

        final Widget table = Panel(
          title: bi('આંકડા સરખામણી', 'Numbers side by side'),
          child: Column(
            children: <Widget>[
              Row(
                children: <Widget>[
                  Expanded(flex: 4, child: const SizedBox()),
                  Expanded(flex: 3, child: Text(pa.label, textAlign: TextAlign.right, style: ts(11.5, w: FontWeight.w800, c: Pal.brand))),
                  Expanded(flex: 3, child: Text(pb.label, textAlign: TextAlign.right, style: ts(11.5, w: FontWeight.w800, c: Pal.muted))),
                  Expanded(flex: 3, child: Text(bi('ફેરફાર', 'Change'), textAlign: TextAlign.right, style: ts(11.5, w: FontWeight.w800, c: Pal.muted))),
                ],
              ),
              divider(),
              metric(bi('કાંટાનું વજન', 'Kanta weight'), sa.kantaKg, sb.kantaKg, kgf),
              divider(),
              metric(bi('ચિઠ્ઠીનું વજન', 'Chit weight'), sa.chitKg, sb.chitKg, kgf),
              divider(),
              metric(bi('ગાડી', 'Vehicles'), sa.trips.toDouble(), sb.trips.toDouble(), nf),
              divider(),
              metric(bi('સરેરાશ લોડ', 'Average load'), sa.avgLoad, sb.avgLoad, kgf),
              divider(),
              metric(bi('ચિઠ્ઠી', 'Chits'), sa.chits.toDouble(), sb.chits.toDouble(), nf),
              divider(),
              _row(bi('ઘટ %', 'Loss %'), _pct1(sa.ghatPct), _pct1(sb.ghatPct), deltaOf(sa.ghatPct.abs(), sb.ghatPct.abs()), false),
              divider(),
              metric(bi('ફરક વાળી ગાડી', 'Trips with difference'), sa.diffTrips.toDouble(), sb.diffTrips.toDouble(), nf, upIsGood: false),
              divider(),
              metric(bi('તપાસ માંગે છે', 'Needs checking'), sa.problems.toDouble(), sb.problems.toDouble(), nf, upIsGood: false),
              divider(),
              metric(bi('માલ બેગ', 'Maal bags'), (sa.bagsIn + sa.bagsOut).toDouble(), (sb.bagsIn + sb.bagsOut).toDouble(), nf),
            ],
          ),
        );

        final List<DayPoint> da = dailySeries(pa);
        final List<DayPoint> db = dailySeries(pb);
        final int m = math.min(da.length, db.length);
        Widget chart = const SizedBox.shrink();
        if (m >= 2) {
          chart = Panel(
            title: bi('દિવસ મુજબ કાંટો (ટન)', 'Kanta per day (tons)'),
            sub: bi('દિવસ 1 થી $m', 'day 1 to $m'),
            child: Column(
              children: <Widget>[
                LineChartX(
                  series: <LineSeries>[
                    LineSeries(pa.label, <double>[for (int i = 0; i < m; i++) da[i].kantaKg / 1000], Pal.brand),
                    LineSeries(pb.label, <double>[for (int i = 0; i < m; i++) db[i].kantaKg / 1000], Pal.amber),
                  ],
                  labels: <String>[for (int i = 0; i < m; i++) _dayLabel(i, m, DateTime(2000, 1, i + 1))],
                  axisFmt: (double v) => v.toStringAsFixed(v < 10 ? 1 : 0),
                  height: 220,
                ),
                const SizedBox(height: 8),
                Wrap(spacing: 16, runSpacing: 6, children: <Widget>[LegendDot(Pal.brand, pa.label), LegendDot(Pal.amber, pb.label)]),
              ],
            ),
          );
        }

        return <Widget>[
          ScreenHeader(bi('સરખામણી', 'Compare'), sub: '${pa.label}  vs  ${pb.label}', actions: <Widget>[refreshBtn()]),
          statusBanner(),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <Widget>[
              Btn(bi('આજ vs ગઈકાલ', 'Today vs yesterday'), dense: true, kind: BtnKind.tonal, onTap: () => _quick(0, 1)),
              Btn(bi('7 દિવસ vs અગાઉના 7', '7 days vs previous 7'), dense: true, kind: BtnKind.tonal, onTap: () => setState(() {
                    _a = RangeSel(2);
                    _b = _before(_a);
                  })),
              Btn(bi('30 દિવસ vs અગાઉના 30', '30 days vs previous 30'), dense: true, kind: BtnKind.tonal, onTap: () => setState(() {
                    _a = RangeSel(3);
                    _b = _before(_a);
                  })),
              Btn(bi('આ મહિનો vs ગયો', 'This vs last month'), dense: true, kind: BtnKind.tonal, onTap: () => _quick(4, 5)),
            ],
          ),
          const SizedBox(height: 14),
          Text('A', style: ts(12, w: FontWeight.w800, c: Pal.brand)),
          const SizedBox(height: 6),
          RangeBar(sel: _a, onChanged: (RangeSel r) => setState(() => _a = r)),
          const SizedBox(height: 10),
          Text('B', style: ts(12, w: FontWeight.w800, c: Pal.muted)),
          const SizedBox(height: 6),
          RangeBar(sel: _b, onChanged: (RangeSel r) => setState(() => _b = r)),
          const SizedBox(height: 16),
          table,
          const SizedBox(height: 16),
          chart,
        ];
      },
    );
  }
}

// ===================================================================== hourly
class HourlyScreen extends StatefulWidget {
  const HourlyScreen({super.key});

  @override
  State<HourlyScreen> createState() => _HourlyState();
}

class _HourlyState extends State<HourlyScreen> {
  RangeSel _sel = RangeSel(3);
  int _metric = 0;

  String _hr(int h) => '${pad2(h)}:00 - ${pad2((h + 1) % 24)}:00';

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 1200,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = _sel.period;
        final Hourly h = hourlyOf(p, _metric);
        final String unit = _metric == 2 ? 'KG' : (_metric == 1 ? bi('ચિઠ્ઠી', 'chits') : bi('ગાડી', 'vehicles'));
        String fmtv(double v) => _metric == 2 ? kgShort(v) : '${v.round()}';

        final List<int> order = List<int>.generate(24, (int i) => i);
        order.sort((int a, int b) => h.byHour[b].compareTo(h.byHour[a]));
        final List<int> busy = order.where((int i) => h.byHour[i] > 0).take(3).toList();

        final List<String> dayN = <String>[for (int i = 0; i < 7; i++) L.gu ? kDayGu[i] : kDayEn[i]];
        final List<String> hourN = <String>[for (int i = 0; i < 24; i++) i % 3 == 0 ? '$i' : ''];

        final Widget hourBars = Panel(
          title: bi('કલાક પ્રમાણે', 'By hour of day'),
          child: BarChartX(
            values: h.byHour,
            labels: hourN,
            color: Pal.info,
            highlight: h.total > 0 ? h.peakHour : null,
            axisFmt: (double v) => _metric == 2 ? (v / 1000).toStringAsFixed(0) : v.toStringAsFixed(0),
            valueFmt: (double v) => fmtv(v),
            height: 220,
          ),
        );
        final Widget wd = Panel(
          title: bi('વાર પ્રમાણે', 'By weekday'),
          child: BarChartX(
            values: h.byWeekday,
            labels: dayN,
            color: Pal.brand,
            highlight: h.total > 0 ? h.peakDay : null,
            axisFmt: (double v) => _metric == 2 ? (v / 1000).toStringAsFixed(0) : v.toStringAsFixed(0),
            valueFmt: (double v) => fmtv(v),
            height: 220,
          ),
        );
        final Widget heat = Panel(
          title: bi('ભીડ નકશો', 'Busy map'),
          sub: bi('વાર × કલાક', 'weekday × hour'),
          child: HeatGrid(data: h.grid, rowLabels: dayN, colLabels: hourN, color: Pal.brand, height: 250),
        );

        return <Widget>[
          ScreenHeader(bi('સમય પ્રમાણે ભીડ', 'Peak hours'), sub: p.label, actions: <Widget>[refreshBtn()]),
          statusBanner(),
          RangeBar(sel: _sel, onChanged: (RangeSel r) => setState(() => _sel = r), presets: const <int>[2, 3, 4, 5, 6]),
          const SizedBox(height: 10),
          Seg(
            dense: true,
            labels: <String>[bi('કાંટો એન્ટ્રી', 'Kanta entries'), bi('ચિઠ્ઠી', 'Chits'), bi('કાંટો KG', 'Kanta KG')],
            index: _metric,
            onChanged: (int i) => setState(() => _metric = i),
          ),
          const SizedBox(height: 14),
          metricGrid(ctx, <Widget>[
            MetricTile(label: bi('સૌથી વ્યસ્ત કલાક', 'Busiest hour'), value: h.total > 0 ? _hr(h.peakHour) : '—', icon: 'clock', tone: 'amber', sub: h.total > 0 ? '${fmtv(h.byHour[h.peakHour])} $unit' : null),
            MetricTile(label: bi('સૌથી વ્યસ્ત વાર', 'Busiest weekday'), value: h.total > 0 ? dayN[h.peakDay] : '—', icon: 'cal', tone: 'violet', sub: h.total > 0 ? '${fmtv(h.byWeekday[h.peakDay])} $unit' : null),
            MetricTile(label: bi('કુલ', 'Total'), value: fmtv(h.total), icon: 'bar', tone: 'blue', sub: unit),
            MetricTile(
              label: bi('ટોપ 3 કલાક', 'Top 3 hours'),
              value: busy.isEmpty ? '—' : busy.map((int i) => '$i').join(' · '),
              icon: 'timeline',
              tone: 'teal',
            ),
          ]),
          const SizedBox(height: 16),
          SplitPane(children: <Widget>[hourBars, wd]),
          const SizedBox(height: 16),
          heat,
        ];
      },
    );
  }
}

// ================================================================= turnaround
class TurnaroundScreen extends StatefulWidget {
  const TurnaroundScreen({super.key});

  @override
  State<TurnaroundScreen> createState() => _TurnaroundState();
}

class _TurnaroundState extends State<TurnaroundScreen> {
  RangeSel _sel = RangeSel(3);
  int _n = 15;

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 1100,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = _sel.period;
        final List<Turn> tl = turnaround(p);
        final List<double> hs = <double>[for (final Turn t in tl) t.hours];
        double sum = 0;
        double mx = 0;
        for (final double v in hs) {
          sum += v;
          if (v > mx) mx = v;
        }
        final double avg = hs.isEmpty ? 0 : sum / hs.length;

        final List<String> bl = <String>['< 2 ${bi('કલાક', 'h')}', '2 - 6', '6 - 12', '12 - 24', '> 24'];
        final List<int> bc = List<int>.filled(5, 0);
        for (final double v in hs) {
          if (v < 2) {
            bc[0]++;
          } else if (v < 6) {
            bc[1]++;
          } else if (v < 12) {
            bc[2]++;
          } else if (v < 24) {
            bc[3]++;
          } else {
            bc[4]++;
          }
        }
        final List<Color> bcol = <Color>[Pal.ok, Pal.ok, Pal.warn, Pal.warn, Pal.bad];

        // slowest vehicles on average
        final Map<String, List<double>> byV = <String, List<double>>{};
        final Map<String, String> vName = <String, String>{};
        for (final Turn t in tl) {
          byV.putIfAbsent(t.trip.vk, () => <double>[]).add(t.hours);
          vName[t.trip.vk] = t.trip.vehicle;
        }
        final List<MapEntry<String, double>> vAvg = <MapEntry<String, double>>[];
        byV.forEach((String k, List<double> l) {
          if (l.length >= 2) {
            double a = 0;
            for (final double x in l) {
              a += x;
            }
            vAvg.add(MapEntry<String, double>(k, a / l.length));
          }
        });
        vAvg.sort((MapEntry<String, double> a, MapEntry<String, double> b) => b.value.compareTo(a.value));

        final List<Turn> slow = List<Turn>.from(tl)..sort((Turn a, Turn b) => b.hours.compareTo(a.hours));

        final Widget dist = Panel(
          title: bi('કેટલા કલાકમાં કાંટે પહોંચ્યા', 'Hours from last chit to kanta'),
          child: tl.isEmpty
              ? EmptyBox(icon: 'clock', title: bi('ડેટા નથી', 'No data'))
              : RankList(<RankItem>[
                  for (int i = 0; i < 5; i++) RankItem(bl[i], bc[i].toDouble(), '${bc[i]}', bcol[i], sub: '${(bc[i] / tl.length * 100).round()}%'),
                ]),
        );
        final Widget vehicles = Panel(
          title: bi('સૌથી ધીમી ગાડી (સરેરાશ)', 'Slowest vehicles (average)'),
          child: vAvg.isEmpty
              ? EmptyBox(icon: 'truck', title: bi('ઓછામાં ઓછા 2 ફેરા જોઈએ', 'Needs at least 2 trips'))
              : RankList(<RankItem>[
                  for (final MapEntry<String, double> e in vAvg.take(8))
                    RankItem(vtxt(vName[e.key] ?? ''), e.value, hoursText(e.value), e.value > 12 ? Pal.bad : Pal.warn,
                        sub: '${byV[e.key]!.length} ${bi('ફેરા', 'trips')}', onTap: () => openParty(PartyRef(Dim.vehicle, e.key, vName[e.key] ?? ''))),
                ]),
        );
        final Widget list = Panel(
          title: bi('સૌથી વધુ સમય લાગ્યો', 'Took the longest'),
          child: slow.isEmpty
              ? EmptyBox(icon: 'clock', title: bi('ડેટા નથી', 'No data'))
              : Column(
                  children: <Widget>[
                    for (final Turn t in slow.take(_n))
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Surface(
                          padding: const EdgeInsets.all(12),
                          color: Pal.surface2,
                          shadow: false,
                          onTap: () => showTripDetail(ctx, t.trip),
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Text(vtxt(t.trip.vehicle), style: ts(14, w: FontWeight.w800)),
                                    Text('${t.trip.farmers} · ${whenTxt(t.trip.at)}', maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12, c: Pal.muted)),
                                  ],
                                ),
                              ),
                              Pill(hoursText(t.hours), tone: t.hours > 24 ? 'rose' : (t.hours > 12 ? 'amber' : 'green')),
                            ],
                          ),
                        ),
                      ),
                    if (_n < slow.length) Btn(bi('વધુ બતાવો', 'Show more'), kind: BtnKind.tonal, expand: true, onTap: () => setState(() => _n += 15)),
                  ],
                ),
        );

        return <Widget>[
          ScreenHeader(bi('ગાડીનો સમય', 'Vehicle turnaround'), sub: p.label, actions: <Widget>[refreshBtn()]),
          statusBanner(),
          RangeBar(sel: _sel, onChanged: (RangeSel r) => setState(() => _sel = r), presets: const <int>[2, 3, 4, 5, 6]),
          const SizedBox(height: 14),
          metricGrid(ctx, <Widget>[
            MetricTile(label: bi('સરેરાશ સમય', 'Average'), value: tl.isEmpty ? '—' : hoursText(avg), icon: 'clock', tone: 'blue'),
            MetricTile(label: bi('મધ્યમ (median)', 'Median'), value: tl.isEmpty ? '—' : hoursText(median(hs)), icon: 'timeline', tone: 'teal'),
            MetricTile(label: bi('સૌથી વધુ', 'Longest'), value: tl.isEmpty ? '—' : hoursText(mx), icon: 'alarm', tone: mx > 24 ? 'rose' : 'amber'),
            MetricTile(label: bi('ગાડી', 'Trips'), value: '${tl.length}', icon: 'truck', tone: 'violet'),
          ]),
          const SizedBox(height: 16),
          SplitPane(children: <Widget>[dist, vehicles]),
          const SizedBox(height: 16),
          list,
        ];
      },
    );
  }
}

// ======================================================================== risk
class RiskScreen extends StatefulWidget {
  const RiskScreen({super.key});

  @override
  State<RiskScreen> createState() => _RiskState();
}

class _RiskState extends State<RiskScreen> {
  RangeSel _sel = RangeSel(3);
  int _dim = 0;
  int _min = 1;
  int _n = 25;
  static const List<Dim> _dims = <Dim>[Dim.vehicle, Dim.majur, Dim.farmer, Dim.broker, Dim.village];
  static const List<int> _mins = <int>[2, 3, 5];

  Color _col(String band) => band == 'rose' ? Pal.bad : (band == 'amber' ? Pal.warn : Pal.ok);

  void _open(BuildContext ctx, Risk r) {
    openPanel(
      ctx,
      title: r.label.isEmpty ? '—' : r.label,
      sub: '${dimName(r.dim)} · ${bi('જોખમ', 'risk')} ${r.score}/100',
      width: 520,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Center(child: ScoreRing(value: r.score / 100, center: '${r.score}', sub: '/100', color: _col(r.band), size: 110)),
          const SizedBox(height: 14),
          InfoRow(bi('ગાડી / ફેરા', 'Trips'), '${r.trips}'),
          InfoRow(bi('કુલ વજન', 'Total weight'), '${grp(r.kg)} KG'),
          InfoRow(bi('સરેરાશ ઘટ', 'Average loss'), r.compared > 0 ? _pct1(r.lossPct) : '—', bold: true, color: r.lossPct > live.cfg.pct ? Pal.bad : null),
          InfoRow(bi('ફરક વાળી ગાડી', 'Trips that differ'), '${r.diffTrips}'),
          InfoRow(bi('કાંટા વગરની ગાડી', 'Trips without kanta'), '${r.noKanta}'),
          InfoRow(bi('ફોટા વગરની ચિઠ્ઠી', 'Chits without photo'), '${r.noPhoto}'),
          if (r.chits > 0) InfoRow(bi('ગોળ વજન', 'Round weights'), '${r.round} / ${r.chits}'),
          const SizedBox(height: 12),
          Btn(bi('પ્રોફાઇલ ખોલો', 'Open profile'), icon: 'user', onTap: () {
            Navigator.of(ctx).pop();
            openParty(PartyRef(r.dim, r.key, r.label));
          }),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 1000,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = _sel.period;
        final List<Risk> all = riskOf(_dims[_dim], p, minTrips: _mins[_min]);
        int hi = 0;
        int mid = 0;
        for (final Risk r in all) {
          if (r.score >= 50) {
            hi++;
          } else if (r.score >= 25) {
            mid++;
          }
        }
        return <Widget>[
          ScreenHeader(bi('જોખમ સ્કોર', 'Risk score'), sub: '${p.label} · ${bi('0-100, વધુ = વધુ તપાસ', '0-100, higher = check more')}', actions: <Widget>[refreshBtn()]),
          statusBanner(),
          RangeBar(sel: _sel, onChanged: (RangeSel r) => setState(() => _sel = r), presets: const <int>[2, 3, 4, 5, 6]),
          const SizedBox(height: 10),
          Wrap(
            spacing: 12,
            runSpacing: 10,
            children: <Widget>[
              Seg(dense: true, labels: <String>[for (final Dim d in _dims) dimName(d)], index: _dim, onChanged: (int i) => setState(() {
                    _dim = i;
                    _n = 25;
                  })),
              Seg(dense: true, labels: <String>[for (final int m in _mins) '$m+ ${bi('ફેરા', 'trips')}'], index: _min, onChanged: (int i) => setState(() => _min = i)),
            ],
          ),
          const SizedBox(height: 14),
          metricGrid(ctx, <Widget>[
            MetricTile(label: bi('ઊંચું જોખમ', 'High risk'), value: '$hi', icon: 'warn', tone: hi == 0 ? 'green' : 'rose'),
            MetricTile(label: bi('મધ્યમ', 'Medium'), value: '$mid', icon: 'flag', tone: 'amber'),
            MetricTile(label: bi('બરાબર', 'Low'), value: '${all.length - hi - mid}', icon: 'check', tone: 'green'),
            MetricTile(label: bi('તપાસેલા', 'Checked'), value: '${all.length}', icon: 'rank', tone: 'blue'),
          ]),
          const SizedBox(height: 14),
          if (all.isEmpty)
            EmptyBox(icon: 'rank', title: bi('આટલા ફેરા વાળું કોઈ નથી', 'Nobody with that many trips'))
          else
            for (final Risk r in all.take(_n))
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Surface(
                  padding: const EdgeInsets.all(12),
                  onTap: () => _open(ctx, r),
                  child: Row(
                    children: <Widget>[
                      ScoreRing(value: r.score / 100, center: '${r.score}', color: _col(r.band), size: 58),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(r.label.isEmpty ? '—' : r.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14.5, w: FontWeight.w800)),
                            const SizedBox(height: 2),
                            Text('${r.trips} ${bi('ફેરા', 'trips')} · ${kgShort(r.kg)}', style: ts(12.5, c: Pal.muted)),
                            if (r.why.isNotEmpty) ...<Widget>[
                              const SizedBox(height: 6),
                              Wrap(spacing: 6, runSpacing: 4, children: <Widget>[for (final String w in r.why.take(3)) Pill(w, tone: r.band, small: true)]),
                            ],
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          if (_n < all.length) Btn(bi('વધુ બતાવો (${all.length - _n})', 'Show more (${all.length - _n})'), kind: BtnKind.tonal, expand: true, onTap: () => setState(() => _n += 25)),
        ];
      },
    );
  }
}

// ===================================================================== leaders
class LeadersScreen extends StatefulWidget {
  const LeadersScreen({super.key});

  @override
  State<LeadersScreen> createState() => _LeadersState();
}

class _LeadersState extends State<LeadersScreen> {
  RangeSel _sel = RangeSel(3);
  int _dim = 0;
  int _sort = 0;
  int _n = 30;
  static const List<Dim> _dims = <Dim>[Dim.farmer, Dim.village, Dim.broker, Dim.vehicle, Dim.majur];

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 1000,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = _sel.period;
        final Dim dim = _dims[_dim];
        final List<GroupRow> rows = topBy(dim, p);
        if (_sort == 1) {
          rows.sort((GroupRow a, GroupRow b) => b.trips.length.compareTo(a.trips.length));
        } else if (_sort == 2) {
          rows.sort((GroupRow a, GroupRow b) => a.ghatPct.compareTo(b.ghatPct));
        }
        double total = 0;
        for (final GroupRow r in rows) {
          total += r.kg;
        }
        final List<GroupRow> bySize = List<GroupRow>.from(rows)..sort((GroupRow a, GroupRow b) => b.kg.compareTo(a.kg));
        double top10 = 0;
        for (int i = 0; i < bySize.length && i < 10; i++) {
          top10 += bySize[i].kg;
        }
        int cover80 = 0;
        double acc = 0;
        for (final GroupRow r in bySize) {
          acc += r.kg;
          cover80++;
          if (total > 0 && acc >= total * 0.8) break;
        }
        double run = 0;
        final List<double> cum = <double>[];
        for (final GroupRow r in rows) {
          run += r.kg;
          cum.add(total > 0 ? run / total * 100 : 0);
        }

        return <Widget>[
          ScreenHeader(bi('ટોપ પાર્ટી', 'Top parties'), sub: '${p.label} · ${rows.length}', actions: <Widget>[refreshBtn()]),
          statusBanner(),
          RangeBar(sel: _sel, onChanged: (RangeSel r) => setState(() => _sel = r), presets: const <int>[2, 3, 4, 5, 6]),
          const SizedBox(height: 10),
          Wrap(
            spacing: 12,
            runSpacing: 10,
            children: <Widget>[
              Seg(dense: true, labels: <String>[for (final Dim d in _dims) dimName(d)], index: _dim, onChanged: (int i) => setState(() {
                    _dim = i;
                    _n = 30;
                  })),
              Seg(dense: true, labels: <String>[bi('વજન', 'Weight'), bi('ફેરા', 'Trips'), bi('ઘટ', 'Loss')], index: _sort, onChanged: (int i) => setState(() => _sort = i)),
            ],
          ),
          const SizedBox(height: 14),
          metricGrid(ctx, <Widget>[
            MetricTile(label: bi('કુલ વજન', 'Total'), value: kgShort(total), icon: 'bar', tone: 'teal'),
            MetricTile(label: bi('ટોપ 10 નો ભાગ', 'Top 10 share'), value: total > 0 ? '${(top10 / total * 100).round()}%' : '—', icon: 'pie', tone: 'violet'),
            MetricTile(label: bi('80% માલ આપનાર', 'Give 80% of weight'), value: '$cover80', icon: 'users', tone: 'blue', sub: bi('${rows.length} માંથી', 'of ${rows.length}')),
            MetricTile(label: dimName(dim), value: '${rows.length}', icon: dimIcon(dim), tone: 'amber'),
          ]),
          const SizedBox(height: 14),
          if (rows.isEmpty)
            EmptyBox(icon: 'bar', title: bi('ડેટા નથી', 'No data'))
          else
            for (int i = 0; i < rows.length && i < _n; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Surface(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
                  onTap: () => openParty(PartyRef(dim, rows[i].key, rows[i].label)),
                  child: Row(
                    children: <Widget>[
                      Container(
                        width: 32,
                        height: 32,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(color: i < 3 ? Pal.tone('amber').bg : Pal.soft, shape: BoxShape.circle),
                        child: Text('${i + 1}', style: ts(13, w: FontWeight.w800, c: i < 3 ? Pal.tone('amber').fg : Pal.brand)),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(rows[i].label.isEmpty ? '—' : rows[i].label, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14.5, w: FontWeight.w800)),
                            Text('${rows[i].trips.length} ${bi('ફેરા', 'trips')} · ${total > 0 ? (rows[i].kg / total * 100).toStringAsFixed(1) : '0'}% · ${bi('કુલ', 'cum')} ${cum[i].round()}%',
                                style: ts(12, c: Pal.muted)),
                          ],
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: <Widget>[
                          Text(kgShort(rows[i].kg), style: ts(14.5, w: FontWeight.w800, tab: true)),
                          if (rows[i].mtrips.isNotEmpty) Text(_pct1(rows[i].ghatPct), style: ts(11.5, w: FontWeight.w700, c: rows[i].ghatPct < -live.cfg.pct ? Pal.bad : Pal.muted)),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
          if (_n < rows.length) Btn(bi('વધુ બતાવો (${rows.length - _n})', 'Show more (${rows.length - _n})'), kind: BtnKind.tonal, expand: true, onTap: () => setState(() => _n += 30)),
        ];
      },
    );
  }
}

// ================================================================= ghat trend
class GhatTrendScreen extends StatefulWidget {
  const GhatTrendScreen({super.key});

  @override
  State<GhatTrendScreen> createState() => _GhatTrendState();
}

class _GhatTrendState extends State<GhatTrendScreen> {
  RangeSel _sel = RangeSel(3);

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 1100,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = _sel.period;
        final List<DayPoint> ds = dailySeries(p);
        final List<WeekPoint> ws = weeklyOf(ds);
        final Stats s = statsFor(p);
        final double lim = live.cfg.pct;

        // 3-day moving average of |loss %|, only days that had comparisons
        final int n = ds.length;
        final List<double> ma = <double>[];
        for (int i = 0; i < n; i++) {
          double a = 0;
          double b = 0;
          for (int j = math.max(0, i - 2); j <= i; j++) {
            a += ds[j].mChit;
            b += ds[j].mKanta;
          }
          ma.add(a > 0 ? ((a - b).abs() / a * 100) : 0.0);
        }
        int above = 0;
        DayPoint? worst;
        for (final DayPoint d in ds) {
          if (d.mChit <= 0) continue;
          if (d.ghatPct.abs() > lim) above++;
          if (worst == null || d.ghatPct.abs() > worst.ghatPct.abs()) worst = d;
        }

        final Widget chart = Panel(
          title: bi('ઘટ % (3 દિવસની સરેરાશ)', 'Loss % (3-day average)'),
          sub: '${bi('માન્ય મર્યાદા', 'allowed')} ${lim.toStringAsFixed(2)}%',
          child: n < 3
              ? EmptyBox(icon: 'line', title: bi('ઓછામાં ઓછા 3 દિવસ પસંદ કરો', 'Pick at least 3 days'))
              : Column(
                  children: <Widget>[
                    LineChartX(
                      series: <LineSeries>[
                        LineSeries(bi('ઘટ %', 'Loss %'), ma, Pal.bad),
                        LineSeries(bi('મર્યાદા', 'Limit'), List<double>.filled(n, lim), Pal.faint),
                      ],
                      labels: <String>[for (int i = 0; i < n; i++) _dayLabel(i, n, ds[i].day)],
                      axisFmt: (double v) => v.toStringAsFixed(2),
                      height: 230,
                    ),
                    const SizedBox(height: 8),
                    Wrap(spacing: 16, runSpacing: 6, children: <Widget>[LegendDot(Pal.bad, bi('ઘટ %', 'Loss %')), LegendDot(Pal.faint, bi('મર્યાદા', 'Limit'))]),
                  ],
                ),
        );

        final Widget weeks = Panel(
          title: bi('અઠવાડિયા પ્રમાણે', 'Week by week'),
          child: ws.isEmpty
              ? EmptyBox(icon: 'cal', title: bi('ડેટા નથી', 'No data'))
              : Column(
                  children: <Widget>[
                    for (final WeekPoint w in ws.reversed)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 7),
                        child: Row(
                          children: <Widget>[
                            Expanded(flex: 4, child: Text('${dm(w.start)} →', style: ts(13.5, w: FontWeight.w700))),
                            Expanded(flex: 3, child: Text('${w.trips} ${bi('ગાડી', 'trips')}', style: ts(13, c: Pal.muted))),
                            Expanded(flex: 3, child: Text(kgShort(w.kantaKg), textAlign: TextAlign.right, style: ts(13, w: FontWeight.w700, tab: true))),
                            Expanded(
                              flex: 3,
                              child: Align(
                                alignment: Alignment.centerRight,
                                child: w.mChit <= 0
                                    ? Text('—', style: ts(13, c: Pal.faint))
                                    : Pill(_pct1(w.ghatPct), tone: w.ghatPct.abs() <= lim ? 'green' : (w.ghatPct < 0 ? 'rose' : 'amber'), small: true),
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
        );

        return <Widget>[
          ScreenHeader(bi('ઘટ ટ્રેન્ડ', 'Loss trend'), sub: p.label, actions: <Widget>[refreshBtn()]),
          statusBanner(),
          RangeBar(sel: _sel, onChanged: (RangeSel r) => setState(() => _sel = r), presets: const <int>[2, 3, 4, 5, 6]),
          const SizedBox(height: 14),
          metricGrid(ctx, <Widget>[
            MetricTile(label: bi('કુલ ઘટ / વધ', 'Overall loss / gain'), value: _pct1(s.ghatPct), icon: 'cmp', tone: s.compared == 0 ? 'slate' : (s.ghatPct.abs() <= lim ? 'green' : 'rose'), sub: '${sk(s.ghat)} KG'),
            MetricTile(label: bi('મર્યાદાથી ઉપર દિવસ', 'Days above limit'), value: '$above', icon: 'warn', tone: above == 0 ? 'green' : 'rose'),
            MetricTile(
              label: bi('સૌથી ખરાબ દિવસ', 'Worst day'),
              value: worst == null ? '—' : dm(worst.day),
              icon: 'flag',
              tone: 'amber',
              sub: worst == null ? null : _pct1(worst.ghatPct),
            ),
            MetricTile(label: bi('મેળ થયેલ ગાડી', 'Matched trips'), value: '${s.compared}', icon: 'truck', tone: 'blue'),
          ]),
          const SizedBox(height: 16),
          chart,
          const SizedBox(height: 16),
          weeks,
        ];
      },
    );
  }
}

// ===================================================================== report
class RangeReportScreen extends StatefulWidget {
  const RangeReportScreen({super.key});

  @override
  State<RangeReportScreen> createState() => _ReportState();
}

class _ReportState extends State<RangeReportScreen> {
  RangeSel _sel = RangeSel(2);

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 800,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = _sel.period;
        final String text = buildReport(p);
        return <Widget>[
          ScreenHeader(bi('રિપોર્ટ', 'Report'), sub: p.label, actions: <Widget>[refreshBtn()]),
          statusBanner(),
          RangeBar(sel: _sel, onChanged: (RangeSel r) => setState(() => _sel = r)),
          const SizedBox(height: 14),
          Surface(
            padding: const EdgeInsets.all(16),
            child: SelectableText(text, style: ts(13.5, h: 1.5, tab: true)),
          ),
          const SizedBox(height: 12),
          Btn(bi('રિપોર્ટ કૉપિ કરો (WhatsApp)', 'Copy report (WhatsApp)'), icon: 'copy', expand: true, onTap: () => copyText(text)),
          const SizedBox(height: 8),
          Btn(
            bi('ગાડીની યાદી CSV કૉપિ', 'Copy vehicle list as CSV'),
            icon: 'table',
            kind: BtnKind.tonal,
            expand: true,
            onTap: () {
              final List<Trip> tl = live.trips.where((Trip t) => p.has(t.at)).toList();
              copyText(csvOf(tripHeader(), <List<Object?>>[for (final Trip t in tl) tripRow(t)]), msg: bi('CSV કૉપિ થયું', 'CSV copied'));
            },
          ),
        ];
      },
    );
  }
}
