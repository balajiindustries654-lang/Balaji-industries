import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/flags.dart';
import '../../core/i18n.dart';
import '../../core/icons.dart';
import '../../core/palette.dart';
import '../../data/live_store.dart';
import '../../widgets/common.dart';
import '../../widgets/page.dart';
import 'kit2.dart';

/// One how-to block: a title and a list of short steps.
class _Tip {
  final String icon;
  final String tone;
  final String gu;
  final String en;
  final List<String> stepsGu;
  final List<String> stepsEn;
  /// who sees it: 'all', 'worker', 'waybridge', 'maal_entry', 'admin'
  final String who;
  const _Tip(this.who, this.icon, this.tone, this.gu, this.en, this.stepsGu, this.stepsEn);
}

/// The GST help card is left out while GST is off.
bool _tipOn(_Tip t) => kGstOn || t.en != 'How to make a GST bill';

const List<_Tip> _tips = <_Tip>[
  // ------------------------------------------------------------ offline
  _Tip(
    'all',
    'wifioff',
    'blue',
    'ઇન્ટરનેટ વગર વાપરવું (ઑફલાઇન)',
    'Using the app without internet (offline)',
    <String>[
      'એક વાર ઇન્ટરનેટ સાથે લૉગિન કરો. પછી એ જ ફોન / PC પર ઇન્ટરનેટ વગર પણ મોબાઇલ + પાસવર્ડથી લૉગિન થશે.',
      'ચિઠ્ઠી, કાંટો, માલ અને Tally નો છેલ્લો ડેટા ફોન / PC પર સેવ રહે છે - ઇન્ટરનેટ વગર પણ જોઈ શકાય છે. ઉપર "ઑફલાઇન" અને છેલ્લા અપડેટનો સમય દેખાય છે.',
      'નવી ચિઠ્ઠી / કાંટો / માલ એન્ટ્રી સેવ કરો તો "મોકલવાની બાકી" માં રહે છે અને ઇન્ટરનેટ આવતા આપોઆપ જાય છે.',
      'ઑફલાઇન લૉગિન કર્યું હોય તો ઇન્ટરનેટ આવ્યા પછી ઉપરની પટ્ટી / ચિપ દબાવી પાસવર્ડ ફરી નાખો - ત્યારે ડેટા તાજો થાય છે અને બાકી એન્ટ્રી જાય છે.',
      'ફેરફાર ઇતિહાસ, કાઢી નાખવું અને Tally Agent ને સિંકની વિનંતી જેવા કામ માટે ઇન્ટરનેટ જોઈએ.',
      'સેટિંગ્સ → "ઇન્ટરનેટ વગર વાપરો" માં સેવ કરેલો ડેટા કાઢી શકાય છે.',
    ],
    <String>[
      'Log in once with internet. After that, on the same phone / PC, the mobile + password login also works without internet.',
      'The last data of chits, kanta, maal and Tally stays saved on the phone / PC and can be seen without internet. The top shows "Offline" and the time of the last update.',
      'A new chit / kanta / maal entry saved offline waits in "Waiting to upload" and goes by itself when the internet is back.',
      'If you logged in offline, once the internet is back tap the bar / chip on top and enter the password again - the data then refreshes and waiting entries are sent.',
      'Change history, deleting and asking the Tally Agent to sync need internet.',
      'Settings → "Use without internet" can remove the saved data from the device.',
    ],
  ),
  // ---------------------------------------------------------------- chit
  _Tip(
    'worker',
    'receipt',
    'teal',
    'નવી ચિઠ્ઠી કેવી રીતે બનાવવી',
    'How to make a new chit',
    <String>[
      'નીચેના ચિઠ્ઠી ટેબમાં + દબાવો, અથવા હોમ પરથી "નવી ચિઠ્ઠી".',
      'સ્લિપનો ફોટો પાડો. સ્કેન વાપરશો તો વિગત આપોઆપ ભરાશે.',
      'ખેડૂતનું નામ લખો - જૂના ખેડૂત સૂચનમાં આવશે, મોબાઇલ અને ગામ આપોઆપ ભરાશે.',
      'ગાડી નંબર, ગ્રોસ વજન, બારદાન અને કરદો લખો. ચોખ્ખું વજન નીચે આપોઆપ દેખાશે.',
      'સેવ પહેલાં આવતી ચેતવણી ધ્યાનથી વાંચો (ગાડી નંબર, વજન, બેગ).',
      'સેવ કરો. ઇન્ટરનેટ ન હોય તો એન્ટ્રી "મોકલવાની બાકી" માં જશે અને નેટ આવતા જ જતી રહેશે.',
    ],
    <String>[
      'Tap + in the Chit tab, or "New chit" on the home.',
      'Take a photo of the slip. Use scan and the fields fill themselves.',
      'Type the farmer - old farmers appear as suggestions with mobile and village.',
      'Enter vehicle, gross weight, bardan and kardo. The net weight shows below.',
      'Read the warnings before saving (vehicle number, weight, bags).',
      'Save. Without internet the entry waits in "Waiting to upload" and goes by itself.',
    ],
  ),
  _Tip(
    'worker',
    'repeat',
    'blue',
    'એ જ ખેડૂત ફરી',
    'Same farmer again',
    <String>[
      'ફોર્મની ઉપર "ફરી એ જ" પટ્ટી આવે છે - દબાવો એટલે છેલ્લી ચિઠ્ઠીનો ખેડૂત, ગાડી અને માલ ભરાઈ જાય.',
      'ફક્ત નવું વજન અને ચિઠ્ઠી નંબર બદલો.',
    ],
    <String>[
      'A "Repeat" bar sits on top of the form - tap it to copy farmer, vehicle and material from the last chit.',
      'Only change the new weight and chit number.',
    ],
  ),
  // ------------------------------------------------------------- kanta
  _Tip(
    'waybridge',
    'scale',
    'blue',
    'કાંટા એન્ટ્રી કેવી રીતે કરવી',
    'How to enter a weighbridge record',
    <String>[
      'નીચેના કાંટો ટેબમાં + દબાવો, અથવા સ્લિપ સ્કેન કરો.',
      'RST નંબર લખો - આગળનો નંબર આપોઆપ સૂચવાય છે. એ જ RST બે વાર હોય તો ચેતવણી આવશે.',
      'ગાડી નંબર લખો. સાચો ફોર્મેટ ન હોય તો લાલ ચેતવણી દેખાશે.',
      'કાંટાનું વજન (ગ્રોસ, ટેર, નેટ) લખો અને સ્લિપનો ફોટો જોડો.',
      'સેવ કરો. આજની ગણતરી ઉપર "આજનો પટ્ટો" માં દેખાશે.',
    ],
    <String>[
      'Tap + in the Kanta tab, or scan the slip.',
      'Enter the RST - the next number is suggested. The same RST twice shows a warning.',
      'Enter the vehicle. A wrong-looking number shows a red warning.',
      'Enter the weights (gross, tare, net) and attach the slip photo.',
      'Save. Today\'s count shows in the strip on top.',
    ],
  ),
  // -------------------------------------------------------------- maal
  _Tip(
    'maal_entry',
    'bag',
    'amber',
    'માલ એન્ટ્રી કેવી રીતે કરવી',
    'How to enter maal in / out',
    <String>[
      'અનલોડિંગ = બેગ ગોડાઉનમાં આવી. લોડિંગ = બેગ બહાર ગઈ.',
      'માલિક, માલ, ગોડાઉન અને ગાડી પસંદ કરો.',
      'બેગની સંખ્યા લખો. એ જ ગાડીમાં અગાઉ ગયેલી બેગ નીચે દેખાશે.',
      'સેવ કરો. ગોડાઉનમાં હાલ કેટલી બેગ છે તે "માલ સ્ટોક" માં દેખાય છે.',
    ],
    <String>[
      'Unloading = bags come into the godown. Loading = bags go out.',
      'Pick owner, material, godown and vehicle.',
      'Enter the number of bags. Bags already moved on the same vehicle show below.',
      'Save. The bags now in the godown show in "Maal stock".',
    ],
  ),
  // --------------------------------------------------------------- all
  _Tip(
    'all',
    'cloudup',
    'blue',
    'ઇન્ટરનેટ ન હોય ત્યારે',
    'When there is no internet',
    <String>[
      'એન્ટ્રી સેવ કરો - ફોનમાં સચવાઈ જશે અને ઉપર "મોકલવાની બાકી" દેખાશે.',
      'નેટ આવતા જ એપ જાતે મોકલી દેશે. ન જાય તો "મોકલવાની બાકી" માં ખોલીને ફરી દબાવો.',
      'એપ બંધ કરતા પહેલાં બાકી એન્ટ્રી ખાલી થઈ ગઈ છે કે નહીં તે જોઈ લો.',
    ],
    <String>[
      'Save the entry - it stays on the phone and "Waiting to upload" shows on top.',
      'It uploads by itself when the net returns. If not, open "Waiting to upload" and retry.',
      'Before closing the app, check that the waiting list is empty.',
    ],
  ),
  _Tip(
    'all',
    'scan',
    'violet',
    'સ્લિપ સ્કેન',
    'Scan a slip',
    <String>[
      'સ્કેન ખોલો અને સ્લિપનો સીધો, સ્પષ્ટ ફોટો પાડો (પ્રકાશ સારો રાખો).',
      'કયા પ્રકારની સ્લિપ છે તે (ચિઠ્ઠી / કાંટો / માલ) પસંદ કરો.',
      'ફોર્મ ભરાઈને ખુલશે - વજન અને નંબર જાતે તપાસીને જ સેવ કરો.',
      'સ્કેન ન ચાલે તો "એપ તપાસ" માં સ્કેનરની સ્થિતિ જુઓ - માલિકે સર્વર પર GEMINI_API_KEY મૂકેલી હોવી જોઈએ.',
    ],
    <String>[
      'Open Scan and take a straight, clear photo of the slip (good light).',
      'Choose the slip type (chit / kanta / maal).',
      'The form opens filled - check weights and numbers yourself before saving.',
      'If scan fails, see "App diagnostics" - the owner must have set GEMINI_API_KEY on the server.',
    ],
  ),
  _Tip(
    'all',
    'star',
    'amber',
    'મનપસંદ ⭐ અને શોધ',
    'Favourites ⭐ and search',
    <String>[
      '"બધા ફીચર" માં કોઈ પણ કાર્ડ પર ⭐ દબાવો - તે હોમ પર ઉપર આવી જશે.',
      'ઉપરના શોધ બોક્સમાં ખેડૂત, ગાડી નંબર કે RST લખો.',
      'સેટિંગ્સમાં ભાષા, ડાર્ક મોડ અને અક્ષરનું કદ બદલી શકાય.',
    ],
    <String>[
      'In "All features" tap ⭐ on any card - it moves up on the home.',
      'Type a farmer, vehicle or RST in the search box.',
      'Settings has language, dark mode and text size.',
    ],
  ),
  // ------------------------------------------------------------- owner
  _Tip(
    'admin',
    'rupee',
    'green',
    'ભાવ મૂકવા (પહેલું પગલું)',
    'Set the rates (first step)',
    <String>[
      '"ભાવ" ખોલો અને દરેક માલનો ₹ પ્રતિ 20 KG ભાવ તારીખ સાથે નાખો.',
      'ભાવ બદલાય ત્યારે નવી તારીખથી નવો ભાવ નાખો - જૂની ચિઠ્ઠી જૂના ભાવે જ ગણાશે.',
      'ભાવ વગર ખરીદ રકમ, ખેડૂત ખાતું અને બિલ ખોટા દેખાશે - એટલે આ પહેલા કરો.',
    ],
    <String>[
      'Open "Rates" and enter Rs per 20 KG for each material with its date.',
      'When the rate changes add the new rate with the new date - old chits keep the old rate.',
      'Without rates the purchase value, farmer ledger and bills are wrong - do this first.',
    ],
  ),
  _Tip(
    'admin',
    'agri',
    'green',
    'ખેડૂત ખાતું અને ચૂકવણી',
    'Farmer ledger and payments',
    <String>[
      '"ખેડૂત ખાતા" માં દરેક ખેડૂતનું બાકી દેખાય છે: ખરીદ રકમ + જૂનું બાકી − ચૂકવણી − ઉપાડ.',
      'ખાતું શરૂ થયાની તારીખ ખાતાની સ્ક્રીન પર બદલી શકાય. તે પહેલાંનું બાકી "જૂનું બાકી" તરીકે નાખો.',
      '"ચૂકવણી નાખો" થી રોકડ, બેંક કે ઉપાડ નોંધો. ખેડૂત પર દબાવી પૂરું ખાતું જુઓ અને WhatsApp પર મોકલો.',
      'ખેડૂતને ચૂકવણી ચોખ્ખા વજન પર કે ગ્રોસ પર - તે ખાતાની સેટિંગમાં બદલી શકાય.',
    ],
    <String>[
      '"Farmer ledger" shows what is due per farmer: purchase + opening − paid − advance.',
      'The ledger start date can be changed; older dues go in as "opening balance".',
      '"Add payment" records cash, bank or an advance. Tap a farmer for the full ledger and send it on WhatsApp.',
      'Payment on net or gross weight can be changed in the ledger settings.',
    ],
  ),
  _Tip(
    'admin',
    'wallet',
    'rose',
    'ખર્ચ, રોજમેળ અને આજનો હિસાબ',
    'Expenses, cash book and day account',
    <String>[
      '"ખર્ચ" માં રોજના ખર્ચ (મજૂરી, ભાડું, ડીઝલ, ચા-પાણી) હેડ મુજબ નોંધો.',
      '"રોજમેળ" માં ચૂકવણી અને ખર્ચ એક જ યાદીમાં તારીખ મુજબ આવે છે.',
      '"આજનો હિસાબ" માં આજની ખરીદ, ચૂકવણી, ખર્ચ અને રોકડ એક જ જગ્યાએ - WhatsApp પર મોકલી શકાય.',
      '"મહિનો બંધ" થી આખા મહિનાનો સરવાળો જુઓ.',
    ],
    <String>[
      '"Expenses" records daily costs (labour, freight, diesel, tea) by head.',
      '"Cash book" lists payments and expenses together by date.',
      '"Day account" gathers today\'s purchase, payments, expenses and cash - send it on WhatsApp.',
      '"Month close" shows the totals of the whole month.',
    ],
  ),
  _Tip(
    'admin',
    'handshake',
    'violet',
    'દલાલી, મજૂરી અને બિલ',
    'Brokerage, wages and bills',
    <String>[
      '"દલાલી" માં દલાલ મુજબ બેગ કે વજન પર દર નાખો - કુલ રકમ આપોઆપ.',
      '"મજૂરી" માં ચડાવવા અને ઉતારવાની બેગ પર દર નાખો - કોને કેટલા આપવા તે દેખાશે.',
      '"વજન બિલ" માં ખેડૂત અને સમય પસંદ કરી ખરીદ બિલ બનાવો અને WhatsApp પર મોકલો.',
      '"ખર્ચ ગણતરી" માં ભાવ, ભાડું, ખર્ચ નાખી નફો કે ખોટ જુઓ.',
    ],
    <String>[
      '"Brokerage" takes a rate per bag or weight for each broker and totals it.',
      '"Wages" takes a rate on bags loaded and unloaded - see who gets how much.',
      '"Weight bill" builds a purchase bill for a farmer and period; send it on WhatsApp.',
      '"Cost calculator" takes rate, freight and costs and shows profit or loss.',
    ],
  ),
  _Tip(
    'admin',
    'cart',
    'amber',
    'વેચાણ, પ્રોસેસ અને સ્ટોક',
    'Sales, processing and stock',
    <String>[
      '"પ્રોસેસ / ગ્રેડ" માં કાચો માલ કેટલો વાપર્યો અને કયા ગ્રેડ કેટલા નીકળ્યા તે લખો. ઘટ આપોઆપ દેખાશે.',
      '"વેચાણ" માં ખરીદનાર, માલ, વજન અને ભાવ લખો. ભાવ ₹ પ્રતિ 20 KG ગણાય છે અને રકમ આપોઆપ થશે.',
      'ખરીદનારે પૈસા આપ્યા ત્યારે "રકમ મળી" દબાવો. "ખરીદનાર ખાતા" માં કોની પાસે કેટલા લેવાના તે દેખાશે.',
      '"ઉઘરાણી" માં કોની પાસે કેટલા દિવસથી બાકી છે તે દેખાય છે. નામ દબાવી WhatsApp રીમાઈન્ડર મોકલો. ખરીદનારનો નંબર સેવ કરો તો સીધી તેની ચેટ ખુલશે.',
      '"સ્ટોક" માં કાંટાથી આવેલો કાચો માલ, પ્રોસેસ અને વેચાણ બાદ ગોડાઉનમાં કેટલું છે તે દેખાય છે.',
      'પહેલી વાર સ્ટોકમાં ગણતરી શરૂ કરવાની તારીખ ચૂંટો અને દરેક માલ પર દબાવી ઓપનિંગ સ્ટોક લખો.',
    ],
    <String>[
      'In "Processing / grades" enter how much raw material went in and what grades came out. The loss is worked out for you.',
      'In "Sales" enter the buyer, item, weight and rate. The rate is Rs per 20 KG and the amount is calculated.',
      'When a buyer pays, tap "Money received". "Buyer ledger" shows who owes how much.',
      '"Collection" shows who owes and since how many days. Tap a name to send a WhatsApp reminder; save the buyer\'s number to open his chat directly.',
      '"Stock" shows what is in the godown: weighbridge receipts less processing and sales.',
      'The first time, pick the counting start date in "Stock" and tap each item to enter its opening stock.',
    ],
  ),
  _Tip(
    'admin',
    'cmp',
    'rose',
    'મેળ અને ઘટ',
    'Match and loss',
    <String>[
      '"મેળ" ચિઠ્ઠી અને કાંટાનું વજન ગાડી મુજબ સરખાવે છે. મર્યાદા ઉપરનો ફરક લાલ દેખાય છે.',
      '"રસ્તામાં" માં ચિઠ્ઠી બની ગઈ છે પણ કાંટો બાકી છે તે ગાડીઓ દેખાય છે.',
      '"આવનાર ગાડી" માં અગાઉથી નોંધેલી ગાડી ક્યારે આવી તે જુઓ.',
      '"ધ્યાનમાં લો" ખોટા, ડુપ્લિકેટ કે શંકાસ્પદ વજન પકડે છે. જોઈ લીધા પછી "જોઈ લીધું" કરો.',
      'એક ગાડીમાં 1,00,000 KG થી વધુ વજનની એન્ટ્રી ટાઈપ ભૂલ ગણાય છે. તે કુલ આંકડામાં આવતી નથી. "ખોટા વજનની એન્ટ્રી" માંથી તેને કાઢી શકાય.',
    ],
    <String>[
      '"Match" compares chit and kanta weight per vehicle. Differences over the limit show red.',
      '"On the way" lists trucks with a chit but no kanta yet.',
      '"Bookings" shows whether the vehicles you noted in advance have arrived.',
      '"Attention" catches wrong, duplicate or suspicious weights. Mark them "checked" after you look.',
      'A weight above 1,00,000 KG in one vehicle is treated as a typing mistake and kept out of every total. Delete such entries in "Wrong-weight entries".',
    ],
  ),
  _Tip(
    'all',
    'calc',
    'amber',
    'કૅલ્ક્યુલેટર / હિસાબ',
    'Calculator / Hisab',
    <String>[
      'ઉપરની પટ્ટીમાં કૅલ્ક્યુલેટરનું બટન છે. PC પર Ctrl+H થી પણ ખુલે છે.',
      '"હિસાબ" માં વજન, બારદાન અને હવા નાખો - ચોખ્ખું વજન, મણ અને ક્વિન્ટલ દેખાશે. છેલ્લા કાંટાના વજન પર ટેપ કરીને લઈ શકાય.',
      'માલિક ભાવ નાખે તો ત્રણ રીતે ગણતરી થાય: સીધો ભાવ, દાણા ભાવ × ઉતારો, અથવા બેઝ ભાવ ± ઉતારો. ડેમેજ અને બીજી કપાત પણ ઉમેરાય.',
      '"નમૂનાથી ઉતારો" માં નમૂનો, દાણા, હવા અને ડેમેજ ગ્રામમાં નાખો - ટકા આપમેળે નીકળશે.',
      '"યાદ રાખો" થી હિસાબ સાચવાય, "કૉપિ" કે WhatsApp થી મોકલાય. બીજા ટેબમાં સાદું કૅલ્ક્યુલેટર અને ઘટ તપાસ છે.',
    ],
    <String>[
      'The top bar has a calculator button. On the PC, Ctrl+H opens it too.',
      '"Hisab": enter weight, bardan and hava - net weight, mann and quintal appear. Tap a recent kanta weight to use it.',
      'The owner can add a rate and work it three ways: direct rate, daana rate × utaro, or base rate ± utaro. Damage and other deductions can be added.',
      '"Utaro from a sample": enter sample, daana, hava and damaged daana in grams and the percentages are worked out.',
      '"Save" keeps a hisab; "Copy" or WhatsApp sends it. The other tabs are a plain calculator and the loss check.',
    ],
  ),
  _Tip(
    'admin',
    'book',
    'violet',
    'Tally નો ડેટા એપમાં જોવો',
    'See Tally data in the app',
    <String>[
      'Tally વાળા PC પર Balaji-Tally-Agent.bat ચાલુ રાખો (સ્ટેપ Tally-Setup.txt માં છે). તે Tally નો ડેટા Supabase માં મૂકે છે. Supabase માં supabase-tally.sql એક વાર ચલાવેલી હોવી જોઈએ.',
      'એપમાં માલિક (admin) તરીકે લૉગિન કરો. હિસાબ → "ટેલી ડેટા (વાંચન)" ખોલો. PC મોડમાં Z મેનુ કે ગેટવેમાંથી પણ ખુલે છે.',
      'ડે બુક, ખાતા, રોજમેળ, સ્ટોક, સારાંશ, બેંક બુક (UTR સાથે), ઉઘરાણી ઉંમર, ખરીદી મેળ, ચૂકવણી, GST અને ચેક્સ - 11 ટેબ છે. ફર્મ અને મહિનો ઉપરથી બદલો. કોઈ પણ લાઇન દબાવો તો વાઉચર કે પાર્ટીનો હિસાબ ખુલશે.',
      '"ચૂકવણી" ટેબ: Tally માં ખેડૂતને આપેલા પૈસા ઓળખાય છે. "બધા તૈયાર ઉમેરો" દબાવો તો ખેડૂત ખાતામાં જાય છે. નામ ન મળે તો "ખેડૂત જોડો" દબાવો - એક વાર જોડશો તો યાદ રહેશે. કશું આપમેળે ઉમેરાતું નથી, દરેક વખતે તમારી ટેપ જોઈએ.',
      '"ખરીદી મેળ": Pro ની ચિઠ્ઠીની રકમ અને Tally ની ખરીદી મેળવે છે. "ઉઘરાણી ઉંમર": કોનું કેટલા દિવસથી બાકી છે અને WhatsApp રીમાઈન્ડર. GST અને ચેક્સ (રોકડ ₹2 લાખ, ₹10,000 રોકડ ચૂકવણી, વાર્ષિક ખરીદી) અંદાજ છે - અંતિમ નિર્ણય CA પાસે કરાવો.',
      'ઉપર "છેલ્લો સિંક" દેખાય છે. 6 કલાકથી વધુ જૂનો હોય તો ચેતવણી આવશે - Tally PC પર Agent ચાલુ છે કે જુઓ.',
      'ડેટા ન આવે તો ઉપરનું "PC Agent" કાર્ડ ખોલો: તે કહે છે કે Agent ઇન્સ્ટોલ નથી, PC બંધ છે, Tally જવાબ નથી આપતું, લોગિન ગયું છે કે છેલ્લું સિંક કેમ ન થયું. "PC પર હમણાં સિંક" દબાવો તો ફોનથી જ Agent ને સિંક કરવા કહેવાય છે.',
      'આ ફક્ત વાંચવા માટે છે. એપથી Tally માં કંઈ બદલાતું નથી.',
    ],
    <String>[
      'Keep Balaji-Tally-Agent.bat running on the Tally PC (steps are in Tally-Setup.txt). It puts the Tally data into Supabase. supabase-tally.sql must have been run once in Supabase.',
      'Sign in to the app as the owner (admin). Open Accounts → "Tally data (read-only)". In PC mode it also opens from the Z menu or the Gateway.',
      'There are 11 tabs: Day Book, Ledgers, Cash book, Stock, Summary, Bank book (with UTR), Ageing, Purchase check, Payments, GST and Checks. Change the firm and month at the top. Tap any line to open the voucher or the party account.',
      'Payments tab: farmer payments made in Tally are spotted. Tap "Add all ready" to put them in the farmer khata. If a name is not found, tap "Link farmer" once and it is remembered. Nothing is added by itself - every import needs your tap.',
      'Purchase check compares Pro chit amounts with Tally purchases. Ageing shows who owes since how many days, with WhatsApp reminders. GST and Checks (cash Rs 2 lakh, Rs 10,000 cash payments, yearly purchases) are estimates - confirm with your CA.',
      'The top shows "Last sync". If it is older than 6 hours a warning appears - check that the Agent is running on the Tally PC.',
      'If no data arrives open the "PC Agent" card on top: it says if the Agent is not installed, the PC is off, Tally is not answering, the login is gone or why the last sync failed. "Sync now on the PC" asks the Agent to sync from your phone.',
      'This is read-only. Nothing is ever changed in Tally from the app.',
    ],
  ),
  _Tip(
    'admin',
    'keyboard',
    'blue',
    'PC મોડ - Tally જેવું',
    'PC mode - Tally style',
    <String>[
      'PC મોડમાં ઉપર મેનુ બાર છે: K કંપની, Y ડેટા, Z એક્સચેન્જ, G જાઓ, O ઇમ્પોર્ટ, E એક્સપોર્ટ, M શેર, P પ્રિન્ટ. Ctrl કે Alt સાથે અક્ષર દબાવો, અથવા ટચ/ક્લિક કરો.',
      'ઘર પર "ગેટવે ઓફ બાલાજી" છે. ↑ ↓ થી પસંદ કરો અને Enter થી ખોલો. પીળી પટ્ટી પસંદ કરેલી લાઇન છે.',
      'જમણી બાજુની F-કી (Tally જેવી): F4 કોન્ટ્રા, F5 ચૂકવણી, F6 રસીદ, F7 જર્નલ, F8 વેચાણ, F9 ખરીદી (ચિઠ્ઠી), Ctrl+F8 ક્રેડિટ નોટ (વેચાણ પરત), Ctrl+F9 ડેબિટ નોટ (ખરીદ પરત), F10 બીજા વાઉચર (ખર્ચ, પ્રોસેસ, કાંટો, માલ, GST બિલ), F2 પીરિયડ / આજનો રિપોર્ટ, F3 શોધ, F11 ધ્યાનમાં લો, F12 ગોઠવણ.',
      'કોઈ પણ વાઉચર / ફોર્મમાં Ctrl+A (અથવા Ctrl+Enter) દબાવો તો તે સેવ (Accept) થઈ જશે - Tally ની જેમ.',
      'Esc થી પાછા જવાય. બધે Esc દબાવતા ગેટવે પર પહોંચશો.',
      'ગેટવે બરાબર TallyPrime જેવું છે: માસ્ટર્સ, વ્યવહાર (વાઉચર, ડે બુક), સાધનો, રિપોર્ટ અને Quit. મેનુની અંદર મેનુ ખુલે છે (જેમ કે રિપોર્ટ → વધુ રિપોર્ટ → હિસાબ ચોપડા). ↑ ↓ થી પસંદ કરો, Enter કે → થી ખોલો, Esc કે Backspace કે ← થી પાછા. ગેટવે પર Esc કે Q દબાવો તો બહાર નીકળવા પૂછશે.',
      'બધું મોટું લાગે તો Ctrl અને − દબાવો (નાનું), Ctrl અને + (મોટું), Ctrl અને 0 (ઓટો). F12 માં "સ્ક્રીન ઝૂમ" પણ છે.',
      'જૂનો દેખાવ જોઈએ તો F12 (ગોઠવણ) માં "Modern" પસંદ કરો.',
    ],
    <String>[
      'In PC mode the top menu bar has K Company, Y Data, Z Exchange, G Go To, O Import, E Export, M Share, P Print. Press Ctrl or Alt with the letter, or tap/click.',
      'Home is the "Gateway of Balaji". Move with the up and down arrows and open with Enter. The yellow bar is the selected line.',
      'F-keys on the right (same as TallyPrime): F4 contra, F5 payment, F6 receipt, F7 journal, F8 sales, F9 purchase (chit), Ctrl+F8 credit note (sales return), Ctrl+F9 debit note (purchase return), F10 other vouchers (expense, processing, kanta, maal, GST bill), F2 period / day report, F3 search, F11 attention, F12 configure.',
      'In any voucher / form press Ctrl+A (or Ctrl+Enter) to save (Accept) it - like Tally.',
      'Esc goes back. Keep pressing Esc to reach the Gateway.',
      'The Gateway is laid out exactly like TallyPrime: Masters, Transactions (Vouchers, Day Book), Utilities, Reports and Quit. Menus open inside menus (like Reports → Display More Reports → Account Books). Move with ↑ ↓, open with Enter or →, go back with Esc, Backspace or ←. Esc or Q on the Gateway asks to quit.',
      'If everything feels big, press Ctrl and − (smaller), Ctrl and + (bigger), Ctrl and 0 (auto). F12 also has "Screen zoom".',
      'For the old look, pick "Modern" in F12 (Configure).',
    ],
  ),
  _Tip(
    'admin',
    'percentbox',
    'amber',
    'GST બિલ કેવી રીતે બનાવવું',
    'How to make a GST bill',
    <String>[
      'વેપાર → "GST બિલ" ખોલો. પહેલી વાર ઉપર પેઢી (Balaji / Patel / Shreenathji) ની GSTIN, સરનામું, બેંક અને બિલ-નંબરની શરૂઆત ભરો.',
      '+ દબાવો. પેઢી, તારીખ, ખરીદદારનું નામ (GSTIN નાખો તો રાજ્ય આપોઆપ આવે) અને માલ ઉમેરો. માલ એક ટેપમાં: મગફળી દાણા, ફોતરાં સાથે, સીંગતેલ, ખોળ, એરંડા, ભાડું.',
      'ભાવ મણ (20 KG), ક્વિન્ટલ કે KG પ્રમાણે નાખી શકાય. CGST + SGST કે IGST રાજ્ય મુજબ આપોઆપ લાગે છે અને નીચે HSN મુજબ સરવાળો દેખાય છે.',
      'સેવ કરો એટલે બિલ નંબર (જેમ કે BI/26-27/001) આપોઆપ મળે છે અને રકમ ખરીદદારના ખાતામાં ચડે છે. વેચાણ યાદીમાંથી પણ "GST બિલ બનાવો" દબાવી શકાય.',
      'બિલ ખોલીને "પ્રિન્ટ / PDF" દબાવો - બ્રાઉઝર ખુલશે અને પ્રિન્ટનો ડાયલોગ આવશે (PDF તરીકે સેવ પણ થાય). WhatsApp પર લખાણ પણ મોકલાય છે.',
      'ખોટું બિલ હોય તો "રદ કરો" - નંબર રહેશે પણ રકમ કપાઈ જશે. ઉપર GSTR-1 માટે CSV એક્સપોર્ટ છે.',
      'GST ટકા (5% વગેરે) ફક્ત શરૂઆતનું સૂચન છે - અંતિમ ટકા તમારા CA પાસે પાક્કા કરાવો.',
    ],
    <String>[
      'Open Accounts & trade → "GST invoice". The first time fill each firm\'s GSTIN, address, bank and bill-number start (Balaji / Patel / Shreenathji).',
      'Tap +. Pick the firm, date, buyer (a GSTIN fills the state by itself) and add items. One tap items: groundnut kernels, in shell, oil, cake, castor, freight.',
      'The rate can be per mann (20 KG), quintal or KG. CGST + SGST or IGST is applied by the state, and the HSN-wise total is shown below.',
      'On save the bill gets its number (like BI/26-27/001) and the amount goes to the buyer\'s ledger. You can also tap "Make GST bill" on a sale.',
      'Open the bill and tap "Print / PDF" - the browser opens with the print dialog (Save as PDF works too). The text can also go on WhatsApp.',
      'A wrong bill can be cancelled - the number stays but the amount is taken off. There is a CSV export for GSTR-1.',
      'The GST % (5% etc.) is only a starting suggestion - have the final rate confirmed by your CA.',
    ],
  ),
  _Tip(
    'admin',
    'truck',
    'blue',
    'ટ્રેડિંગ / મિલ ગાડી',
    'Trading / mill truck',
    <String>[
      'વેપાર → "ટ્રેડિંગ / મિલ" → + દબાવો. ગાડી નંબર લખતા કાંટા/ચિઠ્ઠીનું વજન સૂચન તરીકે મળે છે.',
      'ક્યાંથી ખરીદ્યું, કઈ મિલને, ભરેલું વજન, ખરીદ ભાવ અને વેચાણ ભાવ (20 KG દીઠ) ભરો. ભાડું, મજૂરી, દલાલી પણ.',
      'મિલનું વજન આવે ત્યારે ગાડી ખોલી "મિલ વજન નાખો" - ઘટ KG અને % તરત દેખાશે, નફો મિલ વજન પર ગણાશે.',
      'ગાડી ખોલી "GST બિલ બનાવો" - ફોર્મ ભરેલું આવે છે અને બિલ નંબર ગાડી સાથે જોડાઈ જાય છે.',
      'મિલ પાસેથી પૈસા આવે ત્યારે "રકમ મળી" દબાવો - હપ્તે હપ્તે પણ. "મિલ મુજબ ખાતું" ટેબમાં દરેક મિલની કુલ બાકી દેખાય છે.',
    ],
    <String>[
      'Accounts & trade → "Trading / mill" → tap +. Typing the vehicle suggests the kanta / chit weight.',
      'Enter who it was bought from, the mill, loaded weight, buy rate and sell rate (per 20 KG). Freight, labour and commission too.',
      'When the mill weight comes open the truck and tap "Enter mill weight" - short KG and % show at once and the profit is worked on the mill weight.',
      'Open the truck and tap "Make GST bill" - the form comes filled and the bill number is linked to the truck.',
      'When money comes from the mill tap "Money received" - part payments too. The "Mill ledger" tab shows what each mill still owes.',
    ],
  ),
  _Tip(
    'admin',
    'bank',
    'blue',
    'બેંક / UPI ઑટો-મેચ',
    'Bank / UPI auto-match',
    <String>[
      'બેંક → "બેંક / UPI ઑટો-મેચ" ખોલો. Net-banking માંથી statement (CSV / Excel) હેડર લાઇન સાથે કૉપી કરી "Statement / SMS નાખો" માં paste કરો. બેંકના SMS પણ ચાલે.',
      '"વાંચો" દબાવો - કેટલી લાઇન વંચાઈ, કેટલી નવી, ગયા / આવ્યા કેટલા તે દેખાશે. પછી સેવ. એ જ statement ફરી paste કરશો તો બેવડી નહીં બને.',
      'દરેક લાઇન ખેડૂત (ચૂકવ્યા), ખરીદદાર / મિલ ગાડી (રકમ મળી) કે પહેલેથી નોંધેલી એન્ટ્રી સાથે મેળવાય છે. નામના અક્ષરો અને રકમ-તારીખ બંને જોવાય છે.',
      '"પાક્કી" લાઇન (નામ બરાબર મળ્યું કે એ જ રકમ પહેલેથી નોંધેલી) "એકસાથે નોંધો" થી ખાતામાં ચડે છે. બાકીની લાઇન દબાવી જાતે પસંદ કરો - એક વાર પસંદ કરશો તો એપ યાદ રાખશે.',
      'દરેક નોંધાયેલી લાઇનમાં "પાછી લો (Undo)" છે. Tally નો ડેટા હોય તો દરેક લાઇન સામે Tally ✓ / ✗ દેખાય છે.',
    ],
    <String>[
      'Banking → "Bank / UPI auto-match". Copy the statement (CSV / Excel) with its header row from net-banking and paste it in "Add statement / SMS". Bank SMS work too.',
      'Tap "Read it" - lines read, how many are new and the money out / in are shown. Then save. Pasting the same statement again does not double anything.',
      'Each line is matched with a farmer (paid), a buyer / mill truck (received) or an entry already made. Name letters and amount-date are both used.',
      '"Sure" lines (name matched well, or the same money is already entered) are posted with "post together". Tap the others and choose yourself - the app remembers what you chose.',
      'Every posted line has "Take back (Undo)". With Tally data each line shows Tally ✓ / ✗.',
    ],
  ),
  _Tip(
    'admin',
    'fact',
    'rose',
    'ડેબિટ નોટ રોજની તપાસ',
    'Daily debit-note check',
    <String>[
      'ઘટ / તપાસ → "ડેબિટ નોટ તપાસ" ખોલો. કાંટા વજન ચિઠ્ઠી કરતાં માન્ય ફરક કરતાં વધુ ઓછું હોય તેવી ગાડીઓ ખેડૂત મુજબ ડેબિટ નોટની અંદાજિત રકમ સાથે દેખાય છે.',
      'ગાડી દબાવો: ખેડૂત મુજબ ઘટ KG અને રકમ, Tally માં ડેબિટ નોટ મળી કે નહીં. "ડેબિટ નોટ થઈ ગઈ" કે "છોડી દો" કરો; WhatsApp પર વિગત મોકલી શકાય.',
      'બીજા ટેબમાં Tally ની ડેબિટ નોટ તપાસાય છે: નરેશન ન હોય, રકમ મોટી હોય, એવી જ ડેબિટ નોટ બે વાર હોય, ખરીદી કરતાં વધુ હોય.',
      'સેટિંગ (ઉપર) માં દિવસ, ઓછામાં ઓછી ઘટ KG, મોટી રકમ અને "રોજની ઑટો તપાસ" ગોઠવાય છે. ચાલુ હોય તો દિવસમાં એક વાર એપ ખોલતા કેટલી ગાડીમાં ઘટ છે તે જણાવે છે.',
    ],
    <String>[
      'Checks → "Debit-note check". Trucks that weighed less than the chit by more than the allowed difference are listed with the estimated debit note by farmer.',
      'Tap a truck: short KG and value by farmer, and whether a debit note was found in Tally. Mark "Debit note made" or "Skip"; the details can go on WhatsApp.',
      'The second tab audits the Tally debit notes: no narration, big amount, the same note twice, more than the purchases.',
      'Settings (top) sets the days, smallest short KG, the big amount and "Automatic daily check". When on, the app tells you once a day how many trucks are short.',
    ],
  ),
  _Tip(
    'all',
    'sync',
    'slate',
    'કાંટો ઑટો (કાંટા PC)',
    'Automatic weighbridge (kanta PC)',
    <String>[
      'કાંટા સોફ્ટવેર સ્લિપ CSV / TXT ફાઇલમાં સેવ કરતું હોય તો કાંટા PC પર એપમાં "કાંટો ઑટો" ખોલો.',
      'ફાઇલ કે ફોલ્ડરનો path લખી "ફાઇલ વાંચો" દબાવો. કૉલમ (ગાડી, RST, વજન, તારીખ) એપ નામ પરથી ઓળખે છે - ખોટું હોય તો બદલો.',
      'નીચે દેખાશે કેટલા વજન નવા છે. "એપમાં નાખો" દબાવો તો કાંટા એન્ટ્રી બને છે. જે RST એપમાં પહેલેથી છે તે ફરી નહીં બને.',
      '"ઑટો ચાલુ" કરશો તો જૂના વજન છોડીને નવા વજન દર ~૪૫ સેકન્ડે આપોઆપ જશે (એપ આ PC પર ખુલ્લી હોય ત્યારે). આ બીટા છે - શરૂઆતમાં કાંટા એન્ટ્રી તપાસતા રહો.',
    ],
    <String>[
      'If the weighbridge software saves its slips in a CSV / TXT file, open "Automatic weighbridge" in the app on the kanta PC.',
      'Enter the file or folder path and tap "Read the file". The app guesses the columns (vehicle, RST, weight, date) from the names - change them if wrong.',
      'It shows how many weighings are new. Tap "send to the app" to make the weighbridge entries. A RST that is already in the app is not made again.',
      'Switch "Auto on" and the old weighings are skipped while new ones go about every 45 seconds (while the app is open on this PC). This is beta - keep checking the kanta entries at first.',
    ],
  ),
];

class HelpScreen extends StatelessWidget {
  const HelpScreen({super.key});

  bool _show(_Tip t, String role, bool admin) {
    if (t.who == 'all') return true;
    if (admin) return true;
    return t.who == role;
  }

  @override
  Widget build(BuildContext context) {
    final bool admin = live.isAdmin;
    final String role = live.me?.role ?? '';
    final List<_Tip> own = _tips.where((_Tip t) => _tipOn(t) && t.who != 'all' && t.who != 'admin' && _show(t, role, admin)).toList();
    final List<_Tip> all = _tips.where((_Tip t) => _tipOn(t) && t.who == 'all').toList();
    final List<_Tip> boss = admin ? _tips.where((_Tip t) => _tipOn(t) && t.who == 'admin').toList() : <_Tip>[];
    final List<Widget> kids = <Widget>[
      ScreenHeader(bi('માર્ગદર્શન', 'Guide'), sub: bi('કામ કેવી રીતે કરવું - સ્ટેપ મુજબ', 'How to do each job - step by step')),
      noteBox('bulb', 'teal', bi('કોઈ પણ કાર્ડ ખોલવા દબાવો. બધું તમારા રોલ મુજબ બતાવ્યું છે.', 'Tap a card to open it. Everything is shown for your role.')),
    ];
    void group(String gu, String en, List<_Tip> l, {bool first = false}) {
      if (l.isEmpty) return;
      kids.add(Padding(
        padding: const EdgeInsets.fromLTRB(2, 14, 2, 8),
        child: Text(bi(gu, en), style: ts(15, w: FontWeight.w800)),
      ));
      for (int i = 0; i < l.length; i++) {
        kids.add(_HelpCard(l[i], open: first && i == 0));
      }
    }

    if (admin) {
      group('માલિક માટે', 'For the owner', boss, first: true);
      group('સ્ટાફ કેવી રીતે કામ કરે છે', 'How the staff work', own);
      group('બધા માટે', 'For everyone', all);
    } else {
      group('તમારું કામ', 'Your work', own, first: true);
      group('બધા માટે', 'For everyone', all);
    }
    kids.add(const SizedBox(height: 8));
    kids.add(Btn(bi('બધા ફીચર જુઓ', 'See all features'), icon: 'list', kind: BtnKind.tonal, expand: true, onTap: () => app.go('hub')));
    return ScreenScroll(maxWidth: 760, children: kids);
  }
}

class _HelpCard extends StatefulWidget {
  final _Tip tip;
  final bool open;
  const _HelpCard(this.tip, {this.open = false});

  @override
  State<_HelpCard> createState() => _HelpCardState();
}

class _HelpCardState extends State<_HelpCard> {
  late bool _open = widget.open;

  @override
  Widget build(BuildContext context) {
    final _Tip t = widget.tip;
    final List<String> steps = L.gu ? t.stepsGu : t.stepsEn;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Surface(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        onTap: () => setState(() => _open = !_open),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                IconChip(t.icon, tone: t.tone, size: 40),
                const SizedBox(width: 12),
                Expanded(child: Text(bi(t.gu, t.en), style: ts(14.5, w: FontWeight.w800, h: 1.25))),
                Icon(ic(_open ? 'up' : 'down'), size: 22, color: Pal.faint),
              ],
            ),
            if (_open) ...<Widget>[
              const SizedBox(height: 10),
              for (int i = 0; i < steps.length; i++)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Container(
                        width: 22,
                        height: 22,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(color: Pal.tone(t.tone).bg, shape: BoxShape.circle),
                        child: Text('${i + 1}', style: ts(11.5, w: FontWeight.w800, c: Pal.tone(t.tone).fg)),
                      ),
                      const SizedBox(width: 10),
                      Expanded(child: Text(steps[i], style: ts(13.5, h: 1.4))),
                    ],
                  ),
                ),
            ],
          ],
        ),
      ),
    );
  }
}
