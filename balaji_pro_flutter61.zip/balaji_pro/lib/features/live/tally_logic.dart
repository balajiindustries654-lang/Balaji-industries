part of 'tally_data.dart';

// ======================================================================
// Tally + Pro together (READ-ONLY towards Tally).
// farmer name matching, Tally payments -> farmer khata, purchase check,
// ageing, bank book, GST and checks. No screens here - see tally_tabs.dart
// ======================================================================

String _today() => _dk(DateTime.now());

int _daysBetween(String a, String b) {
  final DateTime? x = DateTime.tryParse(a);
  final DateTime? y = DateTime.tryParse(b);
  if (x == null || y == null) return 0;
  return DateTime(y.year, y.month, y.day).difference(DateTime(x.year, x.month, x.day)).inDays;
}

// ------------------------------------------------------------------ names
final RegExp _splitWords = RegExp(r'[^\p{L}\p{M}\p{N}]+', unicode: true);

List<String> _toks(String s) {
  final List<String> out = <String>[];
  for (final String t in s.toLowerCase().split(_splitWords)) {
    if (t.isNotEmpty) out.add(t);
  }
  return out;
}

int _lev(String a, String b) {
  if (a == b) return 0;
  if (a.isEmpty) return b.length;
  if (b.isEmpty) return a.length;
  List<int> prev = List<int>.generate(b.length + 1, (int i) => i);
  for (int i = 1; i <= a.length; i++) {
    final List<int> cur = List<int>.filled(b.length + 1, 0);
    cur[0] = i;
    final int ca = a.codeUnitAt(i - 1);
    for (int j = 1; j <= b.length; j++) {
      final int cost = ca == b.codeUnitAt(j - 1) ? 0 : 1;
      int v = prev[j] + 1;
      if (cur[j - 1] + 1 < v) v = cur[j - 1] + 1;
      if (prev[j - 1] + cost < v) v = prev[j - 1] + cost;
      cur[j] = v;
    }
    prev = cur;
  }
  return prev[b.length];
}

/// ka / kb = the name without spaces and signs, sa / sb = the words sorted.
double _sim2(String ka, String sa, String kb, String sb) {
  if (ka.isEmpty || kb.isEmpty) return 0;
  if (ka == kb) return 1;
  if (sa == sb) return 0.97;
  if (ka.length >= 5 && kb.length >= 5 && (ka.contains(kb) || kb.contains(ka))) return 0.88;
  final int mx = ka.length > kb.length ? ka.length : kb.length;
  final int mn = ka.length > kb.length ? kb.length : ka.length;
  if (mx > 48 || mx - mn > 4) return 0;
  double best = 1 - _lev(ka, kb) / mx;
  final int mx2 = sa.length > sb.length ? sa.length : sb.length;
  if (mx2 > 0 && mx2 <= 48) {
    final double s2 = 1 - _lev(sa, sb) / mx2;
    if (s2 > best) best = s2;
  }
  return best;
}

String _sortedWords(String s) {
  final List<String> t = _toks(s);
  t.sort();
  return t.join();
}

class _Fm {
  final String key;
  final String label;
  final String uk;
  final String sorted;
  _Fm(this.key, this.label)
      : uk = _nk(label),
        sorted = _sortedWords(label);
}

class _FMatch {
  final String key;
  final String label;
  final double score;
  const _FMatch(this.key, this.label, this.score);
}

/// Every farmer Pro knows (from the chits and from the payments).
List<_Fm> _farmerIndex() {
  final Map<String, _Fm> m = <String, _Fm>{};
  for (final Chit c in live.chits) {
    final String k = nameKey(c.farmer);
    if (k.isEmpty) continue;
    m.putIfAbsent(k, () => _Fm(k, c.farmer.trim()));
  }
  for (final PayItem p in payItems()) {
    if (p.key.isEmpty) continue;
    m.putIfAbsent(p.key, () => _Fm(p.key, p.label.isEmpty ? p.key : p.label));
  }
  final List<_Fm> out = m.values.toList();
  out.sort((_Fm a, _Fm b) => a.label.toLowerCase().compareTo(b.label.toLowerCase()));
  return out;
}

Map<String, String> _aliasMap() {
  final Object? v = prefDoc.data['tallyAlias'];
  final Map<String, String> out = <String, String>{};
  if (v is Map) {
    for (final MapEntry<dynamic, dynamic> e in v.entries) {
      out['${e.key}'] = '${e.value}';
    }
  }
  return out;
}

Set<String> _ignoreSet() {
  final Object? v = prefDoc.data['tallyIgnore'];
  final Set<String> out = <String>{};
  if (v is Map) {
    for (final Object? k in v.keys) {
      out.add('$k');
    }
  }
  return out;
}

Future<void> _setAlias(String party, String farmerKey) {
  final String k = _nk(party);
  return prefDoc.commit(() {
    prefDoc.map('tallyAlias')[k] = farmerKey;
  });
}

Future<void> _setIgnore(String party, bool on) {
  final String k = _nk(party);
  return prefDoc.commit(() {
    final Map<String, dynamic> m = prefDoc.map('tallyIgnore');
    if (on) {
      m[k] = true;
    } else {
      m.remove(k);
    }
  });
}

class _Matcher {
  final List<_Fm> idx;
  final Map<String, String> alias;
  final Map<String, _FMatch?> _memo = <String, _FMatch?>{};
  _Matcher(this.idx, this.alias);

  /// The farmer a Tally party most probably is (null when none is close).
  _FMatch? of(String party) {
    final String uk = _nk(party);
    if (uk.isEmpty) return null;
    if (_memo.containsKey(uk)) return _memo[uk];
    _FMatch? best;
    final String? ak = alias[uk];
    if (ak != null) {
      for (final _Fm f in idx) {
        if (f.key == ak) {
          best = _FMatch(f.key, f.label, 1);
          break;
        }
      }
    }
    if (best == null) {
      final String sp = _sortedWords(party);
      double bs = 0;
      _Fm? bf;
      for (final _Fm f in idx) {
        final double s = _sim2(uk, sp, f.uk, f.sorted);
        if (s > bs) {
          bs = s;
          bf = f;
        }
      }
      if (bf != null && bs >= 0.7) best = _FMatch(bf.key, bf.label, bs);
    }
    _memo[uk] = best;
    return best;
  }
}

class _MCache {
  static String sig = '';
  static _Matcher? m;
}

_Matcher _matcher() {
  final Map<String, String> alias = _aliasMap();
  final String sig = '${live.chits.length}|${payDoc.list('items').length}|${alias.length}|${alias.values.join().hashCode}';
  final _Matcher? cur = _MCache.m;
  if (cur != null && _MCache.sig == sig) return cur;
  final _Matcher n = _Matcher(_farmerIndex(), alias);
  _MCache.sig = sig;
  _MCache.m = n;
  return n;
}

// ------------------------------------------------------------ small helpers
Map<String, String> _kindMap() {
  final Map<String, String> m = <String, String>{};
  for (final TLedger l in tallyStore.ledgers) {
    m['${l.firm}|${_nk(l.name)}'] = l.kind;
  }
  return m;
}

Set<String> _cashSet() {
  final Set<String> s = <String>{};
  for (final TLedger l in tallyStore.ledgers) {
    if (l.kind == 'cash') s.add(_nk(l.name));
  }
  return s;
}

bool _isCashName(Set<String> cash, String n) {
  final String k = _nk(n);
  return k.isNotEmpty && (cash.contains(k) || k.startsWith('cash') || k.contains('pettycash'));
}

bool _bankish(String n) => RegExp(r'cash|bank|^\d{6,}$', caseSensitive: false).hasMatch(n);

String _payMode(String m) {
  if (m == 'cash' || m == 'upi' || m == 'bank' || m == 'cheque') return m;
  return 'bank';
}

bool _inRange(String d, String from, String to) {
  if (from.isNotEmpty && d.compareTo(from) < 0) return false;
  if (to.isNotEmpty && d.compareTo(to) > 0) return false;
  return true;
}

// ================================================= Tally payments -> khata
/// refs of the Tally payments that are already in Pro.
Set<String> tallyRefsUsed() {
  final Set<String> s = <String>{};
  for (final Map<String, dynamic> m in payDoc.list('items')) {
    final String t = '${m['tref'] ?? ''}';
    if (t.isNotEmpty) s.add(t);
  }
  return s;
}

class _Plan {
  final TVoucher v;
  final int line;
  final String ledger;
  final double amount;
  final String ref;
  String state = 'unknown'; // ready | review | unknown | dup | done | ignored
  String key = '';
  String name = '';
  double score = 0;
  String why = '';
  _Plan(this.v, this.line, this.ledger, this.amount, this.ref);
}

String _sig(String key, String date, double amt) => '$key|$date|${amt.round()}';

List<_Plan> _buildPlan(_Matcher mt) {
  final Map<String, String> kinds = _kindMap();
  final Set<String> done = tallyRefsUsed();
  final Set<String> ign = _ignoreSet();
  final Set<String> own = <String>{
    for (final String f in <String>['patel', 'shreenathji', 'balaji']) _nk(firmName(f)),
  };
  final Set<String> manual = <String>{};
  final Set<String> imported = <String>{};
  for (final Map<String, dynamic> m in payDoc.list('items')) {
    final String kind = '${m['kind'] ?? 'pay'}';
    if (kind != 'pay' && kind != 'adv') continue;
    final String sg = _sig('${m['key'] ?? ''}', '${m['date'] ?? ''}', dbl(m['amt']));
    if ('${m['tref'] ?? ''}'.isNotEmpty) {
      imported.add(sg);
    } else {
      manual.add(sg);
    }
  }
  final Set<String> seen = <String>{};
  final List<_Plan> out = <_Plan>[];
  for (final TVoucher v in tallyStore.vouchers) {
    if (v.base != 'payment' || v.cancelled || v.optional) continue;
    final List<TLine> lines = v.lines.isNotEmpty ? v.lines : <TLine>[TLine(v.party, v.amount)];
    for (int i = 0; i < lines.length; i++) {
      final TLine ln = lines[i];
      if (!(ln.amount > 0) || ln.ledger.isEmpty) continue;
      final String ref = '${v.firm}|${v.vkey}#$i';
      final _Plan p = _Plan(v, i, ln.ledger, ln.amount, ref);
      if (done.contains(ref)) {
        p.state = 'done';
        out.add(p);
        continue;
      }
      final String uk = _nk(ln.ledger);
      if (_bankish(ln.ledger) || own.contains(uk)) continue;
      final String kind = kinds['${v.firm}|$uk'] ?? 'other';
      if (kind == 'expense' || kind == 'income' || kind == 'bank' || kind == 'cash' || kind == 'purchase' || kind == 'debtor') continue;
      if (ign.contains(uk)) {
        p.state = 'ignored';
        out.add(p);
        continue;
      }
      final _FMatch? m = mt.of(ln.ledger);
      if (m == null) {
        if (kind == 'creditor') {
          p.state = 'unknown';
          out.add(p);
        }
        continue;
      }
      p.key = m.key;
      p.name = m.label;
      p.score = m.score;
      final String sg = _sig(m.key, v.date, ln.amount);
      if (manual.contains(sg)) {
        p.state = 'dup';
        p.why = 'same';
      } else if (imported.contains(sg) || seen.contains(sg)) {
        p.state = 'review';
        p.why = 'twice';
      } else {
        p.state = m.score >= 0.93 ? 'ready' : 'review';
        if (p.state == 'review') p.why = 'name';
      }
      seen.add(sg);
      out.add(p);
    }
  }
  return out;
}

/// Puts the Tally payments into the farmer khata of Pro. Returns how many were added.
Future<int> _importPlans(List<_Plan> items) async {
  final List<_Plan> ok = <_Plan>[
    for (final _Plan p in items)
      if (p.key.isNotEmpty) p,
  ];
  if (ok.isEmpty) return 0;
  int n = 0;
  await payDoc.commit(() {
    final List<Map<String, dynamic>> l = payDoc.list('items');
    final Set<String> used = <String>{
      for (final Map<String, dynamic> m in l) '${m['tref'] ?? ''}',
    };
    final DateTime now = DateTime.now();
    int seq = 0;
    for (final _Plan p in ok) {
      if (used.contains(p.ref)) continue;
      used.add(p.ref);
      seq++;
      l.add(<String, dynamic>{
        'id': '${now.microsecondsSinceEpoch + seq}',
        'key': p.key,
        'label': p.name,
        'date': p.v.date,
        'amt': p.amount,
        'kind': 'pay',
        'mode': _payMode(p.v.mode),
        'note': 'Tally ${p.v.type}${p.v.no.isEmpty ? '' : ' ${p.v.no}'} · ${_firmShort(p.v.firm)}',
        'at': now.toIso8601String(),
        'tref': p.ref,
      });
      n++;
    }
  });
  return n;
}

/// A payment that came from Tally but Tally has since cancelled, deleted or changed.
class _Orphan {
  final String id;
  final String label;
  final String date;
  final double amt;
  final String why; // cancelled | missing | changed
  final double tallyAmt;
  final String tallyDate;
  const _Orphan(this.id, this.label, this.date, this.amt, this.why, this.tallyAmt, this.tallyDate);
}

List<_Orphan> _orphans() {
  // the whole copy (not only what the owner's rule shows): a payment imported earlier from a firm that is now sales-only is still there
  final Map<String, TVoucher> byKey = <String, TVoucher>{};
  final Set<String> firms = <String>{};
  for (final TVoucher v in tallyStore.allVouchers) {
    byKey['${v.firm}|${v.vkey}'] = v;
    firms.add(v.firm);
  }
  final String fy = TallyStore.fyStart();
  final List<_Orphan> out = <_Orphan>[];
  for (final Map<String, dynamic> m in payDoc.list('items')) {
    final String ref = '${m['tref'] ?? ''}';
    if (ref.isEmpty) continue;
    final int h = ref.lastIndexOf('#');
    if (h < 0) continue;
    final String vk = ref.substring(0, h);
    final int li = int.tryParse(ref.substring(h + 1)) ?? 0;
    final String id = '${m['id'] ?? ''}';
    final String label = '${m['label'] ?? ''}';
    final String date = '${m['date'] ?? ''}';
    final double amt = dbl(m['amt']);
    final TVoucher? v = byKey[vk];
    if (v == null) {
      final int bar = vk.indexOf('|');
      final String firm = bar > 0 ? vk.substring(0, bar) : '';
      if (firms.contains(firm) && date.compareTo(fy) >= 0) {
        out.add(_Orphan(id, label, date, amt, 'missing', 0, ''));
      }
      continue;
    }
    if (v.cancelled) {
      out.add(_Orphan(id, label, date, amt, 'cancelled', 0, v.date));
      continue;
    }
    final List<TLine> lines = v.lines.isNotEmpty ? v.lines : <TLine>[TLine(v.party, v.amount)];
    if (li < lines.length) {
      final double ta = lines[li].amount;
      if ((ta - amt).abs() > 0.5 || v.date != date) {
        out.add(_Orphan(id, label, date, amt, 'changed', ta, v.date));
      }
    }
  }
  return out;
}

/// Forget the Tally link of this payment (it stays in Pro as a normal payment).
Future<void> _unlinkOrphan(String id) {
  return payDoc.commit(() {
    for (final Map<String, dynamic> m in payDoc.list('items')) {
      if ('${m['id'] ?? ''}' == id) {
        m.remove('tref');
      }
    }
  });
}

/// Makes the Pro payment the same as Tally now says.
Future<void> _syncOrphan(_Orphan o) {
  return payDoc.commit(() {
    for (final Map<String, dynamic> m in payDoc.list('items')) {
      if ('${m['id'] ?? ''}' == o.id) {
        m['amt'] = o.tallyAmt;
        m['date'] = o.tallyDate;
      }
    }
  });
}

// ==================================================== purchase check (mel)
class _MelRow {
  final String key;
  String name;
  final bool unknown;
  double app = 0;
  double tally = 0;
  int napp = 0;
  int ntally = 0;
  final List<Chit> chits = <Chit>[];
  final List<TVoucher> vs = <TVoucher>[];
  _MelRow(this.key, this.name, this.unknown);
  double get diff => tally - app;
  String get state {
    if (diff.abs() <= 2) return 'ok';
    if (napp == 0) return 'tally_only';
    if (ntally == 0) return 'app_only';
    return 'diff';
  }
}

class _MelDay {
  final String date;
  double app = 0;
  double tally = 0;
  int napp = 0;
  int ntally = 0;
  _MelDay(this.date);
  double get diff => tally - app;
  String get state {
    if (diff.abs() <= 2) return 'ok';
    if (napp == 0) return 'tally_only';
    if (ntally == 0) return 'app_only';
    return 'diff';
  }
}

class _Mel {
  final List<_MelRow> rows;
  final List<_MelDay> days;
  final double app;
  final double tally;
  final int noRate;
  final int nTally;
  const _Mel(this.rows, this.days, this.app, this.tally, this.noRate, this.nTally);
  double get diff => tally - app;
}

_Mel _buildMel(String firm, String from, String to, _Matcher mt) {
  final Map<String, _MelRow> rows = <String, _MelRow>{};
  final Map<String, _MelDay> days = <String, _MelDay>{};
  int noRate = 0;
  for (final Chit c in live.chits) {
    final String d = _dk(c.at);
    if (!_inRange(d, from, to)) continue;
    final String k = nameKey(c.farmer);
    if (k.isEmpty) continue;
    final double? amt = chitAmount(c);
    final _MelRow r = rows.putIfAbsent(k, () => _MelRow(k, c.farmer.trim(), false));
    r.napp++;
    r.chits.add(c);
    final _MelDay dd = days.putIfAbsent(d, () => _MelDay(d));
    dd.napp++;
    if (amt == null) {
      noRate++;
    } else {
      r.app += amt;
      dd.app += amt;
    }
  }
  int nt = 0;
  for (final TVoucher v in tallyStore.purchases) {
    if (v.cancelled || v.optional) continue;
    if (firm.isNotEmpty && v.firm != firm) continue;
    if (!_inRange(v.date, from, to)) continue;
    nt++;
    final _FMatch? m = mt.of(v.party);
    final String k = m == null ? 't:${_nk(v.party)}' : m.key;
    final String nm = m == null ? v.party : m.label;
    final _MelRow r = rows.putIfAbsent(k, () => _MelRow(k, nm, m == null));
    r.tally += v.amount;
    r.ntally++;
    r.vs.add(v);
    final _MelDay dd = days.putIfAbsent(v.date, () => _MelDay(v.date));
    dd.tally += v.amount;
    dd.ntally++;
  }
  final List<_MelRow> rl = rows.values.toList();
  rl.sort((_MelRow a, _MelRow b) {
    final int c = b.diff.abs().compareTo(a.diff.abs());
    return c != 0 ? c : a.name.toLowerCase().compareTo(b.name.toLowerCase());
  });
  final List<_MelDay> dl = days.values.toList();
  dl.sort((_MelDay a, _MelDay b) => b.date.compareTo(a.date));
  double sa = 0;
  double st = 0;
  for (final _MelRow r in rl) {
    sa += r.app;
    st += r.tally;
  }
  return _Mel(rl, dl, sa, st, noRate, nt);
}

// ============================================================ ageing
class _Ev {
  final String date;
  final double amt;
  final bool inc;
  const _Ev(this.date, this.amt, this.inc);
}

class _Bill {
  final String date;
  double left;
  _Bill(this.date, this.left);
}

class _AgeRow {
  final String firm;
  final String name;
  final double bal;
  final List<double> b;
  final int oldest;
  final String last;
  const _AgeRow(this.firm, this.name, this.bal, this.b, this.oldest, this.last);
}

/// Who owes us (debtors = true) or whom we owe: the open amount is split by
/// how old the bills are. Receipts / payments clear the oldest bill first.
List<_AgeRow> _buildAge(bool debtors, String firm) {
  final String today = _today();
  final Map<String, List<_Ev>> evs = <String, List<_Ev>>{};
  final Set<String> primary = <String>{};
  final Map<String, String> lastDec = <String, String>{};
  for (final TVoucher v in tallyStore.vouchers) {
    if (v.cancelled || v.optional) continue;
    if (firm.isNotEmpty && v.firm != firm) continue;
    int dir = 0;
    if (debtors) {
      if (v.base == 'sales') {
        dir = 1;
      } else if (v.base == 'payment') {
        dir = 1;
      } else if (v.base == 'receipt' || v.base == 'creditnote') {
        dir = -1;
      }
    } else {
      if (v.base == 'purchase') {
        dir = 1;
      } else if (v.base == 'receipt') {
        dir = 1;
      } else if (v.base == 'payment' || v.base == 'debitnote') {
        dir = -1;
      }
    }
    if (dir == 0) continue;
    final List<TLine> lines = v.lines.isNotEmpty ? v.lines : <TLine>[TLine(v.party, v.amount)];
    for (final TLine ln in lines) {
      if (ln.ledger.isEmpty || !(ln.amount > 0)) continue;
      final String key = '${v.firm}|${_nk(ln.ledger)}';
      evs.putIfAbsent(key, () => <_Ev>[]).add(_Ev(v.date, ln.amount, dir > 0));
      if (debtors ? v.base == 'sales' : v.base == 'purchase') primary.add(key);
      if (dir < 0 && (v.base == 'receipt' || v.base == 'payment')) {
        final String cur = lastDec[key] ?? '';
        if (v.date.compareTo(cur) > 0) lastDec[key] = v.date;
      }
    }
  }
  final List<_AgeRow> out = <_AgeRow>[];
  final String want = debtors ? 'debtor' : 'creditor';
  for (final TLedger l in tallyStore.ledgers) {
    if (firm.isNotEmpty && l.firm != firm) continue;
    final String key = '${l.firm}|${_nk(l.name)}';
    final double open = debtors ? -l.closing : l.closing;
    if (open < 0.5) continue;
    final String k = l.kind;
    if (!(k == want || (k == 'other' && primary.contains(key)))) continue;
    final List<_Ev> list = List<_Ev>.from(evs[key] ?? const <_Ev>[]);
    list.sort((_Ev a, _Ev b) {
      final int c = a.date.compareTo(b.date);
      if (c != 0) return c;
      if (a.inc == b.inc) return 0;
      return a.inc ? -1 : 1;
    });
    double incSum = 0;
    double decSum = 0;
    for (final _Ev e in list) {
      if (e.inc) {
        incSum += e.amt;
      } else {
        decSum += e.amt;
      }
    }
    final double opening = open - incSum + decSum;
    final List<_Bill> q = <_Bill>[];
    double credit = 0;
    if (opening > 0.5) {
      q.add(_Bill('', opening));
    } else if (opening < -0.5) {
      credit = -opening;
    }
    for (final _Ev e in list) {
      if (e.inc) {
        double a = e.amt;
        if (credit > 0) {
          final double u = credit < a ? credit : a;
          credit -= u;
          a -= u;
        }
        if (a > 0.005) q.add(_Bill(e.date, a));
      } else {
        double x = e.amt;
        while (x > 0.005 && q.isNotEmpty) {
          final _Bill b = q.first;
          final double u = b.left < x ? b.left : x;
          b.left -= u;
          x -= u;
          if (b.left <= 0.005) q.removeAt(0);
        }
        if (x > 0.005) credit += x;
      }
    }
    final List<double> bk = <double>[0, 0, 0, 0];
    int oldest = 0;
    double qs = 0;
    for (final _Bill b in q) {
      final int age = b.date.isEmpty ? 999 : _daysBetween(b.date, today);
      final int bi2 = age <= 30 ? 0 : (age <= 60 ? 1 : (age <= 90 ? 2 : 3));
      bk[bi2] += b.left;
      qs += b.left;
      if (age > oldest) oldest = age;
    }
    if (qs < open - 1) {
      bk[3] += open - qs;
      oldest = 999;
    } else if (qs > open + 1 && qs > 0) {
      final double f = open / qs;
      for (int i = 0; i < bk.length; i++) {
        bk[i] *= f;
      }
    }
    out.add(_AgeRow(l.firm, l.name, open, bk, oldest, lastDec[key] ?? ''));
  }
  out.sort((_AgeRow a, _AgeRow b) {
    final int c = b.oldest.compareTo(a.oldest);
    return c != 0 ? c : b.bal.compareTo(a.bal);
  });
  return out;
}

String _ageLabel(int days) {
  if (days >= 999) return bi('વર્ષ પહેલાનું', 'before this year');
  return '$days ${bi('દિવસ', 'days')}';
}

String _reminderText(String name, double amt, String since) {
  return bi(
    'નમસ્તે $name, તમારું ${_rs(amt)} બાકી છે (${dmy(DateTime.now())} સુધી${since.isEmpty ? '' : ', છેલ્લી આવક ${dmy(DateTime.tryParse(since) ?? DateTime.now())}'}). કૃપા કરીને ચૂકવણી કરશો. આભાર 🙏',
    'Hello $name, ${_rs(amt)} is pending from you (till ${dmy(DateTime.now())}${since.isEmpty ? '' : ', last payment ${dmy(DateTime.tryParse(since) ?? DateTime.now())}'}). Please pay at your earliest. Thank you 🙏',
  );
}

String _ageListText(List<_AgeRow> rows, bool debtors) {
  final StringBuffer b = StringBuffer();
  b.writeln('${debtors ? '🏪 *${bi('લેવાના બાકી', 'To receive')}*' : '🧑‍💼 *${bi('ચૂકવવાના બાકી', 'To pay')}*'} • ${dmy(DateTime.now())}');
  double tot = 0;
  int i = 0;
  for (final _AgeRow r in rows) {
    tot += r.bal;
    if (i < 40) {
      i++;
      b.writeln('$i. ${r.name} — ${_rs(r.bal)}${r.oldest > 0 ? ' (${_ageLabel(r.oldest)})' : ''}');
    }
  }
  b.writeln('*${bi('કુલ', 'Total')}: ${_rs(tot)}*');
  return b.toString().trimRight();
}

// ======================================================== bank book
class _BankEntry {
  final TVoucher v;
  final bool inn;
  final String who;
  const _BankEntry(this.v, this.inn, this.who);
}

List<String> _bankNames(Set<String> cash) {
  final Map<String, String> m = <String, String>{};
  final Map<String, int> n = <String, int>{};
  for (final TLedger l in tallyStore.ledgers) {
    if (l.kind == 'bank') m.putIfAbsent(_nk(l.name), () => l.name);
  }
  for (final TVoucher v in tallyStore.vouchers) {
    if (v.bank.isEmpty || v.cancelled || _isCashName(cash, v.bank)) continue;
    final String k = _nk(v.bank);
    m.putIfAbsent(k, () => v.bank);
    n[k] = (n[k] ?? 0) + 1;
  }
  final List<String> keys = m.keys.toList();
  keys.sort((String a, String b) => (n[b] ?? 0).compareTo(n[a] ?? 0));
  return <String>[for (final String k in keys) m[k] ?? k];
}

List<_BankEntry> _bankEntries(String bank, String firm, String from, String to) {
  final String bk = _nk(bank);
  final List<_BankEntry> out = <_BankEntry>[];
  for (final TVoucher v in tallyStore.vouchers) {
    if (v.cancelled || v.optional || !(v.amount > 0)) continue;
    if (firm.isNotEmpty && v.firm != firm) continue;
    if (!_inRange(v.date, from, to)) continue;
    final bool mine = _nk(v.bank) == bk;
    if (v.base == 'payment' && mine) {
      out.add(_BankEntry(v, false, v.party));
    } else if (v.base == 'receipt' && mine) {
      out.add(_BankEntry(v, true, v.party));
    } else if (v.base == 'contra') {
      if (mine) {
        out.add(_BankEntry(v, false, v.lines.isNotEmpty ? v.lines.first.ledger : ''));
      } else if (v.lines.any((TLine l) => _nk(l.ledger) == bk)) {
        out.add(_BankEntry(v, true, v.bank));
      }
    }
  }
  out.sort((_BankEntry a, _BankEntry b) {
    final int c = b.v.date.compareTo(a.v.date);
    return c != 0 ? c : b.v.id.compareTo(a.v.id);
  });
  return out;
}

// ============================================================== GST
final RegExp _taxName = RegExp(r'gst|cess', caseSensitive: false);

class _GstMonth {
  final String ym;
  double outTax = 0;
  double inTax = 0;
  double outBase = 0;
  double inBase = 0;
  int n = 0;
  _GstMonth(this.ym);
}

class _Gst {
  final List<_GstMonth> months;
  final Map<String, double> outBy;
  final Map<String, double> inBy;
  final int noLines;
  final int total;
  const _Gst(this.months, this.outBy, this.inBy, this.noLines, this.total);
  double get outTax {
    double t = 0;
    for (final _GstMonth m in months) {
      t += m.outTax;
    }
    return t;
  }

  double get inTax {
    double t = 0;
    for (final _GstMonth m in months) {
      t += m.inTax;
    }
    return t;
  }

  double get outBase {
    double t = 0;
    for (final _GstMonth m in months) {
      t += m.outBase;
    }
    return t;
  }

  double get inBase {
    double t = 0;
    for (final _GstMonth m in months) {
      t += m.inBase;
    }
    return t;
  }
}

_Gst _buildGst(String firm, String from, String to) {
  final Map<String, _GstMonth> ms = <String, _GstMonth>{};
  final Map<String, double> outBy = <String, double>{};
  final Map<String, double> inBy = <String, double>{};
  int noLines = 0;
  int total = 0;
  for (final TVoucher v in tallyStore.vouchers) {
    if (v.cancelled || v.optional || !(v.amount > 0)) continue;
    final bool isOut = v.base == 'sales' || v.base == 'creditnote';
    final bool isIn = v.base == 'purchase' || v.base == 'debitnote';
    if (!isOut && !isIn) continue;
    if (firm.isNotEmpty && v.firm != firm) continue;
    if (!_inRange(v.date, from, to)) continue;
    total++;
    double tax = 0;
    for (final TLine o in v.other) {
      if (_taxName.hasMatch(o.ledger)) {
        tax += o.amount;
        final Map<String, double> by = isOut ? outBy : inBy;
        by[o.ledger] = (by[o.ledger] ?? 0) + (v.base == 'creditnote' || v.base == 'debitnote' ? -o.amount : o.amount);
      }
    }
    if (v.other.isEmpty) noLines++;
    final double sign = (v.base == 'creditnote' || v.base == 'debitnote') ? -1 : 1;
    final String ym = v.date.length >= 7 ? v.date.substring(0, 7) : v.date;
    final _GstMonth m = ms.putIfAbsent(ym, () => _GstMonth(ym));
    m.n++;
    final double base = v.amount - tax;
    if (isOut) {
      m.outTax += sign * tax;
      m.outBase += sign * base;
    } else {
      m.inTax += sign * tax;
      m.inBase += sign * base;
    }
  }
  final List<_GstMonth> list = ms.values.toList();
  list.sort((_GstMonth a, _GstMonth b) => b.ym.compareTo(a.ym));
  return _Gst(list, outBy, inBy, noLines, total);
}

// ============================================================ checks
class _ChkRow {
  final String firm;
  final String party;
  final String date;
  double amount = 0;
  final List<TVoucher> vs = <TVoucher>[];
  _ChkRow(this.firm, this.party, this.date);
}

/// Cash received (receipts = true) or paid in one day to one party, above [minAmt].
List<_ChkRow> _cashGroups(bool receipts, double minAmt, bool orMore, String firm, String from, String to) {
  final Set<String> cash = _cashSet();
  final Map<String, _ChkRow> m = <String, _ChkRow>{};
  for (final TVoucher v in tallyStore.vouchers) {
    if (v.cancelled || v.optional || !(v.amount > 0)) continue;
    if (v.base != (receipts ? 'receipt' : 'payment')) continue;
    if (firm.isNotEmpty && v.firm != firm) continue;
    if (!_inRange(v.date, from, to)) continue;
    if (!(v.mode == 'cash' || _isCashName(cash, v.bank))) continue;
    final List<TLine> lines = v.lines.isNotEmpty ? v.lines : <TLine>[TLine(v.party, v.amount)];
    for (final TLine ln in lines) {
      if (ln.ledger.isEmpty) continue;
      final String k = '${v.firm}|${_nk(ln.ledger)}|${v.date}';
      final _ChkRow r = m.putIfAbsent(k, () => _ChkRow(v.firm, ln.ledger, v.date));
      r.amount += ln.amount;
      r.vs.add(v);
    }
  }
  final List<_ChkRow> out = <_ChkRow>[];
  for (final _ChkRow r in m.values) {
    if (orMore ? r.amount >= minAmt : r.amount > minAmt) out.add(r);
  }
  out.sort((_ChkRow a, _ChkRow b) {
    final int c = b.date.compareTo(a.date);
    return c != 0 ? c : b.amount.compareTo(a.amount);
  });
  return out;
}

class _YearRow {
  final String firm;
  final String party;
  double total = 0;
  _YearRow(this.firm, this.party);
}

/// Purchases of this financial year per party (debit notes taken off).
List<_YearRow> _yearPurchases(String firm) {
  final Map<String, _YearRow> m = <String, _YearRow>{};
  for (final TVoucher v in tallyStore.allVouchers) {
    if (v.cancelled || v.optional || v.party.isEmpty) continue;
    if (v.base != 'purchase' && v.base != 'debitnote') continue;
    if (firm.isNotEmpty && v.firm != firm) continue;
    final _YearRow r = m.putIfAbsent('${v.firm}|${_nk(v.party)}', () => _YearRow(v.firm, v.party));
    r.total += v.base == 'purchase' ? v.amount : -v.amount;
  }
  final List<_YearRow> out = m.values.toList();
  out.sort((_YearRow a, _YearRow b) => b.total.compareTo(a.total));
  return out;
}

/// Same party, same day, same amount, same kind - more than once.
List<List<TVoucher>> _dupGroups(String firm) {
  final Map<String, List<TVoucher>> m = <String, List<TVoucher>>{};
  for (final TVoucher v in tallyStore.vouchers) {
    if (v.cancelled || v.optional || !(v.amount > 0)) continue;
    if (firm.isNotEmpty && v.firm != firm) continue;
    final String k = '${v.firm}|${v.base}|${_nk(v.party)}|${v.date}|${v.amount.round()}';
    m.putIfAbsent(k, () => <TVoucher>[]).add(v);
  }
  final List<List<TVoucher>> out = <List<TVoucher>>[];
  for (final List<TVoucher> g in m.values) {
    if (g.length >= 2) out.add(g);
  }
  out.sort((List<TVoucher> a, List<TVoucher> b) => b.first.date.compareTo(a.first.date));
  return out;
}

// ============================================================ alerts
class _Alert {
  final String tone;
  final String icon;
  final String text;
  final String sub;
  final int tab;
  const _Alert(this.tone, this.icon, this.text, this.sub, this.tab);
}

List<_Alert> _buildAlerts(String firm) {
  final List<_Alert> out = <_Alert>[];
  if (tallyStore.vouchers.isEmpty && tallyStore.ledgers.isEmpty) return out;
  final _Matcher mt = _matcher();
  final String t = _today();

  int wait = 0;
  for (final _Plan p in _buildPlan(mt)) {
    if (firm.isNotEmpty && p.v.firm != firm) continue;
    if (p.state == 'ready' || p.state == 'review') wait++;
  }
  if (wait > 0) {
    out.add(_Alert('amber', 'pay', bi('$wait Tally ચૂકવણી ખેડૂત ખાતામાં નાખવાની / ચકાસવાની બાકી', '$wait Tally payments to add / check in farmer khata'), bi('Tally માં ચૂકવ્યા પણ Pro ના ખેડૂત ખાતામાં નથી', 'Paid in Tally but not in the Pro farmer khata'), 8));
  }

  final String f7 = _dk(DateTime.now().subtract(const Duration(days: 7)));
  final _Mel mel = _buildMel(firm, f7, t, mt);
  if (mel.nTally > 0) {
    int bad = 0;
    for (final _MelRow r in mel.rows) {
      if (r.state != 'ok') bad++;
    }
    if (bad > 0) {
      out.add(_Alert('amber', 'cmp', bi('ખરીદી મેળમાં $bad ફરક (છેલ્લા 7 દિવસ)', '$bad purchase differences (last 7 days)'), bi('Pro નો હિસાબ અને Tally ની ખરીદી મળતી નથી', 'Pro hisab and Tally purchase do not match'), 7));
    }
  }

  for (final TLedger l in tallyStore.ledgers) {
    if (l.kind != 'cash' || l.closing <= 0.5) continue;
    if (firm.isNotEmpty && l.firm != firm) continue;
    out.add(_Alert('rose', 'warn', bi('${firmName(l.firm)}: રોકડ ખાતું માઇનસ (Cr ${_rs(l.closing)})', '${firmName(l.firm)}: cash ledger is negative (Cr ${_rs(l.closing)})'), bi('Tally માં રોકડ કરતાં વધારે ચૂકવણી ચડી છે - એન્ટ્રી તપાસો', 'More cash paid than cash in hand in Tally - check the entries'), 2));
  }

  final List<_ChkRow> big = _cashGroups(true, 200000, true, firm, TallyStore.fyStart(), '');
  if (big.isNotEmpty) {
    out.add(_Alert('amber', 'warn', bi('રોકડ ₹2 લાખ કે વધુ એક પાર્ટી પાસેથી એક દિવસમાં: ${big.length} વાર', 'Cash of Rs 2 lakh or more from one party in a day: ${big.length} times'), bi('કલમ 269ST - CA ને પૂછો', 'Section 269ST - ask your CA'), 10));
  }

  final List<_AgeRow> age = _buildAge(true, firm);
  int old = 0;
  double oldAmt = 0;
  for (final _AgeRow r in age) {
    if (r.oldest >= 60 && r.bal >= 1000) {
      old++;
      oldAmt += r.bal;
    }
  }
  if (old > 0) {
    out.add(_Alert('amber', 'bank', bi('$old ખરીદનારનું ${_rs(oldAmt)} 60+ દિવસથી બાકી', '$old buyers owe ${_rs(oldAmt)} for 60+ days'), bi('ઉઘરાણી કરો - યાદી WhatsApp પર મોકલી શકાય', 'Time to collect - the list can go on WhatsApp'), 6));
  }

  final int dups = _dupGroups(firm).length;
  if (dups > 0) {
    out.add(_Alert('blue', 'copy', bi('$dups સરખા વાઉચર (એક જ પાર્ટી, દિવસ, રકમ)', '$dups look-alike vouchers (same party, day, amount)'), bi('ભૂલથી બે વાર ચડી ગયું હોય તો જુઓ', 'Check if one was entered twice by mistake'), 10));
  }
  return out;
}
