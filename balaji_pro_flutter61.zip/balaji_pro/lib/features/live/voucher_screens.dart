import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/app_state.dart';
import '../../core/errlog.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/books.dart';
import '../../data/contra.dart' show ContraItem, contraBankName, removeContra;
import '../../data/engine.dart';
import '../../data/insights.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../data/money.dart';
import '../../data/owner_docs.dart';
import '../../data/trade.dart';
import '../../data/vno.dart';
import '../../data/vouchers.dart';
import '../../widgets/accept.dart';
import '../../widgets/common.dart';
import '../../widgets/dayfield.dart';
import '../../widgets/keys.dart';
import '../../widgets/page.dart';
import '../../widgets/printer.dart';
import 'field.dart';
import 'kit.dart';
import 'kit2.dart';
import 'money_screens.dart';
import 'contra_screens.dart' show openContraForm;
import 'note_screens.dart' show openNoteForm;
import 'trade_screens.dart';
import 'ui.dart';
import 'tally_data.dart' show TallyWhat, tallyStrip;

// ======================================================================
// Vouchers, Day Book, Ledger and Trial Balance - laid out like TallyPrime
//   Date | Particulars | Vch Type | Vch No. | Debit | Credit
// ======================================================================

/// "P-12" (the number with the letter of its voucher type); a purchase chit shows its chit number.
String vchNoText(Vch v) {
  if (v.src == 'chit') return v.chitNo.isEmpty ? '' : '#${v.chitNo}';
  return v.no > 0 ? '${v.vt.letter}-${v.no}' : '';
}

/// The balance of the party of a voucher right now, as Tally writes it ("12,500.00 Cr").
String curBalText(Vch v) {
  if (v.dim == 'farmer') {
    final FarmerAcct? a = farmerAccts()[v.partyKey];
    return a == null ? '' : tCr(a.balance);
  }
  if (v.dim == 'buyer') {
    final BuyerAcct? a = buyerAccts()[v.partyKey];
    return a == null ? '' : tDr(a.balance);
  }
  return '';
}

Color _typeColor(String type) {
  switch (type) {
    case 'PAY':
      return Pal.warn;
    case 'RCT':
      return Pal.ok;
    case 'SAL':
      return Pal.brand;
    case 'PUR':
      return Pal.info;
    case 'EXP':
      return Pal.bad;
    case 'INC':
      return Pal.ok;
    case 'CON':
      return Pal.violet;
    default:
      return Pal.muted;
  }
}

String _periodText(Period p) => '${tDateFull(p.from)} ${bi('થી', 'to')} ${tDateFull(p.lastDay)}';

/// Export a CSV: a file that opens in Excel on the PC, copied text on the phone.
Future<void> exportCsvOut(String csv, String name) async {
  final String path = await saveCsvFile(csv, name);
  if (path.isNotEmpty) {
    app.toast('${bi('Excel ફાઇલ બની', 'Excel file saved')}: $path');
  } else {
    copyText(csv, msg: bi('કૉપિ થયું - Excel માં પેસ્ટ કરો', 'Copied - paste into Excel'));
  }
}

Future<void> printOut(String html, String name) async {
  final bool ok = await printHtml(html, name);
  if (!ok) app.toast(bi('પ્રિન્ટ પેજ ખૂલ્યું નહીં', 'Could not open the print page'));
}

// ======================================================================
// Expense / income voucher
// ======================================================================

/// [edit] opens an existing voucher for alteration (Alt+D deletes it); [copy] starts a new voucher from an old one.
Future<void> openExpForm(BuildContext context, {ExpItem? edit, ExpItem? copy, String? cat}) {
  return openPanel(
    context,
    title: edit == null ? bi('ખર્ચ / આવક વાઉચર', 'Expense / income voucher') : bi('વાઉચર સુધારો (Alter)', 'Voucher alteration'),
    sub: edit == null ? null : dmy(edit.date),
    width: 460,
    page: true,
    child: ExpForm(edit: edit, copy: copy, cat: cat),
  );
}

class ExpForm extends StatefulWidget {
  final ExpItem? edit;
  final ExpItem? copy;

  /// Opens a new voucher on this expense head (for example the GST payment from the GSTR-1 screen).
  final String? cat;
  const ExpForm({super.key, this.edit, this.copy, this.cat});

  @override
  State<ExpForm> createState() => _ExpFormState();
}

class _ExpFormState extends State<ExpForm> {
  late final VoidCallback _accept = () {
    _save();
  };
  late final VoidCallback _del = () {
    _delete();
  };
  late final VoidCallback _prn = () {
    _print();
  };

  final TextEditingController _amt = TextEditingController();
  final TextEditingController _note = TextEditingController();
  final TextEditingController _ref = TextEditingController();
  int _kind = 0; // 0 expense, 1 income
  int _cat = 0;
  int _mode = 0;
  DateTime _day = dateOnly(DateTime.now());
  bool _busy = false;
  String _err = '';

  List<List<String>> get _cats => _kind == 0 ? kExpCatsShown : kInCats;

  @override
  void initState() {
    super.initState();
    AcceptHub.push(_accept);
    final ExpItem? src = widget.edit ?? widget.copy;
    if (src != null) {
      _kind = src.isIn ? 1 : 0;
      final int c = _cats.indexWhere((List<String> k) => k[0] == src.cat);
      _cat = c < 0 ? 0 : c;
      final int m = kPayModes.indexWhere((List<String> k) => k[0] == src.mode);
      _mode = m < 0 ? 0 : m;
      _amt.text = plainNum(src.amt);
      _note.text = src.note;
      if (widget.edit != null) {
        _day = src.date;
        _ref.text = src.ref;
      }
    } else if (widget.cat != null) {
      final int c = _cats.indexWhere((List<String> k) => k[0] == widget.cat);
      if (c >= 0) _cat = c;
    }
    if (widget.edit != null) {
      deleteHub.push(_del);
      printHub.push(_prn);
      ensureVoucherNumbers();
    }
  }

  @override
  void dispose() {
    _amt.dispose();
    _note.dispose();
    _ref.dispose();
    AcceptHub.pop(_accept);
    deleteHub.pop(_del);
    printHub.pop(_prn);
    super.dispose();
  }

  Future<void> _delete() async {
    final ExpItem? e = widget.edit;
    if (e == null || _busy) return;
    final bool go = await confirmBox(context, title: bi('આ વાઉચર કાઢી નાખવું?', 'Delete this voucher?'), text: bi('આ નોંધ કાયમ માટે કાઢી નંખાશે.', 'This entry will be removed for good.'), yes: bi('હા, કાઢો', 'Yes, delete'), no: bi('ના', 'No'));
    if (!go || !mounted) return;
    await removeExpItem(e.id);
    app.toast(bi('વાઉચર કાઢ્યું', 'Voucher deleted'));
    if (mounted) Navigator.of(context).pop();
  }

  Future<void> _print() async {
    final ExpItem? e = widget.edit;
    if (e == null) return;
    final Vch? v = voucherById('exp', e.id);
    if (v == null) return;
    await printOut(voucherHtml(v), 'voucher-${e.id}');
  }

  Future<void> _save() async {
    final double amt = dbl(_amt.text.replaceAll(',', ''));
    if (amt <= 0) {
      setState(() => _err = bi('સાચી રકમ લખો', 'Enter a valid amount'));
      return;
    }
    if (_busy) return;
    setState(() {
      _busy = true;
      _err = '';
    });
    final String cat = _cats[_cat][0];
    final String kind = _kind == 0 ? 'out' : 'in';
    final String mode = kPayModes[_mode][0];
    final ExpItem? ed = widget.edit;
    if (ed != null) {
      final bool saved = await ErrLog.attempt('Save', () => updateExpItem(ed.id, amt: amt, cat: cat, kind: kind, mode: mode, date: _day, note: _note.text, ref: mode == 'cash' ? '' : _ref.text));
      if (!saved) {
        if (mounted) setState(() => _busy = false);
        return;
      }
      app.toast('${bi('વાઉચર સુધાર્યું', 'Voucher altered')} · ${inr(amt)}');
      if (mounted) Navigator.of(context).pop();
      return;
    }
    final bool added = await ErrLog.attempt('Save', () => addExpItem(amt: amt, cat: cat, kind: kind, mode: mode, date: _day, note: _note.text, ref: mode == 'cash' ? '' : _ref.text));
    if (!added) {
      if (mounted) setState(() => _busy = false);
      return;
    }
    app.toast('${_kind == 0 ? bi('ખર્ચ', 'Expense') : bi('આવક', 'Income')} · ${inr(amt)}');
    if (!mounted) return;
    if (Pal.tally && app.stagePc && widget.copy == null) {
      // like TallyPrime: the voucher stays open, blank, for the next entry (Esc closes it)
      setState(() {
        _busy = false;
        _amt.clear();
        _note.clear();
        _ref.clear();
      });
      KeyScopeState.refocusFrom(context);
      return;
    }
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final ExpItem? ed = widget.edit;
    final VType vt = vTypeOf(expCode(_kind == 0 ? 'out' : 'in'));
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        VoucherHead(
          type: vt.name,
          no: ed != null ? (ed.no > 0 ? '${vt.letter}-${ed.no}' : '') : '${vt.letter}-${nextVoucherNo(vt.code)}',
          date: _day,
          sub: ed == null ? bi('નવું વાઉચર', 'Creation') : bi('સુધારો (Alteration)', 'Alteration'),
        ),
        if (ed == null)
          Seg(
            labels: <String>[bi('ખર્ચ (જાવક)', 'Expense (out)'), bi('આવક (આવ્યા)', 'Income (in)')],
            index: _kind,
            onChanged: (int i) => setState(() {
              _kind = i;
              _cat = 0;
            }),
          ),
        if (ed == null) const SizedBox(height: 12),
        ChipRow(labels: <String>[for (final List<String> k in _cats) bi(k[1], k[2])], index: _cat, onChanged: (int i) => setState(() => _cat = i)),
        const SizedBox(height: 12),
        FieldX(label: '${bi('રકમ', 'Amount')} *', controller: _amt, big: true, prefix: '₹', keyboard: const TextInputType.numberWithOptions(decimal: true)),
        const SizedBox(height: 12),
        LineRow(
          label: bi('કેવી રીતે', 'How'),
          child: ChipRow(labels: <String>[for (final List<String> k in kPayModes) bi(k[1], k[2])], index: _mode, onChanged: (int i) => setState(() => _mode = i)),
        ),
        if (kPayModes[_mode][0] != 'cash') ...<Widget>[
          const SizedBox(height: 12),
          FieldX(label: kPayModes[_mode][0] == 'cheque' ? bi('ચેક નંબર', 'Cheque no.') : bi('UTR / રેફ નંબર', 'UTR / Ref no.'), controller: _ref),
        ],
        const SizedBox(height: 12),
        DayField(label: bi('તારીખ', 'Date'), value: _day, last: dateOnly(DateTime.now()), onChanged: (DateTime d) => setState(() => _day = d)),
        const SizedBox(height: 12),
        FieldX(label: bi('નોંધ / Narration', 'Narration'), controller: _note),
        const SizedBox(height: 14),
        if (_err.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(_err, style: ts(13, w: FontWeight.w700, c: Pal.bad))),
        _busy
            ? SizedBox(height: 52, child: Center(child: SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 2.6, color: Pal.brand))))
            : Btn(ed == null ? bi('સેવ કરો', 'Save') : bi('સુધારો સેવ કરો', 'Save alteration'), icon: 'check', expand: true, onTap: _save),
        if (ed != null) ...<Widget>[
          const SizedBox(height: 8),
          Row(
            children: <Widget>[
              tExp(child: Btn(bi('પ્રિન્ટ (Ctrl+P)', 'Print (Ctrl+P)'), icon: 'print', kind: BtnKind.tonal, dense: true, tabStop: false, onTap: _print)),
              const SizedBox(width: 8),
              tExp(child: Btn(bi('કાઢો (Alt+D)', 'Delete (Alt+D)'), icon: 'trash', kind: BtnKind.danger, dense: true, tabStop: false, onTap: _delete)),
            ],
          ),
        ],
      ],
    );
  }
}

// ======================================================================
// One voucher: look, alter, duplicate, print, ledger, delete
// ======================================================================

/// Opens the form of a voucher for alteration (or, with [copy], a new voucher made from it). [host] is the screen's context.
void alterVoucher(BuildContext host, Vch v, {bool copy = false}) {
  final Object? r = v.raw;
  if (v.src == 'pay' && r is PayItem) {
    if (r.jt == 'dn') {
      openNoteForm(host, credit: false, editPay: copy ? null : r, copyPay: copy ? r : null);
    } else {
      openPayForm(host, kind: r.kind, edit: copy ? null : r, copy: copy ? r : null);
    }
  } else if (v.src == 'sale' && r is SaleItem) {
    if (r.jt == 'cn') {
      openNoteForm(host, credit: true, editSale: copy ? null : r, copySale: copy ? r : null);
    } else {
      openSaleForm(host, kind: r.kind, edit: copy ? null : r, copy: copy ? r : null);
    }
  } else if (v.src == 'exp' && r is ExpItem) {
    openExpForm(host, edit: copy ? null : r, copy: copy ? r : null);
  } else if (v.src == 'contra' && r is ContraItem) {
    openContraForm(host, edit: copy ? null : r, copy: copy ? r : null);
  }
}

/// Opens a voucher: a purchase chit shows the chit; every other voucher shows its panel with Alter / Duplicate / Print / Ledger / Delete.
Future<void> openVoucher(BuildContext context, Vch v) {
  final Object? r = v.raw;
  if (v.src == 'chit') {
    if (r is Chit) return showChitDetail(context, r);
    return Future<void>.value();
  }
  if (v.src == 'sale' && r is SaleItem && r.jt != 'cn') return openSaleDetail(context, r);
  return openPanel(
    context,
    title: v.party,
    sub: '${tDate(v.date)} · ${v.vt.name}',
    width: 460,
    page: true,
    child: VoucherPanel(v, host: context),
  );
}

class VoucherPanel extends StatelessWidget {
  final Vch v;
  final BuildContext host;
  const VoucherPanel(this.v, {super.key, required this.host});

  @override
  Widget build(BuildContext context) {
    final String bal = curBalText(v);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        VoucherHead(type: v.vt.name, no: vchNoText(v), date: v.date, sub: v.party),
        InfoRow(bi('પ્રકાર', 'Type'), v.vt.name),
        if (vchNoText(v).isNotEmpty) InfoRow(bi('વાઉચર નં.', 'Vch No.'), vchNoText(v)),
        InfoRow(bi('વિગત', 'Particulars'), v.party, bold: true),
        InfoRow(bi('રકમ', 'Amount'), '${tAmt(v.amt)} ${v.dr > 0 ? 'Dr' : 'Cr'}', bold: true, color: Pal.brand),
        if (v.contra.isNotEmpty) InfoRow(bi('સામેનું ખાતું', 'Against'), v.contra),
        if (v.ref.isNotEmpty) InfoRow(v.mode == 'cheque' ? bi('ચેક નંબર', 'Cheque no.') : 'UTR / Ref', v.ref),
        if (v.note.isNotEmpty) InfoRow(bi('નોંધ', 'Narration'), v.note),
        if (bal.isNotEmpty) InfoRow(bi('હાલનું બાકી', 'Cur Bal'), bal),
        const SizedBox(height: 14),
        VoucherActions(v, host: host),
      ],
    );
  }
}

/// The buttons (and keys) of an open voucher: Enter / A alter, C duplicate, P print, L ledger, D delete.
class VoucherActions extends StatefulWidget {
  final Vch v;
  final BuildContext host;
  const VoucherActions(this.v, {super.key, required this.host});

  @override
  State<VoucherActions> createState() => _VoucherActionsState();
}

class _VoucherActionsState extends State<VoucherActions> {
  late final VoidCallback _del = () {
    _delete();
  };
  late final VoidCallback _prn = () {
    _print();
  };

  @override
  void initState() {
    super.initState();
    deleteHub.push(_del);
    printHub.push(_prn);
  }

  @override
  void dispose() {
    deleteHub.pop(_del);
    printHub.pop(_prn);
    super.dispose();
  }

  void _alter({bool copy = false}) {
    final BuildContext host = widget.host;
    Navigator.of(context).pop();
    if (host.mounted) alterVoucher(host, widget.v, copy: copy);
  }

  void _ledger() {
    final Vch v = widget.v;
    Navigator.of(context).pop();
    app.go('my_ledger', arg: LedgerRef(v.dim, v.partyKey, v.party));
  }

  Future<void> _print() async {
    await printOut(voucherHtml(widget.v, curBal: curBalText(widget.v)), 'voucher-${widget.v.id}');
  }

  Future<void> _delete() async {
    final Vch v = widget.v;
    final bool go = await confirmBox(
      context,
      title: bi('આ વાઉચર કાઢી નાખવું?', 'Delete this voucher?'),
      text: bi('આ નોંધ કાયમ માટે કાઢી નંખાશે અને ખાતા (અને સ્ટોક) બદલાશે.', 'The entry is removed for good and the ledgers (and stock) change.'),
      yes: bi('હા, કાઢો', 'Yes, delete'),
      no: bi('ના', 'No'),
    );
    if (!go || !mounted) return;
    if (v.src == 'pay') {
      await removePayItem(v.id);
    } else if (v.src == 'sale') {
      await removeSale(v.id);
    } else if (v.src == 'exp') {
      await removeExpItem(v.id);
    } else if (v.src == 'contra') {
      await removeContra(v.id);
    }
    app.toast(bi('વાઉચર કાઢ્યું', 'Voucher deleted'));
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final bool partyLedger = widget.v.partyKey.isNotEmpty;
    return Focus(
      autofocus: true,
      // Enter alters the voucher - but only while no button has the cursor (on a button Enter presses that button)
      onKeyEvent: (FocusNode node, KeyEvent e) {
        if (e is KeyDownEvent && node.hasPrimaryFocus && (e.logicalKey == LogicalKeyboardKey.enter || e.logicalKey == LogicalKeyboardKey.numpadEnter)) {
          _alter();
          return KeyEventResult.handled;
        }
        return KeyEventResult.ignored;
      },
      child: CallbackShortcuts(
        bindings: <ShortcutActivator, VoidCallback>{
          const SingleActivator(LogicalKeyboardKey.keyA): () => _alter(),
          const SingleActivator(LogicalKeyboardKey.keyC): () => _alter(copy: true),
          const SingleActivator(LogicalKeyboardKey.keyP): () {
            _print();
          },
          const SingleActivator(LogicalKeyboardKey.keyL): () {
            if (partyLedger) _ledger();
          },
          const SingleActivator(LogicalKeyboardKey.keyD): () {
            _delete();
          },
        },
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Row(
              children: <Widget>[
                tExp(child: Btn(bi('સુધારો (A)', 'Alter (A)'), icon: 'edit', onTap: _alter)),
                const SizedBox(width: 8),
                tExp(child: Btn(bi('નકલ (C)', 'Duplicate (C)'), icon: 'copy', kind: BtnKind.tonal, onTap: () => _alter(copy: true))),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: <Widget>[
                tExp(child: Btn(bi('પ્રિન્ટ (P)', 'Print (P)'), icon: 'print', kind: BtnKind.outline, dense: true, onTap: _print)),
                const SizedBox(width: 8),
                if (partyLedger) ...<Widget>[
                  tExp(child: Btn(bi('ખાતું (L)', 'Ledger (L)'), icon: 'ledger', kind: BtnKind.outline, dense: true, onTap: _ledger)),
                  const SizedBox(width: 8),
                ],
                tExp(child: Btn(bi('કાઢો (D)', 'Delete (D)'), icon: 'trash', kind: BtnKind.danger, dense: true, onTap: _delete)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ======================================================================
// Table pieces shared by Day Book and Ledger
// ======================================================================

List<PcCol> _vcols() => <PcCol>[
      PcCol(bi('તારીખ', 'Date'), 92),
      PcCol(bi('વિગત (Particulars)', 'Particulars'), 0),
      PcCol(bi('વાઉચર પ્રકાર', 'Vch Type'), 118),
      PcCol(bi('વાઉચર નં.', 'Vch No.'), 84),
      PcCol(bi('ઉધાર (Debit)', 'Debit'), 128, right: true),
      PcCol(bi('જમા (Credit)', 'Credit'), 128, right: true),
    ];

Widget _particulars(String main, String small, {bool bold = true}) {
  return Text.rich(
    TextSpan(
      children: <InlineSpan>[
        TextSpan(text: main, style: ts(12.5, w: bold ? FontWeight.w800 : FontWeight.w600)),
        if (small.isNotEmpty) TextSpan(text: '    $small', style: ts(11.5, c: Pal.muted)),
      ],
    ),
    maxLines: 1,
    overflow: TextOverflow.ellipsis,
  );
}

/// One voucher as a table row. [ledger]: the Particulars is the other account (Cash, Sales...) like a Tally ledger.
Widget _vRow(BuildContext ctx, Vch v, bool showDate, List<PcCol> cols, {bool ledger = false}) {
  final String note = v.note.isEmpty ? '' : v.note;
  final String main = ledger ? (v.contra.isEmpty ? v.party : v.contra) : v.party;
  return pcRow(
    cols,
    <Widget>[
      pcTd(showDate ? tDate(v.date) : '', num: true),
      _particulars(main, note),
      pcTd(v.vt.name),
      pcTd(vchNoText(v), num: true),
      pcTd(tAmt(v.dr), num: true, bold: true),
      v.noRate ? pcTd(bi('ભાવ નથી', 'no rate'), c: Pal.warn, bold: true) : pcTd(tAmt(v.cr), num: true, bold: true),
    ],
    bar: _typeColor(v.type),
    onTap: () => openVoucher(ctx, v),
  );
}

Widget _vTile(BuildContext ctx, Vch v, {bool ledger = false}) {
  final String main = ledger ? (v.contra.isEmpty ? v.party : v.contra) : v.party;
  final bool dr = v.dr > 0;
  return lineItem(
    icon: v.type == 'SAL' || v.type == 'PUR' ? 'receipt' : (v.type == 'JRN' ? 'book' : (v.type == 'CON' ? 'bank' : 'rupee')),
    tone: v.type == 'PAY' ? 'amber' : (v.type == 'EXP' ? 'rose' : (v.type == 'SAL' ? 'teal' : (v.type == 'JRN' ? 'slate' : (v.type == 'CON' ? 'violet' : 'green')))),
    title: main,
    sub: '${tDate(v.date)} · ${v.vt.name}${vchNoText(v).isEmpty ? '' : ' · ${vchNoText(v)}'}${v.note.isEmpty ? '' : ' · ${v.note}'}',
    trailing: v.noRate ? bi('ભાવ નથી', 'no rate') : '${tAmt(v.amt)} ${dr ? 'Dr' : 'Cr'}',
    trailingColor: v.noRate ? Pal.warn : null,
    onTap: () => openVoucher(ctx, v),
  );
}

Widget _grandRow(List<PcCol> cols, String label, String dr, String cr, {int labelAt = 1}) {
  return pcTotal(cols, label, labelAt: labelAt, vals: <int, String>{if (dr.isNotEmpty) cols.length - 2: dr, if (cr.isNotEmpty) cols.length - 1: cr});
}

class _Tot {
  final double dr;
  final double cr;
  const _Tot(this.dr, this.cr);
}

/// Both columns of a ledger end with the same total: the closing balance sits on the smaller side.
_Tot _ledgerGrand(Ledger g) {
  final double c = g.closing;
  final double dr = (g.opening > 0 ? g.opening : 0) + g.dr + (c < 0 ? -c : 0);
  final double cr = (g.opening < 0 ? -g.opening : 0) + g.cr + (c > 0 ? c : 0);
  return _Tot(dr, cr);
}

/// A list of vouchers as a TallyPrime register on the PC (head, rows, Grand Total); simple lines on the phone.
List<Widget> voucherTable(BuildContext ctx, List<Vch> l, {int cap = 500}) {
  if (l.isEmpty) return const <Widget>[];
  double dr = 0;
  double cr = 0;
  for (final Vch v in l) {
    dr += v.dr;
    cr += v.cr;
  }
  if (!app.stagePc) {
    return <Widget>[for (final Vch v in l.take(cap)) _vTile(ctx, v)];
  }
  final List<PcCol> cols = _vcols();
  final List<Widget> out = <Widget>[pcHead(cols)];
  String last = '';
  for (final Vch v in l.take(cap)) {
    final String d = dayKey(v.date);
    out.add(_vRow(ctx, v, d != last, cols));
    last = d;
  }
  out.add(_grandRow(cols, bi('કુલ (Grand Total)', 'Grand Total'), tAmt(dr), tAmt(cr)));
  if (l.length > cap) out.add(caption(bi('પહેલા $cap વાઉચર દેખાય છે - પીરિયડ નાનો કરો', 'First $cap vouchers shown - narrow the period')));
  return out;
}

/// "Ledger Vouchers" of TallyPrime: Opening Balance, the vouchers, Current Total, Closing Balance and the grand total (PC);
/// a short summary and lines on the phone.
List<Widget> ledgerTable(BuildContext ctx, Ledger g, {int cap = 800}) {
  final double c = g.closing;
  final _Tot t = _ledgerGrand(g);
  if (!app.stagePc) {
    return <Widget>[
      Surface(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: <Widget>[
            InfoRow(bi('શરૂઆતનું બાકી', 'Opening Balance'), g.opening.abs() < 0.005 ? '0.00' : tDr(g.opening)),
            InfoRow(bi('ઉધાર (Debit)', 'Debit'), tAmt(g.dr).isEmpty ? '0.00' : tAmt(g.dr)),
            InfoRow(bi('જમા (Credit)', 'Credit'), tAmt(g.cr).isEmpty ? '0.00' : tAmt(g.cr)),
            InfoRow(bi('આખરી બાકી', 'Closing Balance'), c.abs() < 0.005 ? '0.00' : tDr(c), bold: true, color: Pal.brand),
          ],
        ),
      ),
      const SizedBox(height: 8),
      for (final Vch v in g.rows.take(400)) _vTile(ctx, v, ledger: true),
    ];
  }
  final List<PcCol> cols = _vcols();
  final List<Widget> body = <Widget>[pcHead(cols)];
  if (g.opening.abs() >= 0.005) {
    body.add(pcRow(cols, <Widget>[pcTd(''), pcTd('Opening Balance', bold: true), pcTd(''), pcTd(''), pcTd(g.opening > 0 ? tAmt(g.opening) : '', num: true, bold: true), pcTd(g.opening < 0 ? tAmt(g.opening) : '', num: true, bold: true)], bg: Pal.soft));
  }
  String last = '';
  for (final Vch v in g.rows.take(cap)) {
    final String d = dayKey(v.date);
    body.add(_vRow(ctx, v, d != last, cols, ledger: true));
    last = d;
  }
  body.add(pcTotal(cols, 'Current Total', labelAt: 1, vals: <int, String>{4: tAmt(g.dr), 5: tAmt(g.cr)}));
  body.add(pcTotal(cols, 'Closing Balance', labelAt: 1, vals: <int, String>{if (c < 0) 4: tAmt(c), if (c > 0) 5: tAmt(c)}));
  body.add(pcTotal(cols, '', labelAt: 1, vals: <int, String>{4: tAmt(t.dr), 5: tAmt(t.cr)}));
  return body;
}

/// The Cash Book of one day in the TallyPrime layout (receipts on the debit side, payments on the credit side).
List<Widget> cashBookTable(BuildContext ctx, DateTime day, double opening) {
  final List<Vch> l = <Vch>[];
  for (final Vch v in allVouchers(chits: false)) {
    if (!sameDay(v.date, day)) continue;
    if (v.type == 'CON') {
      l.add(v); // contra: cash deposited into the bank / taken out of it
      continue;
    }
    if (v.mode != 'cash') continue;
    if (v.type == 'PAY' || v.type == 'RCT' || v.type == 'EXP' || v.type == 'INC') l.add(v);
  }
  double inSum = 0;
  double outSum = 0;
  bool isIn(Vch v) => v.type == 'RCT' || v.type == 'INC' || (v.type == 'CON' && v.kind == 'wd');
  for (final Vch v in l) {
    if (isIn(v)) {
      inSum += v.amt;
    } else {
      outSum += v.amt;
    }
  }
  final double closing = opening + inSum - outSum;
  final List<PcCol> cols = _vcols();
  final double dTot = (opening > 0 ? opening : 0) + inSum + (closing < 0 ? -closing : 0);
  final double cTot = (opening < 0 ? -opening : 0) + outSum + (closing > 0 ? closing : 0);
  final List<Widget> body = <Widget>[pcHead(cols)];
  body.add(pcRow(cols, <Widget>[pcTd(tDate(day), num: true), pcTd('Opening Balance', bold: true), pcTd(''), pcTd(''), pcTd(opening > 0 ? tAmt(opening) : '', num: true, bold: true), pcTd(opening < 0 ? tAmt(opening) : '', num: true, bold: true)], bg: Pal.soft));
  for (final Vch v in l) {
    final bool inn = isIn(v);
    body.add(pcRow(
      cols,
      <Widget>[
        pcTd(''),
        _particulars(v.type == 'CON' ? contraBankName() : v.party, v.note),
        pcTd(v.vt.name),
        pcTd(vchNoText(v), num: true),
        pcTd(inn ? tAmt(v.amt) : '', num: true, bold: true),
        pcTd(inn ? '' : tAmt(v.amt), num: true, bold: true),
      ],
      bar: _typeColor(v.type),
      onTap: () => openVoucher(ctx, v),
    ));
  }
  body.add(pcTotal(cols, 'Current Total', labelAt: 1, vals: <int, String>{4: tAmt(inSum), 5: tAmt(outSum)}));
  body.add(pcTotal(cols, 'Closing Balance', labelAt: 1, vals: <int, String>{if (closing < 0) 4: tAmt(closing), if (closing > 0) 5: tAmt(closing)}));
  body.add(pcTotal(cols, '', labelAt: 1, vals: <int, String>{4: tAmt(dTot), 5: tAmt(cTot)}));
  return body;
}

// ======================================================================
// Day Book
// ======================================================================

class DayBookArg {
  final String type;
  final RangeSel? sel;
  const DayBookArg({this.type = '', this.sel});
}

class BooksDayBookScreen extends StatefulWidget {
  final Object? arg;
  const BooksDayBookScreen({super.key, this.arg});

  @override
  State<BooksDayBookScreen> createState() => _DayBookState();
}

class _DayBookState extends State<BooksDayBookScreen> {
  late final VoidCallback _prn = () {
    _print();
  };
  late final VoidCallback _exp = () {
    _export();
  };

  RangeSel _sel = RangeSel(4);
  String _type = '';
  final TextEditingController _q = TextEditingController();

  @override
  void initState() {
    super.initState();
    final Object? a = widget.arg;
    if (a is DayBookArg) {
      _type = a.type;
      final RangeSel? s = a.sel;
      if (s != null) _sel = s;
    } else if (a is String) {
      _type = a;
    }
    printHub.push(_prn);
    exportHub.push(_exp);
  }

  @override
  void dispose() {
    _q.dispose();
    printHub.pop(_prn);
    exportHub.pop(_exp);
    super.dispose();
  }

  List<Vch> _list() {
    final String q = _q.text.trim().toLowerCase();
    final List<Vch> l = vouchersIn(_sel.period, type: _type);
    if (q.isEmpty) return l;
    return l.where((Vch v) => v.party.toLowerCase().contains(q) || v.note.toLowerCase().contains(q) || v.ref.toLowerCase().contains(q) || vchNoText(v).toLowerCase().contains(q) || v.vt.en.toLowerCase().contains(q)).toList();
  }

  String get _title => _type.isEmpty ? 'Day Book' : '${vTypeOf(_type).en} Register';

  Future<void> _print() async {
    final List<Vch> l = _list();
    double dr = 0;
    double cr = 0;
    for (final Vch v in l) {
      dr += v.dr;
      cr += v.cr;
    }
    String last = '';
    final List<List<String>> rows = <List<String>>[];
    for (final Vch v in l) {
      final String d = tDate(v.date);
      rows.add(<String>[d == last ? '' : d, v.party + (v.note.isEmpty ? '' : '  (${v.note})'), v.vt.en, vchNoText(v), tAmt(v.dr), tAmt(v.cr)]);
      last = d;
    }
    await printOut(
      reportHtml(
        title: _title,
        period: _periodText(_sel.period),
        heads: const <String>['Date', 'Particulars', 'Vch Type', 'Vch No.', 'Debit', 'Credit'],
        right: const <bool>[false, false, false, false, true, true],
        rows: rows,
        total: <String>['', 'Grand Total', '', '', tAmt(dr), tAmt(cr)],
      ),
      'daybook',
    );
  }

  Future<void> _export() async {
    await exportCsvOut(vouchersCsv(_list()), 'daybook-${dayKey(DateTime.now())}');
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[payDoc, saleDoc, expDoc, prefDoc, rateDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 1200,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final Period p = _sel.period;
          final List<Vch> l = _list();
          double dr = 0;
          double cr = 0;
          for (final Vch v in l) {
            dr += v.dr;
            cr += v.cr;
          }
          final bool pc = app.stagePc;
          final List<PcCol> cols = _vcols();
          const int cap = 600;
          final List<Widget> body = <Widget>[];
          if (l.isEmpty) {
            body.add(EmptyBox(icon: 'book', title: bi('આ સમયમાં કોઈ વાઉચર નથી', 'No vouchers in this period')));
          } else if (pc) {
            body.add(pcHead(cols));
            String last = '';
            for (final Vch v in l.take(cap)) {
              final String d = dayKey(v.date);
              body.add(_vRow(ctx, v, d != last, cols));
              last = d;
            }
            body.add(_grandRow(cols, bi('કુલ (Grand Total)', 'Grand Total'), tAmt(dr), tAmt(cr)));
          } else {
            for (final Vch v in l.take(cap)) {
              body.add(_vTile(ctx, v));
            }
          }
          return <Widget>[
            ScreenHeader(registerName(_type), exact: true, sub: _periodText(p), actions: <Widget>[
              if (_type == 'CON') IconBtn('plus', tip: bi('નવું કોન્ટ્રા વાઉચર', 'New contra voucher'), onTap: () => openContraForm(ctx)),
              if (_type == 'CNT') IconBtn('plus', tip: bi('નવી ક્રેડિટ નોટ (Ctrl+F8)', 'New credit note (Ctrl+F8)'), onTap: () => openNoteForm(ctx, credit: true)),
              if (_type == 'DNT') IconBtn('plus', tip: bi('નવી ડેબિટ નોટ (Ctrl+F9)', 'New debit note (Ctrl+F9)'), onTap: () => openNoteForm(ctx, credit: false)),
              IconBtn('print', tip: bi('પ્રિન્ટ (Ctrl+P)', 'Print (Ctrl+P)'), onTap: _print),
              IconBtn('table', tip: bi('Excel (Alt+E)', 'Export to Excel (Alt+E)'), onTap: _export),
            ]),
            statusBanner(),
            RangeBar(sel: _sel, presets: const <int>[0, 1, 3, 4, 5, 6], onChanged: (RangeSel s) => setState(() => _sel = s)),
            tallyStrip(TallyWhat.all, from: _sel.period.from, to: _sel.period.lastDay),
            const SizedBox(height: 10),
            ChipRow(
              labels: <String>[bi('બધા', 'All'), for (final VType t in kVTypes) t.name],
              index: _type.isEmpty ? 0 : 1 + kVTypes.indexWhere((VType t) => t.code == _type),
              onChanged: (int i) => app.setArg(DayBookArg(type: i == 0 ? '' : kVTypes[i - 1].code, sel: _sel)),
            ),
            const SizedBox(height: 10),
            SearchBox(hint: bi('નામ, નોંધ, નંબર શોધો', 'Search name, narration, number'), controller: _q, onChanged: (String _) => setState(() {})),
            const SizedBox(height: 10),
            if (!pc)
              Surface(
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: <Widget>[
                    Expanded(child: Text('${bi('ઉધાર', 'Debit')}\n${tAmt(dr).isEmpty ? '0.00' : tAmt(dr)}', style: ts(13, w: FontWeight.w800, tab: true))),
                    Expanded(child: Text('${bi('જમા', 'Credit')}\n${tAmt(cr).isEmpty ? '0.00' : tAmt(cr)}', textAlign: TextAlign.right, style: ts(13, w: FontWeight.w800, tab: true))),
                  ],
                ),
              ),
            if (!pc) const SizedBox(height: 8),
            ...body,
            if (l.length > cap) caption(bi('પહેલા $cap વાઉચર દેખાય છે - પીરિયડ નાનો કરો', 'First $cap vouchers shown - narrow the period')),
            const SizedBox(height: 6),
            caption(bi('વાઉચર પર Enter દબાવો: સુધારો / કાઢો / પ્રિન્ટ. Ctrl+P પ્રિન્ટ · Alt+E Excel · F2 પીરિયડ', 'Press Enter on a voucher to alter / delete / print. Ctrl+P print · Alt+E Excel · F2 period')),
          ];
        },
      ),
    );
  }
}

// ======================================================================
// Ledger (list of ledgers, and one ledger with Dr / Cr)
// ======================================================================

/// One month of the Monthly Summary of a ledger.
class _MRow {
  final String label;
  final double dr;
  final double cr;
  final double closing; // Dr positive
  final DateTime from;
  final DateTime to; // last day
  const _MRow(this.label, this.dr, this.cr, this.closing, this.from, this.to);
}

class BooksLedgerScreen extends StatefulWidget {
  final Object? arg;
  const BooksLedgerScreen({super.key, this.arg});

  @override
  State<BooksLedgerScreen> createState() => _LedgerState();
}

RangeSel _yearSel() {
  final DateTime t = dateOnly(DateTime.now());
  final RangeSel s = RangeSel(6);
  s.cFrom = finYearStart(t);
  s.cTo = t;
  return s;
}

class _LedgerState extends State<BooksLedgerScreen> {
  late final VoidCallback _prn = () {
    _print();
  };
  late final VoidCallback _exp = () {
    _export();
  };

  RangeSel _sel = _yearSel();
  String _dim = 'farmer';
  bool _monthly = false; // one ledger: Monthly Summary instead of the vouchers
  final TextEditingController _q = TextEditingController();

  LedgerRef? get _ref => widget.arg is LedgerRef ? widget.arg as LedgerRef : null;

  @override
  void initState() {
    super.initState();
    final Object? a = widget.arg;
    if (a is String && (a == 'farmer' || a == 'buyer' || a == 'head')) _dim = a;
    printHub.push(_prn);
    exportHub.push(_exp);
  }

  @override
  void dispose() {
    _q.dispose();
    printHub.pop(_prn);
    exportHub.pop(_exp);
    super.dispose();
  }

  String _dimName(String d) => d == 'farmer' ? bi('ખેડૂત', 'Farmer') : (d == 'buyer' ? bi('ખરીદનાર', 'Buyer') : bi('ખર્ચ / આવક', 'Expense / income'));

  /// "1,200.00 Dr" for a Dr-positive balance, blank when zero
  String _bal(double v) => v.abs() < 0.005 ? '' : tDr(v);

  List<LedgerSum> _sums() {
    final String q = _q.text.trim().toLowerCase();
    final Period p = _sel.period;
    return ledgerList(_dim, p).where((LedgerSum s) {
      if (s.count == 0 && s.closing.abs() < 0.005) return false;
      return q.isEmpty || s.ref.name.toLowerCase().contains(q);
    }).toList();
  }

  // ---- Monthly Summary of one ledger (Opening, then Debit / Credit / Closing Balance of every month)
  List<_MRow> _monthData(Ledger g) {
    final Period p = g.period;
    final Map<int, List<double>> m = <int, List<double>>{};
    for (final Vch v in g.rows) {
      final List<double> a = m.putIfAbsent(v.date.year * 12 + v.date.month - 1, () => <double>[0, 0]);
      a[0] += v.dr;
      a[1] += v.cr;
    }
    final List<_MRow> out = <_MRow>[];
    double bal = g.opening;
    final int end = p.lastDay.year * 12 + p.lastDay.month - 1;
    for (int k = p.from.year * 12 + p.from.month - 1; k <= end; k++) {
      final int y = k ~/ 12;
      final int mo = k % 12 + 1;
      final List<double> a = m[k] ?? <double>[0, 0];
      bal += a[0] - a[1];
      out.add(_MRow('${monthName(mo)} $y', a[0], a[1], bal, DateTime(y, mo, 1), DateTime(y, mo + 1, 0)));
    }
    return out;
  }

  List<List<String>> _monthRows(Ledger g, List<int> bold) {
    final List<List<String>> rows = <List<String>>[];
    if (g.opening.abs() >= 0.005) {
      bold.add(rows.length);
      rows.add(<String>['Opening Balance', '', '', _bal(g.opening)]);
    }
    for (final _MRow x in _monthData(g)) {
      rows.add(<String>[x.label, tAmt(x.dr), tAmt(x.cr), _bal(x.closing)]);
    }
    return rows;
  }

  List<Widget> _monthlyBody(BuildContext ctx, Ledger g) {
    final List<_MRow> ms = _monthData(g);
    void drill(_MRow x) {
      final RangeSel s = RangeSel(6);
      s.cFrom = x.from.isBefore(_sel.period.from) ? _sel.period.from : x.from;
      s.cTo = x.to.isAfter(_sel.period.lastDay) ? _sel.period.lastDay : x.to;
      setState(() {
        _sel = s;
        _monthly = false;
      });
    }

    if (!app.stagePc) {
      return <Widget>[
        for (final _MRow x in ms)
          lineItem(
            icon: 'cal',
            tone: 'teal',
            title: x.label,
            sub: '${tAmt(x.dr).isEmpty ? '0.00' : tAmt(x.dr)} Dr · ${tAmt(x.cr).isEmpty ? '0.00' : tAmt(x.cr)} Cr',
            trailing: x.closing.abs() < 0.005 ? '0.00' : tDr(x.closing),
            onTap: () => drill(x),
          ),
      ];
    }
    final List<PcCol> cols = <PcCol>[
      PcCol(bi('વિગત (Particulars)', 'Particulars'), 0),
      PcCol(bi('ઉધાર (Debit)', 'Debit'), 140, right: true),
      PcCol(bi('જમા (Credit)', 'Credit'), 140, right: true),
      PcCol(bi('આખરી બાકી', 'Closing Balance'), 170, right: true),
    ];
    return <Widget>[
      pcHead(cols),
      if (g.opening.abs() >= 0.005) pcRow(cols, <Widget>[pcTd('Opening Balance', bold: true), pcTd(''), pcTd(''), pcTd(_bal(g.opening), num: true, bold: true)], bg: Pal.soft),
      for (final _MRow x in ms)
        pcRow(
          cols,
          <Widget>[pcTd(x.label, bold: true), pcTd(tAmt(x.dr), num: true), pcTd(tAmt(x.cr), num: true), pcTd(_bal(x.closing), num: true, bold: true)],
          onTap: () => drill(x),
        ),
      pcTotal(cols, bi('કુલ (Grand Total)', 'Grand Total'), vals: <int, String>{1: tAmt(g.dr), 2: tAmt(g.cr), 3: _bal(g.closing)}),
    ];
  }

  // ---- rows of one ledger (also used for print and export)
  List<List<String>> _ledgerRows(Ledger g, List<int> bold) {
    final List<List<String>> rows = <List<String>>[];
    if (g.opening.abs() >= 0.005) {
      bold.add(rows.length);
      rows.add(<String>['', 'Opening Balance', '', '', g.opening > 0 ? tAmt(g.opening) : '', g.opening < 0 ? tAmt(g.opening) : '']);
    }
    String last = '';
    for (final Vch v in g.rows) {
      final String d = tDate(v.date);
      rows.add(<String>[d == last ? '' : d, (v.contra.isEmpty ? v.party : v.contra) + (v.note.isEmpty ? '' : '  (${v.note})'), v.vt.en, vchNoText(v), tAmt(v.dr), tAmt(v.cr)]);
      last = d;
    }
    bold.add(rows.length);
    rows.add(<String>['', 'Current Total', '', '', tAmt(g.dr), tAmt(g.cr)]);
    final double c = g.closing;
    bold.add(rows.length);
    rows.add(<String>['', 'Closing Balance', '', '', c < 0 ? tAmt(c) : '', c > 0 ? tAmt(c) : '']);
    return rows;
  }

  Future<void> _print() async {
    final LedgerRef? r = _ref;
    if (r != null && _monthly) {
      final Ledger g = buildLedger(r, _sel.period);
      final List<int> bold = <int>[];
      await printOut(
        reportHtml(
          title: 'Ledger Monthly Summary : ${r.name}',
          period: _periodText(_sel.period),
          heads: const <String>['Particulars', 'Debit', 'Credit', 'Closing Balance'],
          right: const <bool>[false, true, true, true],
          rows: _monthRows(g, bold),
          total: <String>['Grand Total', tAmt(g.dr), tAmt(g.cr), _bal(g.closing)],
          bold: bold.toSet(),
        ),
        'ledger-monthly-${nameKey(r.name)}',
      );
      return;
    }
    if (r != null) {
      final Ledger g = buildLedger(r, _sel.period);
      final List<int> bold = <int>[];
      final List<List<String>> rows = _ledgerRows(g, bold);
      final _Tot t = _ledgerGrand(g);
      await printOut(
        reportHtml(
          title: 'Ledger : ${r.name}',
          period: _periodText(_sel.period),
          heads: const <String>['Date', 'Particulars', 'Vch Type', 'Vch No.', 'Debit', 'Credit'],
          right: const <bool>[false, false, false, false, true, true],
          rows: rows,
          total: <String>['', '', '', '', tAmt(t.dr), tAmt(t.cr)],
          bold: bold.toSet(),
        ),
        'ledger-${nameKey(r.name)}',
      );
      return;
    }
    final List<LedgerSum> l = _sums();
    double o = 0;
    double dr = 0;
    double cr = 0;
    for (final LedgerSum s in l) {
      o += s.opening;
      dr += s.dr;
      cr += s.cr;
    }
    await printOut(
      reportHtml(
        title: 'List of Ledgers - ${_dimName(_dim)}',
        period: _periodText(_sel.period),
        heads: const <String>['Particulars', 'Opening Balance', 'Debit', 'Credit', 'Closing Balance'],
        right: const <bool>[false, true, true, true, true],
        rows: <List<String>>[
          for (final LedgerSum s in l) <String>[s.ref.name, _bal(s.opening), tAmt(s.dr), tAmt(s.cr), _bal(s.closing)],
        ],
        total: <String>['Total', _bal(o), tAmt(dr), tAmt(cr), _bal(o + dr - cr)],
      ),
      'ledgers',
    );
  }

  Future<void> _export() async {
    final LedgerRef? r = _ref;
    final StringBuffer b = StringBuffer();
    if (r != null && _monthly) {
      final Ledger g = buildLedger(r, _sel.period);
      b.writeln('Particulars,Debit,Credit,Closing Balance');
      for (final List<String> row in _monthRows(g, <int>[])) {
        b.writeln(row.map(csvCell).join(','));
      }
      await exportCsvOut(b.toString(), 'ledger-monthly-${nameKey(r.name).replaceAll(' ', '_')}');
      return;
    }
    if (r != null) {
      final Ledger g = buildLedger(r, _sel.period);
      b.writeln('Date,Particulars,Vch Type,Vch No.,Debit,Credit');
      final List<int> bold = <int>[];
      for (final List<String> row in _ledgerRows(g, bold)) {
        b.writeln(row.map(csvCell).join(','));
      }
      await exportCsvOut(b.toString(), 'ledger-${nameKey(r.name).replaceAll(' ', '_')}');
      return;
    }
    b.writeln('Particulars,Opening Balance,Debit,Credit,Closing Balance');
    for (final LedgerSum s in _sums()) {
      b.writeln('${csvCell(s.ref.name)},${_bal(s.opening)},${tAmt(s.dr)},${tAmt(s.cr)},${_bal(s.closing)}');
    }
    await exportCsvOut(b.toString(), 'ledgers-$_dim');
  }

  // ---- list of ledgers
  List<Widget> _listBody(BuildContext ctx) {
    final List<LedgerSum> l = _sums();
    final bool pc = app.stagePc;
    final List<PcCol> cols = <PcCol>[
      PcCol(bi('વિગત (Particulars)', 'Particulars'), 0),
      PcCol(bi('શરૂઆતનું બાકી', 'Opening Balance'), 150, right: true),
      PcCol(bi('ઉધાર (Debit)', 'Debit'), 128, right: true),
      PcCol(bi('જમા (Credit)', 'Credit'), 128, right: true),
      PcCol(bi('આખરી બાકી', 'Closing Balance'), 150, right: true),
    ];
    double o = 0;
    double dr = 0;
    double cr = 0;
    for (final LedgerSum s in l) {
      o += s.opening;
      dr += s.dr;
      cr += s.cr;
    }
    void open(LedgerSum s) => app.go('my_ledger', arg: s.ref);
    return <Widget>[
      ChipRow(
        labels: <String>[_dimName('farmer'), _dimName('buyer'), _dimName('head')],
        index: _dim == 'farmer' ? 0 : (_dim == 'buyer' ? 1 : 2),
        onChanged: (int i) => setState(() => _dim = i == 0 ? 'farmer' : (i == 1 ? 'buyer' : 'head')),
      ),
      const SizedBox(height: 10),
      SearchBox(hint: bi('નામ શોધો', 'Search name'), controller: _q, onChanged: (String _) => setState(() {})),
      const SizedBox(height: 10),
      if (l.isEmpty) EmptyBox(icon: 'ledger', title: bi('આ સમયમાં કોઈ ખાતું નથી', 'No ledgers in this period')),
      if (l.isNotEmpty && pc) ...<Widget>[
        pcHead(cols),
        for (final LedgerSum s in l.take(600))
          pcRow(
            cols,
            <Widget>[
              pcTd(s.ref.name, bold: true),
              pcTd(_bal(s.opening), num: true),
              pcTd(tAmt(s.dr), num: true),
              pcTd(tAmt(s.cr), num: true),
              pcTd(_bal(s.closing), num: true, bold: true),
            ],
            onTap: () => open(s),
          ),
        pcTotal(cols, bi('કુલ', 'Total'), vals: <int, String>{1: _bal(o), 2: tAmt(dr), 3: tAmt(cr), 4: _bal(o + dr - cr)}),
      ],
      if (l.isNotEmpty && !pc)
        for (final LedgerSum s in l.take(300))
          lineItem(
            icon: _dim == 'farmer' ? 'agri' : (_dim == 'buyer' ? 'users' : 'wallet'),
            tone: _dim == 'farmer' ? 'teal' : (_dim == 'buyer' ? 'amber' : 'rose'),
            title: s.ref.name,
            sub: '${s.count} ${bi('વાઉચર', 'vouchers')}',
            trailing: s.closing.abs() < 0.005 ? '0.00' : tDr(s.closing),
            onTap: () => open(s),
          ),
    ];
  }

  // ---- one ledger
  List<Widget> _oneBody(BuildContext ctx, LedgerRef r) {
    final Ledger g = buildLedger(r, _sel.period);
    final List<Widget> body = _monthly ? _monthlyBody(ctx, g) : ledgerTable(ctx, g);
    final Widget quick = r.dim == 'farmer'
        ? Row(
            children: <Widget>[
              tExp(child: Btn(bi('ચૂકવણી', 'Payment'), icon: 'plus', dense: true, onTap: () => openPayForm(ctx, farmer: PartyRef(Dim.farmer, r.key, r.name)))),
              const SizedBox(width: 8),
              tExp(child: Btn(bi('ખેડૂત પ્રોફાઇલ', 'Farmer page'), icon: 'user', kind: BtnKind.tonal, dense: true, onTap: () => app.go('khata_party', arg: PartyRef(Dim.farmer, r.key, r.name)))),
            ],
          )
        : (r.dim == 'buyer'
            ? Row(
                children: <Widget>[
                  tExp(child: Btn(bi('વેચાણ', 'Sale'), icon: 'plus', dense: true, onTap: () => openSaleForm(ctx, buyer: r.name))),
                  const SizedBox(width: 8),
                  tExp(child: Btn(bi('રકમ મળી', 'Received'), icon: 'rupee', kind: BtnKind.amber, dense: true, onTap: () => openSaleForm(ctx, kind: 'recv', buyer: r.name))),
                  const SizedBox(width: 8),
                  tExp(child: Btn(bi('ખરીદનાર પેજ', 'Buyer page'), icon: 'user', kind: BtnKind.tonal, dense: true, onTap: () => app.go('buyer_party', arg: nameKey(r.name)))),
                ],
              )
            : const SizedBox.shrink());
    return <Widget>[
      quick,
      if (r.dim != 'head') const SizedBox(height: 10),
      Seg(
        labels: <String>[bi('વાઉચર', 'Vouchers'), bi('માસિક સારાંશ (Monthly Summary)', 'Monthly Summary')],
        index: _monthly ? 1 : 0,
        onChanged: (int i) => setState(() => _monthly = i == 1),
      ),
      const SizedBox(height: 10),
      if (g.rows.isEmpty && g.opening.abs() < 0.005) EmptyBox(icon: 'ledger', title: bi('આ સમયમાં કોઈ વાઉચર નથી', 'No vouchers in this period')),
      ...body,
      const SizedBox(height: 6),
      caption(bi('ખાતાનું બાકી Dr = લેવાના, Cr = આપવાના (ખેડૂત માટે Cr = આપવાના બાકી). વાઉચર પર Enter દબાવો.', 'Dr = to receive, Cr = to give (for a farmer, Cr = we owe him). Press Enter on a voucher.')),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[payDoc, saleDoc, expDoc, prefDoc, rateDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 1200,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final LedgerRef? r = _ref;
          final Period p = _sel.period;
          return <Widget>[
            ScreenHeader(r == null ? bi('ખાતાવહી (Ledger)', 'Ledger') : r.name, exact: true, sub: r == null ? _periodText(p) : '${_dimName(r.dim)} · ${_periodText(p)}', actions: <Widget>[
              IconBtn('print', tip: bi('પ્રિન્ટ (Ctrl+P)', 'Print (Ctrl+P)'), onTap: _print),
              IconBtn('table', tip: bi('Excel (Alt+E)', 'Export to Excel (Alt+E)'), onTap: _export),
            ]),
            statusBanner(),
            RangeBar(sel: _sel, presets: const <int>[3, 4, 5, 6], onChanged: (RangeSel s) => setState(() => _sel = s)),
            const SizedBox(height: 10),
            ...(r == null ? _listBody(ctx) : _oneBody(ctx, r)),
          ];
        },
      ),
    );
  }
}

// ======================================================================
// Trial Balance
// ======================================================================

class BooksTrialScreen extends StatefulWidget {
  const BooksTrialScreen({super.key});

  @override
  State<BooksTrialScreen> createState() => _TrialState();
}

class _TrialState extends State<BooksTrialScreen> {
  late final VoidCallback _prn = () {
    _print();
  };
  late final VoidCallback _exp = () {
    _export();
  };

  RangeSel _sel = _yearSel();
  final Set<String> _open = <String>{};

  @override
  void initState() {
    super.initState();
    printHub.push(_prn);
    exportHub.push(_exp);
  }

  @override
  void dispose() {
    printHub.pop(_prn);
    exportHub.pop(_exp);
    super.dispose();
  }

  /// Both columns end with the same total (the difference line, if any, is added to the smaller side).
  double _grandOf(TrialBal t) {
    final bool hasDiff = t.diff.abs() >= 0.5;
    final double ddr = t.dr + (hasDiff && t.diff > 0 ? t.diff : 0);
    final double dcr = t.cr + (hasDiff && t.diff < 0 ? -t.diff : 0);
    return ddr > dcr ? ddr : dcr;
  }

  void _go(TbLine l) {
    final LedgerRef? r = l.ref;
    if (l.kids.isNotEmpty) {
      setState(() {
        if (!_open.remove(l.name)) _open.add(l.name);
      });
    } else if (r != null) {
      app.go('my_ledger', arg: r);
    } else if (l.go == 'my_daybook') {
      app.go('my_daybook', arg: DayBookArg(type: l.arg, sel: _sel));
    } else if (l.go.isNotEmpty) {
      app.go(l.go);
    }
  }

  List<List<String>> _rows(TrialBal t, List<int> bold) {
    final List<List<String>> rows = <List<String>>[];
    for (final TbLine l in t.lines) {
      bold.add(rows.length);
      rows.add(<String>[l.name, tAmt(l.dr), tAmt(l.cr)]);
      for (final TbLine k in l.kids) {
        rows.add(<String>['     ${k.name}', tAmt(k.dr), tAmt(k.cr)]);
      }
    }
    if (t.diff.abs() >= 0.5) {
      bold.add(rows.length);
      rows.add(<String>['Difference in opening balances', t.diff > 0 ? tAmt(t.diff) : '', t.diff < 0 ? tAmt(t.diff) : '']);
    }
    return rows;
  }

  Future<void> _print() async {
    final TrialBal t = trialBalance(_sel.period);
    final List<int> bold = <int>[];
    final List<List<String>> rows = _rows(t, bold);
    final double grand = _grandOf(t);
    await printOut(
      reportHtml(
        title: 'Trial Balance',
        period: _periodText(_sel.period),
        heads: const <String>['Particulars', 'Debit', 'Credit'],
        right: const <bool>[false, true, true],
        rows: rows,
        total: <String>['Grand Total', tAmt(grand), tAmt(grand)],
        bold: bold.toSet(),
      ),
      'trial-balance',
    );
  }

  Future<void> _export() async {
    final TrialBal t = trialBalance(_sel.period);
    final StringBuffer b = StringBuffer();
    b.writeln('Particulars,Debit,Credit');
    for (final List<String> row in _rows(t, <int>[])) {
      b.writeln(row.map(csvCell).join(','));
    }
    await exportCsvOut(b.toString(), 'trial-balance-${dayKey(DateTime.now())}');
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[payDoc, saleDoc, expDoc, prefDoc, rateDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 1000,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final Period p = _sel.period;
          final TrialBal t = trialBalance(p);
          final bool pc = app.stagePc;
          final List<PcCol> cols = <PcCol>[
            PcCol(bi('વિગત (Particulars)', 'Particulars'), 0),
            PcCol(bi('ઉધાર (Debit)', 'Debit'), 150, right: true),
            PcCol(bi('જમા (Credit)', 'Credit'), 150, right: true),
          ];
          final bool hasDiff = t.diff.abs() >= 0.5;
          final double grand = _grandOf(t);
          final List<Widget> body = <Widget>[];
          if (t.lines.isEmpty && !pc) {
            body.add(EmptyBox(icon: 'balance', title: bi('આ સમયમાં કોઈ હિસાબ નથી', 'Nothing to show for this period')));
          } else if (pc) {
            body.add(pcHead(cols));
            for (final TbLine l in t.lines) {
              final bool isOpen = _open.contains(l.name);
              body.add(pcRow(
                cols,
                <Widget>[
                  Row(
                    children: <Widget>[
                      if (l.kids.isNotEmpty && !Pal.tally) Padding(padding: const EdgeInsets.only(right: 6), child: Icon(isOpen ? Icons.expand_more : Icons.chevron_right, size: 16, color: Pal.muted)),
                      Expanded(child: pcTd(l.name, bold: true)),
                    ],
                  ),
                  pcTd(tAmt(l.dr), num: true, bold: true),
                  pcTd(tAmt(l.cr), num: true, bold: true),
                ],
                onTap: () => _go(l),
              ));
              if (isOpen) {
                for (final TbLine k in l.kids) {
                  body.add(pcRow(
                    cols,
                    <Widget>[
                      Padding(padding: const EdgeInsets.only(left: 28), child: pcTd(k.name)),
                      pcTd(tAmt(k.dr), num: true),
                      pcTd(tAmt(k.cr), num: true),
                    ],
                    onTap: () => _go(k),
                  ));
                }
              }
            }
            if (hasDiff) {
              body.add(pcRow(cols, <Widget>[pcTd(bi('શરૂઆતના બાકીનો તફાવત', 'Difference in opening balances'), bold: true, c: Pal.warn), pcTd(t.diff > 0 ? tAmt(t.diff) : '', num: true, bold: true), pcTd(t.diff < 0 ? tAmt(t.diff) : '', num: true, bold: true)]));
            }
            body.add(pcTotal(cols, bi('કુલ (Grand Total)', 'Grand Total'), vals: <int, String>{1: tAmt(grand), 2: tAmt(grand)}));
          } else {
            for (final TbLine l in t.lines) {
              final bool isOpen = _open.contains(l.name);
              body.add(lineItem(
                icon: l.kids.isNotEmpty ? (isOpen ? 'collapse' : 'expand') : 'balance',
                tone: 'teal',
                title: l.name,
                trailing: '${tAmt(l.dr > 0 ? l.dr : l.cr)} ${l.dr > 0 ? 'Dr' : 'Cr'}',
                onTap: () => _go(l),
              ));
              if (isOpen) {
                for (final TbLine k in l.kids) {
                  body.add(Padding(
                    padding: const EdgeInsets.only(left: 18),
                    child: lineItem(icon: 'ledger', tone: 'slate', title: k.name, trailing: '${tAmt(k.dr > 0 ? k.dr : k.cr)} ${k.dr > 0 ? 'Dr' : 'Cr'}', onTap: () => _go(k)),
                  ));
                }
              }
            }
            if (hasDiff) body.add(noteBox('warn', 'amber', '${bi('શરૂઆતના બાકીનો તફાવત', 'Difference in opening balances')}: ${tAmt(t.diff)} ${t.diff > 0 ? 'Dr' : 'Cr'}'));
            body.add(Surface(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: <Widget>[
                  Expanded(child: Text(bi('કુલ (Grand Total)', 'Grand Total'), style: ts(13.5, w: FontWeight.w800))),
                  Text(tAmt(grand), style: ts(13.5, w: FontWeight.w800, tab: true)),
                ],
              ),
            ));
          }
          return <Widget>[
            ScreenHeader('Trial Balance', sub: _periodText(p), actions: <Widget>[
              IconBtn('print', tip: bi('પ્રિન્ટ (Ctrl+P)', 'Print (Ctrl+P)'), onTap: _print),
              IconBtn('table', tip: bi('Excel (Alt+E)', 'Export to Excel (Alt+E)'), onTap: _export),
            ]),
            statusBanner(),
            RangeBar(sel: _sel, presets: const <int>[3, 4, 5, 6], onChanged: (RangeSel s) => setState(() => _sel = s)),
            tallyStrip(TallyWhat.all, from: _sel.period.from, to: _sel.period.lastDay),
            const SizedBox(height: 10),
            ...body,
            const SizedBox(height: 6),
            caption(bi('ખેડૂત / ખરીદનારનો બાકી છેલ્લી તારીખ સુધીનો છે; ખરીદ, વેચાણ, ખર્ચ, આવક પીરિયડની છે. લીટી પર Enter દબાવો: અંદરના ખાતા.', 'Farmer / buyer balances are as on the last date; purchases, sales, expenses and income are of the period. Press Enter on a line to open it.')),
          ];
        },
      ),
    );
  }
}
