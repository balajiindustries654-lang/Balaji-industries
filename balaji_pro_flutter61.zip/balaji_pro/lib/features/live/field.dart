import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/app_state.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/engine.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../data/owner_docs.dart';
import '../../widgets/common.dart';
import 'kit2.dart';
import 'ui.dart';

/// Building blocks for the field entry forms (chit, weighbridge, maal) so the
/// three people who use them get quick, careful screens.

// ------------------------------------------------------------------ dialogs
/// A yes / no question. true when the person agrees.
Future<bool> confirmBox(BuildContext context, {required String title, required String text, String? yes, String? no}) async {
  final bool pc = app.stagePc;
  final bool? r = await showDialog<bool>(
    context: context,
    builder: (BuildContext c) => CallbackShortcuts(
      // on the PC keyboard: Y = yes, N = no (Esc also means no)
      bindings: <ShortcutActivator, VoidCallback>{
        const SingleActivator(LogicalKeyboardKey.keyY): () => Navigator.of(c).pop(true),
        const SingleActivator(LogicalKeyboardKey.keyN): () => Navigator.of(c).pop(false),
      },
      child: Focus(
        autofocus: true,
        child: AlertDialog(
          title: Text(title, style: ts(17, w: FontWeight.w800)),
          content: Text(text, style: ts(14, h: 1.45)),
          actions: <Widget>[
            TextButton(onPressed: () => Navigator.of(c).pop(false), child: Text('${no ?? bi('ના, સુધારું', 'No, let me fix')}${pc ? '  (N)' : ''}', style: ts(14, w: FontWeight.w700, c: Pal.muted))),
            TextButton(onPressed: () => Navigator.of(c).pop(true), child: Text('${yes ?? bi('હા, સેવ કરો', 'Yes, save')}${pc ? '  (Y)' : ''}', style: ts(14, w: FontWeight.w800, c: Pal.brand))),
          ],
        ),
      ),
    ),
  );
  return r == true;
}

// -------------------------------------------------------------------- notes
/// A one-line check result: level = bad | warn | ok | info.
Widget checkNote(String level, String text) {
  switch (level) {
    case 'bad':
      return noteBox('err', 'rose', text);
    case 'warn':
      return noteBox('warn', 'amber', text);
    case 'ok':
      return noteBox('check', 'green', text);
    default:
      return noteBox('info', 'blue', text);
  }
}

/// Plain number text: 1250 -> "1250", 1250.5 -> "1250.5".
String plainNum(double v) {
  if (v == v.roundToDouble()) return '${v.round()}';
  String s = v.toStringAsFixed(2);
  if (s.endsWith('0')) s = s.substring(0, s.length - 1);
  return s;
}

// ------------------------------------------------------------------ chips
/// A row of small tappable values (recent vehicles, quick numbers).
class PickChips extends StatelessWidget {
  final String title;
  final List<String> values;
  final ValueChanged<String> onPick;
  const PickChips({super.key, required this.title, required this.values, required this.onPick});

  @override
  Widget build(BuildContext context) {
    if (values.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(title, style: ts(12.5, w: FontWeight.w700, c: Pal.muted)),
          const SizedBox(height: 6),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <Widget>[
              for (final String v in values)
                GestureDetector(
                  onTap: () => onPick(v),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(color: Pal.soft, borderRadius: BorderRadius.circular(Pal.rad(99)), border: Border.all(color: Pal.line)),
                    child: Text(v, style: ts(13, w: FontWeight.w700)),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

// -------------------------------------------------------- today's own work
List<Chit> todaysChits() {
  final DateTime t = dayOf(DateTime.now());
  return live.chits.where((Chit c) => !c.at.isBefore(t) && (live.isAdmin || c.by == live.uid)).toList();
}

List<Kanta> todaysKantas() {
  final DateTime t = dayOf(DateTime.now());
  return live.kantas.where((Kanta c) => !c.at.isBefore(t) && (live.isAdmin || c.by == live.uid)).toList();
}

List<MaalRow> todaysMaals() {
  final DateTime t = dayOf(DateTime.now());
  return live.maals.where((MaalRow c) => !c.at.isBefore(t) && (live.isAdmin || c.by == live.uid)).toList();
}

Widget _stat(String label, String value, {Color? color}) {
  return Expanded(
    child: Column(
      children: <Widget>[
        Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(19, w: FontWeight.w800, tab: true, c: color)),
        const SizedBox(height: 2),
        Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(11.5, c: Pal.muted, w: FontWeight.w600)),
      ],
    ),
  );
}

/// "Today so far" strip under a form. kind = chit | kanta | maal.
class TodayStrip extends StatelessWidget {
  final String kind;
  const TodayStrip(this.kind, {super.key});

  @override
  Widget build(BuildContext context) {
    final List<Widget> cells = <Widget>[];
    String title = '';
    if (kind == 'chit') {
      final List<Chit> l = todaysChits();
      double kg = 0;
      final Set<String> veh = <String>{};
      for (final Chit c in l) {
        kg += c.cmpKg;
        veh.add(c.vkey);
      }
      title = bi('આજની ચિઠ્ઠી', 'Chits today');
      cells.addAll(<Widget>[_stat(bi('ચિઠ્ઠી', 'Chits'), '${l.length}'), _stat(bi('ગાડી', 'Vehicles'), '${veh.length}'), _stat(bi('વજન', 'Weight'), kgTxt(kg), color: Pal.brand)]);
    } else if (kind == 'kanta') {
      final List<Kanta> l = todaysKantas();
      double kg = 0;
      for (final Kanta c in l) {
        kg += c.kg;
      }
      title = bi('આજનો કાંટો', 'Weighbridge today');
      cells.addAll(<Widget>[_stat(bi('ગાડી', 'Vehicles'), '${l.length}'), _stat(bi('કુલ વજન', 'Total'), kgTxt(kg), color: Pal.brand), _stat(bi('સરેરાશ', 'Average'), l.isEmpty ? '—' : kgTxt(kg / l.length))]);
    } else {
      final List<MaalRow> l = todaysMaals();
      int inB = 0;
      int outB = 0;
      for (final MaalRow c in l) {
        if (c.loading) {
          outB += c.bags;
        } else {
          inB += c.bags;
        }
      }
      title = bi('આજનો માલ', 'Maal today');
      cells.addAll(<Widget>[_stat(bi('આવ્યા', 'In'), '$inB', color: Pal.ok), _stat(bi('ગયા', 'Out'), '$outB', color: Pal.warn), _stat(bi('એન્ટ્રી', 'Entries'), '${l.length}')]);
    }
    return Surface(
      shadow: false,
      color: Pal.soft,
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(title, style: ts(12.5, w: FontWeight.w800, c: Pal.muted, ls: 0.3)),
          const SizedBox(height: 8),
          Row(children: cells),
        ],
      ),
    );
  }
}

/// The last few entries of today under a form.
Widget recentBlock(BuildContext context, String kind, {int n = 5}) {
  final List<Widget> tiles = <Widget>[];
  if (kind == 'chit') {
    for (final Chit c in todaysChits().take(n)) {
      tiles.add(chitTile(context, c));
    }
  } else if (kind == 'kanta') {
    for (final Kanta c in todaysKantas().take(n)) {
      tiles.add(kantaTile(context, c));
    }
  } else {
    for (final MaalRow c in todaysMaals().take(n)) {
      tiles.add(maalTile(context, c));
    }
  }
  if (tiles.isEmpty) return const SizedBox.shrink();
  return Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: <Widget>[
      const SizedBox(height: 16),
      caption(bi('હમણાંની એન્ટ્રી', 'Latest entries')),
      ...tiles,
      Btn(bi('આખો દિવસ જુઓ', 'See the whole day'), icon: 'list', kind: BtnKind.ghost, dense: true, onTap: () => app.go('my_day')),
    ],
  );
}

// ---------------------------------------------------------- vehicle context
/// Chits already made for this vehicle in the last 40 hours (a truck often
/// carries several farmers).
class VehicleLoadCard extends StatelessWidget {
  final String vehicle;
  const VehicleLoadCard(this.vehicle, {super.key});

  @override
  Widget build(BuildContext context) {
    final String vk = vehicleKey(vehicle);
    if (vk.length < 4) return const SizedBox.shrink();
    final DateTime lim = DateTime.now().subtract(const Duration(hours: 40));
    final List<Chit> cs = live.chits.where((Chit c) => c.vkey == vk && c.at.isAfter(lim)).toList();
    final List<Widget> out = <Widget>[];
    if (vk.length >= 6 && !plateOk(vk)) {
      out.add(checkNote('warn', bi('ગાડી નંબર સામાન્ય ફોર્મેટનો નથી (જેમ કે GJ12AB1234)', 'Vehicle number looks unusual (e.g. GJ12AB1234)')));
    }
    if (cs.isNotEmpty) {
      double kg = 0;
      int bags = 0;
      for (final Chit c in cs) {
        kg += c.cmpKg;
        bags += c.bags;
      }
      final double lim2 = bigLoadKg();
      final bool over = kg > lim2;
      out.add(Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Surface(
          shadow: false,
          color: over ? Pal.tone('amber').bg : Pal.tone('blue').bg,
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                '${bi('આ ગાડીમાં હમણાં', 'Already on this vehicle')}: ${cs.length} ${bi('ચિઠ્ઠી', 'chits')} · ${kgTxt(kg)}${bags > 0 ? ' · $bags ${bi('બેગ', 'bags')}' : ''}',
                style: ts(13.5, w: FontWeight.w800, c: over ? Pal.tone('amber').fg : Pal.tone('blue').fg),
              ),
              if (over) ...<Widget>[
                const SizedBox(height: 4),
                Text(bi('ગાડીનું વજન ${kgTxt(lim2)} થી વધી ગયું છે', 'Load is above ${kgTxt(lim2)}'), style: ts(12.5, w: FontWeight.w700, c: Pal.tone('amber').fg)),
              ],
              const SizedBox(height: 6),
              Wrap(
                spacing: 6,
                runSpacing: 4,
                children: <Widget>[
                  for (final Chit c in cs.take(8)) Pill('#${c.no} · ${vtxt(c.farmer)} · ${grp(c.cmpKg)}', tone: 'slate', small: true),
                ],
              ),
            ],
          ),
        ),
      ));
    }
    if (out.isEmpty) return const SizedBox.shrink();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: out);
  }
}

// -------------------------------------------------------------- helpers
/// KG per bag seen in the chits of this material (0 when unknown).
double avgKgPerBag(String commodityCode) {
  double kg = 0;
  int bags = 0;
  final String want = commodityCode.trim().toLowerCase();
  for (final Chit c in live.chits) {
    if (c.bags <= 0) continue;
    if (want.isNotEmpty && c.commodity.trim().toLowerCase() != want) continue;
    kg += c.cmpKg;
    bags += c.bags;
  }
  return bags >= 20 ? kg / bags : 0;
}

/// Loads with chits but no weighbridge entry yet, newest first (owner only,
/// the workers do not see the chits).
List<Trip> pendingTrips() {
  final List<Trip> l = live.trips.where((Trip t) => t.kanta == null && t.chits.isNotEmpty && t.state != TripState.direct).toList();
  l.sort((Trip a, Trip b) => b.at.compareTo(a.at));
  return l;
}

Trip? pendingTripOf(String vehicle) {
  final String vk = vehicleKey(vehicle);
  if (vk.isEmpty) return null;
  for (final Trip t in pendingTrips()) {
    if (t.vk == vk) return t;
  }
  return null;
}

/// The highest plain number among the values (0 when none).
int lastNumber(Iterable<String> values) {
  int best = 0;
  for (final String v in values) {
    final int? n = int.tryParse(v.trim());
    if (n != null && n > best) best = n;
  }
  return best;
}
