import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/insights.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../data/money.dart';
import '../../data/owner_docs.dart';
import '../../data/trade.dart';
import '../../widgets/charts.dart';
import '../../widgets/common.dart';
import '../../widgets/launch.dart';
import '../../widgets/page.dart';
import 'field.dart';
import 'kit.dart';
import 'kit2.dart';
import 'money_screens.dart';
import 'trade_screens.dart';
import 'ui.dart';

// ======================================================================
// Collection (who has to pay us, and since when) and the cash flow
// ======================================================================

List<String> _bucketNames() => <String>[
      bi('0-15 દિવસ', '0-15 days'),
      bi('16-30 દિવસ', '16-30 days'),
      bi('31-60 દિવસ', '31-60 days'),
      bi('60 દિવસથી વધુ', 'Over 60 days'),
    ];

Color _bucketColor(int i) {
  const List<Color> c = <Color>[Pal.ok, Pal.info, Pal.warn, Pal.bad];
  return c[i];
}

String reminderText(AgedBuyer a) {
  final int d = a.oldDays;
  return bi(
    'નમસ્તે ${a.label}, બાલાજી ઇન્ડસ્ટ્રીઝ તરફથી યાદ: તમારા ${inr(a.due)} બાકી છે${d > 0 ? ' (સૌથી જૂનું $d દિવસથી)' : ''}. કૃપા કરી ચૂકવણી કરશો. આભાર.',
    'Hello ${a.label}, a reminder from Balaji Industries: ${inr(a.due)} is due${d > 0 ? ' (oldest for $d days)' : ''}. Please arrange the payment. Thank you.',
  );
}

// -------------------------------------------------------- one buyer panel
Future<void> openCollectPanel(BuildContext context, AgedBuyer a) {
  return openPanel(
    context,
    title: a.label,
    sub: '${bi('બાકી', 'Due')} ${inr(a.due)}',
    width: 480,
    child: _CollectPanel(a: a, outer: context),
  );
}

class _CollectPanel extends StatelessWidget {
  final AgedBuyer a;
  final BuildContext outer;
  const _CollectPanel({required this.a, required this.outer});

  @override
  Widget build(BuildContext context) {
    final List<String> names = _bucketNames();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        for (int i = 0; i < 4; i++)
          if (a.bucket[i] > 0.5) InfoRow(names[i], inr(a.bucket[i]), color: _bucketColor(i)),
        InfoRow(bi('કુલ બાકી', 'Total due'), inr(a.due), bold: true, color: Pal.brand),
        if (a.oldest != null) InfoRow(bi('સૌથી જૂનું બિલ', 'Oldest bill'), '${dmy(a.oldest!)} · ${a.oldDays} ${bi('દિવસ', 'days')}'),
        const SizedBox(height: 14),
        BuyerPhoneBox(keyId: a.key, message: reminderText(a)),
        const SizedBox(height: 12),
        Row(
          children: <Widget>[
            tExp(
              child: Btn(
                bi('રકમ મળી', 'Money received'),
                icon: 'rupee',
                kind: BtnKind.amber,
                onTap: () {
                  Navigator.of(context).pop();
                  openSaleForm(outer, kind: 'recv', buyer: a.label);
                },
              ),
            ),
            const SizedBox(width: 8),
            tExp(
              child: Btn(
                bi('ખાતું જુઓ', 'See ledger'),
                icon: 'book',
                kind: BtnKind.tonal,
                onTap: () {
                  Navigator.of(context).pop();
                  app.go('buyer_party', arg: a.key);
                },
              ),
            ),
          ],
        ),
      ],
    );
  }
}

// ------------------------------------------------------ collection screen
class CollectionScreen extends StatefulWidget {
  const CollectionScreen({super.key});

  @override
  State<CollectionScreen> createState() => _CollectionState();
}

class _CollectionState extends State<CollectionScreen> {
  int _show = 0; // 0 all, 1 over 30 days, 2 over 60 days

  String _all(List<AgedBuyer> l, double total) {
    final StringBuffer b = StringBuffer();
    b.writeln('Balaji Industries');
    b.writeln('${bi('ઉઘરાણી યાદી', 'Collection list')} (${dmy(DateTime.now())})');
    b.writeln('------------------------');
    for (final AgedBuyer a in l.take(40)) {
      b.writeln('${a.label}: ${inr(a.due)}${a.oldDays > 0 ? ' (${a.oldDays} ${bi('દિવસ', 'days')})' : ''}');
    }
    b.writeln('------------------------');
    b.writeln('${bi('કુલ', 'Total')}: ${inr(total)}');
    return b.toString().trim();
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[saleDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 820,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final List<AgedBuyer> all = agedBuyers().where((AgedBuyer a) => a.due > 0.5).toList();
          final List<double> tot = <double>[0, 0, 0, 0];
          for (final AgedBuyer a in all) {
            for (int i = 0; i < 4; i++) {
              tot[i] += a.bucket[i];
            }
          }
          final double total = tot[0] + tot[1] + tot[2] + tot[3];
          final double old30 = tot[2] + tot[3];
          final List<AgedBuyer> l = all.where((AgedBuyer a) {
            if (_show == 1) return a.bucket[2] + a.bucket[3] > 0.5;
            if (_show == 2) return a.bucket[3] > 0.5;
            return true;
          }).toList();
          l.sort((AgedBuyer a, AgedBuyer b) {
            final int c = b.oldDays.compareTo(a.oldDays);
            return c != 0 ? c : b.due.compareTo(a.due);
          });
          final List<String> names = _bucketNames();
          return <Widget>[
            ScreenHeader(bi('ઉઘરાણી', 'Collection'), sub: bi('કોની પાસે કેટલા દિવસથી બાકી', 'Who owes, and since when')),
            statusBanner(),
            HeroCard(
              title: bi('કુલ ઉઘરાણી બાકી', 'Total to collect'),
              value: inrC(total),
              unit: '',
              sub: '${all.length} ${bi('ખરીદનાર', 'buyers')}',
              chips: <HeroChip>[
                HeroChip('warn', '${bi('30 દિવસથી જૂના', 'Over 30 days')} ${inrC(old30)}'),
                HeroChip('users', '${bi('60 દિવસથી જૂના', 'Over 60 days')} ${inrC(tot[3])}'),
              ],
            ),
            const SizedBox(height: 12),
            if (all.isNotEmpty)
              Panel(
                title: bi('ઉંમર મુજબ બાકી', 'Dues by age'),
                sub: bi('આવેલી રકમ સૌથી જૂના બિલમાં ગણાય છે', 'Money received is set against the oldest bills'),
                child: RankList(<RankItem>[
                  for (int i = 0; i < 4; i++) RankItem(names[i], tot[i], inr(tot[i]), _bucketColor(i)),
                ]),
              ),
            if (all.isNotEmpty) const SizedBox(height: 12),
            if (all.isNotEmpty)
              Btn(bi('આખી યાદી WhatsApp પર', 'Send the list on WhatsApp'), icon: 'chat', kind: BtnKind.tonal, expand: true, onTap: () => whatsappText(_all(all, total))),
            if (all.isNotEmpty) const SizedBox(height: 12),
            ChipRow(
              labels: <String>[bi('બધા', 'All'), bi('30 દિવસથી જૂના', 'Over 30 days'), bi('60 દિવસથી જૂના', 'Over 60 days')],
              index: _show,
              onChanged: (int i) => setState(() => _show = i),
            ),
            const SizedBox(height: 12),
            if (l.isEmpty)
              EmptyBox(
                icon: 'check',
                title: all.isEmpty ? bi('કોઈનું બાકી નથી', 'Nobody owes anything') : bi('આ યાદીમાં કોઈ નથી', 'Nobody in this list'),
                sub: all.isEmpty ? bi('વેચાણ નાખશો એટલે અહીં દેખાશે', 'Sales you add will show here') : null,
              ),
            for (final AgedBuyer a in l.take(150))
              lineItem(
                icon: 'users',
                tone: a.oldDays > 60 ? 'rose' : (a.oldDays > 30 ? 'amber' : 'teal'),
                title: a.label,
                sub: '${a.oldDays} ${bi('દિવસ જૂનું', 'days old')}${buyerPhone(a.key).isEmpty ? '' : ' · ${buyerPhone(a.key)}'}',
                trailing: inr(a.due),
                trailingSub: bi('બાકી', 'due'),
                trailingColor: a.oldDays > 60 ? Pal.bad : (a.oldDays > 30 ? Pal.warn : null),
                onTap: () => openCollectPanel(ctx, a),
              ),
          ];
        },
      ),
    );
  }
}

// ---------------------------------------------------------- cash flow
class CashFlowScreen extends StatefulWidget {
  const CashFlowScreen({super.key});

  @override
  State<CashFlowScreen> createState() => _CashFlowState();
}

class _CashFlowState extends State<CashFlowScreen> {
  RangeSel _sel = RangeSel(4);

  static String _mode(String m) {
    for (final List<String> k in kPayModes) {
      if (k[0] == m) return bi(k[1], k[2]);
    }
    return m;
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[payDoc, expDoc, saleDoc, rateDoc, prefDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 860,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final Period p = _sel.period;
          final DateTime today = dayOf(DateTime.now());
          double inBuyer = 0;
          double inBack = 0;
          double inOther = 0;
          double outFarmer = 0;
          double outExp = 0;
          double sold = 0;
          final Map<String, double> inMode = <String, double>{};
          final Map<String, double> outMode = <String, double>{};
          final Map<String, double> outCat = <String, double>{};
          final Map<String, double> dayIn = <String, double>{};
          final Map<String, double> dayOut = <String, double>{};

          void add(Map<String, double> m, String k, double v) => m[k] = (m[k] ?? 0) + v;

          for (final SaleItem s in saleItems()) {
            if (!p.has(s.date)) continue;
            if (s.kind == 'sale') sold += s.amt;
            if (s.kind != 'recv') continue;
            inBuyer += s.amt;
            add(inMode, s.mode, s.amt);
            add(dayIn, dayKey(s.date), s.amt);
          }
          for (final PayItem x in payItems()) {
            if (x.kind == 'open' || !p.has(x.date)) continue;
            if (x.kind == 'recv') {
              inBack += x.amt;
              add(inMode, x.mode, x.amt);
              add(dayIn, dayKey(x.date), x.amt);
            } else {
              outFarmer += x.amt;
              add(outMode, x.mode, x.amt);
              add(dayOut, dayKey(x.date), x.amt);
            }
          }
          for (final ExpItem x in expItems()) {
            if (!p.has(x.date)) continue;
            if (x.isIn) {
              inOther += x.amt;
              add(inMode, x.mode, x.amt);
              add(dayIn, dayKey(x.date), x.amt);
            } else {
              outExp += x.amt;
              add(outMode, x.mode, x.amt);
              add(outCat, x.cat, x.amt);
              add(dayOut, dayKey(x.date), x.amt);
            }
          }
          double bought = 0;
          for (final Chit c in live.chits) {
            if (!p.has(c.at)) continue;
            bought += chitAmount(c) ?? 0;
          }
          final double totIn = inBuyer + inBack + inOther;
          final double totOut = outFarmer + outExp;
          final double net = totIn - totOut;

          // chart: one point per day (grouped when the period is long)
          final DateTime end = p.to.isAfter(addDays(today, 1)) ? addDays(today, 1) : p.to;
          final List<DateTime> days = <DateTime>[];
          for (DateTime d = p.from; d.isBefore(end); d = addDays(d, 1)) {
            days.add(d);
          }
          final int group = days.length <= 31 ? 1 : (days.length / 31).ceil();
          final List<String> labels = <String>[];
          final List<double> vIn = <double>[];
          final List<double> vOut = <double>[];
          final int points = (days.length / group).ceil();
          for (int i = 0; i < days.length; i += group) {
            double a = 0;
            double b = 0;
            for (int j = i; j < i + group && j < days.length; j++) {
              a += dayIn[dayKey(days[j])] ?? 0;
              b += dayOut[dayKey(days[j])] ?? 0;
            }
            labels.add(axisDay(labels.length, points, days[i]));
            vIn.add(a);
            vOut.add(b);
          }

          final List<MapEntry<String, double>> cats = outCat.entries.toList();
          cats.sort((MapEntry<String, double> a, MapEntry<String, double> b) => b.value.compareTo(a.value));
          final List<String> modes = <String>[];
          for (final String m in <String>[...inMode.keys, ...outMode.keys]) {
            if (!modes.contains(m)) modes.add(m);
          }

          String text() {
            final StringBuffer b = StringBuffer();
            b.writeln('Balaji Industries');
            b.writeln('${bi('આવક-જાવક', 'Cash flow')} - ${p.label}');
            b.writeln('------------------------');
            b.writeln('${bi('ખરીદનાર પાસેથી', 'From buyers')}: ${inr(inBuyer)}');
            if (inBack > 0) b.writeln('${bi('ખેડૂત પાસેથી પાછા', 'Back from farmers')}: ${inr(inBack)}');
            if (inOther > 0) b.writeln('${bi('બીજી આવક', 'Other income')}: ${inr(inOther)}');
            b.writeln('${bi('કુલ આવક', 'Total in')}: ${inr(totIn)}');
            b.writeln('------------------------');
            b.writeln('${bi('ખેડૂતોને ચૂકવ્યા', 'Paid to farmers')}: ${inr(outFarmer)}');
            b.writeln('${bi('ખર્ચ', 'Expenses')}: ${inr(outExp)}');
            b.writeln('${bi('કુલ જાવક', 'Total out')}: ${inr(totOut)}');
            b.writeln('------------------------');
            b.writeln('${bi('ચોખ્ખું', 'Net')}: ${signedInr(net)}');
            return b.toString().trim();
          }

          final Widget inBox = Panel(
            title: '${bi('આવક', 'Money in')} · ${inr(totIn)}',
            child: totIn <= 0
                ? Text(bi('કોઈ નહીં', 'None'), style: ts(13, c: Pal.muted))
                : RankList(<RankItem>[
                    if (inBuyer > 0) RankItem(bi('ખરીદનાર પાસેથી', 'From buyers'), inBuyer, inr(inBuyer), Pal.ok),
                    if (inBack > 0) RankItem(bi('ખેડૂત પાસેથી પાછા', 'Back from farmers'), inBack, inr(inBack), Pal.info),
                    if (inOther > 0) RankItem(bi('બીજી આવક', 'Other income'), inOther, inr(inOther), Pal.amber),
                  ]),
          );
          final Widget outBox = Panel(
            title: '${bi('જાવક', 'Money out')} · ${inr(totOut)}',
            child: totOut <= 0
                ? Text(bi('કોઈ નહીં', 'None'), style: ts(13, c: Pal.muted))
                : RankList(<RankItem>[
                    if (outFarmer > 0) RankItem(bi('ખેડૂતોને', 'To farmers'), outFarmer, inr(outFarmer), Pal.bad),
                    for (final MapEntry<String, double> e in cats.take(8)) RankItem(expCatLabel(e.key), e.value, inr(e.value), Pal.warn),
                  ]),
          );

          return <Widget>[
            ScreenHeader(bi('આવક-જાવક', 'Cash flow'), sub: p.label),
            statusBanner(),
            RangeBar(sel: _sel, presets: const <int>[0, 2, 3, 4, 5, 6], onChanged: (RangeSel s) => setState(() => _sel = s)),
            const SizedBox(height: 12),
            HeroCard(
              title: net < 0 ? bi('જાવક વધારે', 'More went out') : bi('આવક વધારે', 'More came in'),
              value: '${net < 0 ? '-' : ''}${inrC(net.abs())}',
              unit: '',
              sub: p.label,
              chips: <HeroChip>[
                HeroChip('arrowdown', '${bi('આવક', 'In')} ${inrC(totIn)}'),
                HeroChip('arrowup', '${bi('જાવક', 'Out')} ${inrC(totOut)}'),
              ],
            ),
            const SizedBox(height: 12),
            if (labels.length >= 2)
              Panel(
                title: bi('દિવસ મુજબ', 'By day'),
                child: LineChartX(
                  series: <LineSeries>[
                    LineSeries(bi('આવક', 'In'), vIn, Pal.ok),
                    LineSeries(bi('જાવક', 'Out'), vOut, Pal.bad),
                  ],
                  labels: labels,
                  axisFmt: (double v) => inrC(v),
                  height: 200,
                ),
              ),
            if (labels.length >= 2) const SizedBox(height: 12),
            SplitPane(children: <Widget>[inBox, outBox]),
            const SizedBox(height: 12),
            if (modes.isNotEmpty)
              Panel(
                title: bi('રોકડ / UPI / બેંક', 'Cash / UPI / bank'),
                child: Column(
                  children: <Widget>[
                    for (final String m in modes) InfoRow(_mode(m), '${bi('આવક', 'In')} ${inr(inMode[m] ?? 0)} · ${bi('જાવક', 'Out')} ${inr(outMode[m] ?? 0)}'),
                  ],
                ),
              ),
            if (modes.isNotEmpty) const SizedBox(height: 12),
            Panel(
              title: bi('ધંધાનું ચિત્ર', 'Business picture'),
              sub: bi('આ સમયનું વેચાણ અને ખરીદ - બાકી સ્ટોક અને ઉધાર ગણ્યા નથી', 'Sales and purchases of the period - stock and credit are not counted'),
              child: Column(
                children: <Widget>[
                  InfoRow(bi('વેચાણ (બિલ)', 'Sales (billed)'), inr(sold)),
                  InfoRow(bi('ખરીદ રકમ (ચિઠ્ઠી)', 'Purchase value (chits)'), inr(bought)),
                  InfoRow(bi('ખર્ચ', 'Expenses'), inr(outExp)),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Btn(bi('WhatsApp પર મોકલો', 'Send on WhatsApp'), icon: 'chat', expand: true, onTap: () => whatsappText(text())),
          ];
        },
      ),
    );
  }
}

// ------------------------------------------------------------ home strip
/// Three numbers for the owner's home: today's sales, what is to be collected
/// and the raw material in stock.
class TradeStrip extends StatelessWidget {
  const TradeStrip({super.key});

  Widget _stat(String label, String value, {Color? color, String? sub, VoidCallback? onTap}) {
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12, w: FontWeight.w700, c: Pal.muted)),
              const SizedBox(height: 4),
              FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text(value, style: ts(20, w: FontWeight.w800, c: color, tab: true)),
              ),
              if (sub != null) Text(sub, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(11.5, c: Pal.muted)),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!live.isAdmin) return const SizedBox.shrink();
    return DocsScope(
      docs: <SyncDoc>[saleDoc, procDoc, prefDoc],
      builder: (BuildContext _) {
        final DateTime today = dayOf(DateTime.now());
        double soldToday = 0;
        int billsToday = 0;
        for (final SaleItem x in saleItems()) {
          if (x.isSale && sameDay(x.date, today)) {
            soldToday += x.amt;
            billsToday++;
          }
        }
        double due = 0;
        double old30 = 0;
        for (final AgedBuyer a in agedBuyers()) {
          due += a.due;
          old30 += a.bucket[2] + a.bucket[3];
        }
        double raw = 0;
        for (final StockLine r in stockRows()) {
          if (r.raw) raw += r.left;
        }
        return Padding(
          padding: const EdgeInsets.only(top: 12),
          child: Surface(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
            child: Row(
              children: <Widget>[
                _stat(bi('આજે વેચાણ', 'Sold today'), inrC(soldToday), sub: '$billsToday ${bi('બિલ', 'bills')}', onTap: () => app.go('sales')),
                Container(width: 1, height: 46, color: Pal.line),
                _stat(bi('ઉઘરાણી બાકી', 'To collect'), inrC(due), color: old30 > 0 ? Pal.warn : null, sub: old30 > 0 ? '${inrC(old30)} ${bi('જૂના', 'old')}' : null, onTap: () => app.go('collection')),
                Container(width: 1, height: 46, color: Pal.line),
                _stat(bi('કાચો સ્ટોક', 'Raw stock'), kgTxt(raw), color: raw < -0.5 ? Pal.bad : null, onTap: () => app.go('stock_live')),
              ],
            ),
          ),
        );
      },
    );
  }
}

// ------------------------------------------------------------------ margin
/// Buying rate against selling rate, and a rough result of processing.
class MarginScreen extends StatefulWidget {
  const MarginScreen({super.key});

  @override
  State<MarginScreen> createState() => _MarginState();
}

class _MarginState extends State<MarginScreen> {
  RangeSel _sel = RangeSel(4);

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[saleDoc, procDoc, rateDoc, prefDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 820,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final Period p = _sel.period;
          final Map<String, double> buyKg = <String, double>{};
          final Map<String, double> buyAmt = <String, double>{};
          for (final Chit c in live.chits) {
            if (!p.has(c.at)) continue;
            final double? a = chitAmount(c);
            final String k = c.commodity.trim().toLowerCase();
            if (a == null || k.isEmpty) continue;
            buyKg[k] = (buyKg[k] ?? 0) + payKg(c);
            buyAmt[k] = (buyAmt[k] ?? 0) + a;
          }
          double buyRate(String code) {
            final String k = code.trim().toLowerCase();
            final double kg = buyKg[k] ?? 0;
            return kg > 0 ? (buyAmt[k] ?? 0) / kg * 20 : 0;
          }

          final Map<String, double> sKg = <String, double>{};
          final Map<String, double> sAmt = <String, double>{};
          final Map<String, String> sName = <String, String>{};
          for (final SaleItem x in saleItems()) {
            if (!x.isSale || !p.has(x.date) || x.kg <= 0 || x.item.trim().isEmpty) continue;
            final String k = stockKey(x.src == 'raw', x.item);
            sKg[k] = (sKg[k] ?? 0) + x.kg;
            sAmt[k] = (sAmt[k] ?? 0) + x.amt;
            sName[k] = x.src == 'raw' ? matLabel(x.item) : x.item;
          }
          double sellRate(String key) {
            final double kg = sKg[key] ?? 0;
            return kg > 0 ? (sAmt[key] ?? 0) / kg * 20 : 0;
          }

          // raw material sold as it is
          final List<String> raws = <String>[];
          for (final String k in buyKg.keys) {
            if (!raws.contains(k)) raws.add(k);
          }
          for (final String k in sKg.keys) {
            if (k.startsWith('raw|') && !raws.contains(k.substring(4))) raws.add(k.substring(4));
          }
          double totalMargin = 0;
          final List<Widget> rawRows = <Widget>[];
          for (final String code in raws) {
            final double b = buyRate(code);
            final double sr = sellRate(stockKey(true, code));
            final double soldKg = sKg[stockKey(true, code)] ?? 0;
            final bool both = b > 0 && sr > 0;
            final double diff = both ? sr - b : 0;
            final double total = both ? diff / 20 * soldKg : 0;
            totalMargin += total;
            rawRows.add(lineItem(
              icon: 'grain',
              tone: 'amber',
              title: matLabel(code),
              sub: '${bi('ખરીદ', 'Bought')} ${b > 0 ? '₹${plainNum(double.parse(b.toStringAsFixed(1)))}' : '-'} · ${bi('વેચાણ', 'Sold')} ${sr > 0 ? '₹${plainNum(double.parse(sr.toStringAsFixed(1)))}' : '-'} ${bi('(20 KG)', '(20 KG)')}',
              trailing: both ? signedInr(total) : '-',
              trailingSub: both ? '${diff >= 0 ? '+' : '-'}₹${plainNum(double.parse(diff.abs().toStringAsFixed(1)))} / 20 KG' : (sr > 0 ? bi('ખરીદ ભાવ નથી', 'no buy rate') : bi('વેચાણ નથી', 'not sold')),
              trailingColor: both ? (total >= 0 ? Pal.ok : Pal.bad) : null,
            ));
          }

          // finished grades: selling rate only
          final List<String> outs = sKg.keys.where((String k) => k.startsWith('out|')).toList();
          outs.sort((String a, String b) => (sAmt[b] ?? 0).compareTo(sAmt[a] ?? 0));

          // processing estimate
          double procCost = 0;
          double procValue = 0;
          double unpricedKg = 0;
          int batches = 0;
          for (final ProcBatch b in procBatches()) {
            if (!p.has(b.date)) continue;
            batches++;
            double r = buyRate(b.material);
            if (r <= 0) r = rateFor(b.material.trim(), b.date) ?? 0;
            procCost += b.inKg / 20 * r;
            for (final ProcOut o in b.outs) {
              final double sr = sellRate(stockKey(false, o.grade));
              if (sr > 0) {
                procValue += o.kg / 20 * sr;
              } else {
                unpricedKg += o.kg;
              }
            }
          }

          return <Widget>[
            ScreenHeader(bi('માર્જિન', 'Margin'), sub: p.label),
            statusBanner(),
            RangeBar(sel: _sel, presets: const <int>[0, 2, 3, 4, 5, 6], onChanged: (RangeSel s) => setState(() => _sel = s)),
            const SizedBox(height: 12),
            HeroCard(
              title: bi('કાચો માલ સીધો વેચ્યો - માર્જિન', 'Margin on raw material sold as is'),
              value: signedInr(totalMargin),
              unit: '',
              sub: bi('વેચાણ ભાવ - ખરીદ ભાવ, વેચેલા વજન પર', 'Sale rate - buy rate, on the weight sold'),
              chips: <HeroChip>[
                HeroChip('grain', '${raws.length} ${bi('માલ', 'items')}'),
                HeroChip('receipt', '${sKg.length} ${bi('વેચાણ પ્રકાર', 'sold types')}'),
              ],
            ),
            const SizedBox(height: 12),
            if (rawRows.isEmpty) EmptyBox(icon: 'pct', title: bi('આ સમયમાં ખરીદ કે વેચાણ નથી', 'No buying or selling in this period'), sub: bi('ખરીદ ભાવ માટે "ભાવ" માં રેટ નાખેલા હોવા જોઈએ', 'Buy rates come from the rates you set in "Rates"')),
            if (rawRows.isNotEmpty) caption(bi('કાચો માલ (પ્રતિ 20 KG)', 'RAW MATERIAL (PER 20 KG)')),
            ...rawRows,
            if (outs.isNotEmpty) caption(bi('તૈયાર માલ - વેચાણ ભાવ', 'FINISHED GOODS - SELLING RATE')),
            for (final String k in outs)
              lineItem(
                icon: 'box',
                tone: 'teal',
                title: sName[k] ?? k,
                sub: '${kgTxt(sKg[k] ?? 0)} ${bi('વેચ્યું', 'sold')}',
                trailing: '₹${plainNum(double.parse(sellRate(k).toStringAsFixed(1)))}',
                trailingSub: '/ 20 KG',
              ),
            if (batches > 0) ...<Widget>[
              const SizedBox(height: 12),
              Panel(
                title: bi('પ્રોસેસનો આશરે નફો', 'Rough result of processing'),
                sub: bi('$batches પ્રોસેસ · કાચા માલની કિંમત સામે નીકળેલા ગ્રેડ વેચાણ ભાવે', '$batches batches · raw cost against the grades at selling rate'),
                child: Column(
                  children: <Widget>[
                    InfoRow(bi('વાપરેલા કાચા માલની કિંમત', 'Cost of raw material used'), inr(procCost)),
                    InfoRow(bi('નીકળેલા ગ્રેડની કિંમત', 'Value of grades obtained'), inr(procValue)),
                    InfoRow(bi('આશરે ફરક', 'Rough difference'), signedInr(procValue - procCost), bold: true, color: procValue - procCost >= 0 ? Pal.ok : Pal.bad),
                    if (unpricedKg > 0) InfoRow(bi('વેચાણ ભાવ વગરનો માલ', 'Without a selling rate'), '${grp(unpricedKg, dec: 0)} KG'),
                  ],
                ),
              ),
              noteBox('info', 'slate', bi('આ અંદાજ છે - મજૂરી, વીજળી, ભાડું અને બાકી સ્ટોક ગણ્યા નથી.', 'This is an estimate - labour, power, freight and unsold stock are not counted.')),
            ],
          ];
        },
      ),
    );
  }
}
