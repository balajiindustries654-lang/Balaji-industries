import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/app_state.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/kanta_auto.dart';
import '../../data/matrix_slip.dart';
import '../../data/native_io.dart';
import '../../widgets/common.dart';
import '../../widgets/page.dart';
import 'field.dart';
import 'kit2.dart';
import 'ui.dart';

// ======================================================================
// Automatic weighbridge (beta)
//  reads the file of the weighbridge software and sends new weighings to the app
// ======================================================================

class KantaAutoScreen extends StatefulWidget {
  /// File text to read at once (for example a shared / copied terminal report).
  final String text;
  const KantaAutoScreen({super.key, this.text = ''});

  @override
  State<KantaAutoScreen> createState() => _KantaAutoState();
}

class _KantaAutoState extends State<KantaAutoScreen> {
  final TextEditingController _path = TextEditingController();
  final TextEditingController _paste = TextEditingController();
  String _text = '';
  List<int>? _bytes;
  String _fileName = '';
  KantaScan? _scan;
  String _err = '';
  String _info = '';
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    if (widget.text.trim().isNotEmpty) {
      _paste.text = widget.text;
      _text = widget.text;
      WidgetsBinding.instance.addPostFrameCallback((Duration _) {
        if (mounted) _rescan();
      });
    }
    kantaAuto.addListener(_tick);
    kantaAuto.load().then((_) {
      if (mounted) {
        _path.text = kantaAuto.path;
        setState(() {});
      }
    });
  }

  @override
  void dispose() {
    kantaAuto.removeListener(_tick);
    _path.dispose();
    _paste.dispose();
    super.dispose();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  void _rescan() {
    final List<int>? b = _bytes;
    if (b == null && _text.trim().isEmpty) return;
    try {
      final KantaScan s = b != null ? kantaScanBytes(b, kantaAuto.cols) : kantaScan(_text, kantaAuto.cols);
      setState(() {
        _scan = s;
        _err = s.table.isEmpty ? bi('ફાઇલ ખાલી છે', 'The file is empty') : '';
      });
    } on FormatException catch (e) {
      setState(() {
        _scan = null;
        _err = e.message == 'xls'
            ? bi('આ .xls ફાઇલ વંચાઈ નહીં. ટર્મિનલમાં Export CSV / XLSX કરો, અથવા ફાઇલ Excel માં ખોલી "Save as CSV" કરો.', 'This .xls file could not be read. Export CSV / XLSX from the terminal, or open it in Excel and "Save as CSV".')
            : bi('ફાઇલ વંચાઈ નહીં', 'Could not read the file');
      });
    } catch (_) {
      setState(() {
        _scan = null;
        _err = bi('ફાઇલ વંચાઈ નહીં - ફાઇલ તૂટેલી હોઈ શકે', 'Could not read the file - it may be damaged');
      });
    }
  }

  Future<void> _chooseFile() async {
    setState(() {
      _busy = true;
      _err = '';
      _info = '';
    });
    final PickedFile? f = await pickFile();
    if (!mounted) return;
    if (f != null) {
      _bytes = f.bytes;
      _text = '';
      _fileName = f.name;
      _rescan();
    }
    setState(() => _busy = false);
  }

  Future<void> _readFile() async {
    final String p = _path.text.trim();
    if (p.isEmpty) {
      setState(() => _err = bi('ફાઇલ અથવા ફોલ્ડરનો path લખો', 'Enter the file or folder path'));
      return;
    }
    setState(() {
      _busy = true;
      _err = '';
      _info = '';
    });
    kantaAuto.path = p;
    await kantaAuto.save();
    try {
      _bytes = await kantaAuto.readBytes();
      _text = '';
      _fileName = p.split(RegExp(r'[\\/]')).last;
      _rescan();
    } catch (e) {
      setState(() => _err = '${bi('ફાઇલ વંચાઈ નહીં', 'Could not read the file')}: $e');
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _fromClipboard() async {
    final ClipboardData? c = await Clipboard.getData(Clipboard.kTextPlain);
    final String t = c?.text ?? '';
    if (t.trim().isEmpty) {
      setState(() => _err = bi('ક્લિપબોર્ડમાં કંઈ નથી', 'The clipboard is empty'));
      return;
    }
    _paste.text = t;
    _text = t;
    _bytes = null;
    _info = '';
    _rescan();
  }

  void _fromPaste() {
    _text = _paste.text;
    _bytes = null;
    _info = '';
    _rescan();
  }

  Future<void> _setCols(KantaCols c) async {
    c.manual = true;
    kantaAuto.cols = c;
    await kantaAuto.save();
    _rescan();
  }

  List<KantaRow> _fresh(KantaScan s) {
    final List<KantaRow> out = <KantaRow>[];
    for (final KantaRow r in s.rows) {
      if (!r.ok || kantaAuto.seen.contains(r.key) || kantaKnown(r)) continue;
      out.add(r);
    }
    return out;
  }

  Future<void> _sendNow(List<KantaRow> fresh) async {
    final bool go = await confirmBox(context, title: bi('વજન એપમાં નાખવા?', 'Send the weighings to the app?'), text: '${fresh.length} ${bi('નવી કાંટા એન્ટ્રી બનશે (RST, ગાડી, વજન).', 'new weighbridge entries will be made (RST, vehicle, weight).')}', yes: bi('હા, નાખો', 'Yes, send'), no: bi('ના', 'No'));
    if (!go) return;
    setState(() => _busy = true);
    final int n = await kantaAuto.send(fresh);
    app.toast('$n ${bi('કાંટા એન્ટ્રી બની', 'weighbridge entries made')}');
    _info = '$n / ${fresh.length}';
    _rescan();
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _switchAuto(bool want) async {
    if (!want) {
      kantaAuto.on = false;
      await kantaAuto.save();
      kantaAuto.arm();
      return;
    }
    if (_path.text.trim().isEmpty) {
      setState(() => _err = bi('પહેલાં ફાઇલ / ફોલ્ડરનો path લખી "વાંચો" દબાવો', 'First enter the file / folder path and tap "Read"'));
      return;
    }
    if (_scan == null || _scan!.needMap || !_scan!.cols.usable) {
      setState(() => _err = bi('પહેલાં કૉલમ બરાબર ગોઠવો (ગાડી અને વજન જરૂરી)', 'First set the columns properly (vehicle and weight are needed)'));
      return;
    }
    final bool go = await confirmBox(
      context,
      title: bi('ઑટો ચાલુ કરવું?', 'Switch auto on?'),
      text: bi('ફાઇલમાં અત્યારે જે જૂના વજન છે તે નહીં મોકલાય. આજ-ગઈકાલના અને હવે પછીના નવા વજન દર ~૪૫ સેકન્ડે આપોઆપ એપમાં જશે. આ કામ ત્યારે જ ચાલશે જ્યારે આ PC પર એપ ખુલ્લી હોય.', 'Old weighings already in the file are not sent. Today\'s, yesterday\'s and all new weighings go to the app by themselves about every 45 seconds. This works only while the app is open on this PC.'),
      yes: bi('હા, ચાલુ કરો', 'Yes, switch on'),
      no: bi('ના', 'No'),
    );
    if (!go) return;
    setState(() => _busy = true);
    kantaAuto.path = _path.text.trim();
    final int n = await kantaAuto.baseline();
    kantaAuto.on = true;
    await kantaAuto.save();
    kantaAuto.arm();
    _info = '$n ${bi('જૂના વજન છોડ્યા', 'old weighings skipped')}';
    unawaited(kantaAuto.tick());
    if (mounted) setState(() => _busy = false);
  }

  String _colText(KantaScan s, int i) {
    if (i < 0) return '—';
    final String head = i < s.head.length ? s.head[i] : '';
    String sample = '';
    if (s.start < s.table.length && i < s.table[s.start].length) sample = s.table[s.start][i];
    final String a = head.isEmpty ? '' : head;
    return 'C${i + 1}${a.isEmpty ? '' : ' · $a'}${sample.isEmpty || sample == a ? '' : ' (${sample.length > 14 ? sample.substring(0, 14) : sample})'}';
  }

  Widget _pick(KantaScan s, String label, int cur, void Function(KantaCols c, int v) set) {
    final List<int> items = <int>[-1, for (int i = 0; i < s.width; i++) i];
    return Row(
      children: <Widget>[
        SizedBox(width: 104, child: Text(label, style: ts(13, w: FontWeight.w700))),
        Expanded(
          child: Align(
            alignment: Alignment.centerLeft,
            child: PickX<int>(
              label: _colText(s, cur),
              items: items,
              text: (int i) => _colText(s, i),
              onSelected: (int v) {
                final KantaCols c = KantaCols.fromJson(s.cols.toJson());
                set(c, v);
                c.header = s.headerAt >= 0 || s.cols.header;
                _setCols(c);
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget _columns(KantaScan s) {
    final KantaCols c = s.cols;
    return Surface(
      shadow: false,
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text(bi('કૉલમ (કઈ કૉલમમાં શું છે)', 'Columns (what is in which column)'), style: ts(13.5, w: FontWeight.w800)),
          const SizedBox(height: 4),
          Text(c.manual ? bi('તમે ગોઠવેલ', 'Set by you') : bi('એપે નામ પરથી ઓળખ્યું - ખોટું હોય તો બદલો', 'Guessed from the names - change if wrong'), style: ts(12, c: Pal.muted)),
          const SizedBox(height: 10),
          _pick(s, bi('ગાડી નં. *', 'Vehicle *'), c.veh, (KantaCols x, int v) => x.veh = v),
          const SizedBox(height: 8),
          _pick(s, 'RST', c.rst, (KantaCols x, int v) => x.rst = v),
          const SizedBox(height: 8),
          _pick(s, bi('નેટ વજન', 'Net weight'), c.net, (KantaCols x, int v) => x.net = v),
          const SizedBox(height: 8),
          _pick(s, bi('ગ્રોસ', 'Gross'), c.gross, (KantaCols x, int v) => x.gross = v),
          const SizedBox(height: 8),
          _pick(s, bi('ટેર', 'Tare'), c.tare, (KantaCols x, int v) => x.tare = v),
          const SizedBox(height: 8),
          _pick(s, bi('તારીખ', 'Date'), c.date, (KantaCols x, int v) => x.date = v),
          const SizedBox(height: 8),
          _pick(s, bi('સમય', 'Time'), c.time, (KantaCols x, int v) => x.time = v),
          const SizedBox(height: 12),
          Text(bi('વજનનું માપ', 'Weight unit'), style: ts(12.5, w: FontWeight.w700, c: Pal.muted)),
          const SizedBox(height: 6),
          ChipRow(
            labels: <String>['KG', bi('ટન', 'Tonne')],
            index: c.unit,
            onChanged: (int i) {
              final KantaCols x = KantaCols.fromJson(c.toJson());
              x.unit = i;
              _setCols(x);
            },
          ),
        ],
      ),
    );
  }

  /// What was recognised in a weighbridge terminal report (Matrix style).
  Widget _matrixBox(KantaScan s) {
    final WbScan w = s.wb!;
    final double sum = w.chargeSum;
    final double? tot = w.totalCharge;
    String period = '';
    if (w.first != null && w.last != null) {
      period = w.first == w.last ? '${w.first!.day}/${w.first!.month}/${w.first!.year}' : '${w.first!.day}/${w.first!.month} - ${w.last!.day}/${w.last!.month}/${w.last!.year}';
    }
    return Surface(
      shadow: false,
      color: Pal.soft,
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text(bi('કાંટા ટર્મિનલનો રિપોર્ટ ઓળખાયો', 'Weighbridge terminal report recognised'), style: ts(13.5, w: FontWeight.w800, c: Pal.ok)),
          const SizedBox(height: 4),
          Text(bi('કૉલમ ગોઠવવાની જરૂર નથી - RST, તારીખ, ગાડી, ગ્રોસ, ટેર, નેટ આપોઆપ વંચાયા.', 'No column setting needed - RST, date, vehicle, gross, tare and net were read by themselves.'), style: ts(12, c: Pal.muted)),
          const SizedBox(height: 6),
          if (_fileName.isNotEmpty) InfoRow(bi('ફાઇલ', 'File'), _fileName),
          if (period.isNotEmpty) InfoRow(bi('તારીખો', 'Dates'), period),
          InfoRow(bi('સ્લિપ', 'Slips'), '${w.slips.length}'),
          if (w.partialCount > 0) InfoRow(bi('બીજું વજન બાકી (મોકલાશે નહીં)', 'Second weight missing (not sent)'), '${w.partialCount}', color: Pal.warn),
          if (sum > 0) InfoRow(bi('વજન ફી કુલ', 'Weighing charges'), '₹ ${grp(sum, dec: 0)}${tot == null ? '' : (tot.round() == sum.round() ? '  ✓ ${bi('ફાઇલના કુલ જેટલી', 'same as the file total')}' : '  (${bi('ફાઇલનો કુલ', 'file total')} ₹ ${grp(tot, dec: 0)})')}'),
        ],
      ),
    );
  }

  Widget _preview(KantaScan s) {
    final List<KantaRow> fresh = _fresh(s);
    final int partial = s.rows.where((KantaRow r) => r.partial).length;
    final int bad = s.rows.where((KantaRow r) => !r.ok && !r.partial).length;
    final int known = s.rows.length - fresh.length - bad - partial;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Surface(
          shadow: false,
          color: Pal.soft,
          padding: const EdgeInsets.all(12),
          child: Column(
            children: <Widget>[
              InfoRow(bi('ફાઇલમાં લાઇન', 'Lines in the file'), '${s.rows.length}'),
              InfoRow(bi('એપમાં પહેલેથી છે', 'Already in the app'), '$known'),
              InfoRow(bi('નવી (મોકલવાની)', 'New (to send)'), '${fresh.length}', bold: true, color: fresh.isEmpty ? Pal.muted : Pal.ok),
              if (partial > 0 && !s.matrix) InfoRow(bi('બીજું વજન બાકી (મોકલાશે નહીં)', 'Second weight missing (not sent)'), '$partial', color: Pal.warn),
              if (bad > 0) InfoRow(bi('વાંચી ન શકાઈ (ગાડી / વજન ખૂટે)', 'Unreadable (vehicle / weight missing)'), '$bad', color: Pal.warn),
            ],
          ),
        ),
        const SizedBox(height: 8),
        for (final KantaRow r in fresh.take(8))
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 3),
            child: Row(
              children: <Widget>[
                SizedBox(width: 56, child: Text(r.rst.isEmpty ? '-' : r.rst, style: ts(12.5, c: Pal.muted))),
                Expanded(child: Text(r.name.isEmpty ? r.vehicle : '${r.vehicle} · ${r.name}', maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(13, w: FontWeight.w700))),
                Text('${grp(r.weight, dec: 0)} KG', style: ts(13, w: FontWeight.w800, tab: true)),
              ],
            ),
          ),
        if (fresh.length > 8) Text('... +${fresh.length - 8}', style: ts(12, c: Pal.muted)),
        const SizedBox(height: 10),
        if (fresh.isNotEmpty) (_busy ? const Center(child: CircularProgressIndicator()) : Btn('${fresh.length} ${bi('વજન એપમાં નાખો', 'weighings - send to the app')}', icon: 'check', expand: true, onTap: () => _sendNow(fresh))),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final KantaScan? s = _scan;
    final bool pcOk = kantaFilesPossible;
    return LiveBody(
      maxWidth: 820,
      rows: (BuildContext ctx) {
        return <Widget>[
          ScreenHeader(bi('કાંટો ઑટો (બીટા)', 'Automatic weighbridge (beta)'), sub: bi('કાંટા સોફ્ટવેરની ફાઇલ → એપ', 'weighbridge software file → app')),
          statusBanner(),
          noteBox('info', 'blue', bi('કાંટા ટર્મિનલ (Matrix) નો રિપોર્ટ / કાંટા સોફ્ટવેરની CSV, TXT, XLS, XLSX ફાઇલ અહીં વંચાય છે, અને પૂરા થયેલા વજન RST મુજબ કાંટા એન્ટ્રી તરીકે એપમાં જાય છે. એક જ વજન થયેલી (બીજું વજન બાકી) સ્લિપ છોડી દેવાય છે. જે RST એપમાં છે તે બીજી વાર નહીં બને.', 'The report of the weighbridge terminal (Matrix) or the CSV / TXT / XLS / XLSX file of the weighbridge software is read here, and each finished weighing goes to the app as a weighbridge entry by RST. A slip with only one weight (second weight still to come) is left out. A RST that is already in the app is never made twice.')),
          if (canPickFile && !pcOk) ...<Widget>[
            Surface(
              shadow: false,
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Text(bi('ટર્મિનલની ફાઇલ', 'The terminal file'), style: ts(13.5, w: FontWeight.w800)),
                  const SizedBox(height: 4),
                  Text(bi('ટર્મિનલમાં Report → Export કરી પેન ડ્રાઇવમાં ફાઇલ લો, પેન ડ્રાઇવ OTG થી ફોનમાં લગાવો, પછી નીચે ફાઇલ પસંદ કરો.', 'On the terminal do Report → Export to a pen drive, plug the pen drive into the phone with OTG, then choose the file below.'), style: ts(12, c: Pal.muted)),
                  const SizedBox(height: 10),
                  _busy && s == null ? const Center(child: CircularProgressIndicator()) : Btn(bi('ફાઇલ પસંદ કરો', 'Choose the file'), icon: 'search', expand: true, onTap: _chooseFile),
                ],
              ),
            ),
            const SizedBox(height: 12),
          ],
          if (pcOk) ...<Widget>[
            Surface(
              shadow: false,
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  FieldX(label: bi('ફાઇલ અથવા ફોલ્ડરનો path', 'File or folder path'), controller: _path, hint: r'C:\Kanta\Export'),
                  const SizedBox(height: 4),
                  Text(bi('ફોલ્ડર આપો તો તેની સૌથી નવી .csv / .txt / .xls / .xlsx ફાઇલ વંચાશે.', 'If you give a folder, its newest .csv / .txt / .xls / .xlsx file is read.'), style: ts(12, c: Pal.muted)),
                  const SizedBox(height: 10),
                  _busy && s == null ? const Center(child: CircularProgressIndicator()) : Btn(bi('ફાઇલ વાંચો', 'Read the file'), icon: 'search', expand: true, onTap: _readFile),
                  if (canPickFile) ...<Widget>[
                    const SizedBox(height: 8),
                    Btn(bi('ફાઇલ પસંદ કરો…', 'Choose a file…'), kind: BtnKind.tonal, expand: true, onTap: _chooseFile),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 12),
          ],
          Surface(
            shadow: false,
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Text(pcOk ? bi('અથવા ફાઇલનું લખાણ paste કરો', 'Or paste the text of the file') : bi('કાંટા સોફ્ટવેરની ફાઇલનું લખાણ paste કરો', 'Paste the text of the weighbridge file'), style: ts(13.5, w: FontWeight.w800)),
                const SizedBox(height: 8),
                FieldX(label: bi('ફાઇલનું લખાણ', 'File text'), controller: _paste, maxLines: 5),
                const SizedBox(height: 10),
                Row(
                  children: <Widget>[
                    tExp(child: Btn(bi('Clipboard માંથી', 'From clipboard'), icon: 'copy', kind: BtnKind.tonal, onTap: _fromClipboard)),
                    const SizedBox(width: 10),
                    tExp(child: Btn(bi('વાંચો', 'Read it'), icon: 'search', onTap: _fromPaste)),
                  ],
                ),
              ],
            ),
          ),
          if (_err.isNotEmpty) ...<Widget>[const SizedBox(height: 10), noteBox('warn', 'amber', _err)],
          if (_info.isNotEmpty) ...<Widget>[const SizedBox(height: 10), noteBox('check', 'green', _info)],
          if (s != null && s.table.isNotEmpty) ...<Widget>[
            const SizedBox(height: 12),
            if (s.matrix) _matrixBox(s) else _columns(s),
            const SizedBox(height: 12),
            if (!s.matrix && (s.needMap || !s.cols.usable)) noteBox('warn', 'amber', bi('ગાડી અને વજન (નેટ અથવા ગ્રોસ) ની કૉલમ પસંદ કરો', 'Pick the vehicle column and a weight column (net or gross)')) else _preview(s),
          ],
          const SizedBox(height: 14),
          caption(bi('આપોઆપ મોકલવું', 'Automatic sending')),
          if (!pcOk)
            noteBox('info', 'blue', bi('ફાઇલ જોઈ દર ~૪૫ સેકન્ડે આપોઆપ મોકલવું ફક્ત કાંટા PC (Windows) પર ચાલે છે. ફોનમાં ઉપર ફાઇલ પસંદ કરો - કે USB કેબલથી લાઇવ લો ("કાંટો USB").', 'Checking the file every ~45 s by itself works only on the weighbridge PC (Windows). On the phone choose the file above - or take it live over the USB cable ("Weighbridge USB").'), onTap: () => app.go('kanta_usb'))
          else
            Surface(
              shadow: false,
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  ChipRow(labels: <String>[bi('ચાલુ', 'On'), bi('બંધ', 'Off')], index: kantaAuto.on ? 0 : 1, onChanged: (int i) => _switchAuto(i == 0)),
                  const SizedBox(height: 10),
                  InfoRow(bi('સ્થિતિ', 'Status'), kantaAuto.on ? bi('ચાલુ - દર ~૪૫ સેકન્ડે ફાઇલ તપાસે છે', 'On - checks the file about every 45 s') : bi('બંધ', 'Off'), color: kantaAuto.on ? Pal.ok : Pal.muted),
                  InfoRow(bi('છેલ્લી તપાસ', 'Last check'), kantaAuto.lastRun == null ? '—' : hm(kantaAuto.lastRun!)),
                  InfoRow(bi('કુલ મોકલ્યા', 'Total sent'), '${kantaAuto.sentTotal}'),
                  if (kantaAuto.msg.isNotEmpty) InfoRow(bi('સંદેશ', 'Message'), kantaAuto.msg, color: Pal.warn),
                  const SizedBox(height: 6),
                  Text(bi('ધ્યાન: એપ આ PC પર ખુલ્લી હોય ત્યારે જ ચાલે. ઇન્ટરનેટ ન હોય તો એન્ટ્રી કતારમાં રહે છે અને પછી જાય છે.', 'Note: it runs only while the app is open on this PC. Without internet the entries wait in the queue and go later.'), style: ts(12, c: Pal.muted)),
                ],
              ),
            ),
          const SizedBox(height: 12),
          noteBox('bulb', 'amber', bi('કોઈ ફાઇલ બરાબર ન વંચાય તો તેની નકલ મને મોકલો - કૉલમ બરાબર બેસાડી દઈશ.', 'If a file is not read right, send me a copy of it and the columns can be fitted exactly.')),
        ];
      },
    );
  }
}
