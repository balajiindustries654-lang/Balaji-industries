import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/bank.dart' show bankTokens;
import '../../data/debit.dart';
import '../../data/engine.dart' show Trip;
import '../../data/insights.dart' show dayKey;
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../data/owner_docs.dart';
import '../../widgets/common.dart';
import '../../widgets/launch.dart';
import '../../widgets/page.dart';
import 'field.dart';
import 'kit.dart';
import 'kit2.dart';
import 'money_screens.dart';
import 'tally_data.dart' show TVoucher, TLine, tallyStore;
import 'ui.dart';

import '../../widgets/accept.dart';
// ======================================================================
// Daily debit-note check
//  1. trucks that weighed less than their chits -> the farmer should get a debit note
//  2. the debit notes already in Tally are checked for mistakes
// ======================================================================

int _gap(DateTime a, DateTime b) => a.difference(b).inDays.abs();

/// The same person written a little differently ("Ramesh Patel" / "PATEL RAMESHBHAI").
bool _nameLike(String a, String b) {
  final String ka = nameKey(a);
  final String kb = nameKey(b);
  if (ka.isEmpty || kb.isEmpty) return false;
  if (ka == kb) return true;
  if (ka.length >= 5 && kb.length >= 5 && (ka.contains(kb) || kb.contains(ka))) return true;
  final List<String> ta = bankTokens(a);
  final List<String> tb = bankTokens(b);
  if (ta.isEmpty || tb.isEmpty) return false;
  return ta.every(tb.contains) || tb.every(ta.contains);
}

List<TVoucher> _debitNotes() {
  final List<TVoucher> out = <TVoucher>[];
  for (final TVoucher v in tallyStore.vouchers) {
    if (v.base == 'debitnote' && !v.cancelled && !v.optional) out.add(v);
  }
  out.sort((TVoucher a, TVoucher b) => b.dt.compareTo(a.dt));
  return out;
}

/// Debit notes in Tally for the farmers of a truck, written around the truck's day.
List<TVoucher> _foundFor(GhatRow r, List<TVoucher> dns, int days) {
  final List<TVoucher> out = <TVoucher>[];
  for (final TVoucher v in dns) {
    final int d = v.dt.difference(r.trip.at).inDays;
    if (d < -2 || d > days) continue;
    for (final GhatShare s in r.shares) {
      if (s.farmer.isNotEmpty && _nameLike(v.party, s.farmer)) {
        out.add(v);
        break;
      }
    }
  }
  return out;
}

class _DnFlag {
  final TVoucher v;
  final List<String> why;
  const _DnFlag(this.v, this.why);
}

String _whyText(String code) {
  switch (code) {
    case 'narr':
      return bi('નરેશન (કારણ) લખેલું નથી', 'No narration (reason)');
    case 'big':
      return bi('મોટી રકમ', 'Big amount');
    case 'dup':
      return bi('એવી જ ડેબિટ નોટ ફરી છે', 'Same debit note twice');
    case 'more':
      return bi('ખરીદી કરતાં વધુ રકમ', 'More than the purchases');
    case 'nopurchase':
      return bi('આ પાર્ટીની તાજેતરમાં ખરીદી નથી', 'No recent purchase from this party');
  }
  return code;
}

List<_DnFlag> _audit(DebitCfg cfg, List<TVoucher> dns) {
  final Map<String, List<TVoucher>> buys = <String, List<TVoucher>>{};
  for (final TVoucher v in tallyStore.purchases) {
    if (v.cancelled || v.optional) continue;
    buys.putIfAbsent(nameKey(v.party), () => <TVoucher>[]).add(v);
  }
  final List<_DnFlag> out = <_DnFlag>[];
  for (final TVoucher v in dns) {
    final List<String> why = <String>[];
    if (v.narr.trim().isEmpty) why.add('narr');
    if (cfg.minAmt > 0 && v.amount >= cfg.minAmt) why.add('big');
    for (final TVoucher o in dns) {
      if (o.id == v.id || nameKey(o.party) != nameKey(v.party)) continue;
      if ((o.amount - v.amount).abs() < 0.5 && _gap(o.dt, v.dt) <= 7) {
        why.add('dup');
        break;
      }
    }
    final String pk = nameKey(v.party);
    if (pk.isNotEmpty) {
      final List<TVoucher> b = buys[pk] ?? <TVoucher>[];
      double sum = 0;
      for (final TVoucher x in b) {
        final int d = v.dt.difference(x.dt).inDays;
        if (d >= 0 && d <= cfg.days) sum += x.amount;
      }
      if (sum <= 0) {
        why.add('nopurchase');
      } else if (v.amount > sum) {
        why.add('more');
      }
    }
    if (why.isNotEmpty) out.add(_DnFlag(v, why));
  }
  return out;
}

Future<void> openGhatSheet(BuildContext context, String id) {
  return openPanel(context, title: bi('ઘટ - ડેબિટ નોટ', 'Short weight - debit note'), width: 540, child: _GhatSheet(id));
}

Future<void> _openDnSheet(BuildContext context, _DnFlag f) {
  return openPanel(context, title: f.v.party.isEmpty ? bi('ડેબિટ નોટ', 'Debit note') : f.v.party, sub: '${f.v.no.isEmpty ? '' : '${f.v.no} · '}${dmy(f.v.dt)}', width: 520, child: _DnSheet(f));
}

Future<void> _openSettings(BuildContext context) {
  return openPanel(context, title: bi('તપાસના સેટિંગ', 'Check settings'), width: 460, child: const _DebitSettings());
}

// ----------------------------------------------------------------- settings
class _DebitSettings extends StatefulWidget {
  const _DebitSettings();

  @override
  State<_DebitSettings> createState() => _DebitSettingsState();
}

class _DebitSettingsState extends State<_DebitSettings> {
  late final VoidCallback _accept = () {
    _save();
  };

  final TextEditingController _days = TextEditingController();
  final TextEditingController _amt = TextEditingController();
  final TextEditingController _kg = TextEditingController();
  int _basis = 0;
  bool _auto = true;
  bool _busy = false;
  String _last = '';

  @override
  void initState() {
    super.initState();
    AcceptHub.push(_accept);
    final DebitCfg c = debitCfg();
    _days.text = '${c.days}';
    _amt.text = plainNum(c.minAmt);
    _kg.text = c.minKg == 0 ? '' : plainNum(c.minKg);
    _basis = c.basis;
    _auto = c.auto;
    _last = c.last;
  }

  @override
  void dispose() {
    _days.dispose();
    _amt.dispose();
    _kg.dispose();
    AcceptHub.pop(_accept);
    super.dispose();
  }

  Future<void> _save() async {
    setState(() => _busy = true);
    final int d = dbl(_days.text, 30).round().clamp(1, 365).toInt();
    await saveDebitCfg(DebitCfg(days: d, minAmt: dbl(_amt.text), minKg: dbl(_kg.text), basis: _basis, auto: _auto, last: _last));
    app.toast(bi('સેવ થયું', 'Saved'));
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        FieldX(label: bi('કેટલા દિવસ પાછળ તપાસવું', 'Look back (days)'), controller: _days, suffix: bi('દિવસ', 'days'), keyboard: TextInputType.number),
        const SizedBox(height: 12),
        FieldX(label: bi('ઓછામાં ઓછી ઘટ (KG) - એનાથી ઓછી છોડી દો', 'Smallest short weight (KG) to count'), controller: _kg, suffix: 'KG', keyboard: const TextInputType.numberWithOptions(decimal: true)),
        const SizedBox(height: 12),
        FieldX(label: bi('Tally ની આટલી કે વધુ રકમની ડેબિટ નોટ ધ્યાનથી જુઓ', 'Look closely at Tally debit notes of this amount or more'), controller: _amt, prefix: '₹', keyboard: const TextInputType.numberWithOptions(decimal: true)),
        const SizedBox(height: 14),
        caption(bi('ડેબિટ નોટ કેટલા વજન પર બનાવવી', 'Debit note is made on')),
        ChipRow(labels: <String>[bi('આખી ઘટ', 'The whole short weight'), bi('માન્ય ફરક પછીની ઘટ', 'Only beyond the allowed difference')], index: _basis, onChanged: (int i) => setState(() => _basis = i)),
        const SizedBox(height: 14),
        caption(bi('રોજની ઑટો તપાસ', 'Automatic daily check')),
        ChipRow(labels: <String>[bi('ચાલુ', 'On'), bi('બંધ', 'Off')], index: _auto ? 0 : 1, onChanged: (int i) => setState(() => _auto = i == 0)),
        const SizedBox(height: 6),
        Text(bi('ચાલુ હોય તો દિવસમાં એક વાર એપ ખોલો ત્યારે ઘટવાળી ગાડીઓ ગણીને જણાવશે.', 'When on, the app counts the short trucks once a day when you open it and tells you.'), style: ts(12, c: Pal.muted)),
        const SizedBox(height: 16),
        _busy ? const Center(child: CircularProgressIndicator()) : Btn(bi('સેવ કરો', 'Save'), icon: 'check', expand: true, onTap: _save),
      ],
    );
  }
}

// ------------------------------------------------------------- truck sheet
class _GhatSheet extends StatefulWidget {
  final String id;
  const _GhatSheet(this.id);

  @override
  State<_GhatSheet> createState() => _GhatSheetState();
}

class _GhatSheetState extends State<_GhatSheet> {
  final TextEditingController _note = TextEditingController();
  bool _busy = false;

  @override
  void dispose() {
    _note.dispose();
    super.dispose();
  }

  Future<void> _mark(String state) async {
    setState(() => _busy = true);
    await markGhat(widget.id, state, note: _note.text);
    app.toast(state == 'done' ? bi('ડેબિટ નોટ થઈ ગઈ - નોંધ્યું', 'Marked: debit note made') : bi('છોડી દીધી', 'Skipped'));
    if (mounted) Navigator.of(context).pop();
  }

  Future<void> _clear() async {
    await clearGhat(widget.id);
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final DebitCfg cfg = debitCfg();
    GhatRow? r;
    for (final GhatRow x in ghatRows(cfg)) {
      if (x.id == widget.id) {
        r = x;
        break;
      }
    }
    if (r == null) return EmptyBox(icon: 'fact', title: bi('આ ગાડી હવે યાદીમાં નથી', 'This truck is no longer on the list'));
    final GhatRow g = r;
    final Trip t = g.trip;
    final List<TVoucher> found = tallyStore.vouchers.isEmpty ? <TVoucher>[] : _foundFor(g, _debitNotes(), cfg.days);
    final GhatMark? mk = g.mark;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        InfoRow(bi('ગાડી', 'Vehicle'), t.vehicle.isEmpty ? '-' : t.vehicle),
        InfoRow(bi('તારીખ', 'Date'), dmy(t.at)),
        InfoRow(bi('ખેડૂત', 'Farmers'), t.farmers.isEmpty ? '-' : t.farmers),
        InfoRow(bi('ચિઠ્ઠી વજન', 'Chit weight'), '${grp(t.chitKg, dec: 0)} KG'),
        InfoRow(bi('કાંટા વજન', 'Weighbridge'), '${grp(t.kantaKg, dec: 0)} KG'),
        InfoRow(bi('ઘટ', 'Short'), '${grp(g.shortKg, dec: 0)} KG · ${(g.shortKg / t.chitKg * 100).toStringAsFixed(2)}%', bold: true, color: Pal.bad),
        InfoRow(bi('માન્ય ફરક', 'Allowed'), '${grp(t.tol, dec: 0)} KG'),
        divider(),
        const SizedBox(height: 6),
        caption(bi('ખેડૂત મુજબ ડેબિટ નોટ', 'Debit note by farmer')),
        for (final GhatShare s in g.shares)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(
              children: <Widget>[
                Expanded(child: Text(s.farmer.isEmpty ? '-' : s.farmer, style: ts(13.5, w: FontWeight.w700))),
                Text('${s.shortKg.toStringAsFixed(1)} KG', style: ts(12.5, c: Pal.muted, tab: true)),
                const SizedBox(width: 10),
                SizedBox(width: 96, child: Text(s.rate > 0 ? inr(s.value, dec: 2) : bi('ભાવ નથી', 'no rate'), textAlign: TextAlign.right, style: ts(13.5, w: FontWeight.w800, c: s.rate > 0 ? null : Pal.warn, tab: true))),
              ],
            ),
          ),
        if (g.value > 0) InfoRow(bi('કુલ ડેબિટ નોટ', 'Total debit note'), inr(g.value, dec: 2), bold: true, color: Pal.bad),
        if (g.rateMissing) Padding(padding: const EdgeInsets.only(top: 6), child: Text(bi('જે માલનો તે દિવસનો ભાવ નથી તેની રકમ ગણાઈ નથી (ભાવ સેટિંગમાં નાખો).', 'Items with no rate for that day are not valued (set the rate).'), style: ts(12, c: Pal.muted))),
        divider(),
        const SizedBox(height: 6),
        caption('Tally'),
        if (tallyStore.vouchers.isEmpty)
          noteBox('info', 'blue', bi('Tally નો ડેટા હજી આવ્યો નથી - Tally Agent ચાલુ કરો.', 'No Tally data yet - start the Tally Agent.'))
        else if (found.isEmpty)
          noteBox('warn', 'amber', bi('Tally માં આ ખેડૂતની ડેબિટ નોટ મળી નથી', 'No debit note for these farmers found in Tally'))
        else
          for (final TVoucher v in found)
            lineItem(icon: 'fact', tone: 'green', title: v.party.isEmpty ? v.title : v.party, sub: '${v.no.isEmpty ? '' : '${v.no} · '}${dmy(v.dt)}${v.narr.isEmpty ? '' : ' · ${v.narr}'}', trailing: inr(v.amount, dec: 2)),
        if (mk != null) ...<Widget>[
          const SizedBox(height: 6),
          noteBox(mk.state == 'done' ? 'check' : 'info', mk.state == 'done' ? 'green' : 'blue', '${mk.state == 'done' ? bi('ડેબિટ નોટ થઈ ગઈ', 'Debit note made') : bi('છોડી દીધી', 'Skipped')} · ${dmy(mk.at)}${mk.note.isEmpty ? '' : ' · ${mk.note}'}'),
        ],
        const SizedBox(height: 10),
        if (mk == null) ...<Widget>[
          FieldX(label: bi('નોંધ (ઇચ્છા મુજબ)', 'Note (optional)'), controller: _note),
          const SizedBox(height: 10),
          _busy
              ? const Center(child: CircularProgressIndicator())
              : Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: <Widget>[
                    Btn(bi('ડેબિટ નોટ થઈ ગઈ', 'Debit note made'), icon: 'check', onTap: () => _mark('done')),
                    Btn(bi('છોડી દો', 'Skip'), icon: 'close', kind: BtnKind.outline, onTap: () => _mark('skip')),
                  ],
                ),
        ] else
          Align(alignment: Alignment.centerLeft, child: Btn(bi('નિશાની કાઢો', 'Remove mark'), icon: 'undo', kind: BtnKind.outline, onTap: _clear)),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: <Widget>[
            Btn('WhatsApp', icon: 'chat', kind: BtnKind.tonal, onTap: () => whatsappText(ghatText(g))),
            Btn(bi('કૉપિ', 'Copy'), icon: 'copy', kind: BtnKind.tonal, onTap: () => copyText(ghatText(g))),
          ],
        ),
      ],
    );
  }
}

// -------------------------------------------------------- Tally debit note
class _DnSheet extends StatelessWidget {
  final _DnFlag f;
  const _DnSheet(this.f);

  @override
  Widget build(BuildContext context) {
    final TVoucher v = f.v;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        for (final String w in f.why) noteBox('warn', 'amber', _whyText(w)),
        InfoRow(bi('પાર્ટી', 'Party'), v.party.isEmpty ? '-' : v.party),
        InfoRow(bi('ફર્મ', 'Firm'), v.firm),
        InfoRow(bi('વાઉચર નં.', 'Voucher no.'), v.no.isEmpty ? '-' : v.no),
        InfoRow(bi('તારીખ', 'Date'), dmy(v.dt)),
        InfoRow(bi('રકમ', 'Amount'), inr(v.amount, dec: 2), bold: true),
        InfoRow(bi('નરેશન', 'Narration'), v.narr.isEmpty ? '-' : v.narr),
        if (v.lines.isNotEmpty) ...<Widget>[
          divider(),
          const SizedBox(height: 6),
          for (final TLine l in v.lines)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(
                children: <Widget>[
                  Expanded(child: Text(l.ledger, style: ts(13))),
                  Text(inr(l.amount.abs(), dec: 2), style: ts(13, w: FontWeight.w700, tab: true)),
                ],
              ),
            ),
        ],
      ],
    );
  }
}

// ------------------------------------------------------------------ screen
class DebitCheckScreen extends StatefulWidget {
  const DebitCheckScreen({super.key});

  @override
  State<DebitCheckScreen> createState() => _DebitState();
}

class _DebitState extends State<DebitCheckScreen> {
  int _tab = 0; // 0 trucks, 1 Tally debit notes
  int _f = 0; // 0 open, 1 in Tally, 2 done, 3 skipped, 4 all
  bool _ran = false;

  @override
  void initState() {
    super.initState();
    tallyStore.addListener(_tick);
    if (tallyStore.vouchers.isEmpty && !tallyStore.loading) {
      tallyStore.load();
    }
  }

  @override
  void dispose() {
    tallyStore.removeListener(_tick);
    super.dispose();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  /// Once a day (when switched on) the check is stamped as done and the owner is told how many trucks wait.
  void _daily(DebitCfg c, int open) {
    if (_ran) return;
    _ran = true;
    final String today = dayKey(DateTime.now());
    if (!c.auto || c.last == today) return;
    Future<void>.microtask(() async {
      await saveDebitCfg(DebitCfg(days: c.days, minAmt: c.minAmt, minKg: c.minKg, basis: c.basis, auto: c.auto, last: today));
      if (open > 0) app.toast('$open ${bi('ગાડીમાં ઘટ છે - ડેબિટ નોટ તપાસો', 'trucks are short - check the debit notes')}');
    });
  }

  List<PcCol> _cols() => <PcCol>[
        PcCol(bi('તારીખ', 'Date'), 96),
        PcCol(bi('ગાડી', 'Vehicle'), 120),
        PcCol(bi('ખેડૂત', 'Farmers'), 0),
        PcCol(bi('ચિઠ્ઠી KG', 'Chit KG'), 100, right: true),
        PcCol(bi('કાંટા KG', 'Kanta KG'), 100, right: true),
        PcCol(bi('ઘટ KG', 'Short KG'), 90, right: true),
        PcCol(bi('ડેબિટ નોટ ₹', 'Debit note ₹'), 120, right: true),
        PcCol(bi('સ્થિતિ', 'Status'), 130),
      ];

  String _stText(String st) {
    switch (st) {
      case 'tally':
        return bi('Tally માં છે', 'In Tally');
      case 'done':
        return bi('થઈ ગઈ', 'Done');
      case 'skip':
        return bi('છોડેલી', 'Skipped');
    }
    return bi('બનાવવાની', 'To make');
  }

  String _stTone(String st) {
    switch (st) {
      case 'tally':
      case 'done':
        return 'green';
      case 'skip':
        return 'slate';
    }
    return 'rose';
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[debitDoc, prefDoc, rateDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 1100,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final DebitCfg cfg = debitCfg();
          final List<GhatRow> rows = ghatRows(cfg);
          final bool tOn = tallyStore.vouchers.isNotEmpty;
          final List<TVoucher> dns = _debitNotes();
          final Map<String, String> status = <String, String>{};
          final Map<String, List<TVoucher>> found = <String, List<TVoucher>>{};
          int open = 0;
          int inTally = 0;
          int done = 0;
          int skip = 0;
          double openVal = 0;
          for (final GhatRow r in rows) {
            final List<TVoucher> fv = tOn ? _foundFor(r, dns, cfg.days) : <TVoucher>[];
            found[r.id] = fv;
            String st;
            final GhatMark? mk = r.mark;
            if (mk != null) {
              st = mk.state == 'done' ? 'done' : 'skip';
            } else if (fv.isNotEmpty) {
              st = 'tally';
            } else {
              st = 'open';
            }
            status[r.id] = st;
            if (st == 'open') {
              open++;
              openVal += r.value;
            } else if (st == 'tally') {
              inTally++;
            } else if (st == 'done') {
              done++;
            } else {
              skip++;
            }
          }
          _daily(cfg, rows.where((GhatRow r) => r.mark == null).length);
          final List<_DnFlag> flags = tOn ? _audit(cfg, dns.where((TVoucher v) => !v.dt.isBefore(DateTime.now().subtract(Duration(days: cfg.days)))).toList()) : <_DnFlag>[];
          final List<GhatRow> shown = rows.where((GhatRow r) {
            final String st = status[r.id] ?? 'open';
            if (_f == 0) return st == 'open';
            if (_f == 1) return st == 'tally';
            if (_f == 2) return st == 'done';
            if (_f == 3) return st == 'skip';
            return true;
          }).toList();
          final List<PcCol> cols = _cols();
          final bool pc = app.stagePc;
          return <Widget>[
            ScreenHeader(bi('ડેબિટ નોટ તપાસ', 'Debit-note check'), sub: '${bi('છેલ્લા', 'Last')} ${cfg.days} ${bi('દિવસ', 'days')}', actions: <Widget>[
              IconBtn('tune', tip: bi('સેટિંગ', 'Settings'), onTap: () => _openSettings(ctx)),
            ]),
            statusBanner(),
            HeroCard(
              title: bi('ડેબિટ નોટ બનાવવાની ગાડી', 'Trucks that need a debit note'),
              value: '$open',
              unit: bi('ગાડી', 'trucks'),
              sub: open == 0 ? bi('અત્યારે કંઈ બાકી નથી', 'Nothing pending now') : '${bi('અંદાજે', 'About')} ${inrC(openVal)}',
              chips: <HeroChip>[
                HeroChip('check', '${bi('થઈ ગઈ', 'Done')} ${done + inTally}'),
                HeroChip('warn', '${bi('Tally ની શંકા', 'Tally doubts')} ${flags.length}'),
              ],
            ),
            const SizedBox(height: 12),
            metricGrid(ctx, <Widget>[
              MetricTile(label: bi('બનાવવાની', 'To make'), value: '$open', icon: 'fact', tone: open > 0 ? 'rose' : 'green', onTap: () => setState(() {
                    _tab = 0;
                    _f = 0;
                  })),
              MetricTile(label: bi('Tally માં મળી', 'Found in Tally'), value: tOn ? '$inTally' : '—', icon: 'db', tone: 'blue', onTap: () => setState(() {
                    _tab = 0;
                    _f = 1;
                  })),
              MetricTile(label: bi('નોંધેલી / છોડેલી', 'Marked / skipped'), value: '$done / $skip', icon: 'check', tone: 'green', onTap: () => setState(() {
                    _tab = 0;
                    _f = 2;
                  })),
              MetricTile(label: bi('Tally ડેબિટ નોટ શંકા', 'Tally debit-note doubts'), value: tOn ? '${flags.length}' : '—', icon: 'warn', tone: flags.isEmpty ? 'green' : 'amber', onTap: () => setState(() => _tab = 1)),
            ]),
            const SizedBox(height: 12),
            if (!tOn) noteBox('info', 'blue', bi('Tally નો ડેટા આવ્યો નથી. ઘટવાળી ગાડીની યાદી દેખાય છે; Tally Agent ચાલુ થાય એટલે ડેબિટ નોટ આપોઆપ મેળવાશે.', 'No Tally data yet. The short trucks are listed; once the Tally Agent runs, debit notes are matched automatically.')),
            ChipRow(labels: <String>[bi('ઘટવાળી ગાડી', 'Short trucks'), bi('Tally ડેબિટ નોટ', 'Tally debit notes')], index: _tab, onChanged: (int i) => setState(() => _tab = i)),
            const SizedBox(height: 10),
            if (_tab == 1) ...<Widget>[
              if (!tOn)
                EmptyBox(icon: 'db', title: bi('Tally નો ડેટા નથી', 'No Tally data'))
              else if (flags.isEmpty)
                EmptyBox(icon: 'check', title: bi('ડેબિટ નોટમાં કોઈ શંકા નથી', 'No doubts in the debit notes'), sub: '${dns.length} ${bi('ડેબિટ નોટ તપાસી', 'debit notes checked')}')
              else
                for (final _DnFlag f in flags)
                  lineItem(
                    icon: 'warn',
                    tone: 'amber',
                    title: f.v.party.isEmpty ? f.v.title : f.v.party,
                    sub: '${dayLabel(f.v.dt)}${f.v.no.isEmpty ? '' : ' · ${f.v.no}'} · ${f.why.map(_whyText).join(' · ')}',
                    trailing: inr(f.v.amount),
                    onTap: () => _openDnSheet(ctx, f),
                  ),
            ] else ...<Widget>[
              ChipRow(labels: <String>[bi('બનાવવાની', 'To make'), 'Tally', bi('થઈ ગઈ', 'Done'), bi('છોડેલી', 'Skipped'), bi('બધી', 'All')], index: _f, onChanged: (int i) => setState(() => _f = i)),
              const SizedBox(height: 10),
              if (shown.isEmpty) EmptyBox(icon: 'check', title: _f == 0 ? bi('ઘટવાળી કોઈ ગાડી બાકી નથી', 'No short truck is pending') : bi('આમાં કંઈ નથી', 'Nothing here')),
              if (pc && shown.isNotEmpty) ...<Widget>[
                pcHead(cols),
                for (final GhatRow r in shown.take(300)) _tableRow(ctx, r, cols, status[r.id] ?? 'open'),
              ] else
                for (final GhatRow r in shown.take(200)) _tile(ctx, r, status[r.id] ?? 'open'),
            ],
          ];
        },
      ),
    );
  }

  Widget _tableRow(BuildContext ctx, GhatRow r, List<PcCol> cols, String st) {
    final Trip t = r.trip;
    return pcRow(
      cols,
      <Widget>[
        pcTd(dmy(t.at)),
        pcTd(t.vehicle.isEmpty ? '-' : t.vehicle, bold: true),
        pcTd(t.farmers.isEmpty ? '-' : t.farmers),
        pcTd(grp(t.chitKg, dec: 0), num: true),
        pcTd(grp(t.kantaKg, dec: 0), num: true),
        pcTd(grp(r.shortKg, dec: 0), num: true, c: Pal.bad, bold: true),
        pcTd(r.value > 0 ? grp(r.value, dec: 0) : '-', num: true, bold: true),
        pcTd(_stText(st)),
      ],
      bar: Pal.tone(_stTone(st)).fg,
      onTap: () => openGhatSheet(ctx, r.id),
    );
  }

  Widget _tile(BuildContext ctx, GhatRow r, String st) {
    final Trip t = r.trip;
    return lineItem(
      icon: 'fact',
      tone: _stTone(st),
      title: '${t.vehicle.isEmpty ? '-' : t.vehicle} · ${t.farmers.isEmpty ? '-' : t.farmers}',
      sub: '${dayLabel(t.at)} · ${grp(t.chitKg, dec: 0)} → ${grp(t.kantaKg, dec: 0)} KG · ${bi('ઘટ', 'short')} ${grp(r.shortKg, dec: 0)} KG',
      trailing: r.value > 0 ? inr(r.value) : '—',
      trailingSub: _stText(st),
      trailingColor: st == 'open' ? Pal.bad : Pal.ok,
      onTap: () => openGhatSheet(ctx, r.id),
    );
  }
}
