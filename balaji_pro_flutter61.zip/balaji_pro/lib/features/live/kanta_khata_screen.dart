import 'dart:async';
import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/kanta_khata.dart';
import '../../widgets/common.dart';
import '../../widgets/page.dart';
import '../kanta/khata_view.dart';
import 'ui.dart';

// ======================================================================
// Weighbridge khata on the owner's phone / PC: how much each name owes for the weighing charges ("baki"), the statement of a name,
// Jama (money received) and a WhatsApp reminder. The accounts are built by the weighbridge laptop (Balaji Kanta) and read from the server.
// ======================================================================

class KantaKhataScreen extends StatelessWidget {
  const KantaKhataScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 760,
      rows: (BuildContext ctx) => <Widget>[
        ScreenHeader(bi('કાંટા ખાતું (બાકી)', 'Weighbridge Khata (Baki)'), sub: bi('નામ મુજબ વજનના ચાર્જનું બાકી - કાંટા લેપટોપથી આપોઆપ', 'Charges baki per name - from the weighbridge laptop, by itself')),
        const KhataBody(),
      ],
    );
  }
}

/// The card on the owner's dashboard: total baki and how many names owe. Tap = the khata.
class KantaKhataCard extends StatefulWidget {
  const KantaKhataCard({super.key});

  @override
  State<KantaKhataCard> createState() => _KantaKhataCardState();
}

class _KantaKhataCardState extends State<KantaKhataCard> {
  Timer? _t;

  @override
  void initState() {
    super.initState();
    kantaKhata.addListener(_tick);
    unawaited(kantaKhata.load().then((_) => kantaKhata.sync()));
    _t = Timer.periodic(const Duration(seconds: 90), (Timer _) => unawaited(kantaKhata.sync()));
  }

  @override
  void dispose() {
    _t?.cancel();
    kantaKhata.removeListener(_tick);
    super.dispose();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final KantaKhata k = kantaKhata;
    // nothing to show until the first account exists
    if (k.accs.isEmpty) return const SizedBox.shrink();
    final bool owes = k.totalBaki >= 0.5;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Surface(
        onTap: () => app.go('kanta_khata'),
        padding: const EdgeInsets.all(12),
        child: Row(
          children: <Widget>[
            IconChip('ledger', tone: owes ? 'rose' : 'green', size: 42),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(bi('કાંટા ખાતું (બાકી)', 'Weighbridge khata (baki)'), style: ts(14.5, w: FontWeight.w800)),
                  Text(owes ? inr(k.totalBaki) : '✓', style: ts(22, w: FontWeight.w800, c: owes ? Pal.bad : Pal.ok, tab: true)),
                  Text(owes ? '${k.owingCount} ${bi('નામનું બાકી', 'names owe')}' : bi('કોઈનું બાકી નથી', 'Nobody owes'), style: ts(12.5, w: FontWeight.w700, c: Pal.muted)),
                ],
              ),
            ),
            Icon(Icons.chevron_right_rounded, color: Pal.faint),
          ],
        ),
      ),
    );
  }
}
