import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/live_store.dart';

/// After an offline login: asks for the password once the internet is back, to get a real server session
/// (then the data refreshes and the entries waiting in the queue are sent).
Future<void> showReauth(BuildContext context) {
  final TextEditingController c = TextEditingController();
  bool busy = false;
  String err = '';
  return showDialog<void>(
    context: context,
    builder: (BuildContext dctx) => StatefulBuilder(
      builder: (BuildContext ctx, StateSetter set) {
        Future<void> go() async {
          if (busy) return;
          if (c.text.isEmpty) {
            set(() => err = bi('પાસવર્ડ લખો', 'Enter the password'));
            return;
          }
          set(() {
            busy = true;
            err = '';
          });
          final String? e = await live.reauth(c.text);
          if (!ctx.mounted) return;
          if (e == null) {
            Navigator.of(ctx).pop();
            app.toast(bi('જોડાઈ ગયા - ડેટા તાજો થાય છે', 'Connected - refreshing the data'));
          } else {
            set(() {
              busy = false;
              err = e;
            });
          }
        }

        return AlertDialog(
          title: Text(bi('સર્વર સાથે જોડો', 'Connect to the server'), style: ts(17, w: FontWeight.w800)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                bi('તમે ઇન્ટરનેટ વગર લૉગિન કર્યું હતું. ઇન્ટરનેટ ચાલુ કરીને પાસવર્ડ ફરી નાખો - ડેટા તાજો થશે અને બાકી એન્ટ્રી મોકલાશે.',
                    'You logged in without internet. Switch the internet on and enter the password again - the data refreshes and waiting entries are sent.'),
                style: ts(14, h: 1.45),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: c,
                obscureText: true,
                autofocus: true,
                onSubmitted: (String v) => go(),
                decoration: InputDecoration(labelText: bi('પાસવર્ડ', 'Password')),
              ),
              if (err.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Text(err, style: ts(13, w: FontWeight.w700, c: Pal.bad)),
                ),
            ],
          ),
          actions: <Widget>[
            TextButton(onPressed: busy ? null : () => Navigator.of(ctx).pop(), child: Text(bi('પછી', 'Later'), style: ts(14, w: FontWeight.w700, c: Pal.muted))),
            TextButton(
              onPressed: busy ? null : go,
              child: busy
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2.2))
                  : Text(bi('જોડો', 'Connect'), style: ts(14, w: FontWeight.w800, c: Pal.brand)),
            ),
          ],
        );
      },
    ),
  );
}
