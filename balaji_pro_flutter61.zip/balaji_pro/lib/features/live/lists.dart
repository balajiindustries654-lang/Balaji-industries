import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/device.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/engine.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../widgets/common.dart';
import '../../widgets/page.dart';
import 'tally_data.dart' show tallyPurchaseBanner;
import 'ui.dart';

Widget _filters(BuildContext context, {required TextEditingController c, required String hint, required ValueChanged<String> onQ, required int r, required ValueChanged<int> onR, List<String>? labels, bool dense = true}) {
  final bool pc = DeviceScope.isPc(context);
  final Widget search = SearchBox(hint: hint, controller: c, onChanged: onQ, width: pc ? 320 : null);
  final Widget seg = Seg(dense: dense, labels: labels ?? rangeLabels(), index: r, onChanged: onR);
  if (pc) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(children: <Widget>[search, const SizedBox(width: 12), seg]),
    );
  }
  return Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        search,
        const SizedBox(height: 10),
        SingleChildScrollView(scrollDirection: Axis.horizontal, child: seg),
      ],
    ),
  );
}

Widget _moreBtn(int shown, int total, VoidCallback onTap) {
  if (shown >= total) return const SizedBox.shrink();
  return Padding(
    padding: const EdgeInsets.only(top: 4),
    child: Btn(bi('વધુ બતાવો (${total - shown})', 'Show more (${total - shown})'), kind: BtnKind.tonal, expand: true, onTap: onTap),
  );
}

Widget _sumRow(List<Widget> pills) {
  return Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Wrap(spacing: 8, runSpacing: 8, children: pills),
  );
}

// ================================================================== chithi
class ChithiScreen extends StatefulWidget {
  final String? q;
  const ChithiScreen({super.key, this.q});

  @override
  State<ChithiScreen> createState() => _ChithiScreenState();
}

class _ChithiScreenState extends State<ChithiScreen> {
  late final TextEditingController _c = TextEditingController(text: widget.q ?? '');
  late String _q = widget.q ?? '';
  int _r = 1;
  int _n = 60;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      rows: (BuildContext ctx) {
        final String q = _q.trim().toLowerCase();
        final List<Chit> l = live.chits.where((Chit x) {
          if (!inRange(_r, x.at)) return false;
          if (q.isEmpty) return true;
          return '${x.farmer} ${x.village} ${x.vehicle} ${x.no} ${x.broker} ${x.mobile} ${x.commodity}'.toLowerCase().contains(q);
        }).toList();
        double kg = 0;
        for (final Chit x in l) {
          kg += x.cmpKg;
        }
        return <Widget>[
          ScreenHeader(
            bi('ચિઠ્ઠી', 'Chits'),
            sub: '${l.length} · ${grp(kg)} KG',
            actions: <Widget>[refreshBtn(), Btn(bi('નવી ચિઠ્ઠી', 'New chit'), icon: 'plus', dense: true, onTap: () => app.go('chithi_new'))],
          ),
          statusBanner(),
          tallyPurchaseBanner(),
          _filters(ctx, c: _c, hint: bi('ખેડૂત, ગાડી, ગામ, નંબર…', 'Farmer, vehicle, village, no…'), onQ: (String v) => setState(() {
                _q = v;
                _n = 60;
              }), r: _r, onR: (int i) => setState(() {
                _r = i;
                _n = 60;
              })),
          if (!DeviceScope.isPc(ctx)) _sumRow(<Widget>[Pill('${l.length} ${bi('ચિઠ્ઠી', 'chits')}', tone: 'teal'), Pill('${grp(kg)} KG', tone: 'blue')]),
          if (l.isEmpty)
            EmptyBox(icon: 'receipt', title: bi('કોઈ ચિઠ્ઠી નથી', 'No chits'))
          else if (app.stagePc) ...<Widget>[
            pcHead(chitCols()),
            for (final Chit x in l.take(_n)) chitTile(ctx, x, table: true),
            pcTotal(chitCols(), '${bi('કુલ', 'Total')} · ${l.length} ${bi('ચિઠ્ઠી', 'chits')}', labelAt: 2, vals: <int, String>{(live.isAdmin ? 8 : 7): grp(kg)}),
          ] else
            for (final Chit x in l.take(_n)) chitTile(ctx, x),
          _moreBtn(_n < l.length ? _n : l.length, l.length, () => setState(() => _n += 60)),
        ];
      },
    );
  }
}

// =================================================================== kanta
class KantaScreen extends StatefulWidget {
  final String? q;
  const KantaScreen({super.key, this.q});

  @override
  State<KantaScreen> createState() => _KantaScreenState();
}

class _KantaScreenState extends State<KantaScreen> {
  late final TextEditingController _c = TextEditingController(text: widget.q ?? '');
  late String _q = widget.q ?? '';
  int _r = 1;
  int _n = 60;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      rows: (BuildContext ctx) {
        final String q = _q.trim().toLowerCase();
        final List<Kanta> l = live.kantas.where((Kanta x) {
          if (!inRange(_r, x.at)) return false;
          if (q.isEmpty) return true;
          return '${x.rst} ${x.vehicle} ${x.name}'.toLowerCase().contains(q);
        }).toList();
        double kg = 0;
        for (final Kanta x in l) {
          kg += x.kg;
        }
        return <Widget>[
          ScreenHeader(
            bi('કાંટો', 'Weighbridge'),
            sub: '${l.length} · ${grp(kg)} KG',
            actions: <Widget>[refreshBtn(), Btn(bi('નવી કાંટા એન્ટ્રી', 'New kanta entry'), icon: 'plus', dense: true, onTap: () => app.go('kanta_new'))],
          ),
          statusBanner(),
          _filters(ctx, c: _c, hint: bi('RST, ગાડી…', 'RST, vehicle…'), onQ: (String v) => setState(() {
                _q = v;
                _n = 60;
              }), r: _r, onR: (int i) => setState(() {
                _r = i;
                _n = 60;
              })),
          if (!DeviceScope.isPc(ctx)) _sumRow(<Widget>[Pill('${l.length} ${bi('એન્ટ્રી', 'entries')}', tone: 'blue'), Pill('${grp(kg)} KG', tone: 'teal')]),
          if (l.isEmpty)
            EmptyBox(icon: 'scale', title: bi('કોઈ કાંટા એન્ટ્રી નથી', 'No kanta entries'))
          else if (app.stagePc) ...<Widget>[
            pcHead(kantaCols()),
            for (final Kanta x in l.take(_n)) kantaTile(ctx, x, table: true),
            pcTotal(kantaCols(), '${bi('કુલ', 'Total')} · ${l.length} ${bi('એન્ટ્રી', 'entries')}', labelAt: 2, vals: <int, String>{(live.isAdmin ? 7 : 4): grp(kg)}),
          ] else
            for (final Kanta x in l.take(_n)) kantaTile(ctx, x),
          _moreBtn(_n < l.length ? _n : l.length, l.length, () => setState(() => _n += 60)),
        ];
      },
    );
  }
}

// ==================================================================== maal
class MaalScreen extends StatefulWidget {
  final String? q;
  const MaalScreen({super.key, this.q});

  @override
  State<MaalScreen> createState() => _MaalScreenState();
}

class _MaalScreenState extends State<MaalScreen> {
  late final TextEditingController _c = TextEditingController(text: widget.q ?? '');
  late String _q = widget.q ?? '';
  int _r = 1;
  int _n = 60;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      rows: (BuildContext ctx) {
        final String q = _q.trim().toLowerCase();
        final List<MaalRow> l = live.maals.where((MaalRow x) {
          if (!inRange(_r, x.date)) return false;
          if (q.isEmpty) return true;
          return '${x.vehicle} ${x.owner} ${x.material} ${x.godown}'.toLowerCase().contains(q);
        }).toList();
        int bin = 0;
        int bout = 0;
        for (final MaalRow x in l) {
          if (x.loading) {
            bout += x.bags;
          } else {
            bin += x.bags;
          }
        }
        return <Widget>[
          ScreenHeader(
            bi('માલ (લોડિંગ / અનલોડિંગ)', 'Maal (loading / unloading)'),
            sub: '${l.length}',
            actions: <Widget>[refreshBtn(), Btn(bi('નવી માલ એન્ટ્રી', 'New maal entry'), icon: 'plus', dense: true, onTap: () => app.go('maal_new'))],
          ),
          statusBanner(),
          _filters(ctx, c: _c, hint: bi('ગાડી, માલિક, માલ…', 'Vehicle, owner, material…'), onQ: (String v) => setState(() {
                _q = v;
                _n = 60;
              }), r: _r, onR: (int i) => setState(() {
                _r = i;
                _n = 60;
              })),
          _sumRow(<Widget>[
            Pill('${bi('અનલોડિંગ', 'Unloading')} ${grp(bin)} ${bi('બેગ', 'bags')}', tone: 'green'),
            Pill('${bi('લોડિંગ', 'Loading')} ${grp(bout)} ${bi('બેગ', 'bags')}', tone: 'amber'),
          ]),
          if (l.isEmpty)
            EmptyBox(icon: 'bag', title: bi('કોઈ માલ એન્ટ્રી નથી', 'No maal entries'))
          else if (app.stagePc) ...<Widget>[
            pcHead(maalCols()),
            for (final MaalRow x in l.take(_n)) maalTile(ctx, x, table: true),
            pcTotal(maalCols(), '${bi('કુલ', 'Total')} · ${l.length}', labelAt: 2, vals: <int, String>{6: grp(bin + bout)}),
          ] else
            for (final MaalRow x in l.take(_n)) maalTile(ctx, x),
          _moreBtn(_n < l.length ? _n : l.length, l.length, () => setState(() => _n += 60)),
        ];
      },
    );
  }
}

// =================================================================== daily
class _Day {
  final DateTime d;
  int nc = 0;
  double kc = 0;
  int nk = 0;
  double kk = 0;
  double diff = 0;
  double matched = 0;
  int bin = 0;
  int bout = 0;
  int problems = 0;
  _Day(this.d);
}

class DailyScreen extends StatefulWidget {
  const DailyScreen({super.key});

  @override
  State<DailyScreen> createState() => _DailyScreenState();
}

class _DailyScreenState extends State<DailyScreen> {
  int _r = 1; // 0 = 7 days, 1 = 30 days, 2 = all

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 1000,
      rows: (BuildContext ctx) {
        final Map<int, _Day> m = <int, _Day>{};
        _Day day(DateTime x) {
          final DateTime d = dayOf(x);
          return m.putIfAbsent(d.millisecondsSinceEpoch, () => _Day(d));
        }

        for (final Chit x in live.chits) {
          final _Day r = day(x.at);
          r.nc++;
          r.kc += x.cmpKg;
        }
        for (final Kanta x in live.kantas) {
          final _Day r = day(x.at);
          r.nk++;
          r.kk += x.kg;
        }
        for (final MaalRow x in live.maals) {
          final _Day r = day(x.date);
          if (x.loading) {
            r.bout += x.bags;
          } else {
            r.bin += x.bags;
          }
        }
        for (final Trip t in live.trips) {
          final _Day r = day(t.at);
          if (t.both) {
            r.diff += t.diff;
            r.matched += t.chitKg;
          }
          if (t.problem) r.problems++;
        }
        final List<_Day> rows = m.values.where((_Day d) => inRange(<int>[1, 2, 3][_r], d.d)).toList();
        rows.sort((_Day a, _Day b) => b.d.compareTo(a.d));
        double tc = 0;
        double tk = 0;
        for (final _Day d in rows) {
          tc += d.kc;
          tk += d.kk;
        }
        return <Widget>[
          ScreenHeader(bi('દૈનિક રજિસ્ટર', 'Daily register'), sub: '${rows.length} ${bi('દિવસ', 'days')}', actions: <Widget>[refreshBtn()]),
          statusBanner(),
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Seg(dense: true, labels: rangeLabels().sublist(1), index: _r, onChanged: (int i) => setState(() => _r = i)),
          ),
          _sumRow(<Widget>[Pill('${bi('ચિઠ્ઠી', 'Chits')} ${grp(tc)} KG', tone: 'teal'), Pill('${bi('કાંટો', 'Kanta')} ${grp(tk)} KG', tone: 'blue')]),
          if (rows.isEmpty)
            EmptyBox(icon: 'doc', title: bi('ડેટા નથી', 'No data'))
          else
            for (final _Day d in rows)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Surface(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Expanded(child: Text('${dayLabel(d.d)}  ·  ${dayName(d.d)}', style: ts(14.5, w: FontWeight.w800))),
                          if (d.problems > 0) Pill('${d.problems} ${bi('તપાસ', 'to check')}', tone: 'rose', small: true),
                          if (d.matched > 0) ...<Widget>[
                            const SizedBox(width: 6),
                            Pill('${sk(d.diff)} KG', tone: d.diff.abs() <= live.cfg.tol(d.matched) ? 'green' : 'rose', small: true),
                          ],
                        ],
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: <Widget>[
                          Expanded(child: _cell(bi('ચિઠ્ઠી', 'Chits'), '${d.nc}', '${grp(d.kc)} KG')),
                          Expanded(child: _cell(bi('કાંટો', 'Kanta'), '${d.nk}', '${grp(d.kk)} KG')),
                          Expanded(child: _cell(bi('માલ', 'Maal'), '${bi('અંદર', 'in')} ${d.bin}', '${bi('બહાર', 'out')} ${d.bout}')),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
        ];
      },
    );
  }

  Widget _cell(String label, String a, String b) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(label, style: ts(11.5, c: Pal.muted, w: FontWeight.w600)),
        const SizedBox(height: 2),
        Text(a, style: ts(14, w: FontWeight.w800, tab: true)),
        Text(b, style: ts(12.5, c: Pal.muted, tab: true)),
      ],
    );
  }
}
