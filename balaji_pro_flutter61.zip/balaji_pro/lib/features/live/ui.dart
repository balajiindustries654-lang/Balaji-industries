import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/app_state.dart';
import '../../core/device.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/icons.dart';
import '../../core/palette.dart';
import '../../data/engine.dart';
import '../../data/lists.dart' show danaLabel;
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../widgets/common.dart';
import '../../widgets/keys.dart';
import '../../widgets/launch.dart';
import '../../widgets/page.dart';
import 'kit.dart';
import 'reauth.dart';

// ------------------------------------------------------------- live screens
/// Screen body that rebuilds when the live data changes and supports
/// pull-to-refresh.
class LiveBody extends StatelessWidget {
  final List<Widget> Function(BuildContext) rows;
  final double maxWidth;
  const LiveBody({super.key, required this.rows, this.maxWidth = 1560});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: live,
      builder: (BuildContext c, Widget? w) {
        return RefreshIndicator(
          color: Pal.brand,
          onRefresh: live.refresh,
          child: ScreenScroll(
            maxWidth: maxWidth,
            children: (live.loadedAt == null && live.loading) ? <Widget>[const SkeletonList()] : rows(c),
          ),
        );
      },
    );
  }
}

Widget refreshBtn() {
  return AnimatedBuilder(
    animation: live,
    builder: (BuildContext c, Widget? w) {
      if (live.loading) {
        return const SizedBox(width: 44, height: 44, child: Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator(strokeWidth: 2.4)));
      }
      return IconBtn('refresh', onTap: live.refresh, tip: bi('તાજું કરો', 'Refresh'));
    },
  );
}

/// Banner for offline / pending / error states.
Widget statusBanner() {
  // TallyPrime has no banners: the status line at the bottom of the window tells the same
  if (Pal.tally) return const SizedBox.shrink();
  return AnimatedBuilder(
    animation: live,
    builder: (BuildContext c, Widget? w) {
      final List<Widget> l = <Widget>[];
      if (live.needsReauth) {
        l.add(_banner('lock', 'amber', bi('ઑફલાઇન લૉગિન - ઇન્ટરનેટ આવે ત્યારે અહીં દબાવી પાસવર્ડ નાખો (ડેટા તાજો થશે, બાકી એન્ટ્રી જશે)', 'Offline login - when the internet is back tap here and enter the password (data refreshes, waiting entries are sent)'),
            onTap: () => showReauth(c)));
      }
      if (live.offline) {
        final DateTime? la = live.loadedAt;
        l.add(_banner('wifioff', 'amber', '${bi('ઇન્ટરનેટ નથી - ફોન / PC પર સેવ કરેલો ડેટા દેખાય છે', 'No internet - showing the data saved on this device')}${la == null ? '' : ' (${ago(la)})'}'));
      }
      if (live.error.isNotEmpty) {
        l.add(_banner('err', 'rose', live.error));
      }
      if (live.pending.isNotEmpty) {
        l.add(_banner('cloudup', 'blue', bi('${live.pending.length} એન્ટ્રી મોકલવાની બાકી', '${live.pending.length} entries waiting to upload'),
            onTap: () => app.go('offline_queue')));
      }
      if (l.isEmpty) return const SizedBox.shrink();
      return Column(children: l);
    },
  );
}

Widget _banner(String icon, String tone, String text, {VoidCallback? onTap}) {
  final Tone t = Pal.tone(tone);
  return Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: Material(
      color: t.bg,
      borderRadius: BorderRadius.circular(Pal.rad(12)),
      child: InkWell(
        borderRadius: BorderRadius.circular(Pal.rad(12)),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: Row(
            children: <Widget>[
              Icon(ic(icon), size: 19, color: t.fg),
              const SizedBox(width: 10),
              Expanded(child: Text(text, style: ts(13, w: FontWeight.w700, c: t.fg))),
              if (onTap != null) Icon(ic('chev'), size: 18, color: t.fg),
            ],
          ),
        ),
      ),
    ),
  );
}

// ------------------------------------------------------------------- states
String stateLabel(TripState s) {
  switch (s) {
    case TripState.ok:
      return bi('બરાબર', 'Match');
    case TripState.diff:
      return bi('ફરક', 'Difference');
    case TripState.noKanta:
      return bi('કાંટો બાકી', 'No kanta');
    case TripState.wait:
      return bi('રસ્તામાં', 'On the way');
    case TripState.noChit:
      return bi('ચિઠ્ઠી નથી', 'No chit');
    case TripState.direct:
      return bi('સીધી રવાના', 'Direct');
  }
}

String stateTone(TripState s) {
  switch (s) {
    case TripState.ok:
      return 'green';
    case TripState.diff:
      return 'rose';
    case TripState.noKanta:
      return 'rose';
    case TripState.wait:
      return 'amber';
    case TripState.noChit:
      return 'rose';
    case TripState.direct:
      return 'blue';
  }
}

Widget stateChip(TripState s, {bool small = true}) => Pill(stateLabel(s), tone: stateTone(s), small: small);

Color diffColor(double diff, double tol) {
  if (diff.abs() <= tol) return Pal.ok;
  return diff < 0 ? Pal.bad : Pal.warn;
}

String vtxt(String v) => v.isEmpty ? '—' : v;

String whenTxt(DateTime d) => '${dayLabel(d)} ${hm(d)}';

// ------------------------------------------------------------- date filter
List<String> rangeLabels() => <String>[bi('આજે', 'Today'), bi('7 દિવસ', '7 days'), bi('30 દિવસ', '30 days'), bi('બધા', 'All')];

bool inRange(int i, DateTime d) {
  final DateTime now = DateTime.now();
  final DateTime today = dayOf(now);
  if (i == 0) return !d.isBefore(today);
  if (i == 1) return !d.isBefore(today.subtract(const Duration(days: 6)));
  if (i == 2) return !d.isBefore(today.subtract(const Duration(days: 29)));
  return true;
}

/// Distinct non-empty values, newest first (for suggestion chips).
List<String> recentValues(Iterable<String> src, {int max = 60}) {
  final List<String> out = <String>[];
  final Set<String> seen = <String>{};
  for (final String s in src) {
    final String t = s.trim();
    if (t.isEmpty) continue;
    if (seen.add(t.toLowerCase())) {
      out.add(t);
      if (out.length >= max) break;
    }
  }
  return out;
}

// ----------------------------------------------------------- suggest field
/// A text box with a list of earlier values under it.
/// Phone: tap a chip. PC: the list opens under the box - Down / Up choose, Enter takes the choice and goes to the
/// next field, Esc closes the list. Without choosing, Enter just goes to the next field.
class SuggestField extends StatefulWidget {
  final String label;
  final TextEditingController controller;
  final List<String> options;
  final TextInputType? keyboard;
  final String? hint;
  final ValueChanged<String>? onPick;
  final ValueChanged<String>? onChanged;

  /// A small grey line at the right of a value of [options] (e.g. the mobile number of a name). It is searched too.
  final Map<String, String>? hints;
  final String? prefix;

  /// To move the focus here from outside (optional; the box makes its own when null).
  final FocusNode? focusNode;

  /// Enter on a box without a chosen row goes to the next field; this runs first (the last field of a form uses it).
  final ValueChanged<String>? onSubmitted;
  const SuggestField({
    super.key,
    required this.label,
    required this.controller,
    required this.options,
    this.keyboard,
    this.hint,
    this.onPick,
    this.onChanged,
    this.hints,
    this.prefix,
    this.focusNode,
    this.onSubmitted,
  });

  @override
  State<SuggestField> createState() => _SuggestFieldState();
}

class _SuggestFieldState extends State<SuggestField> {
  FocusNode? _own;
  FocusNode get _fn => widget.focusNode ?? (_own ??= FocusNode(debugLabel: 'SuggestField'));
  final GlobalKey _listKey = GlobalKey();
  List<String> _cur = <String>[];
  int _hi = -1; // highlighted row of the list (-1 = none)
  bool _open = true; // Esc closes the list until the text changes
  String _last = '';

  @override
  void initState() {
    super.initState();
    _last = widget.controller.text;
    widget.controller.addListener(_onText);
    _fn.addListener(_onFocus);
  }

  @override
  void didUpdateWidget(SuggestField old) {
    super.didUpdateWidget(old);
    if (old.controller != widget.controller) {
      old.controller.removeListener(_onText);
      widget.controller.addListener(_onText);
      _last = widget.controller.text;
    }
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onText);
    _fn.removeListener(_onFocus);
    _own?.dispose();
    super.dispose();
  }

  void _onText() {
    final String t = widget.controller.text;
    if (t == _last) return; // only the cursor moved
    _last = t;
    _open = true;
    _hi = -1;
    if (mounted) setState(() {});
  }

  void _onFocus() {
    if (_fn.hasFocus) {
      _open = true;
      _hi = -1;
    }
    if (mounted) setState(() {});
  }

  static String _k(String s) => s.toLowerCase().replaceAll(RegExp(r'[^a-z0-9\u0A80-\u0AFF]'), '');

  /// Values that contain the typed text (a part of a word, a part of a number, spaces and dashes ignored) - the ones that start with it
  /// come first, then the ones that only have it inside; values whose small grey line has it (a name found by its number) come last.
  List<String> _matches(int max) {
    final String q = widget.controller.text.trim().toLowerCase();
    final String qk = _k(q);
    final List<String> starts = <String>[];
    final List<String> inside = <String>[];
    final List<String> viaHint = <String>[];
    for (final String o in widget.options) {
      if (o.isEmpty) continue;
      final String lo = o.toLowerCase();
      if (q.isEmpty) {
        starts.add(o);
      } else if (lo != q) {
        final String ok = _k(o);
        if (lo.startsWith(q) || (qk.isNotEmpty && ok.startsWith(qk))) {
          starts.add(o);
        } else if (lo.contains(q) || (qk.isNotEmpty && ok.contains(qk))) {
          inside.add(o);
        } else {
          final String? h = widget.hints?[o];
          if (h != null && h.toLowerCase().contains(q)) viaHint.add(o);
        }
      }
      if (starts.length >= max && q.isEmpty) break;
      if (starts.length + inside.length + viaHint.length >= 80) break;
    }
    final List<String> all = <String>[...starts, ...inside, ...viaHint];
    return all.length > max ? all.sublist(0, max) : all;
  }

  void _pick(String o, {bool next = false}) {
    final TextEditingController c = widget.controller;
    c.text = o;
    c.selection = TextSelection.collapsed(offset: o.length);
    _last = o;
    if (widget.onPick != null) widget.onPick!(o);
    if (widget.onChanged != null) widget.onChanged!(o);
    if (mounted) {
      setState(() {
        _open = false;
        _hi = -1;
      });
    }
    if (next) focusNextField();
  }

  void _reveal() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final BuildContext? c = _listKey.currentContext;
      if (c != null && c.mounted) {
        Scrollable.ensureVisible(c, duration: const Duration(milliseconds: 80), alignmentPolicy: ScrollPositionAlignmentPolicy.keepVisibleAtEnd);
      }
    });
  }

  KeyEventResult _key(FocusNode node, KeyEvent e) {
    final List<String> m = _cur;
    if (!_fn.hasFocus || !_open || m.isEmpty || !app.stagePc) return KeyEventResult.ignored;
    final LogicalKeyboardKey k = e.logicalKey;
    if (k == LogicalKeyboardKey.arrowDown) {
      setState(() => _hi = _hi + 1 >= m.length ? 0 : _hi + 1);
      _reveal();
      return KeyEventResult.handled;
    }
    if (k == LogicalKeyboardKey.arrowUp) {
      setState(() => _hi = _hi <= 0 ? m.length - 1 : _hi - 1);
      _reveal();
      return KeyEventResult.handled;
    }
    if (k == LogicalKeyboardKey.escape) {
      // nothing typed and nothing chosen: Esc leaves the form at once (like TallyPrime), it does not stop at the list
      if (_hi < 0 && widget.controller.text.trim().isEmpty) return KeyEventResult.ignored;
      setState(() {
        _open = false;
        _hi = -1;
      });
      return KeyEventResult.handled;
    }
    if (isEnterKey(e) && _hi >= 0 && _hi < m.length) {
      _pick(m[_hi], next: true);
      return KeyEventResult.handled;
    }
    return KeyEventResult.ignored;
  }

  Widget _list(List<String> m) {
    final Widget box = TextFieldTapRegion(
      child: Material(
        color: Pal.surface,
        elevation: 4,
        child: Container(
          decoration: BoxDecoration(border: Border.all(color: Pal.focusLine, width: 1)),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              for (int i = 0; i < m.length; i++)
                InkWell(
                  canRequestFocus: false,
                  onTap: () => _pick(m[i]),
                  child: Container(
                    height: 30,
                    alignment: Alignment.centerLeft,
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    color: i == _hi ? Pal.focusFill : Colors.transparent,
                    child: Row(
                      children: <Widget>[
                        Expanded(child: Text(m[i], maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(13.5, w: i == _hi ? FontWeight.w800 : FontWeight.w600))),
                        if (widget.hints?[m[i]] != null) ...<Widget>[
                          const SizedBox(width: 10),
                          Flexible(child: Text(widget.hints![m[i]]!, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(11.5, w: FontWeight.w700, c: Pal.muted))),
                        ],
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
    final Widget row = Pal.tally
        ? Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              const Spacer(flex: 4),
              const SizedBox(width: 14),
              Expanded(flex: 6, child: box),
            ],
          )
        : box;
    return Padding(key: _listKey, padding: const EdgeInsets.only(top: 2), child: row);
  }

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    final List<String> m = _matches(pc ? 8 : 6);
    _cur = m;
    if (_hi >= m.length) _hi = m.length - 1;
    final bool showList = pc && _fn.hasFocus && _open && m.isNotEmpty;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        FieldX(label: widget.label, controller: widget.controller, focusNode: _fn, keyboard: widget.keyboard, hint: widget.hint, prefix: widget.prefix, onChanged: widget.onChanged, onKey: _key, onSubmitted: widget.onSubmitted == null ? null : (String v) => widget.onSubmitted!(v)),
        if (showList) _list(m),
        if (!pc && m.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Wrap(
              spacing: 6,
              runSpacing: 6,
              children: <Widget>[
                for (final String o in m)
                  GestureDetector(
                    onTap: () => _pick(o),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                      decoration: BoxDecoration(color: Pal.soft, borderRadius: BorderRadius.circular(Pal.rad(99))),
                      child: Text(widget.hints?[o] == null ? o : '$o  ·  ${widget.hints![o]}', style: ts(12.5, w: FontWeight.w700, c: Pal.brand)),
                    ),
                  ),
              ],
            ),
          ),
      ],
    );
  }
}

// ------------------------------------------------------------------- photo
class PhotoBox extends StatelessWidget {
  final String url;
  final double height;
  const PhotoBox(this.url, {super.key, this.height = 260});

  @override
  Widget build(BuildContext context) {
    if (url.isEmpty) {
      return Container(
        height: 90,
        alignment: Alignment.center,
        decoration: BoxDecoration(color: Pal.surface2, borderRadius: BorderRadius.circular(Pal.rad(12)), border: Border.all(color: Pal.line)),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(ic('img'), size: 20, color: Pal.faint),
            const SizedBox(width: 8),
            Text(bi('ફોટો નથી', 'No photo'), style: ts(13, w: FontWeight.w700, c: Pal.faint)),
          ],
        ),
      );
    }
    return GestureDetector(
      onTap: () => showDialog<void>(
        context: context,
        builder: (BuildContext c) => Dialog(
          backgroundColor: Colors.black,
          insetPadding: const EdgeInsets.all(8),
          child: Stack(
            children: <Widget>[
              InteractiveViewer(
                minScale: 0.8,
                maxScale: 6,
                child: Image.network(url, fit: BoxFit.contain),
              ),
              Positioned(
                right: 4,
                top: 4,
                child: IconBtn('close', color: Colors.white, bg: const Color(0x66000000), onTap: () => Navigator.of(c).pop()),
              ),
            ],
          ),
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(Pal.rad(12)),
        child: Container(
          constraints: BoxConstraints(maxHeight: height),
          color: Pal.surface2,
          child: Image.network(
            url,
            fit: BoxFit.contain,
            loadingBuilder: (BuildContext c, Widget child, ImageChunkEvent? p) {
              if (p == null) return child;
              return SizedBox(height: 120, child: Center(child: CircularProgressIndicator(strokeWidth: 2.4, color: Pal.brand)));
            },
            errorBuilder: (BuildContext c, Object e, StackTrace? s) => SizedBox(
              height: 90,
              child: Center(child: Text(bi('ફોટો ખૂલ્યો નહીં', 'Photo failed to load'), style: ts(13, c: Pal.bad, w: FontWeight.w700))),
            ),
          ),
        ),
      ),
    );
  }
}

// ------------------------------------------------------------------- tiles
Widget rowShell({required Widget child, VoidCallback? onTap, Color? bar}) {
  if (Pal.tally) {
    // TallyPrime list line: no card, a thin rule under it; the active line is yellow
    return RowMark(
      child: Material(
        color: Pal.surface,
        child: InkWell(
          onTap: onTap,
          hoverColor: Pal.soft,
          focusColor: Pal.focusFill,
          child: Container(
            padding: const EdgeInsets.fromLTRB(8, 4, 8, 4),
            decoration: BoxDecoration(border: Border(left: BorderSide(color: bar ?? Colors.transparent, width: 3), bottom: BorderSide(color: Pal.line.withAlpha(110)))),
            child: child,
          ),
        ),
      ),
    );
  }
  // PC: slim, flat rows (like a Tally list) so many more entries fit on the screen
  final bool pc = app.stagePc;
  final double r = pc ? 8 : 14;
  return Padding(
    padding: EdgeInsets.only(bottom: pc ? 4 : 8),
    child: Surface(
      onTap: onTap,
      padding: EdgeInsets.zero,
      radius: r,
      shadow: !pc,
      child: IntrinsicHeight(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Container(
              width: pc ? 3 : 4,
              decoration: BoxDecoration(
                color: bar ?? Colors.transparent,
                borderRadius: BorderRadius.only(topLeft: Radius.circular(r), bottomLeft: Radius.circular(r)),
              ),
            ),
            Expanded(child: Padding(padding: pc ? const EdgeInsets.fromLTRB(10, 5, 10, 5) : const EdgeInsets.fromLTRB(12, 11, 12, 11), child: child)),
          ],
        ),
      ),
    ),
  );
}

// ------------------------------------------------- PC table rows (Tally style)
// Slim one-line rows with fixed columns, a head row and a total row - used by the chit / kanta / maal lists on PC.
class PcCol {
  final String label;
  final double w; // 0 = takes the rest of the width
  final bool right;
  const PcCol(this.label, this.w, {this.right = false});
}

Widget _pcCell(PcCol c, Widget child) {
  final Widget a = Align(alignment: c.right ? Alignment.centerRight : Alignment.centerLeft, child: child);
  return c.w <= 0 ? Expanded(child: a) : SizedBox(width: c.w, child: a);
}

Text pcTd(String t, {bool bold = false, Color? c, bool num = false}) {
  return Text(t, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(num ? 13 : 12.5, w: bold ? FontWeight.w800 : (Pal.tally ? FontWeight.w500 : FontWeight.w600), c: c, tab: num));
}

Widget pcHead(List<PcCol> cols) {
  if (Pal.tally) {
    // TallyPrime column heads: bold text between two thin dark lines
    return Container(
      height: 24,
      padding: const EdgeInsets.symmetric(horizontal: 6),
      decoration: BoxDecoration(border: Border(top: BorderSide(color: Pal.ink.withAlpha(150)), bottom: BorderSide(color: Pal.ink.withAlpha(150)))),
      child: Row(children: <Widget>[for (final PcCol c in cols) _pcCell(c, Text(c.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12.5, w: FontWeight.w800)))]),
    );
  }
  return Container(
    height: 28,
    padding: const EdgeInsets.symmetric(horizontal: 10),
    decoration: BoxDecoration(color: Pal.soft, border: Border.all(color: Pal.line)),
    child: Row(children: <Widget>[for (final PcCol c in cols) _pcCell(c, Text(c.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(11.5, w: FontWeight.w800, c: Pal.muted)))]),
  );
}

Widget pcRow(List<PcCol> cols, List<Widget> cells, {VoidCallback? onTap, Color? bar, Color? bg, bool total = false}) {
  if (Pal.tally) {
    return RowMark(
      child: Material(
        color: bg ?? Colors.transparent,
        child: InkWell(
          onTap: onTap,
          hoverColor: Pal.soft,
          focusColor: Pal.focusFill,
          child: Container(
            height: 24,
            padding: const EdgeInsets.symmetric(horizontal: 6),
            decoration: BoxDecoration(
              border: Border(
                left: BorderSide(color: bar ?? Colors.transparent, width: 3),
                top: total ? BorderSide(color: Pal.ink.withAlpha(150)) : BorderSide.none,
                bottom: total ? BorderSide(color: Pal.ink.withAlpha(150)) : BorderSide.none,
              ),
            ),
            child: Row(children: <Widget>[for (int i = 0; i < cols.length && i < cells.length; i++) _pcCell(cols[i], cells[i])]),
          ),
        ),
      ),
    );
  }
  return RowMark(
    child: Material(
      color: bg ?? Pal.surface,
      child: InkWell(
        onTap: onTap,
        hoverColor: Pal.soft,
        focusColor: Pal.focusFill,
        child: Container(
          height: 30,
          padding: const EdgeInsets.symmetric(horizontal: 10),
          decoration: BoxDecoration(
            border: Border(
              left: BorderSide(color: bar ?? Pal.line, width: bar == null ? 1 : 3),
              right: BorderSide(color: Pal.line),
              bottom: BorderSide(color: Pal.line),
            ),
          ),
          child: Row(children: <Widget>[for (int i = 0; i < cols.length && i < cells.length; i++) _pcCell(cols[i], cells[i])]),
        ),
      ),
    ),
  );
}

/// Total row: [label] sits in column [labelAt]; [vals] puts text in other columns (index -> text).
Widget pcTotal(List<PcCol> cols, String label, {int labelAt = 0, Map<int, String> vals = const <int, String>{}}) {
  return pcRow(
    cols,
    <Widget>[
      for (int i = 0; i < cols.length; i++)
        if (i == labelAt) pcTd(label, bold: true) else if (vals.containsKey(i)) pcTd(vals[i]!, bold: true, num: true) else const SizedBox.shrink(),
    ],
    bg: Pal.tally ? null : Pal.soft,
    total: true,
  );
}

List<PcCol> chitCols() => <PcCol>[
      PcCol(bi('સમય', 'Time'), 118),
      PcCol(bi('નં.', 'No'), 60),
      PcCol(bi('ખેડૂત', 'Farmer'), 0),
      PcCol(bi('ગામ', 'Village'), 130),
      PcCol(bi('ગાડી', 'Vehicle'), 120),
      PcCol(bi('માલ', 'Commodity'), 100),
      PcCol(bi('દલાલ', 'Broker'), 110),
      if (live.isAdmin) PcCol(bi('સ્થિતિ', 'Status'), 110),
      PcCol(bi('ચોખ્ખું KG', 'Net KG'), 100, right: true),
    ];

List<PcCol> kantaCols() => <PcCol>[
      PcCol(bi('સમય', 'Time'), 118),
      PcCol('RST', 80),
      PcCol(bi('ગાડી', 'Vehicle'), 0),
      PcCol(bi('નામ', 'Name'), 150),
      if (live.isAdmin) PcCol(bi('સ્થિતિ', 'Status'), 110),
      if (live.isAdmin) PcCol(bi('ચિઠ્ઠી KG', 'Chit KG'), 100, right: true),
      if (live.isAdmin) PcCol(bi('ફરક', 'Diff'), 90, right: true),
      PcCol('KG', 100, right: true),
    ];

List<PcCol> maalCols() => <PcCol>[
      PcCol(bi('તારીખ', 'Date'), 110),
      PcCol(bi('પ્રકાર', 'Type'), 110),
      PcCol(bi('ગાડી', 'Vehicle'), 0),
      PcCol(bi('માલ', 'Material'), 140),
      PcCol(bi('માલિક', 'Owner'), 140),
      PcCol(bi('ગોડાઉન', 'Godown'), 110),
      PcCol(bi('બેગ', 'Bags'), 80, right: true),
    ];

Trip? tripOfChit(Chit c) => live.chitTrip[c];

Trip? tripOfKanta(Kanta k) => live.kantaTrip[k];

Widget chitTile(BuildContext context, Chit c, {bool table = false}) {
  final Trip? t = live.isAdmin ? tripOfChit(c) : null;
  if (table) {
    return pcRow(
      chitCols(),
      <Widget>[
        pcTd(whenTxt(c.at)),
        pcTd('#${vtxt(c.no)}'),
        pcTd(vtxt(c.farmer), bold: true),
        pcTd(vtxt(c.village)),
        pcTd(vtxt(c.vehicle)),
        pcTd(c.commodity),
        pcTd(c.broker),
        if (live.isAdmin) (t == null ? const SizedBox.shrink() : FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: stateChip(t.state))),
        pcTd(grp(c.cmpKg), bold: true, num: true),
      ],
      onTap: () => showChitDetail(context, c),
      bar: t == null ? null : Pal.tone(stateTone(t.state)).fg,
    );
  }
  return rowShell(
    onTap: () => showChitDetail(context, c),
    bar: t == null ? null : Pal.tone(stateTone(t.state)).fg,
    child: Row(
      children: <Widget>[
        Avatar(c.farmer.isEmpty ? '?' : c.farmer, size: 40),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(vtxt(c.farmer), maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14.5, w: FontWeight.w800)),
              const SizedBox(height: 2),
              Text('${vtxt(c.village)} · ${vtxt(c.vehicle)}', maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12.5, c: Pal.muted)),
              const SizedBox(height: 6),
              Wrap(
                spacing: 6,
                runSpacing: 4,
                children: <Widget>[
                  Pill('#${vtxt(c.no)}', tone: 'slate', small: true),
                  if (c.commodity.isNotEmpty) Pill(c.commodity, tone: 'teal', small: true),
                  if (c.broker.isNotEmpty) Pill(c.broker, tone: 'violet', small: true),
                  if (t != null) stateChip(t.state),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(width: 8),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[
            Text('${grp(c.cmpKg)} KG', style: ts(15, w: FontWeight.w800, tab: true)),
            const SizedBox(height: 2),
            Text(whenTxt(c.at), style: ts(11.5, c: Pal.muted)),
          ],
        ),
      ],
    ),
  );
}

Widget kantaTile(BuildContext context, Kanta k, {bool table = false}) {
  final Trip? t = live.isAdmin ? tripOfKanta(k) : null;
  if (table) {
    return pcRow(
      kantaCols(),
      <Widget>[
        pcTd(whenTxt(k.at)),
        pcTd(vtxt(k.rst)),
        pcTd(vtxt(k.vehicle), bold: true),
        pcTd(k.name),
        if (live.isAdmin) (t == null ? const SizedBox.shrink() : FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: stateChip(t.state))),
        if (live.isAdmin) pcTd(t != null && t.both ? grp(t.chitKg) : '', num: true),
        if (live.isAdmin) pcTd(t != null && t.both ? sk(t.diff) : '', num: true, bold: true, c: t != null && t.both ? (t.state == TripState.ok ? Pal.ok : Pal.bad) : null),
        pcTd(grp(k.kg), bold: true, num: true),
      ],
      onTap: () => showKantaDetail(context, k),
      bar: t == null ? null : Pal.tone(stateTone(t.state)).fg,
    );
  }
  return rowShell(
    onTap: () => showKantaDetail(context, k),
    bar: t == null ? null : Pal.tone(stateTone(t.state)).fg,
    child: Row(
      children: <Widget>[
        const IconChip('scale', tone: 'blue', size: 40),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(vtxt(k.vehicle), maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14.5, w: FontWeight.w800)),
              const SizedBox(height: 2),
              Text('RST ${vtxt(k.rst)}${k.name.isEmpty ? '' : ' · ${k.name}'}', maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12.5, c: Pal.muted)),
              if (t != null) ...<Widget>[
                const SizedBox(height: 6),
                Wrap(spacing: 6, runSpacing: 4, children: <Widget>[
                  stateChip(t.state),
                  if (t.both) Pill('${bi('ચિઠ્ઠી', 'Chit')} ${grp(t.chitKg)}', tone: 'slate', small: true),
                  if (t.both) Pill(sk(t.diff), tone: t.state == TripState.ok ? 'green' : 'rose', small: true),
                ]),
              ],
            ],
          ),
        ),
        const SizedBox(width: 8),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[
            Text('${grp(k.kg)} KG', style: ts(15, w: FontWeight.w800, tab: true)),
            const SizedBox(height: 2),
            Text(whenTxt(k.at), style: ts(11.5, c: Pal.muted)),
          ],
        ),
      ],
    ),
  );
}

Widget maalTile(BuildContext context, MaalRow m, {bool table = false}) {
  if (table) {
    return pcRow(
      maalCols(),
      <Widget>[
        pcTd(dayLabel(m.date)),
        FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Pill(m.loading ? bi('લોડિંગ', 'Loading') : bi('અનલોડિંગ', 'Unloading'), tone: m.loading ? 'amber' : 'green', small: true)),
        pcTd(vtxt(m.vehicle), bold: true),
        pcTd(m.dana.isEmpty ? m.material : '${m.material} · ${danaLabel(m.dana, gu: L.gu)}'),
        pcTd(m.owner),
        pcTd(m.godown),
        pcTd(grp(m.bags), bold: true, num: true),
      ],
      onTap: () => showMaalDetail(context, m),
      bar: m.loading ? Pal.tone('amber').fg : Pal.tone('green').fg,
    );
  }
  return rowShell(
    onTap: () => showMaalDetail(context, m),
    bar: m.loading ? Pal.tone('amber').fg : Pal.tone('green').fg,
    child: Row(
      children: <Widget>[
        IconChip(m.loading ? 'ul' : 'dl', tone: m.loading ? 'amber' : 'green', size: 40),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(vtxt(m.vehicle), maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14.5, w: FontWeight.w800)),
              const SizedBox(height: 2),
              Text('${vtxt(m.material)}${m.owner.isEmpty ? '' : ' · ${m.owner}'}', maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12.5, c: Pal.muted)),
              const SizedBox(height: 6),
              Wrap(spacing: 6, children: <Widget>[
                Pill(m.loading ? bi('લોડિંગ', 'Loading') : bi('અનલોડિંગ', 'Unloading'), tone: m.loading ? 'amber' : 'green', small: true),
                if (m.dana.isNotEmpty) Pill(danaLabel(m.dana, gu: L.gu), tone: 'blue', small: true),
                if (m.godown.isNotEmpty) Pill(m.godown, tone: 'slate', small: true),
              ]),
            ],
          ),
        ),
        const SizedBox(width: 8),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[
            Text('${grp(m.bags)} ${bi('બેગ', 'bags')}', style: ts(15, w: FontWeight.w800, tab: true)),
            const SizedBox(height: 2),
            Text(dayLabel(m.date), style: ts(11.5, c: Pal.muted)),
          ],
        ),
      ],
    ),
  );
}

Widget tripTile(BuildContext context, Trip t) {
  final Color tone = Pal.tone(stateTone(t.state)).fg;
  return rowShell(
    onTap: () => showTripDetail(context, t),
    bar: tone,
    child: Row(
      children: <Widget>[
        IconChip('truck', tone: stateTone(t.state), size: 40),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                children: <Widget>[
                  Flexible(child: Text(vtxt(t.vehicle), maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14.5, w: FontWeight.w800))),
                  const SizedBox(width: 8),
                  stateChip(t.state),
                ],
              ),
              const SizedBox(height: 2),
              Text(
                t.chits.isEmpty
                    ? 'RST ${vtxt(t.kanta?.rst ?? '')} · ${bi('ચિઠ્ઠી નથી', 'no chit')}'
                    : '${t.farmers}${t.villages.isEmpty ? '' : ' · ${t.villages}'}',
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: ts(12.5, c: Pal.muted),
              ),
            ],
          ),
        ),
        const SizedBox(width: 8),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[
            if (t.both) ...<Widget>[
              Text(sk(t.diff), style: ts(15.5, w: FontWeight.w800, c: diffColor(t.diff, t.tol), tab: true)),
              Text('${t.diffPct.toStringAsFixed(2)}%', style: ts(11.5, w: FontWeight.w700, c: diffColor(t.diff, t.tol))),
            ] else
              Text('${grp(t.chits.isEmpty ? t.kantaKg : t.chitKg)} KG', style: ts(14, w: FontWeight.w800, tab: true)),
            const SizedBox(height: 2),
            Text(whenTxt(t.at), style: ts(11.5, c: Pal.muted)),
          ],
        ),
      ],
    ),
  );
}

// ----------------------------------------------------------------- details
Widget _kv(String k, String v, {bool bold = false, Color? color}) => InfoRow(k, v, bold: bold, color: color);

Widget _shareBtn(String text, {String phone = ''}) {
  return Padding(
    padding: const EdgeInsets.only(top: 14),
    child: Row(
      children: <Widget>[
        tExp(child: Btn(bi('કૉપિ', 'Copy'), icon: 'copy', kind: BtnKind.tonal, dense: true, onTap: () => copyText(text))),
        const SizedBox(width: 8),
        tExp(child: Btn('WhatsApp', icon: 'chat', kind: BtnKind.tonal, dense: true, onTap: () => whatsappText(text, phone: phone))),
        if (phone.isNotEmpty) ...<Widget>[
          const SizedBox(width: 8),
          tExp(child: Btn(bi('ફોન', 'Call'), icon: 'call', kind: BtnKind.tonal, dense: true, onTap: () => callPhone(phone))),
        ],
      ],
    ),
  );
}

String chitText(Chit c) {
  return '${bi('ચિઠ્ઠી', 'Chit')} #${c.no}\n${c.farmer} · ${c.village}\n${bi('ગાડી', 'Vehicle')}: ${c.vehicle}\n${bi('કુલ', 'Gross')}: ${grp(c.gross, dec: 2)} KG\n${bi('બારદાન', 'Bardan')}: ${grp(c.bardan, dec: 2)}  ${bi('કરદો', 'Kardo')}: ${grp(c.kardo, dec: 2)}\n${bi('ચોખ્ખું', 'Net')}: ${grp(c.net, dec: 2)} KG\n${dmy(c.at)} ${hm(c.at)}';
}

Future<void> showChitDetail(BuildContext context, Chit c) {
  final Trip? t = live.isAdmin ? tripOfChit(c) : null;
  return openPanel(
    context,
    title: '${bi('ચિઠ્ઠી', 'Chit')} #${vtxt(c.no)}',
    sub: '${dmy(c.at)} · ${hm(c.at)}',
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        PhotoBox(c.photo),
        const SizedBox(height: 12),
        _kv(bi('ખેડૂત', 'Farmer'), vtxt(c.farmer)),
        _kv(bi('મોબાઇલ', 'Mobile'), vtxt(c.mobile)),
        _kv(bi('ગામ', 'Village'), vtxt(c.village)),
        _kv(bi('દલાલ', 'Broker'), vtxt(c.broker)),
        _kv(bi('માલ', 'Material'), vtxt(c.commodity)),
        _kv(bi('ગાડી', 'Vehicle'), vtxt(c.vehicle)),
        divider(),
        _kv(bi('કુલ વજન', 'Gross'), '${grp(c.gross, dec: 2)} KG'),
        _kv(bi('બારદાન', 'Bardan'), '${grp(c.bardan, dec: 2)} KG'),
        _kv(bi('કરદો', 'Kardo'), '${grp(c.kardo, dec: 2)} KG'),
        _kv(bi('ચોખ્ખું વજન', 'Net'), '${grp(c.net, dec: 2)} KG', bold: true),
        if (c.bags > 0) _kv(bi('બેગ', 'Bags'), '${c.bags}'),
        _kv(bi('નોંધનાર', 'Entered by'), majurName(live.names, c.by)),
        if (t != null) ...<Widget>[
          const SizedBox(height: 10),
          divider(),
          const SizedBox(height: 10),
          Row(children: <Widget>[Text(bi('કાંટા સાથે મેળ', 'Weighbridge check'), style: ts(14, w: FontWeight.w800)), const Spacer(), stateChip(t.state, small: false)]),
          if (t.both) ...<Widget>[
            _kv(bi('કાંટો', 'Kanta'), '${grp(t.kantaKg)} KG'),
            _kv(bi('ફરક', 'Difference'), '${sk(t.diff)} KG (${t.diffPct.toStringAsFixed(2)}%)', bold: true, color: diffColor(t.diff, t.tol)),
          ],
          const SizedBox(height: 6),
          Btn(bi('આખી ગાડી જુઓ', 'See whole trip'), icon: 'truck', kind: BtnKind.outline, expand: true, onTap: () {
            Navigator.of(context).pop();
            showTripDetail(context, t);
          }),
        ],
        _shareBtn(chitText(c), phone: c.mobile),
      ],
    ),
  );
}

Future<void> showKantaDetail(BuildContext context, Kanta k) {
  final Trip? t = live.isAdmin ? tripOfKanta(k) : null;
  return openPanel(
    context,
    title: 'RST ${vtxt(k.rst)}',
    sub: '${dmy(k.at)} · ${hm(k.at)}',
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        PhotoBox(k.slip),
        const SizedBox(height: 12),
        _kv(bi('ગાડી', 'Vehicle'), vtxt(k.vehicle)),
        _kv(bi('વજન (ચોખ્ખું)', 'Net weight'), '${grp(k.kg, dec: 2)} KG', bold: true),
        if (k.name.isNotEmpty) _kv(bi('નામ', 'Name'), k.name),
        _kv(bi('નોંધનાર', 'Entered by'), majurName(live.names, k.by)),
        if (t != null) ...<Widget>[
          const SizedBox(height: 10),
          divider(),
          const SizedBox(height: 10),
          Row(children: <Widget>[Text(bi('ચિઠ્ઠી સાથે મેળ', 'Chit check'), style: ts(14, w: FontWeight.w800)), const Spacer(), stateChip(t.state, small: false)]),
          if (t.both) ...<Widget>[
            _kv(bi('ચિઠ્ઠી', 'Chit'), '${grp(t.chitKg)} KG'),
            _kv(bi('ફરક', 'Difference'), '${sk(t.diff)} KG (${t.diffPct.toStringAsFixed(2)}%)', bold: true, color: diffColor(t.diff, t.tol)),
          ],
          const SizedBox(height: 6),
          Btn(bi('આખી ગાડી જુઓ', 'See whole trip'), icon: 'truck', kind: BtnKind.outline, expand: true, onTap: () {
            Navigator.of(context).pop();
            showTripDetail(context, t);
          }),
        ],
        _shareBtn('RST ${k.rst}\n${k.vehicle}\n${grp(k.kg, dec: 2)} KG\n${dmy(k.at)} ${hm(k.at)}'),
      ],
    ),
  );
}

String maalText(MaalRow m) {
  return '${m.loading ? bi('લોડિંગ', 'Loading') : bi('અનલોડિંગ', 'Unloading')}\n${bi('ગાડી', 'Vehicle')}: ${m.vehicle}\n${bi('માલ', 'Material')}: ${m.material}\n${m.dana.isEmpty ? '' : '${bi('દાણા', 'Dana')}: ${danaLabel(m.dana, gu: L.gu)}\n'}${bi('બેગ', 'Bags')}: ${m.bags}\n${bi('માલિક', 'Owner')}: ${m.owner}\n${dmy(m.date)}';
}

Future<void> showMaalDetail(BuildContext context, MaalRow m) {
  return openPanel(
    context,
    title: m.loading ? bi('લોડિંગ', 'Loading') : bi('અનલોડિંગ', 'Unloading'),
    sub: dmy(m.date),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        PhotoBox(m.slip),
        const SizedBox(height: 12),
        _kv(bi('ગાડી', 'Vehicle'), vtxt(m.vehicle)),
        _kv(bi('માલ', 'Material'), vtxt(m.material)),
        if (m.dana.isNotEmpty) _kv(bi('દાણા', 'Dana'), danaLabel(m.dana, gu: L.gu)),
        _kv(bi('બેગ', 'Bags'), '${m.bags}', bold: true),
        _kv(bi('માલિક', 'Owner'), vtxt(m.owner)),
        _kv(bi('ગોડાઉન', 'Godown'), vtxt(m.godown)),
        _kv(bi('નોંધનાર', 'Entered by'), majurName(live.names, m.by)),
        _shareBtn(maalText(m)),
      ],
    ),
  );
}

String tripText(Trip t) {
  final StringBuffer b = StringBuffer();
  b.writeln('${bi('ગાડી', 'Vehicle')}: ${t.vehicle}  [${stateLabel(t.state)}]');
  b.writeln('${dmy(t.at)} ${hm(t.at)}');
  for (final Chit c in t.chits) {
    b.writeln('• ${c.farmer} (${c.village}) #${c.no}: ${grp(c.cmpKg)} KG');
  }
  if (t.kanta != null) b.writeln('${bi('કાંટો', 'Kanta')} RST ${t.kanta!.rst}: ${grp(t.kantaKg)} KG');
  if (t.both) b.writeln('${bi('ફરક', 'Difference')}: ${sk(t.diff)} KG (${t.diffPct.toStringAsFixed(2)}%)');
  return b.toString().trim();
}

Future<void> showTripDetail(BuildContext context, Trip t) {
  return openPanel(
    context,
    title: vtxt(t.vehicle),
    sub: '${dmy(t.at)} · ${hm(t.at)}',
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Row(children: <Widget>[stateChip(t.state, small: false), const Spacer(), if (t.commodity.isNotEmpty) Pill(t.commodity, tone: 'teal')]),
        const SizedBox(height: 10),
        _kv(bi('ચિઠ્ઠી કુલ (${t.chits.length})', 'Chits total (${t.chits.length})'), '${grp(t.chitKg)} KG'),
        _kv(bi('કાંટો', 'Kanta'), t.kanta == null ? '—' : '${grp(t.kantaKg)} KG'),
        if (t.both) ...<Widget>[
          _kv(bi('ફરક', 'Difference'), '${sk(t.diff)} KG (${t.diffPct.toStringAsFixed(2)}%)', bold: true, color: diffColor(t.diff, t.tol)),
          _kv(bi('માન્ય ફરક', 'Allowed'), '± ${grp(t.tol)} KG'),
        ],
        if (t.kanta != null) ...<Widget>[
          const SizedBox(height: 12),
          Text('RST ${vtxt(t.kanta!.rst)}', style: ts(14, w: FontWeight.w800)),
          const SizedBox(height: 8),
          PhotoBox(t.kanta!.slip, height: 220),
        ],
        for (final Chit c in t.chits) ...<Widget>[
          const SizedBox(height: 14),
          Surface(
            padding: const EdgeInsets.all(12),
            color: Pal.surface2,
            shadow: false,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Row(children: <Widget>[
                  Expanded(child: Text('${vtxt(c.farmer)} · #${vtxt(c.no)}', style: ts(14, w: FontWeight.w800))),
                  Text('${grp(c.cmpKg)} KG', style: ts(14, w: FontWeight.w800, tab: true)),
                ]),
                const SizedBox(height: 2),
                Text('${vtxt(c.village)} · ${vtxt(c.broker)} · ${majurName(live.names, c.by)}', style: ts(12, c: Pal.muted)),
                const SizedBox(height: 8),
                PhotoBox(c.photo, height: 200),
              ],
            ),
          ),
        ],
        _shareBtn(tripText(t)),
      ],
    ),
  );
}
