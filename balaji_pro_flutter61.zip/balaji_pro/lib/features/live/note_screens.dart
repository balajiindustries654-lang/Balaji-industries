import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/errlog.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/engine.dart';
import '../../data/insights.dart';
import '../../data/live_models.dart';
import '../../data/money.dart';
import '../../data/trade.dart';
import '../../data/vno.dart';
import '../../data/vouchers.dart';
import '../../widgets/accept.dart';
import '../../widgets/common.dart';
import '../../widgets/dayfield.dart';
import '../../widgets/keys.dart';
import 'field.dart';
import 'money_screens.dart' show balColor, balWord;
import 'ui.dart';
import 'voucher_screens.dart' show printOut;

// ======================================================================
// Credit Note / Debit Note, like TallyPrime (Ctrl+F8 / Ctrl+F9)
//   Credit Note (sales return)   : Sales Returns Dr  /  Buyer Cr   - the buyer owes us less, the sales shrink
//   Debit Note (purchase return) : Farmer Dr  /  Purchase Returns Cr - we owe the farmer less, the purchases shrink
// A note is stored as a journal entry ('open') with a negative amount and a journal type ('cn' / 'dn').
// ======================================================================

/// [credit] true = Credit Note (buyer), false = Debit Note (farmer). Give [editSale] / [editPay] to alter a note
/// (Alt+D deletes it, Ctrl+P prints it); [copySale] / [copyPay] start a new one from an old one.
Future<void> openNoteForm(
  BuildContext context, {
  bool credit = true,
  SaleItem? editSale,
  PayItem? editPay,
  SaleItem? copySale,
  PayItem? copyPay,
}) {
  final bool altering = editSale != null || editPay != null;
  return openPanel(
    context,
    title: altering ? bi('વાઉચર સુધારો (Alter)', 'Voucher alteration') : (credit ? bi('ક્રેડિટ નોટ · વેચાણ પરત', 'Credit Note · Sales return') : bi('ડેબિટ નોટ · ખરીદ પરત', 'Debit Note · Purchase return')),
    sub: altering ? dmy(editSale?.date ?? editPay!.date) : null,
    width: 460,
    page: true,
    child: NoteForm(credit: credit, editSale: editSale, editPay: editPay, copySale: copySale, copyPay: copyPay),
  );
}

class NoteForm extends StatefulWidget {
  final bool credit;
  final SaleItem? editSale;
  final PayItem? editPay;
  final SaleItem? copySale;
  final PayItem? copyPay;
  const NoteForm({super.key, this.credit = true, this.editSale, this.editPay, this.copySale, this.copyPay});

  @override
  State<NoteForm> createState() => _NoteFormState();
}

class _NoteFormState extends State<NoteForm> {
  late final VoidCallback _accept = () {
    _save();
  };
  late final VoidCallback _del = () {
    _delete();
  };
  late final VoidCallback _prn = () {
    _print();
  };

  final TextEditingController _who = TextEditingController();
  final TextEditingController _amt = TextEditingController();
  final TextEditingController _note = TextEditingController();
  final TextEditingController _ref = TextEditingController();
  late bool _credit = widget.credit;
  DateTime _day = dateOnly(DateTime.now());
  bool _busy = false;
  String _err = '';

  bool get _altering => widget.editSale != null || widget.editPay != null;
  String get _editId => widget.editSale?.id ?? widget.editPay?.id ?? '';

  @override
  void initState() {
    super.initState();
    AcceptHub.push(_accept);
    final SaleItem? s = widget.editSale ?? widget.copySale;
    final PayItem? p = widget.editPay ?? widget.copyPay;
    if (s != null) {
      _credit = true;
      _who.text = s.buyer;
      _amt.text = plainNum(s.amt.abs());
      _note.text = s.note;
      if (widget.editSale != null) {
        _day = s.date;
        _ref.text = s.ref;
      }
    } else if (p != null) {
      _credit = false;
      _who.text = p.label;
      _amt.text = plainNum(p.amt.abs());
      _note.text = p.note;
      if (widget.editPay != null) {
        _day = p.date;
        _ref.text = p.ref;
      }
    }
    if (_altering) {
      deleteHub.push(_del);
      printHub.push(_prn);
      ensureVoucherNumbers();
    }
  }

  @override
  void dispose() {
    _who.dispose();
    _amt.dispose();
    _note.dispose();
    _ref.dispose();
    AcceptHub.pop(_accept);
    deleteHub.pop(_del);
    printHub.pop(_prn);
    super.dispose();
  }

  Future<void> _delete() async {
    if (!_altering || _busy) return;
    final bool go = await confirmBox(context, title: bi('આ વાઉચર કાઢી નાખવું?', 'Delete this voucher?'), text: bi('આ નોંધ કાયમ માટે કાઢી નંખાશે અને ખાતું બદલાશે.', 'This entry will be removed for good and the ledger changes.'), yes: bi('હા, કાઢો', 'Yes, delete'), no: bi('ના', 'No'));
    if (!go || !mounted) return;
    if (widget.editSale != null) {
      await removeSale(widget.editSale!.id);
    } else {
      await removePayItem(widget.editPay!.id);
    }
    app.toast(bi('વાઉચર કાઢ્યું', 'Voucher deleted'));
    if (mounted) Navigator.of(context).pop();
  }

  Future<void> _print() async {
    if (!_altering) return;
    final Vch? v = voucherById(widget.editSale != null ? 'sale' : 'pay', _editId);
    if (v == null) return;
    await printOut(voucherHtml(v, curBal: _curBalText()), 'voucher-$_editId');
  }

  /// What the party owes / is owed right now, "Cur Bal" of TallyPrime (buyer: Dr = he owes us, farmer: Cr = we owe him).
  double? _balance() {
    final String k0 = nameKey(_who.text.trim());
    if (k0.isEmpty) return null;
    if (_credit) {
      for (final BuyerAcct a in buyerAccts().values) {
        if (nameKey(a.label) == k0) return a.balance;
      }
    } else {
      for (final FarmerAcct a in farmerAccts().values) {
        if (nameKey(a.label) == k0) return a.balance;
      }
    }
    return null;
  }

  String _curBalText() {
    final double? b = _balance();
    if (b == null) return '';
    if (_credit) return '${tAmt(b.abs())} ${b >= 0 ? 'Dr' : 'Cr'}';
    return '${tAmt(b.abs())} ${b >= 0 ? 'Cr' : 'Dr'}';
  }

  Future<void> _save() async {
    final String name = _who.text.trim();
    final double amt = dbl(_amt.text.replaceAll(',', ''));
    if (name.isEmpty) {
      setState(() => _err = _credit ? bi('ખરીદનારનું નામ લખો', 'Enter the buyer') : bi('ખેડૂતનું નામ લખો', 'Enter the farmer'));
      return;
    }
    if (amt <= 0) {
      setState(() => _err = bi('સાચી રકમ લખો', 'Enter a valid amount'));
      return;
    }
    if (_busy) return;
    String key = nameKey(name);
    String label = name;
    if (_credit) {
      for (final BuyerAcct a in buyerAccts().values) {
        if (nameKey(a.label) == key) {
          label = a.label;
          break;
        }
      }
    } else {
      for (final PartySummary s in directoryOf(Dim.farmer)) {
        if (nameKey(s.ref.label) == key) {
          key = s.ref.key;
          label = s.ref.label;
          break;
        }
      }
    }
    setState(() {
      _busy = true;
      _err = '';
    });
    final double signed = -amt; // a note lowers what the party owes (buyer) / what we owe (farmer)
    final SaleItem? es = widget.editSale;
    final PayItem? ep = widget.editPay;
    if (es != null || ep != null) {
      final bool saved = await ErrLog.attempt('Save', () {
        if (es != null) return updateSale(es.id, buyer: label, date: _day, amt: signed, mode: 'cash', note: _note.text, ref: _ref.text);
        return updatePayItem(ep!.id, key: key, label: label, amt: signed, kind: 'open', mode: 'cash', date: _day, note: _note.text, ref: _ref.text);
      });
      if (!saved) {
        if (mounted) setState(() => _busy = false);
        return;
      }
      app.toast('${bi('વાઉચર સુધાર્યું', 'Voucher altered')} · ${inr(amt)} · $label');
      if (mounted) Navigator.of(context).pop();
      return;
    }
    final bool added = await ErrLog.attempt('Save', () {
      if (_credit) return addSale(buyer: label, kind: 'open', jt: 'cn', date: _day, amt: signed, mode: 'cash', note: _note.text, ref: _ref.text);
      return addPayItem(key: key, label: label, amt: signed, kind: 'open', jt: 'dn', mode: 'cash', date: _day, note: _note.text, ref: _ref.text);
    });
    if (!added) {
      if (mounted) setState(() => _busy = false);
      return;
    }
    app.toast('${_credit ? bi('ક્રેડિટ નોટ', 'Credit Note') : bi('ડેબિટ નોટ', 'Debit Note')} · ${inr(amt)} · $label');
    if (!mounted) return;
    if (Pal.tally && app.stagePc && widget.copySale == null && widget.copyPay == null) {
      // like TallyPrime: the voucher stays open, blank, for the next entry (Esc closes it)
      setState(() {
        _busy = false;
        _who.clear();
        _amt.clear();
        _note.clear();
        _ref.clear();
      });
      KeyScopeState.refocusFrom(context);
      return;
    }
    Navigator.of(context).pop();
  }

  Widget _curBal() {
    final double? b = _balance();
    if (b == null) return const SizedBox.shrink();
    final String word = _credit ? (b > 0.5 ? bi('લેવાના', 'to get') : (b < -0.5 ? bi('એડવાન્સ', 'advance') : bi('ચૂકતે', 'clear'))) : balWord(b);
    final Color col = _credit ? (b > 0.5 ? Pal.warn : (b < -0.5 ? Pal.ok : Pal.muted)) : balColor(b);
    return Padding(
      padding: const EdgeInsets.only(top: 6),
      child: Text('${bi('હાલનું બાકી', 'Current balance')}: ${inr(b.abs())} · $word', style: ts(12.5, w: FontWeight.w800, c: col)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final VType vt = vTypeOf(_credit ? 'CNT' : 'DNT');
    final Vch? old = _altering ? voucherById(widget.editSale != null ? 'sale' : 'pay', _editId) : null;
    final int no = old?.no ?? 0;
    final List<String> names = _credit
        ? <String>[for (final BuyerAcct a in (buyerAccts().values.toList()..sort((BuyerAcct x, BuyerAcct y) => (y.last ?? DateTime(2000)).compareTo(x.last ?? DateTime(2000)))).take(300)) a.label]
        : <String>[for (final PartySummary s in (directoryOf(Dim.farmer)..sort((PartySummary x, PartySummary y) => y.last.compareTo(x.last))).take(400)) s.ref.label];
    final double amt = dbl(_amt.text.replaceAll(',', ''));
    final double? bal = _balance();
    // a credit note larger than what the buyer owes (or a debit note larger than what we owe the farmer) turns the account around
    final bool over = amt > 0 && bal != null && amt > bal + 0.5 && !_altering;
    final String partyName = _who.text.trim().isEmpty ? (_credit ? bi('ખરીદનાર', 'Buyer') : bi('ખેડૂત', 'Farmer')) : _who.text.trim();
    final String retName = _credit ? bi('વેચાણ પરત (Sales Returns)', 'Sales Returns') : bi('ખરીદ પરત (Purchase Returns)', 'Purchase Returns');
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        VoucherHead(
          type: vt.name,
          no: _altering ? (no > 0 ? '${vt.letter}-$no' : '') : '${vt.letter}-${nextVoucherNo(vt.code)}',
          date: _day,
          sub: _altering ? bi('સુધારો (Alteration)', 'Alteration') : bi('નવું વાઉચર', 'Creation'),
        ),
        if (!_altering && widget.copySale == null && widget.copyPay == null) ...<Widget>[
          Seg(
            labels: <String>[bi('ક્રેડિટ નોટ (વેચાણ પરત)', 'Credit Note (sales return)'), bi('ડેબિટ નોટ (ખરીદ પરત)', 'Debit Note (purchase return)')],
            index: _credit ? 0 : 1,
            onChanged: (int i) => setState(() {
              _credit = i == 0;
              _who.clear();
            }),
          ),
          const SizedBox(height: 10),
        ],
        Surface(
          padding: const EdgeInsets.all(12),
          child: Column(
            children: <Widget>[
              InfoRow(bi('ઉધાર (Dr)', 'Account (Dr)'), _credit ? retName : partyName, bold: true),
              InfoRow(bi('જમા (Cr)', 'Account (Cr)'), _credit ? partyName : retName, bold: true),
            ],
          ),
        ),
        const SizedBox(height: 12),
        SuggestField(
          label: '${_credit ? bi('ખરીદનાર', 'Buyer') : bi('ખેડૂત', 'Farmer')} *',
          controller: _who,
          options: names,
          onChanged: (String v) => setState(() {}),
          onPick: (String v) => setState(() {}),
        ),
        _curBal(),
        const SizedBox(height: 12),
        FieldX(label: '${bi('રકમ', 'Amount')} *', controller: _amt, big: true, prefix: '₹', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String _) => setState(() {})),
        if (over)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              _credit ? bi('આ નોટ ખરીદનારના બાકી કરતાં મોટી છે - ખાતું એડવાન્સમાં જશે', 'This note is more than the buyer owes - the account turns into an advance') : bi('આ નોટ ખેડૂતના બાકી કરતાં મોટી છે - ખેડૂત આપણને આપશે', 'This note is more than we owe the farmer - the farmer will owe us'),
              style: ts(12.5, w: FontWeight.w700, c: Pal.warn),
            ),
          ),
        const SizedBox(height: 12),
        FieldX(label: _credit ? bi('કયા બિલ સામે (બિલ નં.)', 'Against bill no.') : bi('કઈ ચિઠ્ઠી / બિલ સામે', 'Against chit / bill no.'), controller: _ref),
        const SizedBox(height: 12),
        DayField(label: bi('તારીખ', 'Date'), value: _day, last: dateOnly(DateTime.now()), onChanged: (DateTime d) => setState(() => _day = d)),
        const SizedBox(height: 12),
        FieldX(label: bi('નોંધ / Narration', 'Narration'), controller: _note),
        const SizedBox(height: 14),
        if (_err.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(_err, style: ts(13, w: FontWeight.w700, c: Pal.bad))),
        _busy
            ? SizedBox(height: 52, child: Center(child: SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 2.6, color: Pal.brand))))
            : Btn(_altering ? bi('સુધારો સેવ કરો', 'Save alteration') : bi('સેવ કરો', 'Save'), icon: 'check', expand: true, onTap: _save),
        if (_altering) ...<Widget>[
          const SizedBox(height: 8),
          Row(
            children: <Widget>[
              tExp(child: Btn(bi('પ્રિન્ટ (Ctrl+P)', 'Print (Ctrl+P)'), icon: 'print', kind: BtnKind.tonal, dense: true, tabStop: false, onTap: _print)),
              const SizedBox(width: 8),
              tExp(child: Btn(bi('કાઢો (Alt+D)', 'Delete (Alt+D)'), icon: 'trash', kind: BtnKind.danger, dense: true, tabStop: false, onTap: _delete)),
            ],
          ),
        ],
      ],
    );
  }
}
