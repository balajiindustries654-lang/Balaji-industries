import '../../core/flags.dart';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/engine.dart';
import '../../data/insights.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../data/owner_docs.dart';
import '../../data/supa.dart' show digitsOf;
import '../../widgets/common.dart';
import '../../widgets/launch.dart';
import '../../widgets/page.dart';
import 'kit.dart';
import 'kit2.dart';
import 'ui.dart';

import '../../widgets/accept.dart';
/// "3|ramesh patel" -> PartyRef (the id of a PartyRef is "<dim index>|<key>").
PartyRef? partyRefOf(String id, String label) {
  final int bar = id.indexOf('|');
  if (bar < 1) return null;
  final int? di = int.tryParse(id.substring(0, bar));
  if (di == null || di < 0 || di >= Dim.values.length) return null;
  return PartyRef(Dim.values[di], id.substring(bar + 1), label);
}

// =============================================================== follow-ups
Future<void> addFollowup(String text, {DateTime? due, String ref = ''}) {
  final List<Map<String, dynamic>> items = todoDoc.list('items');
  items.add(<String, dynamic>{
    'id': '${DateTime.now().microsecondsSinceEpoch}',
    'text': text.trim(),
    'due': due == null ? '' : dayKey(due),
    'done': false,
    'ref': ref,
    'at': DateTime.now().toIso8601String(),
  });
  return todoDoc.save();
}

/// The owner's to-do / "call him back" list.
class FollowupsScreen extends StatefulWidget {
  final String prefill;
  const FollowupsScreen({super.key, this.prefill = ''});

  @override
  State<FollowupsScreen> createState() => _FollowupsState();
}

class _FollowupsState extends State<FollowupsScreen> {
  late final TextEditingController _t = TextEditingController(text: widget.prefill);
  int _due = 0;
  bool _showDone = false;

  @override
  void initState() {
    super.initState();
    todoDoc.addListener(_tick);
    todoDoc.ensure();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    todoDoc.removeListener(_tick);
    _t.dispose();
    super.dispose();
  }

  DateTime? _dueDate() {
    final DateTime t = dayOf(DateTime.now());
    if (_due == 0) return t;
    if (_due == 1) return addDays(t, 1);
    if (_due == 2) return addDays(t, 3);
    if (_due == 3) return addDays(t, 7);
    return null;
  }

  Future<void> _add() async {
    final String x = _t.text.trim();
    if (x.isEmpty) {
      app.toast(bi('શું કરવાનું છે તે લખો', 'Write the task'));
      return;
    }
    await addFollowup(x, due: _dueDate());
    _t.clear();
    app.toast(bi('ઉમેરાયું', 'Added'));
  }

  Future<void> _toggle(String id) async {
    final List<Map<String, dynamic>> items = todoDoc.list('items');
    for (final Map<String, dynamic> x in items) {
      if ('${x['id']}' == id) {
        x['done'] = x['done'] != true;
        x['doneAt'] = DateTime.now().toIso8601String();
      }
    }
    await todoDoc.save();
  }

  Future<void> _remove(String id) async {
    final List<Map<String, dynamic>> items = todoDoc.list('items');
    items.removeWhere((Map<String, dynamic> x) => '${x['id']}' == id);
    await todoDoc.save();
  }

  Widget _row(Map<String, dynamic> it, DateTime today) {
    final bool done = it['done'] == true;
    final String dueS = '${it['due'] ?? ''}';
    final DateTime? due = dueS.isEmpty ? null : DateTime.tryParse(dueS);
    String dueTxt = '';
    Color? dueColor;
    if (due != null) {
      final int d = daysBetween(today, dayOf(due));
      if (d == 0) {
        dueTxt = bi('આજે', 'Today');
      } else if (d == 1) {
        dueTxt = bi('કાલે', 'Tomorrow');
      } else if (d > 1) {
        dueTxt = dm(due);
      } else {
        dueTxt = bi('${-d} દિવસ મોડું', '${-d} days late');
        dueColor = done ? null : Pal.bad;
      }
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Surface(
        padding: const EdgeInsets.fromLTRB(4, 6, 6, 6),
        child: Row(
          children: <Widget>[
            IconBtn(done ? 'check' : 'circle', size: 42, color: done ? Pal.ok : Pal.muted, onTap: () => _toggle('${it['id']}')),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text('${it['text'] ?? ''}', style: ts(14.5, w: FontWeight.w700, c: done ? Pal.muted : null, deco: done ? TextDecoration.lineThrough : null)),
                  if (dueTxt.isNotEmpty) Text(dueTxt, style: ts(12, w: FontWeight.w700, c: dueColor ?? Pal.muted)),
                ],
              ),
            ),
            IconBtn('trash', size: 38, tip: bi('કાઢો', 'Delete'), onTap: () => _remove('${it['id']}')),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 700,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final DateTime today = dayOf(DateTime.now());
        final String tk = dayKey(today);
        final List<Map<String, dynamic>> all = todoDoc.list('items');
        final List<Map<String, dynamic>> late0 = <Map<String, dynamic>>[];
        final List<Map<String, dynamic>> now0 = <Map<String, dynamic>>[];
        final List<Map<String, dynamic>> soon0 = <Map<String, dynamic>>[];
        final List<Map<String, dynamic>> none0 = <Map<String, dynamic>>[];
        final List<Map<String, dynamic>> done0 = <Map<String, dynamic>>[];
        for (final Map<String, dynamic> it in all) {
          final String due = '${it['due'] ?? ''}';
          if (it['done'] == true) {
            done0.add(it);
          } else if (due.isEmpty) {
            none0.add(it);
          } else if (due.compareTo(tk) < 0) {
            late0.add(it);
          } else if (due == tk) {
            now0.add(it);
          } else {
            soon0.add(it);
          }
        }
        int byDue(Map<String, dynamic> a, Map<String, dynamic> b) => '${a['due']}'.compareTo('${b['due']}');
        late0.sort(byDue);
        soon0.sort(byDue);
        done0.sort((Map<String, dynamic> a, Map<String, dynamic> b) => '${b['doneAt'] ?? ''}'.compareTo('${a['doneAt'] ?? ''}'));
        final int open = late0.length + now0.length + soon0.length + none0.length;

        return <Widget>[
          ScreenHeader(bi('ફોલો-અપ · યાદી', 'Follow-ups'), sub: bi('$open બાકી', '$open open')),
          statusBanner(),
          Panel(
            title: bi('નવું કામ', 'New task'),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                FieldX(label: bi('શું કરવાનું છે?', 'What to do?'), controller: _t, hint: bi('જેમ કે: રમેશભાઈને ફોન કરવો', 'e.g. call Ramesh back'), maxLines: 2),
                const SizedBox(height: 10),
                ChipRow(
                  labels: <String>[bi('આજે', 'Today'), bi('કાલે', 'Tomorrow'), bi('3 દિવસ', '3 days'), bi('અઠવાડિયું', 'A week'), bi('તારીખ વગર', 'No date')],
                  index: _due,
                  onChanged: (int i) => setState(() => _due = i),
                ),
                const SizedBox(height: 12),
                Btn(bi('ઉમેરો', 'Add'), icon: 'plus', expand: true, onTap: _add),
              ],
            ),
          ),
          const SizedBox(height: 14),
          if (open == 0) EmptyBox(icon: 'todo', title: bi('કોઈ કામ બાકી નથી', 'Nothing pending')),
          if (late0.isNotEmpty) ...<Widget>[caption(bi('મોડું થયેલું', 'Overdue')), for (final Map<String, dynamic> it in late0) _row(it, today)],
          if (now0.isNotEmpty) ...<Widget>[caption(bi('આજે', 'Today')), for (final Map<String, dynamic> it in now0) _row(it, today)],
          if (soon0.isNotEmpty) ...<Widget>[caption(bi('આવનાર', 'Coming up')), for (final Map<String, dynamic> it in soon0) _row(it, today)],
          if (none0.isNotEmpty) ...<Widget>[caption(bi('તારીખ વગર', 'No date')), for (final Map<String, dynamic> it in none0) _row(it, today)],
          if (done0.isNotEmpty) ...<Widget>[
            const SizedBox(height: 6),
            Btn(_showDone ? bi('પૂરા થયેલા છુપાવો', 'Hide done') : '${bi('પૂરા થયેલા', 'Done')} (${done0.length})', icon: 'check', kind: BtnKind.ghost, dense: true, onTap: () => setState(() => _showDone = !_showDone)),
            if (_showDone) ...<Widget>[const SizedBox(height: 6), for (final Map<String, dynamic> it in done0.take(20)) _row(it, today)],
          ],
        ];
      },
    );
  }
}

// ==================================================================== notes
/// Free-text note about one farmer / vehicle / broker, shown on its profile.
class PartyNoteCard extends StatefulWidget {
  final PartyRef party;
  const PartyNoteCard(this.party, {super.key});

  @override
  State<PartyNoteCard> createState() => _PartyNoteState();
}

class _PartyNoteState extends State<PartyNoteCard> {
  late final VoidCallback _accept = () {
    _save();
  };

  final TextEditingController _c = TextEditingController();
  bool _edit = false;

  @override
  void initState() {
    super.initState();
    AcceptHub.push(_accept);
    noteDoc.addListener(_tick);
    noteDoc.ensure();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    noteDoc.removeListener(_tick);
    _c.dispose();
    AcceptHub.pop(_accept);
    super.dispose();
  }

  Future<void> _save() async {
    await setNote(widget.party.id, _c.text, label: widget.party.label);
    if (mounted) setState(() => _edit = false);
    app.toast(bi('નોંધ સેવ થઈ', 'Note saved'));
  }

  @override
  Widget build(BuildContext context) {
    final String cur = noteOf(widget.party.id);
    return Panel(
      title: bi('મારી નોંધ', 'My note'),
      action: _edit
          ? null
          : IconBtn(cur.isEmpty ? 'plus' : 'edit', size: 38, onTap: () {
              _c.text = cur;
              setState(() => _edit = true);
            }),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          if (_edit) ...<Widget>[
            FieldX(label: bi('નોંધ', 'Note'), controller: _c, maxLines: 4, hint: bi('જેમ કે: ભાવમાં વાંધો કરે છે, ફોન ઉપાડતો નથી...', 'e.g. argues on price, does not pick up calls...')),
            const SizedBox(height: 10),
            Row(
              children: <Widget>[
                tExp(child: Btn(bi('રદ', 'Cancel'), kind: BtnKind.outline, onTap: () => setState(() => _edit = false))),
                const SizedBox(width: 10),
                tExp(child: Btn(bi('સેવ', 'Save'), icon: 'check', onTap: _save)),
              ],
            ),
          ] else
            Text(cur.isEmpty ? bi('કોઈ નોંધ નથી - ઉપરનું + દબાવી લખો', 'No note - tap + to write one') : cur, style: ts(14, c: cur.isEmpty ? Pal.muted : null, h: 1.4)),
          if (!_edit) ...<Widget>[
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                if (screenOn('followups')) ...<Widget>[
                  tExp(child: Btn(bi('ફોલો-અપ', 'Follow-up'), icon: 'todo', kind: BtnKind.tonal, dense: true, onTap: () => app.go('followups', arg: widget.party.label))),
                  const SizedBox(width: 8),
                ],
                tExp(child: Btn(bi('સ્ટેટમેન્ટ', 'Statement'), icon: 'doc', kind: BtnKind.tonal, dense: true, onTap: () => app.go('statement', arg: widget.party))),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

/// Every note written so far.
class NotesScreen extends StatefulWidget {
  const NotesScreen({super.key});

  @override
  State<NotesScreen> createState() => _NotesState();
}

class _NotesState extends State<NotesScreen> {
  final TextEditingController _q = TextEditingController();

  @override
  void initState() {
    super.initState();
    noteDoc.addListener(_tick);
    noteDoc.ensure();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    noteDoc.removeListener(_tick);
    _q.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 700,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final String q = _q.text.trim().toLowerCase();
        final List<Map<String, dynamic>> l = <Map<String, dynamic>>[];
        for (final MapEntry<String, dynamic> e in noteDoc.map('n').entries) {
          final Object? v = e.value;
          if (v is! Map) continue;
          final String label = '${v['l'] ?? ''}';
          final String text = '${v['t'] ?? ''}';
          if (q.isNotEmpty && !label.toLowerCase().contains(q) && !text.toLowerCase().contains(q)) continue;
          l.add(<String, dynamic>{'id': e.key, 'l': label, 't': text, 'at': '${v['at'] ?? ''}'});
        }
        l.sort((Map<String, dynamic> a, Map<String, dynamic> b) => '${b['at']}'.compareTo('${a['at']}'));
        return <Widget>[
          ScreenHeader(bi('નોંધો', 'Notes'), sub: bi('ખેડૂત / ગાડી / દલાલ વિશેની તમારી નોંધ', 'Your notes about farmers, vehicles and brokers')),
          statusBanner(),
          SearchBox(hint: bi('નામ કે નોંધમાં શોધો', 'Search name or note'), controller: _q, onChanged: (String _) => setState(() {})),
          const SizedBox(height: 12),
          if (l.isEmpty) EmptyBox(icon: 'note', title: bi('કોઈ નોંધ નથી', 'No notes yet'), sub: bi('કોઈ પણ પાર્ટીની પ્રોફાઇલ ખોલી "મારી નોંધ" માં લખો', 'Open any profile and write in "My note"')),
          for (final Map<String, dynamic> n in l)
            lineItem(
              icon: 'note',
              tone: 'amber',
              title: '${n['l']}'.isEmpty ? '${n['id']}' : '${n['l']}',
              sub: '${n['t']}',
              trailing: '${n['at']}'.isEmpty ? null : ago(DateTime.tryParse('${n['at']}') ?? DateTime.now()),
              onTap: () {
                final PartyRef? r = partyRefOf('${n['id']}', '${n['l']}');
                if (r != null) openParty(r);
              },
            ),
        ];
      },
    );
  }
}

// =================================================================== target
String _tonStr(double v) => v == v.roundToDouble() ? '${v.round()}' : v.toStringAsFixed(1);

/// Daily goal in tons: how today is going and how many days reached it.
class TargetScreen extends StatefulWidget {
  const TargetScreen({super.key});

  @override
  State<TargetScreen> createState() => _TargetState();
}

class _TargetState extends State<TargetScreen> {
  late final VoidCallback _accept = () {
    _save();
  };

  final TextEditingController _t = TextEditingController();
  int _src = 0;

  @override
  void initState() {
    super.initState();
    AcceptHub.push(_accept);
    prefDoc.addListener(_tick);
    prefDoc.ensure().then((_) {
      if (!mounted) return;
      final double g = dailyTarget();
      setState(() => _t.text = g > 0 ? _tonStr(g / 1000) : '');
    });
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    prefDoc.removeListener(_tick);
    _t.dispose();
    AcceptHub.pop(_accept);
    super.dispose();
  }

  Future<void> _save() async {
    final double tons = dbl(_t.text.replaceAll(',', ''), 0);
    prefDoc.data['target'] = tons <= 0 ? 0 : tons * 1000;
    await prefDoc.save();
    app.toast(tons <= 0 ? bi('ટાર્ગેટ કાઢ્યો', 'Target removed') : bi('ટાર્ગેટ સેવ થયો', 'Target saved'));
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 800,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final double target = dailyTarget();
        final List<DayPoint> pts = dailySeries(lastDays(14));
        final List<double> v = <double>[for (final DayPoint d in pts) _src == 0 ? d.kantaKg : d.chitKg];
        final int last = v.length - 1;
        final double today = v.isEmpty ? 0 : v[last];
        int hit = 0;
        double best = 0;
        double sum = 0;
        for (int i = 0; i < last; i++) {
          if (target > 0 && v[i] >= target) hit++;
          if (v[i] > best) best = v[i];
          sum += v[i];
        }
        final double avg = last <= 0 ? 0 : sum / last;
        int streak = 0;
        for (int i = last - 1; i >= 0; i--) {
          if (target > 0 && v[i] >= target) {
            streak++;
          } else {
            break;
          }
        }
        if (target > 0 && today >= target) streak++;
        final double frac = target <= 0 ? 0 : (today / target).clamp(0.0, 1.0).toDouble();
        final Color ringColor = target <= 0 ? Pal.muted : (today >= target ? Pal.ok : (frac >= 0.6 ? Pal.warn : Pal.info));
        final List<Color> cols = <Color>[
          for (int i = 0; i < v.length; i++)
            target <= 0 ? Pal.info : (v[i] >= target ? Pal.ok : (i == last ? Pal.amber : Pal.bad)),
        ];
        double mx = target;
        for (final double x in v) {
          mx = math.max(mx, x);
        }

        return <Widget>[
          ScreenHeader(bi('રોજનો ટાર્ગેટ', 'Daily target'), sub: bi('છેલ્લા 14 દિવસ', 'Last 14 days')),
          statusBanner(),
          Seg(labels: <String>[bi('કાંટાનો માલ', 'Weighed in'), bi('ચિઠ્ઠીનો માલ', 'Chit weight')], index: _src, onChanged: (int i) => setState(() => _src = i), dense: true),
          const SizedBox(height: 12),
          Panel(
            child: Row(
              children: <Widget>[
                ScoreRing(value: frac, center: target <= 0 ? '—' : '${(today / target * 100).round()}%', color: ringColor, sub: kgTxt(today), size: 120),
                const SizedBox(width: 18),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(target <= 0 ? bi('ટાર્ગેટ નક્કી કરો', 'Set a target') : (today >= target ? bi('ટાર્ગેટ પૂરો! 🎉', 'Target reached! 🎉') : '${bi('બાકી', 'To go')} ${kgTxt(target - today)}'), style: ts(17, w: FontWeight.w800, c: ringColor)),
                      const SizedBox(height: 4),
                      Text(target <= 0 ? bi('નીચે ટન લખી સેવ કરો', 'Type tons below and save') : '${bi('ટાર્ગેટ', 'Target')} ${kgTxt(target)} / ${bi('દિવસ', 'day')}', style: ts(12.5, c: Pal.muted)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          metricGrid(ctx, <Widget>[
            MetricTile(label: bi('ટાર્ગેટ પૂરો થયો', 'Days reached'), value: target <= 0 ? '—' : '$hit / $last', icon: 'target', tone: 'green', sub: bi('આજ સિવાય', 'excluding today')),
            MetricTile(label: bi('સતત દિવસ', 'Streak'), value: target <= 0 ? '—' : '$streak', icon: 'fire', tone: 'amber', sub: bi('ટાર્ગેટ પૂરો થયેલા', 'days in a row')),
            MetricTile(label: bi('રોજનું સરેરાશ', 'Daily average'), value: kgShort(avg), icon: 'chart', tone: 'blue'),
            MetricTile(label: bi('સૌથી સારો દિવસ', 'Best day'), value: kgShort(best), icon: 'trophy', tone: 'violet'),
          ], pcCols: 4),
          const SizedBox(height: 12),
          Panel(
            title: bi('દરરોજનો માલ', 'Weight per day'),
            sub: target <= 0 ? null : bi('લીલો = ટાર્ગેટ પૂરો · લાલ = ઓછો', 'green = reached · red = below'),
            child: MiniBars(
              values: v,
              colors: cols,
              labels: <String>[for (final DayPoint d in pts) '${d.day.day}'],
              height: 150,
              maxV: mx <= 0 ? null : mx * 1.05,
            ),
          ),
          const SizedBox(height: 12),
          Panel(
            title: bi('ટાર્ગેટ બદલો', 'Change the target'),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Expanded(child: FieldX(label: bi('રોજના ટન', 'Tons per day'), controller: _t, keyboard: TextInputType.number, suffix: 'T')),
                const SizedBox(width: 10),
                Btn(bi('સેવ', 'Save'), icon: 'check', onTap: _save),
              ],
            ),
          ),
        ];
      },
    );
  }
}

// ================================================================ statement
/// A statement of one party for any period, ready to paste in WhatsApp.
class StatementScreen extends StatefulWidget {
  final PartyRef? party;
  const StatementScreen({super.key, this.party});

  @override
  State<StatementScreen> createState() => _StatementState();
}

class _StatementState extends State<StatementScreen> {
  RangeSel _sel = RangeSel(4);
  int _dim = 0;
  static const List<Dim> _dd = <Dim>[Dim.farmer, Dim.broker, Dim.village, Dim.vehicle];
  final TextEditingController _c = TextEditingController();
  List<PartySummary> _dir = <PartySummary>[];
  String _dirFor = '';

  @override
  void initState() {
    super.initState();
    rateDoc.ensure();
    final PartyRef? r = widget.party;
    if (r != null) {
      final int i = _dd.indexOf(r.dim);
      _dim = i < 0 ? 0 : i;
      _c.text = r.label;
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  /// Latest mobile number written on a chit of this party ('' when none).
  String _phoneOf(PartyRef r) {
    if (r.dim != Dim.farmer) return '';
    DateTime at = DateTime(2000);
    String best = '';
    for (final Chit c in live.chits) {
      if (dimKey(r.dim, c) != r.key) continue;
      final String d = digitsOf(c.mobile);
      if (d.length == 10 && c.at.isAfter(at)) {
        at = c.at;
        best = d;
      }
    }
    return best;
  }

  String _build(PartyRef r, Period p) {
    final PartyData d = partyData(r);
    final List<Chit> cs = d.chits.where((Chit c) => p.has(c.at)).toList();
    cs.sort((Chit a, Chit b) => a.at.compareTo(b.at));
    final List<Kanta> ks = d.kantas.where((Kanta k) => p.has(k.at)).toList();
    ks.sort((Kanta a, Kanta b) => a.at.compareTo(b.at));
    final StringBuffer b = StringBuffer();
    b.writeln('Balaji Industries');
    b.writeln('${bi('સ્ટેટમેન્ટ', 'Statement')}: ${r.label} (${dimName(r.dim)})');
    b.writeln(p.label);
    b.writeln('------------------------');
    double kg = 0;
    double amt = 0;
    bool anyRate = false;
    for (final Chit c in cs) {
      kg += c.cmpKg;
      final double? rate = rateFor(c.commodity.trim(), c.at);
      String amtTxt = '';
      if (rate != null) {
        final double a = c.cmpKg / 20 * rate;
        amt += a;
        anyRate = true;
        amtTxt = ' · ${inr(a)}';
      }
      b.writeln('${dm(c.at)} #${c.no} · ${c.vehicle} · ${c.commodity.isEmpty ? '' : '${matLabel(c.commodity)} · '}${grp(c.cmpKg)} KG$amtTxt');
    }
    if (cs.isNotEmpty) {
      b.writeln('------------------------');
      b.writeln('${bi('કુલ ચિઠ્ઠી', 'Chits')}: ${cs.length} · ${grp(kg)} KG${anyRate ? ' · ${inr(amt)}' : ''}');
    }
    if (ks.isNotEmpty) {
      double kk = 0;
      b.writeln();
      b.writeln(bi('કાંટો', 'Weighbridge'));
      for (final Kanta k in ks) {
        kk += k.kg;
        b.writeln('${dm(k.at)} RST ${k.rst} · ${k.vehicle} · ${grp(k.kg)} KG');
      }
      b.writeln('${bi('કુલ કાંટો', 'Total')}: ${ks.length} · ${grp(kk)} KG');
    }
    if (cs.isEmpty && ks.isEmpty) b.writeln(bi('આ સમયમાં કોઈ એન્ટ્રી નથી', 'No entries in this period'));
    return b.toString().trim();
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 800,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = _sel.period;
        final Dim dim = _dd[_dim];
        final String sig = '$_dim|${live.chits.length}|${live.kantas.length}';
        if (_dirFor != sig) {
          _dir = directoryOf(dim);
          _dir.sort((PartySummary a, PartySummary b) => b.kg.compareTo(a.kg));
          _dirFor = sig;
        }
        PartyRef? pick;
        final String q = _c.text.trim().toLowerCase();
        if (q.isNotEmpty) {
          for (final PartySummary s in _dir) {
            if (s.ref.label.toLowerCase() == q) {
              pick = s.ref;
              break;
            }
          }
        }
        final String text = pick == null ? '' : _build(pick, p);

        return <Widget>[
          ScreenHeader(bi('સ્ટેટમેન્ટ', 'Statement'), sub: bi('કોઈ પણ પાર્ટીનો હિસાબ - WhatsApp માટે', 'Any party - ready for WhatsApp')),
          statusBanner(),
          ChipRow(
            labels: <String>[bi('ખેડૂત', 'Farmer'), bi('દલાલ', 'Broker'), bi('ગામ', 'Village'), bi('ગાડી', 'Vehicle')],
            index: _dim,
            onChanged: (int i) => setState(() {
              _dim = i;
              _c.clear();
            }),
          ),
          const SizedBox(height: 10),
          SuggestField(
            label: bi('નામ પસંદ કરો', 'Pick a name'),
            controller: _c,
            options: <String>[for (final PartySummary s in _dir.take(400)) s.ref.label],
            onPick: (String _) => setState(() {}),
            onChanged: (String _) => setState(() {}),
          ),
          const SizedBox(height: 10),
          RangeBar(sel: _sel, presets: const <int>[2, 3, 4, 5, 6], onChanged: (RangeSel s) => setState(() => _sel = s)),
          const SizedBox(height: 12),
          if (pick == null)
            EmptyBox(icon: 'doc', title: bi('ઉપરથી નામ પસંદ કરો', 'Pick a name above'), sub: q.isEmpty ? null : bi('આ નામ મળ્યું નથી - યાદીમાંથી પસંદ કરો', 'Name not found - choose from the list'))
          else
            Panel(
              title: pick.label,
              action: IconBtn('copy', size: 40, tip: bi('કૉપિ', 'Copy'), onTap: () => copyText(text, msg: bi('કૉપિ થયું - WhatsApp માં મોકલો', 'Copied - paste in WhatsApp'))),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  SelectableText(text, style: ts(12.5, h: 1.5, tab: true)),
                  const SizedBox(height: 12),
                  Row(
                    children: <Widget>[
                      tExp(child: Btn(bi('કૉપિ કરો', 'Copy'), icon: 'copy', kind: BtnKind.tonal, onTap: () => copyText(text, msg: bi('કૉપિ થયું - WhatsApp માં મોકલો', 'Copied - paste in WhatsApp')))),
                      const SizedBox(width: 10),
                      tExp(child: Btn('WhatsApp', icon: 'chat', onTap: () => whatsappText(text, phone: _phoneOf(pick!)))),
                    ],
                  ),
                ],
              ),
            ),
        ];
      },
    );
  }
}

// ================================================================== mobiles
class _Mob {
  final String key;
  String label;
  String village = '';
  String mobile = '';
  DateTime mobileAt = DateTime(2000);
  int n = 0;
  DateTime last;
  _Mob(this.key, this.label, this.last);
}

/// Farmer phone book built from the mobile numbers written on chits.
class MobilesScreen extends StatefulWidget {
  const MobilesScreen({super.key});

  @override
  State<MobilesScreen> createState() => _MobilesState();
}

class _MobilesState extends State<MobilesScreen> {
  final TextEditingController _q = TextEditingController();
  int _show = 0;

  void _mobileMenu(BuildContext ctx, _Mob x) {
    openPanel(
      ctx,
      title: x.label,
      sub: x.mobile,
      width: 420,
      child: Builder(
        builder: (BuildContext c) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Btn(bi('ફોન કરો', 'Call'), icon: 'call', expand: true, onTap: () {
                Navigator.of(c).pop();
                callPhone(x.mobile);
              }),
              const SizedBox(height: 10),
              Btn('WhatsApp', icon: 'chat', kind: BtnKind.tonal, expand: true, onTap: () {
                Navigator.of(c).pop();
                whatsappText('', phone: x.mobile);
              }),
              const SizedBox(height: 10),
              Btn(bi('નંબર કૉપિ', 'Copy number'), icon: 'copy', kind: BtnKind.outline, expand: true, onTap: () {
                Navigator.of(c).pop();
                copyText(x.mobile, msg: bi('નંબર કૉપિ થયો: ${x.mobile}', 'Number copied: ${x.mobile}'));
              }),
              const SizedBox(height: 10),
              Btn(bi('ખેડૂતની પ્રોફાઇલ', 'Farmer profile'), icon: 'user', kind: BtnKind.ghost, expand: true, onTap: () {
                Navigator.of(c).pop();
                openParty(PartyRef(Dim.farmer, x.key, x.label));
              }),
            ],
          );
        },
      ),
    );
  }

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 700,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Map<String, _Mob> m = <String, _Mob>{};
        for (final Chit c in live.chits) {
          final String k = nameKey(c.farmer);
          if (k.isEmpty) continue;
          final _Mob x = m.putIfAbsent(k, () => _Mob(k, c.farmer, c.at));
          x.n++;
          if (c.at.isAfter(x.last)) x.last = c.at;
          if (c.village.isNotEmpty) x.village = c.village;
          final String d = digitsOf(c.mobile);
          if (d.length == 10 && c.at.isAfter(x.mobileAt)) {
            x.mobile = d;
            x.mobileAt = c.at;
          }
        }
        final String q = _q.text.trim().toLowerCase();
        final List<_Mob> all = m.values.toList();
        final int without = all.where((_Mob x) => x.mobile.isEmpty).length;
        List<_Mob> l = all.where((_Mob x) => _show == 0 ? x.mobile.isNotEmpty : x.mobile.isEmpty).toList();
        if (q.isNotEmpty) {
          l = l.where((_Mob x) => x.label.toLowerCase().contains(q) || x.village.toLowerCase().contains(q) || x.mobile.contains(q)).toList();
        }
        l.sort((_Mob a, _Mob b) => b.last.compareTo(a.last));

        return <Widget>[
          ScreenHeader(bi('ખેડૂતના મોબાઇલ', 'Farmer mobiles'), sub: '${all.length - without} / ${all.length}'),
          statusBanner(),
          SearchBox(hint: bi('નામ, ગામ કે નંબર', 'Name, village or number'), controller: _q, onChanged: (String _) => setState(() {})),
          const SizedBox(height: 10),
          ChipRow(
            labels: <String>['${bi('મોબાઇલ સાથે', 'With mobile')} (${all.length - without})', '${bi('મોબાઇલ વગર', 'Without')} ($without)'],
            index: _show,
            onChanged: (int i) => setState(() => _show = i),
          ),
          const SizedBox(height: 12),
          if (l.isEmpty) EmptyBox(icon: 'phone', title: bi('કંઈ મળ્યું નથી', 'Nothing found')),
          for (final _Mob x in l.take(80))
            lineItem(
              icon: x.mobile.isEmpty ? 'warn' : 'phone',
              tone: x.mobile.isEmpty ? 'rose' : 'green',
              title: x.label,
              sub: '${x.village.isEmpty ? '' : '${x.village} · '}${x.mobile.isEmpty ? bi('મોબાઇલ લખ્યો નથી', 'no mobile') : x.mobile} · ${x.n} ${bi('ચિઠ્ઠી', 'chits')}',
              trailing: ago(x.last),
              onTap: x.mobile.isEmpty ? () => openParty(PartyRef(Dim.farmer, x.key, x.label)) : () => _mobileMenu(ctx, x),
            ),
          if (l.length > 80) Padding(padding: const EdgeInsets.all(12), child: Text(bi('શોધ વડે બાકીના શોધો', 'Use search to find the rest'), style: ts(12.5, c: Pal.muted))),
        ];
      },
    );
  }
}
