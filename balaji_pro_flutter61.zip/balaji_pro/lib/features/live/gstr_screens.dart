import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/gst.dart';
import '../../data/gstr.dart';
import '../../data/insights.dart';
import '../../data/live_store.dart';
import '../../data/owner_docs.dart';
import '../../data/trade.dart' show saleDoc;
import '../../data/money.dart' show kGstHead;
import '../../data/vouchers.dart' show GstDuty, gstDuty, reportHtml;
import '../../widgets/accept.dart';
import '../../widgets/common.dart';
import '../../widgets/page.dart';
import 'gst_screens.dart' show openGstDetail;
import 'kit.dart';
import 'kit2.dart';
import 'money_screens.dart';
import 'ui.dart';
import 'voucher_screens.dart' show exportCsvOut, openExpForm, printOut;

// ======================================================================
// GSTR-1 summary, laid out like the GSTR-1 report of TallyPrime:
//   Particulars | Vch | Taxable Value | Integrated Tax | Central Tax | State Tax | Invoice Amount
//   Enter on a table opens the invoices inside it.
// ======================================================================

class _GRow {
  final String key; // table the row belongs to
  final String label;
  final String sub;
  final String vch;
  final String taxable;
  final String igst;
  final String cgst;
  final String sgst;
  final String value;
  final bool head;
  final bool total;
  final bool open;
  final GstInv? inv;
  const _GRow(
    this.key,
    this.label, {
    this.sub = '',
    this.vch = '',
    this.taxable = '',
    this.igst = '',
    this.cgst = '',
    this.sgst = '',
    this.value = '',
    this.head = false,
    this.total = false,
    this.open = false,
    this.inv,
  });

  String get full => sub.isEmpty ? label : '$label  ·  $sub';
}

String _a(double v) => v.abs() < 0.005 ? '' : grp(v, dec: 2);

String _rate(double r) => r == r.roundToDouble() ? '${r.round()}%' : '${r.toStringAsFixed(1)}%';

String _rates(Set<double> s) {
  final List<double> l = s.toList()..sort();
  return l.map(_rate).join(', ');
}

class Gstr1Screen extends StatefulWidget {
  const Gstr1Screen({super.key});

  @override
  State<Gstr1Screen> createState() => _Gstr1State();
}

class _Gstr1State extends State<Gstr1Screen> {
  late final VoidCallback _prn = () {
    _print();
  };
  late final VoidCallback _exp = () {
    _export();
  };

  RangeSel _sel = RangeSel(4);
  String _firm = '';
  final Set<String> _open = <String>{};

  @override
  void initState() {
    super.initState();
    printHub.push(_prn);
    exportHub.push(_exp);
  }

  @override
  void dispose() {
    printHub.pop(_prn);
    exportHub.pop(_exp);
    super.dispose();
  }

  _GRow _head(String key, String name, GrTot t, bool open) {
    return _GRow(key, name, vch: t.vouchers == 0 ? '' : '${t.vouchers}', taxable: _a(t.taxable), igst: _a(t.igst), cgst: _a(t.cgst), sgst: _a(t.sgst), value: _a(t.value), head: true, open: open);
  }

  List<_GRow> _rows(Gstr1 g, {bool all = false}) {
    final List<_GRow> out = <_GRow>[];
    bool opened(String k) => all || _open.contains(k);

    List<_GRow> invRows(String key, List<GrInv> l) {
      return <_GRow>[
        for (final GrInv x in l)
          _GRow(
            key,
            x.inv.party,
            sub: '${gstinClean(x.inv.gstin).isEmpty ? '' : '${gstinClean(x.inv.gstin)}  ·  '}${x.inv.no}  ·  ${dmy(x.inv.date)}  ·  ${_rates(x.rates)}${x.inv.rcm ? '  ·  RCM' : ''}',
            taxable: _a(x.taxable),
            igst: _a(x.igst),
            cgst: _a(x.cgst),
            sgst: _a(x.sgst),
            value: _a(x.value),
            inv: x.inv,
          ),
      ];
    }

    final GrTot b2b = g.tB2b;
    out.add(_head('b2b', '4A, 4B, 6B, 6C  -  ${bi('B2B બિલ (GSTIN વાળા)', 'B2B Invoices')}', b2b, opened('b2b')));
    if (opened('b2b')) out.addAll(invRows('b2b', g.b2b));

    final GrTot b2cl = g.tB2cl;
    out.add(_head('b2cl', '5  -  ${bi('B2C (મોટા) બિલ', 'B2C (Large) Invoices')}', b2cl, opened('b2cl')));
    if (opened('b2cl')) out.addAll(invRows('b2cl', g.b2cl));

    final GrTot b2cs = g.tB2cs;
    out.add(_head('b2cs', '7  -  ${bi('B2C (નાના) બિલ', 'B2C (Small) Invoices')}', b2cs, opened('b2cs')));
    if (opened('b2cs')) {
      for (final GrPos p in g.b2cs) {
        out.add(_GRow('b2cs', gstPlaceText(p.place), sub: _rate(p.rate), vch: '${p.ids.length}', taxable: _a(p.taxable), igst: _a(p.igst), cgst: _a(p.cgst), sgst: _a(p.sgst), value: _a(p.taxable + p.tax)));
      }
    }

    final GrTot nil = g.tNil;
    out.add(_head('nil', '8  -  ${bi('નિલ રેટેડ / મુક્ત સપ્લાય', 'Nil Rated, Exempted Supplies')}', nil, opened('nil')));
    if (opened('nil')) {
      for (final GrNil n in g.nil) {
        final String split = '${bi('નિલ', 'Nil rated')} ${_a(n.nil).isEmpty ? '0.00' : _a(n.nil)}  ·  ${bi('મુક્ત (Bill of Supply)', 'Exempted (Bill of Supply)')} ${_a(n.exempt).isEmpty ? '0.00' : _a(n.exempt)}';
        out.add(_GRow('nil', '${n.code}  ${n.name}', sub: split, vch: '${n.ids.length}', taxable: _a(n.total), value: _a(n.total)));
      }
    }

    // total of the tables above
    final GrTot tx = g.tTax;
    out.add(_GRow(
      'total',
      bi('કુલ (ટેબલ 4, 5, 7, 8)', 'Total (Tables 4, 5, 7, 8)'),
      vch: g.bills == 0 ? '' : '${g.bills}',
      taxable: _a(tx.taxable + nil.taxable),
      igst: _a(tx.igst),
      cgst: _a(tx.cgst),
      sgst: _a(tx.sgst),
      value: _a(tx.value + nil.value),
      total: true,
    ));

    final GrTot h = g.tHsn;
    out.add(_head('hsn', '12  -  ${bi('HSN મુજબ સરવાળો', 'HSN Summary')}', GrTot()..taxable = h.taxable..igst = h.igst..cgst = h.cgst..sgst = h.sgst..value = h.value, opened('hsn')));
    if (opened('hsn')) {
      for (final GrHsn x in g.hsn) {
        out.add(_GRow(
          'hsn',
          'HSN ${x.hsn.isEmpty ? '-' : x.hsn}  ${x.desc}',
          sub: '${grp(x.qty, dec: 2)} ${gstUqc(x.unit)}  ·  ${_rate(x.rate)}',
          taxable: _a(x.taxable),
          igst: _a(x.igst),
          cgst: _a(x.cgst),
          sgst: _a(x.sgst),
          value: _a(x.value),
        ));
      }
    }

    int net = 0;
    for (final GrDocs d in g.docs) {
      net += d.net;
    }
    out.add(_GRow('docs', '13  -  ${bi('આપેલા બિલ નંબર', 'Documents Issued')}', vch: net == 0 ? '' : '$net', head: true, open: opened('docs')));
    if (opened('docs')) {
      for (final GrDocs d in g.docs) {
        out.add(_GRow(
          'docs',
          '${d.from}  ${bi('થી', 'to')}  ${d.to}',
          sub: '${d.firm}  ·  ${d.fy}  ·  ${bi('કુલ', 'Total')} ${d.total}  ·  ${bi('રદ', 'Cancelled')} ${d.cancelled}',
          vch: '${d.net}',
        ));
      }
    }
    return out;
  }

  List<String> get _heads => <String>['Particulars', 'Vch', 'Taxable Value', 'Integrated Tax', 'Central Tax', 'State Tax', 'Invoice Amount'];

  Future<void> _print() async {
    final Gstr1 g = gstr1(_sel.period, firm: _firm);
    final List<_GRow> rows = _rows(g, all: true);
    final Set<int> bold = <int>{};
    final List<List<String>> body = <List<String>>[];
    for (final _GRow r in rows) {
      if (r.head || r.total) bold.add(body.length);
      body.add(<String>[r.full, r.vch, r.taxable, r.igst, r.cgst, r.sgst, r.value]);
    }
    await printOut(
      reportHtml(
        title: 'GSTR-1',
        period: '${_firmName()}  ·  ${tDateFull(g.period.from)} ${bi('થી', 'to')} ${tDateFull(g.period.lastDay)}',
        heads: _heads,
        right: const <bool>[false, true, true, true, true, true, true],
        rows: body,
        bold: bold,
      ),
      'gstr1',
    );
  }

  Future<void> _export() async {
    final Gstr1 g = gstr1(_sel.period, firm: _firm);
    final StringBuffer b = StringBuffer();
    b.writeln(<String>['Table', 'Particulars', 'Details', 'Vch', 'Taxable Value', 'Integrated Tax', 'Central Tax', 'State Tax', 'Invoice Amount'].map(csvCell).join(','));
    for (final _GRow r in _rows(g, all: true)) {
      b.writeln(<String>[r.key, r.label, r.sub, r.vch, r.taxable, r.igst, r.cgst, r.sgst, r.value].map(csvCell).join(','));
    }
    await exportCsvOut(b.toString(), 'gstr1-${dayKey(DateTime.now())}');
  }

  String _firmName() {
    if (_firm.isEmpty) return bi('બધી પેઢી', 'All firms');
    return gstFirmOf(_firm).name;
  }

  void _toggle(String key) {
    setState(() {
      if (!_open.remove(key)) _open.add(key);
    });
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[gstDoc, saleDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 1180,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final Period p = _sel.period;
          final List<GstFirm> firms = gstFirms();
          final Gstr1 g = gstr1(p, firm: _firm);
          final List<_GRow> rows = _rows(g);
          final bool pc = app.stagePc;
          final GrTot tx = g.tTax;
          final List<PcCol> cols = <PcCol>[
            PcCol(bi('વિગત (Particulars)', 'Particulars'), 0),
            PcCol('Vch', 56, right: true),
            PcCol(bi('કરપાત્ર રકમ', 'Taxable Value'), 120, right: true),
            PcCol('Integrated Tax', 112, right: true),
            PcCol('Central Tax', 104, right: true),
            PcCol('State Tax', 104, right: true),
            PcCol(bi('બિલ રકમ', 'Invoice Amount'), 128, right: true),
          ];
          final List<Widget> body = <Widget>[];
          if (pc) {
            body.add(pcHead(cols));
            for (final _GRow r in rows) {
              final VoidCallback? tap = r.head ? () => _toggle(r.key) : (r.inv != null ? () => openGstDetail(ctx, r.inv!) : null);
              body.add(pcRow(
                cols,
                <Widget>[
                  Padding(
                    padding: EdgeInsets.only(left: r.head || r.total ? 0 : 22),
                    child: pcTd(r.head ? '${r.open ? '▾' : '▸'}  ${r.full}' : r.full, bold: r.head || r.total),
                  ),
                  pcTd(r.vch, num: true, bold: r.head || r.total),
                  pcTd(r.taxable, num: true, bold: r.head || r.total),
                  pcTd(r.igst, num: true, bold: r.head || r.total),
                  pcTd(r.cgst, num: true, bold: r.head || r.total),
                  pcTd(r.sgst, num: true, bold: r.head || r.total),
                  pcTd(r.value, num: true, bold: r.head || r.total),
                ],
                onTap: tap,
                bg: r.total ? Pal.soft : null,
              ));
            }
          } else {
            for (final _GRow r in rows) {
              if (r.head || r.total) {
                body.add(const SizedBox(height: 6));
                body.add(Surface(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
                  color: r.total ? Pal.soft : null,
                  onTap: r.head ? () => _toggle(r.key) : null,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Expanded(child: Text(r.label, style: ts(13.5, w: FontWeight.w800))),
                          if (r.head) Icon(r.open ? Icons.expand_less_rounded : Icons.expand_more_rounded, color: Pal.muted, size: 20),
                        ],
                      ),
                      if (r.vch.isNotEmpty) InfoRow(bi('વાઉચર', 'Vouchers'), r.vch),
                      if (r.taxable.isNotEmpty) InfoRow(bi('કરપાત્ર રકમ', 'Taxable Value'), r.taxable),
                      if (r.igst.isNotEmpty) InfoRow('IGST', r.igst),
                      if (r.cgst.isNotEmpty) InfoRow('CGST', r.cgst),
                      if (r.sgst.isNotEmpty) InfoRow('SGST', r.sgst),
                      if (r.value.isNotEmpty) InfoRow(bi('બિલ રકમ', 'Invoice Amount'), r.value, bold: true),
                    ],
                  ),
                ));
              } else {
                body.add(lineItem(
                  icon: r.inv != null ? 'receipt' : 'percentbox',
                  tone: 'teal',
                  title: r.label,
                  sub: r.sub,
                  trailing: r.value.isEmpty ? r.vch : r.value,
                  trailingSub: r.taxable.isEmpty ? '' : '${bi('કરપાત્ર', 'Taxable')} ${r.taxable}',
                  onTap: r.inv == null ? null : () => openGstDetail(ctx, r.inv!),
                ));
              }
            }
          }
          final bool setup = !firms.any((GstFirm f) => f.ready);
          return <Widget>[
            ScreenHeader('GSTR-1', sub: '${_firmName()}  ·  ${_pLabel(p)}', actions: <Widget>[
              IconBtn('print', tip: bi('પ્રિન્ટ (Ctrl+P)', 'Print (Ctrl+P)'), onTap: _print),
              IconBtn('table', tip: bi('Excel (Alt+E)', 'Export to Excel (Alt+E)'), onTap: _export),
            ]),
            statusBanner(),
            RangeBar(sel: _sel, presets: const <int>[4, 5, 6], onChanged: (RangeSel s) => setState(() => _sel = s)),
            const SizedBox(height: 10),
            ChipRow(
              labels: <String>[bi('બધી પેઢી', 'All firms'), for (final GstFirm f in firms) f.name],
              index: _firm.isEmpty ? 0 : firms.indexWhere((GstFirm f) => f.id == _firm) + 1,
              onChanged: (int i) => setState(() => _firm = i == 0 ? '' : firms[i - 1].id),
            ),
            const SizedBox(height: 12),
            HeroCard(
              title: bi('આ પીરિયડનો GST (ટેબલ 4, 5, 7)', 'GST of the period (Tables 4, 5, 7)'),
              value: inrC(tx.tax),
              unit: '',
              sub: '${g.bills} ${bi('બિલ', 'bills')}',
              chips: <HeroChip>[
                HeroChip('rupee', '${bi('કરપાત્ર', 'Taxable')} ${inrC(tx.taxable)}'),
                HeroChip('percentbox', 'IGST ${inrC(tx.igst)}'),
                HeroChip('percentbox', 'CGST ${inrC(tx.cgst)} · SGST ${inrC(tx.sgst)}'),
              ],
            ),
            const SizedBox(height: 12),
            _dutyPanel(ctx, p),
            const SizedBox(height: 12),
            if (setup) noteBox('warn', 'amber', bi('પેઢીનો GSTIN ભર્યો નથી - GST બિલ ખોલી "પેઢીની વિગત" માં ભરો.', 'The GSTIN of the firm is not entered - fill it in GST Invoices > Firm details.'), onTap: () => app.go('gst_bill')),
            for (final String w in g.warnings.take(8)) noteBox('warn', 'amber', w),
            if (g.warnings.length > 8) caption(bi('+ ${g.warnings.length - 8} વધુ સૂચના', '+ ${g.warnings.length - 8} more checks')),
            if (g.bills == 0) EmptyBox(icon: 'receipt', title: bi('આ પીરિયડમાં કોઈ GST બિલ નથી', 'No GST bills in this period'), sub: bi('GST બિલ બનાવો - પછી અહીં રિટર્નનો સરવાળો દેખાશે', 'Make GST bills - the return totals appear here')) else ...body,
            const SizedBox(height: 8),
            noteBox('bulb', 'teal', bi('આ સરવાળો CA માટે છે - રિટર્ન GST પોર્ટલ પર ભરાય છે. ક્રેડિટ / ડેબિટ નોટ (9B) અને એડવાન્સ (11) હજી એપમાં નથી. B2C (મોટા) ની હદ ₹${grp(kB2clLimit)} ગણી છે - CA સાથે ચકાસો.', 'These totals are for your CA - the return itself is filed on the GST portal. Credit / debit notes (9B) and advances (11) are not in the app yet. The B2C (Large) limit used is ₹${grp(kB2clLimit)} - confirm with the CA.')),
            caption(bi('ટેબલ પર Enter / ટેપ: અંદરના બિલ. બિલ પર Enter: બિલ ખૂલશે.', 'Enter / tap on a table to see the bills inside it. Enter on a bill opens it.')),
          ];
        },
      ),
    );
  }

  /// Duties & Taxes (GST) in the books: the tax inside the sales of the period against what was paid to the Government.
  Widget _dutyPanel(BuildContext ctx, Period p) {
    final GstDuty d = gstDuty(p);
    return Panel(
      title: bi('ડ્યુટી અને ટેક્સ (GST) - ચોપડામાં', 'Duties & Taxes (GST) - in the books'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          InfoRow(bi('શરૂઆતનું ભરવાનું', 'Opening payable'), grp(d.opening, dec: 2)),
          InfoRow(bi('વેચાણ બિલમાં GST (જમા)', 'GST in sales bills (Cr)'), grp(d.collected, dec: 2)),
          InfoRow(bi('સરકારને ભર્યું (ઉધાર)', 'Paid to Govt (Dr)'), grp(d.paid, dec: 2)),
          InfoRow(bi('હજી ભરવાનું', 'Still to pay'), grp(d.closing, dec: 2), bold: true, color: d.closing > 0.5 ? Pal.warn : null),
          const SizedBox(height: 8),
          Btn(bi('GST ભર્યું - એન્ટ્રી', 'Record GST payment'), icon: 'plus', kind: BtnKind.tonal, dense: true, onTap: () => openExpForm(ctx, cat: kGstHead)),
          const SizedBox(height: 6),
          caption(bi('ફક્ત ખરીદી પરનો ઇનપુટ ક્રેડિટ (ITC) ગણાયો નથી - એ CA સાથે મેળવો.', 'Input tax credit (ITC) on purchases is not counted here - settle that with your CA.')),
        ],
      ),
    );
  }

  String _pLabel(Period p) => '${tDateFull(p.from)} ${bi('થી', 'to')} ${tDateFull(p.lastDay)}';
}
