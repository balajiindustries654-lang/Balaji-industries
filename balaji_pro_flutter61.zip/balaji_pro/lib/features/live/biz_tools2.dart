import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/app_state.dart';
import '../../core/errlog.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../core/version.dart';
import '../../data/engine.dart';
import '../../data/insights.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../data/owner_docs.dart';
import '../../widgets/common.dart';
import '../../widgets/page.dart';
import '../registry.dart';
import 'biz_tools.dart';
import 'kit.dart';
import 'kit2.dart';
import 'ui.dart';
import 'value_screens.dart' show materialNames;

// ================================================================== recents
/// The screens opened last and the farmers / vehicles pinned to home.
class RecentsScreen extends StatelessWidget {
  const RecentsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 700,
      rows: (BuildContext ctx) {
        final List<FeatureDef> fl = <FeatureDef>[];
        for (final String id in app.recent) {
          final FeatureDef? f = featureById(id);
          if (f == null || id == 'recents') continue;
          if (!shownFor(f, live.isAdmin)) continue;
          if (f.status == FStatus.soon) continue;
          fl.add(f);
        }
        final List<Widget> pinned = <Widget>[];
        if (live.isAdmin) {
          for (final MapEntry<String, String> e in live.pins.entries) {
            final PartyRef? r = partyRefOf(e.key, e.value);
            if (r == null) continue;
            pinned.add(lineItem(icon: 'star', tone: 'amber', title: e.value.isEmpty ? e.key : e.value, sub: dimName(r.dim), onTap: () => openParty(r)));
          }
        }
        return <Widget>[
          ScreenHeader(bi('હમણાં ખોલેલા', 'Recent'), sub: bi('છેલ્લે ખોલેલી સ્ક્રીન અને પિન કરેલી પાર્ટી', 'Screens you opened last and pinned parties')),
          statusBanner(),
          if (fl.isEmpty) EmptyBox(icon: 'hist', title: bi('હજુ કોઈ સ્ક્રીન ખોલી નથી', 'Nothing opened yet')),
          for (final FeatureDef f in fl) lineItem(icon: f.icon, tone: f.tone, title: f.title, sub: f.desc, onTap: () => app.go(f.id)),
          if (pinned.isNotEmpty) ...<Widget>[
            const SizedBox(height: 8),
            caption(bi('હોમ પર પિન કરેલા', 'Pinned to home')),
            ...pinned,
          ],
        ];
      },
    );
  }
}

// =============================================================== diagnostics
/// What the app holds, who is signed in and whether the server answers.
class DiagnosticsScreen extends StatefulWidget {
  const DiagnosticsScreen({super.key});

  @override
  State<DiagnosticsScreen> createState() => _DiagnosticsState();
}

class _DiagnosticsState extends State<DiagnosticsScreen> {
  Map<String, Object>? _h;
  bool _busy = false;

  Future<void> _check() async {
    setState(() => _busy = true);
    Map<String, Object> r;
    try {
      r = await live.supa.health();
    } catch (e) {
      r = <String, Object>{'restOk': false, 'restMsg': '$e', 'restMs': 0, 'scan': 'error', 'scanMs': 0};
    }
    if (!mounted) return;
    setState(() {
      _h = r;
      _busy = false;
    });
  }

  String _scanTxt(String s) {
    if (s == 'ok') return bi('ચાલુ છે', 'Working');
    if (s == 'missing') return bi('deploy થયું નથી', 'Not deployed');
    return bi('ભૂલ', 'Error');
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 700,
      rows: (BuildContext ctx) {
        final Profile? me = live.me;
        final Map<String, Object>? h = _h;
        final String uid = live.uid;
        final String lines = <String>[
          'Balaji Pro $kAppVersion diagnostics ${dmy(DateTime.now())} ${hm(DateTime.now())}',
          'user: ${me == null ? '-' : '${me.name} (${me.role})'}',
          'uid: ${uid.length > 8 ? uid.substring(0, 8) : uid}',
          'chits ${live.chits.length} · kanta ${live.kantas.length} · maal ${live.maals.length} · trips ${live.trips.length} · findings ${live.findings.length}',
          'horizon ${live.days} days · loaded ${live.loadedAt == null ? '-' : hm(live.loadedAt!)}',
          'offline ${live.offline} · waiting ${live.pending.length}',
          if (h != null) 'server ${h['restOk']} ${h['restMs']}ms · scan ${h['scan']} ${h['scanMs']}ms',
          if (ErrLog.items.isNotEmpty) 'errors:\n${ErrLog.text()}',
        ].join('\n');

        return <Widget>[
          ScreenHeader(bi('એપ તપાસ', 'App diagnostics'), sub: bi('કંઈ ખોટું લાગે તો આ જુઓ', 'Look here when something seems wrong')),
          statusBanner(),
          Panel(
            title: bi('ખાતું', 'Account'),
            child: Column(
              children: <Widget>[
                InfoRow(bi('નામ', 'Name'), me == null || me.name.isEmpty ? '—' : me.name),
                InfoRow(bi('ભૂમિકા', 'Role'), me == null ? '—' : me.role),
                InfoRow(bi('મોબાઇલ', 'Mobile'), me == null || me.mobile.length < 4 ? '—' : '******${me.mobile.substring(me.mobile.length - 4)}'),
                InfoRow('ID', uid.length > 8 ? uid.substring(0, 8) : (uid.isEmpty ? '—' : uid)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Panel(
            title: bi('ડેટા', 'Data'),
            child: Column(
              children: <Widget>[
                InfoRow(bi('ચિઠ્ઠી', 'Chits'), grp(live.chits.length)),
                InfoRow(bi('કાંટા એન્ટ્રી', 'Kanta entries'), grp(live.kantas.length)),
                InfoRow(bi('માલ એન્ટ્રી', 'Maal entries'), grp(live.maals.length)),
                InfoRow(bi('ગાડી (મેળ)', 'Trips (matched)'), grp(live.trips.length)),
                InfoRow(bi('શંકાઓ', 'Findings'), '${live.findings.length} (${live.openFindings.length} ${bi('ખુલ્લી', 'open')})'),
                InfoRow(bi('કેટલા દિવસનો ડેટા', 'Days loaded'), '${live.days}'),
                InfoRow(bi('છેલ્લે તાજું', 'Last refreshed'), live.loadedAt == null ? '—' : '${hm(live.loadedAt!)} (${ago(live.loadedAt!)})'),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Panel(
            title: bi('કનેક્શન', 'Connection'),
            child: Column(
              children: <Widget>[
                InfoRow(bi('ઇન્ટરનેટ', 'Internet'), live.offline ? bi('નથી', 'Offline') : bi('ચાલુ', 'Online'), color: live.offline ? Pal.bad : Pal.ok, bold: true),
                InfoRow(bi('મોકલવાની બાકી એન્ટ્રી', 'Entries waiting'), '${live.pending.length}', color: live.pending.isEmpty ? null : Pal.warn),
                if (h != null) ...<Widget>[
                  InfoRow(bi('સર્વર', 'Server'), '${h['restMsg']} · ${h['restMs']} ms', color: h['restOk'] == true ? Pal.ok : Pal.bad, bold: true),
                  InfoRow(bi('સ્કેનર સેવા', 'Scanner service'), '${_scanTxt('${h['scan']}')} · ${h['scanMs']} ms', color: h['scan'] == 'ok' ? Pal.ok : (h['scan'] == 'missing' ? Pal.warn : Pal.bad), bold: true),
                ],
                const SizedBox(height: 10),
                Btn(_busy ? bi('તપાસ ચાલુ...', 'Checking...') : bi('સર્વર તપાસો', 'Check the server'), icon: 'wifi', kind: BtnKind.tonal, expand: true, onTap: _busy ? null : _check),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Panel(
            title: bi('મેળ ની મર્યાદા', 'Match limits'),
            child: Column(
              children: <Widget>[
                InfoRow(bi('ઘટ %', 'Loss %'), '${live.cfg.pct}%'),
                InfoRow(bi('ન્યૂનતમ KG', 'Minimum KG'), '${live.cfg.floorKg}'),
                InfoRow(bi('કાંટા માટે રાહ', 'Wait for kanta'), '${live.cfg.waitH} ${bi('કલાક', 'h')}'),
                InfoRow(bi('એક ગાડીનો સમય', 'One-load window'), '${live.cfg.windowH} ${bi('કલાક', 'h')}'),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Panel(
            title: bi('છેલ્લી ભૂલો (બટન કામ ન કરે તો અહીં કારણ દેખાય)', 'Recent errors (the reason when a button does nothing)'),
            child: ErrLog.items.isEmpty
                ? Text(bi('કોઈ ભૂલ નથી', 'No errors'), style: ts(13.5, w: FontWeight.w700, c: Pal.ok))
                : Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      for (final String e in ErrLog.items.take(12))
                        Padding(padding: const EdgeInsets.only(bottom: 6), child: Text(e, style: ts(12.5, c: Pal.bad))),
                    ],
                  ),
          ),
          const SizedBox(height: 12),
          Btn(bi('રિપોર્ટ કૉપિ કરો (મોકલવા)', 'Copy report (to send)'), icon: 'copy', kind: BtnKind.outline, expand: true, onTap: () => copyText(lines, msg: bi('કૉપિ થયું', 'Copied'))),
        ];
      },
    );
  }
}

// ================================================================== routine
class _RItem {
  final String id;
  final String text;
  final bool custom;
  const _RItem(this.id, this.text, this.custom);
}

/// Daily checklist you tick yourself (the list resets every morning).
class RoutineScreen extends StatefulWidget {
  const RoutineScreen({super.key});

  @override
  State<RoutineScreen> createState() => _RoutineState();
}

class _RoutineState extends State<RoutineScreen> {
  final TextEditingController _new = TextEditingController();
  Set<String> _done = <String>{};

  String get _key => 'routine_${dayKey(DateTime.now())}';

  @override
  void initState() {
    super.initState();
    prefDoc.addListener(_tick);
    prefDoc.ensure();
    _load();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    prefDoc.removeListener(_tick);
    _new.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      final String today = _key;
      for (final String k in p.getKeys().toList()) {
        if (k.startsWith('routine_') && k != today) await p.remove(k);
      }
      _done = (p.getStringList(today) ?? <String>[]).toSet();
    } catch (_) {}
    if (mounted) setState(() {});
  }

  Future<void> _store() async {
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setStringList(_key, _done.toList());
    } catch (_) {}
  }

  void _flip(String id) {
    setState(() {
      if (!_done.remove(id)) _done.add(id);
    });
    _store();
  }

  Future<void> _addCustom() async {
    final String t = _new.text.trim();
    if (t.isEmpty) return;
    final List<Map<String, dynamic>> l = prefDoc.list('routine');
    l.add(<String, dynamic>{'id': 'c${DateTime.now().microsecondsSinceEpoch}', 't': t});
    _new.clear();
    await prefDoc.save();
  }

  Future<void> _removeCustom(String id) async {
    final List<Map<String, dynamic>> l = prefDoc.list('routine');
    l.removeWhere((Map<String, dynamic> x) => '${x['id']}' == id);
    _done.remove(id);
    await prefDoc.save();
    _store();
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 700,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final List<_RItem> items = <_RItem>[
          _RItem('d1', bi('કાંટાનો ઝીરો / ટેસ્ટ વજન તપાસ્યું', 'Weighbridge zero / test weight checked'), false),
          _RItem('d2', bi('ગઈકાલનો દિવસ બંધ કર્યો', 'Yesterday closed'), false),
          _RItem('d3', bi('આજના ભાવ નાખ્યા', 'Today\'s rates entered'), false),
          _RItem('d4', bi('રસ્તામાં ગાડીઓ તપાસી', 'Vehicles on the way checked'), false),
          _RItem('d5', bi('ચિઠ્ઠી-કાંટા ફરક જોયા', 'Chit-kanta differences reviewed'), false),
          _RItem('d6', bi('ગોડાઉન સ્ટોક ગણ્યો', 'Godown stock counted'), false),
          _RItem('d7', bi('ફોલો-અપ યાદી જોઈ', 'Follow-ups reviewed'), false),
          _RItem('d8', bi('સાંજે દિવસ બંધ કર્યો', 'Day closed in the evening'), false),
          for (final Map<String, dynamic> c in prefDoc.list('routine')) _RItem('${c['id']}', '${c['t']}', true),
        ];
        int n = 0;
        for (final _RItem x in items) {
          if (_done.contains(x.id)) n++;
        }
        return <Widget>[
          ScreenHeader(bi('રોજનું લિસ્ટ', 'Daily routine'), sub: '$n / ${items.length} ${bi('પૂરું', 'done')}'),
          statusBanner(),
          Panel(
            child: Row(
              children: <Widget>[
                ScoreRing(value: items.isEmpty ? 0 : n / items.length, center: '$n/${items.length}', color: n == items.length ? Pal.ok : Pal.info, size: 90),
                const SizedBox(width: 16),
                Expanded(child: Text(n == items.length ? bi('આજનું બધું કામ પૂરું! 🎉', 'Everything done for today! 🎉') : bi('દરેક કામ કર્યા પછી ટિક કરો. કાલે સવારે લિસ્ટ ફરી ખાલી થશે.', 'Tick each job when done. The list resets tomorrow morning.'), style: ts(13.5, w: FontWeight.w700))),
              ],
            ),
          ),
          const SizedBox(height: 12),
          for (final _RItem x in items)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Surface(
                padding: const EdgeInsets.fromLTRB(4, 4, 6, 4),
                onTap: () => _flip(x.id),
                child: Row(
                  children: <Widget>[
                    IconBtn(_done.contains(x.id) ? 'check' : 'circle', size: 42, color: _done.contains(x.id) ? Pal.ok : Pal.muted, onTap: () => _flip(x.id)),
                    Expanded(child: Text(x.text, style: ts(14.5, w: FontWeight.w700, c: _done.contains(x.id) ? Pal.muted : null, deco: _done.contains(x.id) ? TextDecoration.lineThrough : null))),
                    if (x.custom) IconBtn('trash', size: 38, onTap: () => _removeCustom(x.id)),
                  ],
                ),
              ),
            ),
          const SizedBox(height: 8),
          Panel(
            title: bi('પોતાનું કામ ઉમેરો', 'Add your own job'),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Expanded(child: FieldX(label: bi('કામ', 'Job'), controller: _new, onSubmitted: (String _) => _addCustom())),
                const SizedBox(width: 10),
                Btn(bi('ઉમેરો', 'Add'), icon: 'plus', onTap: _addCustom),
              ],
            ),
          ),
        ];
      },
    );
  }
}

// ================================================================== day open
class _Chk {
  final bool ok;
  final String title;
  final String sub;
  final String route;
  const _Chk(this.ok, this.title, this.sub, this.route);
}

/// Morning check: is everything ready to start the day? (from the real data)
class DayOpenScreen extends StatefulWidget {
  const DayOpenScreen({super.key});

  @override
  State<DayOpenScreen> createState() => _DayOpenState();
}

class _DayOpenState extends State<DayOpenScreen> {
  @override
  void initState() {
    super.initState();
    rateDoc.addListener(_tick);
    prefDoc.addListener(_tick);
    todoDoc.addListener(_tick);
    rateDoc.ensure();
    prefDoc.ensure();
    todoDoc.ensure();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    rateDoc.removeListener(_tick);
    prefDoc.removeListener(_tick);
    todoDoc.removeListener(_tick);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 700,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final DateTime now = DateTime.now();
        final DateTime today = dayOf(now);
        final DateTime yday = addDays(today, -1);
        final bool hadYday = statsFor(Period(yday, today)).trips > 0;
        final bool ydClosed = !hadYday || live.isClosed(yday);
        final int hot = live.openFindings.where((Finding f) => f.sev >= 2).length;
        final int stale = live.trips.where((Trip t) => t.state == TripState.noKanta && now.difference(t.at).inHours < 72).length;
        final List<String> mats = materialNames().take(3).toList();
        int noRate = 0;
        for (final String m in mats) {
          final List<MapEntry<String, double>> rs = ratesOfMaterial(m);
          if (rs.isEmpty || rs.first.key != dayKey(today)) noRate++;
        }
        final int overdue = followupCounts()[1];
        final bool fresh = live.loadedAt != null && now.difference(live.loadedAt!).inMinutes < 15;
        final List<_Chk> cl = <_Chk>[
          _Chk(ydClosed, bi('ગઈકાલનો દિવસ બંધ', 'Yesterday closed'), ydClosed ? (hadYday ? bi('બંધ થઈ ગયો', 'Closed') : bi('ગઈકાલે કોઈ ગાડી નહોતી', 'No vehicles yesterday')) : bi('હજુ ખુલ્લો છે - બંધ કરો', 'Still open - close it'), 'day_close'),
          _Chk(hot == 0, bi('મોટી શંકાઓ', 'Serious alerts'), hot == 0 ? bi('કોઈ નથી', 'None') : bi('$hot ખુલ્લી છે', '$hot open'), 'alerts'),
          _Chk(stale == 0, bi('કાંટા વગરની જૂની ગાડી', 'Old vehicles without kanta'), stale == 0 ? bi('કોઈ નથી', 'None') : bi('$stale ગાડી', '$stale vehicles'), 'missing_kanta'),
          _Chk(mats.isEmpty || noRate == 0, bi('આજના ભાવ', 'Today\'s rates'), mats.isEmpty ? bi('માલ મળ્યો નથી', 'No material yet') : (noRate == 0 ? bi('નાખેલા છે', 'Entered') : bi('$noRate માલનો ભાવ નાખવો બાકી', '$noRate materials need a rate')), 'rates'),
          _Chk(dailyTarget() > 0, bi('આજનો ટાર્ગેટ', 'Daily target'), dailyTarget() > 0 ? kgTxt(dailyTarget()) : bi('નક્કી કર્યો નથી', 'Not set'), 'target'),
          _Chk(overdue == 0, bi('મોડા ફોલો-અપ', 'Overdue follow-ups'), overdue == 0 ? bi('કોઈ નથી', 'None') : bi('$overdue મોડા', '$overdue overdue'), 'followups'),
          _Chk(live.pending.isEmpty, bi('મોકલવાની બાકી એન્ટ્રી', 'Entries waiting to upload'), live.pending.isEmpty ? bi('કોઈ નથી', 'None') : bi('${live.pending.length} બાકી', '${live.pending.length} waiting'), 'offline_queue'),
          _Chk(fresh, bi('ડેટા તાજો', 'Data is fresh'), live.loadedAt == null ? bi('હજુ આવ્યો નથી', 'Not loaded') : '${bi('છેલ્લે', 'Last')} ${ago(live.loadedAt!)}', ''),
        ];
        final int okN = cl.where((_Chk c) => c.ok).length;
        return <Widget>[
          ScreenHeader(bi('દિવસ શરૂ', 'Start of day'), sub: dmy(now)),
          statusBanner(),
          Panel(
            child: Row(
              children: <Widget>[
                ScoreRing(value: okN / cl.length, center: '$okN/${cl.length}', color: okN == cl.length ? Pal.ok : (okN >= cl.length - 2 ? Pal.warn : Pal.bad), size: 100),
                const SizedBox(width: 16),
                Expanded(child: Text(okN == cl.length ? bi('બધું તૈયાર - દિવસ શરૂ કરો! ☀️', 'All set - start the day! ☀️') : bi('${cl.length - okN} બાબત જોવી બાકી છે', '${cl.length - okN} items need a look'), style: ts(15, w: FontWeight.w800))),
              ],
            ),
          ),
          const SizedBox(height: 12),
          for (final _Chk c in cl)
            lineItem(
              icon: c.ok ? 'check' : 'warn',
              tone: c.ok ? 'green' : 'amber',
              title: c.title,
              sub: c.sub,
              onTap: c.route.isEmpty ? () => live.refresh() : () => app.go(c.route),
            ),
        ];
      },
    );
  }
}

// ================================================================ converter
/// KG / mann / quintal / ton / bags - and what it costs at a rate.
class ConverterScreen extends StatefulWidget {
  const ConverterScreen({super.key});

  @override
  State<ConverterScreen> createState() => _ConverterState();
}

class _ConverterState extends State<ConverterScreen> {
  final TextEditingController _v = TextEditingController(text: '1');
  final TextEditingController _bag = TextEditingController(text: '35');
  final TextEditingController _rate = TextEditingController();
  int _u = 0;

  @override
  void dispose() {
    _v.dispose();
    _bag.dispose();
    _rate.dispose();
    super.dispose();
  }

  Widget _out(String label, double v, int dec, {String unit = ''}) {
    final String txt = '${grp(v, dec: dec)}${unit.isEmpty ? '' : ' $unit'}';
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Surface(
        padding: const EdgeInsets.fromLTRB(16, 12, 8, 12),
        onTap: () => copyText(grp(v, dec: dec).replaceAll(',', ''), msg: bi('કૉપિ થયું: $txt', 'Copied: $txt')),
        child: Row(
          children: <Widget>[
            Expanded(child: Text(label, style: ts(14, w: FontWeight.w700, c: Pal.muted))),
            Text(txt, style: ts(18, w: FontWeight.w800, tab: true)),
            const SizedBox(width: 6),
            Icon(Icons.copy_rounded, size: 16, color: Pal.faint),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 600,
      rows: (BuildContext ctx) {
        final double v = dbl(_v.text.replaceAll(',', ''), 0);
        double bagKg = dbl(_bag.text, 35);
        if (bagKg <= 0) bagKg = 35;
        final List<double> f = <double>[1, 20, 100, 1000, bagKg];
        final double kg = v * f[_u];
        final double rate = dbl(_rate.text.replaceAll(',', ''), 0);
        return <Widget>[
          ScreenHeader(bi('વજન કન્વર્ટર', 'Weight converter'), sub: bi('KG · મણ · ક્વિન્ટલ · ટન · બેગ', 'KG · mann · quintal · ton · bags')),
          statusBanner(),
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                FieldX(label: bi('કેટલું?', 'How much?'), controller: _v, keyboard: const TextInputType.numberWithOptions(decimal: true), big: true, onChanged: (String _) => setState(() {})),
                const SizedBox(height: 10),
                ChipRow(
                  labels: <String>['KG', bi('મણ (20 KG)', 'Mann (20 KG)'), bi('ક્વિન્ટલ', 'Quintal'), bi('ટન', 'Ton'), bi('બેગ', 'Bags')],
                  index: _u,
                  onChanged: (int i) => setState(() => _u = i),
                ),
                if (_u == 4) ...<Widget>[
                  const SizedBox(height: 10),
                  FieldX(label: bi('એક બેગનું વજન', 'Weight of one bag'), controller: _bag, keyboard: TextInputType.number, suffix: 'KG', onChanged: (String _) => setState(() {})),
                ],
              ],
            ),
          ),
          const SizedBox(height: 12),
          _out('KG', kg, kg == kg.roundToDouble() ? 0 : 2),
          _out(bi('મણ (20 KG)', 'Mann (20 KG)'), kg / 20, 2),
          _out(bi('ક્વિન્ટલ', 'Quintal'), kg / 100, 2),
          _out(bi('ટન', 'Ton'), kg / 1000, 3),
          _out(bi('બેગ (${grp(bagKg)} KG)', 'Bags (${grp(bagKg)} KG)'), kg / bagKg, 1),
          const SizedBox(height: 8),
          Panel(
            title: bi('કિંમત', 'Cost'),
            sub: bi('ભાવ પ્રતિ 20 KG (મણ)', 'Rate per 20 KG (mann)'),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                FieldX(label: bi('ભાવ', 'Rate'), controller: _rate, keyboard: TextInputType.number, suffix: '₹ / 20 KG', onChanged: (String _) => setState(() {})),
                if (rate > 0) ...<Widget>[
                  const SizedBox(height: 12),
                  InfoRow(bi('કુલ રકમ', 'Amount'), inr(kg / 20 * rate), bold: true, color: Pal.ok),
                  InfoRow(bi('પ્રતિ KG', 'Per KG'), '₹${(rate / 20).toStringAsFixed(2)}'),
                  InfoRow(bi('પ્રતિ ક્વિન્ટલ', 'Per quintal'), inr(rate * 5)),
                  InfoRow(bi('પ્રતિ ટન', 'Per ton'), inr(rate * 50)),
                ],
              ],
            ),
          ),
        ];
      },
    );
  }
}

// ==================================================================== my day
/// What I entered today (works for the owner and for staff).
class MyDayScreen extends StatelessWidget {
  const MyDayScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 700,
      rows: (BuildContext ctx) {
        final DateTime today = dayOf(DateTime.now());
        final String me = live.uid;
        final List<Chit> cs = live.chits.where((Chit c) => c.by == me && !c.at.isBefore(today)).toList();
        final List<Kanta> ks = live.kantas.where((Kanta k) => k.by == me && !k.at.isBefore(today)).toList();
        final List<MaalRow> ms = live.maals.where((MaalRow m) => m.by == me && !m.at.isBefore(today)).toList();
        double chitKg = 0;
        int chitBags = 0;
        for (final Chit c in cs) {
          chitKg += c.cmpKg;
          chitBags += c.bags;
        }
        double kantaKg = 0;
        for (final Kanta k in ks) {
          kantaKg += k.kg;
        }
        int maalBags = 0;
        for (final MaalRow m in ms) {
          maalBags += m.bags;
        }
        final int total = cs.length + ks.length + ms.length;
        final List<MapEntry<DateTime, Widget>> items = <MapEntry<DateTime, Widget>>[];
        for (final Chit c in cs) {
          items.add(MapEntry<DateTime, Widget>(c.at, chitTile(ctx, c)));
        }
        for (final Kanta k in ks) {
          items.add(MapEntry<DateTime, Widget>(k.at, kantaTile(ctx, k)));
        }
        for (final MaalRow m in ms) {
          items.add(MapEntry<DateTime, Widget>(m.at, maalTile(ctx, m)));
        }
        items.sort((MapEntry<DateTime, Widget> a, MapEntry<DateTime, Widget> b) => b.key.compareTo(a.key));
        final String summary = <String>[
          '${bi('મારો દિવસ', 'My day')} - ${dmy(DateTime.now())}',
          if (cs.isNotEmpty) '${bi('ચિઠ્ઠી', 'Chits')}: ${cs.length} · ${grp(chitKg)} KG${chitBags > 0 ? ' · $chitBags ${bi('બેગ', 'bags')}' : ''}',
          if (ks.isNotEmpty) '${bi('કાંટો', 'Kanta')}: ${ks.length} · ${grp(kantaKg)} KG',
          if (ms.isNotEmpty) '${bi('માલ', 'Maal')}: ${ms.length} · $maalBags ${bi('બેગ', 'bags')}',
        ].join('\n');

        return <Widget>[
          ScreenHeader(bi('મારો દિવસ', 'My day'), sub: dmy(DateTime.now()), onPhone: true),
          statusBanner(),
          HeroCard(
            title: bi('આજે મેં કરેલી એન્ટ્રી', 'Entries I made today'),
            value: '$total',
            unit: bi('એન્ટ્રી', 'entries'),
            sub: live.pending.isEmpty ? null : bi('${live.pending.length} મોકલવાની બાકી', '${live.pending.length} waiting to upload'),
            chips: <HeroChip>[
              HeroChip('receipt', '${cs.length} ${bi('ચિઠ્ઠી', 'chits')}'),
              HeroChip('scale', '${ks.length} ${bi('કાંટો', 'kanta')}'),
              HeroChip('bag', '${ms.length} ${bi('માલ', 'maal')}'),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: <Widget>[
              tExp(child: Btn(bi('ચિઠ્ઠી', 'Chit'), icon: 'plus', kind: BtnKind.tonal, dense: true, onTap: () => app.go('chithi_new'))),
              const SizedBox(width: 8),
              tExp(child: Btn(bi('કાંટો', 'Kanta'), icon: 'plus', kind: BtnKind.tonal, dense: true, onTap: () => app.go('kanta_new'))),
              const SizedBox(width: 8),
              tExp(child: Btn(bi('માલ', 'Maal'), icon: 'plus', kind: BtnKind.tonal, dense: true, onTap: () => app.go('maal_new'))),
            ],
          ),
          const SizedBox(height: 12),
          if (total > 0) ...<Widget>[
            Btn(bi('આજનો હિસાબ કૉપિ (WhatsApp)', 'Copy today\'s summary (WhatsApp)'), icon: 'copy', kind: BtnKind.outline, expand: true, dense: true, onTap: () => copyText(summary, msg: bi('કૉપિ થયું', 'Copied'))),
            const SizedBox(height: 12),
          ],
          if (items.isEmpty) EmptyBox(icon: 'list', title: bi('આજે હજી કોઈ એન્ટ્રી નથી', 'No entries yet today')),
          for (final MapEntry<DateTime, Widget> e in items) e.value,
        ];
      },
    );
  }
}

// ================================================================= handover
/// Hand over to the next person: a short text of what is going on.
class HandoverScreen extends StatefulWidget {
  const HandoverScreen({super.key});

  @override
  State<HandoverScreen> createState() => _HandoverState();
}

class _HandoverState extends State<HandoverScreen> {
  final TextEditingController _note = TextEditingController();

  @override
  void initState() {
    super.initState();
    todoDoc.ensure();
  }

  @override
  void dispose() {
    _note.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 700,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final DateTime now = DateTime.now();
        final DateTime today = dayOf(now);
        final Stats s = statsFor(Period(today, addDays(today, 1)));
        final List<Trip> onWay = live.trips.where((Trip t) => t.state == TripState.wait).toList();
        double onWayKg = 0;
        for (final Trip t in onWay) {
          onWayKg += t.chitKg;
        }
        final int stale = live.trips.where((Trip t) => t.state == TripState.noKanta && now.difference(t.at).inHours < 72).length;
        final int hot = live.openFindings.where((Finding f) => f.sev >= 2).length;
        final List<int> fu = followupCounts();
        final String n = _note.text.trim();
        final String text = <String>[
          '🔄 ${bi('શિફ્ટ હૅન્ડઓવર', 'Shift handover')} - ${dmy(now)} ${hm(now)}',
          '------------------------',
          '${bi('આજે કાંટે', 'Weighed today')}: ${s.trips} ${bi('ગાડી', 'vehicles')} · ${grp(s.kantaKg)} KG',
          '${bi('ચિઠ્ઠી', 'Chits')}: ${s.chits} · ${grp(s.chitKg)} KG',
          '${bi('ફરક વાળી ગાડી', 'Vehicles with difference')}: ${s.diffTrips}',
          '${bi('રસ્તામાં', 'On the way')}: ${onWay.length} ${bi('ગાડી', 'vehicles')} · ${grp(onWayKg)} KG',
          '${bi('કાંટા વગરની જૂની ગાડી', 'Old vehicles without kanta')}: $stale',
          '${bi('મોટી શંકાઓ', 'Serious alerts')}: $hot',
          '${bi('બાકી ફોલો-અપ', 'Open follow-ups')}: ${fu[0]} (${fu[1]} ${bi('મોડા', 'late')})',
          '${bi('મોકલવાની બાકી એન્ટ્રી', 'Entries waiting')}: ${live.pending.length}',
          if (n.isNotEmpty) '',
          if (n.isNotEmpty) '${bi('નોંધ', 'Note')}: $n',
        ].join('\n');

        return <Widget>[
          ScreenHeader(bi('હૅન્ડઓવર', 'Handover'), sub: bi('આગળના માણસને શું ચાલે છે તે મોકલો', 'Tell the next person what is going on')),
          statusBanner(),
          FieldX(label: bi('ખાસ નોંધ (વૈકલ્પિક)', 'Special note (optional)'), controller: _note, maxLines: 3, onChanged: (String _) => setState(() {})),
          const SizedBox(height: 12),
          Panel(
            title: bi('સંદેશ', 'Message'),
            action: IconBtn('copy', size: 40, onTap: () => copyText(text, msg: bi('કૉપિ થયું - WhatsApp માં મોકલો', 'Copied - paste in WhatsApp'))),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                SelectableText(text, style: ts(13, h: 1.5)),
                const SizedBox(height: 12),
                Btn(bi('કૉપિ કરો', 'Copy'), icon: 'copy', expand: true, onTap: () => copyText(text, msg: bi('કૉપિ થયું - WhatsApp માં મોકલો', 'Copied - paste in WhatsApp'))),
              ],
            ),
          ),
        ];
      },
    );
  }
}
