import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../widgets/common.dart';
import '../../widgets/page.dart';
import 'field.dart';
import 'kit.dart';
import 'kit2.dart';
import 'ui.dart';

// ======================================================================
// Entries with an impossible weight (typing mistakes)
// ======================================================================

Future<void> _deleteOne(BuildContext context, String kind, String id) async {
  final bool go = await confirmBox(
    context,
    title: bi('આ ખોટી એન્ટ્રી કાઢી નાખવી?', 'Delete this wrong entry?'),
    text: bi('એન્ટ્રી કાઢી નંખાશે. જરૂર પડે તો "ફેરફાર ઇતિહાસ" માંથી પાછી લાવી શકાય.', 'The entry is removed. If needed it can be brought back from the edit history.'),
    yes: bi('હા, કાઢો', 'Yes, delete'),
    no: bi('ના', 'No'),
  );
  if (!go) return;
  final String e = await live.deleteEntry(kind, id);
  app.toast(e.isEmpty ? bi('કાઢી નાખ્યું', 'Deleted') : e);
}

Future<void> _openBad(BuildContext context, {required String kind, required String id, required String title, required String sub, required List<List<String>> rows}) {
  return openPanel(
    context,
    title: title,
    sub: sub,
    width: 440,
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        for (final List<String> r in rows) InfoRow(r[0], r[1]),
        const SizedBox(height: 14),
        Btn(
          bi('આ એન્ટ્રી કાઢો', 'Delete this entry'),
          icon: 'trash',
          kind: BtnKind.danger,
          expand: true,
          onTap: () async {
            await _deleteOne(context, kind, id);
            if (context.mounted) Navigator.of(context).pop();
          },
        ),
      ],
    ),
  );
}

class BadEntriesScreen extends StatelessWidget {
  const BadEntriesScreen({super.key});

  Future<void> _deleteAll(BuildContext context) async {
    final int n = live.badCount;
    final bool go = await confirmBox(
      context,
      title: bi('બધી $n ખોટી એન્ટ્રી કાઢવી?', 'Delete all $n wrong entries?'),
      text: bi('બધી એન્ટ્રી કાઢી નંખાશે. જરૂર પડે તો "ફેરફાર ઇતિહાસ" માંથી પાછી લાવી શકાય.', 'All of them are removed. If needed they can be brought back from the edit history.'),
      yes: bi('હા, બધી કાઢો', 'Yes, delete all'),
      no: bi('ના', 'No'),
    );
    if (!go) return;
    int ok = 0;
    String last = '';
    final List<MapEntry<String, String>> all = <MapEntry<String, String>>[
      for (final Chit c in live.badChits) MapEntry<String, String>('chit', c.id),
      for (final Kanta k in live.badKantas) MapEntry<String, String>('kanta', k.id),
      for (final MaalRow m in live.badMaals) MapEntry<String, String>('maal', m.id),
    ];
    for (final MapEntry<String, String> e in all) {
      final String r = await live.deleteEntry(e.key, e.value);
      if (r.isEmpty) {
        ok++;
      } else {
        last = r;
      }
    }
    app.toast(last.isEmpty ? '${bi('કાઢી નાખ્યું', 'Deleted')}: $ok' : last);
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 760,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final int n = live.badCount;
        return <Widget>[
          ScreenHeader(bi('ખોટા વજનની એન્ટ્રી', 'Wrong-weight entries'), sub: bi('ગણતરીમાંથી બહાર રાખેલી', 'Kept out of every total')),
          statusBanner(),
          noteBox(
            'info',
            'amber',
            bi(
              'આ એન્ટ્રીઓમાં વજન ${grp(kMaxLoadKg, dec: 0)} KG થી વધારે (કે ${grp(kMaxBags.toDouble(), dec: 0)} થી વધુ બેગ) છે. એક ગાડીમાં આટલું શક્ય નથી, એટલે ટાઈપ ભૂલ ગણીને કોઈ કુલ આંકડામાં લીધી નથી.',
              'These entries have more than ${grp(kMaxLoadKg, dec: 0)} KG (or over ${grp(kMaxBags.toDouble(), dec: 0)} bags). A vehicle cannot carry that, so they are treated as typing mistakes and left out of every total.',
            ),
          ),
          if (n == 0) EmptyBox(icon: 'check', title: bi('કોઈ ખોટી એન્ટ્રી નથી', 'No wrong entries'), sub: bi('બધા વજન સામાન્ય છે', 'All weights look normal')),
          if (n > 0) Btn(bi('બધી $n એન્ટ્રી કાઢો', 'Delete all $n entries'), icon: 'trash', kind: BtnKind.danger, expand: true, onTap: () => _deleteAll(ctx)),
          if (n > 0) const SizedBox(height: 12),
          if (live.badChits.isNotEmpty) caption(bi('ચિઠ્ઠી', 'CHITS')),
          for (final Chit c in live.badChits)
            lineItem(
              icon: 'receipt',
              tone: 'rose',
              title: '${c.farmer.isEmpty ? '-' : c.farmer} · ${c.vehicle}',
              sub: '#${c.no} · ${dayLabel(c.at)}',
              trailing: '${grp(c.gross > 0 ? c.gross : c.net, dec: 0)} KG',
              trailingSub: c.bags > 0 ? '${grp(c.bags.toDouble(), dec: 0)} ${bi('બેગ', 'bags')}' : null,
              trailingColor: Pal.bad,
              onTap: () => _openBad(ctx, kind: 'chit', id: c.id, title: c.farmer.isEmpty ? c.vehicle : c.farmer, sub: '${bi('ચિઠ્ઠી', 'Chit')} #${c.no}', rows: <List<String>>[
                <String>[bi('ગાડી', 'Vehicle'), c.vehicle],
                <String>[bi('કુલ વજન', 'Gross'), '${grp(c.gross, dec: 0)} KG'],
                <String>[bi('ચોખ્ખું', 'Net'), '${grp(c.net, dec: 0)} KG'],
                <String>[bi('બેગ', 'Bags'), '${grp(c.bags.toDouble(), dec: 0)}'],
                <String>[bi('તારીખ', 'Date'), '${dmy(c.at)} ${hm(c.at)}'],
              ]),
            ),
          if (live.badKantas.isNotEmpty) caption(bi('કાંટો', 'WEIGHBRIDGE')),
          for (final Kanta k in live.badKantas)
            lineItem(
              icon: 'scale',
              tone: 'rose',
              title: k.vehicle.isEmpty ? '-' : k.vehicle,
              sub: 'RST ${k.rst} · ${dayLabel(k.at)}',
              trailing: '${grp(k.kg, dec: 0)} KG',
              trailingColor: Pal.bad,
              onTap: () => _openBad(ctx, kind: 'kanta', id: k.id, title: k.vehicle, sub: 'RST ${k.rst}', rows: <List<String>>[
                <String>[bi('વજન', 'Weight'), '${grp(k.kg, dec: 0)} KG'],
                <String>[bi('તારીખ', 'Date'), '${dmy(k.at)} ${hm(k.at)}'],
              ]),
            ),
          if (live.badMaals.isNotEmpty) caption(bi('માલ એન્ટ્રી', 'MAAL ENTRIES')),
          for (final MaalRow m in live.badMaals)
            lineItem(
              icon: 'bag',
              tone: 'rose',
              title: m.vehicle.isEmpty ? '-' : m.vehicle,
              sub: '${matLabel(m.material)} · ${dayLabel(m.date)}',
              trailing: '${grp(m.bags.toDouble(), dec: 0)} ${bi('બેગ', 'bags')}',
              trailingColor: Pal.bad,
              onTap: () => _openBad(ctx, kind: 'maal', id: m.id, title: m.vehicle, sub: matLabel(m.material), rows: <List<String>>[
                <String>[bi('બેગ', 'Bags'), grp(m.bags.toDouble(), dec: 0)],
                <String>[bi('તારીખ', 'Date'), dmy(m.date)],
              ]),
            ),
        ];
      },
    );
  }
}
