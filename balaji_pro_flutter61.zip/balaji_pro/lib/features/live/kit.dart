import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/device.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/icons.dart';
import '../../core/palette.dart';
import '../../data/books.dart';
import '../../data/insights.dart';
import '../../widgets/accept.dart';
import '../../widgets/dayfield.dart';
import '../../widgets/charts.dart';
import '../../widgets/common.dart';

/// Shared building blocks for the insight / operations / tools screens.

// ------------------------------------------------------------------ range bar
/// Chips for choosing a period (today, 7 days, this month ... or own dates).
class RangeBar extends StatefulWidget {
  final RangeSel sel;
  final ValueChanged<RangeSel> onChanged;
  final List<int> presets;
  const RangeBar({super.key, required this.sel, required this.onChanged, this.presets = const <int>[0, 1, 2, 3, 4, 5, 6]});

  @override
  State<RangeBar> createState() => _RangeBarState();
}

class _RangeBarState extends State<RangeBar> {
  // F2 (and Alt+F2) opens the period box of the screen, like TallyPrime
  late final VoidCallback _hub = () {
    _box();
  };

  @override
  void initState() {
    super.initState();
    periodHub.push(_hub);
  }

  @override
  void dispose() {
    periodHub.pop(_hub);
    super.dispose();
  }

  void _box() {
    if (!mounted) return;
    openPeriodBox(context, widget.sel, widget.onChanged);
  }

  @override
  Widget build(BuildContext context) {
    final List<String> all = RangeSel.labels();
    final RangeSel sel = widget.sel;
    final List<int> presets = widget.presets;
    if (Pal.tally) {
      // TallyPrime: the period is one line of text; F2 (or a click on it) opens the Change Period box
      return Padding(
        padding: const EdgeInsets.only(bottom: 4),
        child: Align(
          alignment: Alignment.centerLeft,
          child: InkWell(
            onTap: _box,
            hoverColor: Pal.focusFill,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(border: Border.all(color: Pal.line)),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Text('F2: ${bi('પીરિયડ', 'Period')} : ', style: ts(12.5, w: FontWeight.w800, c: Pal.brand)),
                  Text('${dmy(sel.period.from)} ${bi('થી', 'to')} ${dmy(sel.period.lastDay)}', style: ts(12.5, w: FontWeight.w700)),
                  if (sel.preset != 6 && sel.preset < all.length) Text('   (${all[sel.preset]})', style: ts(12, c: Pal.muted)),
                ],
              ),
            ),
          ),
        ),
      );
    }
    final Widget chips = ChipRow(
      labels: <String>[for (final int i in presets) all[i]],
      index: presets.indexOf(sel.preset),
      onChanged: (int i) {
        final int pr = presets[i];
        if (pr == 6) {
          _box();
        } else {
          widget.onChanged(RangeSel(pr));
        }
      },
    );
    if (sel.preset != 6) return chips;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        chips,
        Padding(
          padding: const EdgeInsets.only(top: 6, left: 2),
          child: Text('${bi('પીરિયડ', 'Period')}: ${dmy(sel.period.from)} - ${dmy(sel.period.lastDay)}', style: ts(12.5, w: FontWeight.w700, c: Pal.muted)),
        ),
      ],
    );
  }
}

// ----------------------------------------------------------------- period box
/// TallyPrime's "Change Period" box (F2): type the From and To dates, or use a quick button.
Future<void> openPeriodBox(BuildContext context, RangeSel cur, ValueChanged<RangeSel> onApply) {
  return openPanel(
    context,
    title: bi('પીરિયડ બદલો', 'Change period'),
    sub: 'F2',
    width: 440,
    child: _PeriodBox(cur: cur, onApply: onApply),
  );
}

class _PeriodBox extends StatefulWidget {
  final RangeSel cur;
  final ValueChanged<RangeSel> onApply;
  const _PeriodBox({required this.cur, required this.onApply});

  @override
  State<_PeriodBox> createState() => _PeriodBoxState();
}

class _PeriodBoxState extends State<_PeriodBox> {
  late final VoidCallback _accept = () {
    _apply();
  };
  late DateTime _from;
  late DateTime _to;

  @override
  void initState() {
    super.initState();
    final Period p = widget.cur.period;
    _from = p.from;
    _to = p.lastDay;
    AcceptHub.push(_accept);
  }

  @override
  void dispose() {
    AcceptHub.pop(_accept);
    super.dispose();
  }

  void _set(DateTime a, DateTime b) => setState(() {
        _from = dateOnly(a);
        _to = dateOnly(b);
      });

  void _apply() {
    if (_to.isBefore(_from)) {
      app.toast(bi('છેલ્લી તારીખ પહેલી તારીખ પછી હોવી જોઈએ', 'The To date must not be before the From date'));
      return;
    }
    final RangeSel n = RangeSel(6);
    n.cFrom = _from;
    n.cTo = _to;
    widget.onApply(n);
    Navigator.of(context).pop();
  }

  Widget _quick(String label, DateTime a, DateTime b) => Btn(label, kind: BtnKind.tonal, dense: true, tabStop: false, onTap: () => _set(a, b));

  @override
  Widget build(BuildContext context) {
    final DateTime t = dateOnly(DateTime.now());
    final DateTime fy = finYearStart(t);
    final DateTime q = DateTime(t.year, ((t.month - 1) ~/ 3) * 3 + 1, 1);
    final DateTime far = DateTime(t.year + 1, 12, 31);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        DayField(label: bi('થી (From)', 'From'), value: _from, last: far, onChanged: (DateTime d) => setState(() => _from = dateOnly(d))),
        const SizedBox(height: 12),
        DayField(label: bi('સુધી (To)', 'To'), value: _to, last: far, onChanged: (DateTime d) => setState(() => _to = dateOnly(d))),
        const SizedBox(height: 14),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: <Widget>[
            _quick(bi('આજે', 'Today'), t, t),
            _quick(bi('ગઈકાલે', 'Yesterday'), t.subtract(const Duration(days: 1)), t.subtract(const Duration(days: 1))),
            _quick(bi('7 દિવસ', 'Last 7 days'), t.subtract(const Duration(days: 6)), t),
            _quick(bi('30 દિવસ', 'Last 30 days'), t.subtract(const Duration(days: 29)), t),
            _quick(bi('આ મહિનો', 'This month'), DateTime(t.year, t.month, 1), t),
            _quick(bi('ગયો મહિનો', 'Last month'), DateTime(t.year, t.month - 1, 1), DateTime(t.year, t.month, 0)),
            _quick(bi('આ ત્રિમાસિક', 'This quarter'), q, t),
            _quick(bi('આ નાણાકીય વર્ષ ${finYearLabel(fy)}', 'This year ${finYearLabel(fy)}'), fy, t),
            _quick(bi('ગયું વર્ષ ${finYearLabel(DateTime(fy.year - 1, 4, 1))}', 'Last year ${finYearLabel(DateTime(fy.year - 1, 4, 1))}'), DateTime(fy.year - 1, 4, 1), DateTime(fy.year, 3, 31)),
            _quick(bi('બધો સમય', 'All time'), DateTime(2023, 1, 1), t),
          ],
        ),
        const SizedBox(height: 8),
        Text(bi('તારીખ ટાઇપ કરો: 1504 = 15 એપ્રિલ, 150426 = પૂરી તારીખ, T = આજે', 'Type a date: 1504 = 15 Apr, 150426 = full date, T = today'), style: ts(12, c: Pal.muted)),
        const SizedBox(height: 16),
        Btn(bi('લાગુ કરો (Enter)', 'Apply (Enter)'), icon: 'check', expand: true, onTap: _apply),
      ],
    );
  }
}

// ------------------------------------------------------------------- skeleton
/// Grey pulsing blocks shown while the first load is running.
class SkeletonList extends StatefulWidget {
  final int rows;
  const SkeletonList({super.key, this.rows = 6});

  @override
  State<SkeletonList> createState() => _SkeletonListState();
}

class _SkeletonListState extends State<SkeletonList> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1100))..repeat(reverse: true);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Widget _bar(double w, double h) => Container(
        width: w,
        height: h,
        decoration: BoxDecoration(color: Pal.line, borderRadius: BorderRadius.circular(Pal.rad(6))),
      );

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (BuildContext context, Widget? child) {
        return Opacity(
          opacity: 0.45 + 0.55 * _c.value,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Surface(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[_bar(120, 12), const SizedBox(height: 14), _bar(220, 30), const SizedBox(height: 14), _bar(160, 12)],
                ),
              ),
              const SizedBox(height: 12),
              for (int i = 0; i < widget.rows; i++)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Surface(
                    padding: const EdgeInsets.all(14),
                    child: Row(
                      children: <Widget>[
                        Container(width: 40, height: 40, decoration: BoxDecoration(color: Pal.line, shape: BoxShape.circle)),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[_bar(150, 13), const SizedBox(height: 8), _bar(100, 10)],
                          ),
                        ),
                        _bar(54, 14),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

// ------------------------------------------------------------------ hero card
/// The big gradient card at the top of the home screen.
class HeroCard extends StatelessWidget {
  final String title;
  final String value;
  final String unit;
  final String? sub;
  final List<double>? spark;
  final List<HeroChip> chips;
  final VoidCallback? onTap;
  const HeroCard({super.key, required this.title, required this.value, required this.unit, this.sub, this.spark, this.chips = const <HeroChip>[], this.onTap});

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    if (Pal.tally) {
      // TallyPrime: a plain boxed line "Total ........ amount" with the small facts under it
      return Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Material(
          color: Pal.surface,
          shape: Border.all(color: Pal.line),
          child: InkWell(
            onTap: onTap,
            hoverColor: Pal.focusFill,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 6, 10, 6),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.baseline,
                    textBaseline: TextBaseline.alphabetic,
                    children: <Widget>[
                      Expanded(child: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(13, w: FontWeight.w700))),
                      Text(value, style: ts(16, w: FontWeight.w800, c: Pal.brand, tab: true)),
                      const SizedBox(width: 4),
                      Text(unit, style: ts(12, w: FontWeight.w700, c: Pal.muted)),
                    ],
                  ),
                  if (sub != null) Text(sub!, style: ts(12, c: Pal.muted)),
                  if (chips.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 3), child: Wrap(spacing: 18, runSpacing: 2, children: chips)),
                ],
              ),
            ),
          ),
        ),
      );
    }
    final Widget text = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(title, style: ts(13.5, w: FontWeight.w700, c: const Color(0xCCFFFFFF))),
        const SizedBox(height: 6),
        Row(
          crossAxisAlignment: CrossAxisAlignment.baseline,
          textBaseline: TextBaseline.alphabetic,
          children: <Widget>[
            Flexible(
              child: FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text(value, style: ts(pc ? 36 : 38, w: FontWeight.w800, c: Colors.white, ls: -1.0, tab: true)),
              ),
            ),
            const SizedBox(width: 6),
            Text(unit, style: ts(15, w: FontWeight.w700, c: const Color(0xB3FFFFFF))),
          ],
        ),
        if (sub != null) ...<Widget>[
          const SizedBox(height: 4),
          Text(sub!, style: ts(13, c: const Color(0xCCFFFFFF), w: FontWeight.w600)),
        ],
        if (chips.isNotEmpty) ...<Widget>[
          const SizedBox(height: 14),
          Wrap(spacing: 8, runSpacing: 8, children: chips),
        ],
      ],
    );
    final Widget body = pc && spark != null
        ? Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Expanded(flex: 3, child: text),
              const SizedBox(width: 20),
              Expanded(flex: 2, child: SizedBox(height: 76, child: Spark(values: spark!, color: Colors.white, fill: true))),
            ],
          )
        : Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              text,
              if (spark != null) ...<Widget>[
                const SizedBox(height: 12),
                SizedBox(height: 54, child: Spark(values: spark!, color: Colors.white, fill: true)),
              ],
            ],
          );
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(Pal.rad(22)),
      child: InkWell(
        borderRadius: BorderRadius.circular(Pal.rad(22)),
        onTap: onTap,
        child: Container(
          padding: EdgeInsets.all(pc ? 18 : 18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(Pal.rad(22)),
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: <Color>[Color(0xFF065E62), Color(0xFF087F83), Color(0xFF2AA39E)],
            ),
            boxShadow: const <BoxShadow>[BoxShadow(color: Color(0x33087F83), blurRadius: 22, offset: Offset(0, 10))],
          ),
          child: body,
        ),
      ),
    );
  }
}

class HeroChip extends StatelessWidget {
  final String icon;
  final String text;
  const HeroChip(this.icon, this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    if (Pal.tally) return Text(text, style: ts(12, w: FontWeight.w600, c: Pal.ink));
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
      decoration: BoxDecoration(color: const Color(0x26FFFFFF), borderRadius: BorderRadius.circular(Pal.rad(99))),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(ic(icon), size: 15, color: Colors.white),
          const SizedBox(width: 6),
          Text(text, style: ts(12.5, w: FontWeight.w700, c: Colors.white)),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- metric tile
/// Compact number card with an up / down comparison.
class MetricTile extends StatelessWidget {
  final String label;
  final String value;
  final String? unit;
  final String? sub;
  final String icon;
  final String tone;
  final Delta? delta;
  final bool upIsGood;
  final VoidCallback? onTap;
  const MetricTile({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
    this.unit,
    this.sub,
    this.tone = 'teal',
    this.delta,
    this.upIsGood = true,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final Delta? d = delta;
    String dTone = 'slate';
    if (d != null && !d.flat) dTone = (d.up == upIsGood) ? 'green' : 'rose';
    if (Pal.tally) {
      return Material(
        color: Pal.surface,
        shape: Border.all(color: Pal.line),
        child: InkWell(
          onTap: onTap,
          hoverColor: Pal.focusFill,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(10, 6, 10, 6),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12, c: Pal.muted, w: FontWeight.w600)),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.baseline,
                  textBaseline: TextBaseline.alphabetic,
                  children: <Widget>[
                    Flexible(child: Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(15, w: FontWeight.w800, tab: true))),
                    if (unit != null) ...<Widget>[const SizedBox(width: 4), Text(unit!, style: ts(11.5, w: FontWeight.w700, c: Pal.muted))],
                    if (d != null) ...<Widget>[const SizedBox(width: 8), Text(d.text, style: ts(11.5, w: FontWeight.w700, c: Pal.tone(dTone).fg))],
                  ],
                ),
                if (sub != null) Text(sub!, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(11, c: Pal.faint)),
              ],
            ),
          ),
        ),
      );
    }
    return Surface(
      onTap: onTap,
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Row(
            children: <Widget>[
              IconChip(icon, tone: tone, size: 34),
              const Spacer(),
              if (d != null) Pill(d.text, tone: dTone, icon: d.flat ? null : (d.up ? 'arrowup' : 'arrowdown'), small: true),
            ],
          ),
          const SizedBox(height: 10),
          Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12.5, c: Pal.muted, w: FontWeight.w600)),
          const SizedBox(height: 2),
          Row(
            crossAxisAlignment: CrossAxisAlignment.baseline,
            textBaseline: TextBaseline.alphabetic,
            children: <Widget>[
              Flexible(child: Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(22, w: FontWeight.w800, ls: -0.4, tab: true))),
              if (unit != null) ...<Widget>[const SizedBox(width: 4), Text(unit!, style: ts(12, w: FontWeight.w700, c: Pal.muted))],
            ],
          ),
          if (sub != null) ...<Widget>[const SizedBox(height: 2), Text(sub!, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(11.5, c: Pal.faint))],
        ],
      ),
    );
  }
}

// ------------------------------------------------------------------ rank list
class RankItem {
  final String label;
  final double value;
  final String valueText;
  final String? sub;
  final Color color;
  final VoidCallback? onTap;
  const RankItem(this.label, this.value, this.valueText, this.color, {this.sub, this.onTap});
}

/// Horizontal bars, biggest first.
class RankList extends StatelessWidget {
  final List<RankItem> items;
  const RankList(this.items, {super.key});

  @override
  Widget build(BuildContext context) {
    double mx = 0;
    for (final RankItem r in items) {
      if (r.value > mx) mx = r.value;
    }
    return Column(
      children: <Widget>[
        for (final RankItem r in items)
          InkWell(
            borderRadius: BorderRadius.circular(Pal.rad(10)),
            onTap: r.onTap,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 7, horizontal: 2),
              child: ProgressRow(label: r.label, value: r.value, max: mx, color: r.color, trailing: r.valueText, sub: r.sub),
            ),
          ),
      ],
    );
  }
}

// ----------------------------------------------------------------- score ring
class ScoreRing extends StatelessWidget {
  final double value; // 0..1
  final String center;
  final String? sub;
  final Color color;
  final double size;
  const ScoreRing({super.key, required this.value, required this.center, required this.color, this.sub, this.size = 96});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: <Widget>[
          CustomPaint(size: Size(size, size), painter: _RingPainter(c01(value), color, Pal.line)),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Text(center, style: ts(size * 0.26, w: FontWeight.w800, ls: -0.5, tab: true)),
              if (sub != null) Text(sub!, style: ts(size * 0.12, c: Pal.muted, w: FontWeight.w600)),
            ],
          ),
        ],
      ),
    );
  }
}

class _RingPainter extends CustomPainter {
  final double v;
  final Color color;
  final Color track;
  _RingPainter(this.v, this.color, this.track);

  @override
  void paint(Canvas canvas, Size size) {
    const double th = 9;
    final Offset c = Offset(size.width / 2, size.height / 2);
    final double r = size.width / 2 - th / 2;
    final Rect rect = Rect.fromCircle(center: c, radius: r);
    canvas.drawCircle(
      c,
      r,
      Paint()
        ..color = track
        ..style = PaintingStyle.stroke
        ..strokeWidth = th,
    );
    if (v > 0) {
      canvas.drawArc(
        rect,
        -math.pi / 2,
        2 * math.pi * v,
        false,
        Paint()
          ..color = color
          ..style = PaintingStyle.stroke
          ..strokeWidth = th
          ..strokeCap = StrokeCap.round,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _RingPainter old) => old.v != v || old.color != color || old.track != track;
}

// ---------------------------------------------------------------- misc helpers
/// Titled block with an icon, used to group things on the owner screens.
class Block extends StatelessWidget {
  final String title;
  final String? sub;
  final Widget? action;
  final Widget child;
  const Block({super.key, required this.title, required this.child, this.sub, this.action});

  @override
  Widget build(BuildContext context) => Panel(title: title, sub: sub, action: action, child: child);
}

/// Opens the profile of a farmer / vehicle / village / broker / labour.
void openParty(PartyRef r) => app.go('party', arg: r);

/// A tappable name chip (opens the profile).
Widget partyChip(PartyRef r, {String? extra}) {
  return InkWell(
    borderRadius: BorderRadius.circular(Pal.rad(99)),
    onTap: () => openParty(r),
    child: Container(
      padding: EdgeInsets.symmetric(horizontal: Pal.tally ? 9 : 12, vertical: Pal.tally ? 3 : 7),
      decoration: BoxDecoration(color: Pal.tally ? Pal.surface : Pal.soft, border: Pal.tally ? Border.all(color: Pal.line) : null, borderRadius: BorderRadius.circular(Pal.rad(99))),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Flexible(child: Text(r.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12.5, w: FontWeight.w700, c: Pal.brand))),
          if (extra != null) ...<Widget>[const SizedBox(width: 6), Text(extra, style: ts(11.5, w: FontWeight.w700, c: Pal.muted))],
        ],
      ),
    ),
  );
}

String tonsOrKg(double kg) => kg.abs() >= 10000 ? tons(kg) : '${grp(kg)} KG';

/// "12.4 T" for big numbers, plain KG for small.
String kgShort(double kg) => kg.abs() >= 1000 ? '${(kg / 1000).toStringAsFixed(1)} T' : '${grp(kg)} KG';

/// What a worker sees when he opens an owner-only screen.
List<Widget> ownerOnlyRows() => <Widget>[EmptyBox(icon: 'lock', title: bi('આ ફક્ત માલિક માટે છે', 'Owner only'))];

/// Colours for charts with several parts (theme aware).
List<Color> chartColors() => <Color>[Pal.brand, Pal.info, Pal.amber, Pal.violet, Pal.ok, Pal.bad, Pal.warn];

/// 4 columns on PC, 2 on phone.
Widget metricGrid(BuildContext context, List<Widget> tiles, {int? pcCols}) {
  final bool pc = DeviceScope.isPc(context);
  return Grid(cols: pc ? (pcCols ?? 4) : 2, gap: 12, children: tiles);
}
