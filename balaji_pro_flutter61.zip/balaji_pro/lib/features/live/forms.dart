import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import '../../core/app_state.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/icons.dart';
import '../../core/palette.dart';
import '../../data/engine.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../data/lists.dart';
import '../../data/owner_docs.dart';
import '../../data/scan.dart';
import '../../data/supa.dart';
import '../../widgets/common.dart';
import '../../widgets/dayfield.dart';
import '../../widgets/keys.dart';
import '../../widgets/page.dart';
import 'field.dart';
import 'kit2.dart';
import 'money_screens.dart' show openPayForm;
import 'trade_screens.dart' show openSaleForm;
import 'ui.dart';
import 'voucher_screens.dart' show openExpForm;

import '../../widgets/accept.dart';
// ----------------------------------------------------------- new entry menu
Future<void> showNewMenu(BuildContext context) {
  return openPanel(
    context,
    title: bi('નવી એન્ટ્રી', 'New entry'),
    width: 420,
    child: Builder(
      builder: (BuildContext ctx) {
        Widget opt(String icon, String tone, String title, String route, {VoidCallback? run}) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Surface(
              padding: const EdgeInsets.all(14),
              onTap: () {
                Navigator.of(ctx).pop();
                if (run != null) {
                  run();
                } else {
                  app.go(route);
                }
              },
              child: Row(
                children: <Widget>[
                  IconChip(icon, tone: tone, size: 46),
                  const SizedBox(width: 14),
                  Expanded(child: Text(title, style: ts(16, w: FontWeight.w800))),
                  Icon(ic('chev'), size: 22, color: Pal.faint),
                ],
              ),
            ),
          );
        }

        return Column(
          children: <Widget>[
            opt('scan', 'violet', bi('સ્લિપ સ્કેન (ફોટો → આપમેળે ભરાય)', 'Scan slip (photo → auto-fill)'), 'scan'),
            opt('receipt', 'teal', bi('ચિઠ્ઠી (ખેતરેથી)', 'Chit (from the field)'), 'chithi_new'),
            opt('scale', 'blue', bi('કાંટા એન્ટ્રી (RST)', 'Weighbridge entry (RST)'), 'kanta_new'),
            opt('bag', 'amber', bi('માલ - લોડિંગ / અનલોડિંગ', 'Maal - loading / unloading'), 'maal_new'),
            // the money entries of the day, in the same place (owner only)
            if (live.isAdmin) ...<Widget>[
              opt('pay', 'green', bi('ખેડૂતને ચૂકવણી', 'Payment to a farmer'), '', run: () => openPayForm(context)),
              opt('wallet', 'rose', bi('ખર્ચ / આવક', 'Expense / income'), '', run: () => openExpForm(context)),
              opt('cart', 'teal', bi('વેચાણ', 'Sale'), '', run: () => openSaleForm(context)),
            ],
          ],
        );
      },
    ),
  );
}

// -------------------------------------------------------------- photo picker
class PhotoPick extends StatelessWidget {
  final String label;
  final String? path;
  final ValueChanged<String?> onChanged;
  final bool mandatory;
  const PhotoPick({super.key, required this.label, required this.path, required this.onChanged, this.mandatory = false});

  Future<void> _pick(ImageSource s) async {
    try {
      final ImageSource src = (Platform.isWindows || Platform.isLinux || Platform.isMacOS) ? ImageSource.gallery : s; // a PC has no camera picker
      final XFile? x = await ImagePicker().pickImage(source: src, imageQuality: 72, maxWidth: 1600, maxHeight: 1600);
      if (x != null) onChanged(x.path);
    } catch (e) {
      app.toast(bi('ફોટો લઈ શકાયો નહીં', 'Could not get the photo'));
    }
  }

  @override
  Widget build(BuildContext context) {
    final String? p = path;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Text('$label${mandatory ? ' *' : ''}', style: ts(12.5, w: FontWeight.w600, c: Pal.muted)),
        const SizedBox(height: 6),
        if (p != null)
          Stack(
            children: <Widget>[
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.file(File(p), height: 170, width: double.infinity, fit: BoxFit.cover),
              ),
              Positioned(
                right: 6,
                top: 6,
                child: IconBtn('close', size: 38, color: Colors.white, bg: const Color(0x99000000), onTap: () => onChanged(null)),
              ),
            ],
          ),
        if (p != null) const SizedBox(height: 8),
        Row(
          children: <Widget>[
            tExp(child: Btn(p == null ? bi('કૅમેરા', 'Camera') : bi('ફરી લો', 'Retake'), icon: 'cam', kind: BtnKind.tonal, tabStop: mandatory, onTap: () => _pick(ImageSource.camera))),
            const SizedBox(width: 10),
            tExp(child: Btn(bi('ગેલેરી', 'Gallery'), icon: 'img', kind: BtnKind.outline, tabStop: mandatory, onTap: () => _pick(ImageSource.gallery))),
          ],
        ),
      ],
    );
  }
}

String _vehicleClean(String v) => v.toUpperCase().replaceAll(RegExp(r'[\s\-]'), '');

Widget _errBox(String t) {
  if (t.isEmpty) return const SizedBox.shrink();
  return Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Icon(ic('err'), size: 18, color: Pal.bad),
        const SizedBox(width: 8),
        Expanded(child: Text(t, style: ts(13, w: FontWeight.w700, c: Pal.bad))),
      ],
    ),
  );
}

Widget _saveBtn(String label, bool busy, VoidCallback onTap) {
  if (busy) {
    return SizedBox(height: 52, child: Center(child: SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 2.6, color: Pal.brand))));
  }
  return Btn(label, icon: 'check', expand: true, onTap: onTap);
}

void _savedToast(SaveResult r, String ok) {
  HapticFeedback.mediumImpact();
  app.toast(r.queued ? bi('ઑફલાઇન સેવ થયું - નેટ આવતા મોકલાશે', 'Saved offline - will upload when online') : ok);
}

/// Banner shown on a form that was pre-filled from a slip scan.
Widget scanNote(ScanPrefill? p) {
  if (p == null || !p.scanned) return const SizedBox.shrink();
  return Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Surface(
      color: Pal.tone('violet').bg,
      shadow: false,
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(ic('scan'), size: 20, color: Pal.tone('violet').fg),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  bi('સ્કેનથી ${p.filled} માહિતી ભરાઈ - સેવ કરતાં પહેલાં ફોટા સાથે મેળવી લો', '${p.filled} fields filled from the scan - check against the photo before saving'),
                  style: ts(13, w: FontWeight.w800, c: Pal.tone('violet').fg),
                ),
              ),
            ],
          ),
          for (final String w in p.warnings.take(4))
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text('• $w', style: ts(12.5, w: FontWeight.w600, c: Pal.tone('violet').fg)),
            ),
        ],
      ),
    ),
  );
}

/// "Scan a slip" shortcut at the top of an empty form.
Widget scanBar(String kind, ScanPrefill? p) {
  if (p != null && p.scanned) return const SizedBox.shrink();
  return Padding(
    padding: EdgeInsets.only(bottom: Pal.tally ? 6 : 12),
    child: Align(
      alignment: Alignment.centerLeft,
      child: Btn(bi('સ્લિપ સ્કેન કરો - ફોટોથી આપમેળે ભરાય', 'Scan a slip - auto-fill from photo'), icon: 'scan', kind: BtnKind.tonal, expand: !Pal.tally, onTap: () => app.go('scan', arg: kind)),
    ),
  );
}

// ================================================================== chithi
class ChithiFormScreen extends StatefulWidget {
  final ScanPrefill? prefill;
  const ChithiFormScreen({super.key, this.prefill});

  @override
  State<ChithiFormScreen> createState() => _ChithiFormState();
}

class _ChithiFormState extends State<ChithiFormScreen> {
  late final VoidCallback _accept = () {
    _save();
  };
  final GlobalKey<KeyScopeState> _ks = GlobalKey<KeyScopeState>();

  final TextEditingController _no = TextEditingController();
  final TextEditingController _broker = TextEditingController();
  final TextEditingController _village = TextEditingController();
  final TextEditingController _vehicle = TextEditingController();
  final TextEditingController _farmer = TextEditingController();
  final TextEditingController _mobile = TextEditingController();
  final TextEditingController _gross = TextEditingController();
  final TextEditingController _bardan = TextEditingController();
  final TextEditingController _kardo = TextEditingController();
  final TextEditingController _bags = TextEditingController();
  String _commodity = '';
  String? _photo;
  bool _busy = false;
  String _err = '';

  @override
  void initState() {
    super.initState();
    AcceptHub.push(_accept);
    _no.text = _nextNo();
    final ScanPrefill? p = widget.prefill;
    if (p != null) _apply(p);
  }

  void _apply(ScanPrefill p) {
    void put(TextEditingController c, String k) {
      final String x = p.v(k).trim();
      if (x.isNotEmpty) c.text = x;
    }

    put(_no, 'no');
    put(_village, 'village');
    put(_vehicle, 'vehicle');
    put(_farmer, 'farmer');
    put(_broker, 'broker');
    final String mob = digitsOf(p.v('mobile'));
    if (mob.length == 10) _mobile.text = mob;
    if (p.v('gross').isNotEmpty) _gross.text = cleanNum(p.v('gross'));
    if (p.v('bardan').isNotEmpty) _bardan.text = cleanNum(p.v('bardan'));
    if (p.v('kardo').isNotEmpty) _kardo.text = cleanNum(p.v('kardo'));
    if (p.bagCount > 0) _bags.text = '${p.bagCount}';
    if (p.v('commodity').isNotEmpty) _commodity = p.v('commodity');
    _photo = p.photo;
  }

  @override
  void dispose() {
    for (final TextEditingController c in <TextEditingController>[_no, _broker, _village, _vehicle, _farmer, _mobile, _gross, _bardan, _kardo, _bags]) {
      c.dispose();
    }
    AcceptHub.pop(_accept);
    super.dispose();
  }

  String _nextNo() {
    for (final Chit c in live.chits) {
      if (c.by != live.uid) continue;
      final int? n = int.tryParse(c.no);
      if (n != null) return '${n + 1}';
    }
    return '';
  }

  double get _net => dbl(_gross.text) - dbl(_bardan.text) - dbl(_kardo.text);

  Chit? _lastChit() {
    for (final Chit c in live.chits) {
      if (c.by == live.uid) return c;
    }
    return live.chits.isEmpty ? null : live.chits.first;
  }

  void _repeat(Chit c) {
    setState(() {
      _vehicle.text = c.vehicle;
      _village.text = c.village;
      _broker.text = c.broker;
      if (c.commodity.isNotEmpty) _commodity = c.commodity;
    });
  }

  String _noHint() {
    final String n = _no.text.trim();
    if (n.isEmpty) return '';
    for (final Chit c in live.chits) {
      if (c.no == n) return bi('આ નંબર પહેલેથી વપરાયો છે: ${vtxt(c.farmer)}', 'Number already used: ${vtxt(c.farmer)}');
    }
    return '';
  }

  List<String> _warnings(String vehicle, double net, double gross, double bardan, double kardo, int bags) {
    final List<String> w = <String>[];
    final String vk = vehicleKey(vehicle);
    if (vk.length >= 6 && !plateOk(vk)) w.add(bi('ગાડી નંબર ($vk) સામાન્ય ફોર્મેટનો નથી', 'Vehicle number ($vk) looks unusual'));
    if (bags > 0) {
      final double per = net / bags;
      if (per < 25 || per > 110) {
        w.add(bi('બેગ દીઠ ${per.toStringAsFixed(1)} KG આવે છે - બેગ કે વજન ચેક કરો', 'That is ${per.toStringAsFixed(1)} KG per bag - check bags or weight'));
      }
    }
    if (gross > 0 && bardan > gross * 0.1) w.add(bi('બારદાન કુલ વજનના 10% થી વધારે છે', 'Bardan is more than 10% of the weight'));
    if (gross > 0 && kardo > gross * 0.1) w.add(bi('કરદો કુલ વજનના 10% થી વધારે છે', 'Kardo is more than 10% of the weight'));
    if (gross > 40000) w.add(bi('એક ચિઠ્ઠીનું વજન ખૂબ વધારે છે (${grp(gross)} KG)', 'A single chit of ${grp(gross)} KG is very large'));
    final String f = nameKey(_farmer.text);
    for (final Chit c in todaysChits()) {
      if (c.vkey == vk && nameKey(c.farmer) == f && (c.gross - gross).abs() < 0.5) {
        w.add(bi('આ જ ખેડૂત, ગાડી અને વજનની ચિઠ્ઠી (#${c.no}) આજે પહેલેથી છે', 'Same farmer, vehicle and weight already saved today (#${c.no})'));
        break;
      }
    }
    return w;
  }

  Future<void> _save() async {
    final String no = _no.text.trim();
    final String village = _village.text.trim();
    final String vehicle = _vehicleClean(_vehicle.text);
    final String farmer = _farmer.text.trim();
    final String mobile = digitsOf(_mobile.text);
    final String broker = _broker.text.trim();
    final double gross = dbl(_gross.text);
    final double bardan = dbl(_bardan.text);
    final double kardo = dbl(_kardo.text);
    final double net = gross - bardan - kardo;
    String e = '';
    if (no.isEmpty || _commodity.isEmpty || village.isEmpty || vehicle.isEmpty || farmer.isEmpty || gross <= 0) {
      e = bi('બધી જરૂરી માહિતી ભરો', 'Fill all required fields');
    } else if (mobile.isNotEmpty && mobile.length != 10) {
      e = bi('મોબાઇલ 10 અંકનો લખો', 'Mobile must be 10 digits');
    } else if (net <= 0) {
      e = bi('ચોખ્ખું વજન 0 કરતાં વધારે હોવું જોઈએ', 'Net weight must be above 0');
    } else if (gross > kMaxLoadKg || bardan > kMaxLoadKg || kardo > kMaxLoadKg) {
      e = bi('વજન ખોટું લાગે છે - એક ગાડીમાં ${grp(kMaxLoadKg, dec: 0)} KG થી વધારે ન હોય. અંકો ફરી તપાસો.', 'That weight cannot be right - a vehicle never carries more than ${grp(kMaxLoadKg, dec: 0)} KG. Check the digits.');
    } else if (dbl(_bags.text) > kMaxBags) {
      e = bi('બેગની સંખ્યા ખોટી લાગે છે (${grp(kMaxBags.toDouble(), dec: 0)} થી વધારે)', 'The bag count looks wrong (above ${grp(kMaxBags.toDouble(), dec: 0)})');
    } else if (_photo == null) {
      e = bi('ચિઠ્ઠીનો ફોટો ફરજિયાત છે', 'Chit photo is required');
    }
    if (e.isNotEmpty) {
      setState(() => _err = e);
      return;
    }
    final int bags = dbl(_bags.text).round();
    final List<String> warn = _warnings(vehicle, net, gross, bardan, kardo, bags);
    if (warn.isNotEmpty) {
      final bool go = await confirmBox(context, title: bi('એક વાર ફરી તપાસો', 'Please check once more'), text: warn.map((String x) => '• $x').join('\n'), yes: bi('છતાં સેવ કરો', 'Save anyway'));
      if (!go || !mounted) return;
    }
    final Map<String, dynamic> row = <String, dynamic>{
      'chiththi_number': no,
      'commodity_type': _commodity,
      'broker_name': broker.isEmpty ? null : broker,
      'village_name': village,
      'vehicle_number': vehicle,
      'farmer_name': farmer,
      'farmer_mobile': mobile.isEmpty ? null : mobile,
      'gross_weight_kg': gross,
      'bardan_kg': bardan,
      'kardo_kg': kardo,
      'weight_kg': net,
    };
    if (bags > 0) row['bag_count'] = bags;
    setState(() {
      _busy = true;
      _err = '';
    });
    final SaveResult r = await live.submit('chit', row, photoPath: _photo);
    if (!mounted) return;
    if (!r.ok) {
      setState(() {
        _busy = false;
        _err = r.error.contains('23505') || r.error.toLowerCase().contains('duplicate')
            ? bi('આ નંબરની ચિઠ્ઠી પહેલેથી સેવ છે. નંબર ચેક કરો.', 'A chit with this number already exists.')
            : r.error;
      });
      return;
    }
    _savedToast(r, '${bi('ચિઠ્ઠી સેવ થઈ', 'Chit saved')} · ${grp(net, dec: 2)} KG');
    if (widget.prefill != null) {
      app.back();
      return;
    }
    final int? n = int.tryParse(no);
    setState(() {
      _busy = false;
      _no.text = n == null ? '' : '${n + 1}';
      _farmer.clear();
      _mobile.clear();
      _gross.clear();
      _bardan.clear();
      _kardo.clear();
      _bags.clear();
      _photo = null;
    });
    _ks.currentState?.refocus();
  }

  Widget _repeatBar() {
    final Chit? last = _lastChit();
    if (last == null || widget.prefill != null || last.vehicle.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: EdgeInsets.only(bottom: Pal.tally ? 8 : 12),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Btn('${bi('છેલ્લી જેવી', 'Same as last')}: ${last.vehicle} · ${last.village}', icon: 'hist', kind: BtnKind.outline, expand: !Pal.tally, onTap: () => _repeat(last)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final List<String> brokers = <String>[...recentValues(live.chits.map((Chit c) => c.broker)), ...kBrokers];
    final List<String> villages = <String>[...recentValues(live.chits.map((Chit c) => c.village)), ...kVillages];
    final List<String> vehicles = <String>[...recentValues(live.chits.map((Chit c) => c.vehicle)), ...kVehicles];
    final List<String> farmers = recentValues(live.chits.map((Chit c) => c.farmer));

    final Widget left = Panel(
      title: bi('ચિઠ્ઠી અને ખેડૂત', 'Chit and farmer'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          FieldX(label: '${bi('ચિઠ્ઠી નંબર', 'Chit number')} *', controller: _no, keyboard: TextInputType.text, onChanged: (String v) => setState(() {})),
          if (_noHint().isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text(_noHint(), style: ts(12.5, w: FontWeight.w700, c: Pal.bad))),
          const SizedBox(height: 14),
          LineRow(label: '${bi('માલ', 'Material')} *', child: ChipRow(
            labels: <String>[for (final List<String> x in kCommodities) bi(x[1], x[2])],
            index: kCommodities.indexWhere((List<String> x) => x[0] == _commodity),
            onChanged: (int i) => setState(() => _commodity = kCommodities[i][0]),
          )),
          const SizedBox(height: 14),
          SuggestField(label: '${bi('ગાડી નંબર', 'Vehicle number')} *', controller: _vehicle, options: vehicles, onChanged: (String v) => setState(() {}), onPick: (String v) => setState(() {})),
          const SizedBox(height: 10),
          VehicleLoadCard(_vehicle.text),
          const SizedBox(height: 4),
          SuggestField(label: '${bi('ખેડૂતનું નામ', 'Farmer name')} *', controller: _farmer, options: farmers, onPick: (String v) {
            for (final Chit c in live.chits) {
              if (c.farmer.toLowerCase() == v.toLowerCase()) {
                if (_mobile.text.trim().isEmpty && c.mobile.isNotEmpty) _mobile.text = c.mobile;
                if (_village.text.trim().isEmpty && c.village.isNotEmpty) _village.text = c.village;
                if (_broker.text.trim().isEmpty && c.broker.isNotEmpty) _broker.text = c.broker;
                break;
              }
            }
          }),
          const SizedBox(height: 14),
          FieldX(label: bi('ખેડૂતનો મોબાઇલ (ઇચ્છા મુજબ)', 'Farmer mobile (optional)'), controller: _mobile, keyboard: TextInputType.phone),
          const SizedBox(height: 14),
          SuggestField(label: '${bi('ગામ', 'Village')} *', controller: _village, options: villages),
          const SizedBox(height: 14),
          SuggestField(label: bi('દલાલ', 'Broker'), controller: _broker, options: brokers),
        ],
      ),
    );

    final Widget right = Panel(
      title: bi('વજન અને ફોટો', 'Weight and photo'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          FieldX(
            label: '${bi('ખેડૂતનું કુલ વજન', 'Gross weight')} *',
            controller: _gross,
            big: true,
            suffix: 'KG',
            keyboard: const TextInputType.numberWithOptions(decimal: true),
            onChanged: (String v) => setState(() {}),
          ),
          const SizedBox(height: 14),
          Row(
            children: <Widget>[
              Expanded(
                child: FieldX(
                  label: bi('બારદાન', 'Bardan'),
                  controller: _bardan,
                  suffix: 'KG',
                  keyboard: const TextInputType.numberWithOptions(decimal: true),
                  onChanged: (String v) => setState(() {}),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FieldX(
                  label: bi('કરદો', 'Kardo'),
                  controller: _kardo,
                  suffix: 'KG',
                  keyboard: const TextInputType.numberWithOptions(decimal: true),
                  onChanged: (String v) => setState(() {}),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          FieldX(label: bi('બેગ (ઇચ્છા મુજબ)', 'Bags (optional)'), controller: _bags, keyboard: TextInputType.number),
          const SizedBox(height: 14),
          Surface(
            color: Pal.soft,
            shadow: false,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            child: Row(
              children: <Widget>[
                Expanded(child: Text(bi('ફાઇનલ (ચોખ્ખું) વજન', 'Final (net) weight'), style: ts(13.5, w: FontWeight.w700, c: Pal.muted))),
                Text('${grp(_net, dec: 2)} KG', style: ts(22, w: FontWeight.w800, c: _net > 0 ? Pal.brand : Pal.bad, tab: true)),
              ],
            ),
          ),
          const SizedBox(height: 14),
          PhotoPick(label: bi('ચિઠ્ઠીનો ફોટો', 'Chit photo'), path: _photo, mandatory: true, onChanged: (String? p) => setState(() => _photo = p)),
          const SizedBox(height: 16),
          _errBox(_err),
          _saveBtn(bi('ચિઠ્ઠી સેવ કરો', 'Save chit'), _busy, _save),
        ],
      ),
    );

    return KeyScope(
      key: _ks,
      child: LiveBody(
      maxWidth: 1100,
      rows: (BuildContext c) => <Widget>[
        ScreenHeader(bi('નવી ચિઠ્ઠી', 'New chit')),
        VoucherHead(type: bi('ચિઠ્ઠી એન્ટ્રી', 'Chit entry'), no: _no.text, date: DateTime.now()),
        statusBanner(),
        scanBar('chit', widget.prefill),
        scanNote(widget.prefill),
        _repeatBar(),
        SplitPane(children: <Widget>[left, right]),
        if (widget.prefill == null) ...<Widget>[
          const SizedBox(height: 16),
          const TodayStrip('chit'),
          recentBlock(c, 'chit'),
        ],
      ],
    ),
    );
  }
}

// =================================================================== kanta
class KantaFormScreen extends StatefulWidget {
  final ScanPrefill? prefill;

  /// Vehicle to start with (from the transit board).
  final String vehicle;
  const KantaFormScreen({super.key, this.prefill, this.vehicle = ''});

  @override
  State<KantaFormScreen> createState() => _KantaFormState();
}

class _KantaFormState extends State<KantaFormScreen> {
  late final VoidCallback _accept = () {
    _save();
  };
  final GlobalKey<KeyScopeState> _ks = GlobalKey<KeyScopeState>();

  final TextEditingController _rst = TextEditingController();
  final TextEditingController _vehicle = TextEditingController();
  final TextEditingController _kg = TextEditingController();
  final TextEditingController _gross = TextEditingController();
  final TextEditingController _tare = TextEditingController();
  bool _gt = false;
  String _autoVehicle = '';
  String? _photo;
  bool _busy = false;
  String _err = '';

  @override
  void initState() {
    super.initState();
    AcceptHub.push(_accept);
    final ScanPrefill? p = widget.prefill;
    if (p != null) {
      if (p.v('rst').isNotEmpty) _rst.text = p.v('rst');
      if (p.v('vehicle').isNotEmpty) _vehicle.text = p.v('vehicle');
      if (p.v('kg').isNotEmpty) _kg.text = cleanNum(p.v('kg'));
      if (p.v('gross').isNotEmpty && p.v('tare').isNotEmpty) {
        _gross.text = cleanNum(p.v('gross'));
        _tare.text = cleanNum(p.v('tare'));
        _gt = true;
      }
      _photo = p.photo;
    }
    if (widget.vehicle.isNotEmpty && _vehicle.text.isEmpty) _vehicle.text = widget.vehicle;
    // weights that came from the weighbridge cable: if exactly one waiting vehicle has this chit weight, it is that vehicle
    if (p != null && p.v('gross').isNotEmpty && _vehicle.text.isEmpty) {
      final List<Trip> likely = _likelyTrips(dbl(_kg.text));
      if (likely.length == 1) {
        _vehicle.text = likely.first.vehicle;
        _autoVehicle = likely.first.vehicle;
      }
    }
    if (_rst.text.isEmpty) _loadRst();
  }

  /// Vehicles waiting for the weighbridge whose chit weight is within the allowed difference of [net] (closest first).
  List<Trip> _likelyTrips(double net) {
    final List<Trip> out = <Trip>[];
    if (net <= 0) return out;
    for (final Trip t in pendingTrips()) {
      if (t.chitKg > 0 && (net - t.chitKg).abs() <= t.tol) out.add(t);
    }
    out.sort((Trip a, Trip b) => (net - a.chitKg).abs().compareTo((net - b.chitKg).abs()));
    return out;
  }

  @override
  void dispose() {
    _rst.dispose();
    _vehicle.dispose();
    _kg.dispose();
    _gross.dispose();
    _tare.dispose();
    AcceptHub.pop(_accept);
    super.dispose();
  }

  Future<void> _loadRst() async {
    final int local = lastNumber(live.kantas.map((Kanta k) => k.rst));
    if (local > 0 && mounted && _rst.text.isEmpty) setState(() => _rst.text = '${local + 1}');
    try {
      final List<Map<String, dynamic>> rows = await live.supa.select(
          'waybridge_entries', <String, String>{'select': 'rst_no', 'order': 'created_at.desc', 'rst_no': 'not.is.null'},
          limit: 100);
      int last = 0;
      for (final Map<String, dynamic> r in rows) {
        final int? n = int.tryParse(str(r['rst_no']));
        if (n != null) {
          last = n;
          break;
        }
      }
      if (mounted && (_rst.text.isEmpty || _rst.text == '${local + 1}')) setState(() => _rst.text = '${last + 1}');
    } catch (_) {
      if (mounted && _rst.text.isEmpty) setState(() => _rst.text = '1');
    }
  }

  void _gtChanged() {
    final double g = dbl(_gross.text);
    final double t = dbl(_tare.text);
    if (g > 0 && t > 0 && g > t) _kg.text = plainNum(g - t);
    setState(() {});
  }

  /// Things worth a second look before the entry is saved.
  List<String> _warnings(String rst, String vehicle, double kg) {
    final List<String> w = <String>[];
    final String vk = vehicleKey(vehicle);
    for (final Kanta k in live.kantas) {
      if (k.rst == rst) {
        w.add(bi('RST $rst પહેલેથી સેવ છે (${vtxt(k.vehicle)})', 'RST $rst is already saved (${vtxt(k.vehicle)})'));
        break;
      }
    }
    if (vk.length >= 6 && !plateOk(vk)) w.add(bi('ગાડી નંબર ($vk) સામાન્ય ફોર્મેટનો નથી', 'Vehicle number ($vk) looks unusual'));
    if (kg < 2000) w.add(bi('વજન ફક્ત ${grp(kg, dec: 2)} KG છે - ખાલી ગાડી તો નથી?', 'Only ${grp(kg, dec: 2)} KG - is it an empty vehicle?'));
    if (kg > bigLoadKg() * 1.25) w.add(bi('વજન ખૂબ વધારે છે (${grp(kg, dec: 2)} KG)', 'Weight is very high (${grp(kg, dec: 2)} KG)'));
    final DateTime today = dayOf(DateTime.now());
    for (final Kanta k in live.kantas) {
      if (k.vkey == vk && !k.at.isBefore(today) && (k.kg - kg).abs() < 0.5) {
        w.add(bi('આ ગાડી અને આટલા જ વજનની એન્ટ્રી આજે પહેલેથી છે (RST ${k.rst})', 'Same vehicle and weight already saved today (RST ${k.rst})'));
        break;
      }
    }
    final Trip? t = pendingTripOf(vehicle);
    if (t != null && (kg - t.chitKg).abs() > t.tol) {
      w.add(bi('ચિઠ્ઠી કરતાં ${sk(kg - t.chitKg)} KG નો ફરક છે (માન્ય ± ${grp(t.tol)})', 'Differs from the chits by ${sk(kg - t.chitKg)} KG (allowed ± ${grp(t.tol)})'));
    }
    return w;
  }

  Future<void> _save() async {
    final String rst = _rst.text.trim();
    final String vehicle = _vehicleClean(_vehicle.text);
    final double kg = dbl(_kg.text);
    if (rst.isEmpty || vehicle.isEmpty || kg <= 0) {
      setState(() => _err = bi('RST, ગાડી અને વજન ભરો', 'Fill RST, vehicle and weight'));
      return;
    }
    if (kg > kMaxLoadKg) {
      setState(() => _err = bi('વજન ખોટું લાગે છે - એક ગાડીમાં ${grp(kMaxLoadKg, dec: 0)} KG થી વધારે ન હોય. અંકો ફરી તપાસો.', 'That weight cannot be right - a vehicle never carries more than ${grp(kMaxLoadKg, dec: 0)} KG. Check the digits.'));
      return;
    }
    final List<String> warn = _warnings(rst, vehicle, kg);
    if (warn.isNotEmpty) {
      final bool go = await confirmBox(context, title: bi('એક વાર ફરી તપાસો', 'Please check once more'), text: warn.map((String x) => '• $x').join('\n'), yes: bi('છતાં સેવ કરો', 'Save anyway'));
      if (!go || !mounted) return;
    }
    final Map<String, dynamic> row = <String, dynamic>{
      'rst_no': rst,
      'vehicle_number': vehicle,
      'total_weight_kg': kg,
      'net_weight_kg': kg,
    };
    setState(() {
      _busy = true;
      _err = '';
    });
    final SaveResult r = await live.submit('kanta', row, photoPath: _photo);
    if (!mounted) return;
    if (!r.ok) {
      setState(() {
        _busy = false;
        _err = r.error;
      });
      return;
    }
    _savedToast(r, '${bi('કાંટો સેવ થયો', 'Saved')} · RST $rst · ${grp(kg, dec: 2)} KG');
    if (widget.prefill != null || widget.vehicle.isNotEmpty) {
      app.back();
      return;
    }
    final int? n = int.tryParse(rst);
    setState(() {
      _busy = false;
      _rst.text = n == null ? '' : '${n + 1}';
      _vehicle.clear();
      _kg.clear();
      _gross.clear();
      _tare.clear();
      _photo = null;
    });
    _ks.currentState?.refocus();
  }

  Widget _expected(Trip t, double kg) {
    final bool has = kg > 0;
    final double diff = kg - t.chitKg;
    final double pctv = t.chitKg > 0 ? diff / t.chitKg * 100 : 0;
    final bool okv = diff.abs() <= t.tol;
    final Tone tone = Pal.tone(!has ? 'blue' : (okv ? 'green' : 'rose'));
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Surface(
        shadow: false,
        color: tone.bg,
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text('${bi('ચિઠ્ઠી મુજબ', 'As per chits')}: ${grp(t.chitKg)} KG · ${t.chits.length} ${bi('ચિઠ્ઠી', 'chits')}', style: ts(13.5, w: FontWeight.w800, c: tone.fg)),
            if (t.farmers.isNotEmpty) Text(t.farmers, maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(12.5, c: tone.fg)),
            if (has) ...<Widget>[
              const SizedBox(height: 6),
              Text(
                '${bi('ફરક', 'Difference')}: ${sk(diff)} KG (${pctv.toStringAsFixed(2)}%) · ${okv ? bi('બરાબર', 'OK') : '${bi('માન્ય', 'allowed')} ± ${grp(t.tol)}'}',
                style: ts(14, w: FontWeight.w800, c: tone.fg),
              ),
            ],
          ],
        ),
      ),
    );
  }

  List<Widget> _checks(double kg, String vehicle) {
    final List<Widget> out = <Widget>[];
    final String vk = vehicleKey(vehicle);
    final String rst = _rst.text.trim();
    bool dup = false;
    if (rst.isNotEmpty) {
      for (final Kanta k in live.kantas) {
        if (k.rst == rst) {
          dup = true;
          out.add(checkNote('bad', bi('RST $rst પહેલેથી સેવ છે (${vtxt(k.vehicle)})', 'RST $rst is already saved (${vtxt(k.vehicle)})')));
          break;
        }
      }
      final int? n = int.tryParse(rst);
      final int last = lastNumber(live.kantas.map((Kanta k) => k.rst));
      if (!dup && n != null && last > 0 && n != last + 1) {
        out.add(checkNote('info', bi('છેલ્લો RST $last હતો', 'The last RST was $last')));
      }
    }
    if (vk.length >= 6 && !plateOk(vk)) {
      out.add(checkNote('warn', bi('ગાડી નંબર સામાન્ય ફોર્મેટનો નથી (જેમ કે GJ12AB1234)', 'Vehicle number looks unusual (e.g. GJ12AB1234)')));
    }
    if (vk.isNotEmpty) {
      final DateTime lim = DateTime.now().subtract(const Duration(hours: 10));
      for (final Kanta k in live.kantas) {
        if (k.vkey == vk && k.at.isAfter(lim)) {
          out.add(checkNote('info', bi('આ ગાડી ${sinceTxt(k.at)} પહેલાં કાંટે થઈ ગઈ છે (RST ${k.rst}, ${grp(k.kg)} KG)', 'This vehicle was weighed ${sinceTxt(k.at)} ago (RST ${k.rst}, ${grp(k.kg)} KG)')));
          break;
        }
      }
    }
    final Trip? t = pendingTripOf(vehicle);
    if (t != null) out.add(_expected(t, kg));
    if (kg > 0 && kg < 2000) out.add(checkNote('warn', bi('વજન ઓછું છે - ખાલી ગાડી?', 'Low weight - an empty vehicle?')));
    if (kg > bigLoadKg() * 1.25) out.add(checkNote('warn', bi('વજન ખૂબ વધારે છે', 'Weight is very high')));
    return out;
  }

  @override
  Widget build(BuildContext context) {
    final List<String> vehicles = <String>[...recentValues(live.chits.map((Chit c) => c.vehicle)), ...recentValues(live.kantas.map((Kanta c) => c.vehicle)), ...kVehicles];
    final double kg = dbl(_kg.text);
    final List<String> waiting = <String>[for (final Trip t in pendingTrips().take(8)) t.vehicle];
    return KeyScope(
      key: _ks,
      child: LiveBody(
      maxWidth: 560,
      rows: (BuildContext c) => <Widget>[
        ScreenHeader(bi('નવી કાંટા એન્ટ્રી', 'New weighbridge entry')),
        VoucherHead(type: bi('કાંટા એન્ટ્રી', 'Weighbridge entry'), no: _rst.text, date: DateTime.now()),
        statusBanner(),
        scanBar('kanta', widget.prefill),
        scanNote(widget.prefill),
        if (_autoVehicle.isNotEmpty && _vehicle.text == _autoVehicle) checkNote('info', bi('ગાડી ચિઠ્ઠીના વજન પરથી જાતે ભરી છે (આ વજન જેટલી એક જ ગાડી બાકી છે) - ખોટી હોય તો બદલો.', 'The vehicle was filled in from the chit weight (only one waiting vehicle has about this weight) - change it if wrong.')),
        if (kg > 0 && _vehicle.text.trim().isEmpty && _likelyTrips(kg).length > 1) PickChips(title: bi('આ વજન જેટલી ચિઠ્ઠીવાળી ગાડી (ટચ કરો)', 'Vehicles whose chits weigh about this much (tap)'), values: <String>[for (final Trip t in _likelyTrips(kg).take(6)) t.vehicle], onPick: (String v) => setState(() => _vehicle.text = v)),
        PickChips(title: bi('કાંટો બાકી ગાડી (ટચ કરો)', 'Waiting for the weighbridge (tap)'), values: waiting, onPick: (String v) => setState(() => _vehicle.text = v)),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              FieldX(label: 'RST *', controller: _rst, keyboard: TextInputType.number, onChanged: (String v) => setState(() {})),
              const SizedBox(height: 14),
              SuggestField(label: '${bi('ગાડી નંબર', 'Vehicle number')} *', controller: _vehicle, options: vehicles, onChanged: (String v) => setState(() {}), onPick: (String v) => setState(() {})),
              const SizedBox(height: 14),
              FieldX(
                label: '${bi('ચોખ્ખું વજન', 'Net weight')} *',
                controller: _kg,
                big: true,
                suffix: 'KG',
                keyboard: const TextInputType.numberWithOptions(decimal: true),
                onChanged: (String v) => setState(() {}),
              ),
              const SizedBox(height: 8),
              Align(
                alignment: Alignment.centerLeft,
                child: Btn(_gt ? bi('ગ્રોસ − ટેર છુપાવો', 'Hide gross − tare') : bi('ગ્રોસ − ટેર થી ગણો', 'Work out from gross − tare'), icon: 'calc', kind: BtnKind.ghost, dense: true, tabStop: false, onTap: () => setState(() => _gt = !_gt)),
              ),
              if (_gt) ...<Widget>[
                const SizedBox(height: 6),
                Row(
                  children: <Widget>[
                    Expanded(child: FieldX(label: bi('ગ્રોસ (ભરેલી)', 'Gross (loaded)'), controller: _gross, suffix: 'KG', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => _gtChanged())),
                    const SizedBox(width: 10),
                    Expanded(child: FieldX(label: bi('ટેર (ખાલી)', 'Tare (empty)'), controller: _tare, suffix: 'KG', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => _gtChanged())),
                  ],
                ),
              ],
              const SizedBox(height: 12),
              ..._checks(kg, _vehicle.text),
              PhotoPick(label: bi('સ્લિપનો ફોટો', 'Slip photo'), path: _photo, onChanged: (String? p) => setState(() => _photo = p)),
              const SizedBox(height: 16),
              _errBox(_err),
              _saveBtn(bi('સેવ કરો', 'Save'), _busy, _save),
            ],
          ),
        ),
        if (widget.prefill == null && widget.vehicle.isEmpty) ...<Widget>[
          const SizedBox(height: 16),
          const TodayStrip('kanta'),
          recentBlock(c, 'kanta'),
        ],
      ],
    ),
    );
  }
}

// ==================================================================== maal
class MaalFormScreen extends StatefulWidget {
  final ScanPrefill? prefill;
  const MaalFormScreen({super.key, this.prefill});

  @override
  State<MaalFormScreen> createState() => _MaalFormState();
}

class _MaalFormState extends State<MaalFormScreen> {
  late final VoidCallback _accept = () {
    _save();
  };
  final GlobalKey<KeyScopeState> _ks = GlobalKey<KeyScopeState>();

  final TextEditingController _vehicle = TextEditingController();
  final TextEditingController _bags = TextEditingController();
  final TextEditingController _owner = TextEditingController();
  final TextEditingController _godown = TextEditingController();
  int _type = 0; // 0 unloading, 1 loading
  String _material = '';
  String _dana = ''; // '' = not told
  DateTime _date = DateTime.now();
  String? _photo;
  bool _busy = false;
  bool _fromLast = false;
  String _err = '';

  @override
  void initState() {
    super.initState();
    AcceptHub.push(_accept);
    final ScanPrefill? p = widget.prefill;
    if (p != null) {
      if (p.v('type') == 'loading') _type = 1;
      if (p.v('vehicle').isNotEmpty) _vehicle.text = p.v('vehicle');
      if (p.v('bags').isNotEmpty) _bags.text = cleanNum(p.v('bags'));
      if (p.v('material').isNotEmpty) _material = p.v('material');
      if (p.v('dana').isNotEmpty) _dana = p.v('dana');
      if (p.v('owner').isNotEmpty) _owner.text = p.v('owner');
      final DateTime? d = DateTime.tryParse(p.v('date'));
      if (d != null && d.isBefore(DateTime.now().add(const Duration(days: 1))) && d.year >= 2024) _date = d;
      _photo = p.photo;
    } else {
      final MaalRow? last = _lastMaal();
      if (last != null) {
        _type = last.loading ? 1 : 0;
        _material = last.material;
        _dana = last.dana;
        _owner.text = last.owner;
        _godown.text = last.godown;
        _fromLast = true;
      }
    }
  }

  MaalRow? _lastMaal() {
    for (final MaalRow m in live.maals) {
      if (m.by == live.uid) return m;
    }
    return live.maals.isEmpty ? null : live.maals.first;
  }

  @override
  void dispose() {
    _vehicle.dispose();
    _bags.dispose();
    _owner.dispose();
    _godown.dispose();
    AcceptHub.pop(_accept);
    super.dispose();
  }

  Future<void> _pickDate() async {
    final DateTime? d = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2024),
      lastDate: DateTime.now().add(const Duration(days: 1)),
    );
    if (d != null) setState(() => _date = d);
  }

  void _addBags(int n) {
    final int cur = dbl(_bags.text).round();
    final int v = cur + n;
    _bags.text = v <= 0 ? '' : '$v';
    setState(() {});
  }

  List<String> _warnings(String vehicle, int bags) {
    final List<String> w = <String>[];
    final String vk = vehicleKey(vehicle);
    if (vk.length >= 6 && !plateOk(vk)) w.add(bi('ગાડી નંબર ($vk) સામાન્ય ફોર્મેટનો નથી', 'Vehicle number ($vk) looks unusual'));
    if (bags > 800) w.add(bi('$bags બેગ ખૂબ વધારે છે', '$bags bags is a lot'));
    final DateTime today = dayOf(DateTime.now());
    if (dayOf(_date) != today) w.add(bi('તારીખ આજની નથી (${dmy(_date)})', 'The date is not today (${dmy(_date)})'));
    for (final MaalRow m in live.maals) {
      if (m.vkey == vk && m.bags == bags && m.loading == (_type == 1) && dayOf(m.date) == dayOf(_date) && !m.at.isBefore(today)) {
        w.add(bi('આ જ ગાડી અને $bags બેગની એન્ટ્રી આજે પહેલેથી છે', 'Same vehicle and $bags bags already saved today'));
        break;
      }
    }
    return w;
  }

  Future<void> _save() async {
    final String vehicle = _vehicleClean(_vehicle.text);
    final int bags = dbl(_bags.text).round();
    if (vehicle.isEmpty || bags <= 0 || _material.isEmpty) {
      setState(() => _err = bi('ગાડી, માલ અને બેગ ભરો', 'Fill vehicle, material and bags'));
      return;
    }
    if (bags > kMaxBags) {
      setState(() => _err = bi('બેગની સંખ્યા ખોટી લાગે છે (${grp(kMaxBags.toDouble(), dec: 0)} થી વધારે)', 'The bag count looks wrong (above ${grp(kMaxBags.toDouble(), dec: 0)})'));
      return;
    }
    final List<String> warn = _warnings(vehicle, bags);
    if (warn.isNotEmpty) {
      final bool go = await confirmBox(context, title: bi('એક વાર ફરી તપાસો', 'Please check once more'), text: warn.map((String x) => '• $x').join('\n'), yes: bi('છતાં સેવ કરો', 'Save anyway'));
      if (!go || !mounted) return;
    }
    final String owner = _owner.text.trim();
    final String godown = _godown.text.trim();
    final Map<String, dynamic> row = <String, dynamic>{
      'entry_type': _type == 1 ? 'loading' : 'unloading',
      'vehicle_number': vehicle,
      'bags': bags,
      'material_type': _material,
      'entry_date': '${_date.year}-${pad2(_date.month)}-${pad2(_date.day)}',
      'owner_name': owner.isEmpty ? null : owner,
    };
    if (godown.isNotEmpty) row['godown'] = godown;
    if (_dana.isNotEmpty) row['dana'] = _dana;
    setState(() {
      _busy = true;
      _err = '';
    });
    final SaveResult r = await live.submit('maal', row, photoPath: _photo);
    if (!mounted) return;
    if (!r.ok) {
      setState(() {
        _busy = false;
        _err = r.error;
      });
      return;
    }
    _savedToast(r, '${bi('માલ એન્ટ્રી સેવ થઈ', 'Maal entry saved')} · $bags ${bi('બેગ', 'bags')}');
    if (live.danaColumnMissing && _dana.isNotEmpty) {
      app.toast(bi('દાણા સેવ થયા નથી - Supabase માં supabase-maal-dana.sql એક વાર ચલાવો', 'Dana was not saved - run supabase-maal-dana.sql once in Supabase'));
    }
    if (widget.prefill != null) {
      app.back();
      return;
    }
    setState(() {
      _busy = false;
      _vehicle.clear();
      _bags.clear();
      _photo = null;
    });
    _ks.currentState?.refocus();
  }

  Widget _estimate() {
    final int bags = dbl(_bags.text).round();
    if (bags <= 0) return const SizedBox.shrink();
    final double per = avgKgPerBag(_material);
    if (per <= 0) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Text('≈ ${grp(bags * per)} KG  (${per.toStringAsFixed(1)} KG / ${bi('બેગ', 'bag')})', style: ts(13, w: FontWeight.w700, c: Pal.muted)),
    );
  }

  List<Widget> _checks() {
    final List<Widget> out = <Widget>[];
    final String vk = vehicleKey(_vehicle.text);
    if (vk.length >= 6 && !plateOk(vk)) {
      out.add(checkNote('warn', bi('ગાડી નંબર સામાન્ય ફોર્મેટનો નથી (જેમ કે GJ12AB1234)', 'Vehicle number looks unusual (e.g. GJ12AB1234)')));
    }
    if (vk.isNotEmpty) {
      final DateTime today = dayOf(DateTime.now());
      int inB = 0;
      int outB = 0;
      for (final MaalRow m in live.maals) {
        if (m.vkey != vk || m.at.isBefore(today)) continue;
        if (m.loading) {
          outB += m.bags;
        } else {
          inB += m.bags;
        }
      }
      if (inB + outB > 0) {
        out.add(checkNote('info', bi('આ ગાડીની આજે: આવ્યા $inB બેગ · ગયા $outB બેગ', 'This vehicle today: in $inB bags · out $outB bags')));
      }
    }
    return out;
  }

  @override
  Widget build(BuildContext context) {
    final List<String> vehicles = <String>[...recentValues(live.maals.map((MaalRow c) => c.vehicle)), ...recentValues(live.chits.map((Chit c) => c.vehicle)), ...kVehicles];
    final List<String> owners = recentValues(live.maals.map((MaalRow c) => c.owner));
    final List<String> recentVeh = recentValues(live.maals.map((MaalRow c) => c.vehicle), max: 6);
    return KeyScope(
      key: _ks,
      child: LiveBody(
      maxWidth: 560,
      rows: (BuildContext c) => <Widget>[
        ScreenHeader(bi('નવી માલ એન્ટ્રી', 'New maal entry')),
        VoucherHead(type: bi('માલ એન્ટ્રી', 'Maal entry'), date: _date),
        statusBanner(),
        scanBar('maal', widget.prefill),
        scanNote(widget.prefill),
        if (_fromLast) checkNote('info', bi('માલ, માલિક અને ગોડાઉન છેલ્લી એન્ટ્રી મુજબ ભર્યા છે - જરૂર હોય તો બદલો', 'Material, owner and godown are copied from the last entry - change if needed')),
        PickChips(title: bi('હમણાંની ગાડી (ટચ કરો)', 'Recent vehicles (tap)'), values: recentVeh, onPick: (String v) => setState(() => _vehicle.text = v)),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Seg(
                labels: <String>[bi('અનલોડિંગ (આવ્યો)', 'Unloading (in)'), bi('લોડિંગ (ગયો)', 'Loading (out)')],
                icons: const <String>['dl', 'ul'],
                index: _type,
                onChanged: (int i) => setState(() => _type = i),
              ),
              const SizedBox(height: 14),
              SuggestField(label: '${bi('ગાડી નંબર', 'Vehicle number')} *', controller: _vehicle, options: vehicles, onChanged: (String v) => setState(() {}), onPick: (String v) => setState(() {})),
              const SizedBox(height: 14),
              LineRow(label: '${bi('માલ', 'Material')} *', child: ChipRow(
                labels: <String>[for (final List<String> x in kCommodities) bi(x[1], x[2])],
                index: kCommodities.indexWhere((List<String> x) => x[0] == _material),
                onChanged: (int i) => setState(() => _material = kCommodities[i][0]),
              )),
              const SizedBox(height: 14),
              LineRow(label: bi('દાણા (Dana)', 'Dana (size)'), child: ChipRow(
                labels: <String>[bi('નક્કી નથી', 'Not told'), for (final List<String> d in kDana) bi(d[1], d[2])],
                index: _dana.isEmpty ? 0 : (kDana.indexWhere((List<String> d) => d[0] == _dana) + 1).clamp(0, kDana.length),
                onChanged: (int i) => setState(() => _dana = i == 0 ? '' : kDana[i - 1][0]),
              )),
              const SizedBox(height: 14),
              FieldX(label: '${bi('બેગ', 'Bags')} *', controller: _bags, big: true, keyboard: TextInputType.number, onChanged: (String v) => setState(() {})),
              const SizedBox(height: 8),
              Row(
                children: <Widget>[
                  tExp(child: Btn('+10', tabStop: false, kind: BtnKind.tonal, dense: true, onTap: () => _addBags(10))),
                  const SizedBox(width: 6),
                  tExp(child: Btn('+25', tabStop: false, kind: BtnKind.tonal, dense: true, onTap: () => _addBags(25))),
                  const SizedBox(width: 6),
                  tExp(child: Btn('+50', tabStop: false, kind: BtnKind.tonal, dense: true, onTap: () => _addBags(50))),
                  const SizedBox(width: 6),
                  tExp(child: Btn('+100', tabStop: false, kind: BtnKind.tonal, dense: true, onTap: () => _addBags(100))),
                  const SizedBox(width: 6),
                  tExp(child: Btn('−10', tabStop: false, kind: BtnKind.outline, dense: true, onTap: () => _addBags(-10))),
                ],
              ),
              _estimate(),
              const SizedBox(height: 14),
              DayField(label: bi('તારીખ', 'Date'), value: _date, first: DateTime(2024), last: dateOnly(DateTime.now()).add(const Duration(days: 1)), onChanged: (DateTime d) => setState(() => _date = d)),
              const SizedBox(height: 14),
              SuggestField(label: bi('માલિક / પાર્ટી', 'Owner / party'), controller: _owner, options: owners),
              const SizedBox(height: 14),
              FieldX(label: bi('ગોડાઉન (ઇચ્છા મુજબ)', 'Godown (optional)'), controller: _godown),
              const SizedBox(height: 14),
              ..._checks(),
              PhotoPick(label: bi('સ્લિપનો ફોટો', 'Slip photo'), path: _photo, onChanged: (String? p) => setState(() => _photo = p)),
              const SizedBox(height: 16),
              _errBox(_err),
              _saveBtn(bi('સેવ કરો', 'Save'), _busy, _save),
            ],
          ),
        ),
        if (widget.prefill == null) ...<Widget>[
          const SizedBox(height: 16),
          const TodayStrip('maal'),
          recentBlock(c, 'maal'),
        ],
      ],
    ),
    );
  }
}
