import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/errlog.dart';
import '../../core/flags.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/books.dart';
import '../../data/gst.dart';
import '../../data/insights.dart';
import '../../data/lists.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../data/money.dart';
import '../../data/owner_docs.dart';
import '../../data/trade.dart';
import '../../data/vno.dart';
import '../../data/vouchers.dart';
import '../../widgets/printer.dart';
import '../../widgets/common.dart';
import '../../widgets/keys.dart';
import '../../widgets/dayfield.dart';
import '../../widgets/launch.dart';
import '../../widgets/page.dart';
import 'field.dart';
import 'gst_screens.dart';
import 'kit.dart';
import 'kit2.dart';
import 'money_screens.dart';
import 'ui.dart';
import 'voucher_screens.dart';

import '../../widgets/accept.dart';
import 'tally_data.dart' show TallyRows, TallyWhat, tallyRows, tallyStrip;
// ======================================================================
// Sales and buyer ledger
// ======================================================================

double _n(TextEditingController c) => dbl(c.text.replaceAll(',', ''));

String _kindLabel(String k) => k == 'sale' ? bi('વેચાણ', 'Sale') : (k == 'recv' ? bi('રકમ મળી', 'Received') : bi('જૂનું બાકી', 'Old balance'));

String _itemLabel(SaleItem s) => s.src == 'raw' ? matLabel(s.item) : s.item;

/// "S-12 · " in front of a line of the sales list
String _vno(SaleItem s) => s.no > 0 ? '${vTypeOf(saleCode(s.kind, jt: s.jt)).letter}-${s.no} · ' : '';

String saleText(SaleItem s) {
  final StringBuffer b = StringBuffer();
  b.writeln('Balaji Industries');
  if (s.isSale) {
    b.writeln('${bi('વેચાણ બિલ', 'Sale bill')}${s.bill.isEmpty ? '' : ' #${s.bill}'}');
    b.writeln('${bi('તારીખ', 'Date')}: ${dmy(s.date)}');
    b.writeln('${bi('ખરીદનાર', 'Buyer')}: ${s.buyer}');
    b.writeln('${bi('માલ', 'Item')}: ${_itemLabel(s)}');
    if (s.kg > 0) b.writeln('${bi('વજન', 'Weight')}: ${grp(s.kg, dec: 2)} KG${s.bags > 0 ? ' · ${s.bags} ${bi('બેગ', 'bags')}' : ''}');
    if (s.rate > 0) b.writeln('${bi('ભાવ', 'Rate')}: ₹${plainNum(s.rate)} / 20 KG');
    if (s.vehicle.isNotEmpty) b.writeln('${bi('ગાડી', 'Vehicle')}: ${s.vehicle}');
    b.writeln('${bi('રકમ', 'Amount')}: ${inr(s.amt, dec: 2)}');
  } else {
    b.writeln('${_kindLabel(s.kind)} - ${dmy(s.date)}');
    b.writeln('${bi('ખરીદનાર', 'Buyer')}: ${s.buyer}');
    b.writeln('${bi('રકમ', 'Amount')}: ${inr(s.amt, dec: 2)}');
  }
  return b.toString().trim();
}

String _balWord(double v) => v > 0.5 ? bi('લેવાના', 'to get') : (v < -0.5 ? bi('એડવાન્સ', 'advance') : bi('ચૂકતે', 'clear'));

Color _balColor(double v) => v > 0.5 ? Pal.warn : (v < -0.5 ? Pal.info : Pal.ok);

// ---------------------------------------------------------------- the form
/// [edit] opens an existing voucher for alteration (Alt+D deletes it); [copy] starts a new voucher from an old one.
Future<void> openSaleForm(BuildContext context, {String kind = 'sale', String buyer = '', SaleItem? edit, SaleItem? copy}) {
  return openPanel(
    context,
    title: edit != null ? bi('વાઉચર સુધારો (Alter)', 'Voucher alteration') : (kind == 'recv' ? bi('રસીદ વાઉચર', 'Receipt Voucher') : (kind == 'open' ? bi('જર્નલ વાઉચર · ખરીદનાર જૂનું બાકી', 'Journal Voucher · Buyer Opening Balance') : bi('વેચાણ વાઉચર', 'Sales Voucher'))),
    sub: edit == null ? null : dmy(edit.date),
    width: 480,
    page: true,
    child: SaleForm(kind: kind, buyer: buyer, edit: edit, copy: copy),
  );
}

class SaleForm extends StatefulWidget {
  final String kind;
  final String buyer;
  final SaleItem? edit;
  final SaleItem? copy;
  const SaleForm({super.key, this.kind = 'sale', this.buyer = '', this.edit, this.copy});

  @override
  State<SaleForm> createState() => _SaleFormState();
}

class _SaleFormState extends State<SaleForm> {
  late final VoidCallback _accept = () {
    _save();
  };

  late final VoidCallback _del = () {
    _delete();
  };
  late final VoidCallback _prn = () {
    _print();
  };

  static const List<String> _kinds = <String>['sale', 'recv', 'open'];
  final TextEditingController _ref = TextEditingController();
  final TextEditingController _buyer = TextEditingController();
  final TextEditingController _grade = TextEditingController();
  final TextEditingController _kg = TextEditingController();
  final TextEditingController _bags = TextEditingController();
  final TextEditingController _rate = TextEditingController();
  final TextEditingController _amt = TextEditingController();
  final TextEditingController _veh = TextEditingController();
  final TextEditingController _bill = TextEditingController();
  final TextEditingController _note = TextEditingController();
  late String _kind = widget.edit?.kind ?? widget.copy?.kind ?? widget.kind;
  String _src = 'out';
  String _raw = '';
  String _mode = 'cash';
  DateTime _day = dateOnly(DateTime.now());
  bool _manual = false;
  bool _busy = false;
  String _err = '';

  @override
  void initState() {
    super.initState();
    AcceptHub.push(_accept);
    _buyer.text = widget.buyer;
    _src = procBatches().isEmpty ? 'raw' : 'out';
    final SaleItem? src = widget.edit ?? widget.copy;
    if (src != null) {
      _buyer.text = src.buyer;
      _amt.text = src.amt == 0 ? '' : plainNum(src.amt);
      _mode = src.mode;
      _note.text = src.note;
      if (src.kind == 'sale') {
        _src = src.src.isEmpty ? _src : src.src;
        if (_src == 'raw') {
          _raw = src.item;
        } else {
          _grade.text = src.item;
        }
        _kg.text = src.kg == 0 ? '' : plainNum(src.kg);
        _bags.text = src.bags == 0 ? '' : '${src.bags}';
        _rate.text = src.rate == 0 ? '' : plainNum(src.rate);
        _veh.text = src.vehicle;
        _manual = src.rate == 0 || (src.kg / 20 * src.rate - src.amt).abs() > 0.5;
      }
      if (widget.edit != null) {
        _day = src.date;
        _ref.text = src.ref;
        _bill.text = src.bill;
      }
    }
    if (widget.edit != null) {
      deleteHub.push(_del);
      printHub.push(_prn);
      ensureVoucherNumbers();
    }
  }

  @override
  void dispose() {
    for (final TextEditingController c in <TextEditingController>[_buyer, _grade, _kg, _bags, _rate, _amt, _veh, _bill, _note, _ref]) {
      c.dispose();
    }
    AcceptHub.pop(_accept);
    deleteHub.pop(_del);
    printHub.pop(_prn);
    super.dispose();
  }

  Future<void> _delete() async {
    final SaleItem? e = widget.edit;
    if (e == null || _busy) return;
    final bool go = await confirmBox(context, title: bi('આ વાઉચર કાઢી નાખવું?', 'Delete this voucher?'), text: bi('આ નોંધ કાયમ માટે કાઢી નંખાશે અને ખાતા અને સ્ટોક બદલાશે.', 'The entry is removed for good and the ledger and stock change.'), yes: bi('હા, કાઢો', 'Yes, delete'), no: bi('ના', 'No'));
    if (!go || !mounted) return;
    await removeSale(e.id);
    app.toast(bi('વાઉચર કાઢ્યું', 'Voucher deleted'));
    if (mounted) Navigator.of(context).pop();
  }

  Future<void> _print() async {
    final SaleItem? e = widget.edit;
    if (e == null) return;
    final Vch? v = voucherById('sale', e.id);
    if (v == null) return;
    final bool ok = await printHtml(voucherHtml(v, curBal: _curBalText()), 'voucher-${e.id}');
    if (!ok) app.toast(bi('પ્રિન્ટ પેજ ખૂલ્યું નહીં', 'Could not open the print page'));
  }

  String _curBalText() {
    final String k0 = nameKey(_buyer.text.trim());
    if (k0.isEmpty) return '';
    for (final BuyerAcct a in buyerAccts().values) {
      if (nameKey(a.label) == k0) return '${tAmt(a.balance.abs())} ${a.balance >= 0 ? 'Dr' : 'Cr'}';
    }
    return '';
  }

  void _calc() {
    if (!_manual) {
      final double kg = _n(_kg);
      final double r = _n(_rate);
      _amt.text = (kg > 0 && r > 0) ? plainNum(double.parse((kg / 20 * r).toStringAsFixed(2))) : '';
    }
    setState(() {});
  }

  Future<void> _pick() async {
    final DateTime? d = await pickDay(context, _day, last: dateOnly(DateTime.now()));
    if (d != null && mounted) setState(() => _day = d);
  }

  String get _item => _src == 'raw' ? _raw : _grade.text.trim();

  Future<void> _save() async {
    final String buyer = _buyer.text.trim();
    final double amt = _n(_amt);
    final double kg = _n(_kg);
    String err = '';
    if (buyer.isEmpty) {
      err = bi('ખરીદનારનું નામ લખો', 'Enter the buyer');
    } else if (_kind == 'sale') {
      if (_item.isEmpty) {
        err = bi('કયો માલ વેચ્યો તે પસંદ કરો', 'Choose what was sold');
      } else if (kg <= 0) {
        err = bi('વજન લખો', 'Enter the weight');
      } else if (amt <= 0) {
        err = bi('ભાવ કે રકમ લખો', 'Enter the rate or the amount');
      }
    } else if (_kind == 'recv') {
      if (amt <= 0) err = bi('સાચી રકમ લખો', 'Enter a valid amount');
    } else if (amt == 0) {
      err = bi('સાચી રકમ લખો', 'Enter a valid amount');
    }
    if (err.isNotEmpty) {
      setState(() => _err = err);
      return;
    }
    if (_kind == 'sale') {
      double? left = stockLeftOf(_src == 'raw', _item);
      final SaleItem? oldSale = widget.edit;
      // the sale being altered is already taken out of the stock
      if (left != null && oldSale != null && oldSale.kind == 'sale' && oldSale.src == _src && oldSale.item == _item) left += oldSale.kg;
      if (left != null && kg > left + 0.5) {
        final bool go = await confirmBox(
          context,
          title: bi('સ્ટોક કરતાં વધારે વેચાણ', 'More than the stock'),
          text: bi('સ્ટોકમાં ${grp(left, dec: 0)} KG છે અને તમે ${grp(kg, dec: 0)} KG વેચો છો. છતાં સેવ કરવું?', 'Stock is ${grp(left, dec: 0)} KG but you are selling ${grp(kg, dec: 0)} KG. Save anyway?'),
          yes: bi('હા, સેવ કરો', 'Yes, save'),
          no: bi('ના', 'No'),
        );
        if (!go || !mounted) return;
      }
    }
    if (_kind == 'sale') {
      final double lim = buyerLimit(nameKey(buyer));
      if (lim > 0) {
        double cur = 0;
        for (final BuyerAcct a in buyerAccts().values) {
          if (nameKey(a.label) == nameKey(buyer)) cur = a.balance;
        }
        final SaleItem? oe = widget.edit;
        if (oe != null && oe.kind == 'sale' && oe.key == nameKey(buyer)) cur -= oe.amt;
        if (cur + amt > lim + 0.5) {
          final bool go = await confirmBox(
            context,
            title: bi('ક્રેડિટ લિમિટ પાર', 'Credit limit exceeded'),
            text: bi('લિમિટ ${inr(lim)} છે. આ વેચાણ પછી બાકી ${inr(cur + amt)} થશે. છતાં સેવ કરવું?', 'The limit is ${inr(lim)}. After this sale the balance is ${inr(cur + amt)}. Save anyway?'),
            yes: bi('હા, સેવ કરો', 'Yes, save'),
            no: bi('ના', 'No'),
          );
          if (!go || !mounted) return;
        }
      }
    }
    setState(() {
      _busy = true;
      _err = '';
    });
    final SaleItem? ed = widget.edit;
    if (ed != null) {
      final bool saved = await ErrLog.attempt(
        'Save',
        () => updateSale(
          ed.id,
          buyer: buyer,
          date: _day,
          amt: amt,
          src: _kind == 'sale' ? _src : '',
          item: _kind == 'sale' ? _item : '',
          kg: _kind == 'sale' ? kg : 0,
          bags: _kind == 'sale' ? _n(_bags).round() : 0,
          rate: _kind == 'sale' ? _n(_rate) : 0,
          vehicle: _kind == 'sale' ? _veh.text : '',
          bill: _kind == 'sale' ? _bill.text : '',
          mode: _kind == 'recv' ? _mode : 'cash',
          note: _note.text,
          ref: _kind == 'recv' && _mode != 'cash' ? _ref.text : '',
        ),
      );
      if (!saved) {
        if (mounted) setState(() => _busy = false);
        return;
      }
      app.toast('${bi('વાઉચર સુધાર્યું', 'Voucher altered')} · ${inr(amt.abs())} · $buyer');
      if (mounted) Navigator.of(context).pop();
      return;
    }
    final bool added = await ErrLog.attempt(
      'Save',
      () => addSale(
        buyer: buyer,
        kind: _kind,
        date: _day,
        amt: amt,
        src: _kind == 'sale' ? _src : '',
        item: _kind == 'sale' ? _item : '',
        kg: _kind == 'sale' ? kg : 0,
        bags: _kind == 'sale' ? _n(_bags).round() : 0,
        rate: _kind == 'sale' ? _n(_rate) : 0,
        vehicle: _kind == 'sale' ? _veh.text : '',
        bill: _kind == 'sale' ? _bill.text : '',
        mode: _kind == 'recv' ? _mode : 'cash',
        note: _note.text,
        ref: _kind == 'recv' && _mode != 'cash' ? _ref.text : '',
      ),
    );
    if (!added) {
      if (mounted) setState(() => _busy = false);
      return;
    }
    app.toast('${_kindLabel(_kind)} · ${inr(amt.abs())} · $buyer');
    if (!mounted) return;
    if (Pal.tally && app.stagePc && widget.buyer.isEmpty) {
      // like TallyPrime: the voucher stays open, blank, for the next entry (Esc closes it)
      setState(() {
        _busy = false;
        _manual = false;
        for (final TextEditingController c in <TextEditingController>[_buyer, _grade, _kg, _bags, _rate, _amt, _veh, _bill, _note, _ref]) {
          c.clear();
        }
      });
      KeyScopeState.refocusFrom(context);
      return;
    }
    Navigator.of(context).pop();
  }

  Widget _stockHint() {
    if (_kind != 'sale' || _item.isEmpty) return const SizedBox.shrink();
    final double? left = stockLeftOf(_src == 'raw', _item);
    if (left == null) return const SizedBox.shrink();
    final bool over = _n(_kg) > left + 0.5;
    return Padding(
      padding: const EdgeInsets.only(top: 6),
      child: Text(
        '${bi('સ્ટોકમાં', 'In stock')}: ${grp(left, dec: 0)} KG',
        style: ts(12.5, w: FontWeight.w700, c: over ? Pal.bad : Pal.muted),
      ),
    );
  }

  /// "Cur Bal" under the buyer, like TallyPrime.
  Widget _curBal(List<BuyerAcct> bl) {
    final String k0 = nameKey(_buyer.text.trim());
    if (k0.isEmpty) return const SizedBox.shrink();
    for (final BuyerAcct a in bl) {
      if (nameKey(a.label) != k0) continue;
      return Padding(
        padding: const EdgeInsets.only(top: 6),
        child: Text('${bi('હાલનું બાકી', 'Current balance')}: ${inr(a.balance.abs())} · ${_balWord(a.balance)}', style: ts(12.5, w: FontWeight.w800, c: _balColor(a.balance))),
      );
    }
    return const SizedBox.shrink();
  }

  @override
  Widget build(BuildContext context) {
    final List<BuyerAcct> bl = buyerAccts().values.toList();
    bl.sort((BuyerAcct a, BuyerAcct b) => (b.last ?? DateTime(2000)).compareTo(a.last ?? DateTime(2000)));
    final List<String> vehicles = recentValues(live.kantas.map((Kanta k) => k.vehicle));
    final SaleItem? ed = widget.edit;
    final VType vt = vTypeOf(saleCode(_kind, jt: widget.edit?.jt ?? widget.copy?.jt ?? ''));
    // an altered voucher keeps its type (a sale stays a sale)
    final List<String> kinds = ed == null ? _kinds : <String>[ed.kind];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        VoucherHead(
          type: vt.name,
          no: ed != null ? (ed.no > 0 ? '${vt.letter}-${ed.no}' : '') : '${vt.letter}-${nextVoucherNo(vt.code)}',
          date: _day,
          sub: ed == null ? bi('નવું વાઉચર', 'Creation') : bi('સુધારો (Alteration)', 'Alteration'),
        ),
        if (kinds.length > 1)
          ChipRow(
            labels: <String>[for (final String k in kinds) k == 'sale' ? bi('વેચાણ', 'Sale') : (k == 'recv' ? bi('રકમ મળી', 'Received') : bi('જૂનું બાકી / જર્નલ', 'Old balance / Journal'))],
            index: kinds.indexOf(_kind),
            onChanged: (int i) => setState(() => _kind = kinds[i]),
          ),
        if (kinds.length > 1) const SizedBox(height: 14),
        SuggestField(label: '${bi('ખરીદનાર', 'Buyer')} *', controller: _buyer, options: <String>[for (final BuyerAcct a in bl.take(300)) a.label], onChanged: (String v) => setState(() {}), onPick: (String v) => setState(() {})),
        _curBal(bl),
        const SizedBox(height: 14),
        if (_kind == 'sale') ...<Widget>[
          Seg(
            labels: <String>[bi('તૈયાર માલ (ગ્રેડ)', 'Finished (grade)'), bi('કાચો માલ', 'Raw material')],
            index: _src == 'out' ? 0 : 1,
            onChanged: (int i) => setState(() => _src = i == 0 ? 'out' : 'raw'),
            dense: true,
          ),
          const SizedBox(height: 12),
          if (_src == 'out')
            SuggestField(label: '${bi('ગ્રેડ / માલનું નામ', 'Grade / item')} *', controller: _grade, options: knownGrades(), onChanged: (String v) => setState(() {}), onPick: (String v) => setState(() {}))
          else
            ChipRow(
              labels: <String>[for (final List<String> x in kCommodities) bi(x[1], x[2])],
              index: kCommodities.indexWhere((List<String> x) => x[0] == _raw),
              onChanged: (int i) => setState(() => _raw = kCommodities[i][0]),
            ),
          _stockHint(),
          const SizedBox(height: 14),
          Row(
            children: <Widget>[
              Expanded(flex: 3, child: FieldX(label: '${bi('વજન', 'Weight')} *', controller: _kg, suffix: 'KG', big: true, keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => _calc())),
              const SizedBox(width: 10),
              Expanded(flex: 2, child: FieldX(label: bi('બેગ', 'Bags'), controller: _bags, keyboard: TextInputType.number)),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: <Widget>[
              Expanded(child: FieldX(label: bi('ભાવ', 'Rate'), controller: _rate, prefix: '₹', suffix: '/ 20 KG', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => _calc())),
              const SizedBox(width: 10),
              Expanded(
                child: FieldX(
                  label: '${bi('રકમ', 'Amount')} *',
                  controller: _amt,
                  prefix: '₹',
                  keyboard: const TextInputType.numberWithOptions(decimal: true),
                  onChanged: (String v) {
                    _manual = v.trim().isNotEmpty;
                    setState(() {});
                  },
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: <Widget>[
              Expanded(child: SuggestField(label: bi('ગાડી નંબર', 'Vehicle'), controller: _veh, options: vehicles)),
              const SizedBox(width: 10),
              Expanded(child: FieldX(label: bi('બિલ નંબર', 'Bill no.'), controller: _bill)),
            ],
          ),
        ] else ...<Widget>[
          FieldX(
            label: '${bi('રકમ', 'Amount')} *',
            controller: _amt,
            big: true,
            prefix: '₹',
            keyboard: TextInputType.numberWithOptions(decimal: true, signed: _kind == 'open'),
            onChanged: (String v) => setState(() {}),
          ),
          if (_kind == 'open')
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text(bi('+ = ખરીદનાર પાસેથી લેવાના, - = ખરીદનારને આપવાના', '+ = the buyer owes us, - = we owe the buyer'), style: ts(12, c: Pal.muted)),
            ),
          if (_kind == 'recv') ...<Widget>[
            const SizedBox(height: 12),
            LineRow(label: bi('કેવી રીતે', 'How'), child: ChipRow(
              labels: <String>[for (final List<String> k in kPayModes) bi(k[1], k[2])],
              index: kPayModes.indexWhere((List<String> k) => k[0] == _mode),
              onChanged: (int i) => setState(() => _mode = kPayModes[i][0]),
            )),
            if (_mode != 'cash') ...<Widget>[
              const SizedBox(height: 12),
              FieldX(label: _mode == 'cheque' ? bi('ચેક નંબર', 'Cheque no.') : bi('UTR / રેફ નંબર', 'UTR / Ref no.'), controller: _ref),
            ],
          ],
        ],
        const SizedBox(height: 12),
        DayField(label: bi('તારીખ', 'Date'), value: _day, last: dateOnly(DateTime.now()), onChanged: (DateTime d) => setState(() => _day = d)),
        const SizedBox(height: 14),
        FieldX(label: bi('નોંધ / Narration', 'Narration'), controller: _note),
        const SizedBox(height: 14),
        if (_err.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(_err, style: ts(13, w: FontWeight.w700, c: Pal.bad))),
        _busy
            ? SizedBox(height: 52, child: Center(child: SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 2.6, color: Pal.brand))))
            : Btn(ed == null ? bi('સેવ કરો', 'Save') : bi('સુધારો સેવ કરો', 'Save alteration'), icon: 'check', expand: true, onTap: _save),
        if (ed != null) ...<Widget>[
          const SizedBox(height: 8),
          Row(
            children: <Widget>[
              tExp(child: Btn(bi('પ્રિન્ટ (Ctrl+P)', 'Print (Ctrl+P)'), icon: 'print', kind: BtnKind.tonal, dense: true, tabStop: false, onTap: _print)),
              const SizedBox(width: 8),
              tExp(child: Btn(bi('કાઢો (Alt+D)', 'Delete (Alt+D)'), icon: 'trash', kind: BtnKind.danger, dense: true, tabStop: false, onTap: _delete)),
            ],
          ),
        ],
      ],
    );
  }
}

// ------------------------------------------------------------ one entry
Future<void> openSaleDetail(BuildContext context, SaleItem s) {
  return openPanel(
    context,
    title: s.buyer,
    sub: '${dmy(s.date)} · ${_kindLabel(s.kind)}',
    width: 460,
    page: true,
    child: _SaleDetail(s, host: context),
  );
}

class _SaleDetail extends StatelessWidget {
  final SaleItem s;
  final BuildContext host;
  const _SaleDetail(this.s, {required this.host});

  /// Opens the GST bill form with this sale filled in. The sale is already in the buyer ledger,
  /// so the bill is not added to it again; the bill number is written back to the sale.
  void _gstBill(BuildContext context) {
    final String low = s.item.toLowerCase();
    final bool castor = low.contains('aeranda') || low.contains('castor') || s.item.contains('એરંડા');
    final List<String> pre = kGstPresets[castor ? 4 : 0];
    final GstLine line = GstLine(desc: pre[1], hsn: pre[2], qty: s.kg, unit: pre[5], rate: s.rate, basis: s.rate > 0 ? 'mann' : pre[4], gst: double.tryParse(pre[3]) ?? 5);
    final String id = s.id;
    openGstForm(
      context,
      prefill: GstPrefill(
        party: s.buyer,
        vehicle: s.vehicle,
        lines: <GstLine>[line],
        toKhata: false,
        onSaved: (GstInv inv) {
          saleDoc.commit(() {
            for (final Map<String, dynamic> m in saleDoc.list('items')) {
              if ('${m['id']}' == id) m['bill'] = inv.no;
            }
          });
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final Vch? vch = voucherById('sale', s.id);
    final String vno = vch == null ? '' : vchNoText(vch);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        if (vch != null) VoucherHead(type: vch.vt.name, no: vno, date: s.date, sub: s.buyer),
        InfoRow(bi('પ્રકાર', 'Type'), _kindLabel(s.kind)),
        if (vno.isNotEmpty) InfoRow(bi('વાઉચર નં.', 'Vch No.'), vno),
        if (s.isSale) ...<Widget>[
          InfoRow(bi('માલ', 'Item'), _itemLabel(s)),
          InfoRow(bi('વજન', 'Weight'), '${grp(s.kg, dec: 2)} KG'),
          if (s.bags > 0) InfoRow(bi('બેગ', 'Bags'), '${s.bags}'),
          if (s.rate > 0) InfoRow(bi('ભાવ', 'Rate'), '₹${plainNum(s.rate)} / 20 KG'),
          if (s.vehicle.isNotEmpty) InfoRow(bi('ગાડી', 'Vehicle'), s.vehicle),
          if (s.bill.isNotEmpty) InfoRow(bi('બિલ નંબર', 'Bill no.'), s.bill),
        ],
        if (s.kind == 'recv') InfoRow(bi('રીત', 'How'), payModeLabel(s.mode)),
        if (s.ref.isNotEmpty) InfoRow(s.mode == 'cheque' ? bi('ચેક નંબર', 'Cheque no.') : 'UTR / Ref', s.ref),
        InfoRow(bi('રકમ', 'Amount'), s.kind == 'open' ? signedInr(s.amt) : inr(s.amt, dec: 2), bold: true, color: Pal.brand),
        if (s.note.isNotEmpty) InfoRow(bi('નોંધ', 'Note'), s.note),
        const SizedBox(height: 14),
        if (kGstOn && s.isSale && s.bill.isEmpty) ...<Widget>[
          Btn(bi('GST બિલ બનાવો', 'Make GST bill'), icon: 'receipt', kind: BtnKind.amber, expand: true, onTap: () => _gstBill(context)),
          const SizedBox(height: 8),
        ],
        Btn('WhatsApp', icon: 'chat', kind: BtnKind.tonal, expand: true, onTap: () => whatsappText(saleText(s))),
        const SizedBox(height: 8),
        if (vch != null) VoucherActions(vch, host: host),
      ],
    );
  }
}

// ---------------------------------------------------------- sales screen
class SalesScreen extends StatefulWidget {
  const SalesScreen({super.key});

  @override
  State<SalesScreen> createState() => _SalesState();
}

class _SalesState extends State<SalesScreen> {
  RangeSel _sel = RangeSel(4);
  int _show = 0; // 0 sales, 1 money received and old balances

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[saleDoc, procDoc, prefDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 820,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final Period p = _sel.period;
          final List<SaleItem> inP = saleItems().where((SaleItem s) => p.has(s.date)).toList();
          double sales = 0;
          double kg = 0;
          double recv = 0;
          int bills = 0;
          for (final SaleItem s in inP) {
            if (s.kind == 'sale') {
              sales += s.amt;
              kg += s.kg;
              bills++;
            } else if (s.kind == 'recv') {
              recv += s.amt;
            }
          }
          double due = 0;
          for (final BuyerAcct a in buyerAccts().values) {
            if (a.balance > 0.5) due += a.balance;
          }
          final List<SaleItem> shown = inP.where((SaleItem s) => _show == 0 ? s.kind == 'sale' : s.kind != 'sale').toList();
          return <Widget>[
            ScreenHeader(bi('વેચાણ', 'Sales'), sub: p.label, actions: <Widget>[
              IconBtn('plus', tip: bi('નવું વેચાણ', 'New sale'), onTap: () => openSaleForm(ctx)),
            ]),
            statusBanner(),
            RangeBar(sel: _sel, presets: const <int>[0, 2, 3, 4, 5, 6], onChanged: (RangeSel s) => setState(() => _sel = s)),
            tallyStrip(TallyWhat.sales, from: p.from, to: p.lastDay),
            tallyRows(TallyRows.sales, from: p.from, to: p.lastDay),
            const SizedBox(height: 12),
            HeroCard(
              title: bi('કુલ વેચાણ', 'Total sales'),
              value: inrC(sales),
              unit: '',
              sub: '$bills ${bi('બિલ', 'bills')} · ${kgTxt(kg)}',
              chips: <HeroChip>[
                HeroChip('rupee', '${bi('રકમ મળી', 'Received')} ${inrC(recv)}'),
                HeroChip('users', '${bi('કુલ લેવાના', 'Total to get')} ${inrC(due)}'),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                tExp(child: Btn(bi('નવું વેચાણ', 'New sale'), icon: 'plus', onTap: () => openSaleForm(ctx))),
                const SizedBox(width: 8),
                tExp(child: Btn(bi('રકમ મળી', 'Money received'), icon: 'rupee', kind: BtnKind.amber, onTap: () => openSaleForm(ctx, kind: 'recv'))),
              ],
            ),
            const SizedBox(height: 8),
            Btn(bi('ખરીદનાર ખાતા', 'Buyer ledger'), icon: 'users', kind: BtnKind.tonal, expand: true, onTap: () => app.go('buyer_khata')),
            const SizedBox(height: 12),
            ChipRow(
              labels: <String>[bi('વેચાણ', 'Sales'), bi('રકમ મળી / જૂનું', 'Received / old')],
              index: _show,
              onChanged: (int i) => setState(() => _show = i),
            ),
            const SizedBox(height: 12),
            if (shown.isEmpty) EmptyBox(icon: 'receipt', title: bi('આ સમયમાં કોઈ નોંધ નથી', 'No entries in this period'), sub: bi('ઉપર "નવું વેચાણ" દબાવો', 'Tap "New sale" above')),
            if (Pal.tally && app.stagePc)
              ...voucherTable(ctx, vouchersIn(p).where((Vch v) => v.src == 'sale' && (_show == 0 ? v.kind == 'sale' : v.kind != 'sale')).toList())
            else
              for (final SaleItem s in shown.take(150))
              lineItem(
                icon: s.kind == 'sale' ? 'receipt' : (s.kind == 'recv' ? 'rupee' : 'book'),
                tone: s.kind == 'sale' ? 'teal' : (s.kind == 'recv' ? 'green' : 'slate'),
                title: s.buyer,
                sub: s.isSale
                    ? '${_vno(s)}${dayLabel(s.date)} · ${_itemLabel(s)} · ${kgTxt(s.kg)}${s.rate > 0 ? ' · ₹${plainNum(s.rate)}' : ''}'
                    : '${_vno(s)}${dayLabel(s.date)} · ${_kindLabel(s.kind)}${s.kind == 'recv' ? ' · ${payModeLabel(s.mode)}' : ''}${s.ref.isEmpty ? '' : ' · ${s.ref}'}',
                trailing: s.kind == 'open' ? signedInr(s.amt) : inr(s.amt),
                onTap: () => openSaleDetail(ctx, s),
              ),
          ];
        },
      ),
    );
  }
}

// ---------------------------------------------------------- buyer ledger
class BuyerKhataScreen extends StatefulWidget {
  const BuyerKhataScreen({super.key});

  @override
  State<BuyerKhataScreen> createState() => _BuyerKhataState();
}

class _BuyerKhataState extends State<BuyerKhataScreen> {
  final TextEditingController _q = TextEditingController();
  int _show = 0; // 0 to get, 1 all, 2 advance

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  String _text(List<BuyerAcct> l, double due) {
    final StringBuffer b = StringBuffer();
    b.writeln('Balaji Industries');
    b.writeln('${bi('ખરીદનાર - લેવાના બાકી', 'Buyers - dues')} (${dmy(DateTime.now())})');
    b.writeln('------------------------');
    for (final BuyerAcct a in l.where((BuyerAcct x) => x.balance > 0.5).take(40)) {
      b.writeln('${a.label}: ${inr(a.balance)}');
    }
    b.writeln('------------------------');
    b.writeln('${bi('કુલ લેવાના', 'Total to get')}: ${inr(due)}');
    return b.toString().trim();
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[saleDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 800,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final List<BuyerAcct> all = buyerAccts().values.toList();
          double due = 0;
          double adv = 0;
          double sold = 0;
          double got = 0;
          int nDue = 0;
          for (final BuyerAcct a in all) {
            sold += a.sales;
            got += a.recv;
            if (a.balance > 0.5) {
              due += a.balance;
              nDue++;
            } else if (a.balance < -0.5) {
              adv += -a.balance;
            }
          }
          final String q = _q.text.trim().toLowerCase();
          final List<BuyerAcct> l = all.where((BuyerAcct a) {
            if (q.isNotEmpty && !a.label.toLowerCase().contains(q)) return false;
            if (_show == 0) return a.balance > 0.5;
            if (_show == 2) return a.balance < -0.5;
            return true;
          }).toList();
          l.sort((BuyerAcct a, BuyerAcct b) => b.balance.abs().compareTo(a.balance.abs()));
          return <Widget>[
            ScreenHeader(bi('ખરીદનાર ખાતા', 'Buyer ledger'), actions: <Widget>[
              IconBtn('plus', tip: bi('નવું વેચાણ', 'New sale'), onTap: () => openSaleForm(ctx)),
            ]),
            statusBanner(),
            tallyStrip(TallyWhat.dues),
            HeroCard(
              title: bi('ખરીદનાર પાસેથી કુલ લેવાના', 'Total to get from buyers'),
              value: inrC(due),
              unit: '',
              sub: '$nDue ${bi('ખરીદનારના બાકી', 'buyers owe')}${adv > 0 ? ' · ${bi('એડવાન્સ', 'advance')} ${inrC(adv)}' : ''}',
              chips: <HeroChip>[
                HeroChip('receipt', '${bi('વેચ્યું', 'Sold')} ${inrC(sold)}'),
                HeroChip('rupee', '${bi('મળ્યા', 'Received')} ${inrC(got)}'),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                tExp(child: Btn(bi('નવું વેચાણ', 'New sale'), icon: 'plus', onTap: () => openSaleForm(ctx))),
                const SizedBox(width: 8),
                tExp(child: Btn(bi('યાદી મોકલો', 'Send list'), icon: 'chat', kind: BtnKind.tonal, onTap: () => whatsappText(_text(all, due)))),
              ],
            ),
            const SizedBox(height: 12),
            SearchBox(hint: bi('ખરીદનારનું નામ', 'Buyer name'), controller: _q, onChanged: (String _) => setState(() {})),
            const SizedBox(height: 10),
            ChipRow(
              labels: <String>[bi('લેવાના', 'To get'), bi('બધા', 'All'), bi('એડવાન્સ', 'Advance')],
              index: _show,
              onChanged: (int i) => setState(() => _show = i),
            ),
            const SizedBox(height: 12),
            if (l.isEmpty) EmptyBox(icon: 'users', title: bi('કોઈ ખરીદનાર નથી', 'No buyers here'), sub: all.isEmpty ? bi('પહેલું વેચાણ નાખો', 'Add the first sale') : null),
            for (final BuyerAcct a in l.take(150))
              lineItem(
                icon: 'users',
                tone: a.balance > 0.5 ? 'amber' : (a.balance < -0.5 ? 'blue' : 'green'),
                title: a.label,
                sub: '${bi('વેચ્યું', 'Sold')} ${inrC(a.sales)} · ${bi('મળ્યા', 'Received')} ${inrC(a.recv)}${a.last == null ? '' : ' · ${dayLabel(a.last!)}'}',
                trailing: inr(a.balance.abs()),
                trailingSub: _balWord(a.balance),
                trailingColor: _balColor(a.balance),
                onTap: () => app.go('buyer_party', arg: a.key),
              ),
          ];
        },
      ),
    );
  }
}

class BuyerDetailScreen extends StatelessWidget {
  final String keyId;
  const BuyerDetailScreen(this.keyId, {super.key});

  String _statement(BuyerAcct a, List<SaleItem> asc) {
    final StringBuffer b = StringBuffer();
    b.writeln('Balaji Industries');
    b.writeln('${bi('ખાતું', 'Account')}: ${a.label}');
    b.writeln('------------------------');
    double run = 0;
    for (final SaleItem s in asc) {
      run += s.effect;
      final String what = s.isSale ? '${_itemLabel(s)} ${grp(s.kg, dec: 0)} KG' : _kindLabel(s.kind);
      b.writeln('${dm(s.date)} $what: ${s.kind == 'recv' ? '-' : ''}${inr(s.amt)}  → ${inr(run)}');
    }
    b.writeln('------------------------');
    b.writeln('${bi('બાકી', 'Balance')}: ${inr(a.balance)} (${_balWord(a.balance)})');
    return b.toString().trim();
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[saleDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 760,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final BuyerAcct? a = buyerAccts()[keyId];
          if (a == null) return <Widget>[EmptyBox(icon: 'users', title: bi('ખરીદનાર મળ્યો નથી', 'Buyer not found'))];
          final List<SaleItem> items = saleItems().where((SaleItem s) => s.key == keyId).toList();
          final List<SaleItem> asc = items.reversed.toList();
          final Map<String, double> run = <String, double>{};
          double r = 0;
          for (final SaleItem s in asc) {
            r += s.effect;
            run[s.id] = r;
          }
          return <Widget>[
            ScreenHeader(a.label, sub: bi('ખરીદનારનું ખાતું', 'Buyer account'), actions: <Widget>[
              IconBtn('ledger', tip: bi('ખાતાવહી (Dr/Cr)', 'Ledger (Dr/Cr)'), onTap: () => app.go('my_ledger', arg: LedgerRef('buyer', keyId, a.label))),
            ]),
            statusBanner(),
            HeroCard(
              title: a.balance < -0.5 ? bi('એડવાન્સ (પાછા આપવાના)', 'Advance held') : bi('લેવાના બાકી', 'Balance to get'),
              value: inr(a.balance.abs()),
              unit: '',
              sub: '${_balWord(a.balance)} · ${a.bills} ${bi('બિલ', 'bills')} · ${kgTxt(a.kg)}',
              chips: <HeroChip>[
                HeroChip('receipt', '${bi('વેચ્યું', 'Sold')} ${inrC(a.sales)}'),
                HeroChip('rupee', '${bi('મળ્યા', 'Received')} ${inrC(a.recv)}'),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                tExp(child: Btn(bi('વેચાણ', 'Sale'), icon: 'plus', onTap: () => openSaleForm(ctx, buyer: a.label))),
                const SizedBox(width: 8),
                tExp(child: Btn(bi('રકમ મળી', 'Received'), icon: 'rupee', kind: BtnKind.amber, onTap: () => openSaleForm(ctx, kind: 'recv', buyer: a.label))),
              ],
            ),
            const SizedBox(height: 8),
            const SizedBox(height: 12),
            Panel(
              title: bi('સંપર્ક', 'Contact'),
              child: BuyerPhoneBox(keyId: keyId, message: _statement(a, asc)),
            ),
            const SizedBox(height: 12),
            Panel(
              title: bi('ક્રેડિટ લિમિટ', 'Credit limit'),
              child: BuyerLimitBox(keyId: keyId, balance: a.balance),
            ),
            const SizedBox(height: 14),
            if (Pal.tally && app.stagePc)
              ...ledgerTable(ctx, buildLedger(LedgerRef('buyer', keyId, a.label), Period(DateTime(2000), addDays(dayOf(DateTime.now()), 1))))
            else
              for (final SaleItem s in items)
              lineItem(
                icon: s.kind == 'sale' ? 'receipt' : (s.kind == 'recv' ? 'rupee' : 'book'),
                tone: s.kind == 'sale' ? 'teal' : (s.kind == 'recv' ? 'green' : 'slate'),
                title: s.isSale ? '${_itemLabel(s)} · ${kgTxt(s.kg)}' : _kindLabel(s.kind),
                sub: '${_vno(s)}${dayLabel(s.date)}${s.rate > 0 ? ' · ₹${plainNum(s.rate)}' : ''}${s.bill.isEmpty ? '' : ' · #${s.bill}'}',
                trailing: '${s.kind == 'recv' ? '-' : ''}${inr(s.amt.abs())}',
                trailingSub: '${bi('બાકી', 'bal')} ${inr(run[s.id] ?? 0)}',
                onTap: () => openSaleDetail(ctx, s),
              ),
          ];
        },
      ),
    );
  }
}

// ------------------------------------------------------------ buyer phone
/// Phone number of a buyer with call / WhatsApp buttons. [message] is the text
/// sent on WhatsApp.
class BuyerPhoneBox extends StatefulWidget {
  final String keyId;
  final String message;
  const BuyerPhoneBox({super.key, required this.keyId, this.message = ''});

  @override
  State<BuyerPhoneBox> createState() => _BuyerPhoneBoxState();
}

class _BuyerPhoneBoxState extends State<BuyerPhoneBox> {
  late final VoidCallback _accept = () {
    _save();
  };

  @override
  void initState() {
    super.initState();
    AcceptHub.push(_accept);
  }

  late final TextEditingController _c = TextEditingController(text: buyerPhone(widget.keyId));

  @override
  void dispose() {
    _c.dispose();
    AcceptHub.pop(_accept);
    super.dispose();
  }

  String get _digits => _c.text.replaceAll(RegExp(r'[^0-9]'), '');

  Future<void> _save() async {
    await setBuyerPhone(widget.keyId, _c.text);
    if (mounted) {
      app.toast(bi('નંબર સેવ થયો', 'Number saved'));
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final bool ok = _digits.length >= 10;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[
            Expanded(child: FieldX(label: bi('મોબાઇલ નંબર', 'Mobile number'), controller: _c, keyboard: TextInputType.phone, onChanged: (String v) => setState(() {}))),
            const SizedBox(width: 8),
            Btn(bi('સેવ', 'Save'), icon: 'check', kind: BtnKind.tonal, onTap: _save),
          ],
        ),
        if (ok) ...<Widget>[
          const SizedBox(height: 10),
          Row(
            children: <Widget>[
              tExp(child: Btn(bi('ફોન કરો', 'Call'), icon: 'call', kind: BtnKind.outline, onTap: () => callPhone(_digits))),
              const SizedBox(width: 8),
              tExp(child: Btn('WhatsApp', icon: 'chat', onTap: () => whatsappText(widget.message, phone: _digits))),
            ],
          ),
        ] else if (widget.message.isNotEmpty) ...<Widget>[
          const SizedBox(height: 10),
          Btn(bi('WhatsApp પર મોકલો (નંબર વગર)', 'Send on WhatsApp (pick contact)'), icon: 'chat', kind: BtnKind.outline, expand: true, onTap: () => whatsappText(widget.message)),
        ],
      ],
    );
  }
}

// ------------------------------------------------------------ credit limit
/// The most this buyer may owe. A sale that takes the balance above it asks "Save anyway?".
class BuyerLimitBox extends StatefulWidget {
  final String keyId;
  final double balance;
  const BuyerLimitBox({super.key, required this.keyId, required this.balance});

  @override
  State<BuyerLimitBox> createState() => _BuyerLimitBoxState();
}

class _BuyerLimitBoxState extends State<BuyerLimitBox> {
  late final TextEditingController _c = TextEditingController(text: buyerLimit(widget.keyId) > 0 ? plainNum(buyerLimit(widget.keyId)) : '');

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    await setBuyerLimit(widget.keyId, _n(_c));
    if (mounted) {
      app.toast(_n(_c) > 0 ? bi('લિમિટ સેવ થઈ', 'Limit saved') : bi('લિમિટ કાઢી', 'Limit removed'));
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final double lim = _n(_c);
    final bool over = lim > 0 && widget.balance > lim + 0.5;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[
            Expanded(child: FieldX(label: bi('વધુમાં વધુ બાકી (₹)', 'Most he may owe (Rs)'), controller: _c, prefix: '₹', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {}))),
            const SizedBox(width: 8),
            Btn(bi('સેવ', 'Save'), icon: 'check', kind: BtnKind.tonal, onTap: _save),
          ],
        ),
        const SizedBox(height: 6),
        Text(
          lim <= 0 ? bi('0 = કોઈ લિમિટ નથી', '0 = no limit') : (over ? bi('બાકી ${inr(widget.balance)} - લિમિટ ${inr(lim)} પાર', 'Balance ${inr(widget.balance)} is over the limit ${inr(lim)}') : bi('બાકી ${inr(widget.balance)} / લિમિટ ${inr(lim)}', 'Balance ${inr(widget.balance)} of limit ${inr(lim)}')),
          style: ts(12.5, w: FontWeight.w700, c: over ? Pal.bad : Pal.muted),
        ),
      ],
    );
  }
}
