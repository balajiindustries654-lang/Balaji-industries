import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/errlog.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/contra.dart' show contraDoc;
import '../../data/engine.dart';
import '../../data/insights.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../data/money.dart';
import '../../data/owner_docs.dart';
import '../../data/trade.dart';
import '../../data/vno.dart';
import '../../data/vouchers.dart';
import '../../widgets/printer.dart';
import '../../widgets/common.dart';
import '../../widgets/keys.dart';
import '../../widgets/dayfield.dart';
import '../../widgets/launch.dart';
import '../../widgets/page.dart';
import 'field.dart';
import 'kit.dart';
import 'kit2.dart';
import 'ui.dart';
import 'contra_screens.dart' show openContraForm;
import 'voucher_screens.dart';
import '../../data/books.dart';

import '../../widgets/accept.dart';
import 'tally_data.dart' show TallyRows, TallyWhat, tallyPayBanner, tallyRows, tallyStrip;
// ======================================================================
// Shared helpers for the money screens
// ======================================================================

/// Loads the shared documents once and rebuilds [builder] whenever any of
/// them changes.
class DocsScope extends StatefulWidget {
  final List<SyncDoc> docs;
  final Widget Function(BuildContext) builder;
  const DocsScope({super.key, required this.docs, required this.builder});

  @override
  State<DocsScope> createState() => _DocsScopeState();
}

class _DocsScopeState extends State<DocsScope> {
  // the contra vouchers (cash <-> bank) change the cash and bank figures of every report, so they are always loaded
  late final List<SyncDoc> _docs = <SyncDoc>[...widget.docs, if (!widget.docs.contains(contraDoc)) contraDoc];

  @override
  void initState() {
    super.initState();
    for (final SyncDoc d in _docs) {
      d.addListener(_tick);
      d.ensure();
    }
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    for (final SyncDoc d in _docs) {
      d.removeListener(_tick);
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => widget.builder(context);
}

Future<DateTime?> pickDay(BuildContext context, DateTime init, {DateTime? first, DateTime? last}) {
  final DateTime now = DateTime.now();
  return showDatePicker(
    context: context,
    initialDate: init,
    firstDate: first ?? DateTime(now.year - 3),
    lastDate: last ?? DateTime(now.year, now.month, now.day).add(const Duration(days: 365)),
  );
}

/// A date shown as a button.
Widget dayButton(DateTime d, VoidCallback onTap) => Btn(dmy(d), icon: 'cal', kind: BtnKind.outline, onTap: onTap);

/// Colour of a balance we owe (red), are owed (amber) or that is clear (green).
Color balColor(double v) => v > 0.5 ? Pal.bad : (v < -0.5 ? Pal.warn : Pal.ok);

String balWord(double v) => v > 0.5 ? bi('આપવાના', 'to pay') : (v < -0.5 ? bi('લેવાના', 'to get') : bi('ચૂકતે', 'clear'));

String signedInr(double v) => v < 0 ? '-${inr(v.abs())}' : inr(v);

Widget _dateHead(String text) => Padding(padding: const EdgeInsets.fromLTRB(2, 10, 2, 6), child: Text(text, style: ts(12.5, w: FontWeight.w800, c: Pal.muted, ls: 0.3)));

// ======================================================================
// Payment form
// ======================================================================

/// [edit] opens an existing voucher for alteration (Alt+D deletes it); [copy] starts a new voucher from an old one.
Future<void> openPayForm(BuildContext context, {PartyRef? farmer, String kind = 'pay', PayItem? edit, PayItem? copy}) {
  return openPanel(
    context,
    title: edit == null ? (kind == 'open' ? bi('જર્નલ વાઉચર · ખેડૂત જૂનું બાકી', 'Journal Voucher · Farmer Opening Balance') : bi('ચૂકવણી વાઉચર', 'Payment Voucher')) : bi('વાઉચર સુધારો (Alter)', 'Voucher alteration'),
    sub: edit == null ? null : dmy(edit.date),
    width: 460,
    page: true,
    child: PayForm(farmer: farmer, kind: kind, edit: edit, copy: copy),
  );
}

class PayForm extends StatefulWidget {
  final PartyRef? farmer;
  final String kind;
  final PayItem? edit;
  final PayItem? copy;
  const PayForm({super.key, this.farmer, this.kind = 'pay', this.edit, this.copy});

  @override
  State<PayForm> createState() => _PayFormState();
}

class _PayFormState extends State<PayForm> {
  late final VoidCallback _accept = () {
    _save();
  };

  late final VoidCallback _del = () {
    _delete();
  };
  late final VoidCallback _prn = () {
    _print();
  };

  final TextEditingController _who = TextEditingController();
  final TextEditingController _amt = TextEditingController();
  final TextEditingController _note = TextEditingController();
  final TextEditingController _ref = TextEditingController();
  late String _kind = widget.edit?.kind ?? widget.copy?.kind ?? widget.kind;
  String _mode = 'cash';
  DateTime _day = dateOnly(DateTime.now());
  bool _busy = false;
  String _err = '';

  @override
  void initState() {
    super.initState();
    AcceptHub.push(_accept);
    final PartyRef? f = widget.farmer;
    if (f != null) _who.text = f.label;
    final PayItem? src = widget.edit ?? widget.copy;
    if (src != null) {
      _who.text = src.label;
      _amt.text = plainNum(src.amt);
      _mode = src.mode;
      _note.text = src.note;
      if (widget.edit != null) {
        _day = src.date;
        _ref.text = src.ref;
      }
    }
    if (widget.edit != null) {
      deleteHub.push(_del);
      printHub.push(_prn);
      ensureVoucherNumbers();
    }
  }

  @override
  void dispose() {
    _who.dispose();
    _amt.dispose();
    _note.dispose();
    _ref.dispose();
    AcceptHub.pop(_accept);
    deleteHub.pop(_del);
    printHub.pop(_prn);
    super.dispose();
  }

  Future<void> _delete() async {
    final PayItem? e = widget.edit;
    if (e == null || _busy) return;
    final bool go = await confirmBox(context, title: bi('આ વાઉચર કાઢી નાખવું?', 'Delete this voucher?'), text: bi('આ ચૂકવણીની નોંધ કાયમ માટે કાઢી નંખાશે અને ખાતું બદલાશે.', 'This payment entry will be removed for good and the ledger changes.'), yes: bi('હા, કાઢો', 'Yes, delete'), no: bi('ના', 'No'));
    if (!go || !mounted) return;
    await removePayItem(e.id);
    app.toast(bi('વાઉચર કાઢ્યું', 'Voucher deleted'));
    if (mounted) Navigator.of(context).pop();
  }

  Future<void> _print() async {
    final PayItem? e = widget.edit;
    if (e == null) return;
    final Vch? v = voucherById('pay', e.id);
    if (v == null) return;
    final bool ok = await printHtml(voucherHtml(v, curBal: _curBalText()), 'voucher-${e.id}');
    if (!ok) app.toast(bi('પ્રિન્ટ પેજ ખૂલ્યું નહીં', 'Could not open the print page'));
  }

  String _curBalText() {
    final String k0 = nameKey(_who.text.trim());
    if (k0.isEmpty) return '';
    for (final FarmerAcct a in farmerAccts().values) {
      if (nameKey(a.label) == k0) return '${tAmt(a.balance.abs())} ${a.balance >= 0 ? 'Cr' : 'Dr'}';
    }
    return '';
  }

  Future<void> _save() async {
    final String name = _who.text.trim();
    final double amt = dbl(_amt.text.replaceAll(',', ''));
    if (name.isEmpty) {
      setState(() => _err = bi('ખેડૂતનું નામ લખો', 'Enter the farmer'));
      return;
    }
    if (amt == 0 || (amt < 0 && _kind != 'open')) {
      setState(() => _err = bi('સાચી રકમ લખો', 'Enter a valid amount'));
      return;
    }
    String key = nameKey(name);
    String label = name;
    for (final PartySummary s in directoryOf(Dim.farmer)) {
      if (nameKey(s.ref.label) == key) {
        key = s.ref.key;
        label = s.ref.label;
        break;
      }
    }
    setState(() {
      _busy = true;
      _err = '';
    });
    final PayItem? ed = widget.edit;
    if (ed != null) {
      final bool saved = await ErrLog.attempt('Save', () => updatePayItem(ed.id, key: key, label: label, amt: amt, kind: _kind, mode: _mode, date: _day, note: _note.text, ref: _ref.text));
      if (!saved) {
        if (mounted) setState(() => _busy = false);
        return;
      }
      app.toast('${bi('વાઉચર સુધાર્યું', 'Voucher altered')} · ${inr(amt)} · $label');
      if (mounted) Navigator.of(context).pop();
      return;
    }
    final bool added = await ErrLog.attempt('Save', () => addPayItem(key: key, label: label, amt: amt, kind: _kind, mode: _mode, date: _day, note: _note.text, ref: _ref.text));
    if (!added) {
      if (mounted) setState(() => _busy = false);
      return;
    }
    app.toast('${payKindLabel(_kind)} · ${inr(amt)} · $label');
    if (!mounted) return;
    if (Pal.tally && app.stagePc && widget.farmer == null) {
      // like TallyPrime: the voucher stays open, blank, for the next entry (Esc closes it)
      setState(() {
        _busy = false;
        _who.clear();
        _amt.clear();
        _note.clear();
        _ref.clear();
      });
      KeyScopeState.refocusFrom(context);
      return;
    }
    Navigator.of(context).pop();
  }

  /// "Cur Bal" under the party, like TallyPrime: what we owe the farmer (or he owes us) right now.
  Widget _curBal(List<PartySummary> dir) {
    final String k0 = nameKey(_who.text.trim());
    if (k0.isEmpty) return const SizedBox.shrink();
    for (final PartySummary s in dir) {
      if (nameKey(s.ref.label) != k0) continue;
      final FarmerAcct? a = farmerAccts()[s.ref.key];
      if (a == null) return const SizedBox.shrink();
      return Padding(
        padding: const EdgeInsets.only(top: 6),
        child: Text('${bi('હાલનું બાકી', 'Current balance')}: ${signedInr(a.balance)} · ${balWord(a.balance)}', style: ts(12.5, w: FontWeight.w800, c: balColor(a.balance))),
      );
    }
    return const SizedBox.shrink();
  }

  @override
  Widget build(BuildContext context) {
    final List<PartySummary> dir = directoryOf(Dim.farmer);
    dir.sort((PartySummary a, PartySummary b) => b.last.compareTo(a.last));
    final PayItem? ed = widget.edit;
    // an altered voucher keeps its type: only Payment <-> Advance may be switched
    final List<List<String>> kinds = ed == null
        ? kPayKinds
        : (ed.kind == 'pay' || ed.kind == 'adv' ? kPayKinds.take(2).toList() : kPayKinds.where((List<String> k) => k[0] == ed.kind).toList());
    final VType vt = vTypeOf(payCode(_kind, jt: widget.edit?.jt ?? widget.copy?.jt ?? ''));
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        VoucherHead(
          type: vt.name,
          no: ed != null ? (ed.no > 0 ? '${vt.letter}-${ed.no}' : '') : '${vt.letter}-${nextVoucherNo(vt.code)}',
          date: _day,
          sub: ed == null ? bi('નવું વાઉચર', 'Creation') : bi('સુધારો (Alteration)', 'Alteration'),
        ),
        if (kinds.length > 1)
          ChipRow(
            labels: <String>[for (final List<String> k in kinds) k[0] == 'open' ? bi('જૂનું બાકી / જર્નલ', 'Old balance / Journal') : bi(k[1], k[2])],
            index: kinds.indexWhere((List<String> k) => k[0] == _kind),
            onChanged: (int i) => setState(() => _kind = kinds[i][0]),
          ),
        if (kinds.length > 1) const SizedBox(height: 14),
        SuggestField(label: '${bi('ખેડૂત', 'Farmer')} *', controller: _who, options: <String>[for (final PartySummary s in dir.take(400)) s.ref.label], onChanged: (String v) => setState(() {}), onPick: (String v) => setState(() {})),
        _curBal(dir),
        const SizedBox(height: 14),
        FieldX(
          label: '${bi('રકમ', 'Amount')} *',
          controller: _amt,
          big: true,
          prefix: '₹',
          keyboard: TextInputType.numberWithOptions(decimal: true, signed: _kind == 'open'),
        ),
        if (_kind == 'open')
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(bi('+ = ખેડૂતને આપવાના બાકી, - = ખેડૂત પાસેથી લેવાના', '+ = we owe the farmer, - = the farmer owes us'), style: ts(12, c: Pal.muted)),
          ),
        const SizedBox(height: 14),
        LineRow(label: bi('કેવી રીતે', 'How'), child: ChipRow(
          labels: <String>[for (final List<String> k in kPayModes) bi(k[1], k[2])],
          index: kPayModes.indexWhere((List<String> k) => k[0] == _mode),
          onChanged: (int i) => setState(() => _mode = kPayModes[i][0]),
        )),
        const SizedBox(height: 14),
        if (_mode != 'cash') ...<Widget>[
          const SizedBox(height: 14),
          FieldX(label: _mode == 'cheque' ? bi('ચેક નંબર', 'Cheque no.') : bi('UTR / રેફ નંબર', 'UTR / Ref no.'), controller: _ref),
        ],
        const SizedBox(height: 14),
        DayField(label: bi('તારીખ', 'Date'), value: _day, last: dateOnly(DateTime.now()), onChanged: (DateTime d) => setState(() => _day = d)),
        const SizedBox(height: 14),
        FieldX(label: bi('નોંધ / Narration', 'Narration'), controller: _note),
        const SizedBox(height: 14),
        if (_err.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(_err, style: ts(13, w: FontWeight.w700, c: Pal.bad))),
        _busy
            ? SizedBox(height: 52, child: Center(child: SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 2.6, color: Pal.brand))))
            : Btn(ed == null ? bi('સેવ કરો', 'Save') : bi('સુધારો સેવ કરો', 'Save alteration'), icon: 'check', expand: true, onTap: _save),
        if (ed != null) ...<Widget>[
          const SizedBox(height: 8),
          Row(
            children: <Widget>[
              tExp(child: Btn(bi('પ્રિન્ટ (Ctrl+P)', 'Print (Ctrl+P)'), icon: 'print', kind: BtnKind.tonal, dense: true, tabStop: false, onTap: _print)),
              const SizedBox(width: 8),
              tExp(child: Btn(bi('કાઢો (Alt+D)', 'Delete (Alt+D)'), icon: 'trash', kind: BtnKind.danger, dense: true, tabStop: false, onTap: _delete)),
            ],
          ),
        ],
      ],
    );
  }
}

// ======================================================================
// Farmer ledger (khedut khata)
// ======================================================================

class FarmerKhataScreen extends StatefulWidget {
  const FarmerKhataScreen({super.key});

  @override
  State<FarmerKhataScreen> createState() => _KhataState();
}

class _KhataState extends State<FarmerKhataScreen> {
  final TextEditingController _q = TextEditingController();
  int _show = 0; // 0 to pay, 1 all, 2 advance
  int _sort = 0; // 0 amount, 1 name, 2 longest unpaid

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  Future<void> _fromPick() async {
    final DateTime? d = await pickDay(context, khataFrom(), last: dateOnly(DateTime.now()));
    if (d != null) await setKhataFrom(d);
  }

  String _csv(List<FarmerAcct> l) {
    final StringBuffer b = StringBuffer();
    b.writeln('Farmer,Chits,KG,Purchase,Paid,Advance,Old balance,Balance');
    for (final FarmerAcct a in l) {
      b.writeln('${csvCell(a.label)},${a.chits},${a.kg.round()},${a.purchase.round()},${a.paid.round()},${a.adv.round()},${a.open.round()},${a.balance.round()}');
    }
    return b.toString();
  }

  String _text(List<FarmerAcct> l, double due) {
    final StringBuffer b = StringBuffer();
    b.writeln('Balaji Industries');
    b.writeln('${bi('ખેડૂત ખાતા - બાકી', 'Farmer ledger - dues')} (${dmy(DateTime.now())})');
    b.writeln('------------------------');
    for (final FarmerAcct a in l.where((FarmerAcct x) => x.balance > 0.5).take(40)) {
      b.writeln('${a.label}: ${inr(a.balance)}');
    }
    b.writeln('------------------------');
    b.writeln('${bi('કુલ બાકી', 'Total due')}: ${inr(due)}');
    return b.toString().trim();
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[payDoc, rateDoc, prefDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 820,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final Map<String, FarmerAcct> m = farmerAccts();
          final List<FarmerAcct> all = m.values.toList();
          double due = 0;
          double adv = 0;
          double bought = 0;
          double given = 0;
          int nDue = 0;
          for (final FarmerAcct a in all) {
            bought += a.purchase;
            given += a.given;
            if (a.balance > 0.5) {
              due += a.balance;
              nDue++;
            } else if (a.balance < -0.5) {
              adv += -a.balance;
            }
          }
          final String q = _q.text.trim().toLowerCase();
          List<FarmerAcct> l = all.where((FarmerAcct a) {
            if (q.isNotEmpty && !a.label.toLowerCase().contains(q)) return false;
            if (_show == 0) return a.balance > 0.5;
            if (_show == 2) return a.balance < -0.5;
            return true;
          }).toList();
          if (_sort == 0) {
            l.sort((FarmerAcct a, FarmerAcct b) => b.balance.abs().compareTo(a.balance.abs()));
          } else if (_sort == 1) {
            l.sort((FarmerAcct a, FarmerAcct b) => a.label.toLowerCase().compareTo(b.label.toLowerCase()));
          } else {
            l.sort((FarmerAcct a, FarmerAcct b) {
              final DateTime x = a.lastPay ?? DateTime(2000);
              final DateTime y = b.lastPay ?? DateTime(2000);
              return x.compareTo(y);
            });
          }
          final bool hasRates = rateDoc.data['rates'] is Map && (rateDoc.data['rates'] as Map).isNotEmpty;
          final DateTime from = khataFrom();
          DateTime? firstChit;
          for (final Chit c in live.chits) {
            final DateTime? fc = firstChit;
            if (fc == null || c.at.isBefore(fc)) firstChit = c.at;
          }
          final DateTime? fcF = firstChit;

          return <Widget>[
            ScreenHeader(bi('ખેડૂત ખાતા', 'Farmer ledger'), sub: '${bi('ખાતું શરૂ', 'From')} ${dmy(from)}', actions: <Widget>[
              IconBtn('plus', tip: bi('ચૂકવણી નાખો', 'Add payment'), onTap: () => openPayForm(ctx)),
            ]),
            statusBanner(),
            tallyPayBanner(),
            HeroCard(
              title: bi('ખેડૂતોને કુલ આપવાના બાકી', 'Total to pay the farmers'),
              value: inrC(due),
              unit: '',
              sub: '$nDue ${bi('ખેડૂતના બાકી', 'farmers have dues')}${adv > 0 ? ' · ${bi('એડવાન્સ', 'advance')} ${inrC(adv)}' : ''}',
              chips: <HeroChip>[
                HeroChip('receipt', '${bi('ખરીદ', 'Bought')} ${inrC(bought)}'),
                HeroChip('rupee', '${bi('ચૂકવ્યા', 'Paid')} ${inrC(given)}'),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                tExp(child: Btn(bi('ચૂકવણી નાખો', 'Add payment'), icon: 'plus', onTap: () => openPayForm(ctx))),
                const SizedBox(width: 8),
                tExp(child: Btn(bi('યાદી મોકલો', 'Send list'), icon: 'chat', kind: BtnKind.tonal, onTap: () => whatsappText(_text(all, due)))),
              ],
            ),
            const SizedBox(height: 12),
            if (!hasRates) noteBox('warn', 'amber', bi('ભાવ નાખ્યા નથી - પહેલા "ભાવ" માં માલનો ભાવ નાખો, નહીં તો ખરીદ રકમ 0 દેખાશે', 'No rates set - add material rates first or purchases show 0'), onTap: () => app.go('rates')),
            if (hasRates && all.any((FarmerAcct a) => a.noRateKg > 0)) noteBox('info', 'amber', bi('કેટલીક ચિઠ્ઠીનો ભાવ નથી - તેની રકમ ગણાઈ નથી', 'Some chits have no rate - not counted'), onTap: () => app.go('rates')),
            if (fcF != null && dayOf(fcF).isAfter(addDays(from, 1)))
              noteBox('warn', 'amber', bi('એપમાં ${dmy(fcF)} થી જ ડેટા છે; ખાતું ${dmy(from)} થી છે. વચ્ચેની ખરીદ ગણાશે નહીં.', 'App data starts ${dmy(fcF)} but the ledger starts ${dmy(from)}. Purchases in between are missing.')),
            if (!khataFromSet()) noteBox('info', 'blue', bi('ખાતું ${dmy(from)} થી ગણાય છે. બદલવા અહીં ટચ કરો. તે પહેલાનું બાકી "જૂનું બાકી" તરીકે નાખો.', 'Ledger counts from ${dmy(from)}. Tap to change. Put older dues as "Old balance".'), onTap: _fromPick),
            SearchBox(hint: bi('ખેડૂતનું નામ', 'Farmer name'), controller: _q, onChanged: (String _) => setState(() {})),
            const SizedBox(height: 10),
            ChipRow(
              labels: <String>[bi('આપવાના', 'To pay'), bi('બધા', 'All'), bi('એડવાન્સ', 'Advance')],
              index: _show,
              onChanged: (int i) => setState(() => _show = i),
            ),
            const SizedBox(height: 8),
            ChipRow(
              labels: <String>[bi('રકમ મુજબ', 'By amount'), bi('નામ મુજબ', 'By name'), bi('ઘણા સમયથી ચૂકવણી નથી', 'Longest unpaid')],
              index: _sort,
              onChanged: (int i) => setState(() => _sort = i),
            ),
            const SizedBox(height: 12),
            if (l.isEmpty) EmptyBox(icon: 'agri', title: bi('કોઈ ખેડૂત નથી', 'No farmers here')),
            for (final FarmerAcct a in l.take(120))
              lineItem(
                icon: 'agri',
                tone: a.balance > 0.5 ? 'rose' : (a.balance < -0.5 ? 'amber' : 'green'),
                title: a.label,
                sub: '${bi('ખરીદ', 'Bought')} ${inrC(a.purchase)} · ${bi('ચૂકવ્યા', 'Paid')} ${inrC(a.given)}${a.lastPay == null ? '' : ' · ${dayLabel(a.lastPay!)}'}',
                trailing: inr(a.balance.abs()),
                trailingSub: balWord(a.balance),
                trailingColor: balColor(a.balance),
                onTap: () => app.go('khata_party', arg: PartyRef(Dim.farmer, a.key, a.label)),
              ),
            if (l.length > 120) Padding(padding: const EdgeInsets.all(12), child: Text(bi('શોધ વડે બાકીના શોધો', 'Use search to find the rest'), style: ts(12.5, c: Pal.muted))),
            const SizedBox(height: 14),
            Panel(
              title: bi('ખાતાની ગોઠવણ', 'Ledger settings'),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Text(bi('ખેડૂતને કયા વજન પર ભાવ ચૂકવાય છે?', 'Which weight is the farmer paid on?'), style: ts(13, w: FontWeight.w700)),
                  const SizedBox(height: 8),
                  Seg(
                    labels: <String>[bi('ચોખ્ખું (બારદાન-કરદો બાદ)', 'Net (after bardan, kardo)'), bi('કુલ વજન', 'Full weight')],
                    index: payOn(),
                    onChanged: (int i) => setPayOn(i),
                    dense: true,
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: <Widget>[
                      Expanded(child: Text('${bi('ખાતું શરૂ તારીખ', 'Ledger starts')}: ${dmy(from)}', style: ts(13, w: FontWeight.w700))),
                      Btn(bi('બદલો', 'Change'), icon: 'cal', kind: BtnKind.outline, dense: true, onTap: _fromPick),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Btn(bi('Excel માટે CSV કૉપિ', 'Copy CSV for Excel'), icon: 'copy', kind: BtnKind.ghost, dense: true, onTap: () => copyText(_csv(all), msg: bi('કૉપિ થયું - Excel માં પેસ્ટ કરો', 'Copied - paste into Excel'))),
                ],
              ),
            ),
          ];
        },
      ),
    );
  }
}

// ======================================================================
// One farmer's account
// ======================================================================

class _Led {
  final DateTime at;
  final String title;
  final String sub;
  final double effect;
  final String payId; // '' for a chit
  final bool noRate;
  const _Led(this.at, this.title, this.sub, this.effect, this.payId, this.noRate);
}

class KhataDetailScreen extends StatelessWidget {
  final PartyRef? party;
  const KhataDetailScreen(this.party, {super.key});

  Future<void> _remove(BuildContext context, String id) async {
    final bool go = await confirmBox(context, title: bi('આ નોંધ કાઢી નાખવી?', 'Delete this entry?'), text: bi('આ ચૂકવણીની નોંધ કાયમ માટે કાઢી નંખાશે.', 'This payment entry will be removed for good.'), yes: bi('હા, કાઢો', 'Yes, delete'), no: bi('ના', 'No'));
    if (go) await removePayItem(id);
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[payDoc, rateDoc, prefDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 760,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final PartyRef? r = party;
          if (r == null) return <Widget>[EmptyBox(icon: 'agri', title: bi('ખેડૂત મળ્યો નથી', 'Farmer not found'))];
          final DateTime from = khataFrom();
          final FarmerAcct a = farmerAccts()[r.key] ?? FarmerAcct(r.key, r.label);
          final List<_Led> led = <_Led>[];
          for (final Chit c in live.chits) {
            if (c.at.isBefore(from) || nameKey(c.farmer) != r.key) continue;
            final double? amt = chitAmount(c);
            final double? rate = rateFor(c.commodity.trim(), c.at);
            led.add(_Led(
              c.at,
              '${bi('ચિઠ્ઠી', 'Chit')} #${c.no} · ${grp(payKg(c))} KG',
              '${matLabel(c.commodity)} · ${vtxt(c.vehicle)}${rate == null ? '' : ' · ₹${grp(rate)}/20'}',
              amt ?? 0,
              '',
              amt == null,
            ));
          }
          for (final PayItem p in payItems()) {
            if (p.key != r.key) continue;
            if (p.kind != 'open' && p.date.isBefore(from)) continue;
            led.add(_Led(p.date, '${payItemLabel(p)} · ${payModeLabel(p.mode)}', p.note, p.effect, p.id, false));
          }
          led.sort((_Led x, _Led y) => x.at.compareTo(y.at));
          final List<double> running = <double>[];
          double run = 0;
          for (final _Led e in led) {
            run += e.effect;
            running.add(run);
          }
          final String mobile = farmerMobile(r.key);
          final double bal = a.balance;

          String statement() {
            final StringBuffer b = StringBuffer();
            b.writeln('Balaji Industries');
            b.writeln('${bi('ખાતું', 'Account')}: ${r.label}');
            b.writeln('${dmy(from)} - ${dmy(DateTime.now())}');
            b.writeln('------------------------');
            b.writeln('${bi('ખરીદ', 'Purchase')}: ${inr(a.purchase)} (${grp(a.kg)} KG)');
            if (a.open != 0) b.writeln('${bi('જૂનું બાકી', 'Old balance')}: ${signedInr(a.open)}');
            if (a.paid > 0) b.writeln('${bi('ચૂકવ્યા', 'Paid')}: ${inr(a.paid)}');
            if (a.adv > 0) b.writeln('${bi('એડવાન્સ', 'Advance')}: ${inr(a.adv)}');
            if (a.recv > 0) b.writeln('${bi('પાછા લીધા', 'Taken back')}: ${inr(a.recv)}');
            b.writeln('------------------------');
            b.writeln('${balWord(bal)}: ${inr(bal.abs())}');
            return b.toString().trim();
          }

          final List<Widget> rows = <Widget>[];
          String lastDay = '';
          for (int i = led.length - 1; i >= 0; i--) {
            final _Led e = led[i];
            final String dk = dayKey(e.at);
            if (dk != lastDay) {
              rows.add(_dateHead(dayLabel(e.at)));
              lastDay = dk;
            }
            final bool isPay = e.payId.isNotEmpty;
            rows.add(Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Surface(
                padding: const EdgeInsets.fromLTRB(12, 10, 6, 10),
                onTap: isPay
                    ? () {
                        final Vch? vv = voucherById('pay', e.payId);
                        if (vv != null) openVoucher(ctx, vv);
                      }
                    : null,
                child: Row(
                  children: <Widget>[
                    IconChip(isPay ? 'rupee' : 'receipt', tone: isPay ? (e.effect < 0 ? 'green' : 'amber') : 'teal', size: 36),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(e.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14, w: FontWeight.w800)),
                          if (e.sub.isNotEmpty) Text(e.sub, maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(12, c: Pal.muted)),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: <Widget>[
                        Text(e.noRate ? bi('ભાવ નથી', 'no rate') : '${e.effect < 0 ? '-' : '+'}${inr(e.effect.abs())}', style: ts(14, w: FontWeight.w800, tab: true, c: e.noRate ? Pal.warn : (e.effect < 0 ? Pal.ok : null))),
                        Text(inr(running[i]), style: ts(11.5, c: Pal.muted, tab: true)),
                      ],
                    ),
                    if (isPay) IconBtn('trash', size: 38, tip: bi('કાઢો', 'Delete'), onTap: () => _remove(ctx, e.payId)) else const SizedBox(width: 6),
                  ],
                ),
              ),
            ));
          }

          return <Widget>[
            ScreenHeader(r.label, sub: bi('ખેડૂત ખાતું', 'Farmer account'), actions: <Widget>[
              IconBtn('ledger', tip: bi('ખાતાવહી (Dr/Cr)', 'Ledger (Dr/Cr)'), onTap: () => app.go('my_ledger', arg: LedgerRef('farmer', r.key, r.label))),
              IconBtn('user', tip: bi('પ્રોફાઇલ', 'Profile'), onTap: () => openParty(r)),
            ]),
            statusBanner(),
            HeroCard(
              title: balWord(bal),
              value: inr(bal.abs()),
              unit: '',
              sub: '${a.chits} ${bi('ચિઠ્ઠી', 'chits')} · ${grp(a.kg)} KG',
              chips: <HeroChip>[
                HeroChip('receipt', '${bi('ખરીદ', 'Bought')} ${inrC(a.purchase)}'),
                HeroChip('rupee', '${bi('ચૂકવ્યા', 'Paid')} ${inrC(a.given)}'),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                tExp(child: Btn(bi('ચૂકવણી', 'Payment'), icon: 'plus', onTap: () => openPayForm(ctx, farmer: r))),
                const SizedBox(width: 8),
                tExp(child: Btn(bi('એડવાન્સ', 'Advance'), icon: 'plus', kind: BtnKind.tonal, onTap: () => openPayForm(ctx, farmer: r, kind: 'adv'))),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: <Widget>[
                tExp(child: Btn('WhatsApp', icon: 'chat', kind: BtnKind.tonal, dense: true, onTap: () => whatsappText(statement(), phone: mobile))),
                const SizedBox(width: 8),
                if (mobile.isNotEmpty) ...<Widget>[
                  tExp(child: Btn(bi('ફોન', 'Call'), icon: 'call', kind: BtnKind.tonal, dense: true, onTap: () => callPhone(mobile))),
                  const SizedBox(width: 8),
                ],
                tExp(child: Btn(bi('કૉપિ', 'Copy'), icon: 'copy', kind: BtnKind.outline, dense: true, onTap: () => copyText(statement()))),
              ],
            ),
            const SizedBox(height: 12),
            if (bal > 0.5) Btn(bi('ફોલો-અપ યાદીમાં ઉમેરો', 'Add to follow-ups'), icon: 'todo', kind: BtnKind.ghost, dense: true, onTap: () {
              addFollowup0(r.label, bal);
            }),
            if (led.isEmpty) EmptyBox(icon: 'agri', title: bi('આ ખાતામાં હજી કંઈ નથી', 'Nothing in this account yet'), sub: bi('ખાતું ${dmy(from)} થી શરૂ છે', 'Ledger starts ${dmy(from)}')),
            if (Pal.tally && app.stagePc)
              ...ledgerTable(ctx, buildLedger(LedgerRef('farmer', r.key, r.label), Period(DateTime(2000), addDays(dayOf(DateTime.now()), 1))))
            else
              ...rows,
          ];
        },
      ),
    );
  }
}

/// A follow-up "pay <farmer> <amount>" for tomorrow.
Future<void> addFollowup0(String label, double amt) async {
  final List<Map<String, dynamic>> items = todoDoc.list('items');
  items.add(<String, dynamic>{
    'id': '${DateTime.now().microsecondsSinceEpoch}',
    'text': '${bi('ચૂકવણી', 'Pay')} $label ${inr(amt)}',
    'due': dayKey(addDays(dayOf(DateTime.now()), 1)),
    'done': false,
    'ref': '',
    'at': DateTime.now().toIso8601String(),
  });
  await todoDoc.save();
  app.toast(bi('ફોલો-અપમાં ઉમેરાયું', 'Added to follow-ups'));
}

// ======================================================================
// Payment register
// ======================================================================

class PaymentsScreen extends StatefulWidget {
  const PaymentsScreen({super.key});

  @override
  State<PaymentsScreen> createState() => _PaymentsState();
}

class _PaymentsState extends State<PaymentsScreen> {
  RangeSel _sel = RangeSel(2);
  int _mode = 0; // 0 all, 1.. kPayModes

  Future<void> _remove(String id) async {
    final bool go = await confirmBox(context, title: bi('આ નોંધ કાઢી નાખવી?', 'Delete this entry?'), text: bi('આ ચૂકવણીની નોંધ કાયમ માટે કાઢી નંખાશે.', 'This payment entry will be removed for good.'), yes: bi('હા, કાઢો', 'Yes, delete'), no: bi('ના', 'No'));
    if (go) await removePayItem(id);
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[payDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 800,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final Period p = _sel.period;
          final List<PayItem> all = payItems().where((PayItem x) => x.kind != 'open' && p.has(x.date)).toList();
          final List<PayItem> list = all.where((PayItem x) => _mode == 0 || x.mode == kPayModes[_mode - 1][0]).toList();
          double out = 0;
          double back = 0;
          final Map<String, double> byMode = <String, double>{};
          for (final PayItem x in all) {
            if (x.kind == 'recv') {
              back += x.amt;
            } else {
              out += x.amt;
              byMode[x.mode] = (byMode[x.mode] ?? 0) + x.amt;
            }
          }
          final List<Widget> rows = <Widget>[];
          String lastDay = '';
          for (final PayItem x in list) {
            final String dk = dayKey(x.date);
            if (dk != lastDay) {
              rows.add(_dateHead(dayLabel(x.date)));
              lastDay = dk;
            }
            rows.add(Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Surface(
                padding: const EdgeInsets.fromLTRB(12, 8, 4, 8),
                onTap: () {
                  final Vch? vv = voucherById('pay', x.id);
                  if (vv != null) openVoucher(ctx, vv);
                },
                child: Row(
                  children: <Widget>[
                    IconChip('rupee', tone: x.kind == 'recv' ? 'amber' : 'green', size: 36),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(x.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14, w: FontWeight.w800)),
                          Text('${x.no > 0 ? '${vTypeOf(payCode(x.kind, jt: x.jt)).letter}-${x.no} · ' : ''}${payItemLabel(x)} · ${payModeLabel(x.mode)}${x.ref.isEmpty ? '' : ' · ${x.ref}'}${x.note.isEmpty ? '' : ' · ${x.note}'}', maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12, c: Pal.muted)),
                        ],
                      ),
                    ),
                    Text(inr(x.amt), style: ts(14.5, w: FontWeight.w800, tab: true, c: x.kind == 'recv' ? Pal.warn : null)),
                    IconBtn('trash', size: 38, tip: bi('કાઢો', 'Delete'), onTap: () => _remove(x.id)),
                  ],
                ),
              ),
            ));
          }

          return <Widget>[
            ScreenHeader(bi('ચૂકવણી નોંધ', 'Payments'), sub: p.label, actions: <Widget>[
              IconBtn('plus', tip: bi('ચૂકવણી નાખો', 'Add payment'), onTap: () => openPayForm(ctx)),
            ]),
            statusBanner(),
            tallyPayBanner(),
            RangeBar(sel: _sel, presets: const <int>[0, 1, 2, 3, 4, 5], onChanged: (RangeSel s) => setState(() => _sel = s)),
            const SizedBox(height: 12),
            HeroCard(
              title: bi('ખેડૂતોને કુલ ચૂકવ્યા', 'Paid to farmers'),
              value: inrC(out),
              unit: '',
              sub: back > 0 ? '${bi('પાછા લીધા', 'Taken back')} ${inrC(back)}' : null,
              chips: <HeroChip>[
                HeroChip('list', '${all.length} ${bi('નોંધ', 'entries')}'),
                for (final MapEntry<String, double> e in byMode.entries) HeroChip('rupee', '${payModeLabel(e.key)} ${inrC(e.value)}'),
              ],
            ),
            const SizedBox(height: 12),
            ChipRow(
              labels: <String>[bi('બધા', 'All'), for (final List<String> k in kPayModes) bi(k[1], k[2])],
              index: _mode,
              onChanged: (int i) => setState(() => _mode = i),
            ),
            const SizedBox(height: 6),
            if (list.isEmpty) EmptyBox(icon: 'rupee', title: bi('આ સમયમાં કોઈ ચૂકવણી નથી', 'No payments in this period')),
            if (Pal.tally && app.stagePc)
              ...voucherTable(
                ctx,
                vouchersIn(p).where((Vch v) => v.src == 'pay' && v.kind != 'open' && (_mode == 0 || v.mode == kPayModes[_mode - 1][0])).toList(),
              )
            else
              ...rows,
          ];
        },
      ),
    );
  }
}

// ======================================================================
// Expenses and money received
// ======================================================================

class ExpensesScreen extends StatefulWidget {
  const ExpensesScreen({super.key});

  @override
  State<ExpensesScreen> createState() => _ExpensesState();
}

class _ExpensesState extends State<ExpensesScreen> {
  late final VoidCallback _accept = () {
    _save();
  };

  @override
  void initState() {
    super.initState();
    AcceptHub.push(_accept);
  }

  RangeSel _sel = RangeSel(4);
  final TextEditingController _amt = TextEditingController();
  final TextEditingController _note = TextEditingController();
  int _kind = 0; // 0 expense, 1 income
  int _cat = 0;
  int _mode = 0;
  DateTime _day = dateOnly(DateTime.now());
  bool _busy = false;

  @override
  void dispose() {
    _amt.dispose();
    _note.dispose();
    AcceptHub.pop(_accept);
    super.dispose();
  }

  List<List<String>> get _cats => _kind == 0 ? kExpCatsShown : kInCats;

  Future<void> _pick() async {
    final DateTime? d = await pickDay(context, _day, last: dateOnly(DateTime.now()));
    if (d != null && mounted) setState(() => _day = d);
  }

  Future<void> _save() async {
    final double amt = dbl(_amt.text.replaceAll(',', ''));
    if (amt <= 0) {
      app.toast(bi('રકમ લખો', 'Enter the amount'));
      return;
    }
    if (_busy) return;
    setState(() => _busy = true);
    final bool ok = await ErrLog.attempt('Save', () => addExpItem(amt: amt, cat: _cats[_cat][0], kind: _kind == 0 ? 'out' : 'in', mode: kPayModes[_mode][0], date: _day, note: _note.text));
    if (!ok) {
      if (mounted) setState(() => _busy = false);
      return;
    }
    _amt.clear();
    _note.clear();
    if (mounted) setState(() => _busy = false);
    app.toast('${_kind == 0 ? bi('ખર્ચ', 'Expense') : bi('આવક', 'Income')} · ${inr(amt)}');
  }

  Future<void> _remove(String id) async {
    final bool go = await confirmBox(context, title: bi('આ નોંધ કાઢી નાખવી?', 'Delete this entry?'), text: bi('આ નોંધ કાયમ માટે કાઢી નંખાશે.', 'This entry will be removed for good.'), yes: bi('હા, કાઢો', 'Yes, delete'), no: bi('ના', 'No'));
    if (go) await removeExpItem(id);
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[expDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 820,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final Period p = _sel.period;
          final List<ExpItem> all = expItems().where((ExpItem x) => p.has(x.date)).toList();
          double out = 0;
          double inn = 0;
          final Map<String, double> byCat = <String, double>{};
          for (final ExpItem x in all) {
            if (x.isIn) {
              inn += x.amt;
            } else {
              out += x.amt;
              byCat[x.cat] = (byCat[x.cat] ?? 0) + x.amt;
            }
          }
          final List<MapEntry<String, double>> cats = byCat.entries.toList();
          cats.sort((MapEntry<String, double> a, MapEntry<String, double> b) => b.value.compareTo(a.value));
          final List<Color> cols = chartColors();

          final List<Widget> rows = <Widget>[];
          String lastDay = '';
          for (final ExpItem x in all) {
            final String dk = dayKey(x.date);
            if (dk != lastDay) {
              rows.add(_dateHead(dayLabel(x.date)));
              lastDay = dk;
            }
            rows.add(Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Surface(
                padding: const EdgeInsets.fromLTRB(12, 8, 4, 8),
                onTap: () {
                  final Vch? vv = voucherById('exp', x.id);
                  if (vv != null) openVoucher(ctx, vv);
                },
                child: Row(
                  children: <Widget>[
                    IconChip(x.isIn ? 'arrowdown' : 'arrowup', tone: x.isIn ? 'green' : 'rose', size: 36),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(expCatLabel(x.cat), maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14, w: FontWeight.w800)),
                          Text('${x.no > 0 ? '${vTypeOf(expCode(x.kind)).letter}-${x.no} · ' : ''}${payModeLabel(x.mode)}${x.ref.isEmpty ? '' : ' · ${x.ref}'}${x.note.isEmpty ? '' : ' · ${x.note}'}', maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12, c: Pal.muted)),
                        ],
                      ),
                    ),
                    Text('${x.isIn ? '+' : '-'}${inr(x.amt)}', style: ts(14.5, w: FontWeight.w800, tab: true, c: x.isIn ? Pal.ok : null)),
                    IconBtn('trash', size: 38, tip: bi('કાઢો', 'Delete'), onTap: () => _remove(x.id)),
                  ],
                ),
              ),
            ));
          }

          return <Widget>[
            ScreenHeader(bi('ખર્ચ અને આવક', 'Expenses and income'), sub: p.label),
            statusBanner(),
            Panel(
              title: bi('નવી નોંધ', 'New entry'),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Seg(labels: <String>[bi('ખર્ચ (જાવક)', 'Expense (out)'), bi('આવક (આવ્યા)', 'Income (in)')], index: _kind, onChanged: (int i) => setState(() {
                        _kind = i;
                        _cat = 0;
                      })),
                  const SizedBox(height: 12),
                  ChipRow(labels: <String>[for (final List<String> k in _cats) bi(k[1], k[2])], index: _cat, onChanged: (int i) => setState(() => _cat = i)),
                  const SizedBox(height: 12),
                  FieldX(label: '${bi('રકમ', 'Amount')} *', controller: _amt, big: true, prefix: '₹', keyboard: const TextInputType.numberWithOptions(decimal: true)),
                  const SizedBox(height: 12),
                  ChipRow(labels: <String>[for (final List<String> k in kPayModes) bi(k[1], k[2])], index: _mode, onChanged: (int i) => setState(() => _mode = i)),
                  const SizedBox(height: 12),
                  DayField(label: bi('તારીખ', 'Date'), value: _day, last: dateOnly(DateTime.now()), onChanged: (DateTime d) => setState(() => _day = d)),
                  const SizedBox(height: 14),
                  FieldX(label: bi('નોંધ (ઇચ્છા મુજબ)', 'Note (optional)'), controller: _note),
                  const SizedBox(height: 14),
                  Btn(bi('સેવ કરો', 'Save'), icon: 'check', expand: true, onTap: _save),
                ],
              ),
            ),
            const SizedBox(height: 14),
            RangeBar(sel: _sel, presets: const <int>[0, 1, 2, 3, 4, 5], onChanged: (RangeSel s) => setState(() => _sel = s)),
            const SizedBox(height: 12),
            HeroCard(
              title: bi('કુલ ખર્ચ', 'Total expenses'),
              value: inrC(out),
              unit: '',
              sub: p.label,
              chips: <HeroChip>[
                HeroChip('arrowdown', '${bi('આવક', 'Income')} ${inrC(inn)}'),
                HeroChip('list', '${all.length} ${bi('નોંધ', 'entries')}'),
              ],
            ),
            const SizedBox(height: 12),
            if (cats.isNotEmpty)
              Panel(
                title: bi('ખર્ચ ક્યાં થયો', 'Where it went'),
                child: RankList(<RankItem>[
                  for (int i = 0; i < cats.length; i++) RankItem(expCatLabel(cats[i].key), cats[i].value, inr(cats[i].value), cols[i % cols.length], sub: out > 0 ? '${(cats[i].value / out * 100).toStringAsFixed(0)}%' : null),
                ]),
              ),
            if (cats.isNotEmpty) const SizedBox(height: 12),
            if (all.isEmpty) EmptyBox(icon: 'wallet', title: bi('આ સમયમાં કોઈ નોંધ નથી', 'No entries in this period')),
            if (Pal.tally && app.stagePc) ...voucherTable(ctx, vouchersIn(p).where((Vch v) => v.src == 'exp').toList()) else ...rows,
          ];
        },
      ),
    );
  }
}

// ======================================================================
// Cash book (rojmel)
// ======================================================================

class _SeedForm extends StatefulWidget {
  const _SeedForm();

  @override
  State<_SeedForm> createState() => _SeedFormState();
}

class _SeedFormState extends State<_SeedForm> {
  late final TextEditingController _c = TextEditingController(text: cashSeedDate() == null ? '' : plainNum(cashSeed()));
  late DateTime _d = cashSeedDate() ?? dateOnly(DateTime.now());

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Text(bi('જે દિવસથી રોજમેળ શરૂ કરવો છે તે દિવસની સવારે ગલ્લામાં કેટલી રોકડ હતી?', 'How much cash was in hand on the morning of the day the cash book starts?'), style: ts(13.5, h: 1.4)),
        const SizedBox(height: 12),
        FieldX(label: bi('શરૂઆતની રોકડ', 'Opening cash'), controller: _c, big: true, prefix: '₹', keyboard: const TextInputType.numberWithOptions(decimal: true, signed: true)),
        const SizedBox(height: 12),
        DayField(label: bi('તારીખ', 'Date'), value: _d, last: dateOnly(DateTime.now()), onChanged: (DateTime x) => setState(() => _d = x)),
        const SizedBox(height: 16),
        Btn(bi('સેવ કરો', 'Save'), icon: 'check', expand: true, onTap: () async {
          await setCashSeed(dbl(_c.text.replaceAll(',', '')), _d);
          if (context.mounted) Navigator.of(context).pop();
        }),
      ],
    );
  }
}

class CashBookScreen extends StatefulWidget {
  const CashBookScreen({super.key});

  @override
  State<CashBookScreen> createState() => _CashBookState();
}

class _CashBookState extends State<CashBookScreen> {
  DateTime _day = dateOnly(DateTime.now());

  Future<void> _pick() async {
    final DateTime? d = await pickDay(context, _day, last: dateOnly(DateTime.now()));
    if (d != null && mounted) setState(() => _day = d);
  }

  Widget _line(CashLine l) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Surface(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(l.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14, w: FontWeight.w800)),
                  if (l.sub.isNotEmpty) Text(l.sub, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12, c: Pal.muted)),
                ],
              ),
            ),
            Text(inr(l.amt), style: ts(14.5, w: FontWeight.w800, tab: true, c: l.isIn ? Pal.ok : Pal.bad)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[payDoc, expDoc, saleDoc, prefDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 900,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final double opening = cashOpening(_day);
          final List<CashLine> day = cashLines().where((CashLine l) => sameDay(l.date, _day)).toList();
          final List<CashLine> ins = day.where((CashLine l) => l.isIn).toList();
          final List<CashLine> outs = day.where((CashLine l) => !l.isIn).toList();
          double inSum = 0;
          for (final CashLine l in ins) {
            inSum += l.amt;
          }
          double outSum = 0;
          for (final CashLine l in outs) {
            outSum += l.amt;
          }
          final double closing = opening + inSum - outSum;
          // payments by bank / UPI / cheque on the same day (not part of the cash)
          double other = 0;
          for (final PayItem x in payItems()) {
            if (x.mode != 'cash' && x.kind != 'open' && sameDay(x.date, _day) && x.kind != 'recv') other += x.amt;
          }
          for (final ExpItem x in expItems()) {
            if (x.mode != 'cash' && !x.isIn && sameDay(x.date, _day)) other += x.amt;
          }

          final Widget inBox = Panel(
            title: '${bi('આવક', 'Cash in')} · ${inr(inSum)}',
            child: ins.isEmpty ? Text(bi('કોઈ નહીં', 'None'), style: ts(13, c: Pal.muted)) : Column(children: <Widget>[for (final CashLine l in ins) _line(l)]),
          );
          final Widget outBox = Panel(
            title: '${bi('જાવક', 'Cash out')} · ${inr(outSum)}',
            child: outs.isEmpty ? Text(bi('કોઈ નહીં', 'None'), style: ts(13, c: Pal.muted)) : Column(children: <Widget>[for (final CashLine l in outs) _line(l)]),
          );

          return <Widget>[
            ScreenHeader(bi('રોજમેળ (રોકડ)', 'Cash book'), sub: dmy(_day)),
            statusBanner(),
            tallyStrip(TallyWhat.cash),
            tallyRows(TallyRows.cash, from: _day, to: _day),
            Row(
              children: <Widget>[
                IconBtn('chevl', tip: bi('પાછળનો દિવસ', 'Previous day'), onTap: () => setState(() => _day = addDays(_day, -1))),
                Expanded(child: Center(child: dayButton(_day, _pick))),
                IconBtn('chev', tip: bi('આગળનો દિવસ', 'Next day'), onTap: sameDay(_day, DateTime.now()) ? null : () => setState(() => _day = addDays(_day, 1))),
              ],
            ),
            const SizedBox(height: 10),
            if (cashSeedDate() == null) noteBox('info', 'blue', bi('શરૂઆતની રોકડ નાખો - પછી જ રોજમેળ સાચો ચાલશે', 'Set the opening cash first so the cash book is correct'), onTap: () => openPanel(ctx, title: bi('શરૂઆતની રોકડ', 'Opening cash'), width: 440, child: const _SeedForm())),
            HeroCard(
              title: bi('દિવસના અંતે રોકડ', 'Cash at end of day'),
              value: inr(closing),
              unit: '',
              sub: '${bi('સવારે', 'Morning')} ${inr(opening)}',
              chips: <HeroChip>[
                HeroChip('arrowdown', '${bi('આવક', 'In')} ${inrC(inSum)}'),
                HeroChip('arrowup', '${bi('જાવક', 'Out')} ${inrC(outSum)}'),
              ],
            ),
            const SizedBox(height: 12),
            if (other > 0) noteBox('info', 'slate', bi('આ દિવસે બેંક / UPI / ચેકથી ${inr(other)} ચૂકવાયા (રોકડમાં ગણાયા નથી)', '${inr(other)} was paid by bank / UPI / cheque (not in cash)')),
            if (Pal.tally && app.stagePc) ...cashBookTable(ctx, _day, opening) else SplitPane(children: <Widget>[inBox, outBox]),
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                tExp(child: Btn(bi('ખર્ચ / આવક', 'Expense / income'), icon: 'plus', kind: BtnKind.tonal, dense: true, onTap: () => app.go('expenses'))),
                const SizedBox(width: 8),
                tExp(child: Btn(bi('ખેડૂતને ચૂકવણી', 'Pay a farmer'), icon: 'plus', kind: BtnKind.tonal, dense: true, onTap: () => openPayForm(ctx))),
                const SizedBox(width: 8),
                tExp(child: Btn(bi('શરૂઆત બદલો', 'Opening'), icon: 'gear', kind: BtnKind.outline, dense: true, onTap: () => openPanel(ctx, title: bi('શરૂઆતની રોકડ', 'Opening cash'), width: 440, child: const _SeedForm()))),
              ],
            ),
            const SizedBox(height: 8),
            Btn(bi('બેંકમાં જમા / ઉપાડ (Contra)', 'Cash <-> Bank (Contra)'), icon: 'bank', kind: BtnKind.tonal, dense: true, expand: true, onTap: () => openContraForm(ctx)),
          ];
        },
      ),
    );
  }
}

// ======================================================================
// Day account
// ======================================================================

class DayAccountScreen extends StatefulWidget {
  const DayAccountScreen({super.key});

  @override
  State<DayAccountScreen> createState() => _DayAccountState();
}

class _DayAccountState extends State<DayAccountScreen> {
  DateTime _day = dateOnly(DateTime.now());

  Future<void> _pick() async {
    final DateTime? d = await pickDay(context, _day, last: dateOnly(DateTime.now()));
    if (d != null && mounted) setState(() => _day = d);
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[payDoc, expDoc, rateDoc, saleDoc, prefDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 760,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final Period p = Period(_day, addDays(_day, 1));
          int chitN = 0;
          double chitKg = 0;
          double value = 0;
          double noRateKg = 0;
          for (final Chit c in live.chits) {
            if (!p.has(c.at)) continue;
            chitN++;
            chitKg += payKg(c);
            final double? a = chitAmount(c);
            if (a == null) {
              noRateKg += payKg(c);
            } else {
              value += a;
            }
          }
          int kantaN = 0;
          double kantaKg = 0;
          for (final Kanta k in live.kantas) {
            if (!p.has(k.at)) continue;
            kantaN++;
            kantaKg += k.kg;
          }
          int inB = 0;
          int outB = 0;
          final List<MaalRow> ms = live.maals.where((MaalRow m) => p.has(m.date)).toList();
          for (final MaalRow m in ms) {
            if (m.loading) {
              outB += m.bags;
            } else {
              inB += m.bags;
            }
          }
          final double wages = wagesOf(ms);
          double paid = 0;
          double back = 0;
          for (final PayItem x in payItems()) {
            if (x.kind == 'open' || !sameDay(x.date, _day)) continue;
            if (x.kind == 'recv') {
              back += x.amt;
            } else {
              paid += x.amt;
            }
          }
          double exp = 0;
          double inc = 0;
          for (final ExpItem x in expItems()) {
            if (!sameDay(x.date, _day)) continue;
            if (x.isIn) {
              inc += x.amt;
            } else if (x.cat != kGstHead) {
              exp += x.amt;
            }
          }
          final double newDue = value - paid + back;
          double soldAmt = 0;
          double soldKg = 0;
          double gotAmt = 0;
          for (final SaleItem x in saleItems()) {
            if (!sameDay(x.date, _day)) continue;
            if (x.kind == 'sale') {
              soldAmt += x.amt;
              soldKg += x.kg;
            } else if (x.kind == 'recv') {
              gotAmt += x.amt;
            }
          }

          String text() {
            final StringBuffer b = StringBuffer();
            b.writeln('Balaji Industries');
            b.writeln('${bi('આજનો હિસાબ', 'Day account')} - ${dmy(_day)}');
            b.writeln('------------------------');
            b.writeln('${bi('ચિઠ્ઠી', 'Chits')}: $chitN · ${grp(chitKg)} KG');
            b.writeln('${bi('કાંટો', 'Kanta')}: $kantaN · ${grp(kantaKg)} KG');
            b.writeln('${bi('માલ બેગ', 'Maal bags')}: ${bi('આવ્યા', 'in')} $inB · ${bi('ગયા', 'out')} $outB');
            b.writeln('------------------------');
            b.writeln('${bi('ખરીદ રકમ', 'Purchase value')}: ${inr(value)}');
            b.writeln('${bi('ખેડૂતોને ચૂકવ્યા', 'Paid to farmers')}: ${inr(paid)}');
            b.writeln('${bi('ખર્ચ', 'Expenses')}: ${inr(exp)}');
            if (wages > 0) b.writeln('${bi('મજૂરી (બેગ મુજબ)', 'Labour (by bags)')}: ${inr(wages)}');
            if (inc > 0) b.writeln('${bi('આવક', 'Income')}: ${inr(inc)}');
            b.writeln('------------------------');
            b.writeln('${bi('ખેડૂતોના બાકીમાં વધારો', 'Added to farmer dues')}: ${signedInr(newDue)}');
            if (soldAmt > 0 || gotAmt > 0) {
              b.writeln('------------------------');
              b.writeln('${bi('વેચાણ', 'Sales')}: ${inr(soldAmt)} · ${grp(soldKg)} KG');
              b.writeln('${bi('ખરીદનાર પાસેથી મળ્યા', 'Received from buyers')}: ${inr(gotAmt)}');
            }
            return b.toString().trim();
          }

          return <Widget>[
            ScreenHeader(bi('આજનો હિસાબ', 'Day account'), sub: dmy(_day)),
            statusBanner(),
            Row(
              children: <Widget>[
                IconBtn('chevl', tip: bi('પાછળનો દિવસ', 'Previous day'), onTap: () => setState(() => _day = addDays(_day, -1))),
                Expanded(child: Center(child: dayButton(_day, _pick))),
                IconBtn('chev', tip: bi('આગળનો દિવસ', 'Next day'), onTap: sameDay(_day, DateTime.now()) ? null : () => setState(() => _day = addDays(_day, 1))),
              ],
            ),
            const SizedBox(height: 10),
            HeroCard(
              title: bi('ખરીદ રકમ', 'Purchase value'),
              value: inrC(value),
              unit: '',
              sub: '$chitN ${bi('ચિઠ્ઠી', 'chits')} · ${kgTxt(chitKg)}',
              chips: <HeroChip>[
                HeroChip('rupee', '${bi('ચૂકવ્યા', 'Paid')} ${inrC(paid)}'),
                HeroChip('wallet', '${bi('ખર્ચ', 'Expenses')} ${inrC(exp)}'),
              ],
            ),
            const SizedBox(height: 12),
            if (noRateKg > 0) noteBox('info', 'amber', bi('${kgTxt(noRateKg)} નો ભાવ નાખ્યો નથી (રકમમાં ગણ્યો નથી)', '${kgTxt(noRateKg)} has no rate (not counted)'), onTap: () => app.go('rates')),
            Panel(
              title: bi('આ દિવસનો સરવાળો', 'Totals of the day'),
              child: Column(
                children: <Widget>[
                  InfoRow(bi('ચિઠ્ઠી', 'Chits'), '$chitN · ${grp(chitKg)} KG'),
                  InfoRow(bi('કાંટો', 'Weighbridge'), '$kantaN · ${grp(kantaKg)} KG'),
                  InfoRow(bi('માલ બેગ આવ્યા / ગયા', 'Maal bags in / out'), '$inB / $outB'),
                  divider(),
                  InfoRow(bi('ખરીદ રકમ', 'Purchase value'), inr(value)),
                  InfoRow(bi('ખેડૂતોને ચૂકવ્યા', 'Paid to farmers'), inr(paid)),
                  if (back > 0) InfoRow(bi('પાછા લીધા', 'Taken back'), inr(back)),
                  InfoRow(bi('ખેડૂતોના બાકીમાં વધારો', 'Added to farmer dues'), signedInr(newDue), bold: true, color: balColor(newDue)),
                  divider(),
                  InfoRow(bi('ખર્ચ', 'Expenses'), inr(exp)),
                  if (wages > 0) InfoRow(bi('મજૂરી (બેગ મુજબ)', 'Labour (by bags)'), inr(wages)),
                  if (inc > 0) InfoRow(bi('આવક', 'Income'), inr(inc)),
                  InfoRow(bi('કુલ ખર્ચ', 'Total outgo'), inr(exp + wages), bold: true),
                  if (soldAmt > 0 || gotAmt > 0) ...<Widget>[
                    divider(),
                    InfoRow(bi('વેચાણ', 'Sales'), '${inr(soldAmt)} · ${grp(soldKg)} KG'),
                    InfoRow(bi('ખરીદનાર પાસેથી મળ્યા', 'Received from buyers'), inr(gotAmt), bold: true, color: Pal.ok),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                tExp(child: Btn('WhatsApp', icon: 'chat', onTap: () => whatsappText(text()))),
                const SizedBox(width: 8),
                tExp(child: Btn(bi('કૉપિ', 'Copy'), icon: 'copy', kind: BtnKind.tonal, onTap: () => copyText(text()))),
              ],
            ),
          ];
        },
      ),
    );
  }
}
