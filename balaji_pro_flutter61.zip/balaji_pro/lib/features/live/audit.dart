import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/device.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/engine.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../widgets/common.dart';
import '../../widgets/page.dart';
import 'kit2.dart';
import 'ui.dart';

String _ruleIcon(Rule r) {
  switch (r) {
    case Rule.mismatch:
      return 'cmp';
    case Rule.noKanta:
      return 'scale';
    case Rule.noChit:
      return 'receipt';
    case Rule.rstGap:
      return 'rule';
    case Rule.dup:
      return 'copy';
    case Rule.photo:
      return 'img';
    case Rule.odd:
      return 'warn';
    case Rule.pattern:
      return 'query';
  }
}

String _sevTone(int sev) => sev >= 2 ? 'rose' : (sev == 1 ? 'amber' : 'slate');

void openFinding(BuildContext context, Finding f) {
  if (f.trip != null) {
    showTripDetail(context, f.trip!);
  } else if (f.chit != null) {
    showChitDetail(context, f.chit!);
  } else if (f.kanta != null) {
    showKantaDetail(context, f.kanta!);
  } else if (f.maal != null) {
    showMaalDetail(context, f.maal!);
  }
}

Widget findingTile(BuildContext context, Finding f, {bool check = true}) {
  final String tone = _sevTone(f.sev);
  final bool tappable = f.trip != null || f.chit != null || f.kanta != null || f.maal != null;
  return rowShell(
    onTap: tappable ? () => openFinding(context, f) : null,
    bar: Pal.tone(tone).fg,
    child: Row(
      children: <Widget>[
        IconChip(_ruleIcon(f.rule), tone: tone, size: 38),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(f.title(), maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(13.5, w: FontWeight.w800, h: 1.25)),
              const SizedBox(height: 3),
              Text(f.detail(), maxLines: 3, overflow: TextOverflow.ellipsis, style: ts(12, c: Pal.muted, h: 1.3)),
            ],
          ),
        ),
        const SizedBox(width: 8),
        Text(dayLabel(f.at), style: ts(11.5, c: Pal.muted)),
        if (check && live.isAdmin)
          IconBtn(
            'check',
            size: 36,
            tip: bi('જોઈ લીધું', 'Mark as checked'),
            color: Pal.ok,
            onTap: () {
              live.setReviewed(<Finding>[f], true);
              app.toast(bi('જોઈ લીધું - ફરી જોવા માટે "જોઈ લીધેલા" માં છે', 'Marked as checked'));
            },
          ),
      ],
    ),
  );
}

// =================================================================== audit
/// Everything the app found suspicious, with a filter per kind.
class AuditScreen extends StatefulWidget {
  final Rule? rule;
  const AuditScreen({super.key, this.rule});

  @override
  State<AuditScreen> createState() => _AuditScreenState();
}

class _AuditScreenState extends State<AuditScreen> {
  late int _i = widget.rule == null ? 0 : Rule.values.indexOf(widget.rule!) + 1;
  int _n = 50;

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 1000,
      rows: (BuildContext ctx) {
        final List<Finding> open = live.openFindings;
        final int nRev = live.findings.length - open.length;
        final List<int> cnt = List<int>.filled(Rule.values.length, 0);
        for (final Finding f in open) {
          cnt[f.rule.index]++;
        }
        final List<String> labels = <String>['${bi('બધા', 'All')} ${open.length}'];
        for (final Rule r in Rule.values) {
          labels.add('${ruleName(r)} ${cnt[r.index]}');
        }
        final List<Finding> l = _i == 0 ? open : open.where((Finding f) => f.rule == Rule.values[_i - 1]).toList();
        return <Widget>[
          ScreenHeader(
            _i == 0 ? bi('ધ્યાનમાં લો', 'Attention') : ruleName(Rule.values[_i - 1]),
            exact: true,
            sub: '${l.length}',
            actions: <Widget>[
              if (live.isAdmin && nRev > 0) Btn('${bi('જોઈ લીધેલા', 'Checked')} $nRev', icon: 'check', dense: true, kind: BtnKind.tonal, onTap: () => app.go('reviewed')),
              refreshBtn(),
            ],
          ),
          statusBanner(),
          ChipRow(labels: labels, index: _i, onChanged: (int i) => setState(() {
                _i = i;
                _n = 50;
              })),
          const SizedBox(height: 14),
          if (live.isAdmin && l.length > 1)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Btn(bi('આ બધા જોઈ લીધા (${l.length})', 'Mark all as checked (${l.length})'), icon: 'check', dense: true, kind: BtnKind.outline, onTap: () async {
                final bool? ok = await showDialog<bool>(
                  context: ctx,
                  builder: (BuildContext c) => AlertDialog(
                    title: Text(bi('${l.length} બાબત જોઈ લીધી?', 'Mark ${l.length} as checked?')),
                    content: Text(bi('તે "તપાસ માંગે છે" માંથી નીકળી જશે. પાછું લાવી શકાય છે.', 'They leave "needs checking". You can bring them back.')),
                    actions: <Widget>[
                      TextButton(onPressed: () => Navigator.of(c).pop(false), child: Text(bi('ના', 'No'))),
                      TextButton(onPressed: () => Navigator.of(c).pop(true), child: Text(bi('હા', 'Yes'))),
                    ],
                  ),
                );
                if (ok == true) live.setReviewed(l, true);
              }),
            ),
          if (!live.isAdmin)
            EmptyBox(icon: 'lock', title: bi('આ ફક્ત માલિક માટે છે', 'Owner only'))
          else if (l.isEmpty)
            EmptyBox(icon: 'check', title: bi('બધું બરાબર છે', 'All clear'))
          else
            for (final Finding f in l.take(_n)) findingTile(ctx, f),
          if (_n < l.length) Btn(bi('વધુ બતાવો (${l.length - _n})', 'Show more (${l.length - _n})'), kind: BtnKind.tonal, expand: true, onTap: () => setState(() => _n += 50)),
        ];
      },
    );
  }
}

// =================================================================== today
class TodayScreen extends StatefulWidget {
  const TodayScreen({super.key});

  @override
  State<TodayScreen> createState() => _TodayScreenState();
}

class _TodayScreenState extends State<TodayScreen> {
  int _i = 0;

  String _report(DateTime d) {
    final DateTime e = d.add(const Duration(days: 1));
    bool inDay(DateTime x) => !x.isBefore(d) && x.isBefore(e);
    final List<Chit> cs = live.chits.where((Chit x) => inDay(x.at)).toList();
    final List<Kanta> ks = live.kantas.where((Kanta x) => inDay(x.at)).toList();
    final List<MaalRow> ms = live.maals.where((MaalRow x) => inDay(x.date)).toList();
    final List<Trip> ts = live.trips.where((Trip x) => inDay(x.at)).toList();
    double ck = 0;
    for (final Chit x in cs) {
      ck += x.cmpKg;
    }
    double kk = 0;
    for (final Kanta x in ks) {
      kk += x.kg;
    }
    double df = 0;
    double mt = 0;
    for (final Trip t in ts) {
      if (t.both) {
        df += t.diff;
        mt += t.chitKg;
      }
    }
    int bin = 0;
    int bout = 0;
    for (final MaalRow x in ms) {
      if (x.loading) {
        bout += x.bags;
      } else {
        bin += x.bags;
      }
    }
    final StringBuffer b = StringBuffer();
    b.writeln('${dmy(d)} (${dayName(d)})');
    b.writeln('-----------------------');
    b.writeln('${bi('ચિઠ્ઠી', 'Chits')}: ${cs.length} | ${grp(ck)} KG');
    b.writeln('${bi('કાંટો', 'Kanta')}: ${ks.length} | ${grp(kk)} KG');
    if (live.isAdmin) {
      b.writeln('${bi('ફરક (મેળ થયેલ)', 'Difference (matched)')}: ${sk(df)} KG${mt > 0 ? ' (${(df / mt * 100).toStringAsFixed(2)}%)' : ''}');
    }
    b.writeln('${bi('માલ', 'Maal')}: ${bi('અંદર', 'in')} $bin ${bi('બેગ', 'bags')} | ${bi('બહાર', 'out')} $bout ${bi('બેગ', 'bags')}');
    if (ts.isNotEmpty) {
      b.writeln('');
      b.writeln(bi('ગાડી વાર:', 'Vehicle-wise:'));
      for (final Trip t in ts) {
        final String who = t.farmers.isEmpty ? '' : ' | ${t.farmers}';
        if (t.both) {
          b.writeln('• ${t.vehicle}$who | ${bi('ચિઠ્ઠી', 'Chit')} ${grp(t.chitKg)} → ${bi('કાંટો', 'Kanta')} ${grp(t.kantaKg)} | ${sk(t.diff)} [${stateLabel(t.state)}]');
        } else {
          b.writeln('• ${t.vehicle}$who | ${grp(t.chits.isEmpty ? t.kantaKg : t.chitKg)} KG [${stateLabel(t.state)}]');
        }
      }
    }
    final List<Finding> fs = live.openFindings.where((Finding f) => f.sev >= 2 && inDay(f.at)).toList();
    if (fs.isNotEmpty) {
      b.writeln('');
      b.writeln(bi('તપાસ:', 'To check:'));
      for (final Finding f in fs.take(15)) {
        b.writeln('• ${f.title()}');
      }
    }
    return b.toString().trim();
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 760,
      rows: (BuildContext ctx) {
        final DateTime today = dayOf(DateTime.now());
        final List<DateTime> days = <DateTime>[for (int i = 0; i < 7; i++) today.subtract(Duration(days: i))];
        final DateTime d = days[_i];
        final String text = _report(d);
        return <Widget>[
          ScreenHeader(bi('આજનો રિપોર્ટ', 'Day report'), sub: dmy(d), actions: <Widget>[refreshBtn()]),
          statusBanner(),
          ChipRow(labels: <String>[for (final DateTime x in days) dayLabel(x)], index: _i, onChanged: (int i) => setState(() => _i = i)),
          const SizedBox(height: 14),
          Surface(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                SelectableText(text, style: ts(13.5, h: 1.5, tab: true)),
                const SizedBox(height: 16),
                Btn(bi('કૉપિ કરો (WhatsApp માટે)', 'Copy (for WhatsApp)'), icon: 'copy', expand: true, onTap: () => copyText(text)),
              ],
            ),
          ),
        ];
      },
    );
  }
}

// =================================================================== search
class LiveSearchScreen extends StatefulWidget {
  const LiveSearchScreen({super.key});

  @override
  State<LiveSearchScreen> createState() => _LiveSearchState();
}

class _LiveSearchState extends State<LiveSearchScreen> {
  final TextEditingController _c = TextEditingController();
  String _q = '';

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 900,
      rows: (BuildContext ctx) {
        final String q = _q.trim().toLowerCase();
        final bool pc = DeviceScope.isPc(ctx);
        final List<Widget> out = <Widget>[];
        if (q.length >= 2) {
          final List<Chit> cs = live.chits.where((Chit x) => '${x.farmer} ${x.village} ${x.vehicle} ${x.no} ${x.broker} ${x.mobile} ${x.commodity}'.toLowerCase().contains(q)).toList();
          final List<Kanta> ks = live.kantas.where((Kanta x) => '${x.rst} ${x.vehicle} ${x.name}'.toLowerCase().contains(q)).toList();
          final List<MaalRow> ms = live.maals.where((MaalRow x) => '${x.vehicle} ${x.owner} ${x.material}'.toLowerCase().contains(q)).toList();
          if (cs.isEmpty && ks.isEmpty && ms.isEmpty) {
            out.add(EmptyBox(title: bi('કંઈ મળ્યું નથી', 'Nothing found')));
          }
          if (cs.isNotEmpty) {
            out.add(SectionTitle(bi('ચિઠ્ઠી', 'Chits'), sub: '${cs.length}'));
            out.add(const SizedBox(height: 8));
            out.addAll(cs.take(15).map((Chit x) => chitTile(ctx, x)));
          }
          if (ks.isNotEmpty) {
            out.add(const SizedBox(height: 8));
            out.add(SectionTitle(bi('કાંટો', 'Weighbridge'), sub: '${ks.length}'));
            out.add(const SizedBox(height: 8));
            out.addAll(ks.take(10).map((Kanta x) => kantaTile(ctx, x)));
          }
          if (ms.isNotEmpty) {
            out.add(const SizedBox(height: 8));
            out.add(SectionTitle(bi('માલ', 'Maal'), sub: '${ms.length}'));
            out.add(const SizedBox(height: 8));
            out.addAll(ms.take(10).map((MaalRow x) => maalTile(ctx, x)));
          }
        }
        if (q.length < 2) {
          Widget chips(String title, List<String> items) {
            if (items.isEmpty) return const SizedBox.shrink();
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                caption(title),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: <Widget>[
                    for (final String t in items)
                      Material(
                        color: Pal.soft,
                        borderRadius: BorderRadius.circular(99),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(99),
                          onTap: () {
                            _c.text = t;
                            setState(() => _q = t);
                          },
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
                            child: Text(t, style: ts(13, w: FontWeight.w700, c: Pal.brand)),
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 10),
              ],
            );
          }

          out.add(noteBox('bulb', 'teal', bi('ખેડૂત, ગાડી નંબર, ગામ, RST કે ચિઠ્ઠી નંબર લખો, અથવા નીચેનું તાજું નામ દબાવો.', 'Type a farmer, vehicle, village, RST or chit number - or tap a recent name below.')));
          out.add(chips(bi('તાજા ખેડૂત', 'RECENT FARMERS'), recentValues(live.chits.map((Chit x) => x.farmer), max: 10)));
          out.add(chips(bi('તાજી ગાડી', 'RECENT VEHICLES'), recentValues(<String>[...live.chits.map((Chit x) => x.vehicle), ...live.kantas.map((Kanta x) => x.vehicle)], max: 10)));
          out.add(chips(bi('તાજા ગામ', 'RECENT VILLAGES'), recentValues(live.chits.map((Chit x) => x.village), max: 10)));
        }
        return <Widget>[
          ScreenHeader(bi('બધે શોધો', 'Search everything')),
          SearchBox(hint: bi('ખેડૂત, ગાડી, ગામ, RST, નંબર…', 'Farmer, vehicle, village, RST, no…'), controller: _c, width: pc ? 420 : null, onChanged: (String v) => setState(() => _q = v)),
          const SizedBox(height: 14),
          ...out,
        ];
      },
    );
  }
}

// ================================================================== history
String _colName(String k) {
  switch (k) {
    case 'gross_weight_kg':
      return bi('કુલ વજન', 'Gross');
    case 'weight_kg':
      return bi('ચોખ્ખું વજન', 'Net');
    case 'net_weight_kg':
      return bi('કાંટો ચોખ્ખું', 'Kanta net');
    case 'total_weight_kg':
      return bi('કાંટો કુલ', 'Kanta total');
    case 'bardan_kg':
      return bi('બારદાન', 'Bardan');
    case 'kardo_kg':
      return bi('કરદો', 'Kardo');
    case 'vehicle_number':
      return bi('ગાડી', 'Vehicle');
    case 'farmer_name':
      return bi('ખેડૂત', 'Farmer');
    case 'village_name':
      return bi('ગામ', 'Village');
    case 'broker_name':
      return bi('દલાલ', 'Broker');
    case 'chiththi_number':
      return bi('ચિઠ્ઠી નં.', 'Chit no.');
    case 'rst_no':
      return 'RST';
    case 'bags':
      return bi('બેગ', 'Bags');
    case 'commodity_type':
    case 'material_type':
      return bi('માલ', 'Material');
    case 'owner_name':
      return bi('માલિક', 'Owner');
    case 'farmer_mobile':
      return bi('મોબાઇલ', 'Mobile');
  }
  return k;
}

String _tableName(String t) {
  if (t == 'chiththis') return bi('ચિઠ્ઠી', 'Chit');
  if (t == 'waybridge_entries') return bi('કાંટો', 'Kanta');
  if (t == 'maal_entries') return bi('માલ', 'Maal');
  return t;
}

String _rowBrief(Map<String, dynamic> r) {
  final List<String> p = <String>[];
  for (final String k in <String>['chiththi_number', 'rst_no', 'farmer_name', 'vehicle_number', 'material_type']) {
    final String v = str(r[k]);
    if (v.isNotEmpty) p.add(v);
  }
  final String w = str(r['weight_kg']).isNotEmpty ? str(r['weight_kg']) : str(r['net_weight_kg']);
  if (w.isNotEmpty) p.add('$w KG');
  return p.join(' · ');
}

/// Who edited or deleted an entry (owner only).
class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryState();
}

class _HistoryState extends State<HistoryScreen> {
  List<Map<String, dynamic>>? _rows;
  String _err = '';
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _busy = true;
      _err = '';
    });
    try {
      final List<Map<String, dynamic>> r = await live.loadHistory();
      if (!mounted) return;
      setState(() {
        _rows = r;
        _busy = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _err = '$e';
        _busy = false;
      });
    }
  }

  Map<String, dynamic> _map(Object? o) => o is Map ? Map<String, dynamic>.from(o) : <String, dynamic>{};

  void _open(BuildContext ctx, Map<String, dynamic> h) {
    final bool del = str(h['action']) == 'DELETE';
    final Map<String, dynamic> o = _map(h['old_row']);
    final Map<String, dynamic> n = _map(h['new_row']);
    final List<Widget> rows = <Widget>[];
    if (del) {
      o.forEach((String k, dynamic v) {
        if (v == null || str(v).isEmpty || k == 'created_by' || k.endsWith('_url') || k == 'id') return;
        rows.add(InfoRow(_colName(k), str(v)));
      });
    } else {
      n.forEach((String k, dynamic v) {
        if ('${o[k]}' != '$v' && k != 'updated_at') {
          rows.add(InfoRow(_colName(k), '${str(o[k]).isEmpty ? '—' : str(o[k])}  →  ${str(v).isEmpty ? '—' : str(v)}', bold: true));
        }
      });
    }
    openPanel(
      ctx,
      title: '${_tableName(str(h['table_name']))} · ${del ? bi('કાઢી નાખી', 'Deleted') : bi('સુધારી', 'Edited')}',
      sub: '${majurName(live.names, str(h['actor_id']))} · ${parseTs(h['changed_at']) == null ? '' : '${dmy(parseTs(h['changed_at'])!)} ${hm(parseTs(h['changed_at'])!)}'}',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          ...rows,
          const SizedBox(height: 14),
          Btn(bi('આ ફેરફાર પાછો લાવો', 'Restore this'), icon: 'undo', kind: BtnKind.tonal, expand: true, onTap: () async {
            final bool? ok = await showDialog<bool>(
              context: ctx,
              builder: (BuildContext c) => AlertDialog(
                title: Text(bi('પાછું લાવવું છે?', 'Restore?')),
                content: Text(del ? bi('કાઢી નાખેલી એન્ટ્રી ફરી ઉમેરાશે.', 'The deleted entry will be added back.') : bi('જૂની કિંમતો પાછી મુકાશે.', 'Old values will be put back.')),
                actions: <Widget>[
                  TextButton(onPressed: () => Navigator.of(c).pop(false), child: Text(bi('ના', 'No'))),
                  TextButton(onPressed: () => Navigator.of(c).pop(true), child: Text(bi('હા', 'Yes'))),
                ],
              ),
            );
            if (ok != true) return;
            final String? e = await live.restoreHistory(str(h['id']));
            if (ctx.mounted) Navigator.of(ctx).pop();
            if (e != null) {
              showMsg(e);
            } else {
              showMsg(bi('પાછું લવાયું', 'Restored'));
            }
          }),
        ],
      ),
    );
  }

  void showMsg(String m) => app.toast(m);

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>>? rows = _rows;
    return LiveBody(
      maxWidth: 900,
      rows: (BuildContext ctx) {
        return <Widget>[
          ScreenHeader(bi('ફેરફાર ઇતિહાસ', 'Change history'), sub: rows == null ? null : '${rows.length}', actions: <Widget>[IconBtn('refresh', onTap: _load)]),
          if (!live.isAdmin)
            EmptyBox(icon: 'lock', title: bi('આ ફક્ત માલિક માટે છે', 'Owner only'))
          else if (_busy && rows == null)
            const Padding(padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator()))
          else if (_err.isNotEmpty)
            EmptyBox(icon: 'err', title: _err)
          else if (rows == null || rows.isEmpty)
            EmptyBox(icon: 'hist', title: bi('હજી કોઈ ફેરફાર નથી', 'No changes yet'))
          else
            for (final Map<String, dynamic> h in rows)
              rowShell(
                onTap: () => _open(ctx, h),
                bar: str(h['action']) == 'DELETE' ? Pal.bad : Pal.warn,
                child: Row(
                  children: <Widget>[
                    IconChip(str(h['action']) == 'DELETE' ? 'trash' : 'edit', tone: str(h['action']) == 'DELETE' ? 'rose' : 'amber', size: 38),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text('${_tableName(str(h['table_name']))} · ${str(h['action']) == 'DELETE' ? bi('કાઢી નાખી', 'Deleted') : bi('સુધારી', 'Edited')}', style: ts(13.5, w: FontWeight.w800)),
                          const SizedBox(height: 2),
                          Text(_rowBrief(_map(h['old_row'])), maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(12, c: Pal.muted)),
                          Text(majurName(live.names, str(h['actor_id'])), style: ts(11.5, c: Pal.faint)),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(parseTs(h['changed_at']) == null ? '' : whenTxt(parseTs(h['changed_at'])!), style: ts(11.5, c: Pal.muted)),
                  ],
                ),
              ),
        ];
      },
    );
  }
}
