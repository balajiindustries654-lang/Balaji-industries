import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/app_state.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../widgets/common.dart';
import '../../widgets/launch.dart';
import 'kit2.dart' show noteBox;

// ======================================================================
// Calculator + Hisab (same working as the web app)
//   weight - bardan - hava%  ->  net  ->  mann  ->  rate  ->  amount
// ======================================================================

/// Reads a typed number: Gujarati / Hindi digits, commas and spaces are fine.
/// Returns NaN when it is empty or not a number.
double hisabNum(String s) {
  final String t = s.trim();
  if (t.isEmpty) return double.nan;
  final StringBuffer b = StringBuffer();
  for (final int c in t.runes) {
    if (c >= 0x0AE6 && c <= 0x0AEF) {
      b.writeCharCode(c - 0x0AE6 + 48);
    } else if (c >= 0x0966 && c <= 0x096F) {
      b.writeCharCode(c - 0x0966 + 48);
    } else if (c == 44 || c == 32) {
      // thousands comma / space: ignored
    } else {
      b.writeCharCode(c);
    }
  }
  String x = b.toString();
  if (x.endsWith('.')) x = x.substring(0, x.length - 1);
  if (!RegExp(r'^\d*\.?\d+$').hasMatch(x)) return double.nan;
  return double.tryParse(x) ?? double.nan;
}

double _r3(double n) => (n * 1000).round() / 1000;

class HisabIn {
  final String w;
  final String bardan;
  final String hava;
  final String dameg;
  final String other;
  final String utaro;
  final String rate;
  final String daana;
  final String base;
  final String baseU;
  final String step;
  final int mode; // 0 direct rate, 1 daana x utaro, 2 base +- utaro
  final int unit; // 1, 20 or 40 KG
  const HisabIn({
    this.w = '',
    this.bardan = '',
    this.hava = '',
    this.dameg = '',
    this.other = '',
    this.utaro = '',
    this.rate = '',
    this.daana = '',
    this.base = '',
    this.baseU = '',
    this.step = '',
    this.mode = 1,
    this.unit = 20,
  });
}

class HisabOut {
  bool ok = false;
  final List<String> errors = <String>[];
  int mode = 1;
  int unit = 20;
  double w = 0;
  double bardan = 0;
  double havaPct = 0;
  double damegPct = 0;
  double other = 0;
  double? utaro;
  double net0 = 0;
  double havaKg = 0;
  double net = 0;
  double mann = 0;
  double quintal = 0;
  bool weightOk = false;
  double daana = double.nan;
  double base = double.nan;
  double baseU = double.nan;
  double step = 0;
  double rate = double.nan;
  bool rateOk = false;
  double perKg = 0;
  double perQuintal = 0;
  int gross = 0;
  int damegAmt = 0;
  int otherAmt = 0;
  int amount = 0;
  bool amountOk = false;
}

/// One rule, always the same order:
///  net0 = weight - bardan; hava is taken out of the weight; mann = net / unit;
///  rate = direct | daana x utaro% | base + (utaro - base utaro) x step;
///  gross = round(mann x rate); damage % is taken out of the amount; then other deductions.
HisabOut hisabCompute(HisabIn i) {
  final HisabOut o = HisabOut();
  o.mode = (i.mode >= 0 && i.mode <= 2) ? i.mode : 1;
  o.unit = (i.unit == 1 || i.unit == 20 || i.unit == 40) ? i.unit : 20;
  final double w = hisabNum(i.w);
  final double bd = hisabNum(i.bardan);
  final double hv = hisabNum(i.hava);
  final double dm = hisabNum(i.dameg);
  final double ot = hisabNum(i.other);
  final double u = hisabNum(i.utaro);
  o.w = w.isNaN ? 0 : w;
  o.bardan = bd.isNaN ? 0 : bd;
  o.havaPct = hv.isNaN ? 0 : hv;
  o.damegPct = dm.isNaN ? 0 : dm;
  o.other = ot.isNaN ? 0 : ot;
  o.utaro = u.isNaN ? null : u;
  if (!(w > 0)) {
    o.errors.add('w');
    return o;
  }
  final double net0 = w - o.bardan;
  if (!(net0 > 0)) {
    o.errors.add('bardan');
    return o;
  }
  if (o.havaPct < 0 || o.havaPct >= 100) o.errors.add('hava');
  if (o.damegPct < 0 || o.damegPct >= 100) o.errors.add('dameg');
  if (o.errors.isNotEmpty) return o;
  o.net0 = _r3(net0);
  o.havaKg = _r3(net0 * o.havaPct / 100);
  o.net = _r3(net0 - o.havaKg);
  o.mann = o.net / o.unit;
  o.quintal = o.net / 100;
  o.weightOk = o.net > 0;
  double r = double.nan;
  if (o.mode == 0) {
    r = hisabNum(i.rate);
  } else if (o.mode == 1) {
    o.daana = hisabNum(i.daana);
    if (!u.isNaN && (u < 0 || u > 100)) {
      o.errors.add('utaro');
    } else if (o.daana > 0 && u > 0) {
      r = o.daana * u / 100;
    }
  } else {
    o.base = hisabNum(i.base);
    o.baseU = hisabNum(i.baseU);
    final double st = hisabNum(i.step);
    o.step = st.isNaN ? 0 : st;
    if (!u.isNaN && (u < 0 || u > 100)) {
      o.errors.add('utaro');
    } else if (o.base > 0 && !o.baseU.isNaN && !u.isNaN) {
      r = o.base + (u - o.baseU) * o.step;
    }
  }
  o.rate = (!r.isNaN && r > 0) ? (r * 100).round() / 100 : double.nan;
  o.rateOk = !o.rate.isNaN;
  o.ok = o.weightOk && o.errors.isEmpty;
  if (o.rateOk && o.ok) {
    o.perKg = o.rate / o.unit;
    o.perQuintal = o.rate * 100 / o.unit;
    o.gross = (o.mann * o.rate).round();
    o.damegAmt = (o.gross * o.damegPct / 100).round();
    o.otherAmt = o.other.round();
    o.amount = o.gross - o.damegAmt - o.otherAmt;
    o.amountOk = true;
  }
  return o;
}

/// Sample helper: grams -> percentages (utaro, hava, damage).
class HisabSample {
  double? utaro;
  double? hava;
  double? dameg;
}

HisabSample hisabSample(String sample, String daana, String hava, String damage) {
  final double s = hisabNum(sample);
  final double d = hisabNum(daana);
  final double h = hisabNum(hava);
  final double m = hisabNum(damage);
  final HisabSample o = HisabSample();
  if (s > 0 && d >= 0 && d <= s) o.utaro = (d / s * 10000).round() / 100;
  if (s > 0 && h >= 0 && h < s) o.hava = (h / s * 10000).round() / 100;
  if (d > 0 && m >= 0 && m <= d) o.dameg = (m / d * 10000).round() / 100;
  return o;
}

// ---------------------------------------------------------- expression maths
class _Val {
  final double v;
  final bool pct;
  const _Val(this.v, this.pct);
}

class _Expr {
  final String s;
  int i = 0;
  _Expr(this.s);

  double _number() {
    final int st = i;
    while (i < s.length) {
      final int c = s.codeUnitAt(i);
      if ((c >= 48 && c <= 57) || c == 46) {
        i++;
      } else {
        break;
      }
    }
    if (st == i) throw const FormatException('n');
    final String t = s.substring(st, i);
    if ('.'.allMatches(t).length > 1) throw const FormatException('n');
    final double? v = double.tryParse(t);
    if (v == null) throw const FormatException('n');
    return v;
  }

  _Val _factor() {
    bool neg = false;
    while (i < s.length && (s[i] == '-' || s[i] == '+')) {
      if (s[i] == '-') neg = !neg;
      i++;
    }
    double v = _number();
    bool pct = false;
    while (i < s.length && s[i] == '%') {
      v = v / 100;
      pct = true;
      i++;
    }
    return _Val(neg ? -v : v, pct);
  }

  _Val _term() {
    _Val a = _factor();
    while (i < s.length && (s[i] == '*' || s[i] == '/')) {
      final String op = s[i];
      i++;
      final _Val b = _factor();
      if (op == '/' && b.v == 0) throw const FormatException('div');
      a = _Val(op == '*' ? a.v * b.v : a.v / b.v, false);
    }
    return a;
  }

  double expr() {
    double a = _term().v;
    while (i < s.length && (s[i] == '+' || s[i] == '-')) {
      final String op = s[i];
      i++;
      final _Val b = _term();
      final double rhs = b.pct ? a * b.v : b.v;
      a = op == '+' ? a + rhs : a - rhs;
    }
    return a;
  }
}

/// Safe calculator maths (no eval). "200+10%" means 200 + 10% of 200.
double evalExpr(String src) {
  final String s = src.replaceAll('×', '*').replaceAll('÷', '/').replaceAll('−', '-').replaceAll(RegExp(r'\s+'), '');
  if (s.isEmpty) return double.nan;
  try {
    final _Expr p = _Expr(s);
    final double v = p.expr();
    if (p.i != s.length || v.isNaN || v.isInfinite) return double.nan;
    return (v * 1e9).round() / 1e9;
  } catch (_) {
    return double.nan;
  }
}

/// 12345.6 -> "12,345.6" (Indian grouping, trailing zeros removed).
String _fmtN(double n, [int d = 6]) {
  if (n.isNaN || n.isInfinite) return '—';
  String s = grp(n, dec: d);
  if (d > 0 && s.contains('.')) {
    s = s.replaceFirst(RegExp(r'0+$'), '');
    if (s.endsWith('.')) s = s.substring(0, s.length - 1);
  }
  if (s == '-0') s = '0';
  return s;
}

String _plain(double v) {
  String s = v.toStringAsFixed(9);
  if (s.contains('.')) {
    s = s.replaceFirst(RegExp(r'0+$'), '');
    if (s.endsWith('.')) s = s.substring(0, s.length - 1);
  }
  return s;
}

String _todayKey() {
  final DateTime d = DateTime.now();
  return '${d.year}-${pad2(d.month)}-${pad2(d.day)}';
}

// ---------------------------------------------------------------- the state
/// Lives as long as the app, so a half-done hisab is still there when the
/// calculator is closed and opened again. Rates are also kept on the phone.
class _HisabStore {
  final TextEditingController w = TextEditingController();
  final TextEditingController bardan = TextEditingController();
  final TextEditingController hava = TextEditingController();
  final TextEditingController dameg = TextEditingController();
  final TextEditingController other = TextEditingController();
  final TextEditingController utaro = TextEditingController();
  final TextEditingController rate = TextEditingController();
  final TextEditingController daana = TextEditingController();
  final TextEditingController base = TextEditingController();
  final TextEditingController baseU = TextEditingController();
  final TextEditingController step = TextEditingController();
  final TextEditingController sSample = TextEditingController();
  final TextEditingController sDaana = TextEditingController();
  final TextEditingController sHava = TextEditingController();
  final TextEditingController sDam = TextEditingController();
  int mode = 1;
  int unit = 20;
  String rateDate = '';
  bool loaded = false;
  List<Map<String, dynamic>> hist = <Map<String, dynamic>>[];
  // keypad
  String expr = '';
  bool fresh = false;
  bool invalid = false;
  final List<List<String>> khist = <List<String>>[]; // [expression, result]

  Map<String, TextEditingController> get inputs => <String, TextEditingController>{
        'w': w,
        'bardan': bardan,
        'hava': hava,
        'dameg': dameg,
        'other': other,
        'utaro': utaro,
        'rate': rate,
        'daana': daana,
        'base': base,
        'baseU': baseU,
        'step': step,
      };

  List<String> get rateKeys => <String>['rate', 'daana', 'base', 'baseU', 'step'];

  Future<void> load() async {
    if (loaded) return;
    loaded = true;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      final int m = p.getInt('hisab_mode') ?? 1;
      mode = (m >= 0 && m <= 2) ? m : 1;
      final int u = p.getInt('hisab_unit') ?? 20;
      unit = (u == 1 || u == 20 || u == 40) ? u : 20;
      final String? r = p.getString('hisab_rates');
      if (r != null) {
        final Object? d = jsonDecode(r);
        if (d is Map) {
          rateDate = (d['d'] ?? '').toString();
          for (final String k in rateKeys) {
            final TextEditingController? c = inputs[k];
            if (c != null && c.text.isEmpty) c.text = (d[k] ?? '').toString();
          }
        }
      }
      final String? h = p.getString('hisab_hist');
      if (h != null) {
        final Object? d = jsonDecode(h);
        if (d is List) {
          hist = <Map<String, dynamic>>[
            for (final Object? e in d)
              if (e is Map) Map<String, dynamic>.from(e),
          ];
        }
      }
    } catch (_) {}
  }

  Future<void> saveMode() async {
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setInt('hisab_mode', mode);
      await p.setInt('hisab_unit', unit);
    } catch (_) {}
  }

  Future<void> saveRates() async {
    rateDate = _todayKey();
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      final Map<String, String> m = <String, String>{'d': rateDate};
      for (final String k in rateKeys) {
        final String t = inputs[k]?.text ?? '';
        if (t.isNotEmpty) m[k] = t;
      }
      await p.setString('hisab_rates', jsonEncode(m));
    } catch (_) {}
  }

  Future<void> saveHist() async {
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setString('hisab_hist', jsonEncode(hist));
    } catch (_) {}
  }

  HisabIn input(bool admin) {
    return HisabIn(
      w: w.text,
      bardan: bardan.text,
      hava: hava.text,
      dameg: admin ? dameg.text : '',
      other: admin ? other.text : '',
      utaro: utaro.text,
      rate: rate.text,
      daana: daana.text,
      base: base.text,
      baseU: baseU.text,
      step: step.text,
      mode: mode,
      unit: unit,
    );
  }

  void remember(HisabOut o, bool admin) {
    if (!o.ok) return;
    final Map<String, String> v = <String, String>{};
    inputs.forEach((String k, TextEditingController c) {
      if (c.text.isNotEmpty) v[k] = c.text;
    });
    final String key = jsonEncode(<Object>[mode, unit, v]);
    hist.removeWhere((Map<String, dynamic> x) => jsonEncode(<Object?>[x['mode'], x['unit'], x['v']]) == key);
    hist.insert(0, <String, dynamic>{
      't': DateTime.now().millisecondsSinceEpoch,
      'mode': mode,
      'unit': unit,
      'v': v,
      'net': o.net,
      'amt': (o.amountOk && admin) ? o.amount : null,
      'utaro': o.utaro,
    });
    if (hist.length > 20) hist = hist.sublist(0, 20);
    saveHist();
  }

  void restore(Map<String, dynamic> x) {
    final Object? m = x['mode'];
    final Object? u = x['unit'];
    mode = (m is int && m >= 0 && m <= 2) ? m : 1;
    unit = (u is int && (u == 1 || u == 20 || u == 40)) ? u : 20;
    final Object? v = x['v'];
    inputs.forEach((String k, TextEditingController c) {
      c.text = (v is Map && v[k] != null) ? v[k].toString() : '';
    });
    saveMode();
  }

  void newLot() {
    for (final TextEditingController c in <TextEditingController>[w, bardan, hava, dameg, other, utaro, sSample, sDaana, sHava, sDam]) {
      c.clear();
    }
  }
}

final _HisabStore _hs = _HisabStore();

// ------------------------------------------------------------------ the sheet
/// Opens the calculator from anywhere (phone: bottom sheet, PC: side panel).
Future<void> openCalcSheet(BuildContext context) {
  return openPanel(
    context,
    title: bi('કૅલ્ક્યુલેટર', 'Calculator'),
    sub: bi('વજન · ઉતારો · ભાવ · રકમ', 'Weight · utaro · rate · amount'),
    width: 480,
    child: const HisabCalc(),
  );
}

/// Hisab + the plain calculator (and optionally one more tab from the caller).
class HisabCalc extends StatefulWidget {
  final Widget? extra;
  final String extraLabel;
  const HisabCalc({super.key, this.extra, this.extraLabel = ''});

  @override
  State<HisabCalc> createState() => _HisabCalcState();
}

class _HisabCalcState extends State<HisabCalc> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    final List<String> labels = <String>[
      bi('હિસાબ', 'Hisab'),
      bi('કૅલ્ક્યુલેટર', 'Calculator'),
      if (widget.extra != null) widget.extraLabel,
    ];
    final int tab = _tab < labels.length ? _tab : 0;
    Widget body;
    if (tab == 0) {
      body = const _HisabPane();
    } else if (tab == 1) {
      body = const _KeypadPane();
    } else {
      body = widget.extra ?? const SizedBox.shrink();
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Seg(labels: labels, index: tab, onChanged: (int i) => setState(() => _tab = i)),
        const SizedBox(height: 14),
        body,
      ],
    );
  }
}

// ---------------------------------------------------------------- hisab tab
class _Ln {
  final String k;
  final String v;
  final String c; // '', 'minus', 'sum', 'dim'
  const _Ln(this.k, this.v, [this.c = '']);
}

class _HisabPane extends StatefulWidget {
  const _HisabPane();

  @override
  State<_HisabPane> createState() => _HisabPaneState();
}

class _HisabPaneState extends State<_HisabPane> {
  bool _showHist = false;
  bool _showSample = false;

  @override
  void initState() {
    super.initState();
    _hs.load().then((_) {
      if (mounted) setState(() {});
    });
  }

  void _chg([String? _]) => setState(() {});

  void _chgRate([String? _]) {
    setState(() {});
    _hs.saveRates();
  }

  Widget _f(String label, TextEditingController c, {String? suffix, String? prefix, bool big = false, bool rate = false}) {
    return FieldX(
      label: label,
      controller: c,
      suffix: suffix,
      prefix: prefix,
      big: big,
      keyboard: const TextInputType.numberWithOptions(decimal: true),
      onChanged: rate ? _chgRate : _chg,
    );
  }

  Widget _two(Widget a, Widget b) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[Expanded(child: a), const SizedBox(width: 10), Expanded(child: b)],
    );
  }

  String _mann() => bi('મણ', 'Mann');

  List<_Ln> _lines(HisabOut o, bool norate) {
    String kg(double n) => '${_fmtN(n, 3)} KG';
    String rs(num n) => '₹ ${_fmtN(n.toDouble(), 0)}';
    String rs2(double n) => '₹ ${_fmtN(n, 2)}';
    final String ms = o.unit == 1 ? ' / KG' : ' / ${_mann()}';
    final List<_Ln> a = <_Ln>[];
    a.add(_Ln(bi('વજન', 'Weight'), kg(o.w)));
    if (o.bardan > 0) a.add(_Ln('− ${bi('બારદાન / કાપ', 'Bardan / cut')}', kg(o.bardan), 'minus'));
    if (o.havaPct > 0) a.add(_Ln('− ${bi('હવા', 'Hava')} (${_fmtN(o.havaPct, 2)} %)', kg(o.havaKg), 'minus'));
    a.add(_Ln(bi('ચોખ્ખું વજન', 'Net weight'), kg(o.net), 'sum'));
    if (o.unit != 1) a.add(_Ln('${_mann()} (÷ ${o.unit} KG)', _fmtN(o.mann, 2)));
    a.add(_Ln(bi('ક્વિન્ટલ', 'Quintal'), _fmtN(o.quintal, 3), 'dim'));
    if (norate || !o.rateOk) return a;
    final double u = o.utaro ?? 0;
    if (o.mode == 1) {
      a.add(_Ln(bi('દાણા ભાવ', 'Daana rate'), rs2(o.daana) + ms));
      a.add(_Ln('× ${bi('ઉતારો', 'Utaro')}', '${_fmtN(u, 2)} %'));
      a.add(_Ln(bi('મગફળીનો ભાવ', 'Magfadi rate'), rs2(o.rate) + ms, 'sum'));
    } else if (o.mode == 2) {
      final double diff = ((u - o.baseU) * o.step * 100).round() / 100;
      a.add(_Ln('${bi('બેઝ ભાવ', 'Base rate')} (${_fmtN(o.baseU, 2)} %)', rs2(o.base) + ms));
      a.add(_Ln(
        '${diff < 0 ? '− ' : '+ '}${bi('ઉતારો', 'Utaro')} (${_fmtN(u, 2)} % → ${_fmtN(u - o.baseU, 2)} × ₹${_fmtN(o.step, 2)})',
        '${diff < 0 ? '− ' : '+ '}${rs2(diff.abs())}',
        diff < 0 ? 'minus' : '',
      ));
      a.add(_Ln(bi('મગફળીનો ભાવ', 'Magfadi rate'), rs2(o.rate) + ms, 'sum'));
    } else {
      a.add(_Ln(bi('ભાવ', 'Rate'), rs2(o.rate) + ms, 'sum'));
    }
    a.add(_Ln(bi('રકમ (મણ × ભાવ)', 'Amount (mann × rate)'), rs(o.gross)));
    if (o.damegPct > 0) a.add(_Ln('− ${bi('ડેમેજ', 'Damage')} (${_fmtN(o.damegPct, 2)} %)', rs(o.damegAmt), 'minus'));
    if (o.otherAmt > 0) a.add(_Ln('− ${bi('બીજી કપાત', 'Other deduction')}', rs(o.otherAmt), 'minus'));
    return a;
  }

  String _text(HisabOut o, bool norate) {
    final DateTime d = DateTime.now();
    final StringBuffer b = StringBuffer();
    b.writeln('⚖️ ${bi('હિસાબ', 'Hisab')} — ${pad2(d.day)}-${pad2(d.month)}-${d.year}');
    for (final _Ln l in _lines(o, norate)) {
      if (l.c != 'dim') b.writeln('${l.k}: ${l.v}');
    }
    if (o.amountOk && !norate) b.writeln('💰 ${bi('કુલ રકમ', 'Total amount')}: ₹ ${_fmtN(o.amount.toDouble(), 0)}');
    return b.toString().trimRight();
  }

  Widget _ledger(List<_Ln> ls) {
    return Column(
      children: <Widget>[
        for (final _Ln l in ls)
          Container(
            padding: const EdgeInsets.symmetric(vertical: 6),
            decoration: l.c == 'sum' ? BoxDecoration(border: Border(top: BorderSide(color: Pal.line))) : null,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Expanded(
                  child: Text(l.k, style: ts(13.5, w: l.c == 'sum' ? FontWeight.w800 : FontWeight.w500, c: l.c == 'dim' ? Pal.faint : (l.c == 'minus' ? Pal.bad : Pal.ink))),
                ),
                const SizedBox(width: 10),
                Text(l.v, style: ts(14, w: l.c == 'sum' ? FontWeight.w800 : FontWeight.w700, c: l.c == 'dim' ? Pal.faint : (l.c == 'minus' ? Pal.bad : Pal.ink), tab: true)),
              ],
            ),
          ),
      ],
    );
  }

  Widget _card(HisabOut o, bool norate) {
    String lbl = bi('કુલ રકમ', 'Total amount');
    String amt = '—';
    String sub = '';
    if (o.ok) {
      if (o.amountOk && !norate) {
        amt = '₹ ${_fmtN(o.amount.toDouble(), 0)}';
        sub = '${_fmtN(o.net, 3)} KG • ${_fmtN(o.mann, 2)} ${_mann()}';
      } else {
        lbl = bi('ચોખ્ખું વજન', 'Net weight');
        amt = '${_fmtN(o.net, 3)} KG';
        sub = norate ? '${_fmtN(o.mann, 2)} ${_mann()} • ${_fmtN(o.quintal, 3)} ${bi('ક્વિન્ટલ', 'quintal')}' : bi('ભાવ ઉમેરો — રકમ તરત દેખાશે.', 'Add the rate — the amount appears at once.');
      }
    }
    return Surface(
      color: Pal.side,
      border: false,
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(lbl, style: ts(13, c: Pal.sideText, w: FontWeight.w600)),
          FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(amt, style: ts(36, w: FontWeight.w800, c: Colors.white, tab: true, ls: -1))),
          if (sub.isNotEmpty) Text(sub, style: ts(13, c: Pal.sideText, w: FontWeight.w600)),
        ],
      ),
    );
  }

  Widget _chip(String label, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.only(right: 8, bottom: 8),
      child: Material(
        color: Pal.soft,
        borderRadius: BorderRadius.circular(Pal.rad(99)),
        child: InkWell(
          borderRadius: BorderRadius.circular(Pal.rad(99)),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            child: Text(label, style: ts(12.5, w: FontWeight.w700, c: Pal.brand)),
          ),
        ),
      ),
    );
  }

  List<Widget> _recentWeights() {
    final List<Kanta> ks = live.kantas.where((Kanta k) => k.kg > 0).toList();
    ks.sort((Kanta a, Kanta b) => b.at.compareTo(a.at));
    final List<Widget> out = <Widget>[];
    for (final Kanta k in ks.take(4)) {
      final String who = k.vehicle.isEmpty ? 'RST ${k.rst}' : k.vehicle;
      out.add(_chip('$who · ${grp(k.kg, dec: k.kg == k.kg.roundToDouble() ? 0 : 1)}', () {
        _hs.w.text = _plain(k.kg);
        _chg();
      }));
    }
    return out;
  }

  Widget _sample() {
    final HisabSample r = hisabSample(_hs.sSample.text, _hs.sDaana.text, _hs.sHava.text, _hs.sDam.text);
    final List<String> bits = <String>[
      if (r.utaro != null) '${bi('ઉતારો', 'Utaro')} ${_fmtN(r.utaro!, 2)} %',
      if (r.hava != null) '${bi('હવા', 'Hava')} ${_fmtN(r.hava!, 2)} %',
      if (r.dameg != null) '${bi('ડેમેજ', 'Damage')} ${_fmtN(r.dameg!, 2)} %',
    ];
    return Panel(
      title: bi('નમૂનાથી ઉતારો / હવા / ડેમેજ', 'Utaro / hava / damage from a sample'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          _two(_f(bi('નમૂનો (ગ્રામ)', 'Sample (g)'), _hs.sSample), _f(bi('દાણા (ગ્રામ)', 'Daana (g)'), _hs.sDaana)),
          const SizedBox(height: 12),
          _two(_f(bi('હવા (ગ્રામ)', 'Hava (g)'), _hs.sHava), _f(bi('ડેમેજ દાણા (ગ્રામ)', 'Damaged daana (g)'), _hs.sDam)),
          const SizedBox(height: 12),
          Text(bits.isEmpty ? '—' : bits.join('  •  '), style: ts(15, w: FontWeight.w800, c: Pal.brand)),
          const SizedBox(height: 10),
          Btn(
            bi('આ % ભરો', 'Use these %'),
            icon: 'check',
            kind: BtnKind.tonal,
            dense: true,
            onTap: bits.isEmpty
                ? null
                : () {
                    final double? u = r.utaro;
                    final double? h = r.hava;
                    final double? d = r.dameg;
                    if (u != null) _hs.utaro.text = _plain(u);
                    if (h != null) _hs.hava.text = _plain(h);
                    if (d != null) _hs.dameg.text = _plain(d);
                    setState(() => _showSample = false);
                    app.toast(bi('% ભરાઈ ગયા', 'Percentages filled'));
                  },
          ),
        ],
      ),
    );
  }

  Widget _history() {
    final bool admin = live.isAdmin;
    if (_hs.hist.isEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 20),
        child: Text(bi('હજી કંઈ યાદ રાખ્યું નથી. હિસાબ કરીને "યાદ રાખો" દબાવો.', 'Nothing saved yet. Do a hisab and press "Save".'), textAlign: TextAlign.center, style: ts(14, c: Pal.muted)),
      );
    }
    return Column(
      children: <Widget>[
        for (int i = 0; i < _hs.hist.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Surface(
              padding: const EdgeInsets.fromLTRB(14, 10, 6, 10),
              onTap: () {
                _hs.restore(_hs.hist[i]);
                setState(() => _showHist = false);
              },
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          (admin && _hs.hist[i]['amt'] is num) ? '₹ ${_fmtN((_hs.hist[i]['amt'] as num).toDouble(), 0)}' : '${_fmtN(((_hs.hist[i]['net'] ?? 0) as num).toDouble(), 1)} KG',
                          style: ts(16, w: FontWeight.w800, tab: true),
                        ),
                        Text(_histSub(_hs.hist[i]), style: ts(12.5, c: Pal.muted)),
                      ],
                    ),
                  ),
                  IconBtn('trash', size: 40, color: Pal.bad, tip: bi('કાઢો', 'Delete'), onTap: () {
                    setState(() => _hs.hist.removeAt(i));
                    _hs.saveHist();
                  }),
                ],
              ),
            ),
          ),
      ],
    );
  }

  String _histSub(Map<String, dynamic> x) {
    final Object? t = x['t'];
    String when = '';
    if (t is int) {
      final DateTime d = DateTime.fromMillisecondsSinceEpoch(t);
      when = '${pad2(d.day)}-${pad2(d.month)} ${pad2(d.hour)}:${pad2(d.minute)}';
    }
    final List<String> bits = <String>[when];
    final Object? net = x['net'];
    if (net is num) bits.add('${_fmtN(net.toDouble(), 1)} KG');
    final Object? u = x['utaro'];
    if (u is num && x['mode'] != 0) bits.add('${bi('ઉતારો', 'Utaro')} ${_fmtN(u.toDouble(), 2)}%');
    return bits.where((String s) => s.isNotEmpty).join('  •  ');
  }

  @override
  Widget build(BuildContext context) {
    final bool admin = live.isAdmin;
    final HisabOut o = hisabCompute(_hs.input(admin));
    final bool norate = !admin;
    final List<Widget> recent = _recentWeights();
    final String today = _todayKey();
    final bool hasRates = _hs.rateKeys.any((String k) => (_hs.inputs[k]?.text ?? '').isNotEmpty);
    final bool stale = admin && hasRates && _hs.rateDate.isNotEmpty && _hs.rateDate != today;

    String? err;
    if (o.errors.contains('bardan')) {
      err = bi('બારદાન વજન કરતાં વધુ છે.', 'Bardan is more than the weight.');
    } else if (o.errors.contains('hava')) {
      err = bi('હવા % 0 થી 100 ની અંદર લખો.', 'Hava % must be between 0 and 100.');
    } else if (o.errors.contains('dameg')) {
      err = bi('ડેમેજ % 0 થી 100 ની અંદર લખો.', 'Damage % must be between 0 and 100.');
    } else if (o.errors.contains('utaro')) {
      err = bi('ઉતારો % 0 થી 100 ની અંદર લખો.', 'Utaro % must be between 0 and 100.');
    }
    final bool empty = o.errors.contains('w');

    final List<Widget> rateFields = <Widget>[];
    if (admin) {
      if (_hs.mode == 0) {
        rateFields.add(_f('${bi('ભાવ', 'Rate')} (₹ / ${_hs.unit == 1 ? 'KG' : _mann()})', _hs.rate, prefix: '₹', rate: true));
      } else if (_hs.mode == 1) {
        rateFields.add(_two(
          _f('${bi('દાણા ભાવ', 'Daana rate')} (₹ / ${_hs.unit == 1 ? 'KG' : _mann()})', _hs.daana, prefix: '₹', rate: true),
          _f(bi('ઉતારો', 'Utaro'), _hs.utaro, suffix: '%'),
        ));
      } else {
        rateFields.add(_two(
          _f('${bi('બેઝ ભાવ', 'Base rate')} (₹ / ${_hs.unit == 1 ? 'KG' : _mann()})', _hs.base, prefix: '₹', rate: true),
          _f(bi('બેઝ ઉતારો', 'Base utaro'), _hs.baseU, suffix: '%', rate: true),
        ));
        rateFields.add(const SizedBox(height: 12));
        rateFields.add(_two(
          _f(bi('ઉતારો', 'Utaro'), _hs.utaro, suffix: '%'),
          _f('${bi('દર 1% ના', 'Per 1 %')} (₹ / ${_hs.unit == 1 ? 'KG' : _mann()})', _hs.step, prefix: '₹', rate: true),
        ));
      }
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              _f(bi('વજન', 'Weight'), _hs.w, suffix: 'KG', big: true),
              if (recent.isNotEmpty) ...<Widget>[
                const SizedBox(height: 10),
                Text(bi('છેલ્લા કાંટાનું વજન લો', 'Take a recent kanta weight'), style: ts(12, w: FontWeight.w700, c: Pal.muted)),
                const SizedBox(height: 6),
                Wrap(children: recent),
              ],
              const SizedBox(height: 4),
              _two(_f(bi('બારદાન / કાપ', 'Bardan / cut'), _hs.bardan, suffix: 'KG'), _f(bi('હવા', 'Hava'), _hs.hava, suffix: '%')),
              if (admin) ...<Widget>[
                const SizedBox(height: 12),
                _two(_f(bi('ડેમેજ', 'Damage'), _hs.dameg, suffix: '%'), _f(bi('બીજી કપાત', 'Other deduction'), _hs.other, prefix: '₹')),
              ],
            ],
          ),
        ),
        if (admin) ...<Widget>[
          const SizedBox(height: 12),
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                LineRow(label: bi('ભાવ પ્રતિ', 'Rate per'), child: ChipRow(
                  labels: const <String>['1 KG', '20 KG', '40 KG'],
                  index: _hs.unit == 1 ? 0 : (_hs.unit == 20 ? 1 : 2),
                  onChanged: (int i) {
                    setState(() => _hs.unit = <int>[1, 20, 40][i]);
                    _hs.saveMode();
                  },
                )),
                const SizedBox(height: 12),
                Seg(
                  labels: <String>[bi('સીધો ભાવ', 'Direct'), bi('દાણા × ઉતારો', 'Daana × utaro'), bi('બેઝ ± ઉતારો', 'Base ± utaro')],
                  index: _hs.mode,
                  onChanged: (int i) {
                    setState(() => _hs.mode = i);
                    _hs.saveMode();
                  },
                ),
                if (stale) ...<Widget>[
                  const SizedBox(height: 10),
                  noteBox('warn', 'amber', bi('આ ભાવ ${_hs.rateDate.substring(5)} નો છે — આજનો ભાવ નાખો.', 'These rates are from ${_hs.rateDate.substring(5)} — enter today\'s rate.')),
                ] else
                  const SizedBox(height: 12),
                ...rateFields,
              ],
            ),
          ),
        ],
        const SizedBox(height: 14),
        Row(
          children: <Widget>[
            tExp(child: Btn(bi('યાદ રાખો', 'Save'), icon: 'pin', kind: BtnKind.tonal, dense: true, onTap: o.ok ? () {
              _hs.remember(o, admin);
              app.toast(bi('યાદ રાખ્યું', 'Saved'));
              setState(() {});
            } : null)),
            const SizedBox(width: 8),
            tExp(child: Btn(bi('નવો હિસાબ', 'New lot'), icon: 'refresh', kind: BtnKind.outline, dense: true, onTap: () {
              _hs.newLot();
              setState(() {});
            })),
            const SizedBox(width: 8),
            tExp(child: Btn(_showHist ? bi('હિસાબ', 'Hisab') : bi('યાદી (${_hs.hist.length})', 'Saved (${_hs.hist.length})'), icon: 'hist', kind: BtnKind.outline, dense: true, onTap: () => setState(() => _showHist = !_showHist))),
          ],
        ),
        const SizedBox(height: 14),
        if (_showHist)
          _history()
        else ...<Widget>[
          _card(o, norate),
          const SizedBox(height: 10),
          if (empty)
            Text(bi('વજન લખો — ગણતરી અહીં દેખાશે.', 'Enter the weight — the working appears here.'), textAlign: TextAlign.center, style: ts(13.5, c: Pal.muted))
          else if (err != null)
            noteBox('warn', 'rose', err)
          else ...<Widget>[
            Surface(padding: const EdgeInsets.fromLTRB(14, 8, 14, 8), child: _ledger(_lines(o, norate))),
            if (!norate && !o.rateOk)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Text(
                  _hs.mode == 1
                      ? bi('દાણા ભાવ અને ઉતારો ઉમેરો.', 'Add the daana rate and utaro %.')
                      : (_hs.mode == 2 ? bi('બેઝ ભાવ, બેઝ ઉતારો અને ઉતારો ઉમેરો.', 'Add base rate, base utaro and utaro %.') : bi('ભાવ ઉમેરો — રકમ તરત દેખાશે.', 'Add the rate — the amount appears at once.')),
                  style: ts(13, c: Pal.muted),
                ),
              ),
            if (!norate && o.rateOk)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text('₹ ${_fmtN(o.perKg, 2)} / KG  •  ₹ ${_fmtN(o.perQuintal, 0)} / ${bi('ક્વિન્ટલ', 'quintal')}', textAlign: TextAlign.center, style: ts(12.5, w: FontWeight.w700, c: Pal.muted)),
              ),
            const SizedBox(height: 10),
            Row(
              children: <Widget>[
                tExp(child: Btn(bi('કૉપિ', 'Copy'), icon: 'copy', kind: BtnKind.tonal, dense: true, onTap: o.ok ? () => copyText(_text(o, norate)) : null)),
                const SizedBox(width: 8),
                tExp(child: Btn('WhatsApp', icon: 'chat', kind: BtnKind.tonal, dense: true, onTap: o.ok ? () => whatsappText(_text(o, norate)) : null)),
              ],
            ),
          ],
          const SizedBox(height: 10),
          Btn(
            _showSample ? bi('નમૂનો બંધ કરો', 'Close sample helper') : bi('નમૂનાથી ઉતારો / હવા / ડેમેજ કાઢો', 'Work out utaro / hava / damage from a sample'),
            icon: 'grain',
            kind: BtnKind.ghost,
            dense: true,
            onTap: () => setState(() => _showSample = !_showSample),
          ),
          if (_showSample) ...<Widget>[
            const SizedBox(height: 8),
            _sample(),
          ],
        ],
      ],
    );
  }
}

// --------------------------------------------------------------- keypad tab
class _KeypadPane extends StatefulWidget {
  const _KeypadPane();

  @override
  State<_KeypadPane> createState() => _KeypadPaneState();
}

class _KeypadPaneState extends State<_KeypadPane> {
  static const List<List<String>> _rows = <List<String>>[
    <String>['C', '⌫', '%', '÷'],
    <String>['7', '8', '9', '×'],
    <String>['4', '5', '6', '−'],
    <String>['1', '2', '3', '+'],
    <String>['00', '0', '.', '='],
  ];

  final FocusNode _fn = FocusNode(debugLabel: 'calcpad');

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((Duration _) {
      if (mounted) _fn.requestFocus();
    });
  }

  @override
  void dispose() {
    _fn.dispose();
    super.dispose();
  }

  static const Map<String, String> _typed = <String, String>{
    '+': '+',
    '-': '−',
    '*': '×',
    'x': '×',
    'X': '×',
    '/': '÷',
    '%': '%',
    '=': '=',
    '.': '.',
    'c': 'C',
    'C': 'C',
  };

  /// PC keyboard: digits, + - * / % . = Enter, Backspace, Delete (clear).
  KeyEventResult _onKey(FocusNode node, KeyEvent e) {
    if (e is! KeyDownEvent && e is! KeyRepeatEvent) return KeyEventResult.ignored;
    final HardwareKeyboard hk = HardwareKeyboard.instance;
    if (hk.isControlPressed || hk.isMetaPressed || hk.isAltPressed) return KeyEventResult.ignored;
    final LogicalKeyboardKey lk = e.logicalKey;
    String? k;
    if (lk == LogicalKeyboardKey.enter || lk == LogicalKeyboardKey.numpadEnter) {
      k = '=';
    } else if (lk == LogicalKeyboardKey.backspace) {
      k = '⌫';
    } else if (lk == LogicalKeyboardKey.delete) {
      k = 'C';
    } else {
      final String ch = e.character ?? '';
      if (ch.length == 1 && ch.codeUnitAt(0) >= 48 && ch.codeUnitAt(0) <= 57) {
        k = ch;
      } else {
        k = _typed[ch];
      }
    }
    if (k == null) return KeyEventResult.ignored;
    _press(k);
    return KeyEventResult.handled;
  }

  String _pretty(String e) => e.replaceAllMapped(RegExp(r'([+−×÷])'), (Match m) => ' ${m.group(1)} ');

  bool _isOp(String c) => c == '+' || c == '−' || c == '×' || c == '÷';

  String _numTok() {
    final Match? m = RegExp(r'[0-9.]*$').firstMatch(_hs.expr);
    return m == null ? '' : m.group(0) ?? '';
  }

  double _current() {
    String e = _hs.expr;
    if (e.isNotEmpty && _isOp(e.substring(e.length - 1))) e = e.substring(0, e.length - 1);
    return evalExpr(e);
  }

  void _equals() {
    final double v = _current();
    if (v.isNaN) {
      setState(() => _hs.invalid = true);
      return;
    }
    _hs.khist.insert(0, <String>[_hs.expr, _plain(v)]);
    if (_hs.khist.length > 4) _hs.khist.removeLast();
    _hs.expr = _plain(v).replaceFirst('-', '−');
    _hs.fresh = true;
    setState(() => _hs.invalid = false);
  }

  void _press(String k) {
    final _HisabStore s = _hs;
    s.invalid = false;
    if (k == 'C') {
      s.expr = '';
      s.fresh = false;
    } else if (k == '⌫') {
      if (s.expr.isNotEmpty) s.expr = s.expr.substring(0, s.expr.length - 1);
      s.fresh = false;
    } else if (k == '=') {
      _equals();
      return;
    } else if (k == '.') {
      if (s.fresh) {
        s.expr = '';
        s.fresh = false;
      }
      final String t = _numTok();
      if (t.contains('.')) {
        setState(() {});
        return;
      }
      s.expr += t.isEmpty ? '0.' : '.';
    } else if (_isOp(k)) {
      s.fresh = false;
      if (s.expr.isEmpty) {
        if (k == '−') s.expr = '−';
      } else if (_isOp(s.expr.substring(s.expr.length - 1))) {
        if (s.expr.length > 1 || k == '−') s.expr = s.expr.substring(0, s.expr.length - 1) + k;
      } else {
        s.expr += k;
      }
    } else if (k == '%') {
      s.fresh = false;
      if (RegExp(r'[0-9.]$').hasMatch(s.expr)) s.expr += '%';
    } else {
      // digits and "00"
      if (s.fresh) {
        s.expr = '';
        s.fresh = false;
      }
      final String t = _numTok();
      if (k == '00') {
        if (t.isEmpty) {
          s.expr += '0';
        } else if (t != '0') {
          s.expr += '00';
        }
      } else {
        if (t == '0') s.expr = s.expr.substring(0, s.expr.length - 1);
        s.expr += k;
      }
    }
    setState(() {});
  }

  Widget _key(String k) {
    final bool op = _isOp(k);
    final bool eq = k == '=';
    final bool fn = k == 'C' || k == '⌫' || k == '%';
    final Color bg = eq ? Pal.brand : (op ? Pal.soft : (fn ? Pal.surface2 : Pal.surface));
    final Color fg = eq ? Colors.white : (k == 'C' ? Pal.bad : (op ? Pal.brand : Pal.ink));
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(4),
        child: Material(
          color: bg,
          borderRadius: BorderRadius.circular(Pal.rad(14)),
          child: InkWell(
            borderRadius: BorderRadius.circular(Pal.rad(14)),
            onTap: () => _press(k),
            child: Container(
              height: 58,
              alignment: Alignment.center,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(Pal.rad(14)), border: Border.all(color: Pal.line)),
              child: Text(k, style: ts(k == '⌫' ? 22 : 24, w: FontWeight.w700, c: fg)),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final double v = _current();
    final String shown = _hs.invalid ? bi('ખોટી ગણતરી', 'Invalid') : (_hs.expr.isEmpty ? '0' : (v.isNaN ? '…' : _fmtN(v)));
    final String line = _pretty(_hs.expr);
    return Focus(
      focusNode: _fn,
      onKeyEvent: _onKey,
      child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Surface(
          color: Pal.side,
          border: false,
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              Text(line.isEmpty ? ' ' : line, maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.right, style: ts(16, c: Pal.sideText, w: FontWeight.w600, tab: true)),
              const SizedBox(height: 4),
              FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerRight, child: Text(shown, style: ts(38, w: FontWeight.w800, c: (!v.isNaN && v < 0) ? const Color(0xFFFFA6B0) : Colors.white, tab: true, ls: -1))),
            ],
          ),
        ),
        if (_hs.khist.isNotEmpty) ...<Widget>[
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 6,
            children: <Widget>[
              for (final List<String> h in _hs.khist)
                InkWell(
                  borderRadius: BorderRadius.circular(Pal.rad(99)),
                  onTap: () {
                    _hs.expr = h[1].replaceFirst('-', '−');
                    _hs.fresh = true;
                    setState(() {});
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(color: Pal.soft, borderRadius: BorderRadius.circular(Pal.rad(99))),
                    child: Text('${_pretty(h[0])} = ${_fmtN(double.tryParse(h[1]) ?? double.nan)}', style: ts(12, w: FontWeight.w700, c: Pal.brand, tab: true)),
                  ),
                ),
            ],
          ),
        ],
        const SizedBox(height: 8),
        for (final List<String> r in _rows) Row(children: <Widget>[for (final String k in r) _key(k)]),
        const SizedBox(height: 6),
        Row(
          children: <Widget>[
            tExp(child: Btn(bi('જવાબ કૉપિ', 'Copy result'), icon: 'copy', kind: BtnKind.tonal, dense: true, onTap: (v.isNaN || _hs.expr.isEmpty) ? null : () => copyText(_plain(v)))),
          ],
        ),
      ],
      ),
    );
  }
}
