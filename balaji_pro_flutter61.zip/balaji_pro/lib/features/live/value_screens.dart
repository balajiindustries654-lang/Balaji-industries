import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/engine.dart';
import '../../data/insights.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../data/owner_docs.dart';
import '../../data/scan.dart' show commodityCode;
import '../../widgets/charts.dart';
import '../../widgets/common.dart';
import '../../widgets/page.dart';
import 'kit.dart';
import 'kit2.dart';
import 'ui.dart';

import '../../widgets/accept.dart';
import '../../widgets/dayfield.dart';

/// Every material name seen in chits, maal entries and saved rates
/// (most used first).
List<String> materialNames() {
  final Map<String, int> m = <String, int>{};
  for (final Chit c in live.chits) {
    final String s = c.commodity.trim();
    if (s.isNotEmpty) m[s] = (m[s] ?? 0) + 1;
  }
  for (final MaalRow r in live.maals) {
    final String s = r.material.trim();
    if (s.isNotEmpty) m[s] = (m[s] ?? 0) + 1;
  }
  final Object? all = rateDoc.data['rates'];
  if (all is Map) {
    for (final Object? k in all.keys) {
      final String s = '$k'.trim();
      if (s.isNotEmpty) m.putIfAbsent(s, () => 0);
    }
  }
  final List<String> out = m.keys.toList();
  out.sort((String a, String b) => (m[b] ?? 0).compareTo(m[a] ?? 0));
  return out;
}

// ============================================================== maal stock
class _St {
  final String key;
  int inB = 0;
  int outB = 0;
  int n = 0;
  DateTime last;
  _St(this.key, this.last);
}

class _OpenForm extends StatefulWidget {
  final int initial;
  final Future<void> Function(int) onSave;
  const _OpenForm({required this.initial, required this.onSave});

  @override
  State<_OpenForm> createState() => _OpenFormState();
}

class _OpenFormState extends State<_OpenForm> {
  late final TextEditingController _c = TextEditingController(text: widget.initial == 0 ? '' : '${widget.initial}');

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        FieldX(label: bi('શરૂઆતનો સ્ટોક (બેગ)', 'Opening stock (bags)'), controller: _c, keyboard: TextInputType.number, big: true),
        const SizedBox(height: 14),
        Btn(bi('સેવ', 'Save'), icon: 'check', expand: true, onTap: () async {
          final int v = dbl(_c.text, 0).round();
          await widget.onSave(v);
          if (context.mounted) Navigator.of(context).pop();
        }),
      ],
    );
  }
}

/// Bags in the godown: opening stock + unloaded - loaded, by material, owner
/// or godown.
class MaalStockScreen extends StatefulWidget {
  final int tab;
  const MaalStockScreen({super.key, this.tab = 0});

  @override
  State<MaalStockScreen> createState() => _MaalStockState();
}

class _MaalStockState extends State<MaalStockScreen> {
  late int _tab = widget.tab;

  @override
  void initState() {
    super.initState();
    prefDoc.addListener(_tick);
    prefDoc.ensure();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    prefDoc.removeListener(_tick);
    super.dispose();
  }

  String _okey(String key) => '$_tab|$key';

  int _open(String key) {
    final Object? v = prefDoc.map('openStock')[_okey(key)];
    if (v is num) return v.round();
    return 0;
  }

  Future<void> _setOpen(String key, int v) async {
    final Map<String, dynamic> o = prefDoc.map('openStock');
    if (v == 0) {
      o.remove(_okey(key));
    } else {
      o[_okey(key)] = v;
    }
    await prefDoc.save();
  }

  void _edit(BuildContext context, String key) {
    openPanel(
      context,
      title: _tab == 0 ? matLabel(key) : key,
      sub: bi('ગોડાઉનમાં શરૂઆતથી પડેલી બેગ', 'Bags already lying before the first entry'),
      width: 420,
      child: _OpenForm(initial: _open(key), onSave: (int v) => _setOpen(key, v)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 800,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Map<String, _St> m = <String, _St>{};
        for (final MaalRow r in live.maals) {
          String k = _tab == 0 ? r.material : (_tab == 1 ? r.owner : r.godown);
          k = k.trim();
          if (k.isEmpty) k = '—';
          final _St s = m.putIfAbsent(k, () => _St(k, r.at));
          s.n++;
          if (r.loading) {
            s.outB += r.bags;
          } else {
            s.inB += r.bags;
          }
          if (r.at.isAfter(s.last)) s.last = r.at;
        }
        final String pre = '$_tab|';
        for (final MapEntry<String, dynamic> e in prefDoc.map('openStock').entries) {
          if (e.key.startsWith(pre)) {
            final String k = e.key.substring(pre.length);
            m.putIfAbsent(k, () => _St(k, DateTime.now()));
          }
        }
        int totIn = 0;
        int totOut = 0;
        int totOpen = 0;
        int minus = 0;
        final List<_St> list = m.values.toList();
        for (final _St s in list) {
          totIn += s.inB;
          totOut += s.outB;
          totOpen += _open(s.key);
          if (_open(s.key) + s.inB - s.outB < 0) minus++;
        }
        final int stock = totOpen + totIn - totOut;
        list.sort((_St a, _St b) => (_open(b.key) + b.inB - b.outB).compareTo(_open(a.key) + a.inB - a.outB));

        return <Widget>[
          ScreenHeader(bi('માલ સ્ટોક · ગોડાઉન', 'Maal stock'), sub: bi('છેલ્લા ${live.days} દિવસની એન્ટ્રી + શરૂઆતનો સ્ટોક', 'Last ${live.days} days of entries + opening stock')),
          statusBanner(),
          HeroCard(
            title: bi('ગોડાઉનમાં હાલ બેગ', 'Bags in stock now'),
            value: grp(stock),
            unit: bi('બેગ', 'bags'),
            sub: bi('શરૂઆત + આવ્યા - ગયા', 'opening + in - out'),
            chips: <HeroChip>[
              HeroChip('down', '${grp(totIn)} ${bi('આવ્યા', 'in')}'),
              HeroChip('up', '${grp(totOut)} ${bi('ગયા', 'out')}'),
              HeroChip('box', '${grp(totOpen)} ${bi('શરૂઆત', 'opening')}'),
            ],
          ),
          const SizedBox(height: 12),
          ChipRow(
            labels: <String>[bi('માલ', 'Material'), bi('માલિક', 'Owner'), bi('ગોડાઉન', 'Godown')],
            index: _tab,
            onChanged: (int i) => setState(() => _tab = i),
          ),
          const SizedBox(height: 12),
          noteBox('info', 'blue', bi('અનલોડિંગ = ગોડાઉનમાં આવ્યું · લોડિંગ = બહાર ગયું. લાઇનને ટૅપ કરી શરૂઆતનો સ્ટોક નાખો.', 'Unloading = came into the godown · Loading = went out. Tap a line to set its opening stock.')),
          if (minus > 0) noteBox('warn', 'rose', bi('$minus નામમાં સ્ટોક માઇનસ છે - શરૂઆતનો સ્ટોક નાખો કે એન્ટ્રી તપાસો', '$minus names show negative stock - set the opening stock or check entries')),
          if (list.isEmpty) EmptyBox(icon: 'box', title: bi('માલ એન્ટ્રી નથી', 'No maal entries')),
          for (final _St s in list)
            lineItem(
              icon: _tab == 0 ? 'grain' : (_tab == 1 ? 'user' : 'warehouse'),
              tone: (_open(s.key) + s.inB - s.outB) < 0 ? 'rose' : 'amber',
              title: _tab == 0 ? matLabel(s.key) : s.key,
              sub: '${bi('આવ્યા', 'in')} ${grp(s.inB)} · ${bi('ગયા', 'out')} ${grp(s.outB)} · ${bi('શરૂઆત', 'opening')} ${grp(_open(s.key))}',
              trailing: grp(_open(s.key) + s.inB - s.outB),
              trailingSub: bi('બેગ', 'bags'),
              trailingColor: (_open(s.key) + s.inB - s.outB) < 0 ? Pal.bad : null,
              onTap: () => _edit(ctx, s.key),
            ),
        ];
      },
    );
  }
}

// ============================================================== maal cross
/// Table: owner (or godown) against material - bags net, in or out.
class MaalCrossScreen extends StatefulWidget {
  const MaalCrossScreen({super.key});

  @override
  State<MaalCrossScreen> createState() => _MaalCrossState();
}

class _MaalCrossState extends State<MaalCrossScreen> {
  RangeSel _sel = RangeSel(3);
  int _rows = 0;
  int _metric = 0;

  Widget _cell(String t, {bool head = false, bool right = true, Color? color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
      child: Text(
        t,
        textAlign: right ? TextAlign.right : TextAlign.left,
        style: ts(head ? 12 : 13.5, w: head ? FontWeight.w800 : FontWeight.w600, c: color ?? (head ? Pal.muted : null), tab: true),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 900,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = _sel.period;
        final Map<String, Map<String, int>> grid = <String, Map<String, int>>{};
        final Map<String, int> rowTot = <String, int>{};
        final Map<String, int> colTot = <String, int>{};
        for (final MaalRow r in live.maals) {
          if (!p.has(r.date)) continue;
          String rk = (_rows == 0 ? r.owner : r.godown).trim();
          if (rk.isEmpty) rk = '—';
          String ck = r.material.trim();
          if (ck.isEmpty) ck = '—';
          int v;
          if (_metric == 0) {
            v = r.loading ? -r.bags : r.bags;
          } else if (_metric == 1) {
            v = r.loading ? 0 : r.bags;
          } else {
            v = r.loading ? r.bags : 0;
          }
          final Map<String, int> row = grid.putIfAbsent(rk, () => <String, int>{});
          row[ck] = (row[ck] ?? 0) + v;
          rowTot[rk] = (rowTot[rk] ?? 0) + v;
          colTot[ck] = (colTot[ck] ?? 0) + v;
        }
        final List<String> cols = colTot.keys.toList();
        cols.sort((String a, String b) => (colTot[b] ?? 0).abs().compareTo((colTot[a] ?? 0).abs()));
        final List<String> shownCols = cols.take(7).toList();
        final List<String> rowsK = rowTot.keys.toList();
        rowsK.sort((String a, String b) => (rowTot[b] ?? 0).abs().compareTo((rowTot[a] ?? 0).abs()));
        int grand = 0;
        for (final int v in rowTot.values) {
          grand += v;
        }

        Color? colorOf(int v) => _metric == 0 && v < 0 ? Pal.bad : null;

        final List<TableRow> trs = <TableRow>[
          TableRow(
            children: <Widget>[
              _cell(_rows == 0 ? bi('માલિક', 'Owner') : bi('ગોડાઉન', 'Godown'), head: true, right: false),
              for (final String c in shownCols) _cell(matLabel(c), head: true),
              _cell(bi('કુલ', 'Total'), head: true),
            ],
          ),
          for (final String r in rowsK.take(40))
            TableRow(
              children: <Widget>[
                _cell(r, right: false),
                for (final String c in shownCols) _cell(((grid[r] ?? <String, int>{})[c] ?? 0) == 0 ? '·' : grp((grid[r] ?? <String, int>{})[c] ?? 0), color: colorOf((grid[r] ?? <String, int>{})[c] ?? 0)),
                _cell(grp(rowTot[r] ?? 0), color: colorOf(rowTot[r] ?? 0)),
              ],
            ),
          TableRow(
            children: <Widget>[
              _cell(bi('કુલ', 'Total'), head: true, right: false),
              for (final String c in shownCols) _cell(grp(colTot[c] ?? 0), head: true, color: colorOf(colTot[c] ?? 0)),
              _cell(grp(grand), head: true, color: colorOf(grand)),
            ],
          ),
        ];

        return <Widget>[
          ScreenHeader(bi('માલ · માલિક × માલ', 'Maal cross table'), sub: p.label),
          statusBanner(),
          RangeBar(sel: _sel, presets: const <int>[2, 3, 4, 5], onChanged: (RangeSel s) => setState(() => _sel = s)),
          const SizedBox(height: 10),
          Seg(labels: <String>[bi('ચોખ્ખા', 'Net'), bi('આવ્યા', 'In'), bi('ગયા', 'Out')], index: _metric, onChanged: (int i) => setState(() => _metric = i), dense: true),
          const SizedBox(height: 8),
          ChipRow(labels: <String>[bi('માલિક', 'Owner'), bi('ગોડાઉન', 'Godown')], index: _rows, onChanged: (int i) => setState(() => _rows = i)),
          const SizedBox(height: 12),
          if (rowsK.isEmpty)
            EmptyBox(icon: 'table', title: bi('આ સમયમાં માલ એન્ટ્રી નથી', 'No maal entries in this period'))
          else
            Panel(
              title: bi('બેગ', 'Bags'),
              sub: cols.length > shownCols.length ? bi('સૌથી મોટા 7 માલ બતાવ્યા', 'Top 7 materials shown') : null,
              flush: true,
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Table(
                  defaultColumnWidth: const IntrinsicColumnWidth(),
                  border: TableBorder(horizontalInside: BorderSide(color: Pal.line)),
                  children: trs,
                ),
              ),
            ),
        ];
      },
    );
  }
}

// ==================================================================== rates
/// Today's price per 20 kg (mann) for every material, with the history.
class RatesScreen extends StatefulWidget {
  const RatesScreen({super.key});

  @override
  State<RatesScreen> createState() => _RatesState();
}

class _RatesState extends State<RatesScreen> {
  late final VoidCallback _accept = () {
    _save();
  };

  final TextEditingController _mat = TextEditingController();
  final TextEditingController _rate = TextEditingController();
  DateTime _day = dateOnly(DateTime.now());

  @override
  void initState() {
    super.initState();
    AcceptHub.push(_accept);
    rateDoc.addListener(_tick);
    rateDoc.ensure();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    rateDoc.removeListener(_tick);
    _mat.dispose();
    _rate.dispose();
    AcceptHub.pop(_accept);
    super.dispose();
  }

  Future<void> _save() async {
    final String typed = _mat.text.trim();
    final String code = commodityCode(typed);
    final String m = code.isEmpty ? typed : code;
    final double r = dbl(_rate.text.replaceAll(',', ''), 0);
    if (m.isEmpty) {
      app.toast(bi('માલનું નામ લખો', 'Enter the material'));
      return;
    }
    if (r <= 0) {
      app.toast(bi('ભાવ લખો', 'Enter the rate'));
      return;
    }
    await setRate(m, _day, r);
    _rate.clear();
    app.toast(bi('ભાવ સેવ થયો', 'Rate saved'));
  }

  Future<void> _del(String m, String day) async {
    final DateTime? d = DateTime.tryParse(day);
    if (d == null) return;
    await setRate(m, d, null);
  }

  Widget _matPanel(String m) {
    final List<MapEntry<String, double>> hist = ratesOfMaterial(m);
    if (hist.isEmpty) return const SizedBox.shrink();
    final double cur = hist.first.value;
    final double? prev = hist.length > 1 ? hist[1].value : null;
    final List<MapEntry<String, double>> chart = hist.take(30).toList().reversed.toList();
    String move = '';
    if (prev != null && prev > 0) {
      final double d = cur - prev;
      move = d == 0 ? bi('ફેરફાર નથી', 'unchanged') : '${d > 0 ? '+' : ''}${grp(d)} (${(d / prev * 100).toStringAsFixed(1)}%)';
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Panel(
        title: matLabel(m),
        sub: '${hist.first.key}${move.isEmpty ? '' : ' · $move'}',
        action: Pill('₹${grp(cur)} / 20 KG', tone: 'green'),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Text('= ₹${(cur / 20).toStringAsFixed(2)} / KG · ₹${grp(cur * 5)} / ${bi('ક્વિન્ટલ', 'quintal')}', style: ts(12.5, c: Pal.muted)),
            if (chart.length >= 2) ...<Widget>[
              const SizedBox(height: 10),
              LineChartX(
                series: <LineSeries>[LineSeries(m, <double>[for (final MapEntry<String, double> e in chart) e.value], Pal.brand)],
                labels: <String>[for (final MapEntry<String, double> e in chart) e.key.length >= 10 ? e.key.substring(5) : e.key],
                axisFmt: (double v) => grp(v),
                height: 150,
              ),
            ],
            const SizedBox(height: 6),
            for (final MapEntry<String, double> e in hist.take(6))
              Row(
                children: <Widget>[
                  Expanded(child: Text(e.key, style: ts(13, c: Pal.muted))),
                  Text('₹${grp(e.value)}', style: ts(14, w: FontWeight.w800, tab: true)),
                  IconBtn('trash', size: 38, tip: bi('કાઢો', 'Delete'), onTap: () => _del(m, e.key)),
                ],
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 800,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final List<String> names = materialNames();
        final List<String> withRate = <String>[];
        final Object? all = rateDoc.data['rates'];
        if (all is Map) {
          for (final String n in names) {
            if (all[n] is Map && (all[n] as Map).isNotEmpty) withRate.add(n);
          }
        }
        return <Widget>[
          ScreenHeader(bi('ભાવ · રેટ', 'Rates'), sub: bi('₹ પ્રતિ 20 KG (મણ)', 'Rs per 20 KG (mann)')),
          statusBanner(),
          Panel(
            title: bi('ભાવ નાખો', 'Set a rate'),
            sub: bi('આ ભાવથી ખરીદ રકમ અને ઘટની કિંમત ગણાય છે', 'Used for purchase amounts and the value of the loss'),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                SuggestField(label: bi('માલ', 'Material'), controller: _mat, options: <String>[for (final String n in names) matLabel(n)]),
                const SizedBox(height: 10),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    Expanded(child: FieldX(label: bi('ભાવ', 'Rate'), controller: _rate, keyboard: TextInputType.number, suffix: '₹ / 20 KG')),
                    const SizedBox(width: 10),
                    SizedBox(
                      width: app.stagePc ? 210 : 158,
                      child: DayField(
                        label: bi('તારીખ', 'Date'),
                        value: _day,
                        stacked: true,
                        first: DateTime(DateTime.now().year - 2),
                        last: dateOnly(DateTime.now()),
                        onChanged: (DateTime d) => setState(() => _day = d),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Btn(bi('ભાવ સેવ કરો', 'Save rate'), icon: 'check', expand: true, onTap: _save),
              ],
            ),
          ),
          const SizedBox(height: 12),
          if (withRate.isEmpty) EmptyBox(icon: 'rupee', title: bi('હજુ કોઈ ભાવ નથી', 'No rate saved yet'), sub: bi('ઉપર માલ અને ભાવ નાખો', 'Add a material and its rate above')),
          for (final String n in withRate) _matPanel(n),
        ];
      },
    );
  }
}

// ================================================================ purchase
class _Amt {
  final String key;
  final String label;
  double kg = 0;
  double amt = 0;
  double noRateKg = 0;
  int n = 0;
  _Amt(this.key, this.label);
}

/// What the chits are worth: weight x the rate of that day.
class PurchaseScreen extends StatefulWidget {
  const PurchaseScreen({super.key});

  @override
  State<PurchaseScreen> createState() => _PurchaseState();
}

class _PurchaseState extends State<PurchaseScreen> {
  RangeSel _sel = RangeSel(2);
  int _dim = 0;
  int _wt = 0;
  static const List<Dim> _dd = <Dim>[Dim.farmer, Dim.broker, Dim.village, Dim.commodity];

  @override
  void initState() {
    super.initState();
    rateDoc.addListener(_tick);
    rateDoc.ensure();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    rateDoc.removeListener(_tick);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 800,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = _sel.period;
        final Dim dim = _dd[_dim];
        final Map<String, _Amt> m = <String, _Amt>{};
        double totKg = 0;
        double totAmt = 0;
        double noRate = 0;
        int chitsN = 0;
        for (final Trip t in live.trips) {
          if (t.chits.isEmpty) continue;
          for (final Chit c in t.chits) {
            if (!p.has(c.at)) continue;
            double kg = c.cmpKg;
            if (_wt == 1 && t.kanta != null && t.chitKg > 0) kg = t.kantaKg * (c.cmpKg / t.chitKg);
            final double? r = rateFor(c.commodity.trim(), c.at);
            final double v = r == null ? 0 : kg / 20 * r;
            totKg += kg;
            chitsN++;
            if (r == null) {
              noRate += kg;
            } else {
              totAmt += v;
            }
            final String k = dimKey(dim, c);
            if (k.isEmpty) continue;
            final _Amt a = m.putIfAbsent(k, () => _Amt(k, dimLabel(dim, c)));
            a.n++;
            a.kg += kg;
            a.amt += v;
            if (r == null) a.noRateKg += kg;
          }
        }
        final List<_Amt> list = m.values.toList();
        list.sort((_Amt a, _Amt b) => b.amt.compareTo(a.amt));
        final bool hasRates = rateDoc.data['rates'] is Map && (rateDoc.data['rates'] as Map).isNotEmpty;

        String text() {
          final StringBuffer b = StringBuffer();
          b.writeln('${bi('ખરીદ રકમ', 'Purchase value')} - ${p.label}');
          b.writeln('${kgTxt(totKg)} · ${inr(totAmt)}');
          b.writeln('----------------');
          for (final _Amt a in list) {
            b.writeln('${a.label} · ${kgTxt(a.kg)} · ${inr(a.amt)}');
          }
          return b.toString().trim();
        }

        return <Widget>[
          ScreenHeader(bi('ખરીદ રકમ', 'Purchase value'), sub: p.label),
          statusBanner(),
          RangeBar(sel: _sel, presets: const <int>[0, 1, 2, 3, 4, 5], onChanged: (RangeSel s) => setState(() => _sel = s)),
          const SizedBox(height: 10),
          Row(
            children: <Widget>[
              Expanded(
                child: ChipRow(
                  labels: <String>[bi('ખેડૂત', 'Farmer'), bi('દલાલ', 'Broker'), bi('ગામ', 'Village'), bi('માલ', 'Material')],
                  index: _dim,
                  onChanged: (int i) => setState(() => _dim = i),
                ),
              ),
              IconBtn('copy', tip: bi('કૉપિ', 'Copy'), onTap: () => copyText(text(), msg: bi('કૉપિ થયું', 'Copied'))),
            ],
          ),
          const SizedBox(height: 8),
          Seg(labels: <String>[bi('ચિઠ્ઠીનું વજન', 'Chit weight'), bi('કાંટાનું વજન', 'Kanta weight')], index: _wt, onChanged: (int i) => setState(() => _wt = i), dense: true),
          const SizedBox(height: 12),
          HeroCard(
            title: bi('કુલ ખરીદ રકમ', 'Total purchase value'),
            value: inrC(totAmt),
            unit: '',
            sub: _wt == 0 ? bi('ચિઠ્ઠીના વજન × તે દિવસનો ભાવ', 'chit weight × that day\'s rate') : bi('કાંટાના વજન (ચિઠ્ઠી મુજબ વહેંચેલું) × ભાવ', 'kanta weight (shared by chit) × rate'),
            chips: <HeroChip>[
              HeroChip('weight', kgTxt(totKg)),
              HeroChip('receipt', '$chitsN ${bi('ચિઠ્ઠી', 'chits')}'),
              if (totKg > 0 && totAmt > 0) HeroChip('pct', '₹${grp(totAmt / (totKg - noRate) * 20)} / 20 KG'),
            ],
          ),
          const SizedBox(height: 12),
          if (!hasRates) noteBox('warn', 'amber', bi('હજુ કોઈ ભાવ નાખ્યો નથી - પહેલા "ભાવ" માં માલનો ભાવ નાખો', 'No rate set yet - add the material rates first'), onTap: () => app.go('rates')),
          if (hasRates && noRate > 0) noteBox('info', 'amber', bi('${kgTxt(noRate)} નો ભાવ નાખ્યો નથી (રકમમાં ગણ્યો નથી)', '${kgTxt(noRate)} has no rate (not in the amount)'), onTap: () => app.go('rates')),
          if (list.isEmpty) EmptyBox(icon: 'receipt', title: bi('આ સમયમાં ચિઠ્ઠી નથી', 'No chits in this period')),
          for (final _Amt a in list.take(60))
            lineItem(
              icon: dimIcon(dim),
              tone: a.noRateKg > 0 ? 'amber' : 'teal',
              title: dim == Dim.commodity ? matLabel(a.label) : a.label,
              sub: '${kgTxt(a.kg)} · ${a.n} ${bi('ચિઠ્ઠી', 'chits')}${a.noRateKg > 0 ? ' · ${bi('ભાવ વગર', 'no rate')} ${kgTxt(a.noRateKg)}' : ''}',
              trailing: inr(a.amt),
              onTap: () => openParty(PartyRef(dim, a.key, a.label)),
            ),
        ];
      },
    );
  }
}

// =============================================================== loss value
class _Lv {
  final String key;
  final String label;
  double lossKg = 0;
  double beyondKg = 0;
  double lossAmt = 0;
  double beyondAmt = 0;
  double gainKg = 0;
  int trips = 0;
  _Lv(this.key, this.label);
}

/// The rupee value of the weight lost between chit and kanta.
class LossValueScreen extends StatefulWidget {
  const LossValueScreen({super.key});

  @override
  State<LossValueScreen> createState() => _LossValueState();
}

class _LossValueState extends State<LossValueScreen> {
  RangeSel _sel = RangeSel(3);
  int _dim = 0;
  static const List<Dim> _dd = <Dim>[Dim.majur, Dim.vehicle, Dim.farmer, Dim.village, Dim.broker];

  @override
  void initState() {
    super.initState();
    rateDoc.addListener(_tick);
    rateDoc.ensure();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    rateDoc.removeListener(_tick);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 800,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = _sel.period;
        final Dim dim = _dd[_dim];
        final Map<String, _Lv> m = <String, _Lv>{};
        double lossKg = 0;
        double beyondKg = 0;
        double lossAmt = 0;
        double beyondAmt = 0;
        double gainKg = 0;
        int tripsN = 0;
        int noRateTrips = 0;
        for (final Trip t in live.trips) {
          if (!t.both || !p.has(t.at) || t.chitKg <= 0) continue;
          final double d = t.kantaKg - t.chitKg;
          tripsN++;
          if (d >= 0) {
            gainKg += d;
            continue;
          }
          final double loss = -d;
          final double beyond = loss > t.tol ? loss - t.tol : 0;
          lossKg += loss;
          beyondKg += beyond;
          bool anyNoRate = false;
          for (final Chit c in t.chits) {
            final double share = c.cmpKg / t.chitKg;
            final double? r = rateFor(c.commodity.trim(), t.at);
            if (r == null) anyNoRate = true;
            final double la = r == null ? 0 : loss * share / 20 * r;
            final double ba = r == null ? 0 : beyond * share / 20 * r;
            lossAmt += la;
            beyondAmt += ba;
            final String k = dim == Dim.vehicle ? t.vk : dimKey(dim, c);
            if (k.isEmpty) continue;
            final String label = dim == Dim.vehicle ? t.vehicle : dimLabel(dim, c);
            final _Lv x = m.putIfAbsent(k, () => _Lv(k, label));
            x.lossKg += loss * share;
            x.beyondKg += beyond * share;
            x.lossAmt += la;
            x.beyondAmt += ba;
            x.trips++;
          }
          if (anyNoRate) noRateTrips++;
        }
        final List<_Lv> list = m.values.toList();
        list.sort((_Lv a, _Lv b) {
          final int c = b.beyondAmt.compareTo(a.beyondAmt);
          return c != 0 ? c : b.lossKg.compareTo(a.lossKg);
        });
        final bool hasRates = rateDoc.data['rates'] is Map && (rateDoc.data['rates'] as Map).isNotEmpty;

        return <Widget>[
          ScreenHeader(bi('ઘટની કિંમત', 'Value of loss'), sub: p.label),
          statusBanner(),
          RangeBar(sel: _sel, presets: const <int>[2, 3, 4, 5], onChanged: (RangeSel s) => setState(() => _sel = s)),
          const SizedBox(height: 10),
          ChipRow(
            labels: <String>[bi('મજૂર', 'Labour'), bi('ગાડી', 'Vehicle'), bi('ખેડૂત', 'Farmer'), bi('ગામ', 'Village'), bi('દલાલ', 'Broker')],
            index: _dim,
            onChanged: (int i) => setState(() => _dim = i),
          ),
          const SizedBox(height: 12),
          HeroCard(
            title: bi('મર્યાદા ઉપરની ઘટની કિંમત', 'Value of loss beyond the limit'),
            value: inrC(beyondAmt),
            unit: '',
            sub: '${bi('કુલ ઘટ', 'Total loss')}: ${kgTxt(lossKg)} = ${inrC(lossAmt)}',
            chips: <HeroChip>[
              HeroChip('trenddown', kgTxt(beyondKg)),
              HeroChip('truck', '$tripsN ${bi('મેળવેલી ગાડી', 'matched trips')}'),
              HeroChip('trend', '+${kgTxt(gainKg)}'),
            ],
          ),
          const SizedBox(height: 12),
          if (!hasRates) noteBox('warn', 'amber', bi('રકમ જોવા માટે પહેલા "ભાવ" માં ભાવ નાખો', 'Set the rates first to see rupee values'), onTap: () => app.go('rates')),
          if (hasRates && noRateTrips > 0) noteBox('info', 'amber', bi('$noRateTrips ગાડીના માલનો ભાવ નાખ્યો નથી', '$noRateTrips trips have a material without a rate'), onTap: () => app.go('rates')),
          if (list.isEmpty) noteBox('check', 'green', bi('આ સમયમાં કોઈ ઘટ નથી', 'No loss in this period')),
          for (final _Lv x in list.take(40))
            lineItem(
              icon: dimIcon(dim),
              tone: x.beyondKg > 0 ? 'rose' : 'teal',
              title: x.label,
              sub: '${bi('ઘટ', 'loss')} ${kgTxt(x.lossKg)} · ${bi('મર્યાદા ઉપર', 'beyond limit')} ${kgTxt(x.beyondKg)} · ${x.trips} ${bi('ગાડી', 'trips')}',
              trailing: hasRates ? inrC(x.beyondAmt) : null,
              trailingSub: hasRates ? '${bi('કુલ', 'all')} ${inrC(x.lossAmt)}' : null,
              trailingColor: x.beyondAmt > 0 ? Pal.bad : null,
              onTap: dim == Dim.majur ? null : () => openParty(PartyRef(dim, x.key, x.label)),
            ),
        ];
      },
    );
  }
}
