import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/flags.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/engine.dart';
import '../../data/gst.dart';
import '../../data/insights.dart';
import '../../data/lists.dart' show kCommodities;
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../data/money.dart';
import '../../data/owner_docs.dart';
import '../../data/trade.dart';
import '../../data/trading.dart';
import '../../widgets/common.dart';
import '../../widgets/dayfield.dart';
import '../../widgets/launch.dart';
import '../../widgets/page.dart';
import 'field.dart';
import 'gst_screens.dart';
import 'kit.dart';
import 'kit2.dart';
import 'money_screens.dart';
import 'ui.dart';

import '../../widgets/accept.dart';
// ======================================================================
// Trading / mill - trucks that go straight from the seller to the mill
// ======================================================================

Map<String, double> _billTotals() {
  final Map<String, double> m = <String, double>{};
  for (final GstInv i in gstInvoices()) {
    if (!i.cancelled) m[i.no] = i.calc.total;
  }
  return m;
}

String _stLabel(String s) {
  switch (s) {
    case 'paid':
      return bi('પૈસા મળી ગયા', 'Paid');
    case 'billed':
      return bi('બિલ થયું', 'Billed');
    case 'weighed':
      return bi('મિલ વજન આવ્યું', 'Weighed');
  }
  return bi('ગાડી ચાલી', 'On the way');
}

String _stTone(String s) {
  switch (s) {
    case 'paid':
      return 'green';
    case 'billed':
      return 'amber';
    case 'weighed':
      return 'blue';
  }
  return 'slate';
}

/// Latest weighbridge / chit trip of a vehicle.
Trip? _tripOf(String vehicle) {
  final String vk = vehicleKey(vehicle);
  if (vk.length < 4) return null;
  Trip? best;
  for (final Trip t in live.trips) {
    if (t.vk != vk) continue;
    if (best == null || t.at.isAfter(best.at)) best = t;
  }
  return best;
}

String _itemOf(MillDeal d) => d.item.trim().isNotEmpty ? d.item.trim() : matLabel(d.commodity);

String dealText(MillDeal d, DealCalc c) {
  final StringBuffer b = StringBuffer();
  b.writeln('${bi('મિલ ગાડી', 'Mill truck')} · ${d.vehicle.isEmpty ? '-' : d.vehicle} · ${dmy(d.date)}');
  b.writeln('${bi('ખરીદ', 'From')}: ${d.seller.isEmpty ? '-' : d.seller}');
  b.writeln('${bi('મિલ', 'Mill')}: ${d.mill}');
  b.writeln('${bi('માલ', 'Item')}: ${_itemOf(d)}');
  b.writeln('${bi('ભરેલું વજન', 'Load')}: ${grp(d.loadKg, dec: 2)} KG');
  if (d.weighed) b.writeln('${bi('મિલ વજન', 'Mill weight')}: ${grp(d.millKg, dec: 2)} KG (${bi('ઘટ', 'short')} ${grp(c.shortKg, dec: 2)} KG · ${c.shortPct.toStringAsFixed(2)}%)');
  if (d.buyRate > 0) b.writeln('${bi('ખરીદ ભાવ', 'Buy rate')}: ₹${plainNum(d.buyRate)} / 20 KG');
  if (d.sellRate > 0) b.writeln('${bi('વેચાણ ભાવ', 'Sell rate')}: ₹${plainNum(d.sellRate)} / 20 KG');
  if (c.hasSell) b.writeln('${bi('નફો', 'Profit')}: ${inr(c.profit, dec: 2)}');
  if (d.billed) b.writeln('GST ${bi('બિલ', 'bill')}: ${d.billNo}');
  if (c.receivable > 0) b.writeln('${bi('લેવાના', 'Due')}: ${inr(c.due, dec: 2)}');
  return b.toString().trim();
}

Future<void> openDealForm(BuildContext context, {MillDeal? edit}) {
  return openPanel(
    context,
    title: edit == null ? bi('નવી મિલ ગાડી', 'New mill truck') : bi('ગાડી સુધારો', 'Edit truck'),
    width: 560,
    child: DealForm(edit: edit),
  );
}

Future<void> openDealDetail(BuildContext context, MillDeal d) {
  return openPanel(context, title: d.mill, sub: '${d.vehicle.isEmpty ? '' : '${d.vehicle} · '}${dmy(d.date)}', width: 520, child: DealDetail(d.id));
}

// -------------------------------------------------------------------- form
class DealForm extends StatefulWidget {
  final MillDeal? edit;
  const DealForm({super.key, this.edit});

  @override
  State<DealForm> createState() => _DealFormState();
}

class _DealFormState extends State<DealForm> {
  late final VoidCallback _accept = () {
    _save();
  };

  final TextEditingController _veh = TextEditingController();
  final TextEditingController _seller = TextEditingController();
  final TextEditingController _mill = TextEditingController();
  final TextEditingController _item = TextEditingController();
  final TextEditingController _load = TextEditingController();
  final TextEditingController _mkg = TextEditingController();
  final TextEditingController _br = TextEditingController();
  final TextEditingController _sr = TextEditingController();
  final TextEditingController _fr = TextEditingController();
  final TextEditingController _lab = TextEditingController();
  final TextEditingController _com = TextEditingController();
  final TextEditingController _oth = TextEditingController();
  final TextEditingController _bill = TextEditingController();
  final TextEditingController _note = TextEditingController();
  String _code = 'Magfadi';
  String _buyOn = 'load';
  DateTime _day = dateOnly(DateTime.now());
  bool _busy = false;
  String _err = '';

  String _p(double v) => v == 0 ? '' : plainNum(v);

  @override
  void initState() {
    super.initState();
    AcceptHub.push(_accept);
    final MillDeal? e = widget.edit;
    if (e != null) {
      _veh.text = e.vehicle;
      _seller.text = e.seller;
      _mill.text = e.mill;
      _item.text = e.item;
      _load.text = _p(e.loadKg);
      _mkg.text = _p(e.millKg);
      _br.text = _p(e.buyRate);
      _sr.text = _p(e.sellRate);
      _fr.text = _p(e.freight);
      _lab.text = _p(e.labour);
      _com.text = _p(e.commission);
      _oth.text = _p(e.other);
      _bill.text = e.billNo;
      _note.text = e.note;
      _code = e.commodity.isEmpty ? 'Magfadi' : e.commodity;
      _buyOn = e.buyOn;
      _day = e.date;
    } else {
      final double? r = rateFor(_code, _day);
      if (r != null) _br.text = plainNum(r);
    }
  }

  @override
  void dispose() {
    for (final TextEditingController c in <TextEditingController>[_veh, _seller, _mill, _item, _load, _mkg, _br, _sr, _fr, _lab, _com, _oth, _bill, _note]) {
      c.dispose();
    }
    AcceptHub.pop(_accept);
    super.dispose();
  }

  MillDeal _draft() {
    final MillDeal? e = widget.edit;
    return MillDeal(
      id: e?.id ?? newDealId(),
      date: _day,
      vehicle: _veh.text.trim(),
      commodity: _code,
      item: _item.text.trim(),
      seller: _seller.text.trim(),
      mill: _mill.text.trim(),
      loadKg: dbl(_load.text),
      millKg: dbl(_mkg.text),
      buyRate: dbl(_br.text),
      sellRate: dbl(_sr.text),
      buyOn: _buyOn,
      freight: dbl(_fr.text),
      labour: dbl(_lab.text),
      commission: dbl(_com.text),
      other: dbl(_oth.text),
      billNo: _bill.text.trim(),
      note: _note.text.trim(),
      recv: e?.recv ?? const <DealRecv>[],
      at: e?.at ?? DateTime.now(),
    );
  }

  Future<void> _pick() async {
    final DateTime? d = await pickDay(context, _day, last: dateOnly(DateTime.now()));
    if (d != null && mounted) setState(() => _day = d);
  }

  Future<void> _save() async {
    final MillDeal d = _draft();
    String err = '';
    if (d.mill.isEmpty) {
      err = bi('મિલનું નામ લખો', 'Enter the mill');
    } else if (d.loadKg <= 0 && d.millKg <= 0) {
      err = bi('ભરેલું વજન લખો', 'Enter the loaded weight');
    } else if (d.loadKg > kMaxLoadKg * 1.0 || d.millKg > kMaxLoadKg * 1.0) {
      err = bi('વજન ખોટું લાગે છે - ફરી તપાસો', 'That weight cannot be right - check the digits');
    }
    if (err.isNotEmpty) {
      setState(() => _err = err);
      return;
    }
    setState(() {
      _busy = true;
      _err = '';
    });
    await saveDeal(d.loadKg <= 0 ? _withLoad(d) : d);
    app.toast('${bi('મિલ ગાડી સેવ થઈ', 'Mill truck saved')} · ${d.mill}');
    if (mounted) Navigator.of(context).pop();
  }

  /// Mill weight only: the loaded weight is taken the same.
  MillDeal _withLoad(MillDeal d) => MillDeal(
        id: d.id,
        date: d.date,
        vehicle: d.vehicle,
        commodity: d.commodity,
        item: d.item,
        seller: d.seller,
        mill: d.mill,
        loadKg: d.millKg,
        millKg: d.millKg,
        buyRate: d.buyRate,
        sellRate: d.sellRate,
        buyOn: d.buyOn,
        freight: d.freight,
        labour: d.labour,
        commission: d.commission,
        other: d.other,
        billNo: d.billNo,
        note: d.note,
        recv: d.recv,
        at: d.at,
      );

  Widget _kantaHint() {
    final Trip? t = _tripOf(_veh.text);
    if (t == null) return const SizedBox.shrink();
    final double kg = t.kanta != null ? t.kantaKg : t.chitKg;
    if (kg <= 0) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Btn('${t.kanta != null ? bi('કાંટો', 'Kanta') : bi('ચિઠ્ઠી', 'Chit')}: ${grp(kg, dec: 0)} KG · ${dm(t.at)} - ${bi('વાપરો', 'use')}', icon: 'scale', kind: BtnKind.tonal, dense: true, onTap: () {
          _load.text = plainNum(kg);
          if (_seller.text.trim().isEmpty && t.farmers.isNotEmpty) _seller.text = t.farmers;
          setState(() {});
        }),
      ),
    );
  }

  Widget _two(Widget a, Widget b) => Row(children: <Widget>[Expanded(child: a), const SizedBox(width: 10), Expanded(child: b)]);

  Widget _preview() {
    final MillDeal d = _draft();
    final DealCalc c = calcDeal(d);
    final Color pc = c.profit >= 0 ? Pal.ok : Pal.bad;
    return Surface(
      shadow: false,
      color: Pal.soft,
      padding: const EdgeInsets.all(12),
      child: Column(
        children: <Widget>[
          if (d.weighed) InfoRow(bi('ઘટ', 'Short'), '${grp(c.shortKg, dec: 2)} KG · ${c.shortPct.toStringAsFixed(2)}%', color: c.shortKg > live.cfg.tol(d.loadKg) ? Pal.bad : null),
          InfoRow(bi('ખરીદ રકમ', 'Buy amount'), inr(c.buyAmt, dec: 2)),
          InfoRow(bi('વેચાણ રકમ', 'Sell amount'), c.hasSell ? inr(c.sellAmt, dec: 2) : '—'),
          InfoRow(bi('ખર્ચ', 'Expenses'), inr(c.expenses, dec: 2)),
          InfoRow(bi('નફો', 'Profit'), c.hasSell ? inr(c.profit, dec: 2) : '—', bold: true, color: c.hasSell ? pc : null),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final List<MillDeal> old = millDeals();
    final List<String> mills = recentValues(<String>[for (final MillDeal d in old) d.mill, for (final BuyerAcct a in buyerAccts().values) a.label, for (final GstParty p in gstParties()) p.name]);
    final List<String> sellers = recentValues(<String>[for (final MillDeal d in old) d.seller, for (final PartySummary s in directoryOf(Dim.farmer).take(300)) s.ref.label]);
    final List<String> vehicles = recentValues(<String>[for (final MillDeal d in old) d.vehicle, ...live.kantas.map((Kanta k) => k.vehicle)]);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        SuggestField(label: bi('ગાડી નંબર', 'Vehicle'), controller: _veh, options: vehicles, onChanged: (String v) => setState(() {}), onPick: (String v) => setState(() {})),
        _kantaHint(),
        const SizedBox(height: 12),
        SuggestField(label: bi('ક્યાંથી ખરીદ્યું (ખેડૂત / પાર્ટી)', 'Bought from (farmer / party)'), controller: _seller, options: sellers),
        const SizedBox(height: 12),
        SuggestField(label: '${bi('મિલ (ખરીદનાર)', 'Mill (buyer)')} *', controller: _mill, options: mills),
        const SizedBox(height: 12),
        ChipRow(
          labels: <String>[for (final List<String> x in kCommodities) bi(x[1], x[2])],
          index: kCommodities.indexWhere((List<String> x) => x[0] == _code),
          onChanged: (int i) => setState(() {
            _code = kCommodities[i][0];
            if (_br.text.trim().isEmpty) {
              final double? r = rateFor(_code, _day);
              if (r != null) _br.text = plainNum(r);
            }
          }),
        ),
        const SizedBox(height: 12),
        SuggestField(label: bi('બિલ પર માલનું નામ', 'Item name on the bill'), controller: _item, options: <String>[for (final List<String> p in kGstPresets) p[1]]),
        const SizedBox(height: 12),
        _two(
          FieldX(label: '${bi('ભરેલું વજન', 'Loaded weight')} *', controller: _load, suffix: 'KG', big: true, keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {})),
          FieldX(label: bi('મિલ વજન', 'Mill weight'), controller: _mkg, suffix: 'KG', big: true, keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {})),
        ),
        const SizedBox(height: 12),
        _two(
          FieldX(label: bi('ખરીદ ભાવ', 'Buy rate'), controller: _br, prefix: '₹', suffix: '/ 20 KG', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {})),
          FieldX(label: bi('વેચાણ ભાવ', 'Sell rate'), controller: _sr, prefix: '₹', suffix: '/ 20 KG', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {})),
        ),
        const SizedBox(height: 10),
        LineRow(label: bi('ખરીદ કયા વજન પર', 'Buying on which weight'), child: ChipRow(
          labels: <String>[bi('ભરેલું વજન', 'Loaded weight'), bi('મિલ વજન', 'Mill weight')],
          index: _buyOn == 'mill' ? 1 : 0,
          onChanged: (int i) => setState(() => _buyOn = i == 1 ? 'mill' : 'load'),
        )),
        const SizedBox(height: 14),
        Text(bi('ખર્ચ (₹)', 'Expenses (₹)'), style: ts(12.5, w: FontWeight.w800, c: Pal.muted)),
        const SizedBox(height: 6),
        _two(
          FieldX(label: bi('ભાડું', 'Freight'), controller: _fr, prefix: '₹', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {})),
          FieldX(label: bi('મજૂરી', 'Labour'), controller: _lab, prefix: '₹', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {})),
        ),
        const SizedBox(height: 10),
        _two(
          FieldX(label: bi('દલાલી', 'Commission'), controller: _com, prefix: '₹', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {})),
          FieldX(label: bi('બીજું', 'Other'), controller: _oth, prefix: '₹', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {})),
        ),
        const SizedBox(height: 14),
        _preview(),
        const SizedBox(height: 14),
        DayField(label: bi('તારીખ', 'Date'), value: _day, last: dateOnly(DateTime.now()), onChanged: (DateTime d) => setState(() => _day = d)),
        const SizedBox(height: 14),
        FieldX(label: bi('નોંધ', 'Note'), controller: _note),
        const SizedBox(height: 14),
        if (_err.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(_err, style: ts(13, w: FontWeight.w700, c: Pal.bad))),
        _busy
            ? SizedBox(height: 52, child: Center(child: SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 2.6, color: Pal.brand))))
            : Btn(bi('સેવ કરો', 'Save'), icon: 'check', expand: true, onTap: _save),
      ],
    );
  }
}

// ------------------------------------------------------------------ detail
class DealDetail extends StatefulWidget {
  final String id;
  const DealDetail(this.id, {super.key});

  @override
  State<DealDetail> createState() => _DealDetailState();
}

class _DealDetailState extends State<DealDetail> {
  MillDeal? _d;

  @override
  void initState() {
    super.initState();
    tradeDoc.addListener(_tick);
    gstDoc.addListener(_tick);
    _load();
  }

  @override
  void dispose() {
    tradeDoc.removeListener(_tick);
    gstDoc.removeListener(_tick);
    super.dispose();
  }

  void _load() {
    MillDeal? f;
    for (final MillDeal x in millDeals()) {
      if (x.id == widget.id) {
        f = x;
        break;
      }
    }
    _d = f;
  }

  void _tick() {
    if (!mounted) return;
    setState(_load);
  }

  Future<void> _remove(MillDeal d) async {
    final bool go = await confirmBox(context, title: bi('આ ગાડી કાઢી નાખવી?', 'Delete this truck?'), text: bi('ગાડીની બધી નોંધ અને મળેલી રકમ કાયમ માટે કાઢી નંખાશે.', 'The truck and its received money are removed for good.'), yes: bi('હા, કાઢો', 'Yes, delete'), no: bi('ના', 'No'));
    if (!go) return;
    await removeDeal(d.id);
    if (mounted) Navigator.of(context).pop();
  }

  void _gstBill(MillDeal d) {
    final double kg = d.weighed ? d.millKg : d.loadKg;
    GstLine line = GstLine(desc: _itemOf(d), qty: kg, rate: d.sellRate, basis: 'mann', gst: 5);
    for (final List<String> p in kGstPresets) {
      if (p[1].toLowerCase() == _itemOf(d).toLowerCase()) {
        line = GstLine(desc: p[1], hsn: p[2], qty: kg, unit: p[5], rate: d.sellRate, basis: p[4], gst: double.tryParse(p[3]) ?? 5);
      }
    }
    openGstForm(
      context,
      prefill: GstPrefill(
        party: d.mill,
        vehicle: d.vehicle,
        note: bi('સીધી મિલ ગાડી', 'Direct mill truck'),
        lines: <GstLine>[line],
        toKhata: false,
        onSaved: (GstInv inv) => patchDeal(d.id, <String, dynamic>{'bill': inv.no}),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final MillDeal? d = _d;
    if (d == null) return EmptyBox(icon: 'truck', title: bi('આ ગાડી હવે નથી', 'This truck is gone'));
    final Map<String, double> bills = _billTotals();
    final DealCalc c = calcDeal(d, billTotal: d.billed ? bills[d.billNo.trim()] : null);
    final String st = dealStatus(d, c);
    final bool shortBad = d.weighed && c.shortKg > live.cfg.tol(d.loadKg);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Align(alignment: Alignment.centerLeft, child: Pill(_stLabel(st), tone: _stTone(st))),
        const SizedBox(height: 8),
        InfoRow(bi('ક્યાંથી', 'From'), d.seller.isEmpty ? '—' : d.seller),
        InfoRow(bi('માલ', 'Item'), _itemOf(d)),
        InfoRow(bi('ભરેલું વજન', 'Loaded weight'), '${grp(d.loadKg, dec: 2)} KG'),
        InfoRow(bi('મિલ વજન', 'Mill weight'), d.weighed ? '${grp(d.millKg, dec: 2)} KG' : bi('હજી આવ્યું નથી', 'not in yet')),
        if (d.weighed) InfoRow(bi('ઘટ', 'Short'), '${grp(c.shortKg, dec: 2)} KG · ${c.shortPct.toStringAsFixed(2)}%', color: shortBad ? Pal.bad : Pal.ok),
        divider(),
        InfoRow(bi('ખરીદ', 'Buy'), '${d.buyRate > 0 ? '₹${plainNum(d.buyRate)} · ' : ''}${inr(c.buyAmt, dec: 2)}'),
        InfoRow(bi('વેચાણ', 'Sell'), c.hasSell ? '₹${plainNum(d.sellRate)} · ${inr(c.sellAmt, dec: 2)}' : '—'),
        if (d.freight > 0) InfoRow(bi('ભાડું', 'Freight'), inr(d.freight, dec: 2)),
        if (d.labour > 0) InfoRow(bi('મજૂરી', 'Labour'), inr(d.labour, dec: 2)),
        if (d.commission > 0) InfoRow(bi('દલાલી', 'Commission'), inr(d.commission, dec: 2)),
        if (d.other > 0) InfoRow(bi('બીજું', 'Other'), inr(d.other, dec: 2)),
        InfoRow(bi('નફો', 'Profit'), c.hasSell ? inr(c.profit, dec: 2) : '—', bold: true, color: c.hasSell ? (c.profit >= 0 ? Pal.ok : Pal.bad) : null),
        if (c.hasSell) InfoRow(bi('૧૦૦ KG દીઠ નફો', 'Profit per 100 KG'), inr(c.perQtl(d.weighed ? d.millKg : d.loadKg), dec: 2)),
        divider(),
        if (kGstOn) InfoRow('GST ${bi('બિલ', 'bill')}', d.billed ? d.billNo : '—'),
        InfoRow(bi('મિલ પાસેથી લેવાના', 'To get from the mill'), inr(c.receivable, dec: 2)),
        for (final DealRecv r in d.recv)
          Row(
            children: <Widget>[
              Expanded(child: Text('${dmy(r.date)} · ${payModeLabel(r.mode)}${r.note.isEmpty ? '' : ' · ${r.note}'}', style: ts(12.5, c: Pal.muted))),
              Text(inr(r.amt, dec: 2), style: ts(13, w: FontWeight.w700, tab: true)),
              IconBtn('trash', size: 34, tip: bi('કાઢો', 'Delete'), onTap: () => removeDealRecv(d.id, r.id)),
            ],
          ),
        InfoRow(bi('હજી લેવાના', 'Still due'), inr(c.due, dec: 2), bold: true, color: c.due > 0.5 ? Pal.warn : Pal.ok),
        if (d.note.isNotEmpty) InfoRow(bi('નોંધ', 'Note'), d.note),
        const SizedBox(height: 14),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: <Widget>[
            if (!d.weighed) Btn(bi('મિલ વજન નાખો', 'Enter mill weight'), icon: 'scale', onTap: () => openPanel(context, title: bi('મિલ વજન', 'Mill weight'), sub: d.mill, width: 420, child: _MillKgForm(d))),
            Btn(bi('રકમ મળી', 'Money received'), icon: 'rupee', kind: BtnKind.amber, onTap: () => openPanel(context, title: bi('મિલ પાસેથી રકમ મળી', 'Money from the mill'), sub: d.mill, width: 420, child: _RecvForm(d, c.due > 0 ? c.due : 0))),
            if (kGstOn && !d.billed && c.hasSell) Btn(bi('GST બિલ બનાવો', 'Make GST bill'), icon: 'receipt', kind: BtnKind.tonal, onTap: () => _gstBill(d)),
            Btn('WhatsApp', icon: 'chat', kind: BtnKind.tonal, onTap: () => whatsappText(dealText(d, c))),
            Btn(bi('સુધારો', 'Edit'), icon: 'edit', kind: BtnKind.outline, onTap: () => openDealForm(context, edit: d)),
            Btn(bi('કાઢો', 'Delete'), icon: 'trash', kind: BtnKind.danger, onTap: () => _remove(d)),
          ],
        ),
      ],
    );
  }
}

class _MillKgForm extends StatefulWidget {
  final MillDeal d;
  const _MillKgForm(this.d);

  @override
  State<_MillKgForm> createState() => _MillKgFormState();
}

class _MillKgFormState extends State<_MillKgForm> {
  late final VoidCallback _accept = () {
    _save();
  };

  @override
  void initState() {
    super.initState();
    AcceptHub.push(_accept);
  }

  final TextEditingController _kg = TextEditingController();
  bool _busy = false;

  @override
  void dispose() {
    _kg.dispose();
    AcceptHub.pop(_accept);
    super.dispose();
  }

  Future<void> _save() async {
    final double kg = dbl(_kg.text);
    if (kg <= 0 || kg > kMaxLoadKg) return;
    setState(() => _busy = true);
    await patchDeal(widget.d.id, <String, dynamic>{'millKg': kg});
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final double kg = dbl(_kg.text);
    final double sh = kg > 0 ? widget.d.loadKg - kg : 0;
    final double pc = kg > 0 && widget.d.loadKg > 0 ? sh / widget.d.loadKg * 100 : 0;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        FieldX(label: bi('મિલ પર થયેલું વજન', 'Weight at the mill'), controller: _kg, suffix: 'KG', big: true, keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {})),
        const SizedBox(height: 10),
        if (kg > 0) Text('${bi('ઘટ', 'Short')}: ${grp(sh, dec: 2)} KG · ${pc.toStringAsFixed(2)}%', style: ts(13.5, w: FontWeight.w800, c: sh > live.cfg.tol(widget.d.loadKg) ? Pal.bad : Pal.ok)),
        const SizedBox(height: 14),
        _busy ? const Center(child: CircularProgressIndicator()) : Btn(bi('સેવ કરો', 'Save'), icon: 'check', expand: true, onTap: _save),
      ],
    );
  }
}

class _RecvForm extends StatefulWidget {
  final MillDeal d;
  final double due;
  const _RecvForm(this.d, this.due);

  @override
  State<_RecvForm> createState() => _RecvFormState();
}

class _RecvFormState extends State<_RecvForm> {
  late final VoidCallback _accept = () {
    _save();
  };

  @override
  void initState() {
    super.initState();
    AcceptHub.push(_accept);
  }

  late final TextEditingController _amt = TextEditingController(text: widget.due > 0 ? plainNum(widget.due) : '');
  final TextEditingController _note = TextEditingController();
  String _mode = 'bank';
  DateTime _day = dateOnly(DateTime.now());
  bool _busy = false;

  @override
  void dispose() {
    _amt.dispose();
    _note.dispose();
    AcceptHub.pop(_accept);
    super.dispose();
  }

  Future<void> _pick() async {
    final DateTime? d = await pickDay(context, _day, last: dateOnly(DateTime.now()));
    if (d != null && mounted) setState(() => _day = d);
  }

  Future<void> _save() async {
    final double a = dbl(_amt.text);
    if (a <= 0) return;
    setState(() => _busy = true);
    await addDealRecv(widget.d.id, date: _day, amt: a, mode: _mode, note: _note.text);
    app.toast('${bi('રકમ મળી', 'Received')} · ${inr(a)}');
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        FieldX(label: bi('રકમ', 'Amount'), controller: _amt, prefix: '₹', big: true, keyboard: const TextInputType.numberWithOptions(decimal: true)),
        const SizedBox(height: 12),
        ChipRow(
          labels: <String>[for (final List<String> k in kPayModes) bi(k[1], k[2])],
          index: kPayModes.indexWhere((List<String> k) => k[0] == _mode),
          onChanged: (int i) => setState(() => _mode = kPayModes[i][0]),
        ),
        const SizedBox(height: 12),
        DayField(label: bi('તારીખ', 'Date'), value: _day, last: dateOnly(DateTime.now()), onChanged: (DateTime d) => setState(() => _day = d)),
        const SizedBox(height: 14),
        FieldX(label: bi('નોંધ', 'Note'), controller: _note),
        const SizedBox(height: 14),
        _busy ? const Center(child: CircularProgressIndicator()) : Btn(bi('સેવ કરો', 'Save'), icon: 'check', expand: true, onTap: _save),
      ],
    );
  }
}

// ------------------------------------------------------------------ screen
class TradingScreen extends StatefulWidget {
  const TradingScreen({super.key});

  @override
  State<TradingScreen> createState() => _TradingState();
}

class _TradingState extends State<TradingScreen> {
  RangeSel _sel = RangeSel(4);
  int _tab = 0; // 0 trucks, 1 mill ledger
  String _mill = ''; // nameKey of the mill to show
  int _st = 0; // 0 all, 1 money pending, 2 paid

  List<PcCol> _cols() => <PcCol>[
        PcCol(bi('તારીખ', 'Date'), 100),
        PcCol(bi('ગાડી', 'Vehicle'), 120),
        PcCol(bi('ક્યાંથી', 'From'), 0),
        PcCol(bi('મિલ', 'Mill'), 170),
        PcCol(bi('ભરેલું KG', 'Load KG'), 100, right: true),
        PcCol(bi('મિલ KG', 'Mill KG'), 100, right: true),
        PcCol(bi('ઘટ %', 'Short %'), 80, right: true),
        PcCol(bi('નફો', 'Profit'), 110, right: true),
        PcCol(bi('સ્થિતિ', 'Status'), 120),
      ];

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[tradeDoc, gstDoc, prefDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 1100,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final Period p = _sel.period;
          final Map<String, double> bills = _billTotals();
          final List<MillDeal> all = millDeals();
          final Map<String, MillAcct> accts = millAccts(all, bills);
          final List<MillDeal> inP = all.where((MillDeal d) => p.has(d.date)).toList();
          double load = 0;
          double mkg = 0;
          double loadW = 0;
          double sell = 0;
          double profit = 0;
          for (final MillDeal d in inP) {
            final DealCalc c = calcDeal(d, billTotal: d.billed ? bills[d.billNo.trim()] : null);
            load += d.loadKg;
            if (d.weighed) {
              mkg += d.millKg;
              loadW += d.loadKg;
            }
            if (c.hasSell) {
              sell += c.sellAmt;
              profit += c.profit;
            }
          }
          double due = 0;
          for (final MillAcct a in accts.values) {
            if (a.due > 0.5) due += a.due;
          }
          final double shortKg = loadW - mkg;
          final double shortPct = loadW > 0 ? shortKg / loadW * 100 : 0;
          final List<MillDeal> shown = inP.where((MillDeal d) {
            if (_mill.isNotEmpty && nameKey(d.mill) != _mill) return false;
            final DealCalc c = calcDeal(d, billTotal: d.billed ? bills[d.billNo.trim()] : null);
            final String st = dealStatus(d, c);
            if (_st == 1) return st != 'paid';
            if (_st == 2) return st == 'paid';
            return true;
          }).toList();
          final List<MillAcct> ml = accts.values.toList()..sort((MillAcct a, MillAcct b) => b.due.compareTo(a.due));
          final List<PcCol> cols = _cols();
          final bool pc = app.stagePc;
          return <Widget>[
            ScreenHeader(bi('ટ્રેડિંગ / મિલ', 'Trading / mill'), sub: p.label, actions: <Widget>[
              IconBtn('plus', tip: bi('નવી ગાડી', 'New truck'), onTap: () => openDealForm(ctx)),
            ]),
            statusBanner(),
            RangeBar(sel: _sel, presets: const <int>[0, 2, 3, 4, 5, 6], onChanged: (RangeSel s) => setState(() => _sel = s)),
            const SizedBox(height: 12),
            HeroCard(
              title: bi('કુલ નફો (ગાડી પર)', 'Profit on the trucks'),
              value: inrC(profit),
              unit: '',
              sub: '${inP.length} ${bi('ગાડી', 'trucks')} · ${kgTxt(load)}',
              chips: <HeroChip>[
                HeroChip('rupee', '${bi('વેચાણ', 'Sales')} ${inrC(sell)}'),
                HeroChip('users', '${bi('મિલ પાસેથી લેવાના', 'Due from mills')} ${inrC(due)}'),
              ],
            ),
            const SizedBox(height: 12),
            metricGrid(ctx, <Widget>[
              MetricTile(label: bi('ભરેલું વજન', 'Loaded'), value: kgTxt(load), icon: 'truck', tone: 'blue'),
              MetricTile(label: bi('મિલ વજન', 'Mill weight'), value: kgTxt(mkg), icon: 'scale', tone: 'teal', sub: mkg > 0 ? '${bi('ભરેલા માંથી', 'of')} ${kgTxt(loadW)}' : null),
              MetricTile(label: bi('ઘટ', 'Short'), value: '${grp(shortKg, dec: 0)} KG', icon: 'trenddown', tone: shortPct > live.cfg.pct ? 'rose' : 'green', sub: '${shortPct.toStringAsFixed(2)}%'),
              MetricTile(label: bi('મિલ પાસેથી લેવાના', 'Due from mills'), value: inrC(due), icon: 'wallet', tone: 'amber', onTap: () => setState(() => _tab = 1)),
            ]),
            const SizedBox(height: 12),
            Btn(bi('નવી મિલ ગાડી', 'New mill truck'), icon: 'plus', expand: true, onTap: () => openDealForm(ctx)),
            const SizedBox(height: 12),
            ChipRow(labels: <String>[bi('ગાડીઓ', 'Trucks'), bi('મિલ મુજબ ખાતું', 'Mill ledger')], index: _tab, onChanged: (int i) => setState(() => _tab = i)),
            const SizedBox(height: 10),
            if (_tab == 1) ...<Widget>[
              if (ml.isEmpty) EmptyBox(icon: 'factory', title: bi('હજી કોઈ મિલ ગાડી નથી', 'No mill trucks yet')),
              for (final MillAcct a in ml)
                lineItem(
                  icon: 'factory',
                  tone: a.due > 0.5 ? 'amber' : 'green',
                  title: a.label,
                  sub: '${a.deals} ${bi('ગાડી', 'trucks')} · ${kgTxt(a.kg)} · ${bi('નફો', 'profit')} ${inrC(a.profit)}',
                  trailing: inr(a.due),
                  trailingSub: a.due > 0.5 ? bi('લેવાના', 'to get') : bi('ચૂકતે', 'clear'),
                  trailingColor: a.due > 0.5 ? Pal.warn : Pal.ok,
                  onTap: () => setState(() {
                    _mill = a.key;
                    _tab = 0;
                  }),
                ),
            ] else ...<Widget>[
              ChipRow(labels: <String>[bi('બધી', 'All'), bi('પૈસા બાકી', 'Money pending'), bi('પૈસા મળ્યા', 'Paid')], index: _st, onChanged: (int i) => setState(() => _st = i)),
              if (_mill.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Align(alignment: Alignment.centerLeft, child: Btn('${accts[_mill]?.label ?? _mill}  ✕', kind: BtnKind.tonal, dense: true, onTap: () => setState(() => _mill = ''))),
                ),
              const SizedBox(height: 10),
              if (shown.isEmpty) EmptyBox(icon: 'truck', title: bi('આ સમયમાં કોઈ ગાડી નથી', 'No trucks in this period'), sub: bi('ઉપર "નવી મિલ ગાડી" દબાવો', 'Tap "New mill truck" above')),
              if (pc && shown.isNotEmpty) ...<Widget>[
                pcHead(cols),
                for (final MillDeal d in shown.take(300)) _tableRow(ctx, d, cols, bills),
              ] else
                for (final MillDeal d in shown.take(200)) _tile(ctx, d, bills),
            ],
          ];
        },
      ),
    );
  }

  Widget _tableRow(BuildContext ctx, MillDeal d, List<PcCol> cols, Map<String, double> bills) {
    final DealCalc c = calcDeal(d, billTotal: d.billed ? bills[d.billNo.trim()] : null);
    final String st = dealStatus(d, c);
    final bool bad = d.weighed && c.shortKg > live.cfg.tol(d.loadKg);
    return pcRow(
      cols,
      <Widget>[
        pcTd(dmy(d.date)),
        pcTd(d.vehicle.isEmpty ? '-' : d.vehicle, bold: true),
        pcTd(d.seller.isEmpty ? '-' : d.seller),
        pcTd(d.mill),
        pcTd(grp(d.loadKg, dec: 0), num: true),
        pcTd(d.weighed ? grp(d.millKg, dec: 0) : '-', num: true),
        pcTd(d.weighed ? c.shortPct.toStringAsFixed(2) : '-', num: true, c: bad ? Pal.bad : null),
        pcTd(c.hasSell ? grp(c.profit, dec: 0) : '-', num: true, bold: true, c: c.hasSell ? (c.profit >= 0 ? Pal.ok : Pal.bad) : null),
        pcTd(_stLabel(st)),
      ],
      bar: Pal.tone(_stTone(st)).fg,
      onTap: () => openDealDetail(ctx, d),
    );
  }

  Widget _tile(BuildContext ctx, MillDeal d, Map<String, double> bills) {
    final DealCalc c = calcDeal(d, billTotal: d.billed ? bills[d.billNo.trim()] : null);
    final String st = dealStatus(d, c);
    return lineItem(
      icon: 'truck',
      tone: _stTone(st),
      title: '${d.vehicle.isEmpty ? '-' : d.vehicle} · ${d.mill}',
      sub: '${dayLabel(d.date)} · ${d.seller.isEmpty ? '-' : d.seller} · ${grp(d.loadKg, dec: 0)}${d.weighed ? ' → ${grp(d.millKg, dec: 0)}' : ''} KG',
      trailing: c.hasSell ? inr(c.profit) : '—',
      trailingSub: _stLabel(st),
      trailingColor: c.hasSell ? (c.profit >= 0 ? Pal.ok : Pal.bad) : null,
      onTap: () => openDealDetail(ctx, d),
    );
  }
}
