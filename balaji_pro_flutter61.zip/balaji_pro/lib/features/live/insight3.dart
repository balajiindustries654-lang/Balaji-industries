import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/engine.dart';
import '../../data/insights.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../widgets/charts.dart';
import '../../widgets/common.dart';
import '../../widgets/page.dart';
import 'kit.dart';
import 'kit2.dart';
import 'ui.dart';

const List<Dim> _dims4 = <Dim>[Dim.farmer, Dim.village, Dim.broker, Dim.vehicle];

List<String> _dimLabels4() => <String>[bi('ખેડૂત', 'Farmers'), bi('ગામ', 'Villages'), bi('દલાલ', 'Brokers'), bi('ગાડી', 'Vehicles')];

// ================================================================== cohort
/// New farmers, returning farmers and the ones who stopped coming.
class CohortScreen extends StatefulWidget {
  const CohortScreen({super.key});

  @override
  State<CohortScreen> createState() => _CohortState();
}

class _CohortState extends State<CohortScreen> {
  RangeSel _sel = RangeSel(3);

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 900,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = _sel.period;
        final Map<String, DateTime> firstSeen = <String, DateTime>{};
        final Map<String, DateTime> lastSeen = <String, DateTime>{};
        final Map<String, String> label = <String, String>{};
        final Map<String, double> kgIn = <String, double>{};
        final Map<String, double> kgAll = <String, double>{};
        for (final Chit c in live.chits) {
          final String k = nameKey(c.farmer);
          if (k.isEmpty) continue;
          label.putIfAbsent(k, () => c.farmer);
          final DateTime? f = firstSeen[k];
          if (f == null || c.at.isBefore(f)) firstSeen[k] = c.at;
          final DateTime? l = lastSeen[k];
          if (l == null || c.at.isAfter(l)) lastSeen[k] = c.at;
          kgAll[k] = (kgAll[k] ?? 0) + c.cmpKg;
          if (p.has(c.at)) kgIn[k] = (kgIn[k] ?? 0) + c.cmpKg;
        }
        final List<String> active = kgIn.keys.toList();
        final List<String> newOnes = <String>[];
        final List<String> back = <String>[];
        for (final String k in active) {
          final DateTime f = firstSeen[k] ?? p.from;
          if (p.has(f)) {
            newOnes.add(k);
          } else {
            back.add(k);
          }
        }
        final List<String> gone = <String>[];
        for (final String k in kgAll.keys) {
          final DateTime l = lastSeen[k] ?? p.from;
          if (!kgIn.containsKey(k) && l.isBefore(p.from)) gone.add(k);
        }
        newOnes.sort((String a, String b) => (kgIn[b] ?? 0).compareTo(kgIn[a] ?? 0));
        back.sort((String a, String b) => (kgIn[b] ?? 0).compareTo(kgIn[a] ?? 0));
        gone.sort((String a, String b) => (kgAll[b] ?? 0).compareTo(kgAll[a] ?? 0));
        double newKg = 0;
        double backKg = 0;
        for (final String k in newOnes) {
          newKg += kgIn[k] ?? 0;
        }
        for (final String k in back) {
          backKg += kgIn[k] ?? 0;
        }
        PartyRef ref(String k) => PartyRef(Dim.farmer, k, label[k] ?? k);

        return <Widget>[
          ScreenHeader(bi('નવા / જૂના ખેડૂત', 'New vs returning farmers'), sub: p.label),
          statusBanner(),
          RangeBar(sel: _sel, presets: const <int>[2, 3, 4, 5], onChanged: (RangeSel s) => setState(() => _sel = s)),
          const SizedBox(height: 12),
          if (live.days < 90) noteBox('info', 'blue', bi('ડેટા છેલ્લા ${live.days} દિવસનો જ છે - "નવા" એટલે આ ડેટામાં પહેલી વાર દેખાયા. સેટિંગમાં 180/365 કરો.', 'Data covers only the last ${live.days} days - "new" means first seen in it. Raise it in Settings.')),
          Panel(
            child: Row(
              children: <Widget>[
                DonutX(
                  size: 130,
                  thickness: 15,
                  center: '${active.length}',
                  sub: bi('ખેડૂત', 'farmers'),
                  parts: <DonutPart>[
                    DonutPart(bi('નવા', 'New'), newOnes.length.toDouble(), Pal.amber),
                    DonutPart(bi('જૂના', 'Returning'), back.length.toDouble(), Pal.brand),
                  ],
                ),
                const SizedBox(width: 18),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      LegendDot(Pal.amber, bi('નવા', 'New'), value: '${newOnes.length} · ${kgShort(newKg)}'),
                      const SizedBox(height: 8),
                      LegendDot(Pal.brand, bi('જૂના', 'Returning'), value: '${back.length} · ${kgShort(backKg)}'),
                      const SizedBox(height: 8),
                      LegendDot(Pal.faint, bi('આવતા બંધ', 'Stopped coming'), value: '${gone.length}'),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          caption(bi('નવા ખેડૂત', 'New farmers')),
          if (newOnes.isEmpty) Padding(padding: const EdgeInsets.all(12), child: Text(bi('આ સમયમાં કોઈ નવો ખેડૂત નથી', 'No new farmer in this period'), style: ts(13, c: Pal.muted))),
          for (final String k in newOnes.take(10))
            lineItem(icon: 'person_add', tone: 'amber', title: label[k] ?? k, sub: '${bi('પહેલી વાર', 'first')} ${dm(firstSeen[k] ?? p.from)}', trailing: kgShort(kgIn[k] ?? 0), onTap: () => openParty(ref(k))),
          const SizedBox(height: 6),
          caption(bi('આવતા બંધ થયેલા (પહેલાં આવતા હતા)', 'Stopped coming (came before)')),
          if (gone.isEmpty) Padding(padding: const EdgeInsets.all(12), child: Text(bi('કોઈ નથી', 'None'), style: ts(13, c: Pal.muted))),
          for (final String k in gone.take(10))
            lineItem(icon: 'agri', tone: 'rose', title: label[k] ?? k, sub: '${bi('છેલ્લે', 'last')} ${dm(lastSeen[k] ?? p.from)} · ${sinceTxt(lastSeen[k] ?? p.from)} ${bi('પહેલાં', 'ago')}', trailing: kgShort(kgAll[k] ?? 0), onTap: () => openParty(ref(k))),
        ];
      },
    );
  }
}

// ================================================================ farmer due
class _Due {
  final String key;
  final String label;
  final double avgGap;
  final int since;
  final double kg;
  final String mobile;
  final String village;
  final int visits;
  const _Due(this.key, this.label, this.avgGap, this.since, this.kg, this.mobile, this.village, this.visits);
  double get ratio => avgGap <= 0 ? 0 : since / avgGap;
}

/// Farmers who usually come every few days and are now late - call them.
class FarmerDueScreen extends StatefulWidget {
  const FarmerDueScreen({super.key});

  @override
  State<FarmerDueScreen> createState() => _FarmerDueState();
}

class _FarmerDueState extends State<FarmerDueScreen> {
  int _tab = 0;

  void _open(BuildContext context, _Due d) {
    final String msg = bi(
      'નમસ્તે ${d.label}, બાલાજી ઇન્ડસ્ટ્રીઝ તરફથી. ઘણા દિવસથી તમારો માલ આવ્યો નથી. માલ તૈયાર હોય તો જણાવશો.',
      'Hello ${d.label}, from Balaji Industries. We have not received your goods for a few days. Please let us know when your stock is ready.',
    );
    openPanel(
      context,
      title: d.label,
      sub: d.village,
      width: 460,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          InfoRow(bi('સામાન્ય રીતે આવે', 'Usually comes'), bi('દર ${d.avgGap.toStringAsFixed(1)} દિવસે', 'every ${d.avgGap.toStringAsFixed(1)} days')),
          InfoRow(bi('છેલ્લે આવ્યા', 'Last came'), bi('${d.since} દિવસ પહેલાં', '${d.since} days ago')),
          InfoRow(bi('કુલ ફેરા', 'Visits'), '${d.visits}'),
          InfoRow(bi('કુલ માલ', 'Total'), kgShort(d.kg)),
          InfoRow(bi('મોબાઇલ', 'Mobile'), d.mobile.isEmpty ? '—' : d.mobile),
          const SizedBox(height: 14),
          if (d.mobile.isNotEmpty) Btn(bi('મોબાઇલ નંબર કૉપિ', 'Copy mobile number'), icon: 'phone', kind: BtnKind.tonal, expand: true, onTap: () => copyText(d.mobile, msg: bi('નંબર કૉપિ થયો', 'Number copied'))),
          if (d.mobile.isNotEmpty) const SizedBox(height: 8),
          Btn(bi('WhatsApp સંદેશ કૉપિ', 'Copy WhatsApp message'), icon: 'chat', kind: BtnKind.outline, expand: true, onTap: () => copyText(msg, msg: bi('સંદેશ કૉપિ થયો', 'Message copied'))),
          const SizedBox(height: 8),
          Btn(bi('પ્રોફાઇલ ખોલો', 'Open profile'), icon: 'user', kind: BtnKind.ghost, expand: true, onTap: () {
            Navigator.of(context).pop();
            openParty(PartyRef(Dim.farmer, d.key, d.label));
          }),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 800,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final DateTime today = dayOf(DateTime.now());
        final Map<String, Set<String>> dayMap = <String, Set<String>>{};
        final Map<String, double> kg = <String, double>{};
        final Map<String, String> label = <String, String>{};
        final Map<String, String> mobile = <String, String>{};
        final Map<String, DateTime> mobAt = <String, DateTime>{};
        final Map<String, String> village = <String, String>{};
        for (final Chit c in live.chits) {
          final String k = nameKey(c.farmer);
          if (k.isEmpty) continue;
          dayMap.putIfAbsent(k, () => <String>{}).add(dayKey(c.at));
          kg[k] = (kg[k] ?? 0) + c.cmpKg;
          label.putIfAbsent(k, () => c.farmer);
          final DateTime? ma = mobAt[k];
          if (c.mobile.isNotEmpty && (ma == null || c.at.isAfter(ma))) {
            mobile[k] = c.mobile;
            mobAt[k] = c.at;
          }
          if (c.village.isNotEmpty) village[k] = c.village;
        }
        final List<_Due> overdue = <_Due>[];
        final List<_Due> soon = <_Due>[];
        for (final MapEntry<String, Set<String>> e in dayMap.entries) {
          if (e.value.length < 3) continue;
          final List<String> sorted = e.value.toList()..sort();
          final List<DateTime> ds = <DateTime>[for (final String s in sorted) DateTime.parse(s)];
          double sum = 0;
          for (int i = 1; i < ds.length; i++) {
            sum += ds[i].difference(ds[i - 1]).inDays;
          }
          double avg = sum / (ds.length - 1);
          if (avg < 1) avg = 1;
          final int since = daysBetween(ds.last, today);
          final _Due d = _Due(e.key, label[e.key] ?? e.key, avg, since, kg[e.key] ?? 0, mobile[e.key] ?? '', village[e.key] ?? '', ds.length);
          if (d.ratio >= 1.3 && since >= 3) {
            overdue.add(d);
          } else if (d.ratio >= 0.8 && since >= 1) {
            soon.add(d);
          }
        }
        overdue.sort((_Due a, _Due b) => b.kg.compareTo(a.kg));
        soon.sort((_Due a, _Due b) => b.kg.compareTo(a.kg));
        final List<_Due> shown = _tab == 0 ? overdue : soon;
        return <Widget>[
          ScreenHeader(bi('ખેડૂત ક્યારે આવશે', 'When will farmers come'), sub: bi('જેમનો આવવાનો સમય થઈ ગયો', 'Those whose usual time has come')),
          statusBanner(),
          ChipRow(
            labels: <String>['${bi('મોડા', 'Late')} (${overdue.length})', '${bi('આજકાલમાં આવશે', 'Due soon')} (${soon.length})'],
            index: _tab,
            onChanged: (int i) => setState(() => _tab = i),
          ),
          const SizedBox(height: 12),
          noteBox('info', 'blue', _tab == 0 ? bi('સામાન્ય ગાળા કરતાં 1.3 ગણા દિવસ થઈ ગયા - ફોન કરો', 'More than 1.3× their usual gap has passed - call them') : bi('થોડા દિવસમાં આવવાની શક્યતા', 'Likely to come in the next few days')),
          if (shown.isEmpty) EmptyBox(icon: 'agri', title: bi('કોઈ નથી', 'Nobody here')),
          for (final _Due d in shown.take(40))
            lineItem(
              icon: 'agri',
              tone: _tab == 0 ? 'rose' : 'amber',
              title: d.label,
              sub: '${bi('દર', 'every')} ${d.avgGap.toStringAsFixed(1)} ${bi('દિવસે', 'days')} · ${bi('છેલ્લે', 'last')} ${d.since} ${bi('દિવસ પહેલાં', 'days ago')}${d.village.isEmpty ? '' : ' · ${d.village}'}',
              trailing: kgShort(d.kg),
              trailingSub: d.mobile.isEmpty ? null : d.mobile,
              onTap: () => _open(ctx, d),
            ),
        ];
      },
    );
  }
}

// ============================================================== village days
/// Which village sends goods on which weekday.
class VillageDaysScreen extends StatefulWidget {
  const VillageDaysScreen({super.key});

  @override
  State<VillageDaysScreen> createState() => _VillageDaysState();
}

class _VillageDaysState extends State<VillageDaysScreen> {
  int _metric = 0;

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 900,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Map<String, List<double>> grid = <String, List<double>>{};
        final Map<String, String> label = <String, String>{};
        final Map<String, double> tot = <String, double>{};
        for (final Chit c in live.chits) {
          final String k = nameKey(c.village);
          if (k.isEmpty) continue;
          label.putIfAbsent(k, () => c.village);
          final List<double> row = grid.putIfAbsent(k, () => List<double>.filled(7, 0));
          final double v = _metric == 0 ? c.cmpKg / 1000 : 1;
          row[c.at.weekday - 1] += v;
          tot[k] = (tot[k] ?? 0) + c.cmpKg;
        }
        final List<String> keys = grid.keys.toList();
        keys.sort((String a, String b) => (tot[b] ?? 0).compareTo(tot[a] ?? 0));
        final List<String> top = keys.take(12).toList();
        String short(String s) {
          final int p = s.indexOf('(');
          final String t = (p > 0 ? s.substring(0, p) : s).trim();
          return t.length > 8 ? t.substring(0, 8) : t;
        }

        final List<List<double>> data = <List<double>>[for (final String k in top) grid[k] ?? List<double>.filled(7, 0)];
        final List<double> wd = List<double>.filled(7, 0);
        for (final String k in keys) {
          final List<double> r = grid[k] ?? List<double>.filled(7, 0);
          for (int i = 0; i < 7; i++) {
            wd[i] += r[i];
          }
        }
        int best = 0;
        for (int i = 1; i < 7; i++) {
          if (wd[i] > wd[best]) best = i;
        }
        return <Widget>[
          ScreenHeader(bi('ગામ × વાર', 'Village × weekday'), sub: bi('કયું ગામ કયા વારે માલ મોકલે છે', 'Which village sends on which day')),
          statusBanner(),
          ChipRow(
            labels: <String>[bi('વજન (ટન)', 'Weight (tons)'), bi('ચિઠ્ઠી સંખ્યા', 'Chit count')],
            index: _metric,
            onChanged: (int i) => setState(() => _metric = i),
          ),
          const SizedBox(height: 12),
          if (top.isEmpty)
            EmptyBox(icon: 'place', title: bi('હજી ડેટા નથી', 'No data yet'))
          else ...<Widget>[
            Panel(
              title: bi('ટોચના ${top.length} ગામ', 'Top ${top.length} villages'),
              child: HeatGrid(
                data: data,
                rowLabels: <String>[for (final String k in top) short(label[k] ?? k)],
                colLabels: <String>[for (int i = 0; i < 7; i++) (L.gu ? kDayGu[i] : kDayEn[i])],
                color: Pal.brand,
                height: 40.0 + 30.0 * top.length,
              ),
            ),
            const SizedBox(height: 12),
            noteBox('trophy', 'amber', bi('સૌથી વ્યસ્ત વાર: ${L.gu ? kDayGu[best] : kDayEn[best]}', 'Busiest weekday: ${kDayEn[best]}')),
            Panel(
              title: bi('વાર મુજબ કુલ', 'Total by weekday'),
              child: BarChartX(
                values: wd,
                labels: <String>[for (int i = 0; i < 7; i++) (L.gu ? kDayGu[i] : kDayEn[i])],
                color: Pal.info,
                highlight: best,
                axisFmt: (double v) => v.round().toString(),
                valueFmt: (double v) => v.round().toString(),
                height: 170,
              ),
            ),
          ],
        ];
      },
    );
  }
}

// ==================================================================== fleet
class _VInfo {
  final String key;
  String label;
  DateTime first;
  DateTime last;
  int n = 0;
  double kg = 0;
  _VInfo(this.key, this.label, this.first, this.last);
}

/// Vehicles: active, new, gone quiet and slow ones.
class FleetScreen extends StatefulWidget {
  const FleetScreen({super.key});

  @override
  State<FleetScreen> createState() => _FleetState();
}

class _FleetState extends State<FleetScreen> {
  RangeSel _sel = RangeSel(3);
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 800,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = _sel.period;
        final DateTime today = dayOf(DateTime.now());
        final Map<String, _VInfo> m = <String, _VInfo>{};
        void see(String vk, String label, DateTime at, double kg, bool inP) {
          if (vk.isEmpty) return;
          _VInfo? v = m[vk];
          if (v == null) {
            v = _VInfo(vk, label, at, at);
            m[vk] = v;
          }
          if (at.isBefore(v.first)) v.first = at;
          if (at.isAfter(v.last)) v.last = at;
          if (inP) {
            v.n++;
            v.kg += kg;
          }
        }

        for (final Chit c in live.chits) {
          see(c.vkey, c.vehicle, c.at, c.cmpKg, p.has(c.at));
        }
        for (final Kanta k in live.kantas) {
          see(k.vkey, k.vehicle, k.at, 0, false);
        }
        final List<_VInfo> active = m.values.where((_VInfo v) => v.n > 0).toList();
        active.sort((_VInfo a, _VInfo b) => b.kg.compareTo(a.kg));
        final List<_VInfo> fresh = active.where((_VInfo v) => p.has(v.first)).toList();
        final List<_VInfo> quiet = m.values.where((_VInfo v) => v.n == 0 && daysBetween(v.last, today) >= 10).toList();
        quiet.sort((_VInfo a, _VInfo b) => b.last.compareTo(a.last));

        // slow: average hours chit -> kanta per vehicle
        final Map<String, List<double>> hrs = <String, List<double>>{};
        for (final Turn t in turnaround(p)) {
          hrs.putIfAbsent(t.trip.vk, () => <double>[]).add(t.hours);
        }
        final List<MapEntry<String, double>> slow = <MapEntry<String, double>>[];
        hrs.forEach((String k, List<double> l) {
          if (l.length >= 2) {
            double s = 0;
            for (final double x in l) {
              s += x;
            }
            slow.add(MapEntry<String, double>(k, s / l.length));
          }
        });
        slow.sort((MapEntry<String, double> a, MapEntry<String, double> b) => b.value.compareTo(a.value));

        final List<Widget> list = <Widget>[];
        if (_tab == 0) {
          for (final _VInfo v in active.take(40)) {
            list.add(lineItem(icon: 'truck', tone: 'blue', title: v.label, sub: '${v.n} ${bi('ચિઠ્ઠી', 'chits')} · ${bi('છેલ્લે', 'last')} ${whenTxt(v.last)}', trailing: kgShort(v.kg), onTap: () => openParty(PartyRef(Dim.vehicle, v.key, v.label))));
          }
        } else if (_tab == 1) {
          for (final _VInfo v in fresh.take(40)) {
            list.add(lineItem(icon: 'truck', tone: 'amber', title: v.label, sub: '${bi('પહેલી વાર', 'first seen')} ${whenTxt(v.first)}', trailing: kgShort(v.kg), onTap: () => openParty(PartyRef(Dim.vehicle, v.key, v.label))));
          }
        } else if (_tab == 2) {
          for (final _VInfo v in quiet.take(40)) {
            list.add(lineItem(icon: 'truck', tone: 'slate', title: v.label, sub: '${bi('છેલ્લે', 'last seen')} ${dm(v.last)} · ${daysBetween(v.last, today)} ${bi('દિવસ', 'days')}', onTap: () => openParty(PartyRef(Dim.vehicle, v.key, v.label))));
          }
        } else {
          for (final MapEntry<String, double> e in slow.take(40)) {
            final _VInfo? v = m[e.key];
            if (v == null) continue;
            list.add(lineItem(icon: 'hourglass', tone: 'amber', title: v.label, sub: '${hrs[e.key]?.length ?? 0} ${bi('ફેરા', 'trips')}', trailing: hoursText(e.value), trailingSub: bi('ચિઠ્ઠી → કાંટો', 'chit → kanta'), onTap: () => openParty(PartyRef(Dim.vehicle, v.key, v.label))));
          }
        }
        if (list.isEmpty) list.add(EmptyBox(icon: 'truck', title: bi('કંઈ નથી', 'Nothing here')));

        return <Widget>[
          ScreenHeader(bi('ગાડીઓનો રિપોર્ટ', 'Fleet report'), sub: p.label),
          statusBanner(),
          RangeBar(sel: _sel, presets: const <int>[2, 3, 4, 5], onChanged: (RangeSel s) => setState(() => _sel = s)),
          const SizedBox(height: 10),
          ChipRow(
            labels: <String>[
              '${bi('સક્રિય', 'Active')} (${active.length})',
              '${bi('નવી', 'New')} (${fresh.length})',
              '${bi('શાંત', 'Quiet')} (${quiet.length})',
              '${bi('ધીમી', 'Slow')} (${slow.length})',
            ],
            index: _tab,
            onChanged: (int i) => setState(() => _tab = i),
          ),
          const SizedBox(height: 12),
          ...list,
        ];
      },
    );
  }
}

// ============================================================== labour work
class _Worker {
  final String id;
  int n = 0;
  DateTime? last;
  final Map<String, List<DateTime>> times = <String, List<DateTime>>{};
  _Worker(this.id);
}

/// Who worked on which day: a grid of entries per person per day.
class MajurWorkScreen extends StatefulWidget {
  const MajurWorkScreen({super.key});

  @override
  State<MajurWorkScreen> createState() => _MajurWorkState();
}

class _MajurWorkState extends State<MajurWorkScreen> {
  int _metric = 3;
  int _win = 1;
  static const List<int> _wins = <int>[7, 14, 30];

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 900,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final int w = _wins[_win];
        final Period p = lastDays(w);
        final Map<String, _Worker> people = <String, _Worker>{};
        final Map<String, List<double>> grid = <String, List<double>>{};
        void add(String by, DateTime at) {
          if (by.isEmpty || !p.has(at)) return;
          final _Worker pw = people.putIfAbsent(by, () => _Worker(by));
          pw.n++;
          if (pw.last == null || at.isAfter(pw.last!)) pw.last = at;
          pw.times.putIfAbsent(dayKey(at), () => <DateTime>[]).add(at);
          final List<double> row = grid.putIfAbsent(by, () => List<double>.filled(w, 0));
          row[daysBetween(p.from, at)] += 1;
        }

        if (_metric == 0 || _metric == 3) {
          for (final Chit c in live.chits) {
            add(c.by, c.at);
          }
        }
        if (_metric == 1 || _metric == 3) {
          for (final Kanta k in live.kantas) {
            add(k.by, k.at);
          }
        }
        if (_metric == 2 || _metric == 3) {
          for (final MaalRow r in live.maals) {
            add(r.by, r.at);
          }
        }
        final List<_Worker> list = people.values.toList();
        list.sort((_Worker a, _Worker b) => b.n.compareTo(a.n));
        final List<_Worker> top = list.take(12).toList();
        String nm(String id) {
          final String t = majurName(live.names, id);
          return t.length > 7 ? t.substring(0, 7) : t;
        }

        final int step = w <= 14 ? 1 : 3;
        return <Widget>[
          ScreenHeader(bi('કોણ ક્યારે કામ કરે', 'Who worked when'), sub: p.label),
          statusBanner(),
          Row(
            children: <Widget>[
              Expanded(
                child: ChipRow(
                  labels: <String>[bi('ચિઠ્ઠી', 'Chits'), bi('કાંટો', 'Kanta'), bi('માલ', 'Maal'), bi('બધું', 'All')],
                  index: _metric,
                  onChanged: (int i) => setState(() => _metric = i),
                ),
              ),
              const SizedBox(width: 8),
              Seg(dense: true, labels: const <String>['7', '14', '30'], index: _win, onChanged: (int i) => setState(() => _win = i)),
            ],
          ),
          const SizedBox(height: 12),
          if (top.isEmpty)
            EmptyBox(icon: 'users', title: bi('આ સમયમાં કોઈ એન્ટ્રી નથી', 'No entries in this period'))
          else ...<Widget>[
            Panel(
              title: bi('દિવસ મુજબ એન્ટ્રી', 'Entries per day'),
              child: HeatGrid(
                data: <List<double>>[for (final _Worker x in top) grid[x.id] ?? List<double>.filled(w, 0)],
                rowLabels: <String>[for (final _Worker x in top) nm(x.id)],
                colLabels: <String>[for (int i = 0; i < w; i++) (i % step == 0 ? '${addDays(p.from, i).day}' : '')],
                color: Pal.brand,
                height: 40.0 + 30.0 * top.length,
              ),
            ),
            const SizedBox(height: 12),
            caption(bi('સારાંશ', 'Summary')),
            for (final _Worker x in list.take(15))
              Builder(builder: (BuildContext c2) {
                final int dayN = x.times.length;
                double spanSum = 0;
                for (final List<DateTime> l in x.times.values) {
                  l.sort();
                  spanSum += l.last.difference(l.first).inMinutes / 60.0;
                }
                final double span = dayN == 0 ? 0 : spanSum / dayN;
                return lineItem(
                  icon: 'user',
                  tone: 'teal',
                  title: majurName(live.names, x.id),
                  sub: '$dayN/$w ${bi('દિવસ', 'days')} · ${bi('રોજ સરેરાશ', 'avg/day')} ${dayN == 0 ? 0 : (x.n / dayN).round()} · ${bi('કામનો સમય', 'span')} ${span.toStringAsFixed(1)} ${bi('કલાક', 'h')}',
                  trailing: '${x.n}',
                  trailingSub: x.last == null ? null : whenTxt(x.last!),
                );
              }),
          ],
        ];
      },
    );
  }
}

// ================================================================ tolerance
/// Try other difference limits and see how many trucks would be flagged.
class ToleranceScreen extends StatefulWidget {
  const ToleranceScreen({super.key});

  @override
  State<ToleranceScreen> createState() => _ToleranceState();
}

class _ToleranceState extends State<ToleranceScreen> {
  RangeSel _sel = RangeSel(3);
  double _pct = math.min(3.0, math.max(0.1, live.cfg.pct));
  double _floor = math.min(500.0, math.max(0.0, live.cfg.floorKg));
  bool _busy = false;

  Future<void> _apply() async {
    setState(() => _busy = true);
    final MatchCfg c = MatchCfg(pct: _pct, floorKg: _floor, waitH: live.cfg.waitH, windowH: live.cfg.windowH, direct: List<String>.from(live.cfg.direct));
    final String? e = await live.saveCfg(c);
    if (!mounted) return;
    setState(() => _busy = false);
    app.toast(e ?? bi('નવી મર્યાદા લાગુ થઈ', 'New limit applied'));
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 900,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = _sel.period;
        final List<Trip> cmp = live.trips.where((Trip t) => p.has(t.at) && t.both && t.chitKg > 0 && t.kantaKg > 0).toList();
        int nowBad = 0;
        int simBad = 0;
        final List<Trip> newBad = <Trip>[];
        final List<Trip> newOk = <Trip>[];
        final List<double> bins = List<double>.filled(13, 0);
        for (final Trip t in cmp) {
          final bool curBad = t.state == TripState.diff;
          final double tol = math.max(_floor, t.chitKg * _pct / 100);
          final bool simB = t.diff.abs() > tol;
          if (curBad) nowBad++;
          if (simB) simBad++;
          if (simB && !curBad) newBad.add(t);
          if (!simB && curBad) newOk.add(t);
          final int b = math.min(12, (t.diffPct.abs() / 0.25).floor());
          bins[b] += 1;
        }
        newBad.sort((Trip a, Trip b) => b.diff.abs().compareTo(a.diff.abs()));
        newOk.sort((Trip a, Trip b) => b.diff.abs().compareTo(a.diff.abs()));
        final bool changed = (_pct - live.cfg.pct).abs() > 0.001 || (_floor - live.cfg.floorKg).abs() > 0.5;
        return <Widget>[
          ScreenHeader(bi('ઘટની મર્યાદા અજમાવો', 'Tolerance simulator'), sub: bi('સેવ કર્યા વગર જુઓ કેટલી ગાડી પકડાય', 'See how many trucks would be flagged, without saving')),
          statusBanner(),
          RangeBar(sel: _sel, presets: const <int>[2, 3, 4, 5], onChanged: (RangeSel s) => setState(() => _sel = s)),
          const SizedBox(height: 12),
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Expanded(child: Text(bi('ટકાવારી મર્યાદા', 'Percentage limit'), style: ts(13.5, w: FontWeight.w700))),
                    Text('${_pct.toStringAsFixed(2)}%', style: ts(15, w: FontWeight.w800, c: Pal.brand, tab: true)),
                  ],
                ),
                Slider(value: _pct, min: 0.1, max: 3.0, divisions: 58, activeColor: Pal.brand, onChanged: (double v) => setState(() => _pct = v)),
                Row(
                  children: <Widget>[
                    Expanded(child: Text(bi('ઓછામાં ઓછી છૂટ (KG)', 'Minimum allowance (KG)'), style: ts(13.5, w: FontWeight.w700))),
                    Text('${_floor.round()} KG', style: ts(15, w: FontWeight.w800, c: Pal.brand, tab: true)),
                  ],
                ),
                Slider(value: _floor, min: 0, max: 500, divisions: 50, activeColor: Pal.brand, onChanged: (double v) => setState(() => _floor = v)),
                Text(bi('હાલની મર્યાદા: ${live.cfg.pct}% / ${live.cfg.floorKg.round()} KG', 'Current limit: ${live.cfg.pct}% / ${live.cfg.floorKg.round()} KG'), style: ts(12, c: Pal.muted)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          metricGrid(ctx, <Widget>[
            MetricTile(label: bi('સરખાવેલી ગાડી', 'Compared trucks'), value: '${cmp.length}', icon: 'truck', tone: 'blue'),
            MetricTile(label: bi('હાલ ફરક', 'Flagged now'), value: '$nowBad', icon: 'warn', tone: 'slate'),
            MetricTile(label: bi('નવી મર્યાદાએ ફરક', 'Flagged with new'), value: '$simBad', icon: 'cmp', tone: simBad > nowBad ? 'rose' : 'green', delta: deltaOf(simBad.toDouble(), nowBad.toDouble()), upIsGood: false),
            MetricTile(label: bi('બદલાયેલી', 'Changed'), value: '${newBad.length + newOk.length}', icon: 'swap', tone: 'amber', sub: '+${newBad.length} / -${newOk.length}'),
          ], pcCols: 4),
          const SizedBox(height: 12),
          Panel(
            title: bi('ફરક % મુજબ ગાડી', 'Trucks by difference %'),
            sub: bi('દરેક સ્તંભ = 0.25%', 'each bar = 0.25%'),
            child: BarChartX(
              values: bins,
              labels: <String>[for (int i = 0; i < 13; i++) (i % 2 == 0 ? (i * 0.25).toStringAsFixed(1) : '')],
              color: Pal.info,
              axisFmt: (double v) => v.round().toString(),
              valueFmt: (double v) => v.round().toString(),
              height: 170,
            ),
          ),
          const SizedBox(height: 12),
          if (changed) _busy
              ? const Center(child: CircularProgressIndicator())
              : Btn(bi('આ મર્યાદા સેટિંગમાં લાગુ કરો', 'Apply this limit'), icon: 'check', expand: true, onTap: _apply),
          if (newBad.isNotEmpty) ...<Widget>[
            caption(bi('નવી મર્યાદાએ ફરક ગણાશે', 'Would become a difference')),
            for (final Trip t in newBad.take(6)) tripTile(ctx, t),
          ],
          if (newOk.isNotEmpty) ...<Widget>[
            caption(bi('નવી મર્યાદાએ બરાબર ગણાશે', 'Would become OK')),
            for (final Trip t in newOk.take(6)) tripTile(ctx, t),
          ],
        ];
      },
    );
  }
}

// ============================================================ party compare
/// Two farmers / vehicles / villages / brokers side by side.
class PartyCompareScreen extends StatefulWidget {
  const PartyCompareScreen({super.key});

  @override
  State<PartyCompareScreen> createState() => _PartyCompareState();
}

class _PartyCompareState extends State<PartyCompareScreen> {
  int _dim = 0;
  final TextEditingController _a = TextEditingController();
  final TextEditingController _b = TextEditingController();

  @override
  void dispose() {
    _a.dispose();
    _b.dispose();
    super.dispose();
  }

  PartyRef? _find(List<PartySummary> all, String text) {
    final String t = nameKey(text);
    if (t.isEmpty) return null;
    for (final PartySummary s in all) {
      if (nameKey(s.ref.label) == t) return s.ref;
    }
    return null;
  }

  Widget _row(String label, String a, String b, {int better = 0}) {
    Widget cell(String v, bool good, TextAlign al) => Expanded(child: Text(v, textAlign: al, style: ts(14, w: good ? FontWeight.w800 : FontWeight.w600, c: good ? Pal.ok : null, tab: true)));
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: <Widget>[
          cell(a, better == 1, TextAlign.left),
          SizedBox(width: 92, child: Text(label, textAlign: TextAlign.center, style: ts(11.5, c: Pal.muted))),
          cell(b, better == 2, TextAlign.right),
        ],
      ),
    );
  }

  int _cmp(double a, double b, {bool higher = true}) {
    if ((a - b).abs() < 0.0001) return 0;
    if (higher) return a > b ? 1 : 2;
    return a < b ? 1 : 2;
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 760,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Dim dim = _dims4[_dim];
        final List<PartySummary> all = directoryOf(dim);
        all.sort((PartySummary x, PartySummary y) => y.kg.compareTo(x.kg));
        final List<String> opts = <String>[for (final PartySummary s in all.take(250)) s.ref.label];
        final PartyRef? ra = _find(all, _a.text);
        final PartyRef? rb = _find(all, _b.text);
        final List<Widget> out = <Widget>[
          ScreenHeader(bi('બે પાર્ટી સામસામે', 'Compare two parties')),
          statusBanner(),
          ChipRow(
            labels: _dimLabels4(),
            index: _dim,
            onChanged: (int i) => setState(() {
              _dim = i;
              _a.clear();
              _b.clear();
            }),
          ),
          const SizedBox(height: 12),
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                SuggestField(label: bi('પહેલી', 'First'), controller: _a, options: opts, onChanged: (String v) => setState(() {}), onPick: (String v) => setState(() {})),
                const SizedBox(height: 12),
                SuggestField(label: bi('બીજી', 'Second'), controller: _b, options: opts, onChanged: (String v) => setState(() {}), onPick: (String v) => setState(() {})),
              ],
            ),
          ),
          const SizedBox(height: 12),
        ];
        if (ra == null || rb == null) {
          out.add(noteBox('info', 'blue', bi('બંને નામ યાદીમાંથી પસંદ કરો', 'Pick both names from the suggestions')));
          return out;
        }
        final PartyData da = partyData(ra);
        final PartyData db = partyData(rb);
        double lossOf(PartyData d) => d.row == null ? 0 : d.row!.ghatPct;
        final int diffA = da.trips.where((Trip t) => t.state == TripState.diff).length;
        final int diffB = db.trips.where((Trip t) => t.state == TripState.diff).length;
        final double avgA = da.chits.isEmpty ? 0 : da.kg / da.chits.length;
        final double avgB = db.chits.isEmpty ? 0 : db.kg / db.chits.length;
        String top(PartyData d, Map<String, int> m) {
          final List<MapEntry<String, int>> l = topCounts(m, n: 1);
          return l.isEmpty ? '—' : l.first.key;
        }

        out.add(Panel(
          child: Column(
            children: <Widget>[
              Row(
                children: <Widget>[
                  Expanded(child: Text(ra.label, style: ts(15, w: FontWeight.w800, c: Pal.brand))),
                  const SizedBox(width: 8),
                  Expanded(child: Text(rb.label, textAlign: TextAlign.right, style: ts(15, w: FontWeight.w800, c: Pal.info))),
                ],
              ),
              divider(),
              _row(bi('ચિઠ્ઠી', 'Chits'), '${da.chits.length}', '${db.chits.length}', better: _cmp(da.chits.length.toDouble(), db.chits.length.toDouble())),
              _row(bi('કુલ માલ', 'Total'), kgShort(da.kg), kgShort(db.kg), better: _cmp(da.kg, db.kg)),
              _row(bi('ફેરા', 'Trips'), '${da.trips.length}', '${db.trips.length}', better: _cmp(da.trips.length.toDouble(), db.trips.length.toDouble())),
              _row(bi('સરેરાશ ચિઠ્ઠી', 'Avg chit'), kgShort(avgA), kgShort(avgB), better: _cmp(avgA, avgB)),
              _row(bi('ઘટ / વધ %', 'Loss / gain %'), da.row == null ? '—' : '${lossOf(da).toStringAsFixed(2)}%', db.row == null ? '—' : '${lossOf(db).toStringAsFixed(2)}%', better: (da.row == null || db.row == null) ? 0 : _cmp(lossOf(da).abs(), lossOf(db).abs(), higher: false)),
              _row(bi('ફરકવાળી ગાડી', 'Differing trips'), '$diffA', '$diffB', better: _cmp(diffA.toDouble(), diffB.toDouble(), higher: false)),
              _row(bi('પહેલી વાર', 'First seen'), da.first == null ? '—' : dm(da.first!), db.first == null ? '—' : dm(db.first!)),
              _row(bi('છેલ્લે', 'Last seen'), da.last == null ? '—' : dm(da.last!), db.last == null ? '—' : dm(db.last!)),
              _row(bi('મુખ્ય ગામ', 'Main village'), top(da, da.villages), top(db, db.villages)),
              _row(bi('મુખ્ય દલાલ', 'Main broker'), top(da, da.brokers), top(db, db.brokers)),
              _row(bi('મુખ્ય માલ', 'Main material'), top(da, da.commodities), top(db, db.commodities)),
            ],
          ),
        ));
        out.add(const SizedBox(height: 10));
        out.add(Row(
          children: <Widget>[
            tExp(child: Btn(ra.label, icon: 'user', kind: BtnKind.outline, dense: true, onTap: () => openParty(ra))),
            const SizedBox(width: 8),
            tExp(child: Btn(rb.label, icon: 'user', kind: BtnKind.outline, dense: true, onTap: () => openParty(rb))),
          ],
        ));
        return out;
      },
    );
  }
}

// ==================================================================== movers
class _Move {
  final String key;
  final String label;
  final double cur;
  final double prev;
  const _Move(this.key, this.label, this.cur, this.prev);
  double get change => cur - prev;
}

/// Who sends more / less than in the period before.
class MoversScreen extends StatefulWidget {
  const MoversScreen({super.key});

  @override
  State<MoversScreen> createState() => _MoversState();
}

class _MoversState extends State<MoversScreen> {
  RangeSel _sel = RangeSel(3);
  int _dim = 0;

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 800,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = _sel.period;
        final Period q = p.previous;
        final Dim dim = _dims4[_dim];
        final Map<String, double> cur = <String, double>{};
        final Map<String, double> prev = <String, double>{};
        final Map<String, String> label = <String, String>{};
        for (final Chit c in live.chits) {
          final String k = dimKey(dim, c);
          if (k.isEmpty) continue;
          if (p.has(c.at)) {
            cur[k] = (cur[k] ?? 0) + c.cmpKg;
            label.putIfAbsent(k, () => dimLabel(dim, c));
          } else if (q.has(c.at)) {
            prev[k] = (prev[k] ?? 0) + c.cmpKg;
            label.putIfAbsent(k, () => dimLabel(dim, c));
          }
        }
        final Set<String> keys = <String>{...cur.keys, ...prev.keys};
        final List<_Move> all = <_Move>[for (final String k in keys) _Move(k, label[k] ?? k, cur[k] ?? 0, prev[k] ?? 0)];
        final List<_Move> up = all.where((_Move m) => m.change > 0).toList();
        up.sort((_Move a, _Move b) => b.change.compareTo(a.change));
        final List<_Move> down = all.where((_Move m) => m.change < 0).toList();
        down.sort((_Move a, _Move b) => a.change.compareTo(b.change));

        Widget row(_Move m, bool isUp) {
          final String pctTxt = m.prev <= 0 ? bi('નવા', 'new') : (m.cur <= 0 ? bi('બંધ', 'stopped') : '${(m.change / m.prev * 100).abs().round()}%');
          return lineItem(
            icon: isUp ? 'arrowup' : 'arrowdown',
            tone: isUp ? 'green' : 'rose',
            title: m.label,
            sub: '${kgShort(m.prev)} → ${kgShort(m.cur)}',
            trailing: '${isUp ? '+' : '-'}${kgShort(m.change.abs())}',
            trailingColor: isUp ? Pal.ok : Pal.bad,
            trailingSub: pctTxt,
            onTap: () => openParty(PartyRef(dim, m.key, m.label)),
          );
        }

        return <Widget>[
          ScreenHeader(bi('કોણ વધ્યું / ઘટ્યું', 'Biggest movers'), sub: '${p.label} ${bi('vs પહેલાનો સમય', 'vs the period before')}'),
          statusBanner(),
          RangeBar(sel: _sel, presets: const <int>[2, 3, 4, 5], onChanged: (RangeSel s) => setState(() => _sel = s)),
          const SizedBox(height: 10),
          ChipRow(labels: _dimLabels4(), index: _dim, onChanged: (int i) => setState(() => _dim = i)),
          const SizedBox(height: 12),
          caption(bi('સૌથી વધુ વધ્યા', 'Up the most')),
          if (up.isEmpty) Padding(padding: const EdgeInsets.all(12), child: Text(bi('કોઈ નથી', 'None'), style: ts(13, c: Pal.muted))),
          for (final _Move m in up.take(8)) row(m, true),
          caption(bi('સૌથી વધુ ઘટ્યા', 'Down the most')),
          if (down.isEmpty) Padding(padding: const EdgeInsets.all(12), child: Text(bi('કોઈ નથી', 'None'), style: ts(13, c: Pal.muted))),
          for (final _Move m in down.take(8)) row(m, false),
        ];
      },
    );
  }
}

// ================================================================ party book
/// Brokers or villages with more detail than the plain ranking.
class PartyBookScreen extends StatefulWidget {
  final int dim;
  const PartyBookScreen({super.key, this.dim = 0});

  @override
  State<PartyBookScreen> createState() => _PartyBookState();
}

class _PartyBookState extends State<PartyBookScreen> {
  RangeSel _sel = RangeSel(3);
  late int _d = widget.dim;
  static const List<Dim> _ds = <Dim>[Dim.broker, Dim.village];

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 800,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = _sel.period;
        final Dim dim = _ds[_d];
        final Map<String, Set<String>> farmers = <String, Set<String>>{};
        final Map<String, Set<String>> vehicles = <String, Set<String>>{};
        double total = 0;
        for (final Chit c in live.chits) {
          if (!p.has(c.at)) continue;
          final String k = dimKey(dim, c);
          if (k.isEmpty) continue;
          total += c.cmpKg;
          farmers.putIfAbsent(k, () => <String>{}).add(nameKey(c.farmer));
          vehicles.putIfAbsent(k, () => <String>{}).add(c.vkey);
        }
        final List<GroupRow> rows = topBy(dim, p);
        double top3 = 0;
        for (int i = 0; i < rows.length && i < 3; i++) {
          top3 += rows[i].kg;
        }
        return <Widget>[
          ScreenHeader(bi('દલાલ / ગામ બુક', 'Broker / village book'), sub: p.label),
          statusBanner(),
          RangeBar(sel: _sel, presets: const <int>[2, 3, 4, 5], onChanged: (RangeSel s) => setState(() => _sel = s)),
          const SizedBox(height: 10),
          ChipRow(labels: <String>[bi('દલાલ', 'Brokers'), bi('ગામ', 'Villages')], index: _d, onChanged: (int i) => setState(() => _d = i)),
          const SizedBox(height: 12),
          metricGrid(ctx, <Widget>[
            MetricTile(label: dimName(dim), value: '${rows.length}', icon: dimIcon(dim), tone: 'violet'),
            MetricTile(label: bi('કુલ માલ', 'Total'), value: kgShort(total), icon: 'scale', tone: 'blue'),
            MetricTile(label: bi('ટોચના 3 નો હિસ્સો', 'Top-3 share'), value: total <= 0 ? '—' : '${(top3 / total * 100).round()}%', icon: 'pie', tone: 'amber'),
          ], pcCols: 3),
          const SizedBox(height: 12),
          if (rows.isEmpty) EmptyBox(icon: 'users', title: bi('આ સમયમાં ડેટા નથી', 'No data in this period')),
          for (final GroupRow r in rows.take(40))
            lineItem(
              icon: dimIcon(dim),
              tone: 'violet',
              title: r.label,
              sub: '${farmers[r.key]?.length ?? 0} ${bi('ખેડૂત', 'farmers')} · ${vehicles[r.key]?.length ?? 0} ${bi('ગાડી', 'vehicles')} · ${r.chits} ${bi('ચિઠ્ઠી', 'chits')}${r.matchedKg > 0 ? ' · ${bi('ઘટ', 'loss')} ${r.ghatPct.toStringAsFixed(2)}%' : ''}',
              trailing: kgShort(r.kg),
              trailingSub: total <= 0 ? null : '${(r.kg / total * 100).toStringAsFixed(1)}%',
              onTap: () => openParty(PartyRef(dim, r.key, r.label)),
            ),
        ];
      },
    );
  }
}

// ==================================================================== monthly
/// Totals month by month (or week by week).
class MonthlyScreen extends StatefulWidget {
  const MonthlyScreen({super.key});

  @override
  State<MonthlyScreen> createState() => _MonthlyState();
}

class _MonthlyState extends State<MonthlyScreen> {
  int _mode = 1;

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 900,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final DateTime today = dayOf(DateTime.now());
        final List<Widget> out = <Widget>[
          ScreenHeader(bi('મહિના / અઠવાડિયા મુજબ', 'Month / week totals'), sub: bi('છેલ્લા ${live.days} દિવસના ડેટામાંથી', 'From the last ${live.days} days of data')),
          statusBanner(),
          ChipRow(labels: <String>[bi('અઠવાડિયા', 'Weeks'), bi('મહિના', 'Months')], index: _mode, onChanged: (int i) => setState(() => _mode = i)),
          const SizedBox(height: 12),
        ];
        final List<String> labs = <String>[];
        final List<double> vals = <double>[];
        final List<Widget> rows = <Widget>[];
        if (_mode == 0) {
          final List<WeekPoint> ws = weeklyOf(dailySeries(lastDays(live.days)));
          for (final WeekPoint w in ws) {
            labs.add('${w.start.day}/${w.start.month}');
            vals.add(w.kantaKg / 1000);
          }
          for (final WeekPoint w in ws.reversed) {
            rows.add(lineItem(
              icon: 'cal',
              tone: 'blue',
              title: '${dm(w.start)} - ${dm(addDays(w.start, 6))}',
              sub: '${w.trips} ${bi('ગાડી', 'vehicles')} · ${bi('ચિઠ્ઠી', 'chits')} ${kgShort(w.chitKg)}${w.mChit > 0 ? ' · ${bi('ઘટ', 'loss')} ${w.ghatPct.toStringAsFixed(2)}%' : ''}',
              trailing: kgShort(w.kantaKg),
            ));
          }
        } else {
          DateTime start = DateTime(today.year, today.month, 1);
          final DateTime lim = lastDays(live.days).from;
          final List<DateTime> months = <DateTime>[];
          while (months.length < 14) {
            months.add(start);
            if (start.isBefore(lim) || (start.year == lim.year && start.month == lim.month)) break;
            start = DateTime(start.year, start.month - 1, 1);
          }
          for (final DateTime m in months.reversed) {
            final DateTime nx = DateTime(m.year, m.month + 1, 1);
            final Stats s = statsFor(Period(m, nx));
            labs.add(monthName(m.month));
            vals.add(s.kantaKg / 1000);
            rows.insert(
              0,
              lineItem(
                icon: 'month',
                tone: 'violet',
                title: monthYear(m),
                sub: '${s.trips} ${bi('ગાડી', 'vehicles')} · ${bi('ચિઠ્ઠી', 'chits')} ${kgShort(s.chitKg)}${s.compared > 0 ? ' · ${bi('ઘટ', 'loss')} ${s.ghatPct.toStringAsFixed(2)}%' : ''} · ${bi('માલ બેગ', 'bags')} ${s.bagsIn}/${s.bagsOut}',
                trailing: kgShort(s.kantaKg),
              ),
            );
          }
        }
        out.add(Panel(
          title: bi('કાંટો (ટન)', 'Kanta (tons)'),
          child: BarChartX(
            values: vals,
            labels: labs,
            color: Pal.info,
            axisFmt: (double v) => v.round().toString(),
            valueFmt: (double v) => v.toStringAsFixed(1),
            height: 190,
          ),
        ));
        out.add(const SizedBox(height: 12));
        out.addAll(rows);
        return out;
      },
    );
  }
}
