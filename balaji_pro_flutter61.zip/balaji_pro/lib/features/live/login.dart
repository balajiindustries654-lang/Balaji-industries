import 'package:flutter/material.dart';
import '../../core/i18n.dart';
import '../../core/icons.dart';
import '../../core/palette.dart';
import '../../core/version.dart' show kAppTitle;
import '../../data/live_store.dart';
import '../../shell/widgets.dart';
import '../../widgets/common.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Pal.bg,
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const BrandMark(size: 72),
            const SizedBox(height: 18),
            Text(kAppTitle, style: ts(24, w: FontWeight.w800, ls: -0.4)),
            const SizedBox(height: 22),
            SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 2.6, color: Pal.brand)),
          ],
        ),
      ),
    );
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  late final TextEditingController _m = TextEditingController(text: live.lastMobile);
  final TextEditingController _p = TextEditingController();
  bool _busy = false;
  bool _show = false;
  String _err = '';

  @override
  void dispose() {
    _m.dispose();
    _p.dispose();
    super.dispose();
  }

  Future<void> _go() async {
    if (_busy) return;
    final String mobile = _m.text.trim();
    final String pass = _p.text;
    if (mobile.replaceAll(RegExp(r'[^0-9]'), '').length < 10) {
      setState(() => _err = bi('સાચો મોબાઇલ નંબર લખો', 'Enter a valid mobile number'));
      return;
    }
    if (pass.isEmpty) {
      setState(() => _err = bi('પાસવર્ડ લખો', 'Enter the password'));
      return;
    }
    setState(() {
      _busy = true;
      _err = '';
    });
    final String? e = await live.login(mobile, pass);
    if (!mounted) return;
    setState(() {
      _busy = false;
      _err = e ?? '';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Pal.bg,
      child: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 420),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                const Align(alignment: Alignment.center, child: BrandMark(size: 68)),
                const SizedBox(height: 16),
                Text(kAppTitle, textAlign: TextAlign.center, style: ts(26, w: FontWeight.w800, ls: -0.5)),
                const SizedBox(height: 22),
                Surface(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      FieldX(
                        label: bi('મોબાઇલ નંબર', 'Mobile number'),
                        controller: _m,
                        keyboard: TextInputType.phone,
                        prefix: '+91',
                        action: TextInputAction.next,
                      ),
                      const SizedBox(height: 14),
                      FieldX(
                        label: bi('પાસવર્ડ', 'Password'),
                        controller: _p,
                        obscure: !_show,
                        action: TextInputAction.done,
                        onSubmitted: (String v) => _go(),
                        trailing: GestureDetector(
                          onTap: () => setState(() => _show = !_show),
                          child: Padding(
                            padding: const EdgeInsets.all(6),
                            child: Icon(ic(_show ? 'eye' : 'lock'), size: 20, color: Pal.muted),
                          ),
                        ),
                      ),
                      if (_err.isNotEmpty) ...<Widget>[
                        const SizedBox(height: 12),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Icon(ic('err'), size: 18, color: Pal.bad),
                            const SizedBox(width: 8),
                            Expanded(child: Text(_err, style: ts(13, w: FontWeight.w700, c: Pal.bad))),
                          ],
                        ),
                      ],
                      const SizedBox(height: 12),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Icon(ic('wifioff'), size: 16, color: Pal.muted),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              bi('ઇન્ટરનેટ ન હોય તો પણ ચાલશે: આ ફોન / PC પર પહેલા એક વાર ઇન્ટરનેટ સાથે લૉગિન કર્યું હોય તો ઑફલાઇન લૉગિન થશે.',
                                  'Works without internet too: if you logged in once with internet on this device, offline login works.'),
                              style: ts(12, c: Pal.muted, h: 1.4),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      _busy
                          ? SizedBox(height: 48, child: Center(child: SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2.6, color: Pal.brand))))
                          : Btn(bi('લૉગિન', 'Login'), icon: 'key', expand: true, onTap: _go),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Shown when the account is waiting for approval, or is a farmer account.
class BlockedScreen extends StatelessWidget {
  const BlockedScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: live,
      builder: (BuildContext c, Widget? w) {
        final bool farmer = live.me != null && live.me!.isFarmer;
        return Material(
          color: Pal.bg,
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 420),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    EmptyBox(
                      icon: farmer ? 'agri' : 'clock',
                      title: farmer ? bi('આ એપ સ્ટાફ માટે છે', 'This app is for staff') : bi('એડમિનની મંજૂરી બાકી છે', 'Waiting for admin approval'),
                    ),
                    if (!farmer) Btn(bi('ફરી તપાસો', 'Check again'), icon: 'refresh', kind: BtnKind.tonal, expand: true, onTap: live.recheck),
                    const SizedBox(height: 10),
                    Btn(bi('લૉગ આઉટ', 'Log out'), icon: 'out', kind: BtnKind.ghost, expand: true, onTap: () => live.logout()),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
