import '../../core/flags.dart';
import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/icons.dart';
import '../../core/palette.dart';
import '../../data/engine.dart';
import '../../data/insights.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../data/scan.dart';
import '../../widgets/common.dart';
import '../../widgets/page.dart';
import 'kit.dart';
import 'kit2.dart';
import 'ui.dart';

/// Median hours a truck normally needs from its last chit to the weighbridge.
double _typicalHours() {
  final List<Turn> tl = turnaround(lastDays(30));
  if (tl.length < 3) return 0;
  return median(<double>[for (final Turn x in tl) x.hours]);
}

int _bagsOf(Trip t) {
  int n = 0;
  for (final Chit c in t.chits) {
    n += c.bags;
  }
  return n;
}

String _tripLine(Trip t) {
  final StringBuffer b = StringBuffer();
  b.writeln('🚛 ${t.vehicle} · ${grp(t.chitKg)} KG');
  for (final Chit c in t.chits) {
    b.writeln('• ${c.farmer}${c.village.isEmpty ? '' : ' (${c.village})'} · ${grp(c.cmpKg)} KG${c.commodity.isEmpty ? '' : ' · ${matLabel(c.commodity)}'}');
  }
  b.writeln('${bi('ચિઠ્ઠી બની', 'Chit made')}: ${hm(t.at)} (${sinceTxt(t.at)} ${bi('પહેલાં', 'ago')})');
  return b.toString().trim();
}

String _allText(String title, List<Trip> l) {
  final StringBuffer b = StringBuffer();
  double kg = 0;
  for (final Trip t in l) {
    kg += t.chitKg;
  }
  b.writeln('$title - ${dmy(DateTime.now())} ${hm(DateTime.now())}');
  b.writeln('${l.length} ${bi('ગાડી', 'vehicles')} · ${grp(kg)} KG');
  b.writeln('----------------');
  for (final Trip t in l) {
    b.writeln(_tripLine(t));
    b.writeln();
  }
  return b.toString().trim();
}

// ================================================================== transit
/// Vehicles that have a chit but have not reached the weighbridge yet:
/// what is on each truck, since when, and when it should arrive.
class TransitScreen extends StatefulWidget {
  const TransitScreen({super.key});

  @override
  State<TransitScreen> createState() => _TransitState();
}

class _TransitState extends State<TransitScreen> {
  int _tab = 0;

  Widget _card(BuildContext context, Trip t, double typ, bool onWay) {
    final double hrs = DateTime.now().difference(t.at).inMinutes / 60.0;
    String tone = 'teal';
    String eta = '';
    if (onWay && typ > 0) {
      if (hrs <= typ) {
        eta = bi('લગભગ ${hoursText(typ - hrs)} માં પહોંચશે', 'Expected in about ${hoursText(typ - hrs)}');
      } else {
        eta = bi('સામાન્ય કરતાં ${hoursText(hrs - typ)} મોડી', '${hoursText(hrs - typ)} later than usual');
        tone = hrs > typ * 2.5 ? 'rose' : 'amber';
      }
    } else if (!onWay) {
      tone = t.state == TripState.direct ? 'blue' : 'rose';
    }
    final int bags = _bagsOf(t);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Surface(
        onTap: () => showTripDetail(context, t),
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Row(
              children: <Widget>[
                IconChip('truck', tone: tone, size: 44),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(vtxt(t.vehicle), style: ts(17, w: FontWeight.w800)),
                      const SizedBox(height: 2),
                      Text('${bi('ચિઠ્ઠી', 'Chit')} ${hm(t.at)} · ${sinceTxt(t.at)} ${bi('પહેલાં', 'ago')}', style: ts(12.5, c: Pal.muted)),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    Text('${grp(t.chitKg)} KG', style: ts(17, w: FontWeight.w800, tab: true)),
                    Text('${t.chits.length} ${bi('ચિઠ્ઠી', 'chits')}', style: ts(11.5, c: Pal.muted)),
                  ],
                ),
              ],
            ),
            if (eta.isNotEmpty) ...<Widget>[
              const SizedBox(height: 10),
              Pill(eta, tone: tone, icon: 'clock'),
            ],
            const SizedBox(height: 10),
            divider(),
            const SizedBox(height: 6),
            for (final Chit c in t.chits)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Avatar(c.farmer.isEmpty ? '?' : c.farmer, size: 30),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(vtxt(c.farmer), maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(13.5, w: FontWeight.w700)),
                          Text('${vtxt(c.village)}${c.commodity.isEmpty ? '' : ' · ${matLabel(c.commodity)}'}${c.no.isEmpty ? '' : ' · #${c.no}'}', maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12, c: Pal.muted)),
                        ],
                      ),
                    ),
                    Text('${grp(c.cmpKg)} KG', style: ts(13.5, w: FontWeight.w800, tab: true)),
                  ],
                ),
              ),
            if (bags > 0) ...<Widget>[
              const SizedBox(height: 4),
              Text('${bi('કુલ બેગ', 'Total bags')}: $bags', style: ts(12, c: Pal.muted)),
            ],
            if (onWay) ...<Widget>[
              const SizedBox(height: 10),
              Row(
                children: <Widget>[
                  tExp(child: Btn(bi('કાંટા એન્ટ્રી', 'Weigh now'), icon: 'scale', kind: BtnKind.tonal, dense: true, onTap: () => app.go(screenOn('weigh_check') ? 'weigh_check' : 'kanta_new', arg: t.vehicle))),
                  const SizedBox(width: 8),
                  tExp(child: Btn(bi('કૉપિ', 'Copy'), icon: 'copy', kind: BtnKind.outline, dense: true, onTap: () => copyText(_tripLine(t), msg: bi('કૉપિ થયું', 'Copied')))),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 900,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final DateTime now = DateTime.now();
        final List<Trip> onWay = live.trips.where((Trip t) => t.state == TripState.wait).toList();
        onWay.sort((Trip a, Trip b) => a.at.compareTo(b.at));
        final List<Trip> overdue = live.trips.where((Trip t) => t.state == TripState.noKanta && now.difference(t.at).inHours < 72).toList();
        final List<Trip> direct = live.trips.where((Trip t) => t.state == TripState.direct && now.difference(t.at).inHours < 24).toList();
        final double typ = _typicalHours();

        double kg = 0;
        final Set<String> farmers = <String>{};
        final Map<String, double> byMat = <String, double>{};
        final Map<String, double> byVil = <String, double>{};
        for (final Trip t in onWay) {
          kg += t.chitKg;
          for (final Chit c in t.chits) {
            if (c.farmer.isNotEmpty) farmers.add(nameKey(c.farmer));
            final String m = c.commodity.isEmpty ? '—' : matLabel(c.commodity);
            final String v = c.village.isEmpty ? '—' : c.village;
            byMat[m] = (byMat[m] ?? 0) + c.cmpKg;
            byVil[v] = (byVil[v] ?? 0) + c.cmpKg;
          }
        }
        final List<RankItem> matItems = <RankItem>[];
        final List<MapEntry<String, double>> me = byMat.entries.toList();
        me.sort((MapEntry<String, double> a, MapEntry<String, double> b) => b.value.compareTo(a.value));
        final List<Color> cols = chartColors();
        for (int i = 0; i < me.length; i++) {
          matItems.add(RankItem(me[i].key, me[i].value, kgTxt(me[i].value), cols[i % cols.length]));
        }
        final List<RankItem> vilItems = <RankItem>[];
        final List<MapEntry<String, double>> ve = byVil.entries.toList();
        ve.sort((MapEntry<String, double> a, MapEntry<String, double> b) => b.value.compareTo(a.value));
        for (int i = 0; i < ve.length && i < 6; i++) {
          vilItems.add(RankItem(ve[i].key, ve[i].value, kgTxt(ve[i].value), Pal.info));
        }

        final DateTime today = dayOf(now);
        final List<Trip> arrived = live.trips.where((Trip t) => t.both && dayOf(t.kanta!.at) == today).toList();
        arrived.sort((Trip a, Trip b) => b.kanta!.at.compareTo(a.kanta!.at));

        final List<Trip> shown = _tab == 0 ? onWay : (_tab == 1 ? overdue : direct);
        final String oldest = onWay.isEmpty ? '—' : sinceTxt(onWay.first.at);

        return <Widget>[
          ScreenHeader(bi('રસ્તામાં · Transit', 'On the way'), sub: bi('ચિઠ્ઠી બની ગઈ છે, કાંટો હજુ થયો નથી', 'Chit made, not yet on the weighbridge')),
          statusBanner(),
          HeroCard(
            title: bi('હમણાં રસ્તામાં માલ', 'Goods on the way now'),
            value: (kg / 1000).toStringAsFixed(1),
            unit: 'T',
            sub: typ > 0 ? bi('સામાન્ય રીતે ગાડી ${hoursText(typ)} માં કાંટે પહોંચે છે', 'Trucks normally reach the kanta in ${hoursText(typ)}') : null,
            chips: <HeroChip>[
              HeroChip('truck', '${onWay.length} ${bi('ગાડી', 'vehicles')}'),
              HeroChip('agri', '${farmers.length} ${bi('ખેડૂત', 'farmers')}'),
              HeroChip('hourglass', '${bi('સૌથી જૂની', 'oldest')} $oldest'),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: <Widget>[
              Expanded(
                child: ChipRow(
                  labels: <String>[
                    '${bi('રસ્તામાં', 'On the way')} (${onWay.length})',
                    '${bi('કાંટો બાકી', 'Overdue')} (${overdue.length})',
                    '${bi('સીધી મિલ', 'To the mill')} (${direct.length})',
                  ],
                  index: _tab,
                  onChanged: (int i) => setState(() => _tab = i),
                ),
              ),
              const SizedBox(width: 8),
              if (onWay.isNotEmpty)
                IconBtn('copy', tip: bi('બધી ગાડીનું લખાણ કૉપિ', 'Copy all'), onTap: () => copyText(_allText(bi('રસ્તામાં ગાડી', 'Vehicles on the way'), onWay), msg: bi('કૉપિ થયું - WhatsApp માં મોકલો', 'Copied - paste in WhatsApp'))),
            ],
          ),
          const SizedBox(height: 12),
          if (_tab == 1 && overdue.isNotEmpty) noteBox('warn', 'rose', bi('આ ગાડીની ચિઠ્ઠી છે પણ ${live.cfg.waitH} કલાકથી વધુ સમયથી કાંટો થયો નથી - તપાસો', 'These have a chit but no kanta for more than ${live.cfg.waitH} hours - check them')),
          if (_tab == 2 && direct.isNotEmpty) noteBox('info', 'blue', bi('એરંડા જેવો માલ સીધો મિલે જાય છે - અહીં કાંટો નથી થતો', 'Castor-type goods go straight to the mill - no kanta here')),
          if (shown.isEmpty)
            EmptyBox(icon: 'truck', title: _tab == 0 ? bi('હમણાં રસ્તામાં કોઈ ગાડી નથી', 'No vehicle on the way right now') : bi('કંઈ નથી', 'Nothing here'))
          else
            for (final Trip t in shown) _card(ctx, t, typ, _tab == 0),
          if (_tab == 0 && onWay.isNotEmpty) ...<Widget>[
            const SizedBox(height: 4),
            SplitPane(
              children: <Widget>[
                Panel(title: bi('કયો માલ', 'By material'), child: RankList(matItems)),
                Panel(title: bi('કયા ગામથી', 'By village'), child: RankList(vilItems)),
              ],
            ),
          ],
          const SizedBox(height: 12),
          Panel(
            title: bi('આજે કાંટે પહોંચી', 'Reached the kanta today'),
            sub: '${arrived.length} ${bi('ગાડી', 'vehicles')}',
            child: arrived.isEmpty
                ? Padding(padding: const EdgeInsets.all(8), child: Text(bi('આજે હજુ કોઈ ગાડીનો કાંટો થયો નથી', 'No vehicle weighed yet today'), style: ts(13, c: Pal.muted)))
                : Column(children: <Widget>[for (final Trip t in arrived.take(6)) tripTile(ctx, t)]),
          ),
        ];
      },
    );
  }
}

// ============================================================== weigh check
/// Before saving a kanta entry: type the vehicle and the weight and see at
/// once what the chits say and whether the difference is allowed.
class WeighCheckScreen extends StatefulWidget {
  final String vehicle;
  const WeighCheckScreen({super.key, this.vehicle = ''});

  @override
  State<WeighCheckScreen> createState() => _WeighCheckState();
}

class _WeighCheckState extends State<WeighCheckScreen> {
  late final TextEditingController _v = TextEditingController(text: widget.vehicle);
  final TextEditingController _kg = TextEditingController();

  @override
  void dispose() {
    _v.dispose();
    _kg.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 640,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final DateTime now = DateTime.now();
        final List<Trip> open = live.trips.where((Trip t) => t.chits.isNotEmpty && t.kanta == null && now.difference(t.at).inHours < 72).toList();
        open.sort((Trip a, Trip b) => b.at.compareTo(a.at));

        final String key = vehicleKey(_v.text);
        Trip? hit;
        List<Trip> cands = <Trip>[];
        if (key.length >= 3) {
          for (final Trip t in open) {
            if (t.vk == key) {
              hit = t;
              break;
            }
          }
          if (hit == null) {
            cands = open.where((Trip t) => t.vk.contains(key)).toList();
            if (cands.length == 1) hit = cands.first;
          }
        }
        final Trip? h = hit;
        final double kg = dbl(_kg.text);

        final List<Widget> out = <Widget>[
          ScreenHeader(bi('કાંટા ચેક', 'Weigh check'), sub: bi('સેવ કરતાં પહેલાં ફરક જુઓ', 'See the difference before saving')),
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                SuggestField(
                  label: bi('ગાડી નંબર (છેલ્લા 4 અંક પણ ચાલે)', 'Vehicle number (last 4 digits work)'),
                  controller: _v,
                  options: <String>[for (final Trip t in open) t.vehicle],
                  onChanged: (String v) => setState(() {}),
                  onPick: (String v) => setState(() {}),
                ),
                const SizedBox(height: 14),
                FieldX(
                  label: bi('કાંટાનું ચોખ્ખું વજન', 'Weighbridge net weight'),
                  controller: _kg,
                  big: true,
                  suffix: 'KG',
                  keyboard: const TextInputType.numberWithOptions(decimal: true),
                  onChanged: (String v) => setState(() {}),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
        ];

        if (key.length < 3) {
          out.add(noteBox('info', 'blue', bi('ગાડી નંબર લખો - રસ્તામાં હોય તો ચિઠ્ઠીનું વજન તરત દેખાશે', 'Type the vehicle - if it is on the way you will see its chit weight')));
          if (open.isNotEmpty) {
            out.add(caption(bi('હમણાં રસ્તામાં', 'On the way now')));
            for (final Trip t in open.take(8)) {
              out.add(lineItem(
                icon: 'truck',
                tone: 'amber',
                title: vtxt(t.vehicle),
                sub: '${t.farmers} · ${sinceTxt(t.at)} ${bi('પહેલાં', 'ago')}',
                trailing: '${grp(t.chitKg)} KG',
                onTap: () => setState(() => _v.text = t.vehicle),
              ));
            }
          }
        } else if (h == null) {
          if (cands.length > 1) {
            out.add(caption(bi('કઈ ગાડી?', 'Which vehicle?')));
            for (final Trip t in cands.take(8)) {
              out.add(lineItem(
                icon: 'truck',
                tone: 'amber',
                title: vtxt(t.vehicle),
                sub: t.farmers,
                trailing: '${grp(t.chitKg)} KG',
                onTap: () => setState(() => _v.text = t.vehicle),
              ));
            }
          } else {
            out.add(noteBox('warn', 'amber', bi('આ ગાડીની કોઈ ચિઠ્ઠી રસ્તામાં નથી. ચિઠ્ઠી બની છે કે નહીં ચેક કરો.', 'No chit is waiting for this vehicle. Check that the chit was made.')));
            if (kg > 0) {
              out.add(Btn(bi('તો પણ કાંટા એન્ટ્રી કરો', 'Weigh anyway'), icon: 'scale', kind: BtnKind.outline, expand: true, onTap: () {
                app.go('kanta_new', arg: ScanPrefill(kind: 'kanta', f: <String, String>{'vehicle': _v.text.trim(), 'kg': cleanNum(_kg.text)}, scanned: false));
              }));
            }
          }
        } else {
          final double tol = live.cfg.tol(h.chitKg);
          final double diff = kg - h.chitKg;
          final bool ok = diff.abs() <= tol;
          out.add(Panel(
            title: vtxt(h.vehicle),
            sub: '${sinceTxt(h.at)} ${bi('પહેલાં ચિઠ્ઠી બની', 'since the chit')}',
            action: Pill('${h.chits.length} ${bi('ચિઠ્ઠી', 'chits')}', tone: 'slate', small: true),
            child: Column(
              children: <Widget>[
                for (final Chit c in h.chits) InfoRow('${vtxt(c.farmer)} · ${vtxt(c.village)}', '${grp(c.cmpKg)} KG'),
                divider(),
                InfoRow(bi('ચિઠ્ઠીનું કુલ', 'Chit total'), '${grp(h.chitKg)} KG', bold: true),
                InfoRow(bi('માન્ય ફરક', 'Allowed difference'), '± ${grp(tol)} KG'),
              ],
            ),
          ));
          out.add(const SizedBox(height: 12));
          if (kg <= 0) {
            out.add(noteBox('info', 'blue', bi('હવે કાંટાનું વજન લખો', 'Now type the weighbridge weight')));
          } else {
            final String tone = ok ? 'green' : 'rose';
            out.add(Surface(
              color: Pal.tone(tone).bg,
              shadow: false,
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Icon(ic(ok ? 'check' : 'warn'), size: 26, color: Pal.tone(tone).fg),
                      const SizedBox(width: 10),
                      Expanded(child: Text(ok ? bi('બરાબર છે', 'Within the limit') : bi('ફરક વધારે છે!', 'Difference is too big!'), style: ts(18, w: FontWeight.w800, c: Pal.tone(tone).fg))),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text('${bi('ફરક', 'Difference')}: ${sk(diff)} KG (${h.chitKg > 0 ? (diff / h.chitKg * 100).toStringAsFixed(2) : '0'}%)', style: ts(15, w: FontWeight.w700, c: Pal.tone(tone).fg)),
                  if (!ok) Text(diff < 0 ? bi('કાંટો ચિઠ્ઠી કરતાં ઓછો છે - ઘટ', 'Kanta is lower than the chits - loss') : bi('કાંટો ચિઠ્ઠી કરતાં વધારે છે', 'Kanta is higher than the chits'), style: ts(13, c: Pal.tone(tone).fg)),
                ],
              ),
            ));
          }
          out.add(const SizedBox(height: 12));
          out.add(Btn(bi('આ વજનથી કાંટા એન્ટ્રી કરો', 'Continue to the kanta entry'), icon: 'check', expand: true, onTap: () {
            app.go('kanta_new', arg: ScanPrefill(kind: 'kanta', f: <String, String>{'vehicle': h.vehicle, 'kg': kg > 0 ? cleanNum(_kg.text) : ''}, scanned: false));
          }));
        }
        return out;
      },
    );
  }
}

// ============================================================ vehicle lookup
/// Type any part of a vehicle number and open its full history.
class VehicleLookupScreen extends StatefulWidget {
  const VehicleLookupScreen({super.key});

  @override
  State<VehicleLookupScreen> createState() => _VehicleLookupState();
}

class _VehicleLookupState extends State<VehicleLookupScreen> {
  final TextEditingController _q = TextEditingController();

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 720,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final String k = vehicleKey(_q.text);
        final List<PartySummary> all = directoryOf(Dim.vehicle);
        all.sort((PartySummary a, PartySummary b) => b.last.compareTo(a.last));
        final List<PartySummary> found = k.isEmpty ? all.take(25).toList() : all.where((PartySummary s) => s.ref.key.contains(k)).take(40).toList();
        final List<Widget> out = <Widget>[
          ScreenHeader(bi('ગાડી શોધો', 'Vehicle lookup'), sub: bi('નંબરનો કોઈ પણ ભાગ લખો', 'Type any part of the number')),
          SearchBox(hint: bi('જેમ કે 5828 અથવા GJ12CT', 'e.g. 5828 or GJ12CT'), controller: _q, onChanged: (String v) => setState(() {})),
          const SizedBox(height: 12),
        ];
        if (found.isEmpty) {
          out.add(EmptyBox(icon: 'truck', title: bi('આ નંબરની કોઈ ગાડી મળી નથી', 'No vehicle with this number')));
          return out;
        }
        if (found.length == 1) {
          final PartyData d = partyData(found.first.ref);
          out.add(HeroCard(
            title: found.first.ref.label,
            value: (d.kg / 1000).toStringAsFixed(1),
            unit: 'T',
            sub: bi('છેલ્લે ${whenTxt(found.first.last)}', 'Last seen ${whenTxt(found.first.last)}'),
            chips: <HeroChip>[
              HeroChip('receipt', '${d.chits.length} ${bi('ચિઠ્ઠી', 'chits')}'),
              HeroChip('scale', '${d.kantas.length} ${bi('કાંટા', 'kanta')}'),
              HeroChip('route', '${d.trips.length} ${bi('ફેરા', 'trips')}'),
            ],
            onTap: () => openParty(found.first.ref),
          ));
          out.add(const SizedBox(height: 12));
          out.add(caption(bi('છેલ્લા ફેરા', 'Latest trips')));
          for (final Trip t in d.trips.take(6)) {
            out.add(tripTile(ctx, t));
          }
          out.add(Btn(bi('આખી પ્રોફાઇલ ખોલો', 'Open full profile'), icon: 'user', kind: BtnKind.tonal, expand: true, onTap: () => openParty(found.first.ref)));
          return out;
        }
        out.add(caption(k.isEmpty ? bi('તાજેતરની ગાડીઓ', 'Recent vehicles') : '${found.length} ${bi('ગાડી મળી', 'found')}'));
        for (final PartySummary s in found) {
          out.add(lineItem(
            icon: 'truck',
            tone: 'blue',
            title: s.ref.label,
            sub: '${s.chits} ${bi('ચિઠ્ઠી', 'chits')} · ${s.kantas} ${bi('કાંટા', 'kanta')} · ${whenTxt(s.last)}',
            trailing: kgTxt(s.kg),
            onTap: () => openParty(s.ref),
          ));
        }
        return out;
      },
    );
  }
}

// ================================================================= arrivals
/// When the trucks that are on the way will probably reach the weighbridge,
/// hour by hour, so the kanta team can get ready.
class ArrivalsScreen extends StatelessWidget {
  const ArrivalsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 800,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final DateTime now = DateTime.now();
        final double typ = _typicalHours();
        final List<Trip> onWay = live.trips.where((Trip t) => t.state == TripState.wait).toList();
        final List<MapEntry<Trip, DateTime>> eta = <MapEntry<Trip, DateTime>>[];
        for (final Trip t in onWay) {
          DateTime e = typ > 0 ? t.at.add(Duration(minutes: (typ * 60).round())) : now.add(const Duration(minutes: 30));
          if (e.isBefore(now)) e = now.add(const Duration(minutes: 10));
          eta.add(MapEntry<Trip, DateTime>(t, e));
        }
        eta.sort((MapEntry<Trip, DateTime> a, MapEntry<Trip, DateTime> b) => a.value.compareTo(b.value));

        final DateTime start = DateTime(now.year, now.month, now.day, now.hour);
        final List<double> kg = List<double>.filled(8, 0);
        for (final MapEntry<Trip, DateTime> e in eta) {
          final int idx = e.value.difference(start).inHours;
          if (idx >= 0 && idx < 8) {
            kg[idx] += e.key.chitKg;
          }
        }
        int peak = 0;
        for (int i = 1; i < 8; i++) {
          if (kg[i] > kg[peak]) peak = i;
        }
        double total = 0;
        for (final double v in kg) {
          total += v;
        }
        final List<Color> cols = <Color>[for (int i = 0; i < 8; i++) (i == peak && kg[peak] > 0) ? Pal.amber : Pal.info];
        final String text = <String>[
          '${bi('અપેક્ષિત આગમન', 'Expected arrivals')} - ${dmy(now)} ${hm(now)}',
          for (final MapEntry<Trip, DateTime> e in eta) '${hm(e.value)} · ${e.key.vehicle} · ${grp(e.key.chitKg)} KG',
        ].join('\n');

        return <Widget>[
          ScreenHeader(bi('આવનાર ગાડી · કલાક મુજબ', 'Expected arrivals'), sub: typ > 0 ? bi('સામાન્ય સમય ${hoursText(typ)}', 'usual time ${hoursText(typ)}') : bi('સરેરાશ સમય માટે ડેટા ઓછો છે', 'Not enough data for a usual time')),
          statusBanner(),
          HeroCard(
            title: bi('આવતા 8 કલાકમાં કાંટે આવશે', 'Reaching the kanta in the next 8 hours'),
            value: (total / 1000).toStringAsFixed(1),
            unit: 'T',
            sub: kg[peak] > 0 ? bi('સૌથી વધુ ભીડ ${pad2((start.hour + peak) % 24)}:00 વાગ્યે', 'Busiest around ${pad2((start.hour + peak) % 24)}:00') : null,
            chips: <HeroChip>[
              HeroChip('truck', '${onWay.length} ${bi('ગાડી રસ્તામાં', 'on the way')}'),
              HeroChip('clock', typ > 0 ? hoursText(typ) : '—'),
            ],
          ),
          const SizedBox(height: 12),
          Panel(
            title: bi('કલાક મુજબ માલ (KG)', 'Weight per hour (KG)'),
            sub: bi('પીળો = સૌથી વધુ ભીડ', 'amber = busiest hour'),
            child: MiniBars(
              values: kg,
              colors: cols,
              labels: <String>[for (int i = 0; i < 8; i++) pad2((start.hour + i) % 24)],
              height: 140,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: <Widget>[
              Expanded(child: caption(bi('ગાડી ક્યારે પહોંચશે', 'When each vehicle will arrive'))),
              if (eta.isNotEmpty) IconBtn('copy', size: 38, onTap: () => copyText(text, msg: bi('કૉપિ થયું', 'Copied'))),
            ],
          ),
          if (eta.isEmpty) EmptyBox(icon: 'truck', title: bi('હમણાં રસ્તામાં કોઈ ગાડી નથી', 'No vehicle on the way')),
          for (final MapEntry<Trip, DateTime> e in eta)
            lineItem(
              icon: 'truck',
              tone: DateTime.now().difference(e.key.at).inMinutes / 60.0 > typ * 1.5 && typ > 0 ? 'amber' : 'teal',
              title: vtxt(e.key.vehicle),
              sub: '${e.key.chits.map((Chit c) => c.farmer).where((String s) => s.isNotEmpty).take(2).join(', ')} · ${grp(e.key.chitKg)} KG',
              trailing: hm(e.value),
              trailingSub: sinceTxt(e.key.at),
              onTap: () => showTripDetail(ctx, e.key),
            ),
        ];
      },
    );
  }
}
