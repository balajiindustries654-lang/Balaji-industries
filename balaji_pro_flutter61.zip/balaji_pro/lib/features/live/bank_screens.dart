import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/app_state.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/bank.dart';
import '../../data/gst.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../data/money.dart';
import '../../data/owner_docs.dart';
import '../../data/trade.dart';
import '../../data/trading.dart';
import '../../widgets/common.dart';
import '../../widgets/page.dart';
import 'field.dart';
import 'kit.dart';
import 'kit2.dart';
import 'money_screens.dart';
import 'tally_data.dart' show TVoucher, tallyStore;
import 'ui.dart';

import '../../widgets/accept.dart';
// ======================================================================
// Bank / UPI auto-match
//  paste the bank statement (or SMS) -> every line is matched with a farmer / buyer / mill truck
//  or with an entry that is already in the books -> sure ones can be posted together
// ======================================================================

String _kindLabel(String k) {
  switch (k) {
    case 'pay':
      return bi('ખેડૂતને ચૂકવ્યા', 'Paid to farmer');
    case 'recv':
      return bi('ખરીદદાર પાસેથી મળ્યા', 'From buyer');
    case 'deal':
      return bi('મિલ ગાડીના પૈસા', 'Mill truck money');
    case 'exp':
      return bi('ખર્ચ', 'Expense');
    case 'in':
      return bi('આવક', 'Income');
    case 'exists':
      return bi('પહેલેથી નોંધેલ', 'Already entered');
    case 'ignore':
      return bi('છોડી દીધી', 'Ignored');
  }
  return '';
}

String _sugText(BankMatch m) {
  switch (m.kind) {
    case 'exists':
      return '${bi('પહેલેથી નોંધેલ', 'Already entered')}: ${m.partyLabel}';
    case 'exp':
      return bi('બેંક ચાર્જ → ખર્ચ', 'Bank charge → expense');
    case 'deal':
      return '${bi('મિલ ગાડી', 'Mill truck')}: ${m.partyLabel}';
  }
  if (m.hasParty) return '→ ${m.partyLabel}';
  return bi('ઓળખાયું નથી', 'Not recognised');
}

int _gap(DateTime a, DateTime b) => a.difference(b).inDays.abs();

// ------------------------------------------------------------- tally check
Map<int, List<TVoucher>> _tallyIdx() {
  final Map<int, List<TVoucher>> m = <int, List<TVoucher>>{};
  for (final TVoucher v in tallyStore.vouchers) {
    if (v.cancelled || v.optional) continue;
    if (v.base != 'payment' && v.base != 'receipt') continue;
    if (v.mode == 'cash') continue;
    m.putIfAbsent(v.amount.round(), () => <TVoucher>[]).add(v);
  }
  return m;
}

/// The Tally bank voucher of the same money (same UTR, or the same amount within a few days).
TVoucher? _tallyHit(BankLine l, Map<int, List<TVoucher>> idx) {
  final String base = l.isDr ? 'payment' : 'receipt';
  final int r = l.amt.round();
  TVoucher? best;
  for (int k = r - 1; k <= r + 1; k++) {
    final List<TVoucher>? list = idx[k];
    if (list == null) continue;
    for (final TVoucher v in list) {
      if (v.base != base || (v.amount - l.amt).abs() >= 0.5) continue;
      final bool utr = l.ref.length >= 6 && v.utr.length >= 6 && (v.utr.contains(l.ref) || l.ref.contains(v.utr));
      if (utr) return v;
      if (_gap(v.dt, l.date) <= 4) best ??= v;
    }
  }
  return best;
}

Future<void> openBankImport(BuildContext context) {
  return openPanel(context, title: bi('બેંક statement નાખો', 'Add bank statement'), sub: bi('paste કરો - બાકી app કરશે', 'paste it - the app does the rest'), width: 580, child: const _BankImport());
}

Future<void> openBankLine(BuildContext context, String id) {
  return openPanel(context, title: bi('બેંક લાઇન', 'Bank line'), width: 540, child: _BankLineSheet(id));
}

// ------------------------------------------------------------------ import
class _BankImport extends StatefulWidget {
  const _BankImport();

  @override
  State<_BankImport> createState() => _BankImportState();
}

class _BankImportState extends State<_BankImport> {
  late final VoidCallback _accept = () {
    _save();
  };

  final TextEditingController _txt = TextEditingController();
  final TextEditingController _bank = TextEditingController();
  List<BankDraft>? _d;
  int _fresh = 0;
  bool _busy = false;
  String _err = '';

  @override
  void initState() {
    super.initState();
    AcceptHub.push(_accept);
    final List<String> b = bankNames();
    if (b.isNotEmpty) _bank.text = b.last;
  }

  @override
  void dispose() {
    _txt.dispose();
    _bank.dispose();
    AcceptHub.pop(_accept);
    super.dispose();
  }

  Future<void> _paste() async {
    final ClipboardData? c = await Clipboard.getData(Clipboard.kTextPlain);
    final String t = c?.text ?? '';
    if (t.trim().isEmpty) {
      setState(() => _err = bi('ક્લિપબોર્ડમાં કંઈ નથી', 'The clipboard is empty'));
      return;
    }
    _txt.text = t;
    _check();
  }

  void _check() {
    final List<BankDraft> d = parseBankText(_txt.text);
    if (d.isEmpty) {
      setState(() {
        _d = null;
        _err = bi('કોઈ લાઇન વંચાઈ નહીં. Statement ને ઉપરની હેડર લાઇન (Date, Narration, Debit, Credit) સાથે કૉપી કરો.', 'No line could be read. Copy the statement together with its header row (Date, Narration, Debit, Credit).');
      });
      return;
    }
    final int fresh = freshBankDrafts(d, bankLines().map((BankLine l) => l.key)).length;
    setState(() {
      _d = d;
      _fresh = fresh;
      _err = '';
    });
  }

  Future<void> _save() async {
    final List<BankDraft>? d = _d;
    if (d == null) return;
    setState(() => _busy = true);
    final int n = await addBankLines(d, _bank.text.trim());
    app.toast('$n ${bi('નવી લાઇન ઉમેરાઈ', 'new lines added')}');
    if (mounted) Navigator.of(context).pop();
  }

  Widget _preview(List<BankDraft> d) {
    double out = 0;
    double inn = 0;
    DateTime lo = d.first.date;
    DateTime hi = d.first.date;
    for (final BankDraft x in d) {
      if (x.dir == 'dr') {
        out += x.amt;
      } else {
        inn += x.amt;
      }
      if (x.date.isBefore(lo)) lo = x.date;
      if (x.date.isAfter(hi)) hi = x.date;
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Surface(
          shadow: false,
          color: Pal.soft,
          padding: const EdgeInsets.all(12),
          child: Column(
            children: <Widget>[
              InfoRow(bi('વંચાયેલી લાઇન', 'Lines read'), '${d.length}'),
              InfoRow(bi('નવી (પહેલાં નહોતી)', 'New (not saved before)'), '$_fresh', bold: true, color: _fresh > 0 ? Pal.ok : Pal.warn),
              InfoRow(bi('બેંકમાંથી ગયા', 'Money out'), inr(out, dec: 2)),
              InfoRow(bi('બેંકમાં આવ્યા', 'Money in'), inr(inn, dec: 2)),
              InfoRow(bi('તારીખ', 'Dates'), '${dmy(lo)} - ${dmy(hi)}'),
            ],
          ),
        ),
        const SizedBox(height: 8),
        for (final BankDraft x in d.take(6))
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 3),
            child: Row(
              children: <Widget>[
                Text(dm(x.date), style: ts(12, c: Pal.muted)),
                const SizedBox(width: 8),
                Expanded(child: Text(x.desc.isEmpty ? '-' : x.desc, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12.5))),
                const SizedBox(width: 8),
                Text('${x.dir == 'dr' ? '-' : '+'}${inr(x.amt)}', style: ts(12.5, w: FontWeight.w800, c: x.dir == 'dr' ? Pal.bad : Pal.ok, tab: true)),
              ],
            ),
          ),
        if (d.length > 6) Text('... +${d.length - 6}', style: ts(12, c: Pal.muted)),
        const SizedBox(height: 12),
        if (_fresh == 0)
          noteBox('info', 'blue', bi('આ બધી લાઇન પહેલેથી સેવ છે.', 'All these lines are already saved.'))
        else
          _busy ? const Center(child: CircularProgressIndicator()) : Btn('$_fresh ${bi('લાઇન સેવ કરો', 'lines - save')}', icon: 'check', expand: true, onTap: _save),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final List<BankDraft>? d = _d;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Text(
          bi('Net-banking માંથી statement (CSV / Excel) કૉપી કરી અહીં paste કરો. બેંકના SMS પણ paste કરી શકાય. ઉપરની હેડર લાઇન (Date, Narration, Debit, Credit) સાથે કૉપી કરો.',
              'Copy the statement (CSV / Excel) from net-banking and paste it here. Bank SMS also work. Copy it with the header row (Date, Narration, Debit, Credit).'),
          style: ts(12.5, c: Pal.muted),
        ),
        const SizedBox(height: 10),
        SuggestField(label: bi('બેંકનું નામ', 'Bank name'), controller: _bank, options: bankNames()),
        const SizedBox(height: 10),
        FieldX(
          label: 'Statement / SMS',
          controller: _txt,
          maxLines: 8,
          onChanged: (String v) {
            if (_d != null) setState(() => _d = null);
          },
        ),
        const SizedBox(height: 10),
        Row(
          children: <Widget>[
            tExp(child: Btn(bi('Clipboard માંથી', 'From clipboard'), icon: 'copy', kind: BtnKind.tonal, onTap: _paste)),
            const SizedBox(width: 10),
            tExp(child: Btn(bi('વાંચો', 'Read it'), icon: 'search', onTap: _check)),
          ],
        ),
        if (_err.isNotEmpty) ...<Widget>[const SizedBox(height: 10), noteBox('warn', 'amber', _err)],
        if (d != null) ...<Widget>[const SizedBox(height: 14), _preview(d)],
      ],
    );
  }
}

// --------------------------------------------------------------- line sheet
class _BankLineSheet extends StatefulWidget {
  final String id;
  const _BankLineSheet(this.id);

  @override
  State<_BankLineSheet> createState() => _BankLineState();
}

class _BankLineState extends State<_BankLineSheet> {
  final TextEditingController _party = TextEditingController();
  final TextEditingController _note = TextEditingController();
  BankLine? _l;
  BankCtx? _x;
  BankMatch? _m;
  int _mode = 0;
  String _cat = '';
  bool _busy = false;
  String _err = '';

  @override
  void initState() {
    super.initState();
    final List<BankLine> all = bankLines();
    BankLine? f;
    for (final BankLine l in all) {
      if (l.id == widget.id) {
        f = l;
        break;
      }
    }
    _l = f;
    if (f == null || !f.isNew) return;
    final BankCtx x = buildBankCtx(all);
    final Map<String, BankMatch> mm = matchAllBank(all, x);
    final BankMatch m = mm[f.id] ?? BankMatch(f.isDr ? 'pay' : 'recv');
    _x = x;
    _m = m;
    _cat = f.isDr ? 'other' : 'inother';
    if (m.hasParty && m.kind != 'exists') _party.text = m.partyLabel;
    if (m.kind == 'deal') _mode = 1;
    if (m.kind == 'exp') _mode = 2;
  }

  @override
  void dispose() {
    _party.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _do(BankPost p, String msg) async {
    setState(() {
      _busy = true;
      _err = '';
    });
    await bankPostAll(<BankPost>[p]);
    app.toast(msg);
    if (mounted) Navigator.of(context).pop();
  }

  PartyOpt? _resolve(List<PartyOpt> pool, String type) {
    final String t = _party.text.trim();
    if (t.isEmpty) return null;
    final String k = nameKey(t);
    for (final PartyOpt p in pool) {
      if (p.key == k && p.type != 'mill') return p;
    }
    return PartyOpt(k, t, type);
  }

  Future<void> _ignore(BankLine l) async {
    await bankIgnore(l);
    if (mounted) Navigator.of(context).pop();
  }

  Future<void> _restore(BankLine l) async {
    await bankRestore(l);
    if (mounted) Navigator.of(context).pop();
  }

  Future<void> _undo(BankLine l) async {
    final bool go = await confirmBox(
      context,
      title: bi('આ એન્ટ્રી પાછી લેવી?', 'Take this entry back?'),
      text: l.kind == 'exists' ? bi('લાઇન ફરી "ચેક કરવાની" માં જશે. જૂની એન્ટ્રી રહેશે.', 'The line goes back to "to check". The old entry stays.') : bi('જે એન્ટ્રી બની હતી તે કાઢી નંખાશે અને લાઇન ફરી "ચેક કરવાની" માં જશે.', 'The entry that was made is removed and the line goes back to "to check".'),
      yes: bi('હા, પાછી લો', 'Yes, take back'),
      no: bi('ના', 'No'),
    );
    if (!go) return;
    await bankUndo(l);
    app.toast(bi('પાછી લીધી', 'Taken back'));
    if (mounted) Navigator.of(context).pop();
  }

  Future<void> _delete(BankLine l) async {
    final bool go = await confirmBox(context, title: bi('આ લાઇન કાઢી નાખવી?', 'Delete this line?'), text: bi('ફક્ત બેંક લાઇન જશે, તમારા ખાતાની એન્ટ્રી નહીં.', 'Only the bank line goes, not the entries in your books.'), yes: bi('હા, કાઢો', 'Yes, delete'), no: bi('ના', 'No'));
    if (!go) return;
    await removeBankLine(l.id);
    if (mounted) Navigator.of(context).pop();
  }

  Widget _head(BankLine l) {
    final Map<int, List<TVoucher>> idx = _tallyIdx();
    final TVoucher? t = tallyStore.vouchers.isEmpty ? null : _tallyHit(l, idx);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Row(
          children: <Widget>[
            Pill(l.isDr ? bi('બેંકમાંથી ગયા', 'Money out') : bi('બેંકમાં આવ્યા', 'Money in'), tone: l.isDr ? 'rose' : 'green'),
            const Spacer(),
            Text(inr(l.amt, dec: 2), style: ts(22, w: FontWeight.w900, c: l.isDr ? Pal.bad : Pal.ok, tab: true)),
          ],
        ),
        const SizedBox(height: 8),
        InfoRow(bi('તારીખ', 'Date'), dmy(l.date)),
        if (l.bank.isNotEmpty) InfoRow(bi('બેંક', 'Bank'), l.bank),
        if (l.ref.isNotEmpty) InfoRow('UTR / Ref', l.ref),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Text(l.desc.isEmpty ? '-' : l.desc, style: ts(13, c: Pal.muted)),
        ),
        if (tallyStore.vouchers.isNotEmpty)
          noteBox(
            t != null ? 'check' : 'warn',
            t != null ? 'green' : 'amber',
            t != null ? '${bi('Tally માં છે', 'In Tally')}: ${t.title} · ${t.no.isEmpty ? t.type : t.no} · ${dmy(t.dt)}' : bi('Tally માં આ પૈસાનો વાઉચર દેખાતો નથી', 'No Tally voucher found for this money'),
          ),
      ],
    );
  }

  Widget _done(BankLine l) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        _head(l),
        divider(),
        const SizedBox(height: 8),
        InfoRow(bi('સ્થિતિ', 'Status'), l.state == 'ignored' ? bi('છોડી દીધી', 'Ignored') : bi('ખાતામાં નોંધાઈ', 'Posted')),
        if (l.kind.isNotEmpty) InfoRow(bi('શું', 'What'), _kindLabel(l.kind)),
        if (l.party.isNotEmpty) InfoRow(bi('કોને', 'Whom'), l.party),
        const SizedBox(height: 14),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: <Widget>[
            if (l.state == 'ignored') Btn(bi('ફરી ચેક કરવાની', 'Back to check'), icon: 'undo', onTap: () => _restore(l)) else Btn(bi('પાછી લો (Undo)', 'Take back (Undo)'), icon: 'undo', kind: BtnKind.amber, onTap: () => _undo(l)),
            Btn(bi('લાઇન કાઢો', 'Delete line'), icon: 'trash', kind: BtnKind.danger, onTap: () => _delete(l)),
          ],
        ),
      ],
    );
  }

  Widget _manual(BankLine l, BankCtx x, BankMatch m) {
    final List<String> modes = l.isDr
        ? <String>[bi('ખેડૂતને ચૂકવ્યા', 'Paid farmer'), bi('એડવાન્સ', 'Advance'), bi('ખર્ચ', 'Expense')]
        : <String>[bi('ખરીદદાર', 'Buyer'), bi('મિલ ગાડી', 'Mill truck'), bi('બીજી આવક', 'Other income')];
    final List<Widget> body = <Widget>[];
    if (_mode == 2) {
      final List<List<String>> cats = l.isDr ? kExpCats : kInCats;
      final List<String> cur = cats.firstWhere((List<String> c) => c[0] == _cat, orElse: () => cats.last);
      body.add(Align(
        alignment: Alignment.centerLeft,
        child: PickX<List<String>>(label: bi(cur[1], cur[2]), icon: 'tag', items: cats, text: (List<String> c) => bi(c[1], c[2]), onSelected: (List<String> c) => setState(() => _cat = c[0])),
      ));
      body.add(const SizedBox(height: 10));
      body.add(FieldX(label: bi('નોંધ', 'Note'), controller: _note));
      body.add(const SizedBox(height: 12));
      body.add(Btn(bi('ખાતામાં નોંધો', 'Post to books'), icon: 'check', expand: true, onTap: () => _do(BankPost(l, 'exp', cat: _cat, note: _note.text.trim()), '${bi('નોંધાયું', 'Posted')} · ${inr(l.amt)}')));
    } else if (l.isDr) {
      final List<String> opts = <String>[for (final PartyOpt p in x.farmers.take(500)) p.label];
      body.add(SuggestField(label: bi('ખેડૂતનું નામ', 'Farmer'), controller: _party, options: opts, onChanged: (String v) => setState(() {}), onPick: (String v) => setState(() {})));
      body.add(const SizedBox(height: 12));
      body.add(Btn(_mode == 1 ? bi('એડવાન્સ તરીકે નોંધો', 'Post as advance') : bi('ચૂકવણી તરીકે નોંધો', 'Post as payment'), icon: 'check', expand: true, onTap: () {
        final PartyOpt? p = _resolve(x.farmers, 'farmer');
        if (p == null) {
          setState(() => _err = bi('ખેડૂતનું નામ લખો', 'Enter the farmer'));
          return;
        }
        _do(BankPost(l, _mode == 1 ? 'adv' : 'pay', party: p), '${bi('ચૂકવણી નોંધાઈ', 'Payment posted')} · ${p.label}');
      }));
    } else if (_mode == 0) {
      final List<String> opts = <String>[for (final PartyOpt p in x.buyers.take(500)) if (p.type == 'buyer') p.label];
      body.add(SuggestField(label: bi('ખરીદદારનું નામ', 'Buyer'), controller: _party, options: opts, onChanged: (String v) => setState(() {}), onPick: (String v) => setState(() {})));
      body.add(const SizedBox(height: 12));
      body.add(Btn(bi('રકમ મળી તરીકે નોંધો', 'Post as money received'), icon: 'check', expand: true, onTap: () {
        final PartyOpt? p = _resolve(x.buyers, 'buyer');
        if (p == null) {
          setState(() => _err = bi('ખરીદદારનું નામ લખો', 'Enter the buyer'));
          return;
        }
        _do(BankPost(l, 'recv', party: p), '${bi('રકમ નોંધાઈ', 'Received posted')} · ${p.label}');
      }));
    } else {
      final List<String> mills = <String>{for (final MillDeal d in x.deals) d.mill}.toList();
      final List<MillDeal> open = x.openDealsOf(nameKey(_party.text));
      body.add(SuggestField(label: bi('મિલનું નામ', 'Mill'), controller: _party, options: mills, onChanged: (String v) => setState(() {}), onPick: (String v) => setState(() {})));
      body.add(const SizedBox(height: 10));
      if (_party.text.trim().isEmpty) {
        body.add(Text(bi('મિલ પસંદ કરો - તેની બાકી ગાડીઓ દેખાશે', 'Pick a mill - its open trucks are shown'), style: ts(12.5, c: Pal.muted)));
      } else if (open.isEmpty) {
        body.add(noteBox('info', 'blue', bi('આ મિલની પૈસા બાકી હોય એવી કોઈ ગાડી નથી', 'This mill has no truck with money still due')));
      } else {
        for (final MillDeal d in open) {
          final DealCalc c = calcDeal(d, billTotal: d.billed ? x.bills[d.billNo.trim()] : null);
          body.add(lineItem(
            icon: 'truck',
            tone: (c.due - l.amt).abs() < 1 ? 'green' : 'amber',
            title: '${d.vehicle.isEmpty ? '-' : d.vehicle} · ${d.mill}',
            sub: '${dayLabel(d.date)} · ${bi('લેવાના', 'due')} ${inr(c.due, dec: 2)}',
            trailing: bi('આમાં નાખો', 'Use'),
            onTap: () => _do(BankPost(l, 'deal', dealId: d.id, label: d.mill), '${bi('રકમ નોંધાઈ', 'Received posted')} · ${d.vehicle}'),
          ));
        }
      }
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        ChipRow(
          labels: modes,
          index: _mode,
          onChanged: (int i) => setState(() {
            _mode = i;
            _err = '';
          }),
        ),
        const SizedBox(height: 12),
        ...body,
        if (_err.isNotEmpty) ...<Widget>[const SizedBox(height: 8), Text(_err, style: ts(12.5, c: Pal.bad))],
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final BankLine? l = _l;
    if (l == null) return EmptyBox(icon: 'bank', title: bi('આ લાઇન હવે નથી', 'This line is gone'));
    if (!l.isNew) return _done(l);
    final BankCtx? x = _x;
    final BankMatch? m = _m;
    if (x == null || m == null) return const SizedBox.shrink();
    final BankPost? sug = bankSuggestPost(l, m);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        _head(l),
        if (sug != null) ...<Widget>[
          const SizedBox(height: 4),
          noteBox(m.kind == 'exists' ? 'check' : 'bank', m.sure ? 'green' : 'amber', '${_sugText(m)}${m.sure ? '' : '  (${bi('પાક્કું નથી', 'not sure')})'}'),
          _busy
              ? const Center(child: CircularProgressIndicator())
              : Btn(m.kind == 'exists' ? bi('હા, આ જ છે - જોડો', 'Yes, same - link it') : bi('આ મુજબ નોંધો', 'Post like this'), icon: 'check', expand: true, onTap: () => _do(sug, '${bi('નોંધાયું', 'Posted')} · ${inr(l.amt)}')),
          const SizedBox(height: 12),
          caption(bi('અથવા જાતે પસંદ કરો', 'Or choose yourself')),
        ],
        if (_busy && sug == null) const Center(child: CircularProgressIndicator()) else _manual(l, x, m),
        const SizedBox(height: 14),
        divider(),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: <Widget>[
            Btn(bi('છોડી દો', 'Ignore'), icon: 'close', kind: BtnKind.outline, onTap: () => _ignore(l)),
            Btn(bi('લાઇન કાઢો', 'Delete line'), icon: 'trash', kind: BtnKind.danger, onTap: () => _delete(l)),
          ],
        ),
      ],
    );
  }
}

// ------------------------------------------------------------------ screen
class BankScreen extends StatefulWidget {
  const BankScreen({super.key});

  @override
  State<BankScreen> createState() => _BankState();
}

class _BankState extends State<BankScreen> {
  int _f = 0; // 0 to check, 1 sure, 2 posted, 3 ignored, 4 all
  String _q = '';
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    tallyStore.addListener(_tick);
    if (tallyStore.vouchers.isEmpty && !tallyStore.loading) {
      tallyStore.load();
    }
  }

  @override
  void dispose() {
    tallyStore.removeListener(_tick);
    super.dispose();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  List<PcCol> _cols() => <PcCol>[
        PcCol(bi('તારીખ', 'Date'), 96),
        PcCol(bi('બેંક વિગત', 'Narration'), 0),
        PcCol(bi('ગયા', 'Out'), 110, right: true),
        PcCol(bi('આવ્યા', 'In'), 110, right: true),
        PcCol(bi('મેળવણી', 'Match'), 230),
        PcCol(bi('સ્થિતિ', 'Status'), 130),
        PcCol('Tally', 56),
      ];

  Future<void> _autoPost(List<BankPost> posts) async {
    double pay = 0;
    double recv = 0;
    int ex = 0;
    int exp = 0;
    for (final BankPost p in posts) {
      if (p.kind == 'pay' || p.kind == 'adv') pay += p.line.amt;
      if (p.kind == 'recv' || p.kind == 'deal') recv += p.line.amt;
      if (p.kind == 'exists') ex++;
      if (p.kind == 'exp') exp++;
    }
    final String text = '${posts.length} ${bi('લાઇન ખાતામાં નોંધાશે', 'lines will be posted')}:\n'
        '${pay > 0 ? '• ${bi('ખેડૂતોને ચૂકવ્યા', 'Paid to farmers')}: ${inr(pay)}\n' : ''}'
        '${recv > 0 ? '• ${bi('ખરીદદાર / મિલ પાસેથી મળ્યા', 'Received from buyers / mills')}: ${inr(recv)}\n' : ''}'
        '${ex > 0 ? '• $ex ${bi('પહેલેથી નોંધેલ સાથે જોડાશે', 'linked to entries already made')}\n' : ''}'
        '${exp > 0 ? '• $exp ${bi('બેંક ચાર્જ ખર્ચમાં', 'bank charges to expenses')}\n' : ''}'
        '${bi('દરેક લાઇન પછીથી Undo થઈ શકે છે.', 'Each line can be taken back later.')}';
    final bool go = await confirmBox(context, title: bi('પાક્કી મેળવણી નોંધવી?', 'Post the sure matches?'), text: text, yes: bi('હા, નોંધો', 'Yes, post'), no: bi('ના', 'No'));
    if (!go) return;
    setState(() => _busy = true);
    await bankPostAll(posts);
    app.toast('${posts.length} ${bi('લાઇન નોંધાઈ', 'lines posted')}');
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[bankDoc, payDoc, saleDoc, expDoc, tradeDoc, gstDoc, prefDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 1100,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final List<BankLine> all = bankLines();
          final BankCtx x = buildBankCtx(all);
          final Map<String, BankMatch> mm = matchAllBank(all, x);
          final Map<int, List<TVoucher>> tIdx = tallyStore.vouchers.isEmpty ? <int, List<TVoucher>>{} : _tallyIdx();
          final bool tallyOn = tallyStore.vouchers.isNotEmpty;
          final List<BankLine> toCheck = all.where((BankLine l) => l.isNew).toList();
          final List<BankPost> sure = <BankPost>[];
          for (final BankLine l in toCheck) {
            final BankMatch? m = mm[l.id];
            final BankPost? p = m == null ? null : bankAutoPost(l, m);
            if (p != null) sure.add(p);
          }
          final Set<String> sureIds = <String>{for (final BankPost p in sure) p.line.id};
          double out = 0;
          double inn = 0;
          for (final BankLine l in toCheck) {
            if (l.isDr) {
              out += l.amt;
            } else {
              inn += l.amt;
            }
          }
          final int done = all.where((BankLine l) => l.state == 'done').length;
          int notTally = 0;
          if (tallyOn) {
            for (final BankLine l in all) {
              if (l.state == 'ignored') continue;
              if (_tallyHit(l, tIdx) == null) notTally++;
            }
          }
          final String q = _q.trim().toLowerCase();
          final List<BankLine> shown = all.where((BankLine l) {
            if (_f == 0 && !l.isNew) return false;
            if (_f == 1 && !sureIds.contains(l.id)) return false;
            if (_f == 2 && l.state != 'done') return false;
            if (_f == 3 && l.state != 'ignored') return false;
            if (q.isNotEmpty) {
              final String hay = '${l.desc} ${l.party} ${l.ref} ${plainNum(l.amt)}'.toLowerCase();
              if (!hay.contains(q)) return false;
            }
            return true;
          }).toList();
          final List<PcCol> cols = _cols();
          final bool pc = app.stagePc;
          return <Widget>[
            ScreenHeader(bi('બેંક / UPI મેળવણી', 'Bank / UPI match'), sub: '${all.length} ${bi('લાઇન', 'lines')}', actions: <Widget>[
              IconBtn('plus', tip: bi('statement નાખો', 'Add statement'), onTap: () => openBankImport(ctx)),
            ]),
            statusBanner(),
            HeroCard(
              title: bi('ચેક કરવાની બેંક લાઇન', 'Bank lines to check'),
              value: '${toCheck.length}',
              unit: bi('લાઇન', 'lines'),
              sub: sure.isEmpty ? bi('પાક્કી મેળવણી કોઈ નથી', 'No sure matches yet') : '${sure.length} ${bi('પાક્કી મેળવણી તૈયાર', 'sure matches ready')}',
              chips: <HeroChip>[
                HeroChip('arrowup', '${bi('ગયા', 'Out')} ${inrC(out)}'),
                HeroChip('arrowdown', '${bi('આવ્યા', 'In')} ${inrC(inn)}'),
              ],
            ),
            const SizedBox(height: 12),
            metricGrid(ctx, <Widget>[
              MetricTile(label: bi('પાક્કી મેળવણી', 'Sure matches'), value: '${sure.length}', icon: 'check', tone: 'green', onTap: () => setState(() => _f = 1)),
              MetricTile(label: bi('જાતે જોવાની', 'Need a look'), value: '${toCheck.length - sure.length}', icon: 'eye', tone: 'amber', onTap: () => setState(() => _f = 0)),
              MetricTile(label: bi('નોંધાઈ ગઈ', 'Posted'), value: '$done', icon: 'ledger', tone: 'blue', onTap: () => setState(() => _f = 2)),
              if (tallyOn) MetricTile(label: bi('Tally માં નથી', 'Not in Tally'), value: '$notTally', icon: 'warn', tone: notTally > 0 ? 'rose' : 'green') else MetricTile(label: 'Tally', value: '—', icon: 'db', tone: 'slate', sub: bi('ડેટા નથી', 'no data')),
            ]),
            const SizedBox(height: 12),
            Btn(bi('Statement / SMS નાખો', 'Add statement / SMS'), icon: 'plus', expand: true, onTap: () => openBankImport(ctx)),
            if (sure.isNotEmpty) ...<Widget>[
              const SizedBox(height: 8),
              _busy ? const Center(child: CircularProgressIndicator()) : Btn('${sure.length} ${bi('પાક્કી મેળવણી એકસાથે નોંધો', 'sure matches - post together')}', icon: 'bolt', kind: BtnKind.amber, expand: true, onTap: () => _autoPost(sure)),
            ],
            const SizedBox(height: 12),
            ChipRow(labels: <String>[bi('ચેક કરવાની', 'To check'), bi('પાક્કી', 'Sure'), bi('નોંધાઈ', 'Posted'), bi('છોડેલી', 'Ignored'), bi('બધી', 'All')], index: _f, onChanged: (int i) => setState(() => _f = i)),
            const SizedBox(height: 10),
            SearchBox(hint: bi('નામ / રકમ / UTR શોધો', 'Search name / amount / UTR'), onChanged: (String v) => setState(() => _q = v)),
            const SizedBox(height: 10),
            if (all.isEmpty)
              EmptyBox(icon: 'bank', title: bi('હજી કોઈ statement નથી', 'No statement yet'), sub: bi('ઉપર "Statement / SMS નાખો" દબાવી paste કરો', 'Tap "Add statement / SMS" above and paste'))
            else if (shown.isEmpty)
              EmptyBox(icon: 'check', title: _f == 0 ? bi('બધું ચેક થઈ ગયું', 'All checked') : bi('આમાં કંઈ નથી', 'Nothing here')),
            if (pc && shown.isNotEmpty) ...<Widget>[
              pcHead(cols),
              for (final BankLine l in shown.take(400)) _tableRow(ctx, l, cols, mm, tallyOn, tIdx),
            ] else
              for (final BankLine l in shown.take(250)) _tile(ctx, l, mm, tallyOn, tIdx),
          ];
        },
      ),
    );
  }

  String _matchText(BankLine l, Map<String, BankMatch> mm) {
    if (l.isNew) {
      final BankMatch? m = mm[l.id];
      return m == null ? '' : _sugText(m);
    }
    if (l.state == 'ignored') return '';
    return l.party.isEmpty ? _kindLabel(l.kind) : '${_kindLabel(l.kind)} · ${l.party}';
  }

  String _statusText(BankLine l, Map<String, BankMatch> mm) {
    if (l.state == 'done') return bi('નોંધાઈ', 'Posted');
    if (l.state == 'ignored') return bi('છોડેલી', 'Ignored');
    final BankMatch? m = mm[l.id];
    if (m != null && m.sure && bankAutoPost(l, m) != null) return bi('પાક્કી ✓', 'Sure ✓');
    return bi('જોવાની', 'Check');
  }

  Widget _tableRow(BuildContext ctx, BankLine l, List<PcCol> cols, Map<String, BankMatch> mm, bool tallyOn, Map<int, List<TVoucher>> tIdx) {
    final bool hit = tallyOn && _tallyHit(l, tIdx) != null;
    final Color bar = l.state == 'done' ? Pal.ok : (l.state == 'ignored' ? Pal.faint : Pal.warn);
    return pcRow(
      cols,
      <Widget>[
        pcTd(dmy(l.date)),
        pcTd(l.desc.isEmpty ? '-' : l.desc),
        pcTd(l.isDr ? grp(l.amt, dec: 2) : '', num: true, c: Pal.bad),
        pcTd(l.isDr ? '' : grp(l.amt, dec: 2), num: true, c: Pal.ok),
        pcTd(_matchText(l, mm), bold: true),
        pcTd(_statusText(l, mm)),
        pcTd(!tallyOn || l.state == 'ignored' ? '-' : (hit ? '✓' : '✗'), c: !tallyOn ? null : (hit ? Pal.ok : Pal.bad), bold: true),
      ],
      bar: bar,
      onTap: () => openBankLine(ctx, l.id),
    );
  }

  Widget _tile(BuildContext ctx, BankLine l, Map<String, BankMatch> mm, bool tallyOn, Map<int, List<TVoucher>> tIdx) {
    final String mt = _matchText(l, mm);
    final bool hit = tallyOn && _tallyHit(l, tIdx) != null;
    return lineItem(
      icon: l.isDr ? 'arrowup' : 'arrowdown',
      tone: l.state == 'done' ? 'green' : (l.state == 'ignored' ? 'slate' : (l.isDr ? 'rose' : 'teal')),
      title: l.desc.isEmpty ? '-' : l.desc,
      sub: '${dayLabel(l.date)}${l.bank.isEmpty ? '' : ' · ${l.bank}'}${mt.isEmpty ? '' : ' · $mt'}${tallyOn && l.state != 'ignored' ? ' · Tally ${hit ? '✓' : '✗'}' : ''}',
      trailing: '${l.isDr ? '-' : '+'}${inr(l.amt)}',
      trailingSub: _statusText(l, mm),
      trailingColor: l.isDr ? Pal.bad : Pal.ok,
      onTap: () => openBankLine(ctx, l.id),
    );
  }
}
