import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/errlog.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/books.dart';
import '../../data/contra.dart' show contraBankName, contraCashName;
import '../../data/insights.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../data/money.dart';
import '../../data/owner_docs.dart';
import '../../data/statements.dart';
import '../../data/trade.dart' show saleDoc;
import '../../data/vouchers.dart';
import '../../widgets/accept.dart';
import '../../widgets/common.dart';
import '../../widgets/page.dart';
import 'field.dart';
import 'kit.dart';
import 'kit2.dart';
import 'money_screens.dart';
import 'ui.dart';
import 'contra_screens.dart' show openContraForm;
import 'voucher_screens.dart';
import 'tally_data.dart' show TallyRows, TallyWhat, tallyRows, tallyStrip;

// ======================================================================
// Profit & Loss A/c, Balance Sheet, Group Summary, Bank Book and Outstandings - laid out like TallyPrime
//   Profit & Loss A/c and Balance Sheet are two-sided (Particulars | Amount  and  Particulars | Amount),
//   Group Summary is Opening Balance | Debit | Credit | Closing Balance, Bank Book is the Cash Book layout.
// ======================================================================

String _pText(Period p) => '${tDateFull(p.from)} ${bi('થી', 'to')} ${tDateFull(p.lastDay)}';

/// Financial year so far (1 April to today), like the first screen of TallyPrime.
RangeSel _fySel() {
  final DateTime t = dateOnly(DateTime.now());
  final RangeSel s = RangeSel(6);
  s.cFrom = finYearStart(t);
  s.cTo = t;
  return s;
}

String _dc(double v) => v.abs() < 0.005 ? '' : tDr(v);

// ----------------------------------------------------------------- two sided tables
class _TRow {
  final String label;
  final String amt;
  final bool bold;
  final bool sub; // indented (a ledger inside a group)
  final VoidCallback? onTap;
  const _TRow(this.label, this.amt, {this.bold = false, this.sub = false, this.onTap});
}

class _Sec {
  final List<_TRow> l;
  final List<_TRow> r;
  final double total;
  const _Sec(this.l, this.r, this.total);
}

// label | amount | rule | label | amount (the thin rule in the middle is what makes it a Tally "T" account)
List<PcCol> _tcols(String left, String right, String amt) => <PcCol>[
      PcCol(left, 0),
      PcCol(amt, 130, right: true),
      const PcCol('', 16),
      PcCol(right, 0),
      PcCol(amt, 130, right: true),
    ];

Widget _tRule() => SizedBox.expand(child: DecoratedBox(decoration: BoxDecoration(border: Border(right: BorderSide(color: Pal.tally ? Pal.ink.withAlpha(150) : Pal.line)))));

Widget _tLabel(_TRow? x) {
  if (x == null) return const SizedBox.shrink();
  final Widget t = Padding(
    padding: EdgeInsets.only(left: x.sub ? 22 : 0),
    child: pcTd(x.label, bold: x.bold),
  );
  if (x.onTap == null) return t;
  return InkWell(onTap: x.onTap, child: Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: t));
}

Widget _tAmt(_TRow? x) {
  if (x == null) return const SizedBox.shrink();
  return pcTd(x.amt, num: true, bold: x.bold);
}

List<Widget> _tablePc(List<PcCol> cols, List<_Sec> secs) {
  final List<Widget> out = <Widget>[pcHead(cols)];
  for (final _Sec s in secs) {
    final int n = s.l.length > s.r.length ? s.l.length : s.r.length;
    for (int i = 0; i < n; i++) {
      final _TRow? a = i < s.l.length ? s.l[i] : null;
      final _TRow? b = i < s.r.length ? s.r[i] : null;
      out.add(pcRow(cols, <Widget>[_tLabel(a), _tAmt(a), _tRule(), _tLabel(b), _tAmt(b)]));
    }
    out.add(pcTotal(cols, '', vals: <int, String>{1: tAmt(s.total), 4: tAmt(s.total)}));
  }
  return out;
}

List<Widget> _tablePhone(List<_Sec> secs, String leftTitle, String rightTitle) {
  Widget side(String title, List<_TRow> rows, double total) {
    return Surface(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text(title, style: ts(12.5, w: FontWeight.w800, c: Pal.muted, ls: 0.3)),
          const SizedBox(height: 4),
          for (final _TRow x in rows)
            InkWell(
              onTap: x.onTap,
              child: Padding(
                padding: EdgeInsets.only(left: x.sub ? 16 : 0),
                child: InfoRow(x.label, x.amt, bold: x.bold),
              ),
            ),
          const Divider(height: 14),
          InfoRow(bi('કુલ', 'Total'), tAmt(total), bold: true, color: Pal.brand),
        ],
      ),
    );
  }

  final List<Widget> out = <Widget>[];
  for (final _Sec s in secs) {
    out.add(side(leftTitle, s.l, s.total));
    out.add(const SizedBox(height: 8));
    out.add(side(rightTitle, s.r, s.total));
    out.add(const SizedBox(height: 12));
  }
  return out;
}

/// Rows for print / Excel: four columns, a bold total line after every section.
List<List<String>> _flat(List<_Sec> secs, Set<int> bold) {
  final List<List<String>> rows = <List<String>>[];
  for (final _Sec s in secs) {
    final int n = s.l.length > s.r.length ? s.l.length : s.r.length;
    for (int i = 0; i < n; i++) {
      final _TRow? a = i < s.l.length ? s.l[i] : null;
      final _TRow? b = i < s.r.length ? s.r[i] : null;
      if ((a?.bold ?? false) || (b?.bold ?? false)) bold.add(rows.length);
      rows.add(<String>[
        a == null ? '' : '${a.sub ? '     ' : ''}${a.label}',
        a?.amt ?? '',
        b == null ? '' : '${b.sub ? '     ' : ''}${b.label}',
        b?.amt ?? '',
      ]);
    }
    bold.add(rows.length);
    rows.add(<String>['', tAmt(s.total), '', tAmt(s.total)]);
  }
  return rows;
}

Future<void> _printSecs(String title, String period, List<String> heads, List<_Sec> secs) async {
  final Set<int> bold = <int>{};
  final List<List<String>> rows = _flat(secs, bold);
  await printOut(
    reportHtml(title: title, period: period, heads: heads, right: const <bool>[false, true, false, true], rows: rows, bold: bold),
    title.replaceAll(' ', '-').replaceAll('&', 'and').toLowerCase(),
  );
}

Future<void> _exportSecs(String title, List<String> heads, List<_Sec> secs) async {
  final StringBuffer b = StringBuffer();
  b.writeln(heads.map(csvCell).join(','));
  for (final List<String> row in _flat(secs, <int>{})) {
    b.writeln(row.map(csvCell).join(','));
  }
  await exportCsvOut(b.toString(), '${title.replaceAll(' ', '-').replaceAll('&', 'and').toLowerCase()}-${dayKey(DateTime.now())}');
}

// ----------------------------------------------------------------- stock value
Future<void> openStockValueForm(BuildContext context, DateTime fyStart) {
  return openPanel(
    context,
    title: bi('સ્ટોકની કિંમત', 'Stock Value'),
    sub: '${bi('નાણાકીય વર્ષ', 'Financial year')} ${finYearLabel(fyStart)}',
    width: 440,
    child: _StockValForm(fyStart),
  );
}

class _StockValForm extends StatefulWidget {
  final DateTime fy;
  const _StockValForm(this.fy);

  @override
  State<_StockValForm> createState() => _StockValFormState();
}

class _StockValFormState extends State<_StockValForm> {
  late final TextEditingController _o = TextEditingController(text: stockValueOpen(widget.fy) == 0 ? '' : plainNum(stockValueOpen(widget.fy)));
  late final TextEditingController _c = TextEditingController(text: stockValueClose(widget.fy) == 0 ? '' : plainNum(stockValueClose(widget.fy)));
  bool _busy = false;

  @override
  void dispose() {
    _o.dispose();
    _c.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_busy) return;
    setState(() => _busy = true);
    final bool ok = await ErrLog.attempt('Stock value', () => setStockValues(widget.fy, dbl(_o.text.replaceAll(',', '')), dbl(_c.text.replaceAll(',', ''))));
    if (!mounted) return;
    if (ok) {
      Navigator.of(context).pop();
    } else {
      setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Text(
          bi('સ્ટોક KG માં ગણાય છે, એટલે નફો-નુકસાન અને બેલેન્સ શીટ માટે સ્ટોકની કિંમત (₹) અહીં નાખો.', 'Stock is counted in KG, so type the VALUE (Rs) of the stock here for the Profit & Loss A/c and the Balance Sheet.'),
          style: ts(13.5, h: 1.4),
        ),
        const SizedBox(height: 12),
        FieldX(label: bi('શરૂઆતના સ્ટોકની કિંમત (1 એપ્રિલ)', 'Opening stock value (1 April)'), controller: _o, big: true, prefix: '₹', keyboard: const TextInputType.numberWithOptions(decimal: true)),
        const SizedBox(height: 12),
        FieldX(label: bi('આખરી સ્ટોકની કિંમત (આજે / વર્ષ અંતે)', 'Closing stock value (today / year end)'), controller: _c, big: true, prefix: '₹', keyboard: const TextInputType.numberWithOptions(decimal: true)),
        const SizedBox(height: 8),
        Btn(
          bi('સ્ટોક × છેલ્લા ભાવથી ભરો', 'Fill from stock × latest rates'),
          icon: 'calc',
          kind: BtnKind.outline,
          dense: true,
          onTap: () {
            final double v = suggestedStockValue(dateOnly(DateTime.now()));
            if (v <= 0) {
              app.toast(bi('સ્ટોક કે ભાવ મળ્યો નથી - હાથે નાખો', 'No stock or rate found - type it'));
              return;
            }
            setState(() => _c.text = plainNum(v.roundToDouble()));
          },
        ),
        const SizedBox(height: 16),
        Btn(bi('સેવ કરો', 'Save'), icon: 'check', expand: true, onTap: _busy ? null : _save),
      ],
    );
  }
}

// ======================================================================
// Profit & Loss A/c
// ======================================================================

class ProfitLossScreen extends StatefulWidget {
  const ProfitLossScreen({super.key});

  @override
  State<ProfitLossScreen> createState() => _PlState();
}

class _PlState extends State<ProfitLossScreen> {
  late final VoidCallback _prn = () {
    _print();
  };
  late final VoidCallback _exp = () {
    _export();
  };

  RangeSel _sel = _fySel();

  @override
  void initState() {
    super.initState();
    printHub.push(_prn);
    exportHub.push(_exp);
  }

  @override
  void dispose() {
    printHub.pop(_prn);
    exportHub.pop(_exp);
    super.dispose();
  }

  List<String> get _heads => <String>['Particulars', 'Amount', 'Particulars', 'Amount'];

  List<_Sec> _secs(PlReport r) {
    final double g = r.gross;
    void toBook(String type) => app.go('my_daybook', arg: DayBookArg(type: type, sel: _sel));
    void stock() => openStockValueForm(context, r.fyStart);
    final List<_TRow> l1 = <_TRow>[
      _TRow(bi('શરૂઆતનો સ્ટોક', 'Opening Stock'), tAmt(r.openStock), onTap: stock),
      _TRow(bi('ખરીદ ખાતું', 'Purchase Accounts'), tAmt(r.purchase), bold: true, onTap: () => toBook('PUR')),
      if (g > 0.004) _TRow(bi('ગ્રોસ નફો c/o', 'Gross Profit c/o'), tAmt(g), bold: true),
    ];
    final List<_TRow> r1 = <_TRow>[
      _TRow(bi('વેચાણ ખાતું', 'Sales Accounts'), tAmt(r.sales), bold: true, onTap: () => toBook('SAL')),
      _TRow(bi('આખરી સ્ટોક', 'Closing Stock'), tAmt(r.closeStock), onTap: stock),
      if (g < -0.004) _TRow(bi('ગ્રોસ નુકસાન c/o', 'Gross Loss c/o'), tAmt(g), bold: true),
    ];
    final double t1 = r.tradingDr > r.tradingCr ? r.tradingDr : r.tradingCr;

    final double net = r.net;
    final List<_TRow> l2 = <_TRow>[
      if (g < -0.004) _TRow(bi('ગ્રોસ નુકસાન b/f', 'Gross Loss b/f'), tAmt(g), bold: true),
      if (r.expenses.isNotEmpty) _TRow(bi('ખર્ચ (Indirect Expenses)', 'Indirect Expenses'), tAmt(r.expTotal), bold: true),
      for (final PlLine e in r.expenses) _TRow(e.name, tAmt(e.amt), sub: true, onTap: () => app.go('my_ledger', arg: e.ref)),
      if (net > 0.004) _TRow(bi('ચોખ્ખો નફો', 'Net Profit'), tAmt(net), bold: true),
    ];
    final List<_TRow> r2 = <_TRow>[
      if (g > 0.004) _TRow(bi('ગ્રોસ નફો b/f', 'Gross Profit b/f'), tAmt(g), bold: true),
      if (r.incomes.isNotEmpty) _TRow(bi('આવક (Indirect Incomes)', 'Indirect Incomes'), tAmt(r.incTotal), bold: true),
      for (final PlLine e in r.incomes) _TRow(e.name, tAmt(e.amt), sub: true, onTap: () => app.go('my_ledger', arg: e.ref)),
      if (net < -0.004) _TRow(bi('ચોખ્ખું નુકસાન', 'Net Loss'), tAmt(net), bold: true),
    ];
    final double ls = (g < -0.004 ? -g : 0) + r.expTotal + (net > 0.004 ? net : 0);
    final double rs = (g > 0.004 ? g : 0) + r.incTotal + (net < -0.004 ? -net : 0);
    final double t2 = ls > rs ? ls : rs;
    return <_Sec>[_Sec(l1, r1, t1), _Sec(l2, r2, t2)];
  }

  Future<void> _print() async {
    final PlReport r = plReport(_sel.period);
    await _printSecs('Profit & Loss A/c', _pText(_sel.period), _heads, _secs(r));
  }

  Future<void> _export() async {
    final PlReport r = plReport(_sel.period);
    await _exportSecs('Profit & Loss A/c', _heads, _secs(r));
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[payDoc, saleDoc, expDoc, prefDoc, rateDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 1100,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final Period p = _sel.period;
          final PlReport r = plReport(p);
          final List<_Sec> secs = _secs(r);
          final bool pc = app.stagePc;
          final double net = r.net;
          final List<Widget> body = pc
              ? _tablePc(_tcols(bi('વિગત (Particulars)', 'Particulars'), bi('વિગત (Particulars)', 'Particulars'), bi('રકમ (Amount)', 'Amount')), secs)
              : _tablePhone(secs, bi('ઉધાર બાજુ (Debit)', 'Debit side'), bi('જમા બાજુ (Credit)', 'Credit side'));
          return <Widget>[
            ScreenHeader('Profit & Loss A/c', sub: _pText(p), actions: <Widget>[
              Btn(bi('સ્ટોકની કિંમત', 'Stock Value'), icon: 'box', kind: BtnKind.outline, dense: true, onTap: () => openStockValueForm(context, r.fyStart)),
              IconBtn('print', tip: bi('પ્રિન્ટ (Ctrl+P)', 'Print (Ctrl+P)'), onTap: _print),
              IconBtn('table', tip: bi('Excel (Alt+E)', 'Export to Excel (Alt+E)'), onTap: _export),
            ]),
            statusBanner(),
            RangeBar(sel: _sel, presets: const <int>[3, 4, 5, 6], onChanged: (RangeSel s) => setState(() => _sel = s)),
            tallyStrip(TallyWhat.all, from: _sel.period.from, to: _sel.period.lastDay),
            const SizedBox(height: 10),
            if (!Pal.tally) Surface(
              padding: const EdgeInsets.all(12),
              color: Pal.tone(net >= 0 ? 'green' : 'rose').bg,
              shadow: false,
              child: Row(
                children: <Widget>[
                  Expanded(child: Text(net >= 0 ? bi('ચોખ્ખો નફો', 'Net Profit') : bi('ચોખ્ખું નુકસાન', 'Net Loss'), style: ts(14, w: FontWeight.w800))),
                  Text(inr(net.abs(), dec: 2), style: ts(16, w: FontWeight.w800, tab: true, c: net >= 0 ? Pal.ok : Pal.bad)),
                ],
              ),
            ),
            const SizedBox(height: 10),
            if (!r.stockUsed) noteBox('info', 'blue', bi('સ્ટોકની કિંમત ત્યારે જ ગણાય જ્યારે પીરિયડ 1 એપ્રિલથી શરૂ થાય.', 'Stock values are counted only when the period starts on 1 April.')),
            if (r.stockUsed && r.openStock == 0 && r.closeStock == 0) noteBox('warn', 'amber', bi('સ્ટોકની કિંમત નાખી નથી - નફો સ્ટોક વગર દેખાય છે. ઉપર "સ્ટોકની કિંમત" દબાવો.', 'Stock value is not entered - the profit is shown without stock. Press "Stock Value" above.'), onTap: () => openStockValueForm(context, r.fyStart)),
            if (r.purchase == 0 && r.sales == 0 && r.expenses.isEmpty && r.incomes.isEmpty)
              EmptyBox(icon: 'balance', title: bi('આ સમયમાં કોઈ હિસાબ નથી', 'Nothing to show for this period'))
            else
              ...body,
            const SizedBox(height: 6),
            caption(bi('ખરીદ = ચિઠ્ઠીની રકમ, વેચાણ = વેચાણ વાઉચર. લીટી પર Enter: અંદરના વાઉચર.', 'Purchases = chit amounts, sales = sales vouchers. Press Enter on a line to open its vouchers.')),
          ];
        },
      ),
    );
  }
}

// ======================================================================
// Balance Sheet
// ======================================================================

class BalanceSheetScreen extends StatefulWidget {
  const BalanceSheetScreen({super.key});

  @override
  State<BalanceSheetScreen> createState() => _BsState();
}

class _BsState extends State<BalanceSheetScreen> {
  late final VoidCallback _prn = () {
    _print();
  };
  late final VoidCallback _exp = () {
    _export();
  };

  RangeSel _sel = _fySel();
  final Set<String> _open = <String>{};

  @override
  void initState() {
    super.initState();
    printHub.push(_prn);
    exportHub.push(_exp);
  }

  @override
  void dispose() {
    printHub.pop(_prn);
    exportHub.pop(_exp);
    super.dispose();
  }

  List<String> _heads(BsReport b) => <String>['Liabilities', 'as at ${tDateFull(b.asOn)}', 'Assets', 'as at ${tDateFull(b.asOn)}'];

  String _kid(TbLine k, bool liabSide) {
    if (liabSide) return k.cr > 0 ? tAmt(k.cr) : '${tAmt(k.dr)} Dr';
    return k.dr > 0 ? tAmt(k.dr) : '${tAmt(k.cr)} Cr';
  }

  void _tap(BsLine l) {
    if (l.kids.isNotEmpty && l.go.isEmpty) {
      setState(() {
        if (!_open.remove(l.name)) _open.add(l.name);
      });
    } else if (l.go.isNotEmpty) {
      app.go(l.go);
    }
  }

  List<_TRow> _side(List<BsLine> src, bool liabSide) {
    final List<_TRow> out = <_TRow>[];
    for (final BsLine l in src) {
      out.add(_TRow(l.name, tAmt(l.amt), bold: true, onTap: () => _tap(l)));
      final bool show = l.go == 'profit_loss' || _open.contains(l.name);
      if (!show) continue;
      for (final TbLine k in l.kids) {
        final LedgerRef? ref = k.ref;
        out.add(_TRow(k.name, _kid(k, liabSide), sub: true, onTap: ref != null ? () => app.go('my_ledger', arg: ref) : (k.go.isNotEmpty ? () => app.go(k.go) : null)));
      }
    }
    return out;
  }

  List<_Sec> _secs(BsReport b) {
    final List<_TRow> l = _side(b.liabilities, true);
    final List<_TRow> a = _side(b.assets, false);
    if (b.diff > 0) {
      a.add(_TRow(bi('શરૂઆતના બાકીનો તફાવત', 'Difference in opening balances'), tAmt(b.diff), bold: true));
    } else if (b.diff < 0) {
      l.add(_TRow(bi('શરૂઆતના બાકીનો તફાવત', 'Difference in opening balances'), tAmt(b.diff), bold: true));
    }
    return <_Sec>[_Sec(l, a, b.total)];
  }

  Future<void> _print() async {
    final BsReport b = balanceSheet(_sel.period);
    await _printSecs('Balance Sheet', '${bi('તારીખ', 'As at')} ${tDateFull(b.asOn)}', _heads(b), _secs(b));
  }

  Future<void> _export() async {
    final BsReport b = balanceSheet(_sel.period);
    await _exportSecs('Balance Sheet', _heads(b), _secs(b));
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[payDoc, saleDoc, expDoc, prefDoc, rateDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 1100,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final Period p = _sel.period;
          final BsReport b = balanceSheet(p);
          final List<_Sec> secs = _secs(b);
          final bool pc = app.stagePc;
          final bool empty = b.liabilities.isEmpty && b.assets.isEmpty;
          final String asOn = 'as at ${tDateFull(b.asOn)}';
          final List<Widget> body = pc
              ? _tablePc(_tcols(bi('જવાબદારી (Liabilities)', 'Liabilities'), bi('મિલકત (Assets)', 'Assets'), asOn), secs)
              : _tablePhone(secs, bi('જવાબદારી (Liabilities)', 'Liabilities'), bi('મિલકત (Assets)', 'Assets'));
          return <Widget>[
            ScreenHeader('Balance Sheet', sub: '${bi('તારીખ', 'As at')} ${tDateFull(b.asOn)}', actions: <Widget>[
              Btn(bi('સ્ટોકની કિંમત', 'Stock Value'), icon: 'box', kind: BtnKind.outline, dense: true, onTap: () => openStockValueForm(context, b.fyStart)),
              IconBtn('print', tip: bi('પ્રિન્ટ (Ctrl+P)', 'Print (Ctrl+P)'), onTap: _print),
              IconBtn('table', tip: bi('Excel (Alt+E)', 'Export to Excel (Alt+E)'), onTap: _export),
            ]),
            statusBanner(),
            RangeBar(sel: _sel, presets: const <int>[3, 4, 5, 6], onChanged: (RangeSel s) => setState(() => _sel = s)),
            tallyStrip(TallyWhat.all, from: _sel.period.from, to: _sel.period.lastDay),
            const SizedBox(height: 10),
            if (b.stockMissing && !empty) noteBox('warn', 'amber', bi('સ્ટોકની કિંમત નાખી નથી - બેલેન્સ શીટમાં આખરી સ્ટોક દેખાતો નથી. ઉપર "સ્ટોકની કિંમત" દબાવો.', 'Stock value is not entered - closing stock is not on the Balance Sheet. Press "Stock Value" above.'), onTap: () => openStockValueForm(context, b.fyStart)),
            if (b.diff.abs() >= 0.5) noteBox('warn', 'amber', bi('શરૂઆતના બાકીમાં તફાવત છે - જૂના બાકી (જર્નલ) અને શરૂઆતની રોકડ તપાસો.', 'There is a difference in opening balances - check the opening balances (journal) and the opening cash.')),
            if (empty) EmptyBox(icon: 'balance', title: bi('હજી કોઈ હિસાબ નથી', 'Nothing to show yet')) else ...body,
            const SizedBox(height: 6),
            caption(bi('સુંદરી લેણદાર / દેવાદાર પર Enter: અંદરના ખાતા. નફો-નુકસાન ખાતા પર Enter: Profit & Loss A/c.', 'Press Enter on Sundry Creditors / Debtors to see the ledgers inside. Enter on Profit & Loss A/c opens it.')),
          ];
        },
      ),
    );
  }
}

// ======================================================================
// Group Summary
// ======================================================================

class GroupSummaryScreen extends StatefulWidget {
  const GroupSummaryScreen({super.key});

  @override
  State<GroupSummaryScreen> createState() => _GroupState();
}

class _GroupState extends State<GroupSummaryScreen> {
  late final VoidCallback _prn = () {
    _print();
  };
  late final VoidCallback _exp = () {
    _export();
  };

  RangeSel _sel = _fySel();

  @override
  void initState() {
    super.initState();
    printHub.push(_prn);
    exportHub.push(_exp);
  }

  @override
  void dispose() {
    printHub.pop(_prn);
    exportHub.pop(_exp);
    super.dispose();
  }

  List<List<String>> _rows(List<GroupLine> l) {
    return <List<String>>[
      for (final GroupLine g in l) <String>[g.name, _dc(g.opening), tAmt(g.dr), tAmt(g.cr), _dc(g.closing)],
    ];
  }

  List<String> _grand(List<GroupLine> l) {
    double o = 0;
    double d = 0;
    double c = 0;
    for (final GroupLine g in l) {
      o += g.opening;
      d += g.dr;
      c += g.cr;
    }
    return <String>[bi('કુલ (Grand Total)', 'Grand Total'), _dc(o), tAmt(d), tAmt(c), _dc(o + d - c)];
  }

  void _open(GroupLine g) {
    if (g.go.isEmpty) return;
    if (g.go == 'my_daybook') {
      app.go('my_daybook', arg: DayBookArg(type: g.arg, sel: _sel));
    } else {
      app.go(g.go, arg: g.arg.isEmpty ? null : g.arg);
    }
  }

  Future<void> _print() async {
    final List<GroupLine> l = groupSummary(_sel.period);
    await printOut(
      reportHtml(
        title: 'Group Summary',
        period: _pText(_sel.period),
        heads: const <String>['Particulars', 'Opening Balance', 'Debit', 'Credit', 'Closing Balance'],
        right: const <bool>[false, true, true, true, true],
        rows: _rows(l),
        total: _grand(l),
      ),
      'group-summary',
    );
  }

  Future<void> _export() async {
    final List<GroupLine> l = groupSummary(_sel.period);
    final StringBuffer b = StringBuffer();
    b.writeln('Particulars,Opening Balance,Debit,Credit,Closing Balance');
    for (final List<String> row in _rows(l)) {
      b.writeln(row.map(csvCell).join(','));
    }
    b.writeln(_grand(l).map(csvCell).join(','));
    await exportCsvOut(b.toString(), 'group-summary-${dayKey(DateTime.now())}');
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[payDoc, saleDoc, expDoc, prefDoc, rateDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 1100,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final Period p = _sel.period;
          final List<GroupLine> l = groupSummary(p);
          final bool pc = app.stagePc;
          final List<PcCol> cols = <PcCol>[
            PcCol(bi('વિગત (Particulars)', 'Particulars'), 0),
            PcCol(bi('શરૂઆતનું બાકી', 'Opening Balance'), 150, right: true),
            PcCol(bi('ઉધાર (Debit)', 'Debit'), 130, right: true),
            PcCol(bi('જમા (Credit)', 'Credit'), 130, right: true),
            PcCol(bi('આખરી બાકી', 'Closing Balance'), 150, right: true),
          ];
          final List<String> g = _grand(l);
          final List<Widget> body = <Widget>[];
          if (l.isEmpty) {
            body.add(EmptyBox(icon: 'balance', title: bi('આ સમયમાં કોઈ હિસાબ નથી', 'Nothing to show for this period')));
          } else if (pc) {
            body.add(pcHead(cols));
            for (final GroupLine x in l) {
              body.add(pcRow(
                cols,
                <Widget>[pcTd(x.name, bold: true), pcTd(_dc(x.opening), num: true), pcTd(tAmt(x.dr), num: true), pcTd(tAmt(x.cr), num: true), pcTd(_dc(x.closing), num: true, bold: true)],
                onTap: x.go.isEmpty ? null : () => _open(x),
              ));
            }
            body.add(pcTotal(cols, g[0], vals: <int, String>{1: g[1], 2: g[2], 3: g[3], 4: g[4]}));
          } else {
            for (final GroupLine x in l) {
              body.add(lineItem(
                icon: 'balance',
                tone: 'teal',
                title: x.name,
                sub: '${tAmt(x.dr).isEmpty ? '0.00' : tAmt(x.dr)} Dr · ${tAmt(x.cr).isEmpty ? '0.00' : tAmt(x.cr)} Cr',
                trailing: tDr(x.closing),
                onTap: x.go.isEmpty ? null : () => _open(x),
              ));
            }
            body.add(Surface(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: <Widget>[
                  Expanded(child: Text(g[0], style: ts(13.5, w: FontWeight.w800))),
                  Text(g[4], style: ts(13.5, w: FontWeight.w800, tab: true)),
                ],
              ),
            ));
          }
          return <Widget>[
            ScreenHeader('Group Summary', sub: _pText(p), actions: <Widget>[
              IconBtn('print', tip: bi('પ્રિન્ટ (Ctrl+P)', 'Print (Ctrl+P)'), onTap: _print),
              IconBtn('table', tip: bi('Excel (Alt+E)', 'Export to Excel (Alt+E)'), onTap: _export),
            ]),
            statusBanner(),
            RangeBar(sel: _sel, presets: const <int>[3, 4, 5, 6], onChanged: (RangeSel s) => setState(() => _sel = s)),
            tallyStrip(TallyWhat.all, from: _sel.period.from, to: _sel.period.lastDay),
            const SizedBox(height: 10),
            ...body,
            const SizedBox(height: 6),
            caption(bi('લીટી પર Enter: તે ગ્રુપના વાઉચર / ખાતા.', 'Press Enter on a line to open the vouchers / ledgers of that group.')),
          ];
        },
      ),
    );
  }
}

// ======================================================================
// Bank Book
// ======================================================================

class BankBookScreen extends StatefulWidget {
  /// true = the Cash Book (same table, the cash side of the vouchers)
  final bool cash;
  const BankBookScreen({super.key, this.cash = false});

  @override
  State<BankBookScreen> createState() => _BankBookState();
}

class _BankBookState extends State<BankBookScreen> {
  late final VoidCallback _prn = () {
    _print();
  };
  late final VoidCallback _exp = () {
    _export();
  };

  RangeSel _sel = RangeSel(4);

  @override
  void initState() {
    super.initState();
    printHub.push(_prn);
    exportHub.push(_exp);
  }

  @override
  void dispose() {
    printHub.pop(_prn);
    exportHub.pop(_exp);
    super.dispose();
  }

  bool get _cash => widget.cash;

  String get _title => _cash ? 'Cash Book' : 'Bank Book';

  List<Vch> _list(Period p) => _cash ? cashVouchers(p) : bankVouchers(p);

  BankFig _fig(Period p) => _cash ? cashFig(p) : bankFig(p);

  bool _in(Vch v) => _cash ? isCashIn(v) : isMoneyIn(v);

  String _particulars(Vch v) {
    if (v.type == 'CON') return '${_cash ? contraBankName() : contraCashName()}  (Contra${v.ref.isEmpty ? '' : ' ${v.ref}'})';
    if (_cash) return v.party;
    final String how = payModeLabel(v.mode) + (v.ref.isEmpty ? '' : ' ${v.ref}');
    return '${v.party}  ($how)';
  }

  List<List<String>> _rows(Period p, List<Vch> l, BankFig f) {
    final List<List<String>> rows = <List<String>>[];
    if (f.opening.abs() >= 0.005) rows.add(<String>['', 'Opening Balance', '', '', f.opening > 0 ? tAmt(f.opening) : '', f.opening < 0 ? tAmt(f.opening) : '']);
    String last = '';
    for (final Vch v in l) {
      final String d = tDate(v.date);
      final bool inn = _in(v);
      rows.add(<String>[d == last ? '' : d, _particulars(v), v.vt.en, vchNoText(v), inn ? tAmt(v.amt) : '', inn ? '' : tAmt(v.amt)]);
      last = d;
    }
    return rows;
  }

  Future<void> _print() async {
    final Period p = _sel.period;
    final List<Vch> l = _list(p);
    final BankFig f = _fig(p);
    final double c = f.closing;
    final double dTot = (f.opening > 0 ? f.opening : 0) + f.dr + (c < 0 ? -c : 0);
    final double cTot = (f.opening < 0 ? -f.opening : 0) + f.cr + (c > 0 ? c : 0);
    final List<List<String>> rows = _rows(p, l, f);
    rows.add(<String>['', 'Current Total', '', '', tAmt(f.dr), tAmt(f.cr)]);
    rows.add(<String>['', 'Closing Balance', '', '', c < 0 ? tAmt(c) : '', c > 0 ? tAmt(c) : '']);
    await printOut(
      reportHtml(
        title: _title,
        period: _pText(p),
        heads: const <String>['Date', 'Particulars', 'Vch Type', 'Vch No.', 'Debit', 'Credit'],
        right: const <bool>[false, false, false, false, true, true],
        rows: rows,
        total: <String>['', '', '', '', tAmt(dTot), tAmt(cTot)],
        bold: <int>{rows.length - 2, rows.length - 1},
      ),
      _cash ? 'cash-book' : 'bank-book',
    );
  }

  Future<void> _export() async {
    await exportCsvOut(vouchersCsv(_list(_sel.period)), '${_cash ? 'cash' : 'bank'}-book-${dayKey(DateTime.now())}');
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[payDoc, saleDoc, expDoc, prefDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 1200,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final Period p = _sel.period;
          final List<Vch> l = _list(p);
          final BankFig f = _fig(p);
          final double c = f.closing;
          final double dTot = (f.opening > 0 ? f.opening : 0) + f.dr + (c < 0 ? -c : 0);
          final double cTot = (f.opening < 0 ? -f.opening : 0) + f.cr + (c > 0 ? c : 0);
          final bool pc = app.stagePc;
          final List<PcCol> cols = <PcCol>[
            PcCol(bi('તારીખ', 'Date'), 92),
            PcCol(bi('વિગત (Particulars)', 'Particulars'), 0),
            PcCol(bi('વાઉચર પ્રકાર', 'Vch Type'), 118),
            PcCol(bi('વાઉચર નં.', 'Vch No.'), 84),
            PcCol(bi('ઉધાર (Debit)', 'Debit'), 128, right: true),
            PcCol(bi('જમા (Credit)', 'Credit'), 128, right: true),
          ];
          final List<Widget> body = <Widget>[];
          if (l.isEmpty && f.opening.abs() < 0.005) {
            body.add(_cash
                ? EmptyBox(icon: 'book', title: bi('આ સમયમાં રોકડનો કોઈ વ્યવહાર નથી', 'No cash entries in this period'), sub: bi('ચૂકવણી, રસીદ કે ખર્ચની એન્ટ્રીમાં રીત "રોકડ" પસંદ કરો', 'Choose Cash as the mode in a payment, receipt or expense'))
                : EmptyBox(icon: 'bank', title: bi('આ સમયમાં બેંક / UPI / ચેકનો કોઈ વ્યવહાર નથી', 'No bank / UPI / cheque entries in this period'), sub: bi('ચૂકવણી કે રકમ મળી ની એન્ટ્રીમાં રીત બેંક / UPI / ચેક પસંદ કરો', 'Choose Bank / UPI / Cheque as the mode in a payment or receipt')));
          } else if (pc) {
            body.add(pcHead(cols));
            if (f.opening.abs() >= 0.005) {
              body.add(pcRow(cols, <Widget>[pcTd(''), pcTd('Opening Balance', bold: true), pcTd(''), pcTd(''), pcTd(f.opening > 0 ? tAmt(f.opening) : '', num: true, bold: true), pcTd(f.opening < 0 ? tAmt(f.opening) : '', num: true, bold: true)], bg: Pal.soft));
            }
            String last = '';
            for (final Vch v in l.take(600)) {
              final String d = tDate(v.date);
              final bool inn = _in(v);
              body.add(pcRow(
                cols,
                <Widget>[
                  pcTd(d == last ? '' : d, num: true),
                  pcTd(_particulars(v), bold: true),
                  pcTd(v.vt.name),
                  pcTd(vchNoText(v), num: true),
                  pcTd(inn ? tAmt(v.amt) : '', num: true, bold: true),
                  pcTd(inn ? '' : tAmt(v.amt), num: true, bold: true),
                ],
                onTap: () => openVoucher(ctx, v),
              ));
              last = d;
            }
            body.add(pcTotal(cols, 'Current Total', labelAt: 1, vals: <int, String>{4: tAmt(f.dr), 5: tAmt(f.cr)}));
            body.add(pcTotal(cols, 'Closing Balance', labelAt: 1, vals: <int, String>{if (c < 0) 4: tAmt(c), if (c > 0) 5: tAmt(c)}));
            body.add(pcTotal(cols, '', labelAt: 1, vals: <int, String>{4: tAmt(dTot), 5: tAmt(cTot)}));
          } else {
            body.add(Surface(
              padding: const EdgeInsets.all(12),
              child: Column(
                children: <Widget>[
                  InfoRow(bi('શરૂઆતનું બાકી', 'Opening Balance'), f.opening.abs() < 0.005 ? '0.00' : tDr(f.opening)),
                  InfoRow(bi('જમા થયા (Debit)', 'Received (Debit)'), tAmt(f.dr).isEmpty ? '0.00' : tAmt(f.dr)),
                  InfoRow(bi('ચૂકવ્યા (Credit)', 'Paid (Credit)'), tAmt(f.cr).isEmpty ? '0.00' : tAmt(f.cr)),
                  InfoRow(bi('આખરી બાકી', 'Closing Balance'), c.abs() < 0.005 ? '0.00' : tDr(c), bold: true, color: Pal.brand),
                ],
              ),
            ));
            body.add(const SizedBox(height: 8));
            for (final Vch v in l.take(400)) {
              final bool inn = _in(v);
              body.add(lineItem(
                icon: inn ? 'arrowdown' : 'arrowup',
                tone: inn ? 'green' : 'amber',
                title: v.type == 'CON' ? (_cash ? contraBankName() : contraCashName()) : v.party,
                sub: '${tDate(v.date)} · ${v.vt.name} ${vchNoText(v)}${(v.type == 'CON' || _cash) ? '' : ' · ${payModeLabel(v.mode)}'}',
                trailing: '${tAmt(v.amt)} ${inn ? 'Dr' : 'Cr'}',
                onTap: () => openVoucher(ctx, v),
              ));
            }
          }
          return <Widget>[
            ScreenHeader(_title, sub: _pText(p), actions: <Widget>[
              IconBtn('plus', tip: bi('કોન્ટ્રા (રોકડ ↔ બેંક)', 'Contra (cash / bank)'), onTap: () => openContraForm(ctx)),
              IconBtn('print', tip: bi('પ્રિન્ટ (Ctrl+P)', 'Print (Ctrl+P)'), onTap: _print),
              IconBtn('table', tip: bi('Excel (Alt+E)', 'Export to Excel (Alt+E)'), onTap: _export),
            ]),
            statusBanner(),
            RangeBar(sel: _sel, presets: const <int>[3, 4, 5, 6], onChanged: (RangeSel s) => setState(() => _sel = s)),
            tallyStrip(_cash ? TallyWhat.cash : TallyWhat.bank),
            tallyRows(_cash ? TallyRows.cash : TallyRows.bank, from: p.from, to: p.lastDay),
            const SizedBox(height: 10),
            ...body,
            const SizedBox(height: 6),
            caption(_cash ? bi('રોકડથી મળેલી / ચૂકવેલી રકમ. બેંક, UPI અને ચેક માટે Bank Book જુઓ.', 'Money received / paid in cash. For bank, UPI and cheque see the Bank Book.') : bi('બેંક, UPI અને ચેકથી મળેલી / ચૂકવેલી રકમ. રોકડ માટે રોજમેળ જુઓ.', 'Money received / paid by bank, UPI and cheque. For cash see the Cash Book.')),
          ];
        },
      ),
    );
  }
}

// ======================================================================
// Outstandings (Receivables and Payables with ageing)
// ======================================================================

class OutstandingsScreen extends StatefulWidget {
  const OutstandingsScreen({super.key});

  @override
  State<OutstandingsScreen> createState() => _OutState();
}

class _OutState extends State<OutstandingsScreen> {
  late final VoidCallback _prn = () {
    _print();
  };
  late final VoidCallback _exp = () {
    _export();
  };

  int _tab = 0; // 0 receivables, 1 payables
  DateTime _day = dateOnly(DateTime.now());
  final TextEditingController _q = TextEditingController();

  @override
  void initState() {
    super.initState();
    printHub.push(_prn);
    exportHub.push(_exp);
  }

  @override
  void dispose() {
    _q.dispose();
    printHub.pop(_prn);
    exportHub.pop(_exp);
    super.dispose();
  }

  String get _title => _tab == 0 ? 'Outstandings - Receivables' : 'Outstandings - Payables';

  List<OutLine> _list() {
    final String q = _q.text.trim().toLowerCase();
    final List<OutLine> l = outstandings(_tab == 0, _day);
    if (q.isEmpty) return l;
    return l.where((OutLine o) => o.ref.name.toLowerCase().contains(q)).toList();
  }

  List<List<String>> _rows(List<OutLine> l) {
    return <List<String>>[
      for (final OutLine o in l)
        <String>[
          o.ref.name,
          o.last == null ? '' : tDate(o.last!),
          tAmt(o.age[0]),
          tAmt(o.age[1]),
          tAmt(o.age[2]),
          tAmt(o.age[3]),
          tAmt(o.balance),
        ],
    ];
  }

  List<String> _total(List<OutLine> l) {
    final List<double> a = <double>[0, 0, 0, 0];
    double t = 0;
    for (final OutLine o in l) {
      for (int i = 0; i < 4; i++) {
        a[i] += o.age[i];
      }
      t += o.balance;
    }
    return <String>['Grand Total', '', tAmt(a[0]), tAmt(a[1]), tAmt(a[2]), tAmt(a[3]), tAmt(t)];
  }

  Future<void> _print() async {
    final List<OutLine> l = _list();
    await printOut(
      reportHtml(
        title: _title,
        period: '${bi('તારીખ', 'As on')} ${tDateFull(_day)}',
        heads: const <String>['Particulars', 'Last Voucher', '0 - 30 days', '31 - 60 days', '61 - 90 days', 'Over 90 days', 'Pending Amount'],
        right: const <bool>[false, false, true, true, true, true, true],
        rows: _rows(l),
        total: _total(l),
      ),
      _tab == 0 ? 'receivables' : 'payables',
    );
  }

  Future<void> _export() async {
    final List<OutLine> l = _list();
    final StringBuffer b = StringBuffer();
    b.writeln('Particulars,Last Voucher,0-30 days,31-60 days,61-90 days,Over 90 days,Pending Amount');
    for (final List<String> row in _rows(l)) {
      b.writeln(row.map(csvCell).join(','));
    }
    b.writeln(_total(l).map(csvCell).join(','));
    await exportCsvOut(b.toString(), '${_tab == 0 ? 'receivables' : 'payables'}-${dayKey(DateTime.now())}');
  }

  Future<void> _pickDay() async {
    final DateTime? d = await pickDay(context, _day, last: dateOnly(DateTime.now()));
    if (d != null && mounted) setState(() => _day = d);
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[payDoc, saleDoc, expDoc, prefDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 1200,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final List<OutLine> l = _list();
          final bool pc = app.stagePc;
          final List<String> tot = _total(l);
          final List<PcCol> cols = <PcCol>[
            PcCol(bi('વિગત (Particulars)', 'Particulars'), 0),
            PcCol(bi('છેલ્લો વાઉચર', 'Last Voucher'), 96),
            PcCol(bi('0 - 30 દિવસ', '0 - 30 days'), 112, right: true),
            PcCol(bi('31 - 60 દિવસ', '31 - 60 days'), 112, right: true),
            PcCol(bi('61 - 90 દિવસ', '61 - 90 days'), 112, right: true),
            PcCol(bi('90 થી વધુ', 'Over 90 days'), 112, right: true),
            PcCol(bi('બાકી રકમ', 'Pending Amount'), 130, right: true),
          ];
          final List<Widget> body = <Widget>[];
          if (l.isEmpty) {
            body.add(EmptyBox(icon: 'balance', title: _tab == 0 ? bi('કોઈ ખરીદનારનું લેણું બાકી નથી', 'No buyer owes anything') : bi('કોઈ ખેડૂતને આપવાનું બાકી નથી', 'Nothing is due to any farmer')));
          } else if (pc) {
            body.add(pcHead(cols));
            for (final OutLine o in l.take(800)) {
              body.add(pcRow(
                cols,
                <Widget>[
                  pcTd(o.ref.name, bold: true),
                  pcTd(o.last == null ? '' : tDate(o.last!), num: true),
                  pcTd(tAmt(o.age[0]), num: true),
                  pcTd(tAmt(o.age[1]), num: true),
                  pcTd(tAmt(o.age[2]), num: true),
                  pcTd(tAmt(o.age[3]), num: true, c: o.age[3] > 0.005 ? Pal.bad : null),
                  pcTd(tAmt(o.balance), num: true, bold: true),
                ],
                onTap: () => app.go('my_ledger', arg: o.ref),
              ));
            }
            body.add(pcTotal(cols, tot[0], vals: <int, String>{2: tot[2], 3: tot[3], 4: tot[4], 5: tot[5], 6: tot[6]}));
          } else {
            for (final OutLine o in l.take(400)) {
              body.add(lineItem(
                icon: _tab == 0 ? 'rupee' : 'agri',
                tone: _tab == 0 ? 'amber' : 'green',
                title: o.ref.name,
                sub: '${o.last == null ? '' : '${tDate(o.last!)} · '}${bi('90 થી વધુ', 'Over 90')}: ${tAmt(o.age[3]).isEmpty ? '0.00' : tAmt(o.age[3])}',
                trailing: tAmt(o.balance),
                onTap: () => app.go('my_ledger', arg: o.ref),
              ));
            }
            body.add(Surface(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: <Widget>[
                  Expanded(child: Text(tot[0], style: ts(13.5, w: FontWeight.w800))),
                  Text(tot[6], style: ts(13.5, w: FontWeight.w800, tab: true)),
                ],
              ),
            ));
          }
          return <Widget>[
            ScreenHeader('Outstandings', sub: '${_tab == 0 ? bi('લેવાના (Receivables)', 'Receivables') : bi('આપવાના (Payables)', 'Payables')} · ${bi('તારીખ', 'as on')} ${tDateFull(_day)}', actions: <Widget>[
              dayButton(_day, _pickDay),
              IconBtn('print', tip: bi('પ્રિન્ટ (Ctrl+P)', 'Print (Ctrl+P)'), onTap: _print),
              IconBtn('table', tip: bi('Excel (Alt+E)', 'Export to Excel (Alt+E)'), onTap: _export),
            ]),
            statusBanner(),
            tallyStrip(TallyWhat.dues),
            Seg(labels: <String>[bi('લેવાના (ખરીદનાર)', 'Receivables (buyers)'), bi('આપવાના (ખેડૂત)', 'Payables (farmers)')], index: _tab, onChanged: (int i) => setState(() => _tab = i)),
            const SizedBox(height: 10),
            SearchBox(hint: bi('નામ શોધો', 'Search name'), controller: _q, onChanged: (String _) => setState(() {})),
            const SizedBox(height: 10),
            ...body,
            const SizedBox(height: 6),
            caption(bi('બાકી રકમ સૌથી નવા બિલથી ગણાય છે (0-30, 31-60, 61-90, 90 થી વધુ દિવસ). લીટી પર Enter: ખાતું.', 'The pending amount is counted against the newest bills first (0-30, 31-60, 61-90, over 90 days). Press Enter on a line to open the ledger.')),
          ];
        },
      ),
    );
  }
}

// ======================================================================
// Ratio Analysis
// ======================================================================

class _RRow {
  final String name;
  final String value;
  final String meaning;
  final bool head;
  final Color? color;
  final VoidCallback? onTap;
  const _RRow(this.name, this.value, this.meaning, {this.head = false, this.color, this.onTap});
}

String _rMoney(double v) => v.abs() < 0.005 ? '0.00' : (v < 0 ? '(-) ${grp(-v, dec: 2)}' : grp(v, dec: 2));

String _rTimes(double? v) => v == null ? '-' : '${v.toStringAsFixed(2)} : 1';

String _rPct(double? v) => v == null ? '-' : '${v.toStringAsFixed(2)} %';

String _rDays(double? v) => v == null ? '-' : '${v.round()} ${bi('દિવસ', 'days')}';

class RatioScreen extends StatefulWidget {
  const RatioScreen({super.key});

  @override
  State<RatioScreen> createState() => _RatioState();
}

class _RatioState extends State<RatioScreen> {
  late final VoidCallback _prn = () {
    _print();
  };
  late final VoidCallback _exp = () {
    _export();
  };

  RangeSel _sel = _fySel();

  @override
  void initState() {
    super.initState();
    printHub.push(_prn);
    exportHub.push(_exp);
  }

  @override
  void dispose() {
    printHub.pop(_prn);
    exportHub.pop(_exp);
    super.dispose();
  }

  Color? _good(double? v, double min) => v == null ? null : (v >= min ? Pal.ok : Pal.bad);

  List<_RRow> _rows(RatioReport r) {
    return <_RRow>[
      _RRow(bi('મુખ્ય ગ્રુપ (Principal Groups)', 'Principal Groups'), '', '', head: true),
      _RRow(bi('રોકડ (Cash-in-hand)', 'Cash-in-hand'), _rMoney(r.cash), bi('કૅશબુક મુજબ આજની રોકડ', 'Cash as per the Cash Book'), onTap: () => app.go('cashbook')),
      _RRow(bi('બેંક ખાતા (Bank Accounts)', 'Bank Accounts'), _rMoney(r.bank), bi('UPI / બેંક / ચેકની આવક - જાવકનો તફાવત', 'UPI / bank / cheque receipts less payments'), onTap: () => app.go('bank_book')),
      _RRow(bi('લેવાના (Receivables)', 'Receivables'), _rMoney(r.receivables), bi('ખરીદનાર પાસે લેવાના + ખેડૂતને આપેલ એડવાન્સ', 'Due from buyers + advances paid to farmers'), onTap: () => app.go('outstandings')),
      _RRow(bi('દેવાના (Payables)', 'Payables'), _rMoney(r.payables), bi('ખેડૂતને ચૂકવવાના', 'Due to farmers'), onTap: () => app.go('outstandings')),
      _RRow(bi('આખરી સ્ટોક', 'Closing Stock'), _rMoney(r.stock), bi('સ્ટોકની કિંમત (બેલેન્સ શીટ મુજબ)', 'Stock value as on the Balance Sheet'), onTap: () => app.go('stock_live')),
      _RRow(bi('કુલ ચાલુ મિલકત', 'Current Assets'), _rMoney(r.currentAssets), bi('રોકડ + બેંક + લેવાના + સ્ટોક', 'Cash + Bank + Receivables + Stock')),
      _RRow(bi('કુલ ચાલુ જવાબદારી', 'Current Liabilities'), _rMoney(r.currentLiabilities), bi('દેવાના + ઓવરડ્રાફ્ટ', 'Payables + overdrawn cash / bank')),
      _RRow(bi('વર્કિંગ કેપિટલ', 'Working Capital'), _rMoney(r.workingCapital), bi('ચાલુ મિલકત - ચાલુ જવાબદારી', 'Current Assets - Current Liabilities'), color: r.workingCapital >= 0 ? Pal.ok : Pal.bad),
      _RRow(bi('મુખ્ય ગુણોત્તર (Principal Ratios)', 'Principal Ratios'), '', '', head: true),
      _RRow(bi('કરન્ટ રેશિયો', 'Current Ratio'), _rTimes(r.currentRatio), bi('ચાલુ મિલકત ÷ ચાલુ જવાબદારી (1 થી વધારે સારો)', 'Current Assets / Current Liabilities (above 1 is good)'), color: _good(r.currentRatio, 1)),
      _RRow(bi('ક્વિક રેશિયો', 'Quick Ratio'), _rTimes(r.quickRatio), bi('(ચાલુ મિલકત - સ્ટોક) ÷ ચાલુ જવાબદારી', '(Current Assets - Stock) / Current Liabilities'), color: _good(r.quickRatio, 1)),
      _RRow(bi('વેચાણ', 'Sales'), _rMoney(r.sales), bi('પીરિયડનું કુલ વેચાણ', 'Total sales of the period'), onTap: () => app.go('profit_loss')),
      _RRow(bi('ખરીદી', 'Purchase'), _rMoney(r.purchase), bi('પીરિયડની કુલ ખરીદી (ચિઠ્ઠી)', 'Total purchase of the period (chits)'), onTap: () => app.go('profit_loss')),
      _RRow(bi('ગ્રોસ પ્રોફિટ', 'Gross Profit'), _rMoney(r.gross), bi('ટ્રેડિંગ ખાતા મુજબ', 'As per the Trading Account'), color: r.gross >= 0 ? Pal.ok : Pal.bad),
      _RRow(bi('ચોખ્ખો નફો', 'Net Profit'), _rMoney(r.net), bi('Profit & Loss A/c મુજબ', 'As per the Profit & Loss A/c'), color: r.net >= 0 ? Pal.ok : Pal.bad),
      _RRow(bi('ગ્રોસ પ્રોફિટ %', 'Gross Profit %'), _rPct(r.grossPct), bi('ગ્રોસ પ્રોફિટ ÷ વેચાણ', 'Gross Profit / Sales'), color: _good(r.grossPct, 0)),
      _RRow(bi('ચોખ્ખો નફો %', 'Net Profit %'), _rPct(r.netPct), bi('ચોખ્ખો નફો ÷ વેચાણ', 'Net Profit / Sales'), color: _good(r.netPct, 0)),
      _RRow(bi('ખર્ચ %', 'Expense %'), _rPct(r.expensePct), bi('કુલ ખર્ચ ÷ વેચાણ', 'Total expenses / Sales')),
      _RRow(bi('ઉઘરાણી દિવસ', 'Receivable Days'), _rDays(r.receivableDays), bi('લેવાના ÷ વેચાણ × દિવસ - ઓછા સારા', 'Receivables / Sales x days - fewer is better')),
      _RRow(bi('ચૂકવણી દિવસ', 'Payable Days'), _rDays(r.payableDays), bi('દેવાના ÷ ખરીદી × દિવસ', 'Payables / Purchase x days')),
      _RRow(bi('સ્ટોક ફેરબદલી', 'Inventory Turnover'), _rTimes(r.inventoryTurnover), bi('વેચાયેલ માલની કિંમત ÷ સરેરાશ સ્ટોક (બંને સ્ટોક કિંમત જોઈએ)', 'Cost of goods sold / average stock (needs both stock values)')),
    ];
  }

  List<String> get _heads => <String>['Particulars', 'Value', 'Meaning'];

  List<List<String>> _flatRows(RatioReport r, Set<int> bold) {
    final List<List<String>> out = <List<String>>[];
    for (final _RRow x in _rows(r)) {
      if (x.head) bold.add(out.length);
      out.add(<String>[x.name, x.value, x.meaning]);
    }
    return out;
  }

  Future<void> _print() async {
    final RatioReport r = ratioReport(_sel.period);
    final Set<int> bold = <int>{};
    final List<List<String>> rows = _flatRows(r, bold);
    await printOut(
      reportHtml(title: 'Ratio Analysis', period: _pText(r.period), heads: _heads, right: const <bool>[false, true, false], rows: rows, bold: bold),
      'ratio-analysis',
    );
  }

  Future<void> _export() async {
    final RatioReport r = ratioReport(_sel.period);
    final StringBuffer b = StringBuffer();
    b.writeln(_heads.map(csvCell).join(','));
    for (final List<String> row in _flatRows(r, <int>{})) {
      b.writeln(row.map(csvCell).join(','));
    }
    await exportCsvOut(b.toString(), 'ratio-analysis-${dayKey(DateTime.now())}');
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[payDoc, saleDoc, expDoc, prefDoc, rateDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 1100,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final Period p = _sel.period;
          final RatioReport r = ratioReport(p);
          final List<_RRow> rows = _rows(r);
          final bool pc = app.stagePc;
          final List<PcCol> cols = <PcCol>[
            PcCol(bi('વિગત (Particulars)', 'Particulars'), 300),
            PcCol(bi('કિંમત', 'Value'), 160, right: true),
            PcCol(bi('મતલબ', 'Meaning'), 0),
          ];
          final List<Widget> body = <Widget>[];
          if (pc) {
            body.add(pcHead(cols));
            for (final _RRow x in rows) {
              body.add(pcRow(
                cols,
                <Widget>[pcTd(x.name, bold: x.head), pcTd(x.value, num: true, bold: true, c: x.color), pcTd(x.meaning, c: Pal.muted)],
                onTap: x.onTap,
                bg: x.head ? Pal.soft : null,
              ));
            }
          } else {
            for (final _RRow x in rows) {
              if (x.head) {
                body.add(caption(x.name));
              } else {
                body.add(Surface(
                  padding: const EdgeInsets.fromLTRB(12, 6, 12, 8),
                  child: InkWell(
                    onTap: x.onTap,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        InfoRow(x.name, x.value, bold: true, color: x.color),
                        Text(x.meaning, style: ts(12, c: Pal.muted, h: 1.3)),
                      ],
                    ),
                  ),
                ));
                body.add(const SizedBox(height: 6));
              }
            }
          }
          final bool empty = r.sales < 0.5 && r.purchase < 0.5 && r.receivables < 0.5 && r.payables < 0.5 && r.cash.abs() < 0.5 && r.bank.abs() < 0.5;
          return <Widget>[
            ScreenHeader('Ratio Analysis', sub: _pText(p), actions: <Widget>[
              IconBtn('print', tip: bi('પ્રિન્ટ (Ctrl+P)', 'Print (Ctrl+P)'), onTap: _print),
              IconBtn('table', tip: bi('Excel (Alt+E)', 'Export to Excel (Alt+E)'), onTap: _export),
            ]),
            statusBanner(),
            RangeBar(sel: _sel, presets: const <int>[3, 4, 5, 6], onChanged: (RangeSel s) => setState(() => _sel = s)),
            tallyStrip(TallyWhat.all, from: _sel.period.from, to: _sel.period.lastDay),
            const SizedBox(height: 10),
            if (r.stockMissing && !empty) noteBox('warn', 'amber', bi('સ્ટોકની કિંમત નાખી નથી - કરન્ટ રેશિયો અને નફો સાચા નહીં આવે. Stock Summary માં ₹ દબાવી ભાવ લખો અને Balance Sheet માં "સ્ટોકની કિંમત" નાખો.', 'Stock value is not entered - the current ratio and profit will be off. Set the rates in Stock Summary and press "Stock Value" in the Balance Sheet.'), onTap: () => app.go('balance_sheet')),
            if (!r.stockUsed && !empty) noteBox('bulb', 'teal', bi('સ્ટોકની કિંમત આખા નાણાકીય વર્ષ (1 એપ્રિલથી) માટે જ ગણાય છે.', 'The stock value counts only when the period starts on 1 April.')),
            if (empty) EmptyBox(icon: 'chart', title: bi('હજી કોઈ હિસાબ નથી', 'Nothing to show yet')) else ...body,
          ];
        },
      ),
    );
  }
}
