part of 'tally_data.dart';

// ======================================================================
// New Tally tabs (part 2): ageing, bank book, GST, checks.
// ======================================================================

// ================================================================ ageing
Future<void> _openAge(BuildContext context, _AgeRow r, bool debtors) {
  return openPanel(
    context,
    title: r.name,
    sub: firmName(r.firm),
    width: 480,
    child: _AgePanel(r, debtors),
  );
}

class _AgePanel extends StatelessWidget {
  final _AgeRow r;
  final bool debtors;
  const _AgePanel(this.r, this.debtors);

  @override
  Widget build(BuildContext context) {
    const List<String> names = <String>['0–30', '31–60', '61–90', '90+'];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        _darkHead(
          debtors ? bi('લેવાના બાકી', 'To receive') : bi('ચૂકવવાના બાકી', 'To pay'),
          _rs(r.bal),
          r.oldest > 0 ? '${bi('સૌથી જૂનું બિલ', 'Oldest bill')}: ${_ageLabel(r.oldest)}' : '',
        ),
        const SizedBox(height: 12),
        Panel(
          title: bi('કેટલા દિવસથી બાકી', 'How old is it'),
          child: Column(
            children: <Widget>[
              for (int i = 0; i < 4; i++)
                if (r.b[i] > 0.5) InfoRow('${names[i]} ${bi('દિવસ', 'days')}', _rs(r.b[i])),
              InfoRow(
                debtors ? bi('છેલ્લી આવક', 'Last receipt') : bi('છેલ્લી ચૂકવણી', 'Last payment'),
                r.last.isEmpty ? '—' : dmy(DateTime.tryParse(r.last) ?? DateTime.now()),
              ),
            ],
          ),
        ),
        const SizedBox(height: 6),
        Text(
          bi('જૂના બિલ પહેલા ભરાયા ગણ્યા છે (FIFO). વર્ષની શરૂઆતનું બાકી "90+" માં ગણાય.', 'Oldest bills are taken as paid first (FIFO). The balance from before this year is counted in "90+".'),
          style: ts(12, c: Pal.faint),
        ),
        const SizedBox(height: 14),
        if (debtors) ...<Widget>[
          Btn(bi('WhatsApp પર યાદ અપાવો', 'Remind on WhatsApp'), icon: 'chat', onTap: () => whatsappText(_reminderText(r.name, r.bal, r.last))),
          const SizedBox(height: 8),
          Btn(bi('સંદેશ કૉપિ કરો', 'Copy the message'), icon: 'copy', kind: BtnKind.tonal, dense: true, onTap: () => copyText(_reminderText(r.name, r.bal, r.last))),
          const SizedBox(height: 8),
        ],
        Btn(bi('આખો હિસાબ', 'Full account'), icon: 'book', kind: BtnKind.outline, dense: true, onTap: () => openTallyParty(context, r.name)),
      ],
    );
  }
}

class _AgeTab extends StatefulWidget {
  final String firm;
  const _AgeTab({required this.firm});

  @override
  State<_AgeTab> createState() => _AgeTabState();
}

class _AgeTabState extends State<_AgeTab> {
  int _dir = 0;
  int _min = 0;
  int _limit = 60;
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final bool debtors = _dir == 0;
    final List<_AgeRow> all = _buildAge(debtors, widget.firm);
    final int minDays = _min == 0 ? 0 : (_min == 1 ? 31 : (_min == 2 ? 61 : 91));
    final String q = _nk(_q);
    final List<_AgeRow> list = <_AgeRow>[
      for (final _AgeRow r in all)
        if (r.oldest >= minDays && (q.isEmpty || _nk(r.name).contains(q))) r,
    ];
    double tot = 0;
    double o30 = 0;
    double o90 = 0;
    for (final _AgeRow r in all) {
      tot += r.bal;
      o30 += r.b[1] + r.b[2] + r.b[3];
      o90 += r.b[3];
    }
    final List<Widget> out = <Widget>[
      ChipRow(
        labels: <String>[bi('લેવાના (ખરીદનાર)', 'To receive (buyers)'), bi('દેવાના (ખેડૂત / પાર્ટી)', 'To pay (farmers / parties)')],
        index: _dir,
        onChanged: (int i) => setState(() {
          _dir = i;
          _limit = 60;
        }),
      ),
      const SizedBox(height: 10),
      metricGrid(context, <Widget>[
        MetricTile(label: debtors ? bi('કુલ લેવાના', 'Total to receive') : bi('કુલ ચૂકવવાના', 'Total to pay'), value: inrC(tot), icon: debtors ? 'bank' : 'pay', tone: debtors ? 'green' : 'rose', sub: '${all.length} ${bi('પાર્ટી', 'parties')}'),
        MetricTile(label: bi('30 દિવસથી જૂનું', 'Older than 30 days'), value: inrC(o30), icon: 'hist', tone: 'amber'),
        MetricTile(label: bi('90 દિવસથી જૂનું', 'Older than 90 days'), value: inrC(o90), icon: 'warn', tone: 'rose'),
      ], pcCols: 3),
      const SizedBox(height: 10),
      FieldX(
        label: bi('નામ શોધો', 'Find a name'),
        hint: bi('પાર્ટીનું નામ', 'Party name'),
        onChanged: (String s) => setState(() {
          _q = s;
          _limit = 60;
        }),
      ),
      const SizedBox(height: 10),
      ChipRow(
        labels: <String>[bi('બધા', 'All'), '30+ ${bi('દિવસ', 'days')}', '60+ ${bi('દિવસ', 'days')}', '90+ ${bi('દિવસ', 'days')}'],
        index: _min,
        onChanged: (int i) => setState(() {
          _min = i;
          _limit = 60;
        }),
      ),
      const SizedBox(height: 10),
    ];
    if (list.isNotEmpty) {
      out.add(Btn(bi('યાદી WhatsApp પર મોકલો', 'Send the list on WhatsApp'), icon: 'chat', kind: BtnKind.tonal, dense: true, onTap: () => whatsappText(_ageListText(list, debtors))));
      out.add(const SizedBox(height: 10));
    }
    if (list.isEmpty) {
      out.add(_emptyNote(all.isEmpty ? bi('Tally માં કોઈ બાકી નથી (ખાતા સિંક થયા છે?)', 'Nothing outstanding in Tally (have the ledgers synced?)') : bi('આ ફિલ્ટરમાં કોઈ નથી', 'Nobody for this filter')));
    }
    for (final _AgeRow r in list.take(_limit)) {
      final bool old = r.oldest > 60;
      out.add(lineItem(
        icon: debtors ? 'user' : 'users',
        tone: r.oldest > 90 ? 'rose' : (old ? 'amber' : (debtors ? 'green' : 'blue')),
        title: r.name,
        sub: '${_firmShort(r.firm)} · ${r.oldest > 0 ? '${bi('સૌથી જૂનું', 'oldest')} ${_ageLabel(r.oldest)}' : bi('નવું બાકી', 'recent')}${r.last.isEmpty ? '' : '\n${debtors ? bi('છેલ્લી આવક', 'Last receipt') : bi('છેલ્લી ચૂકવણી', 'Last payment')}: ${dmy(DateTime.tryParse(r.last) ?? DateTime.now())}'}',
        trailing: _rs(r.bal),
        trailingSub: r.b[3] > 0.5 ? '90+ ${_rs(r.b[3])}' : null,
        onTap: () => _openAge(context, r, debtors),
      ));
    }
    if (list.length > _limit) out.add(_moreBtn(list.length - _limit, () => setState(() => _limit += 100)));
    out.add(const SizedBox(height: 8));
    out.add(Text(
      bi('Tally ના ખાતાની બાકી રકમ અને વાઉચર પરથી ગણતરી. જૂના બિલ પહેલા ભરાયા ગણ્યા છે. આ ગણતરી અંદાજ છે - બિલ-વાર ચોક્કસ નથી.', 'Worked out from the Tally ledger balance and vouchers. Oldest bills are taken as paid first. It is an estimate - not exact bill by bill.'),
      style: ts(12, c: Pal.faint),
    ));
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: out);
  }
}

// ============================================================== bank book
class _BankTab extends StatefulWidget {
  final String firm;
  final String from;
  final String to;
  const _BankTab({required this.firm, required this.from, required this.to});

  @override
  State<_BankTab> createState() => _BankTabState();
}

class _BankTabState extends State<_BankTab> {
  int _sel = 0;
  int _limit = 80;

  @override
  Widget build(BuildContext context) {
    final Set<String> cash = _cashSet();
    final List<String> names = _bankNames(cash);
    if (names.isEmpty) return _emptyNote(bi('Tally માં બેંકનો કોઈ વ્યવહાર નથી', 'No bank entries in Tally'));
    final int sel = _sel > names.length ? 0 : _sel;
    final List<_BankEntry> entries = <_BankEntry>[];
    if (sel == 0) {
      for (final String n in names) {
        for (final _BankEntry e in _bankEntries(n, widget.firm, widget.from, widget.to)) {
          if (e.v.base != 'contra') entries.add(e);
        }
      }
      entries.sort((_BankEntry a, _BankEntry b) {
        final int c = b.v.date.compareTo(a.v.date);
        return c != 0 ? c : b.v.id.compareTo(a.v.id);
      });
    } else {
      entries.addAll(_bankEntries(names[sel - 1], widget.firm, widget.from, widget.to));
    }
    double inn = 0;
    double outt = 0;
    for (final _BankEntry e in entries) {
      if (e.inn) {
        inn += e.v.amount;
      } else {
        outt += e.v.amount;
      }
    }
    double bal = 0;
    bool haveBal = false;
    final String bk = sel == 0 ? '' : _nk(names[sel - 1]);
    for (final TLedger l in tallyStore.ledgers) {
      if (l.kind != 'bank') continue;
      if (widget.firm.isNotEmpty && l.firm != widget.firm) continue;
      if (bk.isNotEmpty && _nk(l.name) != bk) continue;
      bal += -l.closing;
      haveBal = true;
    }
    final List<Widget> out = <Widget>[
      ChipRow(
        labels: <String>[bi('બધી બેંક', 'All banks'), for (final String n in names) n.length > 22 ? '${n.substring(0, 22)}…' : n],
        index: sel,
        onChanged: (int i) => setState(() {
          _sel = i;
          _limit = 80;
        }),
      ),
      const SizedBox(height: 10),
      metricGrid(context, <Widget>[
        MetricTile(label: bi('બેંકમાં આવ્યા', 'Money in'), value: inrC(inn), icon: 'arrowdown', tone: 'green'),
        MetricTile(label: bi('બેંકમાંથી ગયા', 'Money out'), value: inrC(outt), icon: 'arrowup', tone: 'rose'),
        MetricTile(label: bi('Tally માં બેંક બાકી', 'Bank balance in Tally'), value: haveBal ? inrC(bal) : '—', icon: 'bank', tone: 'blue', sub: bi('અત્યારની', 'right now')),
      ], pcCols: 3),
      const SizedBox(height: 12),
    ];
    if (entries.isEmpty) {
      out.add(_emptyNote(bi('આ સમયમાં બેંકનો કોઈ વ્યવહાર નથી', 'No bank entries in this period')));
      return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: out);
    }
    out.add(Btn(
      bi('CSV કૉપિ (Excel માટે)', 'Copy CSV (for Excel)'),
      icon: 'copy',
      kind: BtnKind.tonal,
      dense: true,
      onTap: () => copyText(
        csvOf(
          <String>['date', 'bank', 'type', 'no', 'party', 'in', 'out', 'utr', 'narration'],
          <List<Object?>>[
            for (final _BankEntry e in entries) <Object?>[e.v.date, e.v.bank, e.v.type, e.v.no, e.who, e.inn ? e.v.amount : '', e.inn ? '' : e.v.amount, e.v.utr, e.v.narr],
          ],
        ),
        msg: bi('CSV કૉપિ થયું', 'CSV copied'),
      ),
    ));
    out.add(const SizedBox(height: 10));
    if (app.stagePc) {
      final List<_Col> cols = <_Col>[
        _Col(bi('તારીખ', 'Date'), 56),
        _Col(bi('વિગત (Particulars)', 'Particulars'), 0),
        _Col(bi('વાઉચર', 'Voucher'), 100),
        _Col(bi('નંબર', 'No'), 60),
        if (sel == 0) _Col(bi('બેંક', 'Bank'), 140),
        _Col('UTR', 150),
        _Col(bi('આવક (Dr)', 'Receipt (Dr)'), 110, right: true),
        _Col(bi('જાવક (Cr)', 'Payment (Cr)'), 110, right: true),
      ];
      out.add(_tblHead(cols));
      String lastDay = '';
      for (final _BankEntry e in entries.take(_limit)) {
        if (e.v.date != lastDay) {
          lastDay = e.v.date;
          double di = 0;
          double dout = 0;
          for (final _BankEntry x in entries) {
            if (x.v.date != lastDay) continue;
            if (x.inn) {
              di += x.v.amount;
            } else {
              dout += x.v.amount;
            }
          }
          out.add(_tDay('${dayName(e.v.dt)} · ${dmy(e.v.dt)}', a: _rs(di), b: _rs(dout)));
        }
        out.add(_tblRow(
          cols,
          <Widget>[
            _td('${pad2(e.v.dt.day)}-${pad2(e.v.dt.month)}', c: Pal.muted, num: true),
            _td(e.who.isEmpty ? e.v.title : e.who, bold: true),
            _td(e.v.type, c: Pal.muted),
            _td(e.v.no.isEmpty ? '' : '#${e.v.no}', c: Pal.muted),
            if (sel == 0) _td(e.v.bank, c: Pal.muted),
            _td(e.v.utr, c: Pal.muted),
            _td(e.inn ? _rs(e.v.amount) : '', num: true),
            _td(e.inn ? '' : _rs(e.v.amount), num: true),
          ],
          onTap: () => openTallyVoucher(context, e.v),
        ));
      }
      out.add(_tblRow(
        cols,
        <Widget>[
          _td(''),
          _td('${bi('કુલ', 'Total')} · ${entries.length}', bold: true),
          _td(''),
          _td(''),
          if (sel == 0) _td(''),
          _td(''),
          _td(_rs(inn), bold: true, num: true),
          _td(_rs(outt), bold: true, num: true),
        ],
        bg: Pal.soft,
        h: 32,
      ));
      if (entries.length > _limit) out.add(_moreBtn(entries.length - _limit, () => setState(() => _limit += 200)));
      out.add(const SizedBox(height: 8));
      out.add(Text(bi('બેંક પાસબુક સાથે મેળવવા UTR વાપરો.', 'Use the UTR to match with the bank passbook.'), style: ts(12, c: Pal.faint)));
      return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: out);
    }
    String day = '';
    for (final _BankEntry e in entries.take(_limit)) {
      if (e.v.date != day) {
        day = e.v.date;
        out.add(caption('${dayName(e.v.dt)} · ${dmy(e.v.dt)}'));
      }
      final String utr = e.v.utr.isEmpty ? '' : ' · UTR ${e.v.utr}';
      out.add(lineItem(
        icon: e.inn ? 'arrowdown' : 'arrowup',
        tone: e.inn ? 'green' : 'rose',
        title: e.who.isEmpty ? e.v.title : e.who,
        sub: '${e.v.type}${e.v.no.isEmpty ? '' : ' · #${e.v.no}'}${sel == 0 ? ' · ${e.v.bank}' : ''}$utr${e.v.narr.isEmpty ? '' : '\n${e.v.narr}'}',
        trailing: '${e.inn ? '+' : '−'} ${_rs(e.v.amount)}',
        trailingColor: e.inn ? Pal.ok : Pal.bad,
        onTap: () => openTallyVoucher(context, e.v),
      ));
    }
    if (entries.length > _limit) out.add(_moreBtn(entries.length - _limit, () => setState(() => _limit += 120)));
    out.add(const SizedBox(height: 8));
    out.add(Text(bi('બેંક પાસબુક સાથે મેળવવા UTR વાપરો.', 'Use the UTR to match with the bank passbook.'), style: ts(12, c: Pal.faint)));
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: out);
  }
}

// ================================================================== GST
class _GstTab extends StatelessWidget {
  final String firm;
  final String from;
  final String to;
  const _GstTab({required this.firm, required this.from, required this.to});

  String _ymLabel(String ym) {
    if (ym.length < 7) return ym;
    final int y = int.tryParse(ym.substring(0, 4)) ?? 2000;
    final int m = int.tryParse(ym.substring(5, 7)) ?? 1;
    return monthYear(DateTime(y, m < 1 || m > 12 ? 1 : m, 1));
  }

  @override
  Widget build(BuildContext context) {
    final _Gst g = _buildGst(firm, from, to);
    final double net = g.outTax - g.inTax;
    final List<Widget> out = <Widget>[];
    if (g.total == 0) {
      return _emptyNote(bi('આ સમયમાં વેચાણ / ખરીદીનું કોઈ વાઉચર નથી', 'No sales / purchase vouchers in this period'));
    }
    out.add(metricGrid(context, <Widget>[
      MetricTile(label: bi('વેચાણ પરનો ટેક્સ (Output)', 'Tax on sales (Output)'), value: inrC(g.outTax), icon: 'cart', tone: 'green', sub: '${bi('કરપાત્ર', 'Taxable')} ${inrC(g.outBase)}'),
      MetricTile(label: bi('ખરીદી પરનો ટેક્સ (Input)', 'Tax on purchase (Input)'), value: inrC(g.inTax), icon: 'bag', tone: 'amber', sub: '${bi('કરપાત્ર', 'Taxable')} ${inrC(g.inBase)}'),
      MetricTile(label: net >= 0 ? bi('ભરવાનો અંદાજ', 'Estimated to pay') : bi('ક્રેડિટ (અંદાજ)', 'Estimated credit'), value: inrC(net.abs()), icon: 'rupee', tone: net >= 0 ? 'rose' : 'green', sub: 'Output − Input'),
    ], pcCols: 3));
    out.add(const SizedBox(height: 10));
    if (g.noLines > 0) {
      out.add(noteBox('warn', 'amber', bi('${g.noLines} વાઉચરમાં ટેક્સની વિગત નથી (જૂનો સિંક). Tally Agent ફરી સિંક કરશે ત્યારે ભરાશે.', '${g.noLines} vouchers have no tax lines (older sync). They fill in when the Tally Agent syncs again.')));
    } else if (g.outTax + g.inTax < 0.5) {
      out.add(noteBox('info', 'blue', bi('આ સમયમાં કોઈ GST ખાતું મળ્યું નથી. ખાતાના નામમાં "GST" હોવું જોઈએ (જેમ કે Output CGST).', 'No GST ledger found in this period. The ledger name must contain "GST" (like Output CGST).')));
    }
    out.add(caption(bi('મહિના મુજબ', 'By month')));
    for (final _GstMonth m in g.months) {
      final double n = m.outTax - m.inTax;
      out.add(lineItem(
        icon: 'month',
        tone: n >= 0 ? 'rose' : 'green',
        title: _ymLabel(m.ym),
        sub: 'Output ${_rs(m.outTax)} · Input ${_rs(m.inTax)}\n${m.n} ${bi('વાઉચર', 'vouchers')}',
        trailing: _sgn(n),
        trailingSub: n >= 0 ? bi('ભરવાના', 'to pay') : bi('ક્રેડિટ', 'credit'),
      ));
    }
    if (g.outBy.isNotEmpty) {
      out.add(const SizedBox(height: 8));
      out.add(caption(bi('Output - ટેક્સ ખાતા મુજબ', 'Output - by tax ledger')));
      out.add(Panel(child: Column(children: <Widget>[for (final MapEntry<String, double> e in _sortedTax(g.outBy)) InfoRow(e.key, _rs(e.value))])));
    }
    if (g.inBy.isNotEmpty) {
      out.add(const SizedBox(height: 8));
      out.add(caption(bi('Input - ટેક્સ ખાતા મુજબ', 'Input - by tax ledger')));
      out.add(Panel(child: Column(children: <Widget>[for (final MapEntry<String, double> e in _sortedTax(g.inBy)) InfoRow(e.key, _rs(e.value))])));
    }
    out.add(const SizedBox(height: 10));
    out.add(Btn(
      bi('CSV કૉપિ', 'Copy CSV'),
      icon: 'copy',
      kind: BtnKind.tonal,
      dense: true,
      onTap: () => copyText(
        csvOf(
          <String>['month', 'output_tax', 'input_tax', 'net', 'taxable_sales', 'taxable_purchase', 'vouchers'],
          <List<Object?>>[
            for (final _GstMonth m in g.months) <Object?>[m.ym, m.outTax, m.inTax, m.outTax - m.inTax, m.outBase, m.inBase, m.n],
          ],
        ),
        msg: bi('CSV કૉપિ થયું', 'CSV copied'),
      ),
    ));
    out.add(const SizedBox(height: 8));
    out.add(Text(
      bi('Tally ના વાઉચરની ટેક્સ લાઇન પરથી અંદાજ છે (નામમાં GST હોય તે ખાતા). રિટર્ન ભરતા પહેલાં CA પાસે તપાસાવો.', 'An estimate from the tax lines of the Tally vouchers (ledgers with GST in the name). Have your CA check before filing a return.'),
      style: ts(12, c: Pal.faint),
    ));
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: out);
  }
}

List<MapEntry<String, double>> _sortedTax(Map<String, double> m) {
  final List<MapEntry<String, double>> l = m.entries.toList();
  l.sort((MapEntry<String, double> a, MapEntry<String, double> b) => b.value.abs().compareTo(a.value.abs()));
  return l;
}

// ============================================================== checks
class _CheckTab extends StatelessWidget {
  final String firm;
  final String from;
  final String to;
  const _CheckTab({required this.firm, required this.from, required this.to});

  Widget _section(String title, String why, List<Widget> rows, String none) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        const SizedBox(height: 8),
        caption(title),
        noteBox('info', 'blue', why),
        if (rows.isEmpty) noteBox('check', 'green', none),
        ...rows,
      ],
    );
  }

  Widget _chkTile(BuildContext context, _ChkRow r) {
    return lineItem(
      icon: 'warn',
      tone: 'amber',
      title: r.party,
      sub: '${dmy(DateTime.tryParse(r.date) ?? DateTime.now())} · ${_firmShort(r.firm)}${r.vs.length > 1 ? ' · ${r.vs.length} ${bi('વાઉચર', 'vouchers')}' : ''}',
      trailing: _rs(r.amount),
      onTap: r.vs.isEmpty ? null : () => openTallyVoucher(context, r.vs.first),
    );
  }

  @override
  Widget build(BuildContext context) {
    final List<_ChkRow> big = _cashGroups(true, 200000, true, firm, from, to);
    final List<_ChkRow> pay = _cashGroups(false, 10000, false, firm, from, to);
    final List<_YearRow> yr = <_YearRow>[
      for (final _YearRow y in _yearPurchases(firm))
        if (y.total >= 4000000) y,
    ];
    final List<List<TVoucher>> dups = _dupGroups(firm);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        noteBox('warn', 'amber', bi('આ ફક્ત ધ્યાન દોરતી યાદી છે, કાયદાકીય સલાહ નથી. નિયમો અને છૂટ બદલાતી રહે છે - જરૂર પડે CA ને પૂછો.', 'This is a list to draw your attention, not legal advice. Rules and exemptions change - ask your CA when in doubt.')),
        _section(
          bi('રોકડ ₹2,00,000 કે વધુ મળ્યા', 'Cash of Rs 2,00,000 or more received'),
          bi('એક પાર્ટી પાસેથી એક દિવસમાં રોકડ ₹2 લાખ કે વધુ લેવા પર કલમ 269ST લાગી શકે. આ પસંદ કરેલા સમયના Receipt વાઉચર છે.', 'Section 269ST can apply to Rs 2 lakh or more taken in cash from one party in a day. These are the Receipt vouchers of the chosen period.'),
          <Widget>[for (final _ChkRow r in big.take(30)) _chkTile(context, r)],
          bi('આ સમયમાં કોઈ નથી', 'None in this period'),
        ),
        _section(
          bi('રોકડ ચૂકવણી ₹10,000 થી વધુ', 'Cash payments above Rs 10,000'),
          bi('એક પાર્ટીને એક દિવસમાં ₹10,000 થી વધુ રોકડ આપો તો ખર્ચ બાદ ન મળવાનું જોખમ (કલમ 40A(3)). ખેડૂતને ખેતપેદાશની ચૂકવણીમાં છૂટ હોઈ શકે.', 'Cash above Rs 10,000 to one party in a day can risk the expense being disallowed (Section 40A(3)). Payments to farmers for farm produce may be exempt.'),
          <Widget>[for (final _ChkRow r in pay.take(30)) _chkTile(context, r)],
          bi('આ સમયમાં કોઈ નથી', 'None in this period'),
        ),
        _section(
          bi('આ વર્ષની ખરીદી ₹40 લાખ થી વધુ (એક પાર્ટી)', 'This year\'s purchases above Rs 40 lakh (one party)'),
          bi('એક વેચનાર પાસેથી વર્ષમાં ₹50 લાખથી વધુ ખરીદી પર TDS (કલમ 194Q) લાગી શકે - તમારા ટર્નઓવર પર આધાર. ₹40 લાખ થી ચેતવણી.', 'TDS (Section 194Q) can apply on purchases above Rs 50 lakh a year from one seller, depending on your turnover. The warning starts at Rs 40 lakh.'),
          <Widget>[
            for (final _YearRow y in yr.take(20))
              lineItem(
                icon: 'bag',
                tone: y.total >= 5000000 ? 'rose' : 'amber',
                title: y.party,
                sub: '${_firmShort(y.firm)} · ${y.total >= 5000000 ? bi('₹50 લાખ ઓળંગાયા', 'Rs 50 lakh crossed') : '${bi('₹50 લાખ માટે બાકી', 'Left to Rs 50 lakh')} ${_rs(5000000 - y.total)}'}',
                trailing: _rs(y.total),
                onTap: () => openTallyParty(context, y.party),
              ),
          ],
          bi('કોઈ પાર્ટી ₹40 લાખ સુધી પહોંચી નથી', 'No party has reached Rs 40 lakh'),
        ),
        _section(
          bi('સરખા વાઉચર', 'Look-alike vouchers'),
          bi('એક જ પાર્ટી, એક જ દિવસ, એક જ રકમ અને એક જ પ્રકારના એકથી વધુ વાઉચર. ભૂલથી બે વાર ચડ્યું હોય તો તપાસો (ઘણી વાર બરાબર પણ હોય).', 'More than one voucher of the same kind for the same party, day and amount. Check if one was entered twice by mistake (often it is fine).'),
          <Widget>[
            for (final List<TVoucher> d in dups.take(20))
              lineItem(
                icon: 'copy',
                tone: 'blue',
                title: d.first.title,
                sub: '${d.length} × ${d.first.type} · ${dmy(d.first.dt)} · ${_firmShort(d.first.firm)}',
                trailing: _rs(d.first.amount),
                onTap: () => openTallyVoucher(context, d.first),
              ),
          ],
          bi('કોઈ સરખા વાઉચર નથી', 'No look-alike vouchers'),
        ),
      ],
    );
  }
}
