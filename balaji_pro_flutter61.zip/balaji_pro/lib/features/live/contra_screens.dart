import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/errlog.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/contra.dart';
import '../../data/insights.dart';
import '../../data/live_models.dart';
import '../../data/money.dart';
import '../../data/statements.dart' show bankFig;
import '../../data/vouchers.dart';
import '../../widgets/accept.dart';
import '../../widgets/common.dart';
import '../../widgets/dayfield.dart';
import '../../widgets/keys.dart';
import 'field.dart';
import 'voucher_screens.dart' show printOut;

// ======================================================================
// Contra voucher (cash <-> bank), like F4 of TallyPrime
//   Cash deposited into the bank  : Bank A/c Dr  /  Cash Cr
//   Cash withdrawn from the bank  : Cash Dr      /  Bank A/c Cr
// ======================================================================

/// [edit] alters a voucher (Alt+D deletes it, Ctrl+P prints it); [copy] starts a new one from an old one.
Future<void> openContraForm(BuildContext context, {ContraItem? edit, ContraItem? copy, bool? deposit}) {
  return openPanel(
    context,
    title: edit == null ? bi('કોન્ટ્રા વાઉચર', 'Contra voucher') : bi('વાઉચર સુધારો (Alter)', 'Voucher alteration'),
    sub: edit == null ? bi('રોકડ ↔ બેંક', 'Cash <-> Bank') : dmy(edit.date),
    width: 460,
    page: true,
    child: ContraForm(edit: edit, copy: copy, deposit: deposit),
  );
}

class ContraForm extends StatefulWidget {
  final ContraItem? edit;
  final ContraItem? copy;
  final bool? deposit;
  const ContraForm({super.key, this.edit, this.copy, this.deposit});

  @override
  State<ContraForm> createState() => _ContraFormState();
}

class _ContraFormState extends State<ContraForm> {
  late final VoidCallback _accept = () {
    _save();
  };
  late final VoidCallback _del = () {
    _delete();
  };
  late final VoidCallback _prn = () {
    _print();
  };

  final TextEditingController _amt = TextEditingController();
  final TextEditingController _note = TextEditingController();
  final TextEditingController _ref = TextEditingController();
  int _dir = 0; // 0 cash deposited into the bank, 1 cash withdrawn from the bank
  DateTime _day = dateOnly(DateTime.now());
  bool _busy = false;
  String _err = '';

  @override
  void initState() {
    super.initState();
    AcceptHub.push(_accept);
    final ContraItem? src = widget.edit ?? widget.copy;
    if (src != null) {
      _dir = src.dep ? 0 : 1;
      _amt.text = plainNum(src.amt);
      _note.text = src.note;
      if (widget.edit != null) {
        _day = src.date;
        _ref.text = src.ref;
      }
    } else if (widget.deposit != null) {
      _dir = widget.deposit! ? 0 : 1;
    }
    if (widget.edit != null) {
      deleteHub.push(_del);
      printHub.push(_prn);
    }
  }

  @override
  void dispose() {
    _amt.dispose();
    _note.dispose();
    _ref.dispose();
    AcceptHub.pop(_accept);
    deleteHub.pop(_del);
    printHub.pop(_prn);
    super.dispose();
  }

  Future<void> _delete() async {
    final ContraItem? e = widget.edit;
    if (e == null || _busy) return;
    final bool go = await confirmBox(context, title: bi('આ વાઉચર કાઢી નાખવું?', 'Delete this voucher?'), text: bi('આ નોંધ કાયમ માટે કાઢી નંખાશે.', 'This entry will be removed for good.'), yes: bi('હા, કાઢો', 'Yes, delete'), no: bi('ના', 'No'));
    if (!go || !mounted) return;
    await removeContra(e.id);
    app.toast(bi('વાઉચર કાઢ્યું', 'Voucher deleted'));
    if (mounted) Navigator.of(context).pop();
  }

  Future<void> _print() async {
    final ContraItem? e = widget.edit;
    if (e == null) return;
    final Vch? v = voucherById('contra', e.id);
    if (v == null) return;
    await printOut(voucherHtml(v), 'voucher-${e.id}');
  }

  Future<void> _save() async {
    final double amt = dbl(_amt.text.replaceAll(',', ''));
    if (amt <= 0) {
      setState(() => _err = bi('સાચી રકમ લખો', 'Enter a valid amount'));
      return;
    }
    if (_busy) return;
    setState(() {
      _busy = true;
      _err = '';
    });
    final bool dep = _dir == 0;
    final ContraItem? ed = widget.edit;
    if (ed != null) {
      final bool saved = await ErrLog.attempt('Save', () => updateContra(ed.id, dep: dep, amt: amt, date: _day, ref: _ref.text, note: _note.text));
      if (!saved) {
        if (mounted) setState(() => _busy = false);
        return;
      }
      app.toast('${bi('વાઉચર સુધાર્યું', 'Voucher altered')} · ${inr(amt)}');
      if (mounted) Navigator.of(context).pop();
      return;
    }
    final bool added = await ErrLog.attempt('Save', () => addContra(dep: dep, amt: amt, date: _day, ref: _ref.text, note: _note.text));
    if (!added) {
      if (mounted) setState(() => _busy = false);
      return;
    }
    app.toast('${dep ? bi('બેંકમાં જમા', 'Deposited') : bi('બેંકમાંથી ઉપાડ', 'Withdrawn')} · ${inr(amt)}');
    if (!mounted) return;
    if (Pal.tally && app.stagePc && widget.copy == null) {
      // like TallyPrime: the voucher stays open, blank, for the next entry (Esc closes it)
      setState(() {
        _busy = false;
        _amt.clear();
        _note.clear();
        _ref.clear();
      });
      KeyScopeState.refocusFrom(context);
      return;
    }
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final ContraItem? ed = widget.edit;
    final VType vt = vTypeOf('CON');
    final bool dep = _dir == 0;
    final double cash = cashOpening(_day);
    final double bank = bankFig(Period(DateTime(2000), _day)).closing;
    final double amt = dbl(_amt.text.replaceAll(',', ''));
    final double avail = dep ? cash : bank;
    final bool short = amt > 0 && amt > avail + 0.5 && ed == null;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        VoucherHead(
          type: vt.name,
          no: ed != null ? (ed.no > 0 ? '${vt.letter}-${ed.no}' : '') : '${vt.letter}-${nextContraNo()}',
          date: _day,
          sub: ed == null ? bi('નવું વાઉચર', 'Creation') : bi('સુધારો (Alteration)', 'Alteration'),
        ),
        Seg(
          labels: <String>[bi('રોકડ બેંકમાં ભરી', 'Cash to bank'), bi('બેંકમાંથી રોકડ ઉપાડી', 'Cash from bank')],
          index: _dir,
          onChanged: (int i) => setState(() => _dir = i),
        ),
        const SizedBox(height: 10),
        Surface(
          padding: const EdgeInsets.all(12),
          child: Column(
            children: <Widget>[
              InfoRow(bi('ઉધાર (Dr)', 'Account (Dr)'), dep ? contraBankName() : contraCashName(), bold: true),
              InfoRow(bi('જમા (Cr)', 'Account (Cr)'), dep ? contraCashName() : contraBankName(), bold: true),
              InfoRow(dep ? bi('હાથમાં રોકડ', 'Cash in hand') : bi('બેંકમાં બાકી', 'Bank balance'), grp(avail, dec: 2)),
            ],
          ),
        ),
        const SizedBox(height: 12),
        FieldX(label: '${bi('રકમ', 'Amount')} *', controller: _amt, big: true, prefix: '₹', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String _) => setState(() {})),
        if (short) Padding(padding: const EdgeInsets.only(top: 6), child: Text(dep ? bi('રોજમેળમાં આટલી રોકડ નથી - શરૂઆતની રોકડ તપાસો', 'The cash book does not have this much cash - check the opening cash') : bi('બેંક બુકમાં આટલું બાકી નથી - બેંકની એન્ટ્રી તપાસો', 'The bank book does not have this much balance - check the bank entries'), style: ts(12.5, w: FontWeight.w700, c: Pal.warn))),
        const SizedBox(height: 12),
        FieldX(label: bi('ચેક / સ્લિપ નંબર', 'Cheque / slip no.'), controller: _ref),
        const SizedBox(height: 12),
        DayField(label: bi('તારીખ', 'Date'), value: _day, last: dateOnly(DateTime.now()), onChanged: (DateTime d) => setState(() => _day = d)),
        const SizedBox(height: 12),
        FieldX(label: bi('નોંધ / Narration', 'Narration'), controller: _note),
        const SizedBox(height: 14),
        if (_err.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(_err, style: ts(13, w: FontWeight.w700, c: Pal.bad))),
        _busy
            ? SizedBox(height: 52, child: Center(child: SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 2.6, color: Pal.brand))))
            : Btn(ed == null ? bi('સેવ કરો', 'Save') : bi('સુધારો સેવ કરો', 'Save alteration'), icon: 'check', expand: true, onTap: _save),
        if (ed != null) ...<Widget>[
          const SizedBox(height: 8),
          Row(
            children: <Widget>[
              tExp(child: Btn(bi('પ્રિન્ટ (Ctrl+P)', 'Print (Ctrl+P)'), icon: 'print', kind: BtnKind.tonal, dense: true, tabStop: false, onTap: _print)),
              const SizedBox(width: 8),
              tExp(child: Btn(bi('કાઢો (Alt+D)', 'Delete (Alt+D)'), icon: 'trash', kind: BtnKind.danger, dense: true, tabStop: false, onTap: _delete)),
            ],
          ),
        ],
      ],
    );
  }
}
