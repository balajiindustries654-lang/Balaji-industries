import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/app_state.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/kanta_khata.dart';
import '../../data/kanta_people.dart';
import '../../data/kanta_remote.dart';
import '../../data/kanta_slip.dart';
import '../../data/kanta_usb.dart';
import '../../data/live_store.dart';
import '../../widgets/common.dart';
import '../../widgets/launch.dart' show whatsappText;
import '../../widgets/page.dart';
import '../kanta/khata_view.dart' show bakiLine, showBakiPopup;
import 'field.dart';
import 'kit2.dart';
import 'ui.dart';

// ======================================================================
// Remote weighing: the owner takes the weight of the vehicle on the weighbridge from his PHONE.
// The laptop at the weighbridge (Balaji Kanta) does the weighing - this screen only asks it to (see data/kanta_remote.dart).
// ======================================================================

/// The words for an answer of the laptop (also used by tests of the screen).
String remoteErrText(String code, {double? kg, double? seen}) {
  if (code.startsWith('perm')) return bi('આ લૉગિનને કાંટા રિમોટની પરવાનગી નથી (admin / waybridge જોઈએ).', 'This login may not use remote weighing (needs admin / waybridge).');
  if (code.startsWith('error')) return code;
  switch (code) {
    case 'remote off':
      return bi('કાંટા લેપટોપ પર "ફોનથી વજન" બંધ છે.', 'The "weighing from phone" switch is OFF on the weighbridge laptop.');
    case 'stale':
      return bi('હુકમ જૂનો થઈ ગયો (લેપટોપ થોડી વાર ઑફલાઇન હતું). ફરી દબાવો.', 'The request got old (the laptop was offline for a while). Tap again.');
    case 'vehicle':
      return bi('પહેલાં ગાડી નંબર લખો.', 'Write the vehicle number first.');
    case 'tare':
      return bi('ટેર (ખાલી ગાડીનું વજન) KG માં લખો.', 'Write the tare (empty weight) in KG.');
    case 'tare high':
      return bi('ટેર કાંટા પરના વજન કરતાં ઓછું હોવું જોઈએ.', 'The tare must be less than the weight on the scale.');
    case 'no steady weight':
      return bi('ગાડી કાંટા પર સ્થિર નથી (કે વજન ઘણું ઓછું છે). થોડી વાર ઊભી રાખી ફરી દબાવો.', 'The vehicle is not standing still on the platform (or the weight is too low). Let it stand a moment and tap again.');
    case 'changed':
      return bi('વજન બદલાઈ ગયું (તમે ${seen == null ? '-' : grp(seen, dec: 0)} KG જોયું, હવે ${kg == null ? '-' : grp(kg, dec: 0)} KG). ફરી જુઓ અને દબાવો.', 'The weight changed (you saw ${seen == null ? '-' : grp(seen, dec: 0)} KG, now ${kg == null ? '-' : grp(kg, dec: 0)} KG). Look again and tap.');
    case 'same weight':
      return bi('આ વજન પહેલા વજન જેટલું જ છે. ગાડી ખાલી (કે ભરેલી) થઈને ફરી આવે ત્યારે દબાવો.', 'This weight is the same as the first one. Tap when the vehicle has come back empty (or loaded).');
    case 'not inside':
      return bi('આ ગાડી અંદરની યાદીમાં નથી (લેપટોપ પર કોઈએ કાઢી હશે).', 'This vehicle is not in the inside list (someone may have removed it on the laptop).');
    case 'cannot undo':
      return bi('આ સ્લિપ હવે પાછી લઈ શકાતી નથી (લેપટોપ ફરી ખોલાયું હશે). લેપટોપ પર કરો.', 'This slip can no longer be taken back from here (the laptop app was reopened). Do it on the laptop.');
    case 'timeout':
      return bi('લેપટોપ તરફથી જવાબ ન આવ્યો. લેપટોપ ચાલુ અને નેટ પર છે? થોડી વાર પછી નીચેની યાદીમાં જુઓ કે થયું કે નહીં - બમણું ન દબાવશો.', 'No answer from the laptop. Is it on and online? In a moment look in the lists below whether it was done - do not tap twice.');
    case 'missing':
      return bi('Supabase માં રિમોટનું SQL હજી ચલાવ્યું નથી (supabase-kanta-remote.sql).', 'The SQL for remote weighing has not been run in Supabase yet (supabase-kanta-remote.sql).');
    case 'offline':
      return bi('આ ફોનમાં ઇન્ટરનેટ નથી.', 'This phone has no internet.');
  }
  return code;
}

class KantaRemoteScreen extends StatefulWidget {
  const KantaRemoteScreen({super.key});

  @override
  State<KantaRemoteScreen> createState() => _KantaRemoteState();
}

class _KantaRemoteState extends State<KantaRemoteScreen> {
  final TextEditingController _veh = TextEditingController();
  final TextEditingController _party = TextEditingController();
  final TextEditingController _charges = TextEditingController();
  final TextEditingController _tare = TextEditingController();
  bool _out = false;
  bool _paid = false;
  bool _busy = false;
  bool _confirm = true;
  String _msg = '';
  bool _msgOk = true;
  Timer? _clock;

  @override
  void initState() {
    super.initState();
    remoteClient.addListener(_tick);
    remoteClient.attach();
    kantaKhata.addListener(_tick);
    unawaited(kantaKhata.load().then((_) => kantaKhata.sync()));
    // the "x seconds ago" text moves by itself
    _clock = Timer.periodic(const Duration(seconds: 1), (Timer _) => _tick());
    SharedPreferences.getInstance().then((SharedPreferences p) {
      if (mounted) setState(() => _confirm = p.getBool('kr_confirm') ?? true);
    }).catchError((Object _) {});
  }

  @override
  void dispose() {
    _clock?.cancel();
    remoteClient.removeListener(_tick);
    remoteClient.detach();
    kantaKhata.removeListener(_tick);
    _veh.dispose();
    _party.dispose();
    _charges.dispose();
    _tare.dispose();
    super.dispose();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  String get _by {
    try {
      return live.me?.name ?? '';
    } catch (_) {
      return '';
    }
  }

  Future<void> _setConfirm(bool v) async {
    setState(() => _confirm = v);
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setBool('kr_confirm', v);
    } catch (_) {}
  }

  void _show(String text, bool ok) {
    if (!mounted) return;
    setState(() {
      _msg = text;
      _msgOk = ok;
    });
  }

  /// Sends one command and shows what came of it.
  Future<RemoteResult> _run(RemoteCmd c, String okText, {double? seen}) async {
    setState(() {
      _busy = true;
      _msg = bi('લેપટોપને હુકમ મોકલ્યો… જવાબની રાહ', 'Request sent to the laptop… waiting for the answer');
      _msgOk = true;
    });
    final RemoteResult r = await remoteClient.send(c);
    if (!mounted) return r;
    setState(() => _busy = false);
    if (r.ok) {
      _show('$okText${r.kg == null ? '' : ' · ${grp(r.kg!, dec: 0)} KG'}${r.rst.isEmpty ? '' : ' · ${r.rst}'}', true);
      app.toast(okText);
    } else {
      final String t = remoteErrText(r.code, kg: r.kg, seen: seen);
      _show(t, false);
      app.toast(t);
    }
    return r;
  }

  Future<bool> _sure(String vehicle, double kg) {
    if (!_confirm) return Future<bool>.value(true);
    return confirmBox(
      context,
      title: bi('વજન લઈએ?', 'Take the weight?'),
      text: '$vehicle\n${bi('કાંટા પર', 'On the platform')}: ${grp(kg, dec: 0)} KG\n\n${bi('કેમેરામાં જોયું કે કાંટા પર ફક્ત આ જ ગાડી છે, કોઈ માણસ / બીજી ગાડી નથી?', 'Did you check on the camera that only this vehicle is on the platform - no person, no other vehicle?')}',
      yes: bi('હા, વજન લો', 'Yes, take it'),
      no: bi('ના', 'No'),
    );
  }

  Future<void> _first() async {
    final RemoteLive? row = remoteClient.row;
    final String v = _veh.text.trim().toUpperCase();
    if (row == null || row.kg == null) return;
    if (v.isEmpty) {
      _show(remoteErrText('vehicle'), false);
      return;
    }
    final double kg = row.kg!;
    if (!await _sure(v, kg)) return;
    final double ch = double.tryParse(_charges.text.replaceAll(',', '').trim()) ?? 0;
    final RemoteResult r = await _run(
      RemoteCmd(kind: 'first', vehicle: v, target: ch > 0 && _paid ? 'paid' : '', outside: _out, party: _party.text.trim(), charges: ch, seenKg: kg, byName: _by, createdAt: DateTime.now()),
      '${bi('પહેલું વજન લીધું', 'First weight taken')}: $v',
      seen: kg,
    );
    if (r.ok && mounted) {
      _veh.clear();
      _party.clear();
      _charges.clear();
      _paid = false;
    }
  }

  /// Direct weighing: the tare is written here, the weight on the platform is the gross, the entry is made at once.
  Future<void> _direct() async {
    final RemoteLive? row = remoteClient.row;
    final String v = _veh.text.trim().toUpperCase();
    if (row == null || row.kg == null) return;
    if (v.isEmpty) {
      _show(remoteErrText('vehicle'), false);
      return;
    }
    final double tare = double.tryParse(_tare.text.replaceAll(',', '').trim()) ?? 0;
    if (tare <= 0) {
      _show(remoteErrText('tare'), false);
      return;
    }
    final double kg = row.kg!;
    if (tare >= kg) {
      _show(remoteErrText('tare high'), false);
      return;
    }
    if (!await _sure(v, kg)) return;
    final double ch = double.tryParse(_charges.text.replaceAll(',', '').trim()) ?? 0;
    final RemoteResult r = await _run(
      RemoteCmd(kind: 'first', vehicle: v, target: 'direct:${tare.round()}${ch > 0 && _paid ? ':paid' : ''}', outside: _out, party: _party.text.trim(), charges: ch, seenKg: kg, byName: _by, createdAt: DateTime.now()),
      '${bi('સીધું વજન લીધું - એન્ટ્રી બની', 'Direct weighing done - entry made')}: $v',
      seen: kg,
    );
    if (r.ok && mounted) {
      _veh.clear();
      _party.clear();
      _charges.clear();
      _tare.clear();
    }
  }

  /// The khata account of a vehicle that is inside (null when it owes nothing).
  KhataAcc? _acc(RemoteInside v) {
    final KhataAcc? a = kantaKhata.find(name: v.party, mobile: v.mobile, vehicle: v.vehicle);
    return a == null || a.baki < 0.5 ? null : a;
  }

  Future<void> _second(RemoteInside v) async {
    final RemoteLive? row = remoteClient.row;
    if (row == null || row.kg == null) return;
    final double kg = row.kg!;
    // the name has baki: a pop-up first
    final KhataAcc? owed = _acc(v);
    if (owed != null && mounted) await showBakiPopup(context, owed);
    if (!mounted) return;
    if (!await _sure(v.vehicle, kg)) return;
    await _run(
      RemoteCmd(kind: 'second', vehicle: v.vehicle, target: v.id, seenKg: kg, byName: _by, createdAt: DateTime.now()),
      '${bi('બીજું વજન લીધું - એન્ટ્રી બની', 'Second weight taken - entry made')}: ${v.vehicle}',
      seen: kg,
    );
  }

  Future<void> _drop(RemoteInside v) async {
    final bool yes = await confirmBox(context, title: bi('ગાડી કાઢી નાખવી?', 'Remove the vehicle?'), text: '${v.vehicle} · ${grp(v.kg, dec: 0)} KG\n${bi('અંદરની યાદીમાંથી નીકળશે (પહેલું વજન રદ).', 'It leaves the inside list (the first weight is dropped).')}', yes: bi('હા, કાઢો', 'Yes, remove'), no: bi('ના', 'No'));
    if (!yes) return;
    await _run(RemoteCmd(kind: 'drop', vehicle: v.vehicle, target: v.id, byName: _by, createdAt: DateTime.now()), '${bi('કાઢી નાખ્યું', 'Removed')}: ${v.vehicle}');
  }

  Future<void> _undo(RemoteDone d) async {
    final bool yes = await confirmBox(context, title: bi('સ્લિપ પાછી લેવી?', 'Take the slip back?'), text: '${d.outside ? bi('સ્લિપ', 'Slip') : 'RST'} ${d.rst} · ${d.vehicle} · ${grp(d.net, dec: 0)} KG\n${d.outside ? bi('લેપટોપની રદ નોંધ બનશે.', 'It is marked cancelled on the laptop.') : bi('સર્વરમાંથી એન્ટ્રી કાઢી નખાશે.', 'The entry is deleted from the server.')}', yes: bi('હા, પાછી લો', 'Yes, take back'), no: bi('ના', 'No'));
    if (!yes) return;
    await _run(RemoteCmd(kind: 'undo', vehicle: d.vehicle, target: d.rst, byName: _by, createdAt: DateTime.now()), '${bi('સ્લિપ પાછી લીધી', 'Slip taken back')}: ${d.rst}');
  }

  // ------------------------------------------------------------------ pieces
  Widget _dot(bool on) => Container(width: 10, height: 10, decoration: BoxDecoration(color: on ? Pal.ok : Pal.faint, shape: BoxShape.circle));

  /// What is wrong (the first thing), or '' when weighing can start.
  Widget _status() {
    final KantaRemoteClient c = remoteClient;
    final RemoteLive? r = c.row;
    if (c.errKind == 'missing') return noteBox('err', 'rose', remoteErrText('missing'));
    if (c.errKind == 'perm') return noteBox('err', 'rose', remoteErrText('perm'));
    if (c.errKind == 'offline') return noteBox('warn', 'amber', remoteErrText('offline'));
    if (c.errKind == 'other') return noteBox('warn', 'amber', c.error);
    if (r == null) {
      return noteBox('warn', 'amber', bi('કાંટા લેપટોપે હજી કંઈ મોકલ્યું નથી. લેપટોપ પર Balaji Kanta ચાલુ કરો (ઑપરેટર લૉગિનથી).', 'The weighbridge laptop has not sent anything yet. Start Balaji Kanta on it (operator login).'));
    }
    if (!c.online) {
      return noteBox('warn', 'amber', '${bi('કાંટા લેપટોપ ઑફલાઇન છે', 'The weighbridge laptop is offline')}${r.updatedAt == null ? '' : ' (${bi('છેલ્લું', 'last seen')} ${hm(r.updatedAt!)})'}. ${bi('લેપટોપ ચાલુ અને ઇન્ટરનેટ પર હોવું જોઈએ.', 'It must be on and online.')}');
    }
    if (!r.remoteOn) {
      return noteBox('warn', 'amber', bi('કાંટા લેપટોપ પર "ફોનથી વજન" સ્વિચ બંધ છે. કાંટા પર Balaji Kanta માં તે એક વાર ચાલુ કરો (પછી ચાલુ જ રહેશે).', 'The "weighing from phone" switch is OFF on the weighbridge laptop. Switch it ON once in Balaji Kanta there (it then stays on).'));
    }
    if (!r.connected) {
      return noteBox('warn', 'amber', bi('લેપટોપ કાંટાના ટર્મિનલ સાથે જોડાયેલ નથી (કેબલ / COM પોર્ટ તપાસો).', 'The laptop is not connected to the weighbridge terminal (check the cable / COM port).'));
    }
    return noteBox('check', 'green', '${bi('કાંટા લેપટોપ ચાલુ છે', 'The weighbridge laptop is on line')}${r.operatorName.isEmpty ? '' : ' · ${r.operatorName}'}');
  }

  Widget _weightCard() {
    final RemoteLive? r = remoteClient.row;
    final bool ok = remoteClient.online && r != null && r.connected && r.kg != null;
    final bool steady = ok && r.steady;
    return Surface(
      shadow: false,
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Row(
            children: <Widget>[
              _dot(ok),
              const SizedBox(width: 8),
              Expanded(child: Text(bi('કાંટા પર હમણાંનું વજન', 'Weight on the platform now'), style: ts(13, w: FontWeight.w700, c: Pal.muted))),
              if (remoteClient.fetchedAt != null) Text(hm(remoteClient.fetchedAt!), style: ts(11.5, c: Pal.faint, tab: true)),
            ],
          ),
          const SizedBox(height: 4),
          Text(ok ? '${grp(r.kg!, dec: 0)} KG' : '— KG', textAlign: TextAlign.center, style: ts(40, w: FontWeight.w800, c: steady ? Pal.ok : (ok ? Pal.warn : Pal.faint), tab: true)),
          Text(
            !ok ? bi('વજન મળતું નથી', 'No weight') : (steady ? (r.remoteOn ? (r.stable ? bi('સ્થિર ✓ - વજન લઈ શકાય', 'Standing still ✓ - the weight can be taken') : bi('વજન બદલાય છે - છતાં લઈ શકાય', 'The weight is changing - it can still be taken')) : bi('વજન આવે છે (ફોનથી વજન બંધ છે)', 'Weight is coming (weighing from phone is OFF)')) : bi('કાંટા પર વજન નથી - રાહ જુઓ', 'Nothing on the scale - wait')),
            textAlign: TextAlign.center,
            style: ts(12.5, w: FontWeight.w700, c: steady ? Pal.ok : Pal.warn),
          ),
        ],
      ),
    );
  }

  List<String> _options() {
    final List<String> out = <String>[];
    final Set<String> seen = <String>{};
    final RemoteLive? r = remoteClient.row;
    String k(String s) => s.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');
    void add(String v) {
      final String t = v.trim().toUpperCase();
      if (t.isEmpty) return;
      if (r != null && r.inside.any((RemoteInside x) => k(x.vehicle) == k(t))) return;
      if (seen.add(k(t))) out.add(t);
    }
    if (_out) {
      if (r != null) {
        for (final RemoteDone d in r.recent) {
          if (d.outside) add(d.vehicle);
        }
      }
    } else {
      try {
        for (final String v in kantaUsb.waitingVehicles) {
          add(v);
        }
        for (final kk in live.kantas.take(80)) {
          add(kk.vehicle);
        }
      } catch (_) {}
    }
    final String q = k(_veh.text);
    return (q.isEmpty ? out : out.where((String v) => k(v).contains(q) && k(v) != q).toList()).take(8).toList();
  }

  Widget _station() {
    final RemoteLive? r = remoteClient.row;
    final bool can = remoteClient.canWeigh && !_busy;
    final List<String> opts = _options();
    return Surface(
      shadow: false,
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text(bi('ગાડી તોલો (ફોનથી)', 'Weigh a vehicle (from the phone)'), style: ts(15, w: FontWeight.w800)),
          const SizedBox(height: 8),
          ChipRow(labels: <String>[bi('મિલની ગાડી', 'Mill vehicle'), bi('બહારની ગાડી (રસ્તા પરની)', 'Road vehicle (outside)')], index: _out ? 1 : 0, onChanged: (int i) => setState(() => _out = i == 1)),
          const SizedBox(height: 6),
          Text(
            _out ? bi('બહારની ગાડી: સ્લિપ ફક્ત કાંટા લેપટોપમાં સેવ થાય છે - એપ / સર્વરમાં જતી નથી.', 'Road vehicle: the slip is saved on the weighbridge laptop only - it does not go to the app / server.') : bi('મિલની ગાડી: એન્ટ્રી તરત એપ / સર્વર પર (RST આપોઆપ) અને લેપટોપમાં કૉપી.', 'Mill vehicle: the entry goes to the app / server at once (RST automatic) and a copy stays on the laptop.'),
            style: ts(12, w: FontWeight.w700, c: _out ? Pal.warn : Pal.ok),
          ),
          const SizedBox(height: 12),
          FieldX(label: bi('ગાડી નંબર', 'Vehicle number'), controller: _veh, hint: 'GJ03AB1234', stacked: true, onChanged: (String _) => setState(() {}), onSubmitted: (String _) => can ? _first() : null),
          const SizedBox(height: 8),
          SuggestField(label: bi('પાર્ટી / નામ (ઇચ્છા મુજબ)', 'Party / name (optional)'), controller: _party, options: KantaPeople.names(), hints: KantaPeople.nameHints(), onChanged: (String _) => setState(() {})),
          if (bakiLine(kantaKhata.find(name: _party.text, vehicle: _veh.text)) != null)
            Padding(padding: const EdgeInsets.only(top: 6), child: Text(bakiLine(kantaKhata.find(name: _party.text, vehicle: _veh.text))!, style: ts(13, w: FontWeight.w800, c: Pal.bad))),
          const SizedBox(height: 8),
          FieldX(label: bi('ચાર્જ ₹ (ઇચ્છા મુજબ)', 'Charges ₹ (optional)'), controller: _charges, stacked: true, keyboard: TextInputType.number, onChanged: (String _) => setState(() {})),
          if ((double.tryParse(_charges.text.replaceAll(',', '').trim()) ?? 0) > 0) ...<Widget>[
            const SizedBox(height: 8),
            ChipRow(labels: <String>[bi('બાકી - ખાતામાં', 'Baki - in the khata'), bi('રોકડા લીધા', 'Cash received')], index: _paid ? 1 : 0, onChanged: (int i) => setState(() => _paid = i == 1)),
          ],
          if (opts.isNotEmpty) ...<Widget>[
            const SizedBox(height: 8),
            PickChips(title: bi('આ ગાડીઓ', 'Vehicles'), values: opts, onPick: (String v) => setState(() => _veh.text = v)),
          ],
          const SizedBox(height: 6),
          Btn(
            '${bi('પહેલું વજન લો', 'Take first weight')}${(r == null || r.kg == null || !remoteClient.canWeigh) ? '' : ' · ${grp(r.kg!, dec: 0)} KG'}',
            icon: 'plus',
            expand: true,
            onTap: (can && _veh.text.trim().isNotEmpty) ? _first : null,
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: Pal.soft, border: Border.all(color: Pal.line)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Text(bi('સીધું વજન (ટેર લખીને)', 'Direct weighing (write the tare)'), style: ts(13.5, w: FontWeight.w800)),
                const SizedBox(height: 2),
                Text(bi('ખાલી ગાડીનું વજન (ટેર) લખો - કાંટા પરનું વજન ગ્રોસ ગણાશે, એન્ટ્રી તરત બનશે.', 'Write the empty weight (tare) - the weight on the scale counts as gross, the entry is made at once.'), style: ts(11.5, c: Pal.muted)),
                const SizedBox(height: 8),
                FieldX(label: bi('ટેર KG', 'Tare KG'), controller: _tare, keyboard: TextInputType.number, stacked: true, onChanged: (String _) => setState(() {})),
                const SizedBox(height: 8),
                Btn(
                  '${bi('સીધું વજન લો', 'Direct weighing')}${(r == null || r.kg == null || !remoteClient.canWeigh) ? '' : ' · ${grp(r.kg!, dec: 0)} KG'}',
                  icon: 'check',
                  kind: BtnKind.tonal,
                  expand: true,
                  onTap: (can && _veh.text.trim().isNotEmpty && (double.tryParse(_tare.text.replaceAll(',', '').trim()) ?? 0) > 0) ? _direct : null,
                ),
              ],
            ),
          ),
          if (r != null && r.inside.isNotEmpty) ...<Widget>[
            const SizedBox(height: 16),
            Text(bi('અંદર ગયેલી ગાડી (પહેલું વજન લીધું)', 'Vehicles inside (first weight taken)'), style: ts(12.5, w: FontWeight.w800, c: Pal.muted)),
            for (final RemoteInside v in r.inside.take(12))
              Container(
                margin: const EdgeInsets.only(top: 6),
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(color: Pal.soft, border: Border.all(color: Pal.line)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Expanded(child: Text(v.outside ? '${v.vehicle}  ·  ${bi('બહારની', 'ROAD')}${v.party.isEmpty ? '' : ' · ${v.party}'}' : v.vehicle, style: ts(16, w: FontWeight.w800, c: v.outside ? Pal.warn : Pal.ink))),
                        Text('${grp(v.kg, dec: 0)} KG · ${hm(v.at)}', style: ts(12.5, c: Pal.muted, tab: true)),
                        InkWell(onTap: _busy ? null : () => _drop(v), child: Padding(padding: const EdgeInsets.all(6), child: Text('✕', style: ts(13, c: Pal.faint, w: FontWeight.w800)))),
                      ],
                    ),
                    if (v.by.isNotEmpty) Text(v.by, style: ts(11.5, c: Pal.faint)),
                    if (_acc(v) != null) Text(bakiLine(_acc(v))!, style: ts(12.5, w: FontWeight.w800, c: Pal.bad)),
                    const SizedBox(height: 6),
                    Btn(
                      '${bi('બીજું વજન લો', 'Take second weight')}${(r.kg == null || !remoteClient.canWeigh) ? '' : ' · ${grp(r.kg!, dec: 0)} KG'}',
                      icon: 'check',
                      kind: BtnKind.tonal,
                      expand: true,
                      onTap: can ? () => _second(v) : null,
                    ),
                  ],
                ),
              ),
          ],
        ],
      ),
    );
  }

  Widget _recent() {
    final RemoteLive? r = remoteClient.row;
    if (r == null || r.recent.isEmpty) return const SizedBox.shrink();
    return Surface(
      shadow: false,
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text(bi('છેલ્લી સ્લિપ (કાંટા લેપટોપ પરની)', 'Last slips (on the weighbridge laptop)'), style: ts(15, w: FontWeight.w800)),
          for (final RemoteDone d in r.recent)
            Container(
              margin: const EdgeInsets.only(top: 8),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: Pal.soft, border: Border.all(color: d.undone ? Pal.faint : Pal.line)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Expanded(child: Text('${d.outside ? bi('સ્લિપ', 'Slip') : 'RST'} ${d.rst} · ${d.vehicle}', style: ts(15, w: FontWeight.w800, c: d.undone ? Pal.faint : (d.outside ? Pal.warn : Pal.ink)))),
                      Text(hm(d.at), style: ts(12, c: Pal.muted, tab: true)),
                    ],
                  ),
                  Text('${grp(d.gross, dec: 0)} − ${grp(d.tare, dec: 0)} = ${grp(d.net, dec: 0)} KG${d.undone ? '  ·  ${bi('રદ', 'CANCELLED')}' : ''}${d.by.isEmpty ? '' : '  ·  ${d.by}'}', style: ts(12.5, c: Pal.muted, tab: true)),
                  if (!d.undone)
                    Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Row(
                        children: <Widget>[
                          Expanded(child: Btn('WhatsApp', icon: 'share', kind: BtnKind.tonal, dense: true, expand: true, onTap: () => whatsappText(slipTextOf(d.toSlip())))),
                          if (d.undoable) ...<Widget>[
                            const SizedBox(width: 8),
                            Expanded(child: Btn(bi('પાછી લો', 'Take back'), icon: 'close', kind: BtnKind.outline, dense: true, expand: true, onTap: _busy ? null : () => _undo(d))),
                          ],
                        ],
                      ),
                    ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 720,
      rows: (BuildContext ctx) {
        return <Widget>[
          ScreenHeader(bi('કાંટો રિમોટ (ફોનથી)', 'Remote Weighing (from phone)'), sub: bi('તમે ફોનથી હુકમ આપો → કાંટા લેપટોપ પર વજન થાય', 'you give the order on the phone → the weighbridge laptop weighs')),
          _status(),
          _weightCard(),
          const SizedBox(height: 10),
          noteBox('bulb', 'amber', bi('વજન લેતા પહેલાં કેમેરામાં ખાતરી કરો: કાંટા પર ફક્ત આ જ ગાડી છે અને કોઈ માણસ / બીજી ગાડી નથી. વજન ગાડી સ્થિર ઊભી હોય ત્યારે જ લેવાય છે.', 'Before taking the weight check on the camera: only this vehicle is on the platform, no person, no other vehicle. The weight is taken only when the vehicle stands still.')),
          if (_msg.isNotEmpty) noteBox(_msgOk ? 'check' : 'warn', _msgOk ? 'green' : 'amber', _msg),
          _station(),
          const SizedBox(height: 12),
          _recent(),
          const SizedBox(height: 12),
          Surface(
            shadow: false,
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Text(bi('વજન લેતા પહેલાં પૂછો', 'Ask before taking the weight'), style: ts(13, w: FontWeight.w800)),
                const SizedBox(height: 6),
                ChipRow(labels: <String>[bi('હા - કેમેરા ખાતરી પૂછો', 'Yes - ask about the camera'), bi('ના', 'No')], index: _confirm ? 0 : 1, onChanged: (int i) => _setConfirm(i == 0)),
                const SizedBox(height: 6),
                Text(bi('દરેક વજનની નોંધમાં તમારું નામ (ફોનથી) લખાય છે - કાંટાના CSV અને સ્લિપ ઇતિહાસમાં.', 'Your name (from phone) is written with every weighing - in the CSV and the slip history of the laptop.'), style: ts(11.5, c: Pal.faint)),
              ],
            ),
          ),
        ];
      },
    );
  }
}

// ======================================================================
// The card at the top of the owner's dashboard: the weight on the platform now and a button to weigh a vehicle from the phone.
// It asks the server once every 15 seconds while the dashboard is open (the full screen asks every 2 seconds).
// ======================================================================
class KantaRemoteCard extends StatefulWidget {
  /// compact = the small box in the left column of the PC Gateway (no card around it)
  final bool compact;
  const KantaRemoteCard({super.key, this.compact = false});

  @override
  State<KantaRemoteCard> createState() => _KantaRemoteCardState();
}

class _KantaRemoteCardState extends State<KantaRemoteCard> {
  Timer? _t;

  @override
  void initState() {
    super.initState();
    remoteClient.addListener(_tick);
    unawaited(remoteClient.poll());
    _t = Timer.periodic(const Duration(seconds: 10), (Timer _) => unawaited(remoteClient.poll()));
  }

  @override
  void dispose() {
    _t?.cancel();
    remoteClient.removeListener(_tick);
    super.dispose();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final KantaRemoteClient c = remoteClient;
    final RemoteLive? r = c.row;
    final bool ok = c.online && r != null && r.connected && r.kg != null;
    String line;
    Color col = Pal.muted;
    if (c.errKind == 'missing') {
      line = remoteErrText('missing');
    } else if (c.errKind == 'perm') {
      line = remoteErrText('perm');
    } else if (c.errKind == 'offline') {
      line = remoteErrText('offline');
    } else if (r == null) {
      line = bi('કાંટા લેપટોપ તરફથી હજી કંઈ આવ્યું નથી', 'Nothing from the weighbridge laptop yet');
    } else if (!c.online) {
      line = bi('કાંટા લેપટોપ ઑફલાઇન છે', 'The weighbridge laptop is offline');
    } else if (!r.connected) {
      line = bi('લેપટોપ કાંટા સાથે જોડાયેલ નથી', 'The laptop is not connected to the scale');
    } else if (!r.remoteOn) {
      line = bi('લેપટોપ પર "ફોનથી વજન" બંધ છે', '"Weighing from phone" is OFF on the laptop');
      col = Pal.warn;
    } else {
      line = r.steady ? (r.stable ? bi('સ્થિર ✓ - તોલી શકાય', 'Standing still ✓ - can weigh') : bi('વજન બદલાય છે', 'The weight is changing')) : bi('કાંટા પર વજન નથી', 'Nothing on the scale');
      col = r.steady ? Pal.ok : Pal.muted;
    }
    if (widget.compact) {
      return InkWell(
        onTap: () => app.go('kanta_remote'),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 2),
          child: Row(
            children: <Widget>[
              IconChip('scale', tone: ok ? 'green' : 'slate', size: 34),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    if (ok) Text('${grp(r.kg!, dec: 0)} KG', style: ts(20, w: FontWeight.w800, c: r.steady ? Pal.ok : Pal.muted, tab: true)),
                    Text(line, style: ts(12.5, w: FontWeight.w700, c: col)),
                  ],
                ),
              ),
              const SizedBox(width: 6),
              Btn(bi('ગાડી તોલો', 'Weigh'), icon: 'scale', dense: true, onTap: () => app.go('kanta_remote')),
            ],
          ),
        ),
      );
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Surface(
        onTap: () => app.go('kanta_remote'),
        padding: const EdgeInsets.all(12),
        child: Row(
          children: <Widget>[
            IconChip('scale', tone: ok ? 'green' : 'slate', size: 42),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(bi('કાંટો રિમોટ (ફોનથી)', 'Remote weighing (from phone)'), style: ts(14.5, w: FontWeight.w800)),
                  if (ok) Text('${grp(r.kg!, dec: 0)} KG', style: ts(22, w: FontWeight.w800, c: r.steady ? Pal.ok : Pal.muted, tab: true)),
                  Text(line, style: ts(12.5, w: FontWeight.w700, c: col)),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Btn(bi('ગાડી તોલો', 'Weigh'), icon: 'scale', dense: true, onTap: () => app.go('kanta_remote')),
          ],
        ),
      ),
    );
  }
}
