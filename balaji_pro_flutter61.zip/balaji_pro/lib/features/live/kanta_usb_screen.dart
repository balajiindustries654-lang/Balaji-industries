import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/app_state.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/engine.dart' show sk;
import '../../data/kanta_auto.dart';
import '../../data/kanta_pair.dart';
import '../../data/kanta_usb.dart';
import '../../data/native_io.dart';
import '../../data/scan.dart' show ScanPrefill;
import '../../data/serial_decode.dart';
import '../../widgets/common.dart';
import '../../widgets/launch.dart' show whatsappText;
import '../../widgets/page.dart';
import 'kit2.dart';
import 'ui.dart';

// ======================================================================
// Weighbridge USB (live): terminal COM port -> USB-to-RS232 cable -> OTG -> phone
// ======================================================================

class KantaUsbScreen extends StatefulWidget {
  const KantaUsbScreen({super.key});

  @override
  State<KantaUsbScreen> createState() => _KantaUsbState();
}

class _KantaUsbState extends State<KantaUsbScreen> {
  bool _hex = false;
  String _speedMsg = '';
  final TextEditingController _hostC = TextEditingController(text: '127.0.0.1');
  final TextEditingController _portC = TextEditingController(text: '2000');
  Timer? _auto;
  int _n = 0;

  static const List<(String, int, int, int)> _modes = <(String, int, int, int)>[
    ('8N1', 8, 0, 1),
    ('7E1', 7, 2, 1),
    ('8E1', 8, 2, 1),
    ('8N2', 8, 0, 2),
  ];

  @override
  void initState() {
    super.initState();
    kantaUsb.addListener(_tick);
    kantaUsb.load().then((_) {
      _hostC.text = kantaUsb.host;
      _portC.text = '${kantaUsb.port}';
      if (kantaUsb.possible && !kantaUsb.net && !kantaUsb.connected) kantaUsb.refresh();
      if (mounted) setState(() {});
    });
    // plug the cable in and it shows up here by itself (no need to tap "Search again")
    _auto = Timer.periodic(const Duration(seconds: 3), (Timer _) {
      final KantaUsbService u = kantaUsb;
      _n++;
      // on Windows every search starts a PowerShell: do it only while no COM port is listed, and slowly
      if (u.winCom && (u.devices.isNotEmpty || _n % 3 != 0)) return;
      if (mounted && u.possible && !u.net && !u.connected && !u.busy && !u.scanning) u.refresh(quiet: true);
    });
  }

  @override
  void dispose() {
    kantaUsb.removeListener(_tick);
    _auto?.cancel();
    _hostC.dispose();
    _portC.dispose();
    super.dispose();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  int get _modeIndex {
    final int i = _modes.indexWhere(((String, int, int, int) m) => m.$2 == kantaUsb.dataBits && m.$3 == kantaUsb.parity && m.$4 == kantaUsb.stopBits);
    return i < 0 ? 0 : i;
  }

  Widget _dot(bool on) => Container(width: 10, height: 10, decoration: BoxDecoration(color: on ? Pal.ok : Pal.faint, shape: BoxShape.circle));

  String _errText(String e) {
    if (e == 'no device') return bi('પહેલાં USB કેબલ પસંદ કરો', 'Choose the USB cable first');
    if (kantaUsb.net) {
      final String l = e.toLowerCase();
      if (l.contains('refused') || l.contains('timed out') || l.contains('timeout') || l.contains('unreachable') || l.contains('socketexception') || l.contains('errno')) {
        return bi('Bridge એપ સાથે જોડાણ થયું નહીં. તે એપ ખોલો, તેમાં USB કેબલ "Allow" કરી TCP server ચાલુ કરો, અને અહીંનો port એ એપના port જેવો જ રાખો. (એપ પોતે ફરી ફરી પ્રયત્ન કરતી રહેશે.)', 'Could not reach the bridge app. Open that app, allow the USB cable, switch its TCP server on, and keep the port here the same as in that app. (This app keeps trying by itself.)');
      }
    }
    return e;
  }

  Widget _connection() {
    final KantaUsbService u = kantaUsb;
    return Surface(
      shadow: false,
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Row(
            children: <Widget>[
              _dot(u.connected),
              const SizedBox(width: 8),
              Expanded(child: Text(u.connected ? '${bi('જોડાયેલ', 'Connected')} · ${u.modeText}' : (u.trying ? bi('રાહ જુએ છે… (જાતે ફરી પ્રયત્ન)', 'Waiting… (trying again by itself)') : bi('જોડાયેલ નથી', 'Not connected')), style: ts(14, w: FontWeight.w800, c: u.connected ? Pal.ok : Pal.ink))),
              if (!u.net) Btn(bi('ફરી શોધો', 'Search again'), kind: BtnKind.ghost, dense: true, onTap: u.possible ? u.refresh : null),
            ],
          ),
          const SizedBox(height: 10),
          if (u.possible && !u.winCom) ...<Widget>[
            Text(bi('ડેટા ક્યાંથી લેવો', 'Where the data comes from'), style: ts(12.5, w: FontWeight.w700, c: Pal.muted)),
            const SizedBox(height: 6),
            ChipRow(labels: <String>[bi('Bridge એપ (સહેલું)', 'Bridge app (easy)'), bi('સીધો USB (આ એપમાં)', 'Direct USB (in this app)')], index: u.net ? 0 : 1, onChanged: (int i) => u.setSource(i == 0)),
            const SizedBox(height: 10),
          ],
          if (u.net) ..._netControls() else ..._usbControls(),
        ],
      ),
    );
  }

  List<Widget> _netControls() {
    final KantaUsbService u = kantaUsb;
    return <Widget>[
      Text(bi('Play Store ની મફત એપ "TCPUART transparent Bridge" USB કેબલ વાંચીને ફોનના પોર્ટ પર ડેટા આપે છે; Balaji Pro ત્યાંથી વાંચે છે. આમાં USB પ્લગ-ઇન જોઈતું નથી.', 'The free Play Store app "TCPUART transparent Bridge" reads the USB cable and gives the data on a port of the phone; Balaji Pro reads it from there. No USB plug-in is needed.'), style: ts(12.5, c: Pal.muted)),
      const SizedBox(height: 10),
      Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: <Widget>[
          Expanded(flex: 3, child: FieldX(label: bi('સરનામું (Host)', 'Address (host)'), controller: _hostC, hint: '127.0.0.1', keyboard: TextInputType.url, stacked: true)),
          const SizedBox(width: 10),
          Expanded(flex: 2, child: FieldX(label: 'Port', controller: _portC, hint: '2000', keyboard: TextInputType.number, stacked: true)),
        ],
      ),
      const SizedBox(height: 4),
      Text(bi('Bridge એપ આ જ ફોનમાં હોય તો 127.0.0.1 રાખો. લેપટોપ / serial-to-network બોક્સ વાપરો તો તેનું IP લખો.', 'If the bridge app is on this same phone keep 127.0.0.1. For a laptop / serial-to-network box write its IP.'), style: ts(11.5, c: Pal.faint)),
      const SizedBox(height: 12),
      Wrap(
        spacing: 10,
        runSpacing: 8,
        children: <Widget>[
          if (u.connected || u.trying) Btn(u.connected ? bi('છૂટો કરો', 'Disconnect') : bi('બંધ કરો', 'Stop'), kind: BtnKind.outline, onTap: u.disconnect) else Btn(bi('જોડો', 'Connect'), icon: 'sync', onTap: (u.netPossible && !u.busy) ? _connectNet : null),
        ],
      ),
    ];
  }

  Future<void> _connectNet() async {
    final int p = int.tryParse(_portC.text.trim()) ?? 2000;
    await kantaUsb.setNet(_hostC.text, p);
    _hostC.text = kantaUsb.host;
    _portC.text = '${kantaUsb.port}';
    await kantaUsb.connect();
  }

  List<Widget> _usbControls() {
    final KantaUsbService u = kantaUsb;
    return <Widget>[
          if (u.devices.isEmpty) ...<Widget>[
            Text(
              u.winCom
                  ? bi('લેપટોપને કોઈ COM પોર્ટ દેખાતો નથી. (જાતે ફરી શોધે છે.) નીચે તપાસો:', 'The laptop does not list any COM port. (It searches again by itself.) Please check:')
                  : (u.possible ? bi('ફોનને કોઈ USB ઉપકરણ દેખાતું નથી. (દર 3 સેકન્ડે જાતે ફરી શોધે છે.) નીચે તપાસો:', 'The phone does not see any USB device. (This screen searches again every 3 seconds.) Please check:') : bi('આ બિલ્ડમાં USB કેબલ સપોર્ટ નથી.', 'This build has no USB cable support.')),
              style: ts(12.5, w: FontWeight.w700),
            ),
            if (u.possible) ...<Widget>[
              const SizedBox(height: 6),
              for (final String t in u.winCom
                  ? <String>[
                      bi('USB-RS232 કેબલ લેપટોપના USB માં પૂરેપૂરો લગાવેલો છે? બીજો USB પોર્ટ પણ અજમાવો.', 'Is the USB-RS232 cable pushed fully into a USB port of the laptop? Try another USB port too.'),
                      bi('Windows ને કેબલનું driver જોઈએ (FTDI). Start → Device Manager → "Ports (COM & LPT)" માં "USB Serial Port (COM3)" જેવું દેખાવું જોઈએ. પીળું ચિહ્ન હોય કે ન દેખાય તો ftdichip.com પરથી "VCP driver" ઇન્સ્ટૉલ કરો.', 'Windows needs the driver of the cable (FTDI). Start → Device Manager → "Ports (COM & LPT)" must show something like "USB Serial Port (COM3)". If there is a yellow mark or nothing, install the "VCP driver" from ftdichip.com.'),
                      bi('બીજી કોઈ એપ (જૂનું કાંટા સૉફ્ટવેર, Putty, વગેરે) એ જ COM પોર્ટ વાપરતી હોય તો તેને બંધ કરો - એક સમયે એક જ એપ પોર્ટ ખોલી શકે.', 'If another program (old weighbridge software, Putty, etc.) uses the same COM port, close it - only one program can open the port at a time.'),
                    ]
                  : <String>[
                      bi('USB-RS232 કેબલ → OTG → ફોન: બધું પૂરેપૂરું અંદર દબાવેલું છે?', 'USB-RS232 cable → OTG → phone: is everything pushed in fully?'),
                      bi('ફોન Settings માં "OTG" ચાલુ કરો (Oppo / Realme / OnePlus: Settings → Additional settings → OTG connection). ત્યાં એ થોડી વારમાં જાતે બંધ થઈ જાય છે - ફરી ચાલુ કરો.', 'Switch "OTG" on in the phone Settings (Oppo / Realme / OnePlus: Settings → Additional settings → OTG connection). It switches itself off after a while - switch it on again.'),
                      bi('OTG માં પેનડ્રાઇવ લગાવી જુઓ. એ ફોનમાં દેખાય તો OTG બરાબર છે, કેબલમાં વાંધો છે.', 'Try a pendrive in the OTG. If the phone shows it, OTG is fine and the problem is the cable.'),
                      bi('ફોન "Allow / મંજૂરી" પૂછે તો Allow દબાવો.', 'If the phone asks "Allow", tap Allow.'),
                    ])
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[SizedBox(width: 16, child: Text('•', style: ts(12.5, c: Pal.muted))), Expanded(child: Text(t, style: ts(12.5, c: Pal.muted)))]),
                ),
            ],
          ] else
            Row(
              children: <Widget>[
                SizedBox(width: 92, child: Text(u.winCom ? 'COM port' : bi('USB કેબલ', 'USB cable'), style: ts(13, w: FontWeight.w700))),
                Expanded(
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: PickX<UsbDev>(label: u.chosen?.label ?? '-', items: u.devices, text: (UsbDev d) => d.label, onSelected: u.choose),
                  ),
                ),
              ],
            ),
          const SizedBox(height: 10),
          Row(
            children: <Widget>[
              SizedBox(width: 92, child: Text(bi('સ્પીડ', 'Speed'), style: ts(13, w: FontWeight.w700))),
              Expanded(
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: PickX<int>(label: '${u.baud} baud', items: kUsbBauds, text: (int b) => '$b', onSelected: (int b) => u.setMode(baud: b)),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(bi('ફોર્મેટ (ડેટા-બિટ, પૅરિટી, સ્ટૉપ)', 'Format (data bits, parity, stop)'), style: ts(12.5, w: FontWeight.w700, c: Pal.muted)),
          const SizedBox(height: 6),
          ChipRow(
            labels: <String>[for (final (String, int, int, int) m in _modes) m.$1],
            index: _modeIndex,
            onChanged: (int i) => u.setMode(bits: _modes[i].$2, par: _modes[i].$3, stop: _modes[i].$4),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 10,
            runSpacing: 8,
            children: <Widget>[
              if (u.connected || u.trying) Btn(u.connected ? bi('છૂટો કરો', 'Disconnect') : bi('બંધ કરો', 'Stop'), kind: BtnKind.outline, onTap: u.disconnect) else Btn(bi('જોડો', 'Connect'), icon: 'sync', onTap: (u.possible && u.chosen != null && !u.busy) ? u.connect : null),
              Btn(u.scanning ? '${bi('શોધે છે', 'Searching')} ${u.progress}' : bi('સ્પીડ આપોઆપ શોધો', 'Find the speed'), kind: BtnKind.tonal, onTap: (u.possible && u.chosen != null && !u.scanning && !u.busy) ? _findSpeed : null),
            ],
          ),
          if (_speedMsg.isNotEmpty) ...<Widget>[const SizedBox(height: 8), Text(_speedMsg, style: ts(12.5, c: Pal.muted))],
    ];
  }

  Future<void> _findSpeed() async {
    setState(() => _speedMsg = '');
    final String r = await kantaUsb.findSpeed();
    if (!mounted) return;
    String t;
    if (r == 'nothing came') {
      t = bi('કોઈ સ્પીડે ડેટા આવ્યો નહીં. ટર્મિનલ પર ગાડી તોલો / સ્લિપ છાપો અને ફરી દબાવો (ટર્મિનલ ત્યારે જ ડેટા મોકલતું હોઈ શકે).', 'No data came at any speed. Weigh a vehicle / print a slip on the terminal and tap again (the terminal may send data only then).');
    } else if (r == 'garbage only') {
      t = bi('ડેટા આવ્યો પણ વાંચી શકાય તેવો નહીં. ફોર્મેટ (7E1 / 8E1) બદલી ફરી પ્રયત્ન કરો.', 'Data came but nothing readable. Change the format (7E1 / 8E1) and try again.');
    } else if (r == 'no device') {
      t = bi('પહેલાં USB કેબલ પસંદ કરો', 'Choose the USB cable first');
    } else {
      t = '${bi('મળ્યું', 'Found')}: $r';
    }
    setState(() => _speedMsg = t);
  }

  Widget _steps() {
    final List<String> st = <String>[
      bi('Play Store માંથી "TCPUART transparent Bridge" (મફત) ઇન્સ્ટૉલ કરો.', 'Install "TCPUART transparent Bridge" (free) from the Play Store.'),
      bi('USB-RS232 કેબલ OTG થી ફોનમાં લગાવો; ફોન પૂછે ત્યારે "Allow" દબાવો.', 'Plug the USB-RS232 cable into the phone with OTG; tap "Allow" when asked.'),
      bi('એ એપમાં સ્પીડ (પહેલાં 9600) પસંદ કરી TCP server / Start ચાલુ કરો. એપ જે port બતાવે (સામાન્ય રીતે 2000) તે નોંધો.', 'In that app choose the speed (try 9600 first) and start the TCP server / Start. Note the port it shows (usually 2000).'),
      bi('એ એપ ખુલ્લી રાખીને અહીં Balaji Pro માં ઉપર 127.0.0.1 અને એ port લખી "જોડો" દબાવો.', 'Keep that app open, write 127.0.0.1 and that port above in Balaji Pro and tap "Connect".'),
      bi('કાંટા પર એક ગાડી તોલો. વજન / સ્લિપ આવે તો ફક્ત "બધું કૉપી કરો" દબાવી મને મોકલો.', 'Weigh one vehicle on the terminal. When weight / slip comes, just tap "Copy everything" and send it to me.'),
    ];
    return Surface(
      shadow: false,
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text(bi('5 પગલાં', '5 steps'), style: ts(13.5, w: FontWeight.w800)),
          const SizedBox(height: 6),
          for (int i = 0; i < st.length; i++)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  SizedBox(width: 22, child: Text('${i + 1}.', style: ts(12.5, w: FontWeight.w800, c: Pal.muted))),
                  Expanded(child: Text(st[i], style: ts(12.5))),
                ],
              ),
            ),
          const SizedBox(height: 4),
          Text(bi('બંને એપ ખુલ્લી અને ફોન ચાલુ (સ્ક્રીન બંધ ન થાય) રાખવો.', 'Keep both apps open and the phone awake (screen not switched off).'), style: ts(11.5, c: Pal.faint)),
        ],
      ),
    );
  }

  Widget _live() {
    final KantaUsbService u = kantaUsb;
    final double? kg = u.dec.kg;
    return Surface(
      shadow: false,
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text(bi('લાઇવ વજન', 'Live weight'), style: ts(13.5, w: FontWeight.w800)),
          const SizedBox(height: 6),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              Text(kg == null ? '—' : grp(kg, dec: kg == kg.roundToDouble() ? 0 : 1), style: ts(38, w: FontWeight.w800, tab: true, c: kg == null ? Pal.faint : (u.dec.stable ? Pal.ok : Pal.ink))),
              const SizedBox(width: 6),
              Padding(padding: const EdgeInsets.only(bottom: 7), child: Text('KG', style: ts(14, w: FontWeight.w700, c: Pal.muted))),
              const Spacer(),
              if (kg != null) Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(u.dec.stable ? bi('સ્થિર', 'Steady') : bi('બદલાય છે…', 'Moving…'), style: ts(12.5, w: FontWeight.w800, c: u.dec.stable ? Pal.ok : Pal.warn))),
            ],
          ),
          if (kg == null) Text(bi('લાઇવ વજન આવતું નથી (ટર્મિનલ કદાચ ફક્ત સ્લિપ છપાય ત્યારે ડેટા મોકલે છે).', 'No live weight is coming (the terminal may send data only when a slip is printed).'), style: ts(12, c: Pal.muted)),
          if (kg != null && kg > 0) ...<Widget>[
            const SizedBox(height: 8),
            Btn(bi('આ વજન સાથે કાંટા એન્ટ્રી', 'Weighbridge entry with this weight'), icon: 'plus', kind: BtnKind.tonal, onTap: () => app.go('kanta_new', arg: ScanPrefill(kind: 'kanta', f: <String, String>{'kg': '${kg.round()}'}, scanned: false))),
          ],
        ],
      ),
    );
  }

  void _entryFromWeights() {
    final KantaUsbService u = kantaUsb;
    if (u.picked.isEmpty) return;
    if (u.picked.length == 1) {
      app.go('kanta_new', arg: ScanPrefill(kind: 'kanta', f: <String, String>{'kg': '${u.picked.first.kg.round()}'}, scanned: false));
      return;
    }
    final double a = u.picked[0].kg;
    final double b = u.picked[1].kg;
    final double g = a >= b ? a : b;
    final double t = a >= b ? b : a;
    app.go('kanta_new', arg: ScanPrefill(kind: 'kanta', f: <String, String>{'gross': '${g.round()}', 'tare': '${t.round()}', 'kg': '${(g - t).round()}'}, scanned: false));
  }

  Widget _weighs() {
    final KantaUsbService u = kantaUsb;
    final List<SettledWeight> l = u.weighs.take(8).toList();
    final List<SettledWeight> free = u.weighs.where((SettledWeight w) => !w.used).toList();
    final List<AutoPair> sug = u.suggestions;
    final bool two = u.picked.length == 2;
    final double g = two ? (u.picked[0].kg >= u.picked[1].kg ? u.picked[0].kg : u.picked[1].kg) : 0;
    final double t = two ? (u.picked[0].kg >= u.picked[1].kg ? u.picked[1].kg : u.picked[0].kg) : 0;
    return Surface(
      shadow: false,
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Row(
            children: <Widget>[
              Expanded(child: Text(bi('સ્થિર વજન (જાતે પકડાયેલું)', 'Steady weights'), style: ts(13.5, w: FontWeight.w800))),
              if (u.weighs.isNotEmpty) InkWell(onTap: u.clearWeighs, child: Padding(padding: const EdgeInsets.all(4), child: Text(bi('સાફ', 'Clear'), style: ts(12.5, c: Pal.faint, w: FontWeight.w800)))),
            ],
          ),
          const SizedBox(height: 4),
          Text(bi('ગાડી કાંટા પર 3 સેકન્ડ સ્થિર રહે એટલે તેનું વજન અહીં આવે છે (100 KG થી વધુ). ભરેલી અને ખાલી ગાડીનાં બે વજન પર ટચ કરો - ગ્રોસ, ટેર અને ચોખ્ખું વજન એન્ટ્રીમાં જાતે ભરાશે.', 'When a vehicle stands still on the platform for 3 seconds its weight comes here (above 100 KG). Tap the two weights of one vehicle (loaded and empty) - gross, tare and net are filled in the entry by themselves.'), style: ts(12, c: Pal.muted)),
          const SizedBox(height: 8),
          if (l.isEmpty)
            Text(bi('હજી કોઈ સ્થિર વજન પકડાયું નથી.', 'No steady weight caught yet.'), style: ts(12.5, c: Pal.faint))
          else
            for (final SettledWeight w in l)
              InkWell(
                onTap: () => u.togglePick(w),
                child: Container(
                  margin: const EdgeInsets.symmetric(vertical: 2),
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                  decoration: BoxDecoration(color: u.isPicked(w) ? Pal.soft : Colors.transparent, border: Border.all(color: u.isPicked(w) ? Pal.ok : Pal.line)),
                  child: Row(
                    children: <Widget>[
                      Container(width: 18, height: 18, decoration: BoxDecoration(color: u.isPicked(w) ? Pal.ok : Colors.transparent, border: Border.all(color: u.isPicked(w) ? Pal.ok : Pal.faint), borderRadius: BorderRadius.circular(3)), child: u.isPicked(w) ? const Icon(Icons.check, size: 14, color: Colors.white) : null),
                      const SizedBox(width: 10),
                      SizedBox(width: 48, child: Text(hm(w.at), style: ts(12, c: Pal.muted, tab: true))),
                      Expanded(child: Text('${grp(w.kg, dec: 0)} KG${w.used ? '  ✓ ${bi('એન્ટ્રી બની', 'entry made')}' : ''}', style: ts(16, w: FontWeight.w800, tab: true, c: w.used ? Pal.faint : Pal.ink))),
                      InkWell(onTap: () => u.removeWeigh(w), child: Padding(padding: const EdgeInsets.all(4), child: Text('✕', style: ts(13, c: Pal.faint, w: FontWeight.w800)))),
                    ],
                  ),
                ),
              ),
          if (sug.isNotEmpty) ...<Widget>[
            const SizedBox(height: 10),
            Text(bi('ગાડી મળી (ચિઠ્ઠીના વજન સાથે મેળ ખાય છે)', 'Vehicle found (fits the chit weight)'), style: ts(12.5, w: FontWeight.w800, c: Pal.ok)),
            for (final AutoPair p in sug)
              Container(
                margin: const EdgeInsets.only(top: 6),
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(color: Pal.soft, border: Border.all(color: Pal.ok)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    Text(p.trip.vehicle, style: ts(15, w: FontWeight.w800)),
                    Text('${grp(p.gross.kg, dec: 0)} − ${grp(p.tare.kg, dec: 0)} = ${grp(p.net, dec: 0)} KG · ${bi('ચિઠ્ઠી', 'chit')} ${grp(p.trip.chitKg, dec: 0)} KG (${sk(p.diff)})', style: ts(12.5, c: Pal.muted)),
                    const SizedBox(height: 6),
                    Btn(bi('આ ગાડીની એન્ટ્રી બનાવો', 'Make the entry for this vehicle'), icon: 'plus', kind: BtnKind.tonal, expand: true, onTap: () => app.go('kanta_new', arg: ScanPrefill(kind: 'kanta', f: <String, String>{'vehicle': p.trip.vehicle, 'gross': '${p.gross.kg.round()}', 'tare': '${p.tare.kg.round()}', 'kg': '${p.net.round()}'}, scanned: false))),
                  ],
                ),
              ),
          ],
          if (two) ...<Widget>[
            const SizedBox(height: 8),
            InfoRow(bi('ગ્રોસ (ભરેલી)', 'Gross (loaded)'), '${grp(g, dec: 0)} KG'),
            InfoRow(bi('ટેર (ખાલી)', 'Tare (empty)'), '${grp(t, dec: 0)} KG'),
            InfoRow(bi('ચોખ્ખું વજન', 'Net weight'), '${grp(g - t, dec: 0)} KG', bold: true, color: g - t >= 100 ? Pal.ok : Pal.warn),
            if (g - t < 100) Text(bi('બંને વજન લગભગ સરખાં છે - એક જ ગાડીનાં ભરેલી અને ખાલી વજન ટિક કરો.', 'The two weights are almost the same - tick the loaded and the empty weight of one vehicle.'), style: ts(12, c: Pal.warn)),
          ],
          if (u.picked.isNotEmpty) ...<Widget>[
            const SizedBox(height: 8),
            Btn(two ? bi('આ બે વજનથી એન્ટ્રી', 'Entry from these 2 weights') : bi('આ એક વજનથી એન્ટ્રી', 'Entry from this weight'), icon: 'plus', kind: BtnKind.tonal, expand: true, onTap: _entryFromWeights),
          ] else if (free.length >= 2 && (free[0].kg - free[1].kg).abs() >= 100) ...<Widget>[
            const SizedBox(height: 8),
            Btn(
              '${bi('છેલ્લાં 2', 'Last 2')}: ${grp(free[0].kg > free[1].kg ? free[0].kg : free[1].kg, dec: 0)} − ${grp(free[0].kg > free[1].kg ? free[1].kg : free[0].kg, dec: 0)} = ${grp((free[0].kg - free[1].kg).abs(), dec: 0)} KG',
              icon: 'plus',
              kind: BtnKind.tonal,
              expand: true,
              onTap: () {
                u.picked
                  ..clear()
                  ..add(free[1])
                  ..add(free[0]);
                _entryFromWeights();
              },
            ),
          ],
          const SizedBox(height: 12),
          Text(bi('આપોઆપ એન્ટ્રી', 'Automatic entries'), style: ts(13, w: FontWeight.w800)),
          const SizedBox(height: 6),
          ChipRow(labels: <String>[bi('બંધ (હું ટચ કરું)', 'Off (I tap)'), bi('ચાલુ (જાતે સેવ)', 'On (saves by itself)')], index: u.autoW ? 1 : 0, onChanged: (int i) => u.setAutoW(i == 1)),
          const SizedBox(height: 6),
          Text(
            u.autoW
                ? bi('ભરેલી અને ખાલી વજનનો ફરક ચિઠ્ઠીના વજન (± માન્ય ફરક) જેટલો હોય અને ફક્ત એક જ ગાડી તથા એક જ વજન-જોડી મેળ ખાય, ત્યારે ગાડી નંબર સાથે એન્ટ્રી જાતે સેવ થાય છે (RST આપોઆપ). બે ગાડી મેળ ખાય તો કંઈ સેવ થતું નથી - ઉપર "ગાડી મળી" માં તમે ટચ કરો. ખોટું થાય તો નીચે "પાછું લો".', 'When the loaded minus the empty weight equals the chit weight (± allowed difference) and only ONE vehicle and ONE pair of weights fit, the entry is saved with the vehicle number by itself (RST automatic). If two vehicles fit nothing is saved - you tap in "Vehicle found" above. If it is wrong, tap "Take back" below.')
                : bi('બંધ: મેળ ખાતી ગાડી ઉપર "ગાડી મળી" માં દેખાય છે, તમે ટચ કરીને એન્ટ્રી બનાવો છો.', 'Off: a vehicle that fits is shown in "Vehicle found" above and you tap to make the entry.'),
            style: ts(12, c: Pal.muted),
          ),
          if (u.made.isNotEmpty) ...<Widget>[
            const SizedBox(height: 8),
            Text(bi('અહીંથી બનેલી એન્ટ્રી', 'Entries made here'), style: ts(12.5, w: FontWeight.w800, c: Pal.muted)),
            for (final AutoMade m in u.made.take(6))
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 3),
                child: Row(
                  children: <Widget>[
                    SizedBox(width: 62, child: Text('RST ${m.rst}', style: ts(11.5, c: Pal.muted))),
                    Expanded(child: Text('${m.vehicle} · ${grp(m.net, dec: 0)} KG', style: ts(12.5, w: FontWeight.w700))),
                    InkWell(
                      onTap: () => whatsappText(u.slipText(m)),
                      child: Padding(padding: const EdgeInsets.all(4), child: Text('WhatsApp', style: ts(12.5, c: Pal.ok, w: FontWeight.w800))),
                    ),
                    InkWell(
                      onTap: () async {
                        final String why = await u.undoAuto(m);
                        app.toast(why.isEmpty ? bi('પાછું લીધું', 'Taken back') : why);
                      },
                      child: Padding(padding: const EdgeInsets.all(4), child: Text(bi('પાછું લો', 'Take back'), style: ts(12.5, c: Pal.warn, w: FontWeight.w800))),
                    ),
                  ],
                ),
              ),
          ],
        ],
      ),
    );
  }

  Widget _row(KantaRow r, {Widget? trailing}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: <Widget>[
          SizedBox(width: 52, child: Text(r.rst.isEmpty ? '-' : r.rst, style: ts(12.5, c: Pal.muted))),
          Expanded(child: Text(r.vehicle.isEmpty ? '-' : r.vehicle, style: ts(13, w: FontWeight.w700))),
          Text('${grp(r.partial ? (r.gross > 0 ? r.gross : r.tare) : r.weight, dec: 0)} KG', style: ts(13, w: FontWeight.w800, tab: true, c: r.partial ? Pal.warn : Pal.ink)),
          if (trailing != null) ...<Widget>[const SizedBox(width: 6), trailing],
        ],
      ),
    );
  }

  Widget _save() {
    final KantaUsbService u = kantaUsb;
    return Surface(
      shadow: false,
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text(bi('એપમાં નાખવું', 'Saving into the app'), style: ts(13.5, w: FontWeight.w800)),
          const SizedBox(height: 8),
          ChipRow(labels: <String>[bi('આપોઆપ', 'Automatic'), bi('હાથથી (Save દબાવી)', 'By hand (tap Save)')], index: u.auto ? 0 : 1, onChanged: (int i) => u.setAuto(i == 0)),
          const SizedBox(height: 6),
          Text(
            u.auto ? bi('પૂરી થયેલી સ્લિપ (બંને વજન) તરત કાંટા એન્ટ્રી તરીકે સેવ થાય છે. એપમાં જે RST પહેલેથી છે તે બીજી વાર બનતી નથી. એપ ખુલ્લી અને ફોન ચાલુ રાખવો.', 'A finished slip (both weights) is saved at once as a weighbridge entry. A RST that is already in the app is never made twice. Keep the app open and the phone on.') : bi('સ્લિપ નીચે "તૈયાર" યાદીમાં આવશે - તપાસીને Save દબાવો.', 'Slips come into the "ready" list below - check them and tap Save.'),
            style: ts(12, c: Pal.muted),
          ),
          const SizedBox(height: 6),
          InfoRow(bi('આ વખતે સેવ થયા', 'Saved this time'), '${u.savedCount}', bold: true, color: u.savedCount > 0 ? Pal.ok : Pal.muted),
          if (u.ready.isNotEmpty) ...<Widget>[
            const SizedBox(height: 8),
            Text(bi('સેવ કરવા તૈયાર', 'Ready to save'), style: ts(12.5, w: FontWeight.w800, c: Pal.muted)),
            for (final KantaRow r in u.ready.take(8)) _row(r, trailing: InkWell(onTap: () => u.dropReady(r), child: Padding(padding: const EdgeInsets.all(4), child: Text('✕', style: ts(13, c: Pal.faint, w: FontWeight.w800))))),
            const SizedBox(height: 8),
            Btn('${u.ready.length} ${bi('સેવ કરો', 'Save')}', icon: 'check', expand: true, onTap: () async {
              final int n = await u.saveReady();
              app.toast('$n ${bi('કાંટા એન્ટ્રી બની', 'weighbridge entries made')}');
            }),
          ],
          if (u.waiting.isNotEmpty) ...<Widget>[
            const SizedBox(height: 10),
            Text(bi('બીજા વજનની રાહ (હજી સેવ નથી)', 'Waiting for the second weight (not saved)'), style: ts(12.5, w: FontWeight.w800, c: Pal.muted)),
            for (final KantaRow r in u.waiting.take(6)) _row(r),
          ],
        ],
      ),
    );
  }

  Widget _events() {
    final List<UsbEvent> l = kantaUsb.log.reversed.take(8).toList();
    if (l.isEmpty) return const SizedBox.shrink();
    return Surface(
      shadow: false,
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text(bi('છેલ્લી ઘટનાઓ', 'Latest events'), style: ts(13.5, w: FontWeight.w800)),
          const SizedBox(height: 6),
          for (final UsbEvent e in l)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 2),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  SizedBox(width: 44, child: Text(hm(e.at), style: ts(11.5, c: Pal.faint, tab: true))),
                  Expanded(child: Text(e.text, style: ts(12.5, c: e.tone == 'warn' ? Pal.warn : (e.tone == 'ok' ? Pal.ok : Pal.ink), w: FontWeight.w600))),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _monitor() {
    final KantaUsbService u = kantaUsb;
    final List<String> all = u.dec.shownLines;
    final List<String> ls = all.length > 14 ? all.sublist(all.length - 14) : all;
    final List<String> oth = u.dec.others.length > 8 ? u.dec.others.sublist(u.dec.others.length - 8) : u.dec.others;
    final String body = _hex ? (u.dec.bytes == 0 ? '' : u.dec.hexTail(160)) : ls.join('\n');
    return Surface(
      shadow: false,
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Row(
            children: <Widget>[
              Expanded(child: Text(bi('કાચો ડેટા (Raw)', 'Raw data'), style: ts(13.5, w: FontWeight.w800))),
              Text('${u.dec.bytes} ${bi('બાઇટ', 'bytes')} · ${u.dec.lineCount} ${bi('લાઇન', 'lines')}${u.dec.rate > 0 ? ' · ~${u.dec.rate.toStringAsFixed(0)}/s' : ''}', style: ts(12, c: Pal.muted, tab: true)),
            ],
          ),
          const SizedBox(height: 8),
          ChipRow(labels: <String>[bi('લખાણ', 'Text'), 'Hex'], index: _hex ? 1 : 0, onChanged: (int i) => setState(() => _hex = i == 1)),
          const SizedBox(height: 8),
          Container(
            constraints: const BoxConstraints(minHeight: 70, maxHeight: 220),
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: Pal.soft, border: Border.all(color: Pal.line)),
            child: SingleChildScrollView(
              reverse: true,
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(body.isEmpty ? bi('હજી કંઈ આવ્યું નથી', 'Nothing has come yet') : body, style: TextStyle(fontFamily: 'monospace', fontSize: 11.5, height: 1.3, color: body.isEmpty ? Pal.faint : Pal.ink)),
              ),
            ),
          ),
          if (oth.isNotEmpty) ...<Widget>[
            const SizedBox(height: 8),
            Text(bi('બીજું લખાણ (વજન નથી) - સ્લિપ જેવું', 'Other text (not a weight) - like a slip'), style: ts(12.5, w: FontWeight.w800, c: Pal.warn)),
            const SizedBox(height: 4),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: Pal.soft, border: Border.all(color: Pal.line)),
              child: Text(oth.join('\n'), style: TextStyle(fontFamily: 'monospace', fontSize: 11.5, height: 1.3, color: Pal.ink)),
            ),
          ],
          const SizedBox(height: 10),
          Wrap(
            spacing: 10,
            runSpacing: 8,
            children: <Widget>[
              Btn(bi('બધું કૉપી કરો', 'Copy everything'), icon: 'copy', kind: BtnKind.tonal, onTap: () async {
                await Clipboard.setData(ClipboardData(text: u.report()));
                app.toast(bi('કૉપી થયું - મને મોકલો', 'Copied - send it to me'));
              }),
              Btn(bi('સાફ કરો', 'Clear'), kind: BtnKind.outline, onTap: u.clearCapture),
            ],
          ),
          const SizedBox(height: 4),
          Text(bi('ટર્મિનલ પર એક ગાડી તોલ્યા પછી "બધું કૉપી કરો" દબાવી મને મોકલશો તો ફોર્મેટ બરાબર બેસાડી શકાશે.', 'After weighing one vehicle on the terminal, tap "Copy everything" and send it to me so the exact format can be fitted.'), style: ts(12, c: Pal.muted)),
        ],
      ),
    );
  }

  Widget _test() {
    return Surface(
      shadow: false,
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text(bi('ટેસ્ટ (કેબલ વગર)', 'Test (no cable)'), style: ts(13.5, w: FontWeight.w800)),
          const SizedBox(height: 4),
          Text(bi('સ્ક્રીન કેવી ચાલે છે તે જોવા માટે. ટેસ્ટની સ્લિપ ક્યારેય સેવ થતી નથી.', 'To see how the screen works. A test slip is never saved.'), style: ts(12, c: Pal.muted)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 10,
            runSpacing: 8,
            children: <Widget>[
              Btn(bi('લાઇવ વજન ટેસ્ટ', 'Test live weight'), kind: BtnKind.outline, onTap: () => kantaUsb.demoFeed(SerialDecoder.demoLive(6200, steadyWord: true))),
              Btn(bi('સ્લિપ ટેસ્ટ', 'Test slip'), kind: BtnKind.outline, onTap: () => kantaUsb.demoFeed(SerialDecoder.demoSlip())),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final KantaUsbService u = kantaUsb;
    return LiveBody(
      maxWidth: 820,
      rows: (BuildContext ctx) {
        return <Widget>[
          ScreenHeader(bi('કાંટો USB (લાઇવ)', 'Weighbridge USB (Live)'), sub: u.winCom ? bi('ટર્મિનલ → USB-RS232 કેબલ → લેપટોપ', 'terminal → USB-RS232 cable → laptop') : bi('ટર્મિનલ → USB-RS232 કેબલ → ફોન', 'terminal → USB-RS232 cable → phone')),
          statusBanner(),
          noteBox('info', 'blue', bi('કાંટા ટર્મિનલના COM પોર્ટમાંથી આવતો ડેટા (લાઇવ વજન અને છપાતી સ્લિપ) અહીં વંચાય છે. પૂરી થયેલી સ્લિપ કાંટા એન્ટ્રી તરીકે એપમાં જાય છે; એક જ વજન થયું હોય તો બીજા વજનની રાહ જુએ છે.', 'Data from the COM port of the weighbridge terminal (live weight and printed slips) is read here. A finished slip goes to the app as a weighbridge entry; a slip with only one weight waits for the second.')),
          if (!u.possible) noteBox('info', 'blue', bi('આ બિલ્ડમાં સીધો USB સપોર્ટ નથી - તેથી "Bridge એપ" રીત વાપરો (નીચેના 5 પગલાં). એ રીત દરેક બિલ્ડમાં ચાલે છે.', 'This build has no direct USB support, so use the "Bridge app" way (the 5 steps below). It works in every build.')),
          _connection(),
          if (u.net && !u.connected) ...<Widget>[const SizedBox(height: 10), _steps()],
          if (u.error.isNotEmpty) ...<Widget>[const SizedBox(height: 10), noteBox('warn', 'amber', _errText(u.error))],
          if (u.connected && u.dec.bytes == 0) ...<Widget>[
            const SizedBox(height: 10),
            noteBox('bulb', 'amber', bi('જોડાયું, પણ હજી ડેટા આવ્યો નથી. ટર્મિનલ પર એક ગાડી તોલો / સ્લિપ છાપો. કંઈ ન આવે તો: Bridge એપમાં સ્પીડ બરાબર છે? ટર્મિનલનો ખાલી COM-1 પોર્ટ વાપરો, કેબલ null-modem (ક્રોસ) જોઈએ, અને ટર્મિનલમાં એ પોર્ટ ચાલુ હોવો જોઈએ.', 'Connected, but no data yet. Weigh a vehicle / print a slip on the terminal. If nothing comes: is the speed right in the bridge app? Use the free COM-1 port of the terminal, the cable must be null-modem (crossed), and the port must be switched on in the terminal.')),
          ],
          const SizedBox(height: 12),
          _live(),
          const SizedBox(height: 12),
          _weighs(),
          const SizedBox(height: 12),
          _save(),
          const SizedBox(height: 12),
          _events(),
          if (u.log.isNotEmpty) const SizedBox(height: 12),
          _monitor(),
          const SizedBox(height: 12),
          _test(),
          if (!u.winCom) const SizedBox(height: 12),
          if (!u.winCom) noteBox('bulb', 'amber', bi('ફોન કાંટે કાયમ મૂકવા માટે: ફોન ચાર્જર પર રાખો · ફોન Settings → Display → Screen timeout = Never (કે "Stay awake while charging") કરો · Balaji Pro આ સ્ક્રીન પર ખુલ્લી રાખો (બંધ ન કરો) · Battery saver / optimisation Balaji Pro માટે બંધ રાખો · નેટ ચાલુ રાખો (નેટ જાય તો એન્ટ્રી ફોનમાં સચવાય છે અને પાછું આવતાં જાતે જાય છે).', 'To leave the phone at the weighbridge: keep it on the charger · phone Settings → Display → Screen timeout = Never (or "Stay awake while charging") · keep Balaji Pro open on this screen (do not close it) · switch battery saver / optimisation off for Balaji Pro · keep the internet on (if it drops, entries stay on the phone and go by themselves when it is back).')),
          const SizedBox(height: 12),
          noteBox('bulb', 'amber', u.winCom ? bi('કેબલ: ટર્મિનલના COM-1 (નર, pin દેખાય છે) માં લગાવવા માટે બંને બાજુ માદા (female) વાળો null-modem કેબલ કે gender-changer જોઈએ. USB-RS232 કેબલ → લેપટોપનો USB.', 'Cable: the COM-1 of the terminal is male (pins), so you need a null-modem cable / gender changer with female ends. USB-RS232 cable → USB of the laptop.') : bi('કેબલ: ટર્મિનલના COM-1 (નર, pin દેખાય છે) માં લગાવવા માટે બંને બાજુ માદા (female) વાળો null-modem કેબલ કે gender-changer જોઈએ. USB-RS232 કેબલ → OTG → ફોન.', 'Cable: the COM-1 of the terminal is male (pins), so you need a null-modem cable / gender changer with female ends. USB-RS232 cable → OTG → phone.')),
        ];
      },
    );
  }
}
