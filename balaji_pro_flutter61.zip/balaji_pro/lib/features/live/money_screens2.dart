import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/engine.dart';
import '../../data/insights.dart';
import '../../data/lists.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../data/money.dart';
import '../../data/owner_docs.dart';
import '../../data/scan.dart' show commodityCode;
import '../../widgets/charts.dart';
import '../../widgets/common.dart';
import '../../widgets/launch.dart';
import '../../widgets/page.dart';
import 'field.dart';
import 'kit.dart';
import 'kit2.dart';
import 'money_screens.dart';
import 'ui.dart';
import '../../widgets/accept.dart';
import 'value_screens.dart' show materialNames;

Widget _head(String text) => Padding(padding: const EdgeInsets.fromLTRB(2, 10, 2, 6), child: Text(text, style: ts(12.5, w: FontWeight.w800, c: Pal.muted, ls: 0.3)));

// ======================================================================
// Brokerage
// ======================================================================

class _BrokerRateForm extends StatefulWidget {
  final String title;
  final String keyId; // '' = the rate for everybody
  const _BrokerRateForm({required this.title, required this.keyId});

  @override
  State<_BrokerRateForm> createState() => _BrokerRateFormState();
}

class _BrokerRateFormState extends State<_BrokerRateForm> {
  late final TextEditingController _c = TextEditingController(text: _start());

  String _start() {
    final double v = widget.keyId.isEmpty ? brokerRateDefault() : brokerRateOf(widget.keyId);
    return v <= 0 ? '' : plainNum(v);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Text(widget.title, style: ts(14, w: FontWeight.w800)),
        const SizedBox(height: 12),
        FieldX(label: bi('દલાલી', 'Brokerage'), controller: _c, big: true, prefix: '₹', suffix: '/ 20 KG', keyboard: const TextInputType.numberWithOptions(decimal: true)),
        const SizedBox(height: 16),
        Btn(bi('સેવ કરો', 'Save'), icon: 'check', expand: true, onTap: () async {
          final double v = dbl(_c.text.replaceAll(',', ''));
          if (widget.keyId.isEmpty) {
            await setBrokerDefault(v);
          } else {
            await setBrokerRate(widget.keyId, v);
          }
          if (context.mounted) Navigator.of(context).pop();
        }),
        if (widget.keyId.isNotEmpty && brokerHasOwnRate(widget.keyId)) ...<Widget>[
          const SizedBox(height: 8),
          Btn(bi('બધા જેવો દર વાપરો', 'Use the common rate'), kind: BtnKind.outline, expand: true, onTap: () async {
            await setBrokerRate(widget.keyId, null);
            if (context.mounted) Navigator.of(context).pop();
          }),
        ],
      ],
    );
  }
}

class _Brk {
  final String key;
  final String label;
  double kg = 0;
  int chits = 0;
  _Brk(this.key, this.label);
}

class BrokerageScreen extends StatefulWidget {
  const BrokerageScreen({super.key});

  @override
  State<BrokerageScreen> createState() => _BrokerageState();
}

class _BrokerageState extends State<BrokerageScreen> {
  RangeSel _sel = RangeSel(4);

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[prefDoc, rateDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 800,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final Period p = _sel.period;
          final Map<String, _Brk> m = <String, _Brk>{};
          for (final Chit c in live.chits) {
            if (!p.has(c.at)) continue;
            final String k = nameKey(c.broker);
            if (k.isEmpty) continue;
            final _Brk b = m.putIfAbsent(k, () => _Brk(k, c.broker));
            b.kg += payKg(c);
            b.chits++;
          }
          final List<_Brk> l = m.values.toList();
          double total = 0;
          double kg = 0;
          for (final _Brk b in l) {
            total += b.kg / 20 * brokerRateOf(b.key);
            kg += b.kg;
          }
          l.sort((_Brk a, _Brk b) => (b.kg * brokerRateOf(b.key)).compareTo(a.kg * brokerRateOf(a.key)));
          final double def = brokerRateDefault();

          String text() {
            final StringBuffer b = StringBuffer();
            b.writeln('Balaji Industries');
            b.writeln('${bi('દલાલી હિસાબ', 'Brokerage')} - ${p.label}');
            b.writeln('------------------------');
            for (final _Brk x in l) {
              final double r = brokerRateOf(x.key);
              b.writeln('${x.label}: ${grp(x.kg)} KG × ₹${plainNum(r)}/20 = ${inr(x.kg / 20 * r)}');
            }
            b.writeln('------------------------');
            b.writeln('${bi('કુલ દલાલી', 'Total')}: ${inr(total)}');
            return b.toString().trim();
          }

          return <Widget>[
            ScreenHeader(bi('દલાલી હિસાબ', 'Brokerage'), sub: p.label),
            statusBanner(),
            RangeBar(sel: _sel, presets: const <int>[2, 3, 4, 5, 6], onChanged: (RangeSel s) => setState(() => _sel = s)),
            const SizedBox(height: 12),
            HeroCard(
              title: bi('કુલ દલાલી', 'Total brokerage'),
              value: inr(total),
              unit: '',
              sub: '${l.length} ${bi('દલાલ', 'brokers')} · ${kgTxt(kg)}',
              chips: <HeroChip>[HeroChip('pct', '${bi('સામાન્ય દર', 'Common rate')} ₹${plainNum(def)} / 20 KG')],
            ),
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                tExp(child: Btn(bi('સામાન્ય દર બદલો', 'Change common rate'), icon: 'edit', kind: BtnKind.tonal, dense: true, onTap: () => openPanel(ctx, title: bi('સામાન્ય દલાલી દર', 'Common brokerage rate'), width: 440, child: _BrokerRateForm(title: bi('જેનો અલગ દર ન હોય તે બધા દલાલ માટે', 'For every broker without his own rate'), keyId: '')))),
                const SizedBox(width: 8),
                tExp(child: Btn('WhatsApp', icon: 'chat', kind: BtnKind.tonal, dense: true, onTap: () => whatsappText(text()))),
              ],
            ),
            const SizedBox(height: 12),
            if (def <= 0 && total <= 0) noteBox('info', 'blue', bi('પહેલા દલાલીનો દર (₹ પ્રતિ 20 KG) નાખો', 'Set the brokerage rate (Rs per 20 KG) first')),
            if (l.isEmpty) EmptyBox(icon: 'users', title: bi('આ સમયમાં દલાલ નથી', 'No brokers in this period')),
            for (final _Brk b in l)
              lineItem(
                icon: 'users',
                tone: brokerHasOwnRate(b.key) ? 'violet' : 'teal',
                title: b.label,
                sub: '${kgTxt(b.kg)} · ${b.chits} ${bi('ચિઠ્ઠી', 'chits')} · ₹${plainNum(brokerRateOf(b.key))}/20 KG${brokerHasOwnRate(b.key) ? ' ★' : ''}',
                trailing: inr(b.kg / 20 * brokerRateOf(b.key)),
                onTap: () => openPanel(ctx, title: b.label, width: 440, child: _BrokerRateForm(title: bi('આ દલાલનો અલગ દર', 'This broker\'s own rate'), keyId: b.key)),
              ),
          ];
        },
      ),
    );
  }
}

// ======================================================================
// Labour wages by bags
// ======================================================================

class _WageForm extends StatefulWidget {
  const _WageForm();

  @override
  State<_WageForm> createState() => _WageFormState();
}

class _WageFormState extends State<_WageForm> {
  late final TextEditingController _in = TextEditingController(text: wageIn() <= 0 ? '' : plainNum(wageIn()));
  late final TextEditingController _out = TextEditingController(text: wageOut() <= 0 ? '' : plainNum(wageOut()));

  @override
  void dispose() {
    _in.dispose();
    _out.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        FieldX(label: bi('ઉતારવાની મજૂરી (અનલોડિંગ)', 'Unloading wage'), controller: _in, big: true, prefix: '₹', suffix: bi('/ બેગ', '/ bag'), keyboard: const TextInputType.numberWithOptions(decimal: true)),
        const SizedBox(height: 12),
        FieldX(label: bi('ભરવાની મજૂરી (લોડિંગ)', 'Loading wage'), controller: _out, big: true, prefix: '₹', suffix: bi('/ બેગ', '/ bag'), keyboard: const TextInputType.numberWithOptions(decimal: true)),
        const SizedBox(height: 16),
        Btn(bi('સેવ કરો', 'Save'), icon: 'check', expand: true, onTap: () async {
          await setWages(dbl(_in.text.replaceAll(',', '')), dbl(_out.text.replaceAll(',', '')));
          if (context.mounted) Navigator.of(context).pop();
        }),
      ],
    );
  }
}

class _WDay {
  final DateTime day;
  int inB = 0;
  int outB = 0;
  _WDay(this.day);
}

class WagesScreen extends StatefulWidget {
  const WagesScreen({super.key});

  @override
  State<WagesScreen> createState() => _WagesState();
}

class _WagesState extends State<WagesScreen> {
  RangeSel _sel = RangeSel(4);

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[prefDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 760,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final Period p = _sel.period;
          final List<MaalRow> ms = live.maals.where((MaalRow m) => p.has(m.date)).toList();
          final Map<String, _WDay> days = <String, _WDay>{};
          int inB = 0;
          int outB = 0;
          for (final MaalRow m in ms) {
            final _WDay d = days.putIfAbsent(dayKey(m.date), () => _WDay(dayOf(m.date)));
            if (m.loading) {
              d.outB += m.bags;
              outB += m.bags;
            } else {
              d.inB += m.bags;
              inB += m.bags;
            }
          }
          final List<_WDay> list = days.values.toList();
          list.sort((_WDay a, _WDay b) => b.day.compareTo(a.day));
          final double total = inB * wageIn() + outB * wageOut();
          final bool noRate = wageIn() <= 0 && wageOut() <= 0;

          String text() {
            final StringBuffer b = StringBuffer();
            b.writeln('Balaji Industries');
            b.writeln('${bi('મજૂરી હિસાબ', 'Labour wages')} - ${p.label}');
            b.writeln('------------------------');
            for (final _WDay d in list.reversed) {
              final double a = d.inB * wageIn() + d.outB * wageOut();
              b.writeln('${dm(d.day)}: ${bi('ઉતાર્યા', 'in')} ${d.inB} · ${bi('ભર્યા', 'out')} ${d.outB} = ${inr(a)}');
            }
            b.writeln('------------------------');
            b.writeln('${bi('કુલ', 'Total')}: ${bi('ઉતાર્યા', 'in')} $inB × ₹${plainNum(wageIn())} + ${bi('ભર્યા', 'out')} $outB × ₹${plainNum(wageOut())} = ${inr(total)}');
            return b.toString().trim();
          }

          return <Widget>[
            ScreenHeader(bi('મજૂરી હિસાબ', 'Labour wages'), sub: p.label),
            statusBanner(),
            RangeBar(sel: _sel, presets: const <int>[0, 1, 2, 3, 4, 5, 6], onChanged: (RangeSel s) => setState(() => _sel = s)),
            const SizedBox(height: 12),
            HeroCard(
              title: bi('કુલ મજૂરી', 'Total wages'),
              value: inr(total),
              unit: '',
              sub: '${bi('ઉતાર્યા', 'Unloaded')} $inB ${bi('બેગ', 'bags')} · ${bi('ભર્યા', 'loaded')} $outB ${bi('બેગ', 'bags')}',
              chips: <HeroChip>[
                HeroChip('dl', '₹${plainNum(wageIn())} / ${bi('બેગ', 'bag')}'),
                HeroChip('ul', '₹${plainNum(wageOut())} / ${bi('બેગ', 'bag')}'),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                tExp(child: Btn(bi('દર બદલો', 'Change rates'), icon: 'edit', kind: BtnKind.tonal, dense: true, onTap: () => openPanel(ctx, title: bi('મજૂરીના દર', 'Wage rates'), width: 440, child: const _WageForm()))),
                const SizedBox(width: 8),
                tExp(child: Btn('WhatsApp', icon: 'chat', kind: BtnKind.tonal, dense: true, onTap: () => whatsappText(text()))),
              ],
            ),
            const SizedBox(height: 12),
            if (noRate) noteBox('info', 'blue', bi('પહેલા ઉતારવા અને ભરવાનો દર (₹ પ્રતિ બેગ) નાખો', 'Set the unloading and loading wage (Rs per bag) first'), onTap: () => openPanel(ctx, title: bi('મજૂરીના દર', 'Wage rates'), width: 440, child: const _WageForm())),
            if (list.isEmpty) EmptyBox(icon: 'bag', title: bi('આ સમયમાં માલ એન્ટ્રી નથી', 'No maal entries in this period')),
            for (final _WDay d in list)
              lineItem(
                icon: 'bag',
                tone: 'amber',
                title: '${dayLabel(d.day)} · ${dm(d.day)}',
                sub: '${bi('ઉતાર્યા', 'in')} ${d.inB} · ${bi('ભર્યા', 'out')} ${d.outB} ${bi('બેગ', 'bags')}',
                trailing: inr(d.inB * wageIn() + d.outB * wageOut()),
              ),
          ];
        },
      ),
    );
  }
}

// ======================================================================
// Purchase bill (weight bill)
// ======================================================================

class _BillPanel extends StatefulWidget {
  final List<Chit> chits;
  final String title;
  const _BillPanel({required this.chits, required this.title});

  @override
  State<_BillPanel> createState() => _BillPanelState();
}

class _BillPanelState extends State<_BillPanel> {
  late final TextEditingController _rate = TextEditingController(text: _startRate());
  final TextEditingController _d1 = TextEditingController();
  final TextEditingController _d2 = TextEditingController();
  final TextEditingController _d3 = TextEditingController();

  String _startRate() {
    for (final Chit c in widget.chits) {
      final double? r = rateFor(c.commodity.trim(), c.at);
      if (r != null) return plainNum(r);
    }
    return '';
  }

  @override
  void dispose() {
    _rate.dispose();
    _d1.dispose();
    _d2.dispose();
    _d3.dispose();
    super.dispose();
  }

  String _bill(double rate, double kg, double amt, double ded, double net) {
    final StringBuffer b = StringBuffer();
    b.writeln('Balaji Industries');
    b.writeln(bi('ખરીદ બિલ', 'Purchase bill'));
    b.writeln(widget.title);
    b.writeln('------------------------');
    for (final Chit c in widget.chits) {
      final double k = payKg(c);
      b.writeln('${vtxt(c.farmer)}${c.village.isEmpty ? '' : ' (${c.village})'} #${c.no}');
      b.writeln('  ${bi('કુલ', 'Gross')} ${grp(c.gross, dec: 2)} - ${bi('બારદાન', 'bardan')} ${grp(c.bardan, dec: 2)} - ${bi('કરદો', 'kardo')} ${grp(c.kardo, dec: 2)} = ${grp(c.net, dec: 2)} KG');
      if (rate > 0) b.writeln('  ${grp(k, dec: 2)} KG × ₹${plainNum(rate)}/20 = ${inr(k / 20 * rate, dec: 2)}');
    }
    b.writeln('------------------------');
    b.writeln('${bi('કુલ વજન', 'Total weight')}: ${grp(kg, dec: 2)} KG');
    if (rate > 0) {
      b.writeln('${bi('ભાવ', 'Rate')}: ₹${plainNum(rate)} / 20 KG');
      b.writeln('${bi('રકમ', 'Amount')}: ${inr(amt, dec: 2)}');
    }
    if (ded > 0) {
      b.writeln('${bi('કપાત', 'Deductions')}: -${inr(ded, dec: 2)}');
      b.writeln('${bi('ચૂકવવાના', 'Payable')}: ${inr(net, dec: 2)}');
    }
    return b.toString().trim();
  }

  @override
  Widget build(BuildContext context) {
    final double rate = dbl(_rate.text.replaceAll(',', ''));
    double kg = 0;
    for (final Chit c in widget.chits) {
      kg += payKg(c);
    }
    final double amt = kg / 20 * rate;
    final double ded = dbl(_d1.text) + dbl(_d2.text) + dbl(_d3.text);
    final double net = amt - ded;
    final Set<String> farmers = <String>{for (final Chit c in widget.chits) nameKey(c.farmer)};
    String phone = '';
    if (farmers.length == 1 && widget.chits.isNotEmpty) phone = farmerMobile(farmers.first);
    final String text = _bill(rate, kg, amt, ded, net);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        for (final Chit c in widget.chits)
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Row(
              children: <Widget>[
                Expanded(child: Text('${vtxt(c.farmer)} · #${c.no}', maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(13.5, w: FontWeight.w700))),
                Text('${grp(c.gross, dec: 0)} - ${grp(c.bardan + c.kardo, dec: 0)} = ${grp(c.net, dec: 0)} KG', style: ts(13, c: Pal.muted, tab: true)),
              ],
            ),
          ),
        divider(),
        const SizedBox(height: 10),
        FieldX(label: bi('ભાવ', 'Rate'), controller: _rate, prefix: '₹', suffix: '/ 20 KG', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {})),
        const SizedBox(height: 10),
        Row(
          children: <Widget>[
            Expanded(child: FieldX(label: bi('મજૂરી કપાત', 'Labour'), controller: _d1, prefix: '₹', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {}))),
            const SizedBox(width: 8),
            Expanded(child: FieldX(label: bi('એડવાન્સ કપાત', 'Advance'), controller: _d2, prefix: '₹', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {}))),
            const SizedBox(width: 8),
            Expanded(child: FieldX(label: bi('બીજી કપાત', 'Other'), controller: _d3, prefix: '₹', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {}))),
          ],
        ),
        const SizedBox(height: 12),
        InfoRow(bi('વજન (ભાવ માટેનું)', 'Weight (for rate)'), '${grp(kg, dec: 2)} KG'),
        InfoRow(bi('રકમ', 'Amount'), inr(amt, dec: 2)),
        if (ded > 0) InfoRow(bi('કપાત', 'Deductions'), '-${inr(ded, dec: 2)}'),
        InfoRow(bi('ચૂકવવાના', 'Payable'), inr(net, dec: 2), bold: true, color: Pal.brand),
        const SizedBox(height: 12),
        Row(
          children: <Widget>[
            tExp(child: Btn('WhatsApp', icon: 'chat', onTap: () => whatsappText(text, phone: phone))),
            const SizedBox(width: 8),
            tExp(child: Btn(bi('કૉપિ', 'Copy'), icon: 'copy', kind: BtnKind.tonal, onTap: () => copyText(text))),
          ],
        ),
      ],
    );
  }
}

class WeightBillScreen extends StatefulWidget {
  const WeightBillScreen({super.key});

  @override
  State<WeightBillScreen> createState() => _WeightBillState();
}

class _WeightBillState extends State<WeightBillScreen> {
  final TextEditingController _q = TextEditingController();
  int _by = 0; // 0 vehicle, 1 farmer
  RangeSel _sel = RangeSel(4);
  final TextEditingController _farmer = TextEditingController();

  @override
  void dispose() {
    _q.dispose();
    _farmer.dispose();
    super.dispose();
  }

  void _open(BuildContext ctx, List<Chit> chits, String title, String sub) {
    openPanel(ctx, title: title, sub: sub, width: 520, child: _BillPanel(chits: chits, title: '$title · $sub'));
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[rateDoc, prefDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 780,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final List<Widget> out = <Widget>[
            ScreenHeader(bi('ખરીદ બિલ', 'Purchase bill'), sub: bi('ચિઠ્ઠી પરથી ભાવ સાથે બિલ', 'Bill with rate from the chits')),
            statusBanner(),
            Seg(labels: <String>[bi('ગાડી મુજબ', 'By vehicle'), bi('ખેડૂત મુજબ', 'By farmer')], index: _by, onChanged: (int i) => setState(() => _by = i)),
            const SizedBox(height: 12),
          ];
          if (_by == 0) {
            final String q = _q.text.trim().toLowerCase();
            final List<Trip> tl = live.trips.where((Trip t) => t.chits.isNotEmpty).toList();
            tl.sort((Trip a, Trip b) => b.at.compareTo(a.at));
            final List<Trip> shown = tl.where((Trip t) => q.isEmpty || t.vehicle.toLowerCase().contains(q) || t.farmers.toLowerCase().contains(q) || t.villages.toLowerCase().contains(q)).take(60).toList();
            out.add(SearchBox(hint: bi('ગાડી, ખેડૂત કે ગામ', 'Vehicle, farmer or village'), controller: _q, onChanged: (String _) => setState(() {})));
            out.add(const SizedBox(height: 12));
            if (shown.isEmpty) out.add(EmptyBox(icon: 'truck', title: bi('કોઈ ગાડી મળી નથી', 'No vehicle found')));
            for (final Trip t in shown) {
              out.add(lineItem(
                icon: 'truck',
                tone: stateTone(t.state),
                title: vtxt(t.vehicle),
                sub: '${t.farmers}${t.villages.isEmpty ? '' : ' · ${t.villages}'}',
                trailing: '${grp(t.chitKg)} KG',
                trailingSub: whenTxt(t.at),
                onTap: () => _open(ctx, t.chits, t.vehicle, dmy(t.at)),
              ));
            }
          } else {
            final Period p = _sel.period;
            final List<PartySummary> dir = directoryOf(Dim.farmer);
            dir.sort((PartySummary a, PartySummary b) => b.last.compareTo(a.last));
            final String key = nameKey(_farmer.text);
            final List<Chit> cs = key.isEmpty ? <Chit>[] : (live.chits.where((Chit c) => nameKey(c.farmer) == key && p.has(c.at)).toList()..sort((Chit a, Chit b) => a.at.compareTo(b.at)));
            out.add(SuggestField(label: bi('ખેડૂત', 'Farmer'), controller: _farmer, options: <String>[for (final PartySummary s in dir.take(400)) s.ref.label], onChanged: (String v) => setState(() {}), onPick: (String v) => setState(() {})));
            out.add(const SizedBox(height: 10));
            out.add(RangeBar(sel: _sel, presets: const <int>[2, 3, 4, 5, 6], onChanged: (RangeSel s) => setState(() => _sel = s)));
            out.add(const SizedBox(height: 12));
            if (cs.isEmpty) {
              out.add(EmptyBox(icon: 'agri', title: bi('ઉપરથી ખેડૂત પસંદ કરો', 'Pick a farmer above'), sub: key.isEmpty ? null : bi('આ સમયમાં ચિઠ્ઠી નથી', 'No chits in this period')));
            } else {
              double kg = 0;
              for (final Chit c in cs) {
                kg += payKg(c);
              }
              out.add(lineItem(icon: 'receipt', tone: 'teal', title: '${cs.length} ${bi('ચિઠ્ઠી', 'chits')}', sub: p.label, trailing: '${grp(kg)} KG'));
              out.add(const SizedBox(height: 8));
              out.add(Btn(bi('બિલ બનાવો', 'Make the bill'), icon: 'receipt', expand: true, onTap: () => _open(ctx, cs, _farmer.text.trim(), p.label)));
            }
          }
          return out;
        },
      ),
    );
  }
}

// ======================================================================
// Cost calculator
// ======================================================================

class CostCalcScreen extends StatefulWidget {
  const CostCalcScreen({super.key});

  @override
  State<CostCalcScreen> createState() => _CostCalcState();
}

class _CostCalcState extends State<CostCalcScreen> {
  final TextEditingController _mat = TextEditingController();
  final TextEditingController _buy = TextEditingController();
  final TextEditingController _brk = TextEditingController();
  final TextEditingController _lab = TextEditingController();
  final TextEditingController _bag = TextEditingController(text: '50');
  final TextEditingController _fr = TextEditingController();
  final TextEditingController _oth = TextEditingController();
  final TextEditingController _shr = TextEditingController();
  final TextEditingController _mar = TextEditingController();
  final TextEditingController _sale = TextEditingController();
  final TextEditingController _qty = TextEditingController(text: '20000');

  @override
  void initState() {
    super.initState();
    rateDoc.ensure();
    prefDoc.ensure();
  }

  @override
  void dispose() {
    for (final TextEditingController c in <TextEditingController>[_mat, _buy, _brk, _lab, _bag, _fr, _oth, _shr, _mar, _sale, _qty]) {
      c.dispose();
    }
    super.dispose();
  }

  void _fillFromSaved() {
    final String code = commodityCode(_mat.text.trim());
    final double? r = rateFor(code.isEmpty ? _mat.text.trim() : code, DateTime.now());
    if (r != null) _buy.text = plainNum(r);
    if (brokerRateDefault() > 0) _brk.text = plainNum(brokerRateDefault());
    if (wageIn() > 0 && _lab.text.isEmpty) _lab.text = plainNum(wageIn());
    setState(() {});
  }

  double _n(TextEditingController c) => dbl(c.text.replaceAll(',', ''));

  @override
  Widget build(BuildContext context) {
    final double buy = _n(_buy);
    final double brk = _n(_brk);
    final double bagKg = _n(_bag) <= 0 ? 50 : _n(_bag);
    final double lab = _n(_lab) * 20 / bagKg;
    final double fr = _n(_fr) * 20 / 1000;
    final double oth = _n(_oth) * 20 / 1000;
    final double base = buy + brk + lab + fr + oth;
    final double shr = _n(_shr).clamp(0, 50).toDouble();
    final double cost = shr >= 100 ? base : base / (1 - shr / 100);
    final double margin = _n(_mar);
    final double need = cost + margin;
    final double sale = _n(_sale);
    final double profit = sale - cost;
    final double qty = _n(_qty);
    final bool any = buy > 0;

    String text() {
      final StringBuffer b = StringBuffer();
      b.writeln('Balaji Industries - ${bi('કિંમત ગણતરી', 'Cost sheet')}');
      b.writeln('${bi('ખરીદ ભાવ', 'Buy rate')}: ₹${plainNum(buy)} / 20 KG');
      b.writeln('${bi('દલાલી', 'Brokerage')}: ₹${plainNum(brk)}');
      b.writeln('${bi('મજૂરી', 'Labour')}: ₹${lab.toStringAsFixed(2)}');
      b.writeln('${bi('ભાડું', 'Freight')}: ₹${fr.toStringAsFixed(2)}');
      b.writeln('${bi('બીજું', 'Other')}: ₹${oth.toStringAsFixed(2)}');
      if (shr > 0) b.writeln('${bi('ઘટ', 'Loss')}: ${shr.toStringAsFixed(2)}%');
      b.writeln('------------------------');
      b.writeln('${bi('કિંમત', 'Cost')}: ₹${cost.toStringAsFixed(2)} / 20 KG');
      if (sale > 0) b.writeln('${bi('વેચાણ', 'Sale')}: ₹${plainNum(sale)} → ${bi('નફો', 'profit')} ₹${profit.toStringAsFixed(2)} / 20 KG');
      return b.toString().trim();
    }

    final Widget inputs = Panel(
      title: bi('ખર્ચ નાખો', 'Enter the costs'),
      sub: bi('બધા ₹ પ્રતિ 20 KG (મણ) મુજબ, જ્યાં લખ્યું ન હોય', 'All Rs per 20 KG (mann) unless written otherwise'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          SuggestField(label: bi('માલ (ભાવ આપમેળે ભરાશે)', 'Material (fills the rate)'), controller: _mat, options: <String>[for (final String n in materialNames()) matLabel(n)], onPick: (String _) => _fillFromSaved()),
          const SizedBox(height: 10),
          Row(children: <Widget>[
            Expanded(child: FieldX(label: bi('ખરીદ ભાવ', 'Buy rate'), controller: _buy, prefix: '₹', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {}))),
            const SizedBox(width: 10),
            Expanded(child: FieldX(label: bi('દલાલી', 'Brokerage'), controller: _brk, prefix: '₹', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {}))),
          ]),
          const SizedBox(height: 10),
          Row(children: <Widget>[
            Expanded(child: FieldX(label: bi('મજૂરી (પ્રતિ બેગ)', 'Labour (per bag)'), controller: _lab, prefix: '₹', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {}))),
            const SizedBox(width: 10),
            Expanded(child: FieldX(label: bi('બેગનું વજન', 'Bag weight'), controller: _bag, suffix: 'KG', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {}))),
          ]),
          const SizedBox(height: 10),
          Row(children: <Widget>[
            Expanded(child: FieldX(label: bi('ભાડું (પ્રતિ ટન)', 'Freight (per ton)'), controller: _fr, prefix: '₹', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {}))),
            const SizedBox(width: 10),
            Expanded(child: FieldX(label: bi('બીજા ખર્ચ (પ્રતિ ટન)', 'Other (per ton)'), controller: _oth, prefix: '₹', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {}))),
          ]),
          const SizedBox(height: 10),
          FieldX(label: bi('ઘટ / ખોટ', 'Loss / shrink'), controller: _shr, suffix: '%', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {})),
        ],
      ),
    );

    final Widget result = Panel(
      title: bi('પરિણામ', 'Result'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          InfoRow(bi('ખરીદ + દલાલી', 'Buy + brokerage'), '₹${(buy + brk).toStringAsFixed(2)}'),
          InfoRow(bi('મજૂરી', 'Labour'), '₹${lab.toStringAsFixed(2)}'),
          InfoRow(bi('ભાડું + બીજા', 'Freight + other'), '₹${(fr + oth).toStringAsFixed(2)}'),
          if (shr > 0) InfoRow(bi('ઘટના કારણે વધારો', 'Added by the loss'), '₹${(cost - base).toStringAsFixed(2)}'),
          divider(),
          InfoRow(bi('કિંમત / 20 KG', 'Cost / 20 KG'), '₹${cost.toStringAsFixed(2)}', bold: true, color: Pal.brand),
          InfoRow(bi('કિંમત / KG', 'Cost / KG'), '₹${(cost / 20).toStringAsFixed(2)}'),
          InfoRow(bi('કિંમત / ક્વિન્ટલ', 'Cost / quintal'), '₹${grp(cost * 5)}'),
          InfoRow(bi('કિંમત / ટન', 'Cost / ton'), '₹${grp(cost * 50)}'),
          const SizedBox(height: 14),
          FieldX(label: bi('જોઈતો નફો', 'Wanted profit'), controller: _mar, prefix: '₹', suffix: '/ 20 KG', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {})),
          if (any && margin > 0) InfoRow(bi('વેચાણ ભાવ આટલો જોઈએ', 'Sale rate needed'), '₹${need.toStringAsFixed(2)} / 20 KG', bold: true, color: Pal.ok),
          const SizedBox(height: 10),
          FieldX(label: bi('વેચાણ ભાવ (જો નક્કી હોય)', 'Sale rate (if known)'), controller: _sale, prefix: '₹', suffix: '/ 20 KG', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {})),
          const SizedBox(height: 10),
          FieldX(label: bi('જથ્થો', 'Quantity'), controller: _qty, suffix: 'KG', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {})),
          if (any && sale > 0) ...<Widget>[
            const SizedBox(height: 6),
            InfoRow(bi('નફો / 20 KG', 'Profit / 20 KG'), '₹${profit.toStringAsFixed(2)}', bold: true, color: profit >= 0 ? Pal.ok : Pal.bad),
            InfoRow(bi('નફો %', 'Profit %'), cost > 0 ? '${(profit / cost * 100).toStringAsFixed(2)}%' : '—'),
            if (qty > 0) InfoRow(bi('કુલ નફો (${grp(qty)} KG)', 'Total profit (${grp(qty)} KG)'), inr(profit * qty / 20), bold: true, color: profit >= 0 ? Pal.ok : Pal.bad),
          ],
          const SizedBox(height: 12),
          Row(children: <Widget>[
            tExp(child: Btn('WhatsApp', icon: 'chat', onTap: () => whatsappText(text()))),
            const SizedBox(width: 8),
            tExp(child: Btn(bi('કૉપિ', 'Copy'), icon: 'copy', kind: BtnKind.tonal, onTap: () => copyText(text()))),
          ]),
        ],
      ),
    );

    return LiveBody(
      maxWidth: 1000,
      rows: (BuildContext ctx) => <Widget>[
        ScreenHeader(bi('કિંમત અને નફાની ગણતરી', 'Cost and profit calculator'), sub: bi('ખરીદથી વેચાણ સુધીનો હિસાબ', 'From buying to selling')),
        SplitPane(children: <Widget>[inputs, result]),
      ],
    );
  }
}

// ======================================================================
// Rate chart
// ======================================================================

class RateChartScreen extends StatefulWidget {
  const RateChartScreen({super.key});

  @override
  State<RateChartScreen> createState() => _RateChartState();
}

class _RateChartState extends State<RateChartScreen> {
  int _mat = 0;
  int _span = 1;
  static const List<int> _spans = <int>[30, 60, 90];

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[rateDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 800,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final List<String> withRate = <String>[];
          final Object? all = rateDoc.data['rates'];
          if (all is Map) {
            for (final String n in materialNames()) {
              if (all[n] is Map && (all[n] as Map).isNotEmpty) withRate.add(n);
            }
          }
          if (withRate.isEmpty) {
            return <Widget>[
              ScreenHeader(bi('ભાવનો ચાર્ટ', 'Rate chart')),
              statusBanner(),
              EmptyBox(icon: 'rupee', title: bi('હજુ કોઈ ભાવ નથી', 'No rate saved yet'), sub: bi('"ભાવ" સ્ક્રીનમાં ભાવ નાખો', 'Add rates in the Rates screen')),
              Btn(bi('ભાવ નાખો', 'Add rates'), icon: 'plus', onTap: () => app.go('rates')),
            ];
          }
          final String m = withRate[_mat >= withRate.length ? 0 : _mat];
          final int n = _spans[_span];
          final DateTime today = dayOf(DateTime.now());
          final List<double> vals = <double>[];
          final List<String> labs = <String>[];
          double? prevV;
          double hi = 0;
          double lo = 1e12;
          double sum = 0;
          int cnt = 0;
          for (int i = n - 1; i >= 0; i--) {
            final DateTime d = addDays(today, -i);
            final double? r = rateFor(m, d);
            final double v = r ?? prevV ?? 0;
            if (r != null) {
              prevV = r;
              if (r > hi) hi = r;
              if (r < lo) lo = r;
              sum += r;
              cnt++;
            }
            vals.add(v);
            labs.add(axisDay(n - 1 - i, n, d));
          }
          final double cur = rateFor(m, today) ?? 0;
          double? weekAgo = rateFor(m, addDays(today, -7));
          double? monthAgo = rateFor(m, addDays(today, -30));
          // average rate actually paid this month from the chits
          final DateTime ms = DateTime(today.year, today.month, 1);
          double paidKg = 0;
          double paidAmt = 0;
          for (final Chit c in live.chits) {
            if (c.at.isBefore(ms) || c.commodity.trim().toLowerCase() != m.toLowerCase()) continue;
            final double? a = chitAmount(c);
            if (a == null) continue;
            paidKg += payKg(c);
            paidAmt += a;
          }
          final List<MapEntry<String, double>> hist = ratesOfMaterial(m);

          return <Widget>[
            ScreenHeader(bi('ભાવનો ચાર્ટ', 'Rate chart'), sub: bi('₹ પ્રતિ 20 KG', 'Rs per 20 KG')),
            statusBanner(),
            ChipRow(labels: <String>[for (final String x in withRate) matLabel(x)], index: _mat >= withRate.length ? 0 : _mat, onChanged: (int i) => setState(() => _mat = i)),
            const SizedBox(height: 10),
            Seg(labels: <String>[bi('30 દિવસ', '30 days'), bi('60 દિવસ', '60 days'), bi('90 દિવસ', '90 days')], index: _span, onChanged: (int i) => setState(() => _span = i), dense: true),
            const SizedBox(height: 12),
            HeroCard(
              title: '${matLabel(m)} · ${bi('આજનો ભાવ', 'today\'s rate')}',
              value: '₹${grp(cur)}',
              unit: '/ 20 KG',
              sub: '₹${(cur / 20).toStringAsFixed(2)} / KG · ₹${grp(cur * 5)} / ${bi('ક્વિન્ટલ', 'quintal')}',
              chips: <HeroChip>[
                if (weekAgo != null && weekAgo > 0) HeroChip(cur >= weekAgo ? 'arrowup' : 'arrowdown', '${bi('અઠવાડિયામાં', '7 days')} ${cur >= weekAgo ? '+' : ''}${grp(cur - weekAgo)}'),
                if (monthAgo != null && monthAgo > 0) HeroChip(cur >= monthAgo ? 'arrowup' : 'arrowdown', '${bi('મહિનામાં', '30 days')} ${cur >= monthAgo ? '+' : ''}${grp(cur - monthAgo)}'),
              ],
            ),
            const SizedBox(height: 12),
            Panel(
              title: bi('ભાવની ચાલ', 'Rate movement'),
              child: LineChartX(
                series: <LineSeries>[LineSeries(matLabel(m), vals, Pal.brand)],
                labels: labs,
                axisFmt: (double v) => grp(v),
                height: 200,
              ),
            ),
            const SizedBox(height: 12),
            metricGrid(ctx, <Widget>[
              MetricTile(label: bi('સૌથી ઊંચો', 'Highest'), value: cnt == 0 ? '—' : '₹${grp(hi)}', icon: 'arrowup', tone: 'rose'),
              MetricTile(label: bi('સૌથી નીચો', 'Lowest'), value: cnt == 0 ? '—' : '₹${grp(lo)}', icon: 'arrowdown', tone: 'green'),
              MetricTile(label: bi('સરેરાશ ભાવ', 'Average rate'), value: cnt == 0 ? '—' : '₹${grp(sum / cnt)}', icon: 'pct', tone: 'blue'),
              MetricTile(label: bi('આ મહિને ખરેખર સરેરાશ', 'Actually paid this month'), value: paidKg <= 0 ? '—' : '₹${grp(paidAmt / paidKg * 20)}', icon: 'rupee', tone: 'violet', sub: paidKg <= 0 ? null : kgTxt(paidKg)),
            ], pcCols: 4),
            const SizedBox(height: 12),
            caption(bi('ભાવ ફેરફારની યાદી', 'Rate changes')),
            for (final MapEntry<String, double> e in hist.take(15))
              lineItem(icon: 'rupee', tone: 'green', title: e.key, trailing: '₹${grp(e.value)}'),
            const SizedBox(height: 6),
            Btn(bi('ભાવ બદલો / ઉમેરો', 'Change / add a rate'), icon: 'edit', kind: BtnKind.outline, expand: true, onTap: () => app.go('rates')),
          ];
        },
      ),
    );
  }
}

// ======================================================================
// Month closing sheet
// ======================================================================

class MonthCloseScreen extends StatefulWidget {
  const MonthCloseScreen({super.key});

  @override
  State<MonthCloseScreen> createState() => _MonthCloseState();
}

class _MonthCloseState extends State<MonthCloseScreen> {
  DateTime _m = DateTime(DateTime.now().year, DateTime.now().month, 1);

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[payDoc, expDoc, rateDoc, prefDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 760,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final DateTime nx = DateTime(_m.year, _m.month + 1, 1);
          final Period p = Period(_m, nx);
          int chitN = 0;
          double chitKg = 0;
          double value = 0;
          double noRateKg = 0;
          double brokerage = 0;
          for (final Chit c in live.chits) {
            if (!p.has(c.at)) continue;
            chitN++;
            final double k = payKg(c);
            chitKg += k;
            final double? a = chitAmount(c);
            if (a == null) {
              noRateKg += k;
            } else {
              value += a;
            }
            if (c.broker.trim().isNotEmpty) brokerage += k / 20 * brokerRateOf(nameKey(c.broker));
          }
          double kantaKg = 0;
          int kantaN = 0;
          for (final Kanta k in live.kantas) {
            if (!p.has(k.at)) continue;
            kantaN++;
            kantaKg += k.kg;
          }
          final List<MaalRow> ms = live.maals.where((MaalRow r) => p.has(r.date)).toList();
          final double wages = wagesOf(ms);
          int bagsIn = 0;
          int bagsOut = 0;
          for (final MaalRow r in ms) {
            if (r.loading) {
              bagsOut += r.bags;
            } else {
              bagsIn += r.bags;
            }
          }
          double paid = 0;
          for (final PayItem x in payItems()) {
            if (x.kind == 'open' || x.kind == 'recv' || !p.has(x.date)) continue;
            paid += x.amt;
          }
          double exp = 0;
          double inc = 0;
          final Map<String, double> byCat = <String, double>{};
          for (final ExpItem x in expItems()) {
            if (!p.has(x.date)) continue;
            if (x.isIn) {
              inc += x.amt;
            } else if (x.cat != kGstHead) {
              exp += x.amt;
              byCat[x.cat] = (byCat[x.cat] ?? 0) + x.amt;
            }
          }
          final double totalCost = value + brokerage + wages + exp;
          final double per20 = kantaKg > 0 ? totalCost / (kantaKg / 20) : 0;

          String text() {
            final StringBuffer b = StringBuffer();
            b.writeln('Balaji Industries');
            b.writeln('${bi('મહિનાનું બંધ-પત્રક', 'Month closing')} - ${monthYear(_m)}');
            b.writeln('------------------------');
            b.writeln('${bi('ચિઠ્ઠી', 'Chits')}: $chitN · ${grp(chitKg)} KG');
            b.writeln('${bi('કાંટો', 'Kanta')}: $kantaN · ${grp(kantaKg)} KG');
            b.writeln('${bi('માલ બેગ', 'Maal bags')}: ${bi('આવ્યા', 'in')} $bagsIn · ${bi('ગયા', 'out')} $bagsOut');
            b.writeln('------------------------');
            b.writeln('${bi('ખરીદ રકમ', 'Purchase')}: ${inr(value)}');
            b.writeln('${bi('દલાલી', 'Brokerage')}: ${inr(brokerage)}');
            b.writeln('${bi('મજૂરી', 'Labour')}: ${inr(wages)}');
            b.writeln('${bi('બીજા ખર્ચ', 'Expenses')}: ${inr(exp)}');
            b.writeln('------------------------');
            b.writeln('${bi('કુલ ખર્ચ', 'Total cost')}: ${inr(totalCost)}');
            if (per20 > 0) b.writeln('${bi('કિંમત / 20 KG (કાંટા મુજબ)', 'Cost / 20 KG (by kanta)')}: ₹${per20.toStringAsFixed(2)}');
            b.writeln('${bi('ખેડૂતોને ચૂકવ્યા', 'Paid to farmers')}: ${inr(paid)}');
            if (inc > 0) b.writeln('${bi('આવક', 'Income')}: ${inr(inc)}');
            return b.toString().trim();
          }

          final List<MapEntry<String, double>> cats = byCat.entries.toList();
          cats.sort((MapEntry<String, double> a, MapEntry<String, double> b) => b.value.compareTo(a.value));

          return <Widget>[
            ScreenHeader(bi('મહિનાનું બંધ-પત્રક', 'Month closing'), sub: monthYear(_m)),
            statusBanner(),
            Row(
              children: <Widget>[
                IconBtn('chevl', tip: bi('પાછલો મહિનો', 'Previous month'), onTap: () => setState(() => _m = DateTime(_m.year, _m.month - 1, 1))),
                Expanded(child: Center(child: Text(monthYear(_m), style: ts(17, w: FontWeight.w800)))),
                IconBtn('chev', tip: bi('આગળનો મહિનો', 'Next month'), onTap: nx.isAfter(DateTime.now()) ? null : () => setState(() => _m = nx)),
              ],
            ),
            const SizedBox(height: 10),
            HeroCard(
              title: bi('કુલ ખર્ચ (ખરીદ + દલાલી + મજૂરી + ખર્ચ)', 'Total cost (purchase + brokerage + labour + expenses)'),
              value: inrC(totalCost),
              unit: '',
              sub: per20 > 0 ? '₹${per20.toStringAsFixed(2)} / 20 KG ${bi('(કાંટા મુજબ)', '(by kanta)')}' : null,
              chips: <HeroChip>[
                HeroChip('scale', kgTxt(kantaKg)),
                HeroChip('rupee', '${bi('ચૂકવ્યા', 'Paid')} ${inrC(paid)}'),
              ],
            ),
            const SizedBox(height: 12),
            if (noRateKg > 0) noteBox('info', 'amber', bi('${kgTxt(noRateKg)} નો ભાવ નાખ્યો નથી (ખરીદ રકમમાં ગણ્યો નથી)', '${kgTxt(noRateKg)} has no rate (not counted)'), onTap: () => app.go('rates')),
            Panel(
              title: bi('હિસાબ', 'Accounts'),
              child: Column(
                children: <Widget>[
                  InfoRow(bi('ચિઠ્ઠી', 'Chits'), '$chitN · ${grp(chitKg)} KG'),
                  InfoRow(bi('કાંટો', 'Weighbridge'), '$kantaN · ${grp(kantaKg)} KG'),
                  InfoRow(bi('માલ બેગ આવ્યા / ગયા', 'Maal bags in / out'), '$bagsIn / $bagsOut'),
                  divider(),
                  InfoRow(bi('ખરીદ રકમ', 'Purchase value'), inr(value)),
                  InfoRow(bi('દલાલી', 'Brokerage'), inr(brokerage)),
                  InfoRow(bi('મજૂરી (બેગ મુજબ)', 'Labour (by bags)'), inr(wages)),
                  InfoRow(bi('બીજા ખર્ચ', 'Other expenses'), inr(exp)),
                  InfoRow(bi('કુલ ખર્ચ', 'Total cost'), inr(totalCost), bold: true, color: Pal.brand),
                  divider(),
                  InfoRow(bi('ખેડૂતોને ચૂકવ્યા', 'Paid to farmers'), inr(paid)),
                  if (inc > 0) InfoRow(bi('આવક', 'Income'), inr(inc)),
                ],
              ),
            ),
            if (cats.isNotEmpty) ...<Widget>[
              const SizedBox(height: 12),
              Panel(
                title: bi('બીજા ખર્ચ', 'Other expenses'),
                child: Column(children: <Widget>[for (final MapEntry<String, double> e in cats) InfoRow(expCatLabel(e.key), inr(e.value))]),
              ),
            ],
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                tExp(child: Btn('WhatsApp', icon: 'chat', onTap: () => whatsappText(text()))),
                const SizedBox(width: 8),
                tExp(child: Btn(bi('કૉપિ', 'Copy'), icon: 'copy', kind: BtnKind.tonal, onTap: () => copyText(text()))),
              ],
            ),
          ];
        },
      ),
    );
  }
}

// ======================================================================
// Expected vehicles (bookings)
// ======================================================================

class BookingsScreen extends StatefulWidget {
  const BookingsScreen({super.key});

  @override
  State<BookingsScreen> createState() => _BookingsState();
}

class _BookingsState extends State<BookingsScreen> {
  late final VoidCallback _accept = () {
    _save();
  };

  @override
  void initState() {
    super.initState();
    AcceptHub.push(_accept);
  }

  final TextEditingController _veh = TextEditingController();
  final TextEditingController _party = TextEditingController();
  final TextEditingController _kg = TextEditingController();
  final TextEditingController _note = TextEditingController();
  String _material = '';
  DateTime _day = dateOnly(DateTime.now());

  @override
  void dispose() {
    _veh.dispose();
    _party.dispose();
    _kg.dispose();
    _note.dispose();
    AcceptHub.pop(_accept);
    super.dispose();
  }

  Future<void> _pick() async {
    final DateTime? d = await pickDay(context, _day, first: dateOnly(DateTime.now()).subtract(const Duration(days: 7)));
    if (d != null && mounted) setState(() => _day = d);
  }

  Future<void> _save() async {
    final String vk = vehicleKey(_veh.text);
    if (vk.isEmpty) {
      app.toast(bi('ગાડી નંબર લખો', 'Enter the vehicle number'));
      return;
    }
    await bookDoc.commit(() {
      bookDoc.list('items').add(<String, dynamic>{
        'id': '${DateTime.now().microsecondsSinceEpoch}',
        'vehicle': vk,
        'party': _party.text.trim(),
        'material': _material,
        'kg': dbl(_kg.text.replaceAll(',', '')),
        'date': dayKey(_day),
        'note': _note.text.trim(),
        'done': false,
        'at': DateTime.now().toIso8601String(),
      });
    });
    _veh.clear();
    _party.clear();
    _kg.clear();
    _note.clear();
    if (mounted) setState(() {});
    app.toast(bi('ગાડીની નોંધ થઈ', 'Vehicle noted'));
  }

  Future<void> _toggle(String id) async {
    await bookDoc.commit(() {
      for (final Map<String, dynamic> m in bookDoc.list('items')) {
        if ('${m['id']}' == id) m['done'] = m['done'] != true;
      }
    });
  }

  Future<void> _remove(String id) async {
    await bookDoc.commit(() {
      bookDoc.list('items').removeWhere((Map<String, dynamic> m) => '${m['id']}' == id);
    });
  }

  /// A chit or weighbridge entry of this vehicle on or after the day it was expected.
  bool _arrived(String vk, DateTime day) {
    for (final Chit c in live.chits) {
      if (c.vkey == vk && !c.at.isBefore(day)) return true;
    }
    for (final Kanta k in live.kantas) {
      if (k.vkey == vk && !k.at.isBefore(day)) return true;
    }
    return false;
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[bookDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 760,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final DateTime today = dayOf(DateTime.now());
          final List<Map<String, dynamic>> items = bookDoc.list('items');
          final List<Map<String, dynamic>> open = <Map<String, dynamic>>[];
          final List<Map<String, dynamic>> done = <Map<String, dynamic>>[];
          for (final Map<String, dynamic> m in items) {
            if (m['done'] == true) {
              done.add(m);
            } else {
              open.add(m);
            }
          }
          open.sort((Map<String, dynamic> a, Map<String, dynamic> b) => '${a['date']}'.compareTo('${b['date']}'));
          done.sort((Map<String, dynamic> a, Map<String, dynamic> b) => '${b['date']}'.compareTo('${a['date']}'));
          final List<String> vehicles = <String>[...recentValues(live.chits.map((Chit c) => c.vehicle)), ...kVehicles];
          final List<String> farmers = recentValues(live.chits.map((Chit c) => c.farmer));

          Widget row(Map<String, dynamic> m) {
            final String vk = '${m['vehicle'] ?? ''}';
            final DateTime d = dayOf(DateTime.tryParse('${m['date'] ?? ''}') ?? today);
            final bool isDone = m['done'] == true;
            final bool came = _arrived(vk, d);
            final bool isLate = !came && d.isBefore(today) && !isDone;
            final double kg = dbl(m['kg']);
            final String party = '${m['party'] ?? ''}';
            final String mat = '${m['material'] ?? ''}';
            final String note = '${m['note'] ?? ''}';
            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Surface(
                padding: const EdgeInsets.fromLTRB(12, 10, 4, 10),
                child: Row(
                  children: <Widget>[
                    IconChip('truck', tone: isDone ? 'slate' : (came ? 'green' : (isLate ? 'rose' : 'amber')), size: 38),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              Flexible(child: Text(vk, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14.5, w: FontWeight.w800))),
                              const SizedBox(width: 8),
                              if (came && !isDone) Pill(bi('આવી ગઈ', 'Arrived'), tone: 'green', small: true) else if (isLate) Pill(bi('મોડી', 'Late'), tone: 'rose', small: true) else if (!isDone) Pill(dayLabel(d), tone: 'amber', small: true),
                            ],
                          ),
                          Text(
                            <String>[if (party.isNotEmpty) party, if (mat.isNotEmpty) matLabel(mat), if (kg > 0) kgTxt(kg), if (note.isNotEmpty) note].join(' · '),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: ts(12.5, c: Pal.muted),
                          ),
                        ],
                      ),
                    ),
                    IconBtn(isDone ? 'check' : 'circle', size: 40, color: isDone ? Pal.ok : Pal.muted, tip: bi('પૂરું', 'Done'), onTap: () => _toggle('${m['id']}')),
                    IconBtn('trash', size: 38, tip: bi('કાઢો', 'Delete'), onTap: () => _remove('${m['id']}')),
                  ],
                ),
              ),
            );
          }

          return <Widget>[
            ScreenHeader(bi('આવનારી ગાડી', 'Expected vehicles'), sub: bi('${open.length} બાકી', '${open.length} open')),
            statusBanner(),
            Panel(
              title: bi('નવી ગાડી નોંધો', 'Note a vehicle'),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  SuggestField(label: '${bi('ગાડી નંબર', 'Vehicle number')} *', controller: _veh, options: vehicles),
                  const SizedBox(height: 10),
                  SuggestField(label: bi('પાર્ટી / ખેડૂત', 'Party / farmer'), controller: _party, options: farmers),
                  const SizedBox(height: 10),
                  LineRow(label: bi('માલ', 'Material'), child: ChipRow(
                    labels: <String>[for (final List<String> x in kCommodities) bi(x[1], x[2])],
                    index: kCommodities.indexWhere((List<String> x) => x[0] == _material),
                    onChanged: (int i) => setState(() => _material = kCommodities[i][0]),
                  )),
                  const SizedBox(height: 10),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: <Widget>[
                      Expanded(child: FieldX(label: bi('અંદાજ વજન', 'Expected weight'), controller: _kg, suffix: 'KG', keyboard: const TextInputType.numberWithOptions(decimal: true))),
                      const SizedBox(width: 10),
                      dayButton(_day, _pick),
                    ],
                  ),
                  const SizedBox(height: 10),
                  FieldX(label: bi('નોંધ', 'Note'), controller: _note),
                  const SizedBox(height: 14),
                  Btn(bi('નોંધો', 'Save'), icon: 'check', expand: true, onTap: _save),
                ],
              ),
            ),
            const SizedBox(height: 14),
            if (open.isEmpty) EmptyBox(icon: 'truck', title: bi('કોઈ ગાડી બાકી નથી', 'No vehicle expected')),
            if (open.isNotEmpty) _head(bi('આવવાની બાકી', 'Expected')),
            for (final Map<String, dynamic> m in open) row(m),
            if (done.isNotEmpty) _head(bi('પૂરી થયેલી', 'Done')),
            for (final Map<String, dynamic> m in done.take(15)) row(m),
          ];
        },
      ),
    );
  }
}
