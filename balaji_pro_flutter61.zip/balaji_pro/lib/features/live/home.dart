import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/device.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/icons.dart';
import '../../core/palette.dart';
import '../../data/engine.dart';
import '../../data/insights.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../widgets/charts.dart';
import '../../widgets/common.dart';
import '../../widgets/page.dart';
import '../hub.dart';
import '../../core/flags.dart';
import '../registry.dart';
import 'audit.dart';
import 'field.dart';
import 'forms.dart';
import 'kit.dart';
import 'kanta_khata_screen.dart' show KantaKhataCard;
import 'kanta_remote_screen.dart' show KantaRemoteCard;
import 'kit2.dart';
import 'ui.dart';
import 'trade_screens3.dart';
import 'tally_data.dart' show TallyWhat, tallyPurchaseBanner, tallyStrip;

/// Front door of the app: the owner sees the whole business, a worker sees
/// his own entries.
class BizHomeScreen extends StatefulWidget {
  const BizHomeScreen({super.key});

  @override
  State<BizHomeScreen> createState() => _BizHomeScreenState();
}

class _BizHomeScreenState extends State<BizHomeScreen> {
  int _chart = 0;

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      rows: (BuildContext c) => live.isAdmin ? _owner(c) : _staff(c),
    );
  }

  /// The screens of these ids that are shown to the owner (simple mode hides the others).
  List<FeatureDef> _pick(List<String> ids) {
    final List<FeatureDef> l = <FeatureDef>[];
    for (final String id in ids) {
      final FeatureDef? f = shownById(id, true);
      if (f != null) l.add(f);
    }
    return l;
  }

  // ----------------------------------------------------- on the way strip
  Widget _transitStrip() {
    final List<Trip> w = live.trips.where((Trip t) => t.state == TripState.wait).toList();
    double kg = 0;
    for (final Trip t in w) {
      kg += t.chitKg;
    }
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Surface(
        onTap: () => app.go('transit'),
        padding: const EdgeInsets.all(12),
        child: Row(
          children: <Widget>[
            IconChip('route', tone: w.isEmpty ? 'slate' : 'amber', size: 42),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(bi('રસ્તામાં · Transit', 'On the way'), style: ts(14.5, w: FontWeight.w800)),
                  Text(
                    w.isEmpty ? bi('હમણાં કોઈ ગાડી રસ્તામાં નથી', 'No vehicle on the way right now') : '${w.length} ${bi('ગાડી', 'vehicles')} · ${(kg / 1000).toStringAsFixed(1)} T ${bi('માલ કાંટે આવવાનો બાકી', 'still to reach the kanta')}',
                    style: ts(12.5, c: Pal.muted),
                  ),
                ],
              ),
            ),
            Icon(ic('chev'), size: 20, color: Pal.faint),
          ],
        ),
      ),
    );
  }

  // ------------------------------------------------------------ owner home
  List<Widget> _owner(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    final DateTime now = DateTime.now();
    final DateTime today = dayOf(now);
    final Period p = Period(today, addDays(today, 1));
    final Stats s = statsFor(p);
    final Stats y = statsFor(p.previous);
    final List<Trip> tt = live.trips.where((Trip t) => p.has(t.at)).toList();
    final List<Finding> hot = live.openFindings.where((Finding f) => f.sev >= 2).toList();
    final int waiting = tt.where((Trip t) => t.state == TripState.noKanta || t.state == TripState.wait).length;
    final List<DayPoint> week = dailySeries(Period(addDays(today, -6), addDays(today, 1)));
    final Profile? me = live.me;
    final DateTime yday = addDays(today, -1);
    final bool ydOpen = !live.isClosed(yday) && statsFor(Period(yday, today)).trips > 0;

    final Widget hero = HeroCard(
      title: bi('આજે કાંટા પર આવ્યો માલ', 'Weighed in today'),
      value: s.kantaKg >= 10000 ? (s.kantaKg / 1000).toStringAsFixed(2) : grp(s.kantaKg),
      unit: s.kantaKg >= 10000 ? bi('ટન', 'tons') : 'KG',
      sub: '${bi('ગઈકાલે', 'Yesterday')}: ${kgShort(y.kantaKg)} · ${bi('ચિઠ્ઠી આજે', 'chits today')}: ${kgShort(s.chitKg)}',
      spark: <double>[for (final DayPoint d in week) d.kantaKg / 1000],
      chips: <HeroChip>[
        HeroChip('truck', '${s.trips} ${bi('ગાડી', 'vehicles')}'),
        HeroChip('receipt', '${s.chits} ${bi('ચિઠ્ઠી', 'chits')}'),
        HeroChip('check', '${s.okTrips} ${bi('બરાબર', 'ok')}'),
        if (s.diffTrips > 0) HeroChip('warn', '${s.diffTrips} ${bi('ફરક', 'differ')}'),
      ],
      onTap: () => app.go(screenOn('live_board') ? 'live_board' : 'kanta'),
    );

    final Widget tiles = metricGrid(context, <Widget>[
      MetricTile(
        label: bi('આજની ચિઠ્ઠી', 'Chits today'),
        value: '${s.chits}',
        icon: 'receipt',
        tone: 'teal',
        sub: '${bi('ગઈકાલે', 'yesterday')} ${y.chits}',
        onTap: () => app.go('chithi'),
      ),
      MetricTile(
        label: bi('ફરક (મેળ થયેલ)', 'Difference (matched)'),
        value: s.compared == 0 ? '—' : '${sk(s.ghat)} KG',
        icon: 'cmp',
        tone: s.compared == 0 ? 'slate' : (s.ghat.abs() <= live.cfg.tol(s.mChit) ? 'green' : 'rose'),
        sub: s.compared == 0 ? bi('મેળ થયેલ ગાડી નથી', 'no matched trips yet') : '${s.ghatPct.toStringAsFixed(2)}% · ${s.compared} ${bi('ગાડી', 'trips')}',
        onTap: () => app.go('mel'),
      ),
      MetricTile(
        label: bi('કાંટાની રાહમાં', 'Waiting for kanta'),
        value: '$waiting',
        icon: 'route',
        tone: waiting == 0 ? 'green' : 'amber',
        sub: bi('ગાડી · રસ્તામાં જુઓ', 'vehicles · see on the way'),
        onTap: () => app.go('transit'),
      ),
      MetricTile(
        label: bi('તપાસ માંગે છે', 'Needs checking'),
        value: '${hot.length}',
        icon: 'warn',
        tone: hot.isEmpty ? 'green' : 'rose',
        sub: live.reviewed.isEmpty ? null : '${live.reviewed.length} ${bi('જોઈ લીધેલા', 'checked')}',
        onTap: () => app.go('alerts'),
      ),
    ]);

    final Widget todayTrips = Panel(
      title: bi('આજની ગાડીઓ', 'Vehicles today'),
      sub: '${tt.length}',
      action: Btn(bi('બધી', 'All'), dense: true, kind: BtnKind.tonal, onTap: () => app.go('mel')),
      child: tt.isEmpty
          ? EmptyBox(icon: 'truck', title: bi('આજે હજી કોઈ ગાડી નથી', 'No vehicle yet today'))
          : Column(children: <Widget>[for (final Trip t in tt.take(8)) tripTile(context, t)]),
    );

    final Widget attention = Panel(
      title: bi('ધ્યાન માંગે છે', 'Needs attention'),
      sub: '${hot.length}',
      action: Btn(bi('બધા', 'All'), dense: true, kind: BtnKind.tonal, onTap: () => app.go('alerts')),
      child: hot.isEmpty
          ? EmptyBox(icon: 'check', title: bi('બધું બરાબર છે', 'All clear'))
          : Column(children: <Widget>[for (final Finding f in hot.take(6)) findingTile(context, f)]),
    );

    final List<double> dc = <double>[for (final DayPoint d in week) d.chitKg / 1000];
    final List<double> dk = <double>[for (final DayPoint d in week) d.kantaKg / 1000];
    final Widget chart = Panel(
      title: bi('છેલ્લા 7 દિવસ (ટન)', 'Last 7 days (tons)'),
      action: Seg(
        dense: true,
        labels: <String>[bi('ચિઠ્ઠી', 'Chit'), bi('કાંટો', 'Kanta')],
        index: _chart,
        onChanged: (int i) => setState(() => _chart = i),
      ),
      child: BarChartX(
        values: _chart == 0 ? dc : dk,
        labels: <String>[for (final DayPoint d in week) '${d.day.day}'],
        color: _chart == 0 ? Pal.brand : Pal.info,
        highlight: 6,
        axisFmt: (double v) => v.toStringAsFixed(v < 10 ? 1 : 0),
        valueFmt: (double v) => '${v.toStringAsFixed(1)} T',
        height: 200,
      ),
    );

    // pinned parties
    final List<Widget> pinned = <Widget>[];
    live.pins.forEach((String id, String label) {
      final int i = id.indexOf('|');
      final int? di = i < 1 ? null : int.tryParse(id.substring(0, i));
      if (di == null || di < 0 || di >= Dim.values.length) return;
      final PartyRef r = PartyRef(Dim.values[di], id.substring(i + 1), label);
      pinned.add(partyChip(r, extra: dimName(r.dim)));
    });

    final List<String> quick = <String>[
      'transit',
      'scan',
      'rates',
      'purchase',
      'followups',
      'target',
      'live_board',
      'analytics',
      'risk',
      'hourly',
      'leaders',
      'compare',
      'day_close',
      'feed',
      'staff',
      'parties',
      'photo_wall',
      'export',
    ];
    final List<FeatureDef> qf = <FeatureDef>[];
    for (final String id in quick) {
      final FeatureDef? f = shownById(id, true);
      if (f != null) qf.add(f);
    }
    final List<FeatureDef> ff = <FeatureDef>[
      for (final String id in app.favs)
        if (shownById(id, true) != null) shownById(id, true)!,
    ];
    final List<FeatureDef> mf = <FeatureDef>[
      for (final String id in <String>['khedut_khata', 'sales', 'buyer_khata', 'collection', 'stock_live', 'process_grade', 'cash_flow', 'margin', 'day_account', 'payments', 'expenses', 'cashbook', 'tally_live', 'tally_pay', 'tally_mel', 'weight_bill', 'brokerage', 'wages', 'cost_calc', 'month_close', 'rate_chart', 'bookings'])
        if (shownById(id, true) != null) shownById(id, true)!,
    ];
    final List<String> checks = <String>['by_vehicle', 'by_farmer', 'by_village', 'by_broker', 'by_majur', 'rst_gap', 'daily', 'history', 'loss_value', 'quality', 'plate_check', 'chit_gaps', 'digits', 'late_entry'];
    final List<FeatureDef> cf = <FeatureDef>[];
    for (final String id in checks) {
      final FeatureDef? f = shownById(id, true);
      if (f != null) cf.add(f);
    }

    Widget tileGrid(List<FeatureDef> l) {
      return LayoutBuilder(builder: (BuildContext c, BoxConstraints box) {
        final int cols = pc ? gridCols(box.maxWidth, min: 230, max: 4) : 2;
        return Grid(cols: cols, gap: 10, children: <Widget>[for (final FeatureDef f in l) FeatureTile(f, showPin: false)]);
      });
    }

    return <Widget>[
      ScreenHeader(
        '${bi('નમસ્તે', 'Hello')}${me == null || me.name.isEmpty ? '' : ', ${me.name}'}',
        sub: '${dayName(now)}, ${dmy(now)}',
        onPhone: true,
        actions: <Widget>[refreshBtn(), Btn(bi('નવી એન્ટ્રી', 'New entry'), icon: 'plus', dense: true, onTap: () => showNewMenu(context))],
      ),
      statusBanner(),
      if (live.isAdmin) const KantaRemoteCard(),
            if (live.isAdmin) const KantaKhataCard(),
      if (live.isAdmin) tallyStrip(TallyWhat.all),
      tallyPurchaseBanner(),
      if (live.badCount > 0)
        noteBox('warn', 'rose', '${live.badCount} ${bi('એન્ટ્રીમાં વજન ખોટું છે - ગણતરીમાં લીધી નથી. જોવા દબાવો', 'entries have an impossible weight - left out of totals. Tap to see')}', onTap: () => app.go('bad_entries')),
      if (live.fresh.isNotEmpty)
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Material(
            color: Pal.tone('green').bg,
            borderRadius: BorderRadius.circular(12),
            child: InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: () => app.go(screenOn('feed') ? 'feed' : 'chithi'),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                child: Row(
                  children: <Widget>[
                    Icon(ic('bolt'), size: 19, color: Pal.tone('green').fg),
                    const SizedBox(width: 10),
                    Expanded(child: Text('${live.fresh.length} ${bi('નવી એન્ટ્રી આવી - જોવા દબાવો', 'new entries arrived - tap to see')}', style: ts(13, w: FontWeight.w700, c: Pal.tone('green').fg))),
                    Icon(ic('chev'), size: 18, color: Pal.tone('green').fg),
                  ],
                ),
              ),
            ),
          ),
        ),
      if (ydOpen && screenOn('day_close'))
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Material(
            color: Pal.tone('amber').bg,
            borderRadius: BorderRadius.circular(12),
            child: InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: () => app.go('day_close'),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                child: Row(
                  children: <Widget>[
                    Icon(ic('lockopen'), size: 19, color: Pal.tone('amber').fg),
                    const SizedBox(width: 10),
                    Expanded(child: Text(bi('ગઈકાલનો દિવસ હજી બંધ કર્યો નથી', 'Yesterday is not closed yet'), style: ts(13, w: FontWeight.w700, c: Pal.tone('amber').fg))),
                    Icon(ic('chev'), size: 18, color: Pal.tone('amber').fg),
                  ],
                ),
              ),
            ),
          ),
        ),
      hero,
      _transitStrip(),
      const TradeStrip(),
      const SizedBox(height: 14),
      tiles,
      const SizedBox(height: 16),
      SplitPane(flex: const <int>[3, 2], children: <Widget>[todayTrips, attention]),
      const SizedBox(height: 16),
      chart,
      if (pinned.isNotEmpty) ...<Widget>[
        const SizedBox(height: 16),
        SectionTitle(bi('પિન કરેલા', 'Pinned'), action: Btn(bi('બધા', 'All'), dense: true, kind: BtnKind.ghost, onTap: () => app.go('parties'))),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: pinned),
      ],
      if (ff.isNotEmpty) ...<Widget>[
        const SizedBox(height: 16),
        SectionTitle(bi('મનપસંદ', 'Favourites'), action: Btn(bi('બધા ફીચર', 'All features'), dense: true, kind: BtnKind.ghost, onTap: () => app.go('hub'))),
        const SizedBox(height: 10),
        tileGrid(ff),
      ],
      if (kSimple) ...<Widget>[
        // simple mode: four short blocks - what is entered, the accounts, the Tally parts, the rest
        for (final (String, List<String>) blk in <(String, List<String>)>[
          (bi('એન્ટ્રી', 'Entries'), <String>['chithi_new', 'kanta', 'maal_new', 'scan', 'transit', 'rates']),
          (bi('હિસાબ', 'Accounts'), <String>['khedut_khata', 'payments', 'expenses', 'cashbook', 'day_account', 'sales', 'buyer_khata', 'collection', 'stock_live']),
          (bi('Tally', 'Tally'), <String>['tally_pay', 'tally_mel', 'tally_live']),
          (bi('બીજું', 'More'), <String>['weight_bill', 'brokerage', 'wages', 'month_close', 'purchase', 'daily', 'history']),
        ])
          if (_pick(blk.$2).isNotEmpty) ...<Widget>[
            const SizedBox(height: 16),
            SectionTitle(blk.$1),
            const SizedBox(height: 10),
            tileGrid(_pick(blk.$2)),
          ],
      ] else ...<Widget>[
      const SizedBox(height: 16),
      SectionTitle(bi('હિસાબ', 'Accounts'), action: Btn(bi('બધા', 'All'), dense: true, kind: BtnKind.ghost, onTap: () => app.go('g_money'))),
      const SizedBox(height: 10),
      tileGrid(mf),
      const SizedBox(height: 16),
      SectionTitle(bi('વિશ્લેષણ અને સાધનો', 'Insights and tools')),
      const SizedBox(height: 10),
      tileGrid(qf),
      const SizedBox(height: 16),
      SectionTitle(bi('તપાસ', 'Checks')),
      const SizedBox(height: 10),
      tileGrid(cf),
      ],
    ];
  }

  // ------------------------------------------------------------ staff home
  List<Widget> _staff(BuildContext context) {
    final Profile? me = live.me;
    final DateTime today = dayOf(DateTime.now());
    final List<MapEntry<DateTime, Widget>> items = <MapEntry<DateTime, Widget>>[];
    int nToday = 0;
    for (final Chit x in live.chits) {
      items.add(MapEntry<DateTime, Widget>(x.at, chitTile(context, x)));
      if (!x.at.isBefore(today)) nToday++;
    }
    for (final Kanta x in live.kantas) {
      items.add(MapEntry<DateTime, Widget>(x.at, kantaTile(context, x)));
      if (!x.at.isBefore(today)) nToday++;
    }
    for (final MaalRow x in live.maals) {
      items.add(MapEntry<DateTime, Widget>(x.at, maalTile(context, x)));
      if (!x.at.isBefore(today)) nToday++;
    }
    items.sort((MapEntry<DateTime, Widget> a, MapEntry<DateTime, Widget> b) => b.key.compareTo(a.key));

    Widget big(String icon, String tone, String label, String route) {
      return Surface(
        onTap: () => app.go(route),
        padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 12),
        child: Column(
          children: <Widget>[
            IconChip(icon, tone: tone, size: 52),
            const SizedBox(height: 10),
            Text(label, textAlign: TextAlign.center, style: ts(14.5, w: FontWeight.w800)),
          ],
        ),
      );
    }

    final String role = me == null ? '' : me.role;
    final bool isWay = role == 'waybridge';
    final bool isMaal = role == 'maal_entry';
    final List<Chit> tc = todaysChits();
    final List<Kanta> tk = todaysKantas();
    final List<MaalRow> tm = todaysMaals();
    double chitKg = 0;
    int chitBags = 0;
    final Set<String> chitVeh = <String>{};
    for (final Chit x in tc) {
      chitKg += x.cmpKg;
      chitBags += x.bags;
      chitVeh.add(x.vkey);
    }
    double kantaKg = 0;
    for (final Kanta x in tk) {
      kantaKg += x.kg;
    }
    int inBags = 0;
    int outBags = 0;
    for (final MaalRow x in tm) {
      if (x.loading) {
        outBags += x.bags;
      } else {
        inBags += x.bags;
      }
    }
    final int lastRst = lastNumber(live.kantas.map((Kanta k) => k.rst));

    Widget hero;
    String roleName;
    if (isWay) {
      roleName = bi('કાંટા (વે-બ્રિજ)', 'Weighbridge');
      hero = HeroCard(
        title: bi('આજનો કાંટો', 'Weighbridge today'),
        value: grp(kantaKg),
        unit: 'KG',
        sub: lastRst > 0 ? bi('છેલ્લો RST $lastRst · આગળનો ${lastRst + 1}', 'Last RST $lastRst · next ${lastRst + 1}') : null,
        chips: <HeroChip>[
          HeroChip('truck', '${tk.length} ${bi('ગાડી', 'vehicles')}'),
          HeroChip('weight', tk.isEmpty ? '—' : '${bi('સરેરાશ', 'avg')} ${kgTxt(kantaKg / tk.length)}'),
        ],
      );
    } else if (isMaal) {
      roleName = bi('માલ એન્ટ્રી', 'Maal entry');
      hero = HeroCard(
        title: bi('આજના માલના બેગ', 'Maal bags today'),
        value: '${inBags + outBags}',
        unit: bi('બેગ', 'bags'),
        sub: live.pending.isEmpty ? null : bi('${live.pending.length} મોકલવાની બાકી', '${live.pending.length} waiting to upload'),
        chips: <HeroChip>[
          HeroChip('dl', '${bi('આવ્યા', 'in')} $inBags'),
          HeroChip('ul', '${bi('ગયા', 'out')} $outBags'),
          HeroChip('list', '${tm.length} ${bi('એન્ટ્રી', 'entries')}'),
        ],
      );
    } else {
      roleName = bi('ચિઠ્ઠી (ખેતર)', 'Chits (field)');
      hero = HeroCard(
        title: bi('આજની ચિઠ્ઠી', 'Chits today'),
        value: '${tc.length}',
        unit: bi('ચિઠ્ઠી', 'chits'),
        sub: tc.isEmpty ? null : '${kgTxt(chitKg)}${chitBags > 0 ? ' · $chitBags ${bi('બેગ', 'bags')}' : ''}',
        chips: <HeroChip>[
          HeroChip('truck', '${chitVeh.length} ${bi('ગાડી', 'vehicles')}'),
          HeroChip('weight', kgTxt(chitKg)),
        ],
      );
    }

    Widget primary(String icon, String tone, String label, String sub, String route) {
      return Surface(
        onTap: () => app.go(route),
        padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
        child: Row(
          children: <Widget>[
            IconChip(icon, tone: tone, size: 58),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(label, style: ts(19, w: FontWeight.w800)),
                  const SizedBox(height: 2),
                  Text(sub, style: ts(12.5, c: Pal.muted)),
                ],
              ),
            ),
            Icon(ic('chev'), size: 24, color: Pal.faint),
          ],
        ),
      );
    }

    Widget mainBtn;
    if (isWay) {
      mainBtn = primary('scale', 'blue', bi('નવી કાંટા એન્ટ્રી', 'New weighbridge entry'), bi('RST, ગાડી અને વજન', 'RST, vehicle and weight'), 'kanta_new');
    } else if (isMaal) {
      mainBtn = primary('bag', 'amber', bi('નવી માલ એન્ટ્રી', 'New maal entry'), bi('લોડિંગ / અનલોડિંગ, બેગ', 'Loading / unloading, bags'), 'maal_new');
    } else {
      mainBtn = primary('receipt', 'teal', bi('નવી ચિઠ્ઠી', 'New chit'), bi('ખેડૂત, ગાડી અને વજન', 'Farmer, vehicle and weight'), 'chithi_new');
    }
    final List<Widget> others = <Widget>[
      big('scan', 'violet', bi('સ્લિપ સ્કેન', 'Scan slip'), 'scan'),
      if (isWay || isMaal) big('receipt', 'teal', bi('ચિઠ્ઠી', 'Chit'), 'chithi_new') else big('scale', 'blue', bi('કાંટો', 'Kanta'), 'kanta_new'),
      if (isMaal) big('scale', 'blue', bi('કાંટો', 'Kanta'), 'kanta_new') else big('bag', 'amber', bi('માલ', 'Maal'), 'maal_new'),
    ];

    return <Widget>[
      ScreenHeader(
        '${bi('નમસ્તે', 'Hello')}, ${me == null || me.name.isEmpty ? '' : me.name}',
        sub: '$roleName · ${dmy(DateTime.now())}',
        actions: <Widget>[refreshBtn()],
        onPhone: true,
      ),
      statusBanner(),
      hero,
      const SizedBox(height: 12),
      mainBtn,
      const SizedBox(height: 10),
      Grid(cols: 3, gap: 10, children: others),
      const SizedBox(height: 10),
      Grid(cols: 3, gap: 10, children: <Widget>[
        big('user', 'teal', bi('મારો દિવસ', 'My day'), 'my_day'),
        big('weight', 'blue', bi('કન્વર્ટર', 'Converter'), 'converter'),
        big('calc', 'amber', bi('કૅલ્ક્યુલેટર', 'Calculator'), 'calc'),
      ]),
      const SizedBox(height: 10),
      Grid(cols: 3, gap: 10, children: <Widget>[
        big('bulb', 'green', bi('માર્ગદર્શન', 'Guide'), 'help'),
        big('health', 'slate', bi('એપ તપાસ', 'Diagnostics'), 'diagnostics'),
        big('gear', 'slate', bi('સેટિંગ્સ', 'Settings'), 'settings'),
      ]),
      const SizedBox(height: 16),
      SectionTitle(bi('મારી એન્ટ્રી', 'My entries'), sub: bi('આજે $nToday', 'Today $nToday')),
      const SizedBox(height: 10),
      if (items.isEmpty)
        EmptyBox(icon: 'list', title: bi('હજી કોઈ એન્ટ્રી નથી', 'No entries yet'))
      else
        for (final MapEntry<DateTime, Widget> e in items.take(30)) e.value,
    ];
  }
}
