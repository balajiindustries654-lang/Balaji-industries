import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/gst.dart';
import '../../data/gst_print.dart';
import '../../data/insights.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../data/owner_docs.dart';
import '../../data/trade.dart';
import '../../widgets/common.dart';
import '../../widgets/launch.dart';
import '../../widgets/page.dart';
import '../../widgets/printer.dart';
import 'field.dart';
import 'kit.dart';
import 'kit2.dart';
import 'money_screens.dart';
import 'ui.dart';

import '../../widgets/accept.dart';
import '../../widgets/dayfield.dart';
// ======================================================================
// GST bills: list, new bill, preview / print, firm details
// ======================================================================

/// Things a screen can hand to the bill form (for example a sale or a mill truck).
class GstPrefill {
  final String party;
  final String vehicle;
  final String note;
  final List<GstLine> lines;
  final bool toKhata;
  final void Function(GstInv)? onSaved; // called with the saved bill (for example to link it to a mill truck)
  const GstPrefill({this.party = '', this.vehicle = '', this.note = '', this.lines = const <GstLine>[], this.toKhata = true, this.onSaved});
}

Future<void> openGstForm(BuildContext context, {GstPrefill? prefill}) {
  return openPanel(context, title: bi('નવું GST બિલ', 'New GST bill'), width: 640, child: GstForm(prefill: prefill));
}

Future<void> openGstDetail(BuildContext context, GstInv inv) {
  return openPanel(context, title: inv.no, sub: inv.party, width: 780, child: GstDetail(inv));
}

Future<void> openGstFirm(BuildContext context, GstFirm firm) {
  return openPanel(context, title: bi('પેઢીની GST વિગત', 'Firm GST details'), sub: firm.name, width: 520, child: _FirmForm(firm));
}

Color get _paperInk => const Color(0xFF111111);

// ----------------------------------------------------------------- preview
/// The bill drawn like the printed paper (always white, always black ink).
class GstPaper extends StatelessWidget {
  final GstInv inv;
  final GstFirm firm;
  const GstPaper(this.inv, this.firm, {super.key});

  TextStyle _t({double s = 11, bool b = false}) => ts(s, w: b ? FontWeight.w800 : FontWeight.w500, c: _paperInk, tab: true);

  Widget _cell(String text, {bool right = false, bool bold = false, bool center = false, double s = 11}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 4),
      child: Text(text, textAlign: center ? TextAlign.center : (right ? TextAlign.right : TextAlign.left), style: _t(s: s, b: bold)),
    );
  }

  Widget _box(Widget child) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(7),
      decoration: BoxDecoration(border: Border.all(color: _paperInk, width: 0.7)),
      child: child,
    );
  }

  Widget _kv(String k, String v) {
    return _box(Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[Text(k, style: _t(s: 9.5)), Text(v.isEmpty ? '-' : v, style: _t(b: true))]));
  }

  @override
  Widget build(BuildContext context) {
    final GstCalc c = inv.calc;
    final bool tax = inv.isTax;
    final List<TableRow> rows = <TableRow>[
      TableRow(
        decoration: const BoxDecoration(color: Color(0xFFEFEFEF)),
        children: <Widget>[_cell('Sl', bold: true, center: true), _cell('Description of Goods', bold: true), _cell('HSN/SAC', bold: true, center: true), _cell('Quantity', bold: true, right: true), _cell('Rate', bold: true, right: true), _cell('GST %', bold: true, center: true), _cell('Amount', bold: true, right: true)],
      ),
      for (int k = 0; k < inv.lines.length; k++)
        TableRow(children: <Widget>[
          _cell('${k + 1}', center: true),
          _cell(inv.lines[k].desc, bold: true),
          _cell(inv.lines[k].hsn, center: true),
          _cell('${grp(inv.lines[k].qty, dec: inv.lines[k].qty == inv.lines[k].qty.roundToDouble() ? 0 : 2)} ${inv.lines[k].unit}', right: true),
          _cell('${grp(inv.lines[k].rate, dec: 2)} / ${gstBasisLabel(inv.lines[k].basis).replaceAll('₹ / ', '')}', right: true),
          _cell(tax ? grp(inv.lines[k].gst, dec: inv.lines[k].gst == inv.lines[k].gst.roundToDouble() ? 0 : 1) : '-', center: true),
          _cell(grp(inv.lines[k].amount, dec: 2), right: true),
        ]),
    ];
    final List<Widget> sums = <Widget>[
      _sumRow('Taxable value', c.taxable, bold: true),
      if (tax && c.cgst > 0) _sumRow('Output CGST', c.cgst),
      if (tax && c.sgst > 0) _sumRow('Output SGST', c.sgst),
      if (tax && c.igst > 0) _sumRow('Output IGST', c.igst),
      if (c.round.abs() >= 0.005) _sumRow('Round off', c.round),
      _sumRow('Total  ₹', c.total, bold: true, big: true),
    ];
    return Container(
      width: 760,
      color: Colors.white,
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Container(
            color: const Color(0xFFEFEFEF),
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Text(tax ? 'TAX INVOICE' : 'BILL OF SUPPLY', textAlign: TextAlign.center, style: _t(s: 14, b: true)),
          ),
          if (inv.cancelled) Padding(padding: const EdgeInsets.only(top: 4), child: Text('CANCELLED', textAlign: TextAlign.center, style: ts(14, w: FontWeight.w900, c: const Color(0xFFC62828)))),
          const SizedBox(height: 6),
          Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Expanded(
                flex: 11,
                child: _box(Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(firm.name, style: _t(s: 16, b: true)),
                    if (firm.addr.trim().isNotEmpty) Text(firm.addr.trim(), style: _t()),
                    if (firm.gstin.trim().isNotEmpty) Text('GSTIN/UIN: ${gstinClean(firm.gstin)}', style: _t(b: true)),
                    Text('State: ${gstStateText(firm.state)}', style: _t()),
                    if (firm.phone.trim().isNotEmpty) Text('Phone: ${firm.phone}', style: _t()),
                  ],
                )),
              ),
              Expanded(
                flex: 9,
                child: Column(
                  children: <Widget>[
                    Row(children: <Widget>[Expanded(child: _kv('Invoice No.', inv.no)), Expanded(child: _kv('Dated', dmy(inv.date)))]),
                    Row(children: <Widget>[Expanded(child: _kv('Vehicle No.', inv.vehicle)), Expanded(child: _kv('E-way Bill No.', inv.ewb))]),
                    Row(children: <Widget>[Expanded(child: _kv('Place of Supply', gstStateText(inv.place))), Expanded(child: _kv('Reverse Charge', inv.rcm ? 'Yes' : 'No'))]),
                  ],
                ),
              ),
            ],
          ),
          _box(Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text('Buyer (Bill to)', style: _t(s: 9.5)),
              Text(inv.party, style: _t(s: 14, b: true)),
              if (inv.addr.trim().isNotEmpty) Text(inv.addr.trim(), style: _t()),
              if (inv.gstin.trim().isNotEmpty) Text('GSTIN/UIN: ${gstinClean(inv.gstin)}', style: _t(b: true)),
              if (inv.state.isNotEmpty) Text('State: ${gstStateText(inv.state)}', style: _t()),
            ],
          )),
          Table(
            border: TableBorder.all(color: _paperInk, width: 0.7),
            columnWidths: const <int, TableColumnWidth>{
              0: FixedColumnWidth(30),
              1: FlexColumnWidth(),
              2: FixedColumnWidth(66),
              3: FixedColumnWidth(96),
              4: FixedColumnWidth(110),
              5: FixedColumnWidth(48),
              6: FixedColumnWidth(104),
            },
            children: rows,
          ),
          Container(
            decoration: BoxDecoration(border: Border(left: BorderSide(color: _paperInk, width: 0.7), right: BorderSide(color: _paperInk, width: 0.7), bottom: BorderSide(color: _paperInk, width: 0.7))),
            child: Column(children: sums),
          ),
          _box(Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[Text('Amount Chargeable (in words)', style: _t(s: 9.5)), Text(rupeesInWords(c.total), style: _t(b: true))],
          )),
          if (inv.note.trim().isNotEmpty) _box(Text('Note: ${inv.note.trim()}', style: _t())),
          Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Expanded(
                flex: 11,
                child: _box(Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    if (firm.acc.trim().isNotEmpty || firm.upi.trim().isNotEmpty) ...<Widget>[
                      Text("Company's Bank Details", style: _t(b: true)),
                      if (firm.bank.trim().isNotEmpty) Text('Bank: ${firm.bank}', style: _t()),
                      if (firm.acc.trim().isNotEmpty) Text('A/c No.: ${firm.acc}', style: _t(b: true)),
                      if (firm.ifsc.trim().isNotEmpty) Text('IFSC: ${firm.ifsc}', style: _t(b: true)),
                      if (firm.upi.trim().isNotEmpty) Text('UPI: ${firm.upi}', style: _t()),
                      const SizedBox(height: 6),
                    ],
                    Text(firm.terms.trim().isEmpty ? 'We declare that this invoice shows the actual price of the goods described and that all particulars are true and correct.' : firm.terms.trim(), style: _t(s: 9.5)),
                  ],
                )),
              ),
              Expanded(
                flex: 9,
                child: _box(Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    Text('for ${firm.name}', style: _t(b: true)),
                    const SizedBox(height: 46),
                    Text('Authorised Signatory', style: _t()),
                  ],
                )),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text('This is a Computer Generated Invoice', textAlign: TextAlign.center, style: _t(s: 9.5)),
        ],
      ),
    );
  }

  Widget _sumRow(String label, double v, {bool bold = false, bool big = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
      child: Row(
        children: <Widget>[
          Expanded(child: Text(label, textAlign: TextAlign.right, style: _t(s: big ? 13 : 11, b: bold))),
          SizedBox(width: 110, child: Text(grp(v, dec: 2), textAlign: TextAlign.right, style: _t(s: big ? 13 : 11, b: bold))),
        ],
      ),
    );
  }
}

// ------------------------------------------------------------------ detail
class GstDetail extends StatelessWidget {
  final GstInv inv;
  const GstDetail(this.inv, {super.key});

  Future<void> _print(BuildContext context) async {
    final GstFirm f = gstFirmOf(inv.firm);
    final bool ok = await printHtml(gstHtml(inv, f), 'bill_${inv.no}');
    if (!ok) copyText(gstText(inv, f), msg: bi('પ્રિન્ટ પેજ ખુલ્યું નહીં - બિલનું લખાણ કૉપિ થયું', 'Could not open the print page - bill text copied'));
  }

  Future<void> _cancel(BuildContext context) async {
    final bool go = await confirmBox(
      context,
      title: bi('આ બિલ રદ કરવું?', 'Cancel this bill?'),
      text: bi('બિલ નંબર રહેશે પણ "રદ" લખાશે અને ખરીદનારના ખાતામાંથી આ વેચાણ નીકળી જશે.', 'The number stays but the bill is marked cancelled and the sale is taken out of the buyer ledger.'),
      yes: bi('હા, રદ કરો', 'Yes, cancel'),
      no: bi('ના', 'No'),
    );
    if (!go) return;
    await cancelGstInvoice(inv);
    if (context.mounted) Navigator.of(context).pop();
  }

  Future<void> _delete(BuildContext context) async {
    final bool go = await confirmBox(
      context,
      title: bi('બિલ કાયમ માટે કાઢવું?', 'Delete this bill for good?'),
      text: bi('નંબરની શ્રેણીમાં ખાલી જગ્યા પડશે. સામાન્ય રીતે "રદ" કરવું વધુ સારું.', 'The number series will have a gap. Normally "Cancel" is better.'),
      yes: bi('હા, કાઢો', 'Yes, delete'),
      no: bi('ના', 'No'),
    );
    if (!go) return;
    await removeGstInvoice(inv);
    if (context.mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final GstFirm f = gstFirmOf(inv.firm);
    final GstCalc c = inv.calc;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Container(
          decoration: BoxDecoration(border: Border.all(color: Pal.line), color: Colors.white),
          child: FittedBox(fit: BoxFit.fitWidth, alignment: Alignment.topCenter, child: GstPaper(inv, f)),
        ),
        const SizedBox(height: 12),
        InfoRow(bi('કુલ બિલ', 'Invoice value'), inr(c.total, dec: 2), bold: true, color: Pal.brand),
        if (inv.isTax) InfoRow(bi('કુલ GST', 'Total GST'), inr(c.tax, dec: 2)),
        if (inv.cancelled) InfoRow(bi('સ્થિતિ', 'Status'), bi('રદ', 'Cancelled'), color: Pal.bad),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: <Widget>[
            Btn(bi('પ્રિન્ટ / PDF', 'Print / PDF'), icon: 'print', onTap: () => _print(context)),
            Btn('WhatsApp', icon: 'chat', kind: BtnKind.tonal, onTap: () => whatsappText(gstText(inv, f), phone: inv.phone)),
            Btn(bi('કૉપિ', 'Copy'), icon: 'copy', kind: BtnKind.outline, onTap: () => copyText(gstText(inv, f))),
            if (!inv.cancelled) Btn(bi('રદ કરો', 'Cancel bill'), icon: 'close', kind: BtnKind.danger, onTap: () => _cancel(context)),
            Btn(bi('કાઢો', 'Delete'), icon: 'trash', kind: BtnKind.ghost, onTap: () => _delete(context)),
          ],
        ),
      ],
    );
  }
}

// -------------------------------------------------------------------- form
class _LineEd {
  final TextEditingController desc = TextEditingController();
  final TextEditingController hsn = TextEditingController();
  final TextEditingController qty = TextEditingController();
  final TextEditingController rate = TextEditingController();
  String basis = 'mann';
  String unit = 'KG';
  double gst = 5;

  void dispose() {
    desc.dispose();
    hsn.dispose();
    qty.dispose();
    rate.dispose();
  }

  GstLine toLine() => GstLine(desc: desc.text.trim(), hsn: hsn.text.trim(), qty: dbl(qty.text), unit: unit, rate: dbl(rate.text), basis: basis, gst: gst);

  void fromLine(GstLine l) {
    desc.text = l.desc;
    hsn.text = l.hsn;
    qty.text = l.qty == 0 ? '' : plainNum(l.qty);
    rate.text = l.rate == 0 ? '' : plainNum(l.rate);
    basis = l.basis;
    unit = l.unit;
    gst = l.gst;
  }
}

const List<double> _gstRates = <double>[0, 5, 12, 18, 28];

class GstForm extends StatefulWidget {
  final GstPrefill? prefill;
  const GstForm({super.key, this.prefill});

  @override
  State<GstForm> createState() => _GstFormState();
}

class _GstFormState extends State<GstForm> {
  late final VoidCallback _accept = () {
    _save();
  };

  final TextEditingController _party = TextEditingController();
  final TextEditingController _gstin = TextEditingController();
  final TextEditingController _addr = TextEditingController();
  final TextEditingController _phone = TextEditingController();
  final TextEditingController _veh = TextEditingController();
  final TextEditingController _ewb = TextEditingController();
  final TextEditingController _note = TextEditingController();
  final TextEditingController _no = TextEditingController();
  final List<_LineEd> _lines = <_LineEd>[];
  String _firm = '';
  int _kind = 0; // 0 tax invoice, 1 bill of supply
  String _state = '';
  String _place = '';
  bool _placeTouched = false;
  bool _rcm = false;
  bool _khata = true;
  DateTime _day = dateOnly(DateTime.now());
  bool _busy = false;
  String _err = '';
  GstInv? _saved;

  @override
  void initState() {
    super.initState();
    AcceptHub.push(_accept);
    final List<GstFirm> fs = gstFirms();
    GstFirm pick = fs.first;
    for (final GstFirm f in fs) {
      if (f.ready) {
        pick = f;
        break;
      }
    }
    _firm = pick.id;
    _place = pick.state;
    final GstPrefill? p = widget.prefill;
    if (p != null) {
      _party.text = p.party;
      _veh.text = p.vehicle;
      _note.text = p.note;
      _khata = p.toKhata;
      for (final GstLine l in p.lines) {
        final _LineEd e = _LineEd();
        e.fromLine(l);
        _lines.add(e);
      }
      if (p.party.isNotEmpty) _fillParty(p.party, quiet: true);
    }
    if (_lines.isEmpty) _lines.add(_LineEd());
  }

  @override
  void dispose() {
    for (final TextEditingController c in <TextEditingController>[_party, _gstin, _addr, _phone, _veh, _ewb, _note, _no]) {
      c.dispose();
    }
    for (final _LineEd l in _lines) {
      l.dispose();
    }
    AcceptHub.pop(_accept);
    super.dispose();
  }

  GstFirm get _f => gstFirmOf(_firm);
  bool get _tax => _kind == 0;
  bool get _inter => _place.isNotEmpty && _place != _f.state;

  void _fillParty(String name, {bool quiet = false}) {
    for (final GstParty p in gstParties()) {
      if (nameKey(p.name) == nameKey(name)) {
        _gstin.text = p.gstin;
        _addr.text = p.addr;
        _phone.text = p.phone;
        _state = p.state;
        if (!_placeTouched && p.state.isNotEmpty) _place = p.state;
        break;
      }
    }
    if (_phone.text.isEmpty) _phone.text = buyerPhone(nameKey(name));
    if (!quiet) setState(() {});
  }

  GstInv? _lastBillOfParty() {
    final String k = nameKey(_party.text);
    if (k.isEmpty) return null;
    for (final GstInv i in gstInvoices()) {
      if (nameKey(i.party) == k && !i.cancelled) return i;
    }
    return null;
  }

  void _useLast(GstInv i) {
    for (final _LineEd l in _lines) {
      l.dispose();
    }
    _lines.clear();
    for (final GstLine l in i.lines) {
      final _LineEd e = _LineEd();
      e.fromLine(l);
      e.qty.clear();
      _lines.add(e);
    }
    if (_lines.isEmpty) _lines.add(_LineEd());
    setState(() {});
  }

  List<GstLine> _built() => <GstLine>[for (final _LineEd l in _lines) l.toLine()];

  Future<void> _save() async {
    final GstFirm f = _f;
    final List<GstLine> ls = _built();
    String err = '';
    if (_party.text.trim().isEmpty) {
      err = bi('ખરીદનારનું નામ લખો', 'Enter the buyer name');
    } else {
      for (int k = 0; k < ls.length; k++) {
        final GstLine l = ls[k];
        if (l.desc.isEmpty) {
          err = bi('લાઇન ${k + 1}: માલનું નામ લખો', 'Line ${k + 1}: enter the item');
        } else if (l.qty <= 0) {
          err = bi('લાઇન ${k + 1}: જથ્થો લખો', 'Line ${k + 1}: enter the quantity');
        } else if (l.rate <= 0) {
          err = bi('લાઇન ${k + 1}: ભાવ લખો', 'Line ${k + 1}: enter the rate');
        }
        if (err.isNotEmpty) break;
      }
    }
    if (err.isEmpty && _no.text.trim().isNotEmpty) {
      for (final GstInv i in gstInvoices()) {
        if (i.firm == f.id && i.no == _no.text.trim()) err = bi('આ બિલ નંબર પહેલેથી છે', 'This bill number already exists');
      }
    }
    if (err.isNotEmpty) {
      setState(() => _err = err);
      return;
    }
    final List<String> warn = <String>[];
    if (_gstin.text.trim().isNotEmpty && !gstinOk(_gstin.text)) warn.add(bi('ખરીદનારનો GSTIN સાચો લાગતો નથી', 'The buyer GSTIN does not look right'));
    if (_tax && !f.ready) warn.add(bi('${f.name} નો GSTIN હજી નાખ્યો નથી (ઉપર "પેઢીની વિગત")', 'GSTIN of ${f.name} is not entered yet (see "Firm details")'));
    if (_tax && ls.any((GstLine l) => l.hsn.isEmpty)) warn.add(bi('કોઈ લાઇનમાં HSN નથી', 'A line has no HSN'));
    if (warn.isNotEmpty) {
      final bool go = await confirmBox(context, title: bi('એક વાર ફરી તપાસો', 'Please check once more'), text: warn.map((String x) => '• $x').join('\n'), yes: bi('છતાં સેવ કરો', 'Save anyway'));
      if (!go || !mounted) return;
    }
    setState(() {
      _busy = true;
      _err = '';
    });
    final String no = await addGstInvoice(
      firm: f,
      date: _day,
      kind: _tax ? 'tax' : 'bos',
      party: _party.text,
      gstin: _gstin.text,
      addr: _addr.text,
      state: _state,
      phone: _phone.text,
      place: _place,
      inter: _inter,
      vehicle: _veh.text,
      ewb: _ewb.text,
      note: _note.text,
      rcm: _rcm,
      lines: ls,
      noOverride: _no.text,
      toKhata: _khata,
    );
    GstInv? made;
    for (final GstInv i in gstInvoices()) {
      if (i.no == no && i.firm == f.id) {
        made = i;
        break;
      }
    }
    app.toast('${bi('બિલ સેવ થયું', 'Bill saved')} · $no');
    final GstInv? madeNow = made;
    final void Function(GstInv)? cb = widget.prefill?.onSaved;
    if (madeNow != null && cb != null) cb(madeNow);
    if (!mounted) return;
    if (made == null) {
      Navigator.of(context).pop();
      return;
    }
    setState(() {
      _busy = false;
      _saved = made;
    });
  }

  Widget _lineCard(int k) {
    final _LineEd l = _lines[k];
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Surface(
        shadow: false,
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Row(
              children: <Widget>[
                Expanded(child: Text('${bi('લાઇન', 'Line')} ${k + 1}', style: ts(12.5, w: FontWeight.w800, c: Pal.muted))),
                if (_lines.length > 1)
                  IconBtn('trash', size: 34, tip: bi('આ લાઇન કાઢો', 'Remove line'), onTap: () {
                    setState(() {
                      _lines.removeAt(k).dispose();
                    });
                  }),
              ],
            ),
            if (l.desc.text.trim().isEmpty)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: <Widget>[
                    for (final List<String> p in kGstPresets)
                      GestureDetector(
                        onTap: () {
                          l.desc.text = p[1];
                          l.hsn.text = p[2];
                          l.gst = double.tryParse(p[3]) ?? 5;
                          l.basis = p[4];
                          l.unit = p[5];
                          setState(() {});
                        },
                        child: Pill(bi(p[0], p[1]), tone: 'teal', small: true),
                      ),
                  ],
                ),
              ),
            FieldX(label: '${bi('માલ', 'Item')} *', controller: l.desc, onChanged: (String v) => setState(() {})),
            const SizedBox(height: 10),
            Row(
              children: <Widget>[
                Expanded(flex: 2, child: FieldX(label: 'HSN', controller: l.hsn, keyboard: TextInputType.number)),
                const SizedBox(width: 10),
                Expanded(flex: 3, child: FieldX(label: '${bi('જથ્થો', 'Quantity')} *', controller: l.qty, suffix: l.unit, keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {}))),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Expanded(child: FieldX(label: '${bi('ભાવ', 'Rate')} *', controller: l.rate, prefix: '₹', keyboard: const TextInputType.numberWithOptions(decimal: true), onChanged: (String v) => setState(() {}))),
                const SizedBox(width: 10),
                PickX<List<String>>(
                  label: gstBasisLabel(l.basis),
                  items: kGstBasis,
                  text: (List<String> b) => bi(b[1], b[2]),
                  onSelected: (List<String> b) => setState(() => l.basis = b[0]),
                ),
              ],
            ),
            if (_tax) ...<Widget>[
              const SizedBox(height: 10),
              LineRow(label: 'GST %', child: ChipRow(
                labels: <String>[for (final double r in _gstRates) '${r.round()}%'],
                index: _gstRates.indexOf(l.gst),
                onChanged: (int i) => setState(() => l.gst = _gstRates[i]),
              )),
            ],
            const SizedBox(height: 8),
            Align(alignment: Alignment.centerRight, child: Text('${bi('રકમ', 'Amount')}: ${inr(l.toLine().amount, dec: 2)}', style: ts(13, w: FontWeight.w800, tab: true))),
          ],
        ),
      ),
    );
  }

  Widget _summary() {
    final GstCalc c = calcGst(_built(), inter: _inter, tax: _tax);
    return Surface(
      shadow: false,
      color: Pal.soft,
      padding: const EdgeInsets.all(12),
      child: Column(
        children: <Widget>[
          InfoRow(bi('કરપાત્ર રકમ', 'Taxable value'), inr(c.taxable, dec: 2)),
          if (_tax && c.cgst > 0) InfoRow('CGST', inr(c.cgst, dec: 2)),
          if (_tax && c.sgst > 0) InfoRow('SGST', inr(c.sgst, dec: 2)),
          if (_tax && c.igst > 0) InfoRow('IGST', inr(c.igst, dec: 2)),
          if (c.round.abs() >= 0.005) InfoRow(bi('રાઉન્ડ ઑફ', 'Round off'), signedInr(c.round)),
          InfoRow(bi('કુલ બિલ', 'Invoice total'), inr(c.total, dec: 2), bold: true, color: Pal.brand),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final GstInv? done = _saved;
    if (done != null) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[noteBox('check', 'green', bi('બિલ સેવ થયું: ${done.no}', 'Bill saved: ${done.no}')), GstDetail(done)],
      );
    }
    final List<GstFirm> firms = gstFirms();
    final List<String> vehicles = recentValues(live.kantas.map((Kanta k) => k.vehicle));
    final GstInv? last = _lastBillOfParty();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        LineRow(label: bi('કઈ પેઢીનું બિલ', 'Bill of which firm'), child: ChipRow(
          labels: <String>[for (final GstFirm f in firms) f.name],
          index: firms.indexWhere((GstFirm f) => f.id == _firm),
          onChanged: (int i) => setState(() {
            _firm = firms[i].id;
            if (!_placeTouched && _state.isEmpty) _place = firms[i].state;
          }),
        )),
        const SizedBox(height: 12),
        Seg(
          labels: <String>[bi('ટેક્સ ઇન્વૉઇસ', 'Tax invoice'), bi('બિલ ઑફ સપ્લાય (ટેક્સ નહીં)', 'Bill of supply (no tax)')],
          index: _kind,
          dense: true,
          onChanged: (int i) => setState(() => _kind = i),
        ),
        const SizedBox(height: 14),
        SuggestField(
          label: '${bi('ખરીદનાર', 'Buyer')} *',
          controller: _party,
          options: <String>[for (final GstParty p in gstParties().take(200)) p.name, for (final BuyerAcct a in buyerAccts().values.take(200)) a.label],
          onChanged: (String v) => setState(() {}),
          onPick: (String v) => _fillParty(v),
        ),
        if (last != null)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Align(alignment: Alignment.centerLeft, child: Btn('${bi('છેલ્લા બિલનો માલ વાપરો', 'Use items of last bill')} (${last.no})', icon: 'copy', kind: BtnKind.tonal, dense: true, onTap: () => _useLast(last))),
          ),
        const SizedBox(height: 12),
        Row(
          children: <Widget>[
            Expanded(
              child: FieldX(
                label: 'GSTIN',
                controller: _gstin,
                hint: '24ABCDE1234F1Z5',
                onChanged: (String v) {
                  final String st = gstinState(v);
                  if (st.isNotEmpty) {
                    _state = st;
                    if (!_placeTouched) _place = st;
                  }
                  setState(() {});
                },
                trailing: _gstin.text.trim().isEmpty ? null : Icon(gstinOk(_gstin.text) ? Icons.check_circle : Icons.error_outline, size: 20, color: gstinOk(_gstin.text) ? Pal.ok : Pal.warn),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(child: FieldX(label: bi('મોબાઇલ', 'Mobile'), controller: _phone, keyboard: TextInputType.phone)),
          ],
        ),
        const SizedBox(height: 12),
        FieldX(label: bi('સરનામું', 'Address'), controller: _addr, maxLines: 2),
        const SizedBox(height: 12),
        Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(bi('માલ ક્યાં જાય છે (Place of supply)', 'Place of supply'), style: ts(12.5, w: FontWeight.w600, c: Pal.muted)),
                  const SizedBox(height: 6),
                  PickX<List<String>>(
                    label: _place.isEmpty ? bi('રાજ્ય પસંદ કરો', 'Choose state') : gstStateText(_place),
                    items: kGstStates,
                    text: (List<String> s) => '${s[0]} - ${s[1]}',
                    onSelected: (List<String> s) => setState(() {
                      _place = s[0];
                      _placeTouched = true;
                    }),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            SizedBox(
              width: app.stagePc ? 210 : 158,
              child: DayField(
                label: bi('તારીખ', 'Date'),
                value: _day,
                stacked: true,
                last: dateOnly(DateTime.now()).add(const Duration(days: 30)),
                onChanged: (DateTime d) => setState(() => _day = d),
              ),
            ),
          ],
        ),
        if (_tax)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(_inter ? bi('બીજા રાજ્યમાં - IGST લાગશે', 'Other state - IGST applies') : bi('એ જ રાજ્ય - CGST + SGST લાગશે', 'Same state - CGST + SGST applies'), style: ts(12.5, w: FontWeight.w700, c: Pal.brand)),
          ),
        const SizedBox(height: 14),
        for (int k = 0; k < _lines.length; k++) _lineCard(k),
        Align(alignment: Alignment.centerLeft, child: Btn(bi('બીજી લાઇન ઉમેરો', 'Add another line'), icon: 'plus', kind: BtnKind.outline, dense: true, onTap: () => setState(() => _lines.add(_LineEd())))),
        const SizedBox(height: 14),
        _summary(),
        const SizedBox(height: 14),
        Row(
          children: <Widget>[
            Expanded(child: SuggestField(label: bi('ગાડી નંબર', 'Vehicle'), controller: _veh, options: vehicles)),
            const SizedBox(width: 10),
            Expanded(child: FieldX(label: bi('E-way બિલ નં.', 'E-way bill no.'), controller: _ewb)),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[
            Expanded(child: FieldX(label: bi('બિલ નંબર (ખાલી = ઑટો)', 'Bill no. (empty = auto)'), controller: _no, hint: gstNextNo(_f, _day))),
            const SizedBox(width: 10),
            Expanded(child: FieldX(label: bi('નોંધ', 'Note'), controller: _note)),
          ],
        ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 14,
          runSpacing: 6,
          children: <Widget>[
            _toggle(bi('ખરીદનારના ખાતામાં પણ વેચાણ નાખો', 'Also add as a sale in the buyer ledger'), _khata, (bool v) => setState(() => _khata = v)),
            _toggle(bi('Reverse charge', 'Reverse charge'), _rcm, (bool v) => setState(() => _rcm = v)),
          ],
        ),
        const SizedBox(height: 14),
        if (_err.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(_err, style: ts(13, w: FontWeight.w700, c: Pal.bad))),
        _busy
            ? SizedBox(height: 52, child: Center(child: SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 2.6, color: Pal.brand))))
            : Btn(bi('બિલ સેવ કરો', 'Save bill'), icon: 'check', expand: true, onTap: _save),
      ],
    );
  }

  Widget _toggle(String label, bool v, ValueChanged<bool> on) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Switch(value: v, onChanged: on),
        Flexible(child: Text(label, style: ts(13, w: FontWeight.w600))),
      ],
    );
  }
}

// ------------------------------------------------------------- firm details
class _FirmForm extends StatefulWidget {
  final GstFirm firm;
  const _FirmForm(this.firm);

  @override
  State<_FirmForm> createState() => _FirmFormState();
}

class _FirmFormState extends State<_FirmForm> {
  late final VoidCallback _accept = () {
    _save();
  };

  @override
  void initState() {
    super.initState();
    AcceptHub.push(_accept);
  }

  late final TextEditingController _name = TextEditingController(text: widget.firm.name);
  late final TextEditingController _gstin = TextEditingController(text: widget.firm.gstin);
  late final TextEditingController _addr = TextEditingController(text: widget.firm.addr);
  late final TextEditingController _phone = TextEditingController(text: widget.firm.phone);
  late final TextEditingController _email = TextEditingController(text: widget.firm.email);
  late final TextEditingController _bank = TextEditingController(text: widget.firm.bank);
  late final TextEditingController _acc = TextEditingController(text: widget.firm.acc);
  late final TextEditingController _ifsc = TextEditingController(text: widget.firm.ifsc);
  late final TextEditingController _upi = TextEditingController(text: widget.firm.upi);
  late final TextEditingController _prefix = TextEditingController(text: widget.firm.prefix);
  late final TextEditingController _terms = TextEditingController(text: widget.firm.terms);
  late String _state = widget.firm.state;
  bool _busy = false;

  @override
  void dispose() {
    for (final TextEditingController c in <TextEditingController>[_name, _gstin, _addr, _phone, _email, _bank, _acc, _ifsc, _upi, _prefix, _terms]) {
      c.dispose();
    }
    AcceptHub.pop(_accept);
    super.dispose();
  }

  Future<void> _save() async {
    final GstFirm f = GstFirm(
      widget.firm.id,
      name: _name.text.trim(),
      gstin: gstinClean(_gstin.text),
      addr: _addr.text.trim(),
      state: _state,
      phone: _phone.text.trim(),
      email: _email.text.trim(),
      bank: _bank.text.trim(),
      acc: _acc.text.trim(),
      ifsc: _ifsc.text.trim().toUpperCase(),
      upi: _upi.text.trim(),
      prefix: _prefix.text.trim(),
      terms: _terms.text.trim(),
    );
    setState(() => _busy = true);
    await saveGstFirm(f);
    app.toast(bi('પેઢીની વિગત સેવ થઈ', 'Firm details saved'));
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final bool has = _gstin.text.trim().isNotEmpty;
    final bool ok = has && gstinOk(_gstin.text);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        FieldX(label: bi('પેઢીનું નામ', 'Firm name'), controller: _name),
        const SizedBox(height: 12),
        FieldX(
          label: 'GSTIN',
          controller: _gstin,
          hint: '24ABCDE1234F1Z5',
          onChanged: (String v) {
            final String st = gstinState(v);
            if (st.isNotEmpty) _state = st;
            setState(() {});
          },
          trailing: has ? Icon(ok ? Icons.check_circle : Icons.error_outline, size: 20, color: ok ? Pal.ok : Pal.warn) : null,
        ),
        const SizedBox(height: 12),
        FieldX(label: bi('સરનામું', 'Address'), controller: _addr, maxLines: 3),
        const SizedBox(height: 12),
        Text(bi('રાજ્ય', 'State'), style: ts(12.5, w: FontWeight.w600, c: Pal.muted)),
        const SizedBox(height: 6),
        Align(
          alignment: Alignment.centerLeft,
          child: PickX<List<String>>(
            label: gstStateText(_state),
            items: kGstStates,
            text: (List<String> s) => '${s[0]} - ${s[1]}',
            onSelected: (List<String> s) => setState(() => _state = s[0]),
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: <Widget>[
            Expanded(child: FieldX(label: bi('ફોન', 'Phone'), controller: _phone, keyboard: TextInputType.phone)),
            const SizedBox(width: 10),
            Expanded(child: FieldX(label: 'E-mail', controller: _email, keyboard: TextInputType.emailAddress)),
          ],
        ),
        const SizedBox(height: 12),
        FieldX(label: bi('બેંકનું નામ / શાખા', 'Bank name / branch'), controller: _bank),
        const SizedBox(height: 12),
        Row(
          children: <Widget>[
            Expanded(child: FieldX(label: bi('ખાતા નંબર', 'Account no.'), controller: _acc, keyboard: TextInputType.number)),
            const SizedBox(width: 10),
            Expanded(child: FieldX(label: 'IFSC', controller: _ifsc)),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: <Widget>[
            Expanded(child: FieldX(label: 'UPI ID', controller: _upi)),
            const SizedBox(width: 10),
            Expanded(child: FieldX(label: bi('બિલ નંબરની શરૂઆત', 'Bill no. prefix'), controller: _prefix, hint: 'BI/')),
          ],
        ),
        const SizedBox(height: 12),
        FieldX(label: bi('શરતો / ડિક્લેરેશન (બિલ નીચે)', 'Terms / declaration (bottom of the bill)'), controller: _terms, maxLines: 3),
        const SizedBox(height: 16),
        _busy
            ? SizedBox(height: 52, child: Center(child: SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 2.6, color: Pal.brand))))
            : Btn(bi('સેવ કરો', 'Save'), icon: 'check', expand: true, onTap: _save),
      ],
    );
  }
}

// ------------------------------------------------------------------ screen
class GstScreen extends StatefulWidget {
  const GstScreen({super.key});

  @override
  State<GstScreen> createState() => _GstScreenState();
}

class _GstScreenState extends State<GstScreen> {
  RangeSel _sel = RangeSel(4);
  String _firm = ''; // '' = all firms
  int _show = 0; // 0 all, 1 with GSTIN (B2B), 2 without (B2C), 3 cancelled

  List<PcCol> _cols() => <PcCol>[
        PcCol(bi('તારીખ', 'Date'), 104),
        PcCol(bi('બિલ નં.', 'Bill no.'), 150),
        PcCol(bi('ખરીદનાર', 'Buyer'), 0),
        PcCol('GSTIN', 150),
        PcCol(bi('કરપાત્ર', 'Taxable'), 110, right: true),
        PcCol('GST', 100, right: true),
        PcCol(bi('કુલ', 'Total'), 120, right: true),
        PcCol(bi('સ્થિતિ', 'Status'), 80),
      ];

  Widget _row(BuildContext ctx, GstInv i, List<PcCol> cols) {
    final GstCalc c = i.calc;
    final Color? col = i.cancelled ? Pal.bad : null;
    return pcRow(
      cols,
      <Widget>[
        pcTd(dmy(i.date), c: col),
        pcTd(i.no, bold: true, c: col),
        pcTd(i.party, c: col),
        pcTd(gstinClean(i.gstin).isEmpty ? '-' : gstinClean(i.gstin), c: col),
        pcTd(grp(c.taxable, dec: 2), num: true, c: col),
        pcTd(grp(c.tax, dec: 2), num: true, c: col),
        pcTd(grp(c.total, dec: 2), num: true, bold: true, c: col),
        pcTd(i.cancelled ? bi('રદ', 'Cancelled') : (i.isTax ? 'Tax' : 'BoS'), c: col),
      ],
      onTap: () => openGstDetail(ctx, i),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[gstDoc, saleDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 1100,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final Period p = _sel.period;
          final List<GstFirm> firms = gstFirms();
          final List<GstInv> all = gstInvoices().where((GstInv i) => p.has(i.date) && (_firm.isEmpty || i.firm == _firm)).toList();
          final List<GstInv> shown = all.where((GstInv i) {
            if (_show == 3) return i.cancelled;
            if (i.cancelled) return false;
            if (_show == 1) return i.b2b;
            if (_show == 2) return !i.b2b;
            return true;
          }).toList();
          double taxable = 0;
          double tax = 0;
          double total = 0;
          int bills = 0;
          int b2b = 0;
          final Map<String, List<double>> months = <String, List<double>>{};
          for (final GstInv i in all) {
            if (i.cancelled) continue;
            final GstCalc c = i.calc;
            taxable += c.taxable;
            tax += c.tax;
            total += c.total;
            bills++;
            if (i.b2b) b2b++;
            final List<double> m = months.putIfAbsent('${i.date.year}-${pad2(i.date.month)}', () => <double>[0, 0, 0, 0, 0, 0]);
            m[0] += c.taxable;
            m[1] += c.cgst;
            m[2] += c.sgst;
            m[3] += c.igst;
            m[4] += c.total;
            m[5] += 1;
          }
          final bool setup = !firms.any((GstFirm f) => f.ready);
          final bool pc = app.stagePc;
          final List<PcCol> cols = _cols();
          final List<String> monthKeys = months.keys.toList()..sort((String a, String b) => b.compareTo(a));
          return <Widget>[
            ScreenHeader(bi('GST બિલ', 'GST bills'), sub: p.label, actions: <Widget>[
              IconBtn('gear', tip: bi('પેઢીની વિગત', 'Firm details'), onTap: () => _pickFirm(ctx, firms)),
              IconBtn('plus', tip: bi('નવું બિલ', 'New bill'), onTap: () => openGstForm(ctx)),
            ]),
            statusBanner(),
            if (setup) noteBox('warn', 'amber', bi('પહેલાં પેઢીની GST વિગત (GSTIN, સરનામું, બેંક) ભરો - અહીં દબાવો', 'First fill the GST details of the firm (GSTIN, address, bank) - tap here'), onTap: () => _pickFirm(ctx, firms)),
            RangeBar(sel: _sel, presets: const <int>[0, 2, 3, 4, 5, 6], onChanged: (RangeSel s) => setState(() => _sel = s)),
            const SizedBox(height: 10),
            ChipRow(
              labels: <String>[bi('બધી પેઢી', 'All firms'), for (final GstFirm f in firms) f.name],
              index: _firm.isEmpty ? 0 : firms.indexWhere((GstFirm f) => f.id == _firm) + 1,
              onChanged: (int i) => setState(() => _firm = i == 0 ? '' : firms[i - 1].id),
            ),
            const SizedBox(height: 12),
            HeroCard(
              title: bi('કુલ બિલ રકમ', 'Total billed'),
              value: inrC(total),
              unit: '',
              sub: '$bills ${bi('બિલ', 'bills')} · $b2b B2B',
              chips: <HeroChip>[
                HeroChip('rupee', '${bi('કરપાત્ર', 'Taxable')} ${inrC(taxable)}'),
                HeroChip('percentbox', 'GST ${inrC(tax)}'),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                tExp(child: Btn(bi('નવું GST બિલ', 'New GST bill'), icon: 'plus', onTap: () => openGstForm(ctx))),
                const SizedBox(width: 8),
                tExp(child: Btn(bi('CA માટે CSV કૉપિ', 'Copy CSV for CA'), icon: 'table', kind: BtnKind.tonal, onTap: () => copyText(gstCsv(all.where((GstInv i) => !i.cancelled).toList()), msg: bi('CSV કૉપિ થયું - Excel માં paste કરો', 'CSV copied - paste in Excel')))),
              ],
            ),
            const SizedBox(height: 12),
            if (monthKeys.isNotEmpty)
              Panel(
                title: bi('મહિના મુજબ સરવાળો (GSTR-1 માટે)', 'Month totals (for GSTR-1)'),
                child: Column(
                  children: <Widget>[
                    for (final String k in monthKeys)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 5),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Expanded(flex: 2, child: Text(k, style: ts(13, w: FontWeight.w800))),
                            Expanded(
                              flex: 5,
                              child: Text(
                                '${bi('કરપાત્ર', 'Taxable')} ${inr(months[k]![0])} · CGST ${inr(months[k]![1])} · SGST ${inr(months[k]![2])} · IGST ${inr(months[k]![3])}',
                                style: ts(12, c: Pal.muted, tab: true),
                              ),
                            ),
                            Text(inr(months[k]![4]), style: ts(13, w: FontWeight.w800, tab: true)),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
            const SizedBox(height: 12),
            ChipRow(
              labels: <String>[bi('બધા', 'All'), 'B2B (GSTIN)', 'B2C', bi('રદ', 'Cancelled')],
              index: _show,
              onChanged: (int i) => setState(() => _show = i),
            ),
            const SizedBox(height: 10),
            if (shown.isEmpty) EmptyBox(icon: 'receipt', title: bi('આ સમયમાં કોઈ બિલ નથી', 'No bills in this period'), sub: bi('ઉપર "નવું GST બિલ" દબાવો', 'Tap "New GST bill" above')),
            if (pc && shown.isNotEmpty) ...<Widget>[
              pcHead(cols),
              for (final GstInv i in shown.take(300)) _row(ctx, i, cols),
              pcTotal(cols, bi('કુલ', 'Total'), labelAt: 2, vals: <int, String>{4: grp(taxable, dec: 2), 5: grp(tax, dec: 2), 6: grp(total, dec: 2)}),
            ] else
              for (final GstInv i in shown.take(200))
                lineItem(
                  icon: 'receipt',
                  tone: i.cancelled ? 'rose' : (i.isTax ? 'teal' : 'slate'),
                  title: i.party,
                  sub: '${i.no} · ${dayLabel(i.date)}${i.b2b ? ' · B2B' : ''}${i.cancelled ? ' · ${bi('રદ', 'Cancelled')}' : ''}',
                  trailing: inr(i.calc.total),
                  trailingSub: i.isTax ? 'GST ${inr(i.calc.tax)}' : bi('ટેક્સ નહીં', 'No tax'),
                  onTap: () => openGstDetail(ctx, i),
                ),
          ];
        },
      ),
    );
  }

  /// One firm = open its details; several firms = choose first.
  Future<void> _pickFirm(BuildContext ctx, List<GstFirm> firms) {
    return openPanel(
      ctx,
      title: bi('પેઢી પસંદ કરો', 'Choose a firm'),
      width: 440,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          for (final GstFirm f in firms)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Surface(
                onTap: () {
                  Navigator.of(ctx).pop();
                  openGstFirm(ctx, f);
                },
                child: Row(
                  children: <Widget>[
                    IconChip('factory', tone: f.ready ? 'green' : 'amber', size: 40),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(f.name, style: ts(14.5, w: FontWeight.w800)),
                          Text(f.ready ? 'GSTIN ${gstinClean(f.gstin)}' : bi('GSTIN હજી નથી', 'GSTIN not entered'), style: ts(12.5, c: f.ready ? Pal.muted : Pal.warn)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
