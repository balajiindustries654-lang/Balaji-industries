import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/device.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/icons.dart';
import '../../core/keep_awake.dart';
import '../../core/palette.dart';
import '../../data/engine.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../widgets/common.dart';
import '../../widgets/page.dart';
import '../../data/offline.dart';
import 'field.dart' show confirmBox;
import 'kit2.dart' show noteBox;
import 'ui.dart';

String roleName(String r) {
  switch (r) {
    case 'admin':
      return bi('માલિક / એડમિન', 'Owner / admin');
    case 'worker':
      return bi('સ્ટાફ - મજૂર', 'Staff - labour');
    case 'waybridge':
      return bi('સ્ટાફ - કાંટો', 'Staff - weighbridge');
    case 'maal_entry':
      return bi('સ્ટાફ - માલ', 'Staff - maal');
    case 'farmer':
      return bi('ખેડૂત', 'Farmer');
  }
  return r;
}

class LiveSettingsScreen extends StatefulWidget {
  const LiveSettingsScreen({super.key});

  @override
  State<LiveSettingsScreen> createState() => _LiveSettingsState();
}

class _LiveSettingsState extends State<LiveSettingsScreen> {
  late final TextEditingController _pct = TextEditingController(text: '${live.cfg.pct}');
  late final TextEditingController _floor = TextEditingController(text: '${live.cfg.floorKg}');
  late final TextEditingController _wait = TextEditingController(text: '${live.cfg.waitH}');
  late final TextEditingController _win = TextEditingController(text: '${live.cfg.windowH}');
  late final TextEditingController _direct = TextEditingController(text: live.cfg.direct.join(', '));
  bool _busy = false;

  @override
  void dispose() {
    _pct.dispose();
    _floor.dispose();
    _wait.dispose();
    _win.dispose();
    _direct.dispose();
    super.dispose();
  }

  Future<void> _saveCfg() async {
    final MatchCfg c = MatchCfg(
      pct: dbl(_pct.text, 0.5),
      floorKg: dbl(_floor.text, 100),
      waitH: dbl(_wait.text, 12).round(),
      windowH: dbl(_win.text, 36).round(),
      direct: _direct.text.split(',').map((String s) => s.trim()).where((String s) => s.isNotEmpty).toList(),
    );
    setState(() => _busy = true);
    final String? e = await live.saveCfg(c);
    if (!mounted) return;
    setState(() => _busy = false);
    app.toast(e ?? bi('સેવ થયું', 'Saved'));
  }

  Widget _label(String t) => Padding(padding: const EdgeInsets.only(bottom: 8, top: 4), child: Text(t, style: ts(12.5, w: FontWeight.w700, c: Pal.muted)));

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 1000,
      rows: (BuildContext ctx) {
        final Profile? me = live.me;

        final Widget account = Panel(
          title: bi('મારું ખાતું', 'My account'),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Row(
                children: <Widget>[
                  Avatar(me == null || me.name.isEmpty ? '?' : me.name, size: 48),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(me == null || me.name.isEmpty ? '—' : me.name, style: ts(16, w: FontWeight.w800)),
                        Text(me == null ? '' : '+91 ${me.mobile}', style: ts(13, c: Pal.muted)),
                      ],
                    ),
                  ),
                  Pill(roleName(me?.role ?? ''), tone: 'teal', small: true),
                ],
              ),
              const SizedBox(height: 14),
              InfoRow(bi('છેલ્લું અપડેટ', 'Last updated'), live.loadedAt == null ? '—' : '${dayLabel(live.loadedAt!)} ${hm(live.loadedAt!)}'),
              InfoRow(bi('ચિઠ્ઠી / કાંટો / માલ', 'Chits / kanta / maal'), '${live.chits.length} / ${live.kantas.length} / ${live.maals.length}'),
              const SizedBox(height: 10),
              _label(bi('કેટલા દિવસનો ડેટા લોડ કરવો', 'Days of data to load')),
              Seg(
                dense: true,
                labels: const <String>['30', '45', '90', '180', '365'],
                index: <int>[30, 45, 90, 180, 365].indexOf(live.days) < 0 ? 1 : <int>[30, 45, 90, 180, 365].indexOf(live.days),
                onChanged: (int i) => live.setDays(<int>[30, 45, 90, 180, 365][i]),
              ),
              const SizedBox(height: 16),
              Btn(bi('લૉગ આઉટ', 'Log out'), icon: 'out', kind: BtnKind.danger, expand: true, onTap: () => live.logout()),
            ],
          ),
        );

        final Widget look = Panel(
          title: bi('દેખાવ', 'Appearance'),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              if (live.isAdmin) ...<Widget>[
                _label(bi('સરળ મોડ (ફક્ત રોજનો કાચા માલનો હિસાબ)', 'Simple mode (only the daily raw-material account)')),
                Seg(labels: <String>[bi('ચાલુ', 'On'), bi('બંધ - બધું બતાવો', 'Off - show everything')], index: app.simple ? 0 : 1, onChanged: (int i) => app.setSimple(i == 0)),
                const SizedBox(height: 4),
                Text(bi('ચાલુ હોય તો ફક્ત જરૂરી સ્ક્રીન અને બટન દેખાય છે. બંધ કરો તો બીજી બધી સ્ક્રીન પાછી આવે છે - કંઈ કાઢી નાખ્યું નથી.', 'When on, only the needed screens and buttons show. Switch it off and all the other screens come back - nothing is deleted.'), style: ts(11.5, c: Pal.muted)),
                const SizedBox(height: 16),
              ],
              _label(bi('એપ ચાલુ હોય ત્યારે સ્ક્રીન / PC બંધ ન થાય', 'Keep the screen / PC awake while the app is open')),
              AnimatedBuilder(
                animation: KeepAwake.tick,
                builder: (BuildContext c, Widget? w) => Seg(labels: <String>[bi('ચાલુ', 'On'), bi('બંધ', 'Off')], index: KeepAwake.on ? 0 : 1, onChanged: (int i) => KeepAwake.setOn(i == 0)),
              ),
              const SizedBox(height: 16),
              _label(bi('થીમ', 'Theme')),
              Seg(labels: <String>[bi('લાઇટ', 'Light'), bi('ડાર્ક', 'Dark')], icons: const <String>['sun', 'moon'], index: app.dark ? 1 : 0, onChanged: (int i) => app.setDark(i == 1)),
              const SizedBox(height: 16),
              _label(bi('ભાષા', 'Language')),
              Seg(labels: const <String>['ગુજરાતી', 'English'], index: L.gu ? 0 : 1, onChanged: (int i) {
                if ((i == 0) != L.gu) {
                  app.toggleLang();
                  live.rederive();
                }
              }),
              const SizedBox(height: 16),
              _label(bi('વ્યૂ', 'View')),
              Seg(
                labels: <String>[bi('ઓટો', 'Auto'), bi('ફોન', 'Phone'), 'PC'],
                icons: const <String>['auto', 'phone', 'pc'],
                index: app.viewMode.index,
                onChanged: (int i) => app.setView(ViewMode.values[i]),
              ),
              const SizedBox(height: 16),
              _label(bi('PC દેખાવ', 'PC look')),
              Seg(
                labels: const <String>['Tally Prime', 'Modern'],
                index: app.tallyMode ? 0 : 1,
                onChanged: (int i) => app.setTally(i == 0),
              ),
              const SizedBox(height: 16),
              _label(bi('અક્ષરની સાઇઝ', 'Letter size')),
              Seg(
                dense: true,
                labels: <String>[bi('નાની', 'Small'), bi('સામાન્ય', 'Normal'), bi('મોટી', 'Large'), bi('ખૂબ મોટી', 'X-Large')],
                index: app.textScale < 0.95 ? 0 : (app.textScale < 1.08 ? 1 : (app.textScale < 1.22 ? 2 : 3)),
                onChanged: (int i) => app.setTextScale(<double>[0.9, 1.0, 1.15, 1.3][i]),
              ),
              const SizedBox(height: 16),
              _label('${bi('સ્ક્રીન ઝૂમ (ફક્ત PC)', 'Screen zoom (PC only)')} · ${(app.pcZoom * 100).round()}%'),
              Seg(
                dense: true,
                labels: const <String>['75%', '85%', '100%', '115%'],
                index: app.pcZoom < 0.8 ? 0 : (app.pcZoom < 0.93 ? 1 : (app.pcZoom < 1.07 ? 2 : 3)),
                onChanged: (int i) => app.setPcZoom(<double>[0.75, 0.85, 1.0, 1.15][i]),
              ),
            ],
          ),
        );

        final Widget limits = Panel(
          title: bi('ઘટ / ફરકની મર્યાદા', 'Difference limits'),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Row(
                children: <Widget>[
                  Expanded(child: FieldX(label: bi('માન્ય ફરક', 'Allowed difference'), controller: _pct, suffix: '%', keyboard: const TextInputType.numberWithOptions(decimal: true))),
                  const SizedBox(width: 10),
                  Expanded(child: FieldX(label: bi('ઓછામાં ઓછો', 'At least'), controller: _floor, suffix: 'KG', keyboard: const TextInputType.numberWithOptions(decimal: true))),
                ],
              ),
              const SizedBox(height: 14),
              Row(
                children: <Widget>[
                  Expanded(child: FieldX(label: bi('કાંટા માટે રાહ', 'Wait for kanta'), controller: _wait, suffix: bi('કલાક', 'h'), keyboard: TextInputType.number)),
                  const SizedBox(width: 10),
                  Expanded(child: FieldX(label: bi('મેળ માટે મહત્તમ અંતર', 'Max gap to match'), controller: _win, suffix: bi('કલાક', 'h'), keyboard: TextInputType.number)),
                ],
              ),
              const SizedBox(height: 14),
              FieldX(label: bi('સીધો મિલ મોકલાતો માલ (કોમા થી)', 'Goods sent straight to the mill (comma)'), controller: _direct),
              const SizedBox(height: 16),
              _busy
                  ? SizedBox(height: 48, child: Center(child: SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2.6, color: Pal.brand))))
                  : Btn(bi('સેવ કરો', 'Save'), icon: 'check', expand: true, onTap: _saveCfg),
            ],
          ),
        );

        const List<int> secs = <int>[0, 30, 75, 120, 300];
        final int si = secs.indexOf(live.refreshSec) < 0 ? 2 : secs.indexOf(live.refreshSec);
        Widget link(String icon, String tone, String title, String sub, String route) {
          return Surface(
            margin: const EdgeInsets.only(top: 8),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            onTap: () => app.go(route),
            child: Row(
              children: <Widget>[
                IconChip(icon, tone: tone, size: 38),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(title, style: ts(14, w: FontWeight.w800)),
                      Text(sub, style: ts(12, c: Pal.muted)),
                    ],
                  ),
                ),
                Icon(ic('chev'), size: 20, color: Pal.faint),
              ],
            ),
          );
        }

        final Widget safety = Panel(
          title: bi('સુરક્ષા અને રિફ્રેશ', 'Security and refresh'),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              _label(bi('ડેટા આપોઆપ તાજો થાય', 'Refresh data automatically')),
              Seg(
                dense: true,
                labels: <String>[bi('બંધ', 'Off'), bi('30 સેકન્ડ', '30 s'), bi('75 સેકન્ડ', '75 s'), bi('2 મિનિટ', '2 min'), bi('5 મિનિટ', '5 min')],
                index: si,
                onChanged: (int i) => live.setRefreshSec(secs[i]),
              ),
              link('lock', app.pinOn ? 'green' : 'slate', bi('PIN લોક', 'PIN lock'), app.pinOn ? bi('ચાલુ - એપ બંધ કરીને ખોલો ત્યારે PIN માંગશે', 'On - asked when you come back to the app') : bi('બંધ - ફોન બીજાના હાથમાં જાય તો સુરક્ષા માટે ચાલુ કરો', 'Off - turn it on to protect the app'), 'pin_lock'),
              if (live.isAdmin) link('verified', 'green', bi('જોઈ લીધેલા', 'Checked alerts'), '${live.reviewed.length}', 'reviewed'),
              if (live.isAdmin) link('hist', 'slate', bi('ફેરફાર ઇતિહાસ', 'Change history'), bi('કોણે શું સુધાર્યું', 'Who edited what'), 'history'),
              if (DeviceScope.isPc(ctx)) link('keyboard', 'teal', bi('કીબોર્ડ શોર્ટકટ', 'Keyboard shortcuts'), '?', 'shortcuts'),
              link('health', 'blue', bi('એપ તપાસ', 'App diagnostics'), bi('સર્વર, સ્કેનર અને ડેટાની સ્થિતિ', 'Server, scanner and data status'), 'diagnostics'),
              if (live.isAdmin) link('rupee', 'green', bi('ભાવ · રેટ', 'Rates'), bi('માલ મુજબ ₹ પ્રતિ 20 KG', 'Rs per 20 KG by material'), 'rates'),
              if (live.isAdmin) link('target', 'green', bi('રોજનો ટાર્ગેટ', 'Daily target'), bi('ટન માં લક્ષ્ય નક્કી કરો', 'Set the goal in tons'), 'target'),
              if (live.isAdmin) link('balance', 'violet', bi('ઘટની મર્યાદા અજમાવો', 'Try the loss limit'), bi('મર્યાદા બદલતા કેટલી ગાડી ફરકમાં આવે', 'See how many trips fall outside a limit'), 'tolerance'),
              if (live.isAdmin) link('night', 'slate', bi('રાતનો સમય', 'Night window'), bi('રાતની એન્ટ્રી ક્યારથી ક્યાં સુધી', 'Hours counted as night'), 'after_hours'),
            ],
          ),
        );

        final Widget offlineP = Panel(
          title: bi('ઇન્ટરનેટ વગર વાપરો', 'Use without internet'),
          sub: bi('ડેટા આ ફોન / PC પર સેવ રહે છે', 'The data is kept on this phone / PC'),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              InfoRow(bi('હમણાં', 'Now'), live.offline ? bi('ઑફલાઇન', 'Offline') : bi('ઓનલાઇન', 'Online'), color: live.offline ? Pal.bad : Pal.ok, bold: true),
              InfoRow(bi('સેવ કરેલો ડેટા', 'Saved data'), live.loadedAt == null ? '—' : '${dayLabel(live.loadedAt!)} ${hm(live.loadedAt!)}'),
              FutureBuilder<int>(
                future: OfflineStore.bytes(),
                builder: (BuildContext fc, AsyncSnapshot<int> sn) => InfoRow(bi('સેવ કરેલી જગ્યા', 'Space used'), sn.hasData ? '${((sn.data ?? 0) / 1048576).toStringAsFixed(1)} MB' : '…'),
              ),
              InfoRow(bi('મોકલવાની બાકી એન્ટ્રી', 'Entries waiting to upload'), '${live.pending.length}', color: live.pending.isEmpty ? null : Pal.warn, bold: live.pending.isNotEmpty),
              const SizedBox(height: 6),
              noteBox(
                'info',
                'blue',
                bi('એક વાર ઇન્ટરનેટ સાથે લૉગિન કરો. પછી ઇન્ટરનેટ વગર પણ લૉગિન, જૂનો ડેટા જોવો, Tally ડેટા જોવો અને નવી ચિઠ્ઠી / કાંટો / માલ એન્ટ્રી સેવ કરવી ચાલશે. ઇન્ટરનેટ આવે ત્યારે એન્ટ્રી આપોઆપ મોકલાય છે.',
                    'Log in once with internet. After that you can log in, see the saved data, see the Tally data and save new chit / kanta / maal entries without internet. Entries are sent automatically when the internet is back.'),
              ),
              Btn(bi('હમણાં તાજું કરો', 'Refresh now'), icon: 'refresh', kind: BtnKind.tonal, expand: true, onTap: live.refresh),
              const SizedBox(height: 8),
              Btn(
                bi('આ ડિવાઇસ પરથી ઑફલાઇન ડેટા કાઢો', 'Remove the offline data from this device'),
                icon: 'trash',
                kind: BtnKind.ghost,
                expand: true,
                onTap: () async {
                  final bool yes = await confirmBox(
                    ctx,
                    title: bi('ઑફલાઇન ડેટા કાઢવો?', 'Remove the offline data?'),
                    text: bi('સેવ કરેલો ડેટા અને ઑફલાઇન લૉગિન આ ડિવાઇસ પરથી જશે. સર્વર પરનો ડેટા એમ જ રહેશે. ફરી ઇન્ટરનેટ સાથે લૉગિન કરવું પડશે.',
                        'The saved data and the offline login go from this device. Data on the server stays. You must log in with internet again.'),
                    yes: bi('હા, કાઢો', 'Yes, remove'),
                    no: bi('ના', 'No'),
                  );
                  if (yes) {
                    await live.clearOffline();
                    app.toast(bi('કાઢી નાખ્યું', 'Removed'));
                  }
                },
              ),
            ],
          ),
        );

        return <Widget>[
          ScreenHeader(bi('સેટિંગ્સ', 'Settings')),
          statusBanner(),
          SplitPane(children: <Widget>[
            account,
            Column(children: <Widget>[look, const SizedBox(height: 16), safety, const SizedBox(height: 16), offlineP, if (live.isAdmin) const SizedBox(height: 16), if (live.isAdmin) limits])
          ]),
        ];
      },
    );
  }
}

// ==================================================================== queue
/// Entries saved on the phone while there was no internet.
class QueueScreen extends StatelessWidget {
  const QueueScreen({super.key});

  String _kind(String k) {
    if (k == 'chit') return bi('ચિઠ્ઠી', 'Chit');
    if (k == 'kanta') return bi('કાંટો', 'Kanta');
    return bi('માલ', 'Maal');
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 760,
      rows: (BuildContext ctx) {
        return <Widget>[
          ScreenHeader(bi('મોકલવાની બાકી', 'Waiting to upload'), sub: '${live.pending.length}', actions: <Widget>[
            Btn(bi('હવે મોકલો', 'Send now'), icon: 'cloudup', dense: true, onTap: live.flush),
          ]),
          statusBanner(),
          if (live.pending.isEmpty)
            EmptyBox(icon: 'cloud', title: bi('બધું મોકલાઈ ગયું છે', 'Everything is uploaded'))
          else
            for (final PendingItem it in live.pending)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Surface(
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    children: <Widget>[
                      IconChip(it.kind == 'chit' ? 'receipt' : (it.kind == 'kanta' ? 'scale' : 'bag'), tone: it.err.isEmpty ? 'blue' : 'rose', size: 40),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text('${_kind(it.kind)} · ${it.title}', maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(13.5, w: FontWeight.w800)),
                            Text(() {
                              final DateTime? t = parseTs(it.queuedAt);
                              return t == null ? '' : '${dayLabel(t)} ${hm(t)}';
                            }(), style: ts(12, c: Pal.muted)),
                            if (it.err.isNotEmpty) Text(it.err, style: ts(12, w: FontWeight.w700, c: Pal.bad)),
                          ],
                        ),
                      ),
                      IconBtn('trash', color: Pal.bad, onTap: () => live.dropPending(it), tip: bi('દૂર કરો', 'Remove')),
                    ],
                  ),
                ),
              ),
        ];
      },
    );
  }
}
