import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../core/flags.dart' show kSimple;
import '../../data/live_store.dart';
import '../../data/tally_rules.dart';
import '../../data/offline.dart';
import '../../data/supa.dart' show SupaError;
import '../../widgets/common.dart';
import '../../widgets/launch.dart';
import '../../widgets/page.dart';
import 'kit.dart' show MetricTile, metricGrid, SkeletonList;
import 'kit2.dart' show lineItem, noteBox, caption;
import '../../data/insights.dart' show csvOf;
import '../../data/live_models.dart' show Chit, dbl, nameKey;
import '../../data/money.dart' show PayItem, payItems, chitAmount, payKg, removePayItem;
import '../../data/owner_docs.dart' show SyncDoc, payDoc, prefDoc;
import 'field.dart' show confirmBox;
import 'money_screens.dart' show DocsScope;

part 'tally_logic.dart';
part 'tally_tabs.dart';
part 'tally_tabs2.dart';
part 'tally_agent.dart';
part 'tally_glance.dart';

// ======================================================================
// Tally data (READ ONLY) - what the PC Agent copied from Tally into
// Supabase (tables tally_vouchers + tally_ledgers). Nothing is ever
// written back to Tally from here.
// ======================================================================

double _n(Object? v) {
  if (v is num) return v.toDouble();
  return double.tryParse('${v ?? ''}') ?? 0;
}

String _s(Object? v) => v == null ? '' : '$v'.trim();

final RegExp _nonWordRe = RegExp(r'[^\p{L}\p{M}\p{N}]', unicode: true);

String _nk(String s) => s.toLowerCase().replaceAll(_nonWordRe, '');

String _dk(DateTime d) => '${d.year}-${pad2(d.month)}-${pad2(d.day)}';

String _rs(double v) => inr(v, dec: (v - v.roundToDouble()).abs() < 0.005 ? 0 : 2);

String firmName(String id) {
  switch (id) {
    case 'patel':
      return 'Patel Enterprises';
    case 'shreenathji':
      return 'Shreenathji Enterprises';
    case 'balaji':
      return 'Balaji Industries';
  }
  return id.isEmpty ? '—' : id;
}

String _firmShort(String id) {
  switch (id) {
    case 'patel':
      return 'Patel';
    case 'shreenathji':
      return 'Shreenathji';
    case 'balaji':
      return 'Balaji';
  }
  return id.isEmpty ? '—' : id;
}

int _firmOrder(String id) {
  switch (id) {
    case 'patel':
      return 0;
    case 'shreenathji':
      return 1;
    case 'balaji':
      return 2;
  }
  return 3;
}

String _kindOf(String parent) {
  final String p = parent.toLowerCase();
  if (p.contains('creditor')) return 'creditor';
  if (p.contains('debtor')) return 'debtor';
  if (p.contains('bank')) return 'bank';
  if (p.contains('cash')) return 'cash';
  if (p.contains('expense')) return 'expense';
  if (p.contains('income') || p.contains('sales')) return 'income';
  if (p.contains('purchase')) return 'purchase';
  return 'other';
}

// ------------------------------------------------------------------ models
class TLine {
  final String ledger;
  final double amount;
  const TLine(this.ledger, this.amount);
}

class TItem {
  final String name;
  final double qty;
  final String unit;
  final double rate;
  final double amount;
  const TItem(this.name, this.qty, this.unit, this.rate, this.amount);
}

class TVoucher {
  final int id;
  final String firm;
  final String vkey;
  final String date;
  final String type;
  final String base;
  final String no;
  final String party;
  final double amount;
  final String narr;
  final String bank;
  final String mode;
  final String utr;
  final bool cancelled;
  final bool optional;
  final List<TLine> lines;
  final List<TLine> other;
  final List<TItem> items;
  final DateTime? synced;

  const TVoucher({
    required this.id,
    required this.firm,
    required this.vkey,
    required this.date,
    required this.type,
    required this.base,
    required this.no,
    required this.party,
    required this.amount,
    required this.narr,
    required this.bank,
    required this.mode,
    required this.utr,
    required this.cancelled,
    required this.optional,
    required this.lines,
    required this.other,
    required this.items,
    required this.synced,
  });

  DateTime get dt => DateTime.tryParse(date) ?? DateTime(2000);

  String get title {
    if (party.isNotEmpty) return party;
    if (lines.isNotEmpty && lines.first.ledger.isNotEmpty) return lines.first.ledger;
    return type;
  }

  static List<TLine> _pairs(Object? v) {
    final List<TLine> out = <TLine>[];
    if (v is List) {
      for (final Object? e in v) {
        if (e is Map) out.add(TLine(_s(e['ledger']), _n(e['amount'])));
      }
    }
    return out;
  }

  factory TVoucher.fromJson(Map<String, dynamic> j) {
    final Object? raw = j['lines'];
    final List<TLine> lines = <TLine>[];
    List<TLine> other = <TLine>[];
    final List<TItem> items = <TItem>[];
    if (raw is List) {
      for (final Object? e in raw) {
        if (e is Map) lines.add(TLine(_s(e['ledger']), _n(e['amount'])));
      }
      if (raw.isNotEmpty && raw.first is Map) {
        final Map<dynamic, dynamic> f = raw.first as Map<dynamic, dynamic>;
        other = _pairs(f['o']);
        final Object? inv = f['inv'];
        if (inv is List) {
          for (final Object? e in inv) {
            if (e is Map) items.add(TItem(_s(e['n']), _n(e['q']), _s(e['u']), _n(e['r']), _n(e['a'])));
          }
        }
      }
    }
    final String src = _s(j['src']);
    return TVoucher(
      id: _n(j['id']).toInt(),
      firm: _s(j['firm']),
      vkey: _s(j['vkey']),
      date: _s(j['v_date']),
      type: _s(j['v_type']),
      base: _s(j['base_type']).isEmpty ? 'other' : _s(j['base_type']),
      no: _s(j['v_no']),
      party: _s(j['party']),
      amount: _n(j['amount']),
      narr: _s(j['narration']),
      bank: _s(j['bank_ledger']),
      mode: _s(j['mode']),
      utr: _s(j['utr']),
      cancelled: j['cancelled'] == true,
      optional: src == 'xmlo',
      lines: lines,
      other: other,
      items: items,
      synced: DateTime.tryParse(_s(j['synced_at']))?.toLocal(),
    );
  }
}

class TLedger {
  final String firm;
  final String name;
  final String parent;
  final double closing; // Cr = plus, Dr = minus (as Tally gives it)
  final DateTime? at;
  const TLedger(this.firm, this.name, this.parent, this.closing, this.at);
  String get kind => _kindOf(parent);
}

class TStock {
  final String firm;
  final String name;
  final String unit;
  final double value;
  final String group;
  final double qty;
  const TStock(this.firm, this.name, this.unit, this.value, this.group, this.qty);
}

// ------------------------------------------------------------------- store
class TallyStore extends ChangeNotifier {
  TallyStore() {
    // simple mode switched on / off in Settings: the shown list changes at once
    app.addListener(_onApp);
  }

  bool _lastSimple = kSimple;

  void _onApp() {
    if (kSimple == _lastSimple) return;
    _lastSimple = kSimple;
    _refilter();
    notifyListeners();
  }

  /// Everything the PC Agent copied (nothing left out).
  List<TVoucher> allVouchers = <TVoucher>[];

  /// What is shown as transactions (the owner's rule, see data/tally_rules.dart): the sales of Patel, Shreenathji and Balaji, and the cash /
  /// online money of the other firm. Simple mode OFF: same as [allVouchers].
  List<TVoucher> vouchers = <TVoucher>[];

  /// The purchase vouchers of all the firms - only for the check "is it already made in Pro?" (never makes a purchase).
  List<TVoucher> purchases = <TVoucher>[];
  List<TLedger> ledgers = <TLedger>[];
  List<TStock> stock = <TStock>[];
  bool loading = false;
  String error = '';
  DateTime? loadedAt;

  /// The PC Agent's heartbeat (row "~A~beat" of firm "_sys" in tally_ledgers) - shows if the Agent is alive and why a sync failed.
  Map<String, dynamic>? beat;
  DateTime? beatRowAt;

  void _setBeat(Map<String, dynamic>? row) {
    beat = null;
    beatRowAt = null;
    if (row == null) return;
    beatRowAt = DateTime.tryParse(_s(row['updated_at']))?.toLocal();
    try {
      final Object? d = jsonDecode(_s(row['parent']));
      if (d is Map) beat = Map<String, dynamic>.from(d);
    } catch (_) {}
  }

  /// Light re-read of just the heartbeat row (used while waiting for a "sync now" answer).
  Future<void> refreshBeat() async {
    try {
      final List<Map<String, dynamic>> r = await live.supa.select(
        'tally_ledgers',
        <String, String>{'select': 'parent,updated_at', 'firm': 'eq._sys', 'name': 'eq.~A~beat'},
        limit: 1,
      );
      _setBeat(r.isEmpty ? null : r.first);
      notifyListeners();
    } catch (_) {}
  }

  /// Asks the Agent on the Tally PC to do something (sync / full / reload). The Agent only reads from Tally.
  Future<void> sendCmd(Map<String, dynamic> cmd) async {
    await live.supa.upsert(
      'tally_ledgers',
      <String, dynamic>{'firm': '_sys', 'name': '~A~cmd', 'parent': jsonEncode(cmd), 'closing': 0, 'updated_at': DateTime.now().toUtc().toIso8601String()},
      'firm,name',
    );
  }

  static String fyStart() {
    final DateTime n = DateTime.now();
    return '${n.month >= 4 ? n.year : n.year - 1}-04-01';
  }

  DateTime? get lastSync {
    DateTime? best;
    for (final TVoucher v in vouchers) {
      final DateTime? s = v.synced;
      if (s != null && (best == null || s.isAfter(best))) best = s;
    }
    for (final TLedger l in ledgers) {
      final DateTime? s = l.at;
      if (s != null && (best == null || s.isAfter(best))) best = s;
    }
    return best;
  }

  List<String> get firms {
    final Set<String> s = <String>{};
    for (final TVoucher v in vouchers) {
      s.add(v.firm);
    }
    for (final TLedger l in ledgers) {
      s.add(l.firm);
    }
    s.remove('');
    final List<String> l = s.toList();
    l.sort((String a, String b) {
      final int c = _firmOrder(a).compareTo(_firmOrder(b));
      return c != 0 ? c : a.compareTo(b);
    });
    return l;
  }

  String _msg(Object e) {
    final String m = e is SupaError ? e.message : '$e';
    if (RegExp(r'does not exist|relation|schema cache|42P01|PGRST205|permission|policy|row-level', caseSensitive: false).hasMatch(m)) {
      return '${bi('Supabase માં supabase-tally.sql ચલાવો અને માલિક (admin) તરીકે લૉગિન કરો. ', 'Run supabase-tally.sql in Supabase and sign in as the owner (admin). ')}$m';
    }
    return m;
  }

  /// true while the screen shows the copy saved on this device (no internet)
  bool fromCache = false;
  DateTime? cacheAt;

  void _apply(List<Map<String, dynamic>> vr, List<Map<String, dynamic>> lr) {
    final List<TVoucher> vs = <TVoucher>[];
    for (final Map<String, dynamic> j in vr) {
      vs.add(TVoucher.fromJson(j));
    }
    final List<TLedger> ls = <TLedger>[];
    final List<TStock> st = <TStock>[];
    Map<String, dynamic>? beatRow;
    for (final Map<String, dynamic> j in lr) {
      final String name = _s(j['name']);
      final String parent = _s(j['parent']);
      final String firm = _s(j['firm']);
      if (firm == '_sys') {
        if (name == '~A~beat') beatRow = j;
        continue;
      }
      if (name.startsWith('~S~')) {
        final List<String> p = parent.split('|');
        st.add(TStock(firm, name.substring(3), p.length > 1 ? p[1] : '', p.length > 2 ? (double.tryParse(p[2]) ?? 0) : 0, p.length > 3 ? p[3] : '', _n(j['closing'])));
      } else if (!RegExp(r'^~[A-Z]~').hasMatch(name)) {
        ls.add(TLedger(firm, name, parent, _n(j['closing']), DateTime.tryParse(_s(j['updated_at']))?.toLocal()));
      }
    }
    allVouchers = vs;
    _refilter();
    ledgers = ls;
    stock = st;
    _setBeat(beatRow);
  }

  void _refilter() {
    _lastSimple = kSimple;
    vouchers = <TVoucher>[
      for (final TVoucher v in allVouchers)
        if (tallyKeepVoucher(firm: v.firm, base: v.base, simple: kSimple)) v,
    ];
    purchases = <TVoucher>[
      for (final TVoucher v in allVouchers)
        if (tallyIsPurchase(v.base)) v,
    ];
  }

  List<Map<String, dynamic>> _rowsOf(Object? v) {
    final List<Map<String, dynamic>> out = <Map<String, dynamic>>[];
    if (v is List) {
      for (final Object? e in v) {
        if (e is Map) out.add(Map<String, dynamic>.from(e));
      }
    }
    return out;
  }

  String get _cacheKey => '${live.uid}_tally';

  /// The copy saved on this device at the last successful load.
  Future<void> _loadCache() async {
    if (live.uid.isEmpty) return;
    try {
      final Object? j = await OfflineStore.read(_cacheKey);
      if (j is! Map) return;
      _apply(_rowsOf(j['v']), _rowsOf(j['l']));
      cacheAt = DateTime.tryParse(_s(j['at']))?.toLocal();
      loadedAt = cacheAt;
      fromCache = true;
    } catch (_) {}
  }

  Future<void> load({bool force = false}) async {
    if (loading) return;
    final DateTime? at = loadedAt;
    if (!force && at != null && !fromCache && DateTime.now().difference(at).inMinutes < 3) return;
    loading = true;
    error = '';
    notifyListeners();
    if (vouchers.isEmpty && ledgers.isEmpty) {
      // show the saved copy at once; the fresh data replaces it when it arrives
      await _loadCache();
      notifyListeners();
    }
    try {
      final List<Map<String, dynamic>> vr = await live.supa.selectAll(
        'tally_vouchers',
        <String, String>{'select': '*', 'v_date': 'gte.${fyStart()}', 'order': 'v_date.desc,id.desc'},
        maxRows: 30000,
      );
      final List<Map<String, dynamic>> lr = await live.supa.selectAll(
        'tally_ledgers',
        <String, String>{'select': '*', 'order': 'name.asc'},
        maxRows: 20000,
      );
      _apply(vr, lr);
      fromCache = false;
      loadedAt = DateTime.now();
      if (live.uid.isNotEmpty) {
        unawaited(OfflineStore.write(_cacheKey, <String, dynamic>{'at': DateTime.now().toUtc().toIso8601String(), 'v': vr, 'l': lr}));
      }
    } catch (e) {
      final bool net = e is SupaError && e.network;
      if (!(net && fromCache && (vouchers.isNotEmpty || ledgers.isNotEmpty))) error = _msg(e);
    }
    loading = false;
    notifyListeners();
  }
}

final TallyStore tallyStore = TallyStore();

// ------------------------------------------------------------ voucher kinds
class _BT {
  final String gu;
  final String en;
  final String tone;
  final String icon;
  const _BT(this.gu, this.en, this.tone, this.icon);
  String get label => bi(gu, en);
}

_BT _bt(String base) {
  switch (base) {
    case 'purchase':
      return const _BT('ખરીદી', 'Purchase', 'amber', 'bag');
    case 'sales':
      return const _BT('વેચાણ', 'Sales', 'green', 'cart');
    case 'payment':
      return const _BT('ચૂકવણી', 'Payment', 'rose', 'pay');
    case 'receipt':
      return const _BT('રકમ મળી', 'Receipt', 'blue', 'dl');
    case 'contra':
      return const _BT('કોન્ટ્રા', 'Contra', 'slate', 'swap');
    case 'journal':
      return const _BT('જર્નલ', 'Journal', 'violet', 'book');
    case 'creditnote':
      return const _BT('ક્રેડિટ નોટ', 'Credit note', 'orange', 'doc');
    case 'debitnote':
      return const _BT('ડેબિટ નોટ', 'Debit note', 'orange', 'doc');
  }
  return const _BT('અન્ય', 'Other', 'slate', 'doc');
}

const List<String> _baseOrder = <String>['purchase', 'sales', 'payment', 'receipt', 'contra', 'journal', 'creditnote', 'debitnote', 'other'];

String _modeLabel(String m) {
  switch (m) {
    case 'cash':
      return bi('રોકડ', 'Cash');
    case 'upi':
      return 'UPI';
    case 'bank':
      return bi('બેંક', 'Bank');
    case 'cheque':
      return bi('ચેક', 'Cheque');
  }
  return '';
}

String _drcr(double closing) {
  final double a = closing.abs();
  if (a < 0.5) return '₹0';
  return '${_rs(a)} ${closing < 0 ? 'Dr' : 'Cr'}';
}

String _vText(TVoucher v) {
  final StringBuffer b = StringBuffer();
  b.writeln('📒 ${v.type} ${v.no.isEmpty ? '' : '#${v.no}'}'.trim());
  b.writeln('${dmy(v.dt)} • ${firmName(v.firm)}');
  if (v.party.isNotEmpty) b.writeln('${bi('પાર્ટી', 'Party')}: ${v.party}');
  b.writeln('${bi('રકમ', 'Amount')}: ${_rs(v.amount)}');
  if (v.bank.isNotEmpty) b.writeln('${bi('બેંક / રોકડ', 'Bank / cash')}: ${v.bank}');
  if (v.utr.isNotEmpty) b.writeln('UTR: ${v.utr}');
  if (v.narr.isNotEmpty) b.writeln(v.narr);
  return b.toString().trimRight();
}

// ----------------------------------------------------------- voucher tile
Widget _vTile(BuildContext context, TVoucher v, {bool showFirm = true}) {
  final _BT t = _bt(v.base);
  final String mode = _modeLabel(v.mode);
  final List<String> sub = <String>[
    v.type,
    if (v.no.isNotEmpty) '#${v.no}',
    if (showFirm) _firmShort(v.firm),
    if (v.cancelled) bi('રદ', 'Cancelled'),
    if (v.optional) bi('ઓપ્શનલ', 'Optional'),
  ];
  return lineItem(
    icon: t.icon,
    tone: v.cancelled ? 'slate' : t.tone,
    title: v.title,
    sub: '${sub.join(' · ')}${v.narr.isEmpty ? '' : '\n${v.narr}'}',
    trailing: _rs(v.amount),
    trailingSub: mode.isEmpty ? null : mode,
    trailingColor: v.cancelled ? Pal.faint : null,
    onTap: () => openTallyVoucher(context, v),
  );
}

Future<void> openTallyVoucher(BuildContext context, TVoucher v) {
  return openPanel(
    context,
    title: '${v.type}${v.no.isEmpty ? '' : ' · ${v.no}'}',
    sub: '${dmy(v.dt)} · ${firmName(v.firm)}',
    width: 480,
    child: _VoucherPanel(v),
  );
}

class _VoucherPanel extends StatelessWidget {
  final TVoucher v;
  const _VoucherPanel(this.v);

  @override
  Widget build(BuildContext context) {
    final _BT t = _bt(v.base);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Surface(
          color: Pal.side,
          border: false,
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(t.label, style: ts(13, c: Pal.sideText, w: FontWeight.w600)),
              FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(_rs(v.amount), style: ts(34, w: FontWeight.w800, c: Colors.white, tab: true, ls: -1))),
              if (v.title.isNotEmpty) Text(v.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(14, c: Pal.sideText, w: FontWeight.w600)),
            ],
          ),
        ),
        const SizedBox(height: 10),
        Wrap(
          spacing: 6,
          runSpacing: 6,
          children: <Widget>[
            Pill(t.label, tone: t.tone, small: true),
            if (v.cancelled) Pill(bi('રદ', 'Cancelled'), tone: 'rose', icon: 'warn', small: true),
            if (v.optional) Pill(bi('ઓપ્શનલ', 'Optional'), tone: 'slate', small: true),
            if (_modeLabel(v.mode).isNotEmpty) Pill(_modeLabel(v.mode), tone: 'blue', small: true),
          ],
        ),
        const SizedBox(height: 12),
        Panel(
          child: Column(
            children: <Widget>[
              InfoRow(bi('તારીખ', 'Date'), dmy(v.dt)),
              InfoRow(bi('ફર્મ', 'Firm'), firmName(v.firm)),
              InfoRow(bi('પ્રકાર', 'Type'), v.type),
              if (v.no.isNotEmpty) InfoRow(bi('નંબર', 'Number'), v.no),
              if (v.party.isNotEmpty) InfoRow(bi('પાર્ટી', 'Party'), v.party),
              if (v.bank.isNotEmpty) InfoRow(bi('બેંક / રોકડ', 'Bank / cash'), v.bank),
              if (v.utr.isNotEmpty) InfoRow('UTR', v.utr),
            ],
          ),
        ),
        if (v.narr.isNotEmpty) ...<Widget>[
          const SizedBox(height: 10),
          noteBox('note', 'slate', v.narr),
        ],
        if (v.lines.isNotEmpty) ...<Widget>[
          const SizedBox(height: 6),
          caption(bi('પાર્ટીની બાજુ', 'Party side')),
          Panel(child: Column(children: <Widget>[for (final TLine l in v.lines) InfoRow(l.ledger.isEmpty ? '—' : l.ledger, _rs(l.amount))])),
        ],
        if (v.other.isNotEmpty) ...<Widget>[
          const SizedBox(height: 10),
          caption(bi('સામેની બાજુ', 'Other side')),
          Panel(child: Column(children: <Widget>[for (final TLine l in v.other) InfoRow(l.ledger.isEmpty ? '—' : l.ledger, _rs(l.amount))])),
        ],
        if (v.items.isNotEmpty) ...<Widget>[
          const SizedBox(height: 10),
          caption(bi('માલ', 'Items')),
          Panel(
            child: Column(
              children: <Widget>[
                for (final TItem i in v.items)
                  InfoRow(
                    i.name,
                    '${i.qty > 0 ? '${grp(i.qty, dec: i.qty == i.qty.roundToDouble() ? 0 : 2)} ${i.unit}' : ''}${i.rate > 0 ? ' × ${_rs(i.rate)}' : ''} = ${_rs(i.amount)}',
                  ),
              ],
            ),
          ),
        ],
        const SizedBox(height: 14),
        Row(
          children: <Widget>[
            tExp(child: Btn(bi('કૉપિ', 'Copy'), icon: 'copy', kind: BtnKind.tonal, dense: true, onTap: () => copyText(_vText(v)))),
            const SizedBox(width: 8),
            tExp(child: Btn('WhatsApp', icon: 'chat', kind: BtnKind.tonal, dense: true, onTap: () => whatsappText(_vText(v)))),
          ],
        ),
        if (v.party.isNotEmpty) ...<Widget>[
          const SizedBox(height: 8),
          Btn(bi('આ પાર્ટીનો હિસાબ', 'This party\'s account'), icon: 'users', kind: BtnKind.outline, dense: true, onTap: () => openTallyParty(context, v.party)),
        ],
      ],
    );
  }
}

// -------------------------------------------------------------- party panel
Future<void> openTallyParty(BuildContext context, String name) {
  return openPanel(
    context,
    title: name,
    sub: bi('Tally મુજબ હિસાબ (વાંચન)', 'Account as in Tally (read-only)'),
    width: 520,
    child: _PartyPanel(name),
  );
}

class _PartyPanel extends StatelessWidget {
  final String name;
  const _PartyPanel(this.name);

  @override
  Widget build(BuildContext context) {
    final String k = _nk(name);
    final List<TLedger> leds = tallyStore.ledgers.where((TLedger l) => _nk(l.name) == k).toList();
    final List<TVoucher> vs = tallyStore.vouchers.where((TVoucher v) {
      if (_nk(v.party) == k) return true;
      for (final TLine l in v.lines) {
        if (_nk(l.ledger) == k) return true;
      }
      return false;
    }).toList();
    final Map<String, double> sum = <String, double>{};
    for (final TVoucher v in vs) {
      if (v.cancelled) continue;
      sum[v.base] = (sum[v.base] ?? 0) + v.amount;
    }
    double total = 0;
    for (final TLedger l in leds) {
      total += l.closing;
    }
    final String kind = leds.isEmpty ? 'other' : leds.first.kind;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Surface(
          color: Pal.side,
          border: false,
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(leds.isEmpty ? bi('ખાતું મળ્યું નથી', 'Ledger not found') : bi('ચાલુ બાકી', 'Closing balance'), style: ts(13, c: Pal.sideText, w: FontWeight.w600)),
              FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(leds.isEmpty ? '—' : _drcr(total), style: ts(34, w: FontWeight.w800, c: Colors.white, tab: true, ls: -1))),
              if (leds.isNotEmpty)
                Text(
                  kind == 'debtor'
                      ? (total < 0 ? bi('આ પાર્ટી પાસેથી લેવાના', 'To receive from this party') : bi('આ પાર્ટીને આપવાના', 'To pay this party'))
                      : (kind == 'creditor' ? (total > 0 ? bi('આ પાર્ટીને ચૂકવવાના', 'To pay this party') : bi('આ પાર્ટી પાસેથી લેવાના', 'To receive from this party')) : (leds.first.parent)),
                  style: ts(13, c: Pal.sideText, w: FontWeight.w600),
                ),
            ],
          ),
        ),
        if (leds.length > 1) ...<Widget>[
          const SizedBox(height: 10),
          Panel(child: Column(children: <Widget>[for (final TLedger l in leds) InfoRow(firmName(l.firm), _drcr(l.closing))])),
        ],
        const SizedBox(height: 10),
        Panel(
          title: bi('આ વર્ષ (1 એપ્રિલથી)', 'This year (from 1 April)'),
          child: Column(
            children: <Widget>[
              for (final String b in _baseOrder)
                if ((sum[b] ?? 0) > 0) InfoRow(_bt(b).label, _rs(sum[b] ?? 0)),
              if (sum.isEmpty) Text(bi('આ વર્ષનો કોઈ વાઉચર નથી', 'No vouchers this year'), style: ts(13.5, c: Pal.muted)),
            ],
          ),
        ),
        const SizedBox(height: 10),
        caption('${bi('વાઉચર', 'Vouchers')} (${vs.length})'),
        for (final TVoucher v in vs.take(60)) _vTile(context, v),
        if (vs.length > 60) Text(bi('છેલ્લા 60 બતાવ્યા', 'Showing the latest 60'), textAlign: TextAlign.center, style: ts(12.5, c: Pal.muted)),
        if (leds.isNotEmpty || vs.isNotEmpty) ...<Widget>[
          const SizedBox(height: 10),
          Btn(
            bi('WhatsApp પર મોકલો', 'Send on WhatsApp'),
            icon: 'chat',
            kind: BtnKind.tonal,
            dense: true,
            onTap: () => whatsappText(_partyText(name, leds, total, sum)),
          ),
        ],
      ],
    );
  }

  String _partyText(String n, List<TLedger> leds, double total, Map<String, double> sum) {
    final StringBuffer b = StringBuffer();
    b.writeln('📒 $n');
    if (leds.isNotEmpty) b.writeln('${bi('ચાલુ બાકી', 'Balance')}: ${_drcr(total)}');
    for (final String k in _baseOrder) {
      final double v = sum[k] ?? 0;
      if (v > 0) b.writeln('${_bt(k).label}: ${_rs(v)}');
    }
    return b.toString().trimRight();
  }
}

// ----------------------------------------------------------------- screen
class TallyDataScreen extends StatefulWidget {
  /// which tab opens first: 0 Day Book, 1 Ledgers, 2 Cash book, 3 Stock, 4 Summary,
  /// 5 Bank book, 6 Ageing, 7 Purchase check, 8 Payments to khata, 9 GST, 10 Checks
  final int tab;
  const TallyDataScreen({super.key, this.tab = 0});

  @override
  State<TallyDataScreen> createState() => _TallyDataState();
}

class _Led {
  final String name;
  final String parent;
  final String kind;
  double closing = 0;
  final Set<String> firms = <String>{};
  _Led(this.name, this.parent, this.kind);
}

class _CashItem {
  final TVoucher v;
  final bool inn;
  final String who;
  const _CashItem(this.v, this.inn, this.who);
}

class _CashDay {
  final String date;
  double inn = 0;
  double out = 0;
  final List<_CashItem> items = <_CashItem>[];
  _CashDay(this.date);
}

class _Cash {
  final List<_CashDay> days;
  final double inn;
  final double out;
  const _Cash(this.days, this.inn, this.out);
}

class _TallyDataState extends State<TallyDataScreen> {
  int _tab = 0;
  String _firm = '';
  int _per = 0;
  String _type = '';
  int _kind = 0;
  int _limit = 80;
  String _q = '';
  final TextEditingController _search = TextEditingController();
  String _asig = '';
  List<_Alert> _acache = <_Alert>[];
  bool _alertAll = false;

  @override
  void initState() {
    super.initState();
    _tab = widget.tab;
    tallyStore.load();
  }

  /// tabs that follow the month / year chips
  bool _usesPeriod(int t) => t == 0 || t == 2 || t == 4 || t == 5 || t == 7 || t == 9 || t == 10;

  List<_Alert> _alerts() {
    final String sig = '${tallyStore.loadedAt?.millisecondsSinceEpoch ?? 0}|${live.chits.length}|${payDoc.list('items').length}|${_aliasMap().length}|${_ignoreSet().length}|$_firm|${_today()}';
    if (sig != _asig) {
      try {
        _acache = _buildAlerts(_firm);
      } catch (_) {
        _acache = <_Alert>[];
      }
      _asig = sig;
    }
    return _acache;
  }

  void _goTab(int t) {
    setState(() {
      _tab = t;
      _limit = 80;
      _q = '';
      _search.clear();
    });
  }

  Widget _alertCard() {
    final List<_Alert> al = _alerts();
    if (al.isEmpty) return const SizedBox.shrink();
    final List<_Alert> shown = _alertAll ? al : al.take(3).toList();
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Panel(
        title: bi('ધ્યાનમાં લો', 'Needs your eye'),
        sub: bi('Tally અને Pro ને સાથે જોઈને', 'From Tally and Pro together'),
        child: Column(
          children: <Widget>[
            for (final _Alert a in shown)
              lineItem(
                icon: a.icon,
                tone: a.tone,
                title: a.text,
                sub: a.sub,
                onTap: a.tab >= 0 ? () => _goTab(a.tab) : null,
              ),
            if (al.length > 3)
              Btn(
                _alertAll ? bi('ઓછું બતાવો', 'Show less') : bi('બધા બતાવો (${al.length})', 'Show all (${al.length})'),
                kind: BtnKind.ghost,
                dense: true,
                onTap: () => setState(() => _alertAll = !_alertAll),
              ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  // ---- filters
  (String, String) _range() {
    final DateTime n = DateTime.now();
    if (_per == 0) return ('${n.year}-${pad2(n.month)}-01', _dk(n));
    if (_per == 1) {
      final DateTime first = DateTime(n.year, n.month - 1, 1);
      final DateTime last = DateTime(n.year, n.month, 0);
      return (_dk(first), _dk(last));
    }
    return ('', '');
  }

  List<TVoucher> _scope() {
    final (String, String) r = _range();
    final List<TVoucher> out = <TVoucher>[];
    for (final TVoucher v in tallyStore.vouchers) {
      if (_firm.isNotEmpty && v.firm != _firm) continue;
      if (r.$1.isNotEmpty && v.date.compareTo(r.$1) < 0) continue;
      if (r.$2.isNotEmpty && v.date.compareTo(r.$2) > 0) continue;
      out.add(v);
    }
    return out;
  }

  // ---- header
  Widget _syncCard() {
    final DateTime? at = tallyStore.lastSync;
    final bool stale = at != null && DateTime.now().difference(at).inHours >= 6;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Row(
          children: <Widget>[
            Expanded(
              child: Text(
                at == null
                    ? bi('Tally સિંક નથી થયું', 'Not synced from Tally yet')
                    : '${bi('છેલ્લો સિંક', 'Last sync')}: ${ago(at)} · ${tallyStore.vouchers.length} ${bi('વાઉચર', 'vouchers')}',
                style: ts(12.5, c: Pal.muted, w: FontWeight.w600),
              ),
            ),
            if (tallyStore.loading)
              const SizedBox(width: 40, height: 40, child: Padding(padding: EdgeInsets.all(10), child: CircularProgressIndicator(strokeWidth: 2.4)))
            else
              IconBtn('refresh', onTap: () => tallyStore.load(force: true), tip: bi('તાજું કરો', 'Refresh')),
          ],
        ),
        if (tallyStore.fromCache)
          noteBox(
            'wifioff',
            'amber',
            '${bi('ઇન્ટરનેટ નથી - આ ફોન / PC પર સેવ કરેલી કૉપી દેખાય છે', 'No internet - showing the copy saved on this device')}${tallyStore.cacheAt == null ? '' : ' (${ago(tallyStore.cacheAt!)})'}',
          ),
        if (stale && !tallyStore.fromCache) noteBox('warn', 'amber', bi('Tally સિંક 6 કલાકથી બંધ છે - Tally વાળા PC પર Agent ચાલુ છે?', 'Tally sync stopped over 6 hours ago - is the Agent running on the Tally PC?')),
      ],
    );
  }

  Widget _filters() {
    final List<String> firms = tallyStore.firms;
    final List<String> fl = <String>[bi('બધી ફર્મ', 'All firms'), for (final String f in firms) _firmShort(f)];
    final int fi = _firm.isEmpty ? 0 : (firms.indexOf(_firm) + 1);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        if (firms.length > 1) ...<Widget>[
          ChipRow(
            labels: fl,
            index: fi < 0 ? 0 : fi,
            onChanged: (int i) => setState(() {
              _firm = i == 0 ? '' : firms[i - 1];
              _limit = 80;
            }),
          ),
          const SizedBox(height: 8),
        ],
        if (_usesPeriod(_tab))
          ChipRow(
            labels: <String>[bi('આ મહિનો', 'This month'), bi('ગયો મહિનો', 'Last month'), bi('આ વર્ષ', 'This year')],
            index: _per,
            onChanged: (int i) => setState(() {
              _per = i;
              _limit = 80;
            }),
          ),
      ],
    );
  }

  // ---- tab 0: day book
  List<Widget> _dayBook(BuildContext context) {
    final List<TVoucher> all = _scope();
    final Set<String> present = <String>{for (final TVoucher v in all) v.base};
    final List<String> types = <String>[for (final String b in _baseOrder) if (present.contains(b)) b];
    final List<String> tl = <String>[bi('બધા', 'All'), for (final String b in types) _bt(b).label];
    final int ti = _type.isEmpty ? 0 : (types.indexOf(_type) + 1);
    final String q = _q.toLowerCase();
    final List<TVoucher> list = <TVoucher>[];
    for (final TVoucher v in all) {
      if (_type.isNotEmpty && v.base != _type) continue;
      if (q.isNotEmpty) {
        final String hay = '${v.party} ${v.no} ${v.narr} ${v.utr} ${v.bank} ${v.type}'.toLowerCase();
        if (!hay.contains(q)) continue;
      }
      list.add(v);
    }
    double tot = 0;
    for (final TVoucher v in list) {
      if (!v.cancelled) tot += v.amount;
    }
    final List<Widget> out = <Widget>[
      FieldX(
        label: bi('શોધો', 'Search'),
        controller: _search,
        hint: bi('પાર્ટી, નંબર, નોંધ, UTR', 'Party, number, note, UTR'),
        onChanged: (String s) => setState(() {
          _q = s.trim();
          _limit = 80;
        }),
      ),
      const SizedBox(height: 10),
      if (types.length > 1)
        ChipRow(
          labels: tl,
          index: ti < 0 ? 0 : ti,
          onChanged: (int i) => setState(() {
            _type = i == 0 ? '' : types[i - 1];
            _limit = 80;
          }),
        ),
      const SizedBox(height: 10),
      Text('${list.length} ${bi('વાઉચર', 'vouchers')} · ${_rs(tot)}', style: ts(12.5, c: Pal.muted, w: FontWeight.w700)),
      const SizedBox(height: 8),
      if (list.isNotEmpty)
        Align(
          alignment: Alignment.centerLeft,
          child: Btn(
            bi('આ યાદી CSV કૉપિ કરો', 'Copy this list as CSV'),
            icon: 'copy',
            kind: BtnKind.ghost,
            dense: true,
            onTap: () => copyText(
              csvOf(
                <String>['Date', 'Firm', 'Type', 'No', 'Party', 'Amount', 'Mode', 'Bank', 'UTR', 'Narration', 'Cancelled'],
                <List<Object?>>[
                  for (final TVoucher v in list) <Object?>[v.date, v.firm, v.type, v.no, v.party, v.amount, v.mode, v.bank, v.utr, v.narr, v.cancelled ? 'yes' : ''],
                ],
              ),
              msg: bi('CSV કૉપિ થયું (Excel માં paste કરો)', 'CSV copied (paste into Excel)'),
            ),
          ),
        ),
      const SizedBox(height: 4),
    ];
    if (list.isEmpty) {
      out.add(Padding(padding: const EdgeInsets.symmetric(vertical: 24), child: Text(bi('આ ફિલ્ટરમાં કોઈ વાઉચર નથી', 'No vouchers for this filter'), textAlign: TextAlign.center, style: ts(14, c: Pal.muted))));
      return out;
    }
    String day = '';
    final bool dense = app.stagePc; // PC: slim Tally-style table rows
    if (dense) out.add(_tHead(_firm.isEmpty));
    for (final TVoucher v in list.take(_limit)) {
      if (v.date != day) {
        day = v.date;
        out.add(dense ? _tDay('${dayName(v.dt)} · ${dmy(v.dt)}') : caption('${dayName(v.dt)} · ${dmy(v.dt)}'));
      }
      out.add(dense ? _tRow(context, v, _firm.isEmpty) : _vTile(context, v, showFirm: _firm.isEmpty));
    }
    if (dense) {
      out.add(_tblRow(
        _dayCols(_firm.isEmpty),
        <Widget>[
          _td(''),
          _td('${bi('કુલ', 'Total')} · ${list.length} ${bi('વાઉચર', 'vouchers')}', bold: true),
          _td(''),
          _td(''),
          if (_firm.isEmpty) _td(''),
          _td(_rs(tot), bold: true, num: true),
        ],
        bg: Pal.soft,
        h: 32,
      ));
    }
    if (list.length > _limit) {
      out.add(const SizedBox(height: 6));
      out.add(Btn(bi('વધુ બતાવો (${list.length - _limit})', 'Show more (${list.length - _limit})'), icon: 'plus', kind: BtnKind.outline, dense: true, onTap: () => setState(() => _limit += 120)));
    }
    return out;
  }

  // ---- tab 1: ledgers
  List<Widget> _ledgerTab(BuildContext context) {
    final Map<String, _Led> m = <String, _Led>{};
    for (final TLedger l in tallyStore.ledgers) {
      if (_firm.isNotEmpty && l.firm != _firm) continue;
      final String k = _nk(l.name);
      if (k.isEmpty) continue;
      final _Led a = m.putIfAbsent(k, () => _Led(l.name, l.parent, l.kind));
      a.closing += l.closing;
      a.firms.add(l.firm);
    }
    final List<_Led> all = m.values.toList();
    double debt = 0;
    double cred = 0;
    double money = 0;
    for (final _Led l in all) {
      if (l.kind == 'debtor') debt += -l.closing;
      if (l.kind == 'creditor') cred += l.closing;
      if (l.kind == 'bank' || l.kind == 'cash') money += -l.closing;
    }
    final String q = _q.toLowerCase();
    final List<_Led> list = <_Led>[];
    for (final _Led l in all) {
      if (q.isNotEmpty) {
        if (!l.name.toLowerCase().contains(q)) continue;
      } else if (l.closing.abs() < 0.5) {
        continue;
      }
      final String k = l.kind;
      if (_kind == 1 && k != 'debtor') continue;
      if (_kind == 2 && k != 'creditor') continue;
      if (_kind == 3 && k != 'bank' && k != 'cash') continue;
      if (_kind == 4 && k != 'expense') continue;
      if (_kind == 5 && (k == 'debtor' || k == 'creditor' || k == 'bank' || k == 'cash' || k == 'expense')) continue;
      list.add(l);
    }
    list.sort((_Led a, _Led b) => b.closing.abs().compareTo(a.closing.abs()));
    final List<Widget> out = <Widget>[
      metricGrid(context, <Widget>[
        MetricTile(label: bi('લેણા (લેવાના)', 'To receive'), value: inrC(debt), icon: 'users', tone: 'green', sub: bi('Sundry Debtors', 'Sundry Debtors')),
        MetricTile(label: bi('દેવા (ચૂકવવાના)', 'To pay'), value: inrC(cred), icon: 'users', tone: 'rose', sub: bi('Sundry Creditors', 'Sundry Creditors')),
        MetricTile(label: bi('રોકડ + બેંક', 'Cash + bank'), value: inrC(money), icon: 'bank', tone: 'blue', sub: bi('Tally મુજબ', 'as in Tally')),
      ], pcCols: 3),
      const SizedBox(height: 12),
      FieldX(
        label: bi('ખાતું શોધો', 'Find a ledger'),
        controller: _search,
        hint: bi('નામ લખો', 'Type a name'),
        onChanged: (String s) => setState(() {
          _q = s.trim();
          _limit = 80;
        }),
      ),
      const SizedBox(height: 10),
      ChipRow(
        labels: <String>[bi('બધા', 'All'), bi('લેણા', 'Debtors'), bi('દેવા', 'Creditors'), bi('રોકડ / બેંક', 'Cash / bank'), bi('ખર્ચ', 'Expense'), bi('અન્ય', 'Other')],
        index: _kind,
        onChanged: (int i) => setState(() {
          _kind = i;
          _limit = 80;
        }),
      ),
      const SizedBox(height: 10),
    ];
    if (list.isEmpty) {
      out.add(Padding(padding: const EdgeInsets.symmetric(vertical: 24), child: Text(bi('કોઈ ખાતું નથી', 'No ledgers'), textAlign: TextAlign.center, style: ts(14, c: Pal.muted))));
      return out;
    }
    out.add(Align(
      alignment: Alignment.centerLeft,
      child: Btn(
        bi('આ યાદી CSV કૉપિ કરો', 'Copy this list as CSV'),
        icon: 'copy',
        kind: BtnKind.ghost,
        dense: true,
        onTap: () => copyText(
          csvOf(
            <String>['Ledger', 'Under', 'Firm', 'Debit', 'Credit'],
            <List<Object?>>[
              for (final _Led l in list) <Object?>[l.name, l.parent, l.firms.join('/'), l.closing < 0 ? -l.closing : '', l.closing > 0 ? l.closing : ''],
            ],
          ),
          msg: bi('CSV કૉપિ થયું (Excel માં paste કરો)', 'CSV copied (paste into Excel)'),
        ),
      ),
    ));
    if (app.stagePc) {
      final List<_Col> cols = <_Col>[
        _Col(bi('ખાતું (Particulars)', 'Particulars'), 0),
        _Col(bi('ગ્રુપ', 'Under'), 190),
        if (_firm.isEmpty) _Col(bi('ફર્મ', 'Firm'), 80),
        _Col(bi('ડેબિટ (Dr)', 'Debit (Dr)'), 120, right: true),
        _Col(bi('ક્રેડિટ (Cr)', 'Credit (Cr)'), 120, right: true),
      ];
      double sd = 0;
      double sc = 0;
      for (final _Led l in list) {
        if (l.closing < 0) {
          sd += -l.closing;
        } else {
          sc += l.closing;
        }
      }
      out.add(_tblHead(cols));
      for (final _Led l in list.take(_limit)) {
        final bool dr = l.closing < 0;
        out.add(_tblRow(
          cols,
          <Widget>[
            _td(l.name, bold: true),
            _td(l.parent.isEmpty ? '—' : l.parent, c: Pal.muted),
            if (_firm.isEmpty) _td(l.firms.length == 1 ? _firmShort(l.firms.first) : '${l.firms.length}', c: Pal.muted),
            _td(dr ? _rs(-l.closing) : '', num: true),
            _td(dr ? '' : _rs(l.closing), num: true),
          ],
          onTap: () => openTallyParty(context, l.name),
        ));
      }
      out.add(_tblRow(
        cols,
        <Widget>[
          _td('${bi('કુલ', 'Total')} · ${list.length} ${bi('ખાતા', 'ledgers')}', bold: true),
          _td(''),
          if (_firm.isEmpty) _td(''),
          _td(_rs(sd), bold: true, num: true),
          _td(_rs(sc), bold: true, num: true),
        ],
        bg: Pal.soft,
        h: 32,
      ));
      if (list.length > _limit) {
        out.add(const SizedBox(height: 6));
        out.add(Btn(bi('વધુ બતાવો (${list.length - _limit})', 'Show more (${list.length - _limit})'), icon: 'plus', kind: BtnKind.outline, dense: true, onTap: () => setState(() => _limit += 200)));
      }
      return out;
    }
    for (final _Led l in list.take(_limit)) {
      final bool dr = l.closing < 0;
      final String k = l.kind;
      final String tone = k == 'debtor' ? 'green' : (k == 'creditor' ? 'rose' : (k == 'bank' || k == 'cash' ? 'blue' : 'slate'));
      out.add(lineItem(
        icon: k == 'bank' || k == 'cash' ? 'bank' : 'user',
        tone: tone,
        title: l.name,
        sub: '${l.parent.isEmpty ? '—' : l.parent}${_firm.isEmpty && l.firms.length == 1 ? ' · ${_firmShort(l.firms.first)}' : ''}',
        trailing: _rs(l.closing.abs()),
        trailingSub: dr ? 'Dr' : 'Cr',
        onTap: () => openTallyParty(context, l.name),
      ));
    }
    if (list.length > _limit) {
      out.add(const SizedBox(height: 6));
      out.add(Btn(bi('વધુ બતાવો (${list.length - _limit})', 'Show more (${list.length - _limit})'), icon: 'plus', kind: BtnKind.outline, dense: true, onTap: () => setState(() => _limit += 120)));
    }
    return out;
  }

  // ---- tab 2: cash book
  _Cash _cashBook(List<TVoucher> vs) {
    final Set<String> cash = <String>{};
    for (final TLedger l in tallyStore.ledgers) {
      if (l.kind == 'cash') cash.add(_nk(l.name));
    }
    bool isCash(String n) {
      final String k = _nk(n);
      return k.isNotEmpty && (cash.contains(k) || k.startsWith('cash') || k.contains('pettycash'));
    }

    final Map<String, _CashDay> days = <String, _CashDay>{};
    double tin = 0;
    double tout = 0;
    for (final TVoucher v in vs) {
      if (v.cancelled || !(v.amount > 0)) continue;
      bool? inn;
      String who = v.party;
      if (v.base == 'payment' && (v.mode == 'cash' || isCash(v.bank))) {
        inn = false;
      } else if (v.base == 'receipt' && (v.mode == 'cash' || isCash(v.bank))) {
        inn = true;
      } else if (v.base == 'sales' && isCash(v.party)) {
        inn = true;
      } else if (v.base == 'purchase' && isCash(v.party)) {
        inn = false;
      } else if (v.base == 'contra') {
        final bool lineCash = v.lines.any((TLine l) => isCash(l.ledger));
        if (isCash(v.bank) && !lineCash) {
          inn = false;
          who = v.lines.isNotEmpty ? v.lines.first.ledger : '';
        } else if (lineCash && !isCash(v.bank)) {
          inn = true;
          who = v.bank;
        }
      }
      if (inn == null) continue;
      final _CashDay d = days.putIfAbsent(v.date, () => _CashDay(v.date));
      if (inn) {
        d.inn += v.amount;
        tin += v.amount;
      } else {
        d.out += v.amount;
        tout += v.amount;
      }
      d.items.add(_CashItem(v, inn, who));
    }
    final List<_CashDay> list = days.values.toList();
    list.sort((_CashDay a, _CashDay b) => b.date.compareTo(a.date));
    return _Cash(list, tin, tout);
  }

  List<Widget> _cashTab(BuildContext context) {
    final _Cash c = _cashBook(_scope());
    double inHand = 0;
    bool haveHand = false;
    for (final TLedger l in tallyStore.ledgers) {
      if (l.kind != 'cash') continue;
      if (_firm.isNotEmpty && l.firm != _firm) continue;
      inHand += -l.closing;
      haveHand = true;
    }
    final List<Widget> out = <Widget>[
      metricGrid(context, <Widget>[
        MetricTile(label: bi('રોકડ આવક', 'Cash in'), value: inrC(c.inn), icon: 'arrowdown', tone: 'green'),
        MetricTile(label: bi('રોકડ જાવક', 'Cash out'), value: inrC(c.out), icon: 'arrowup', tone: 'rose'),
        MetricTile(label: bi('ફરક', 'Net'), value: inrC(c.inn - c.out), icon: 'swap', tone: 'blue', sub: haveHand ? '${bi('Tally માં રોકડ', 'Cash in Tally')}: ${inrC(inHand)}' : null),
      ], pcCols: 3),
      const SizedBox(height: 12),
    ];
    if (c.days.isEmpty) {
      out.add(Padding(padding: const EdgeInsets.symmetric(vertical: 24), child: Text(bi('આ સમયમાં રોકડનો કોઈ વ્યવહાર નથી', 'No cash entries in this period'), textAlign: TextAlign.center, style: ts(14, c: Pal.muted))));
      return out;
    }
    int shown = 0;
    out.add(Align(
      alignment: Alignment.centerLeft,
      child: Btn(
        bi('રોજમેળ CSV કૉપિ કરો', 'Copy cash book as CSV'),
        icon: 'copy',
        kind: BtnKind.ghost,
        dense: true,
        onTap: () => copyText(
          csvOf(
            <String>['Date', 'Firm', 'Particulars', 'Type', 'No', 'Receipt', 'Payment'],
            <List<Object?>>[
              for (final _CashDay d in c.days)
                for (final _CashItem it in d.items) <Object?>[d.date, it.v.firm, it.who.isEmpty ? it.v.title : it.who, it.v.type, it.v.no, it.inn ? it.v.amount : '', it.inn ? '' : it.v.amount],
            ],
          ),
          msg: bi('CSV કૉપિ થયું (Excel માં paste કરો)', 'CSV copied (paste into Excel)'),
        ),
      ),
    ));
    if (app.stagePc) {
      final List<_Col> cols = <_Col>[
        _Col(bi('તારીખ', 'Date'), 56),
        _Col(bi('વિગત (Particulars)', 'Particulars'), 0),
        _Col(bi('વાઉચર પ્રકાર', 'Voucher type'), 110),
        _Col(bi('નંબર', 'No'), 60),
        if (_firm.isEmpty) _Col(bi('ફર્મ', 'Firm'), 80),
        _Col(bi('આવક (Dr)', 'Receipt (Dr)'), 110, right: true),
        _Col(bi('જાવક (Cr)', 'Payment (Cr)'), 110, right: true),
      ];
      out.add(_tblHead(cols));
      for (final _CashDay d in c.days) {
        if (shown >= _limit) break;
        final DateTime dt = DateTime.tryParse(d.date) ?? DateTime(2000);
        out.add(_tDay('${dayName(dt)} · ${dmy(dt)}', a: _rs(d.inn), b: _rs(d.out)));
        for (final _CashItem it in d.items) {
          final _BT t = _bt(it.v.base);
          out.add(_tblRow(
            cols,
            <Widget>[
              _td('${pad2(it.v.dt.day)}-${pad2(it.v.dt.month)}', c: Pal.muted, num: true),
              _td(it.who.isEmpty ? it.v.title : it.who, bold: true),
              _td(t.label, c: Pal.tone(t.tone).fg),
              _td(it.v.no.isEmpty ? '' : '#${it.v.no}', c: Pal.muted),
              if (_firm.isEmpty) _td(_firmShort(it.v.firm), c: Pal.muted),
              _td(it.inn ? _rs(it.v.amount) : '', num: true),
              _td(it.inn ? '' : _rs(it.v.amount), num: true),
            ],
            onTap: () => openTallyVoucher(context, it.v),
          ));
          shown++;
        }
      }
      out.add(_tblRow(
        cols,
        <Widget>[
          _td(''),
          _td('${bi('કુલ', 'Total')} · ${bi('ફરક', 'Net')} ${_rs(c.inn - c.out)}', bold: true),
          _td(''),
          _td(''),
          if (_firm.isEmpty) _td(''),
          _td(_rs(c.inn), bold: true, num: true),
          _td(_rs(c.out), bold: true, num: true),
        ],
        bg: Pal.soft,
        h: 32,
      ));
      if (shown < c.days.fold<int>(0, (int a, _CashDay d) => a + d.items.length)) {
        out.add(const SizedBox(height: 6));
        out.add(Btn(bi('વધુ બતાવો', 'Show more'), icon: 'plus', kind: BtnKind.outline, dense: true, onTap: () => setState(() => _limit += 200)));
      }
      out.add(const SizedBox(height: 6));
      out.add(Text(bi('રોકડ = Payment / Receipt જેમાં રોકડ ખાતું હોય, અને Contra', 'Cash = Payment / Receipt with a cash ledger, and Contra'), style: ts(12, c: Pal.faint)));
      return out;
    }
    for (final _CashDay d in c.days) {
      if (shown >= _limit) break;
      final DateTime dt = DateTime.tryParse(d.date) ?? DateTime(2000);
      out.add(caption('${dayName(dt)} · ${dmy(dt)}   ⬇ ${_rs(d.inn)}   ⬆ ${_rs(d.out)}'));
      for (final _CashItem it in d.items) {
        final _BT t = _bt(it.v.base);
        out.add(lineItem(
          icon: it.inn ? 'arrowdown' : 'arrowup',
          tone: it.inn ? 'green' : 'rose',
          title: it.who.isEmpty ? it.v.title : it.who,
          sub: '${t.label}${it.v.no.isEmpty ? '' : ' · #${it.v.no}'}${_firm.isEmpty ? ' · ${_firmShort(it.v.firm)}' : ''}${it.v.optional ? ' · ${bi('ઓપ્શનલ', 'Optional')}' : ''}',
          trailing: '${it.inn ? '+' : '−'} ${_rs(it.v.amount)}',
          trailingColor: it.inn ? Pal.ok : Pal.bad,
          onTap: () => openTallyVoucher(context, it.v),
        ));
        shown++;
      }
    }
    if (c.days.length > 1 && shown < c.days.fold<int>(0, (int a, _CashDay d) => a + d.items.length)) {
      out.add(const SizedBox(height: 6));
      out.add(Btn(bi('વધુ બતાવો', 'Show more'), icon: 'plus', kind: BtnKind.outline, dense: true, onTap: () => setState(() => _limit += 120)));
    }
    out.add(const SizedBox(height: 6));
    out.add(Text(bi('રોકડ = Payment / Receipt જેમાં રોકડ ખાતું હોય, અને Contra', 'Cash = Payment / Receipt with a cash ledger, and Contra'), style: ts(12, c: Pal.faint)));
    return out;
  }

  // ---- tab 3: stock
  List<Widget> _stockTab(BuildContext context) {
    final List<TStock> list = <TStock>[];
    double value = 0;
    final String q = _q.toLowerCase();
    for (final TStock s in tallyStore.stock) {
      if (_firm.isNotEmpty && s.firm != _firm) continue;
      if (q.isNotEmpty && !s.name.toLowerCase().contains(q)) continue;
      list.add(s);
      value += s.value;
    }
    list.sort((TStock a, TStock b) => b.value.compareTo(a.value));
    final List<Widget> out = <Widget>[
      metricGrid(context, <Widget>[
        MetricTile(label: bi('સ્ટોક આઇટમ', 'Stock items'), value: '${list.length}', icon: 'grain', tone: 'amber'),
        MetricTile(label: bi('સ્ટોકની કિંમત', 'Stock value'), value: inrC(value), icon: 'rupee', tone: 'green', sub: bi('Tally મુજબ', 'as in Tally')),
      ], pcCols: 2),
      const SizedBox(height: 12),
      FieldX(
        label: bi('આઇટમ શોધો', 'Find an item'),
        controller: _search,
        hint: bi('નામ લખો', 'Type a name'),
        onChanged: (String s) => setState(() => _q = s.trim()),
      ),
      const SizedBox(height: 10),
    ];
    if (list.isEmpty) {
      out.add(Padding(padding: const EdgeInsets.symmetric(vertical: 24), child: Text(bi('Tally નો સ્ટોક હજી આવ્યો નથી', 'No Tally stock yet'), textAlign: TextAlign.center, style: ts(14, c: Pal.muted))));
      return out;
    }
    if (app.stagePc) {
      final List<_Col> cols = <_Col>[
        _Col(bi('આઇટમ (Particulars)', 'Particulars'), 0),
        _Col(bi('ગ્રુપ', 'Under'), 170),
        _Col(bi('ફર્મ', 'Firm'), 80),
        _Col(bi('જથ્થો', 'Quantity'), 130, right: true),
        _Col(bi('કિંમત', 'Value'), 130, right: true),
      ];
      out.add(_tblHead(cols));
      for (final TStock s in list.take(400)) {
        out.add(_tblRow(
          cols,
          <Widget>[
            _td(s.name, bold: true),
            _td(s.group.isEmpty ? '—' : s.group, c: Pal.muted),
            _td(_firmShort(s.firm), c: Pal.muted),
            _td('${grp(s.qty, dec: s.qty == s.qty.roundToDouble() ? 0 : 2)} ${s.unit}'.trim(), num: true),
            _td(s.value > 0 ? _rs(s.value) : '', num: true),
          ],
        ));
      }
      out.add(_tblRow(
        cols,
        <Widget>[
          _td('${bi('કુલ', 'Total')} · ${list.length} ${bi('આઇટમ', 'items')}', bold: true),
          _td(''),
          _td(''),
          _td(''),
          _td(_rs(value), bold: true, num: true),
        ],
        bg: Pal.soft,
        h: 32,
      ));
      return out;
    }
    for (final TStock s in list.take(200)) {
      out.add(lineItem(
        icon: 'grain',
        tone: 'amber',
        title: s.name,
        sub: '${s.group.isEmpty ? '' : '${s.group} · '}${_firmShort(s.firm)}',
        trailing: '${grp(s.qty, dec: s.qty == s.qty.roundToDouble() ? 0 : 2)} ${s.unit}'.trim(),
        trailingSub: s.value > 0 ? _rs(s.value) : null,
      ));
    }
    return out;
  }

  // ---- tab 4: summary
  List<Widget> _summaryTab(BuildContext context) {
    final List<TVoucher> vs = _scope();
    final Map<String, double> sum = <String, double>{};
    final Map<String, int> cnt = <String, int>{};
    final Map<String, Map<String, double>> perFirm = <String, Map<String, double>>{};
    final Map<String, double> buyers = <String, double>{};
    final Map<String, double> suppliers = <String, double>{};
    for (final TVoucher v in vs) {
      if (v.cancelled) continue;
      sum[v.base] = (sum[v.base] ?? 0) + v.amount;
      cnt[v.base] = (cnt[v.base] ?? 0) + 1;
      final Map<String, double> f = perFirm.putIfAbsent(v.firm, () => <String, double>{});
      f[v.base] = (f[v.base] ?? 0) + v.amount;
      if (v.party.isEmpty) continue;
      if (v.base == 'sales') buyers[v.party] = (buyers[v.party] ?? 0) + v.amount;
      if (v.base == 'purchase') suppliers[v.party] = (suppliers[v.party] ?? 0) + v.amount;
    }
    List<MapEntry<String, double>> top(Map<String, double> m) {
      final List<MapEntry<String, double>> l = m.entries.toList();
      l.sort((MapEntry<String, double> a, MapEntry<String, double> b) => b.value.compareTo(a.value));
      return l.take(6).toList();
    }

    Widget tile(String b, String icon) => MetricTile(label: _bt(b).label, value: inrC(sum[b] ?? 0), icon: icon, tone: _bt(b).tone, sub: '${cnt[b] ?? 0} ${bi('વાઉચર', 'vouchers')}');
    final (String, String) rg = _range();
    final StringBuffer wa = StringBuffer();
    wa.writeln('*Tally ${bi('સારાંશ', 'summary')}* · ${_firm.isEmpty ? bi('બધી ફર્મ', 'All firms') : firmName(_firm)}');
    wa.writeln('${rg.$1} → ${rg.$2}');
    for (final String b in <String>['purchase', 'sales', 'payment', 'receipt']) {
      wa.writeln('${_bt(b).label}: ${_rs(sum[b] ?? 0)} (${cnt[b] ?? 0})');
    }
    final List<Widget> out = <Widget>[
      metricGrid(context, <Widget>[tile('purchase', 'bag'), tile('sales', 'cart'), tile('payment', 'pay'), tile('receipt', 'dl')]),
      const SizedBox(height: 8),
      if (vs.isNotEmpty)
        Align(
          alignment: Alignment.centerLeft,
          child: Btn(bi('સારાંશ WhatsApp પર મોકલો', 'Send summary on WhatsApp'), icon: 'chat', kind: BtnKind.tonal, dense: true, onTap: () => whatsappText(wa.toString())),
        ),
      const SizedBox(height: 12),
    ];
    if (_firm.isEmpty && perFirm.length > 1) {
      out.add(caption(bi('ફર્મ મુજબ', 'By firm')));
      final List<String> keys = perFirm.keys.toList();
      keys.sort((String a, String b) => _firmOrder(a).compareTo(_firmOrder(b)));
      for (final String f in keys) {
        final Map<String, double> m = perFirm[f] ?? <String, double>{};
        out.add(Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Panel(
            title: firmName(f),
            child: Column(
              children: <Widget>[
                for (final String b in <String>['purchase', 'sales', 'payment', 'receipt'])
                  if ((m[b] ?? 0) > 0) InfoRow(_bt(b).label, _rs(m[b] ?? 0)),
              ],
            ),
          ),
        ));
      }
    }
    if (buyers.isNotEmpty) {
      out.add(caption(bi('સૌથી વધુ વેચાણ (ખરીદનાર)', 'Top buyers (sales)')));
      for (final MapEntry<String, double> e in top(buyers)) {
        out.add(lineItem(icon: 'cart', tone: 'green', title: e.key, trailing: _rs(e.value), onTap: () => openTallyParty(context, e.key)));
      }
    }
    if (suppliers.isNotEmpty) {
      out.add(caption(bi('સૌથી વધુ ખરીદી (પાર્ટી)', 'Top suppliers (purchase)')));
      for (final MapEntry<String, double> e in top(suppliers)) {
        out.add(lineItem(icon: 'bag', tone: 'amber', title: e.key, trailing: _rs(e.value), onTap: () => openTallyParty(context, e.key)));
      }
    }
    if (vs.isEmpty) {
      out.add(Padding(padding: const EdgeInsets.symmetric(vertical: 24), child: Text(bi('આ સમયમાં કોઈ વાઉચર નથી', 'No vouchers in this period'), textAlign: TextAlign.center, style: ts(14, c: Pal.muted))));
    }
    return out;
  }

  // ---- build
  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[payDoc, prefDoc],
      builder: (BuildContext scopeContext) => AnimatedBuilder(
        animation: Listenable.merge(<Listenable>[tallyStore, live]),
        builder: (BuildContext context, Widget? w) => _screen(context),
      ),
    );
  }

  Widget _screen(BuildContext context) {
    final bool empty = tallyStore.vouchers.isEmpty && tallyStore.ledgers.isEmpty;
    final List<Widget> body = <Widget>[];
    if (!live.isAdmin) {
      body.add(noteBox('warn', 'amber', bi('Tally ડેટા ફક્ત માલિક (admin) માટે છે.', 'Tally data is for the owner (admin) only.')));
    } else if (tallyStore.loadedAt == null && tallyStore.loading) {
      body.add(const SkeletonList());
    } else {
      body.add(_syncCard());
      body.add(const _AgentCard());
      if (tallyStore.error.isNotEmpty) {
        body.add(noteBox('warn', 'rose', tallyStore.error));
      } else if (empty) {
        body.add(noteBox(
          'warn',
          'amber',
          bi('Tally નો ડેટા હજી Supabase માં આવ્યો નથી. Tally વાળા PC પર Balaji-Tally-Agent.bat ચાલુ કરો (Tally-Setup.txt માં સ્ટેપ છે) અને થોડી વાર પછી "તાજું કરો" દબાવો.',
              'No Tally data in Supabase yet. Start Balaji-Tally-Agent.bat on the Tally PC (steps are in Tally-Setup.txt), wait a little and press Refresh.'),
        ));
      }
      if (!empty) {
        final (String, String) r = _range();
        body.add(_alertCard());
        body.add(ChipRow(
          labels: <String>[
            bi('ડે બુક', 'Day Book'),
            bi('ખાતા', 'Ledgers'),
            bi('રોજમેળ', 'Cash book'),
            bi('સ્ટોક', 'Stock'),
            bi('સારાંશ', 'Summary'),
            bi('બેંક બુક', 'Bank book'),
            bi('ઉઘરાણી / દેવા', 'Ageing'),
            bi('ખરીદી મેળ', 'Purchase check'),
            bi('ચૂકવણી → ખાતા', 'Payments → khata'),
            'GST',
            bi('ચેક', 'Checks'),
          ],
          index: _tab,
          onChanged: _goTab,
        ));
        body.add(const SizedBox(height: 10));
        body.add(_filters());
        body.add(const SizedBox(height: 12));
        switch (_tab) {
          case 0:
            body.addAll(_dayBook(context));
          case 1:
            body.addAll(_ledgerTab(context));
          case 2:
            body.addAll(_cashTab(context));
          case 3:
            body.addAll(_stockTab(context));
          case 5:
            body.add(_BankTab(firm: _firm, from: r.$1, to: r.$2));
          case 6:
            body.add(_AgeTab(firm: _firm));
          case 7:
            body.add(_MelTab(firm: _firm, from: r.$1, to: r.$2));
          case 8:
            body.add(_PayTab(firm: _firm));
          case 9:
            body.add(_GstTab(firm: _firm, from: r.$1, to: r.$2));
          case 10:
            body.add(_CheckTab(firm: _firm, from: r.$1, to: r.$2));
          default:
            body.addAll(_summaryTab(context));
        }
      }
    }
    return RefreshIndicator(
      color: Pal.brand,
      onRefresh: () => tallyStore.load(force: true),
      child: ScreenScroll(
        maxWidth: 900,
        children: <Widget>[
          ScreenHeader(bi('ટેલી ડેટા (વાંચન)', 'Tally data (read-only)'), sub: bi('Tally ના ખરા વાઉચર અને ખાતા - એપ થી Tally માં કંઈ બદલાતું નથી', 'Real Tally vouchers and ledgers - nothing is written back to Tally')),
          ...body,
        ],
      ),
    );
  }
}
