import 'package:flutter/material.dart';
import '../../core/app_state.dart' show app;
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/icons.dart';
import '../../core/palette.dart';
import '../../data/insights.dart';
import '../../data/lists.dart';
import '../../data/live_models.dart';
import '../../widgets/common.dart';
import 'ui.dart';

/// More shared building blocks for the newer screens.

/// "Magfadi" -> "મગફળી" (or "Groundnut"); an unknown name stays as written.
String matLabel(String code) {
  final String t = code.trim();
  for (final List<String> c in kCommodities) {
    if (c[0].toLowerCase() == t.toLowerCase()) return bi(c[1], c[2]);
  }
  return t;
}

/// The last [n] days including today.
Period lastDays(int n) {
  final DateTime t = dayOf(DateTime.now());
  return Period(addDays(t, -(n - 1)), addDays(t, 1));
}

/// "3.2 hours" since [t].
String sinceTxt(DateTime t) => hoursText(DateTime.now().difference(t).inMinutes / 60.0);

/// One list row: icon, title, small line below and a number on the right.
Widget lineItem({
  required String icon,
  String tone = 'teal',
  required String title,
  String? sub,
  String? trailing,
  String? trailingSub,
  Color? trailingColor,
  VoidCallback? onTap,
  Color? bar,
}) {
  final bool pc = app.stagePc;
  if (Pal.tally) {
    // TallyPrime list line:  name ........ amount   (the small line is under the name)
    return rowShell(
      onTap: onTap,
      bar: bar,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(13, w: FontWeight.w700)),
                if (sub != null) Text(sub, maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(11.5, c: Pal.muted)),
              ],
            ),
          ),
          if (trailing != null) ...<Widget>[
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Text(trailing, style: ts(13, w: FontWeight.w700, c: trailingColor, tab: true)),
                if (trailingSub != null) Text(trailingSub, style: ts(11, c: Pal.muted)),
              ],
            ),
          ],
        ],
      ),
    );
  }
  return rowShell(
    onTap: onTap,
    bar: bar,
    child: Row(
      children: <Widget>[
        IconChip(icon, tone: tone, size: 38),
        SizedBox(width: pc ? 10 : 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(pc ? 13.5 : 14.5, w: FontWeight.w800)),
              if (sub != null) ...<Widget>[
                SizedBox(height: pc ? 1 : 2),
                Text(sub, maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(pc ? 11.5 : 12.5, c: Pal.muted)),
              ],
            ],
          ),
        ),
        if (trailing != null) ...<Widget>[
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              Text(trailing, style: ts(pc ? 13.5 : 14.5, w: FontWeight.w800, c: trailingColor, tab: true)),
              if (trailingSub != null) Text(trailingSub, style: ts(pc ? 11 : 11.5, c: Pal.muted)),
            ],
          ),
        ],
      ],
    ),
  );
}

/// Coloured one-line message box.
Widget noteBox(String icon, String tone, String text, {VoidCallback? onTap}) {
  final Tone t = Pal.tone(tone);
  if (Pal.tally) {
    // TallyPrime message line: plain coloured text with a thin rule, no icon, no card
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: InkWell(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(color: t.bg, border: Border.all(color: Pal.line)),
          child: Text(text, style: ts(12.5, w: FontWeight.w700, c: t.fg)),
        ),
      ),
    );
  }
  return Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: Surface(
      color: t.bg,
      shadow: false,
      onTap: onTap,
      padding: const EdgeInsets.all(12),
      child: Row(
        children: <Widget>[
          Icon(ic(icon), size: 20, color: t.fg),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: ts(13, w: FontWeight.w700, c: t.fg))),
        ],
      ),
    ),
  );
}

/// Small grey caption above a block of rows.
Widget caption(String t) {
  return Padding(
    padding: const EdgeInsets.fromLTRB(2, 6, 2, 8),
    child: Text(t, style: ts(Pal.tally ? 12 : 12.5, w: Pal.tally ? FontWeight.w600 : FontWeight.w800, c: Pal.muted, ls: Pal.tally ? 0 : 0.3)),
  );
}

/// 12,340 -> "12.3 T" / 640 -> "640 KG" (same as kgShort, kept next to the others).
String kgTxt(double kg) => kg.abs() >= 1000 ? '${(kg / 1000).toStringAsFixed(1)} T' : '${grp(kg)} KG';

/// "12 Oct" label for a chart axis, thinned out.
String axisDay(int i, int n, DateTime d) {
  final int step = n <= 10 ? 1 : (n / 8).ceil();
  return (i % step == 0 || i == n - 1) ? '${d.day}' : '';
}

/// Small bar chart where every bar has its own colour (used for forecasts,
/// calendars and "usual vs today" pictures).
class MiniBars extends StatelessWidget {
  final List<double> values;
  final List<Color> colors;
  final List<String> labels;
  final double height;
  final double? maxV;
  const MiniBars({super.key, required this.values, required this.colors, required this.labels, this.height = 120, this.maxV});

  @override
  Widget build(BuildContext context) {
    double mx = maxV ?? 0;
    if (maxV == null) {
      for (final double v in values) {
        if (v > mx) mx = v;
      }
    }
    final double room = height - 16;
    return SizedBox(
      height: height,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: <Widget>[
          for (int i = 0; i < values.length; i++)
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 1.5),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: <Widget>[
                    Container(
                      height: mx <= 0 ? 2.0 : (room * values[i] / mx < 2.0 ? 2.0 : room * values[i] / mx),
                      decoration: BoxDecoration(
                        color: colors[i % colors.length],
                        borderRadius: const BorderRadius.vertical(top: Radius.circular(3)),
                      ),
                    ),
                    SizedBox(
                      height: 14,
                      child: Text(i < labels.length ? labels[i] : '', textAlign: TextAlign.center, softWrap: false, overflow: TextOverflow.visible, style: ts(9.5, c: Pal.muted)),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// true when [a] and [b] differ by exactly one typo (one wrong, missing or
/// extra character).
bool nearStr(String a, String b) {
  if (a == b) return false;
  final int la = a.length;
  final int lb = b.length;
  if ((la - lb).abs() > 1) return false;
  if (la == lb) {
    int d = 0;
    for (int i = 0; i < la; i++) {
      if (a.codeUnitAt(i) != b.codeUnitAt(i)) {
        d++;
        if (d > 1) return false;
      }
    }
    return d == 1;
  }
  final String s = la < lb ? a : b;
  final String l = la < lb ? b : a;
  int i = 0;
  int j = 0;
  int d = 0;
  while (i < s.length && j < l.length) {
    if (s.codeUnitAt(i) == l.codeUnitAt(j)) {
      i++;
      j++;
    } else {
      d++;
      if (d > 1) return false;
      j++;
    }
  }
  d += (l.length - j) + (s.length - i);
  return d <= 1;
}

/// [101, 102, 103, 107] -> "101-103, 107"
String rangesText(List<int> nums) {
  if (nums.isEmpty) return '';
  final List<int> s = List<int>.from(nums)..sort();
  final List<String> parts = <String>[];
  int start = s.first;
  int prev = s.first;
  for (int i = 1; i < s.length; i++) {
    if (s[i] == prev + 1) {
      prev = s[i];
      continue;
    }
    parts.add(start == prev ? '$start' : '$start-$prev');
    start = s[i];
    prev = s[i];
  }
  parts.add(start == prev ? '$start' : '$start-$prev');
  return parts.join(', ');
}

/// Indian vehicle number (GJ12CT5828, GJ03W8824) or BH series, after cleaning.
bool plateOk(String vk) {
  if (vk.isEmpty) return false;
  return RegExp(r'^[A-Z]{2}[0-9]{1,2}[A-Z]{0,3}[0-9]{1,4}$').hasMatch(vk) || RegExp(r'^[0-9]{2}BH[0-9]{4}[A-Z]{2}$').hasMatch(vk);
}
