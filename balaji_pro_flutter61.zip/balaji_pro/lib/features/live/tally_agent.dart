part of 'tally_data.dart';

// ======================================================================
// PC Agent status card (Tally data screen).
// The Agent on the Tally PC copies Tally -> Supabase and writes a small
// heartbeat row (firm "_sys", name "~A~beat"). This card reads it and says in
// plain words WHY there is no data: Agent not installed / PC off / Tally not
// answering / login lost / last sync failed. It can also ask the Agent to
// sync now (row "~A~cmd"). Nothing is ever written into Tally.
// ======================================================================

String _agMin(double m) {
  if (m > 1e8) return '-';
  if (m < 1) return bi('હમણાં જ', 'just now');
  if (m < 60) return '${m.round()} ${bi('મિનિટ', 'min')}';
  if (m < 2880) return '${(m / 60).round()} ${bi('કલાક', 'h')}';
  return '${(m / 1440).round()} ${bi('દિવસ', 'days')}';
}

class _AgSt {
  final String st; // none | down | login | tally | sync | ok
  final double age; // minutes since the last heartbeat
  final Map<String, dynamic> hb;
  _AgSt(this.st, this.age, this.hb);

  Map<String, dynamic> get sync {
    final Object? s = hb['sync'];
    return s is Map ? Map<String, dynamic>.from(s) : <String, dynamic>{};
  }
}

_AgSt _agStatus() {
  if (tallyStore.fromCache) return _AgSt('offline', 0, <String, dynamic>{});
  final Map<String, dynamic>? hb = tallyStore.beat;
  if (hb == null) return _AgSt('none', 0, <String, dynamic>{});
  final DateTime? at = DateTime.tryParse(_s(hb['at']))?.toLocal() ?? tallyStore.beatRowAt;
  final double age = at == null ? 1e9 : DateTime.now().difference(at).inSeconds / 60.0;
  final Object? sy = hb['sync'];
  String st = 'ok';
  if (age > 12) {
    st = 'down';
  } else if (hb['auth'] == false || hb['admin'] == false) {
    st = 'login';
  } else if (hb['tally'] == false) {
    st = 'tally';
  } else if (sy is Map && sy['ok'] == false) {
    st = 'sync';
  }
  return _AgSt(st, age, hb);
}

class _AgentCard extends StatefulWidget {
  const _AgentCard();

  @override
  State<_AgentCard> createState() => _AgentCardState();
}

class _AgentCardState extends State<_AgentCard> {
  bool? _open;
  bool _busy = false;
  String _msg = '';

  @override
  void initState() {
    super.initState();
    tallyStore.refreshBeat();
  }

  void _done(String m) {
    if (!mounted) return;
    setState(() {
      _busy = false;
      _msg = m;
    });
  }

  Future<void> _ask(String c) async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _msg = bi('PC ને વિનંતી મોકલી… (1-2 મિનિટ લાગી શકે)', 'Request sent to the PC… (may take 1-2 minutes)');
    });
    try {
      final String id = '${DateTime.now().microsecondsSinceEpoch}';
      await tallyStore.sendCmd(<String, dynamic>{'id': id, 'c': c, 'at': DateTime.now().toUtc().toIso8601String(), 'by': 'pro'});
      if (c == 'reload') {
        _done(bi('✔ Agent ને ફરી લોડ કરવાનું કહ્યું.', '✔ Asked the Agent to reload.'));
        return;
      }
      final DateTime end = DateTime.now().add(Duration(seconds: c == 'full' ? 240 : 100));
      Map<String, dynamic>? d;
      while (DateTime.now().isBefore(end)) {
        await Future<void>.delayed(const Duration(milliseconds: 3500));
        if (!mounted) return;
        await tallyStore.refreshBeat();
        final Object? cd = tallyStore.beat?['cmdDone'];
        if (cd is Map && '${cd['id']}' == id) {
          d = Map<String, dynamic>.from(cd);
          break;
        }
      }
      if (!mounted) return;
      if (d == null) {
        _done(bi('PC એ હજી જવાબ નથી આપ્યો — થોડી વાર પછી જુઓ.', 'The PC has not answered yet — look again in a little while.'));
        return;
      }
      await tallyStore.load(force: true);
      final String why = _s(d['msg']);
      _done(d['ok'] == true ? bi('✔ PC પર સિંક થઈ ગયું', '✔ Synced on the PC') : '✗ ${why.isEmpty ? bi('સિંક ન થયું', 'Sync failed') : why}');
    } catch (e) {
      _done(tallyStore._msg(e));
    }
  }

  void _log() {
    final Map<String, dynamic>? hb = tallyStore.beat;
    final StringBuffer b = StringBuffer();
    final Object? lg = hb?['log'];
    if (lg is List) {
      for (final Object? e in lg) {
        b.writeln('$e');
      }
    }
    final Object? er = hb?['errs'];
    if (er is List && er.isNotEmpty) {
      b.writeln();
      for (final Object? e in er) {
        b.writeln('$e');
      }
    }
    final String t = b.toString().trim();
    showDialog<void>(
      context: context,
      builder: (BuildContext ctx) => AlertDialog(
        title: Text(bi('Agent લોગ', 'Agent log')),
        content: SizedBox(
          width: 520,
          child: SingleChildScrollView(child: SelectableText(t.isEmpty ? '-' : t, style: ts(12, h: 1.4))),
        ),
        actions: <Widget>[
          TextButton(onPressed: () => copyText(t), child: Text(bi('કૉપિ', 'Copy'))),
          TextButton(onPressed: () => Navigator.of(ctx).pop(), child: Text(bi('બંધ', 'Close'))),
        ],
      ),
    );
  }

  /// icon, tone, title, sub
  (String, String, String, String) _head(_AgSt s) {
    final Map<String, dynamic> sy = s.sync;
    switch (s.st) {
      case 'offline':
        return (
          'wifioff',
          'slate',
          bi('ઇન્ટરનેટ નથી', 'No internet'),
          bi('Agent ની સ્થિતિ ઇન્ટરનેટ આવે ત્યારે દેખાશે. હમણાં સેવ કરેલો Tally ડેટા દેખાય છે.', 'The Agent status shows once the internet is back. The saved Tally data is shown now.'),
        );
      case 'none':
        return (
          'warn',
          'amber',
          bi('PC Agent હજી ચાલુ થયું નથી', 'The PC Agent has not started yet'),
          bi('Supabase માં Agent નો કોઈ સંકેત નથી. Tally વાળા PC પર એક વાર Agent ઇન્સ્ટોલ કરવું પડશે.', 'Supabase has no sign of the Agent. It must be installed once on the Tally PC.'),
        );
      case 'down':
        return (
          'err',
          'rose',
          bi('PC Agent ${_agMin(s.age)} થી જવાબ આપતું નથી', 'The PC Agent has not answered for ${_agMin(s.age)}'),
          bi('Tally વાળું PC ચાલુ છે? Windows લોગિન થયેલું છે? Agent ચાલુ છે?', 'Is the Tally PC on and logged in to Windows? Is the Agent running?'),
        );
      case 'login':
        return (
          'lock',
          'rose',
          bi('Agent માં લોગિન જતું રહ્યું', 'The Agent lost its login'),
          bi('PC પર Desktop ના "Balaji Tally Status" માંથી "Login / setup window" ખોલી admin થી ફરી લોગિન કરો.', 'On the PC open "Balaji Tally Status" on the desktop > "Login / setup window" and sign in as admin again.'),
        );
      case 'tally':
        return (
          'warn',
          'amber',
          bi('Agent ચાલુ છે પણ Tally જવાબ નથી આપતું', 'The Agent is running but Tally is not answering'),
          bi('Tally ખુલ્લું છે? F1 → Settings → Connectivity → Port 9000, અને ત્રણેય કંપની Alt+F3 થી load કરો.', 'Is Tally open? F1 > Settings > Connectivity > port 9000, and load all companies with Alt+F3.'),
        );
      case 'sync':
        return (
          'warn',
          'amber',
          bi('Agent ચાલુ છે — છેલ્લું સિંક ન થયું', 'The Agent is running - the last sync failed'),
          _s(sy['msg']).isEmpty ? bi('Agent લોગ જુઓ.', 'See the Agent log.') : _s(sy['msg']),
        );
    }
    final DateTime? sat = DateTime.tryParse(_s(sy['at']))?.toLocal();
    return (
      'check',
      'green',
      bi('Tally PC Agent ચાલુ છે', 'The Tally PC Agent is running'),
      '${bi('છેલ્લું સિંક', 'Last sync')}: ${sat == null ? '-' : ago(sat)} · ${tallyStore.vouchers.length} ${bi('વાઉચર', 'vouchers')} · ${tallyStore.ledgers.length} ${bi('ખાતા', 'ledgers')}',
    );
  }

  Widget _check(bool? ok, String title, [String? sub]) {
    return lineItem(
      icon: ok == null ? 'info' : (ok ? 'check' : 'err'),
      tone: ok == null ? 'slate' : (ok ? 'green' : 'rose'),
      title: title,
      sub: (sub == null || sub.isEmpty) ? null : sub,
    );
  }

  List<Widget> _details(_AgSt s) {
    final Map<String, dynamic> hb = s.hb;
    final Map<String, dynamic> sy = s.sync;
    final List<Widget> out = <Widget>[];
    final bool dbOk = tallyStore.error.isEmpty;
    out.add(_check(
      dbOk,
      dbOk ? bi('Supabase માં: ${tallyStore.vouchers.length} વાઉચર, ${tallyStore.ledgers.length} ખાતા', 'In Supabase: ${tallyStore.vouchers.length} vouchers, ${tallyStore.ledgers.length} ledgers') : bi('Supabase વંચાતું નથી', 'Supabase cannot be read'),
      dbOk ? null : tallyStore.error,
    ));
    if (s.st == 'offline') return out;
    if (s.st == 'none') {
      out.add(noteBox(
        'info',
        'blue',
        bi(
          'એક વારનું સેટઅપ (Tally વાળા Windows PC પર):\n1) Tally: F1 → Settings → Connectivity → Client/Server → "Both" અને Port 9000.\n2) ત્રણેય કંપની Alt+F3 થી load કરો.\n3) Balaji-Tally-Agent.bat ડબલ-ક્લિક કરો → 1 દબાવો (INSTALL).\n4) ખુલેલી Setup window માં admin થી લોગિન કરી ઉપર "પૂરું" દબાવો.\n5) 5-10 મિનિટ પછી અહીં "તાજું કરો" દબાવો.',
          'One-time setup (on the Windows PC that runs Tally):\n1) Tally: F1 > Settings > Connectivity > Client/Server > "Both", port 9000.\n2) Load all three companies with Alt+F3.\n3) Double-click Balaji-Tally-Agent.bat > press 1 (INSTALL).\n4) In the Setup window that opens, sign in as admin and press "Done" on top.\n5) After 5-10 minutes press Refresh here.',
        ),
      ));
      return out;
    }
    final DateTime? bat = DateTime.tryParse(_s(hb['at']))?.toLocal() ?? tallyStore.beatRowAt;
    out.add(_check(
      s.st != 'down',
      '${bi('Agent નો છેલ્લો જવાબ', 'Last answer from the Agent')}: ${_agMin(s.age)} ${bi('પહેલાં', 'ago')}',
      <String>[
        if (_s(hb['build']).isNotEmpty) '${bi('વર્ઝન', 'build')} ${_s(hb['build'])}',
        if (bat != null) dmy(bat),
        if (_s(hb['every']).isNotEmpty) '${bi('દર', 'every')} ${_s(hb['every'])} ${bi('મિનિટે સિંક', 'min sync')}',
      ].join(' · '),
    ));
    out.add(_check(
      hb['tally'] == null ? null : hb['tally'] == true,
      hb['tally'] == false ? bi('Tally જવાબ નથી આપતું', 'Tally is not answering') : (hb['tally'] == true ? bi('Tally જવાબ આપે છે', 'Tally is answering') : bi('Tally ની સ્થિતિ ખબર નથી', 'Tally status unknown')),
      hb['tally'] == false ? bi('Tally ખુલ્લું રાખો, Port 9000 ચાલુ કરો અને કંપની load કરો.', 'Keep Tally open, switch port 9000 on and load the companies.') : null,
    ));
    final bool? login = (hb['auth'] == null && hb['admin'] == null) ? null : (hb['auth'] != false && hb['admin'] != false);
    out.add(_check(
      login,
      login == false ? bi('Agent માં admin લોગિન નથી', 'The Agent is not logged in as admin') : bi('Agent માં admin લોગિન છે', 'The Agent is logged in as admin'),
    ));
    final DateTime? sat = DateTime.tryParse(_s(sy['at']))?.toLocal();
    final String n = _s(sy['n']);
    out.add(_check(
      sat == null ? null : (sy['ok'] != false),
      sat == null ? bi('હજી સિંક થયું નથી', 'No sync yet') : '${bi('છેલ્લું સિંક', 'Last sync')}: ${ago(sat)}${n.isEmpty || n == '0' ? '' : ' · $n ${bi('વાઉચર', 'vouchers')}'}',
      <String>[
        if (_s(sy['msg']).isNotEmpty) _s(sy['msg']),
        if (_s(sy['warn']).isNotEmpty) _s(sy['warn']),
      ].join('\n'),
    ));
    if (s.st != 'down') {
      out.add(const SizedBox(height: 4));
      out.add(Wrap(
        spacing: 8,
        runSpacing: 8,
        children: <Widget>[
          Btn(bi('PC પર હમણાં સિંક', 'Sync now on the PC'), icon: 'sync', dense: true, onTap: _busy ? null : () => _ask('sync')),
          Btn(bi('શરૂઆતથી બધું', 'Everything from the start'), icon: 'hist', kind: BtnKind.outline, dense: true, onTap: _busy ? null : () => _ask('full')),
          Btn(bi('Agent ફરી લોડ', 'Reload Agent'), icon: 'refresh', kind: BtnKind.outline, dense: true, onTap: _busy ? null : () => _ask('reload')),
          Btn(bi('Agent લોગ', 'Agent log'), icon: 'terminal', kind: BtnKind.ghost, dense: true, onTap: _log),
        ],
      ));
    } else {
      out.add(const SizedBox(height: 4));
      out.add(Btn(bi('Agent લોગ (છેલ્લો)', 'Agent log (last)'), icon: 'terminal', kind: BtnKind.ghost, dense: true, onTap: _log));
    }
    if (_msg.isNotEmpty) {
      out.add(const SizedBox(height: 8));
      out.add(Text(_msg, style: ts(12.5, c: Pal.muted, w: FontWeight.w600)));
    }
    return out;
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: tallyStore,
      builder: (BuildContext context, Widget? w) {
        final _AgSt s = _agStatus();
        final bool open = _open ?? (s.st != 'ok');
        final (String, String, String, String) h = _head(s);
        return Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Surface(
            padding: const EdgeInsets.all(8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                lineItem(
                  icon: h.$1,
                  tone: h.$2,
                  title: h.$3,
                  sub: h.$4,
                  trailing: open ? '▴' : '▾',
                  onTap: () => setState(() => _open = !open),
                ),
                if (open) ...<Widget>[
                  const SizedBox(height: 4),
                  ..._details(s),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}
