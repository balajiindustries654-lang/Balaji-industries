part of 'tally_data.dart';

// ======================================================================
// Tally numbers inside OUR screens.
// The Tally books (the "pakka" books with GST of Patel, Shreenathji and Balaji) are read-only copies made by the PC
// Agent. This file gives a few ready numbers from them, and one small strip that every main screen of the app
// (Sales, Outstandings, Cash book, Bank book, Stock, Balance Sheet, Day Book ...) shows on top, so the Tally figure
// is always next to ours. Tapping the strip opens the matching Tally screen.
// ======================================================================

/// What a strip shows.
enum TallyWhat {
  /// sales of the period + GST on them
  sales,

  /// purchases of the period + GST on them
  purchase,

  /// to receive / to pay (Tally ledgers, as of the last sync)
  dues,

  /// cash in Tally
  cash,

  /// bank in Tally
  bank,

  /// stock value in Tally
  stock,

  /// sales, purchase, GST to pay, to receive / to pay - the whole picture
  all,

  /// only the GST (taken on sales, paid on purchase, to pay)
  gst,
}

/// A few Tally figures of all the firms together.
class TallyGlance {
  final bool has;
  final int salesN;
  final int purchN;
  final double sales; // sales vouchers (with tax), credit notes taken off
  final double purchase; // purchase vouchers (with tax), debit notes taken off
  final double gstOut; // GST charged on sales
  final double gstIn; // GST paid on purchases
  final double receivable; // debtors with a debit balance
  final double payable; // creditors with a credit balance
  final double cash;
  final double bank;
  final double stockValue;
  final DateTime? at;
  const TallyGlance({
    required this.has,
    required this.salesN,
    required this.purchN,
    required this.sales,
    required this.purchase,
    required this.gstOut,
    required this.gstIn,
    required this.receivable,
    required this.payable,
    required this.cash,
    required this.bank,
    required this.stockValue,
    required this.at,
  });

  /// GST to be paid to the Government (negative = to get back)
  double get gstNet => gstOut - gstIn;
}

/// [from] / [to] are inclusive days like "2026-04-01".
TallyGlance tallyGlance(String from, String to) {
  final bool has = tallyStore.allVouchers.isNotEmpty || tallyStore.ledgers.isNotEmpty;
  double sales = 0;
  double purchase = 0;
  int sn = 0;
  int pn = 0;
  for (final TVoucher v in tallyStore.vouchers) {
    if (v.cancelled || v.optional || !(v.amount > 0)) continue;
    if (!_inRange(v.date, from, to)) continue;
    switch (v.base) {
      case 'sales':
        sales += v.amount;
        sn++;
      case 'creditnote':
        sales -= v.amount;
      case 'debitnote':
        purchase -= v.amount;
    }
  }
  // purchases are counted from their own list (they are not shown as transactions in simple mode)
  for (final TVoucher v in tallyStore.purchases) {
    if (v.cancelled || v.optional || !(v.amount > 0)) continue;
    if (!_inRange(v.date, from, to)) continue;
    purchase += v.amount;
    pn++;
  }
  final _Gst g = _buildGst('', from, to);
  double rec = 0;
  double pay = 0;
  double cash = 0;
  double bank = 0;
  for (final TLedger l in tallyStore.ledgers) {
    // simple mode: what the buyers owe is read from the three sales firms; cash and bank are the other firm's only
    final bool own = kOwnFirms.contains(l.firm);
    switch (l.kind) {
      case 'debtor':
        if (l.closing < 0 && (!kSimple || own)) rec += -l.closing;
      case 'creditor':
        if (l.closing > 0 && !kSimple) pay += l.closing;
      case 'cash':
        if (!kSimple || !own) cash += -l.closing;
      case 'bank':
        if (!kSimple || !own) bank += -l.closing;
    }
  }
  double stock = 0;
  for (final TStock s in tallyStore.stock) {
    stock += s.value;
  }
  return TallyGlance(
    has: has,
    salesN: sn,
    purchN: pn,
    sales: sales,
    purchase: purchase,
    gstOut: g.outTax,
    gstIn: g.inTax,
    receivable: rec,
    payable: pay,
    cash: cash,
    bank: bank,
    stockValue: stock,
    at: tallyStore.lastSync,
  );
}

/// The screen that opens when the strip is tapped.
String _tallyRoute(TallyWhat w) {
  if (kSimple) {
    // simple mode: the Tally screens that are hidden lead to the screen of ours that shows the same thing
    switch (w) {
      case TallyWhat.sales:
      case TallyWhat.gst:
      case TallyWhat.all:
        return 'tally_live';
      case TallyWhat.purchase:
        return 'tally_mel';
      case TallyWhat.dues:
        return 'collection';
      case TallyWhat.cash:
        return 'cashbook';
      case TallyWhat.bank:
        return 'bank_book';
      case TallyWhat.stock:
        return 'stock_live';
    }
  }
  switch (w) {
    case TallyWhat.sales:
      return 'tally_live';
    case TallyWhat.purchase:
      return 'tally_mel';
    case TallyWhat.dues:
      return 'tally_age';
    case TallyWhat.cash:
      return 'tally_cash';
    case TallyWhat.bank:
      return 'tally_bank';
    case TallyWhat.stock:
      return 'tally_stock';
    case TallyWhat.gst:
      return 'tally_gst';
    case TallyWhat.all:
      return 'tally_sum';
  }
}

/// A small box "Tally: ..." with the Tally figure for this screen. [from] / [to] (days, inclusive) set the period
/// of the figures that have one; without them the whole financial year is used.
Widget tallyStrip(TallyWhat what, {DateTime? from, DateTime? to}) => _TallyStrip(what, from: from, to: to);

class _TallyStrip extends StatefulWidget {
  final TallyWhat what;
  final DateTime? from;
  final DateTime? to;
  const _TallyStrip(this.what, {this.from, this.to});

  @override
  State<_TallyStrip> createState() => _TallyStripState();
}

class _TallyStripState extends State<_TallyStrip> {
  @override
  void initState() {
    super.initState();
    tallyStore.addListener(_tick);
    if (live.isAdmin) tallyStore.load();
  }

  @override
  void dispose() {
    tallyStore.removeListener(_tick);
    super.dispose();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  List<(String, String, Color?)> _pairs(TallyGlance g) {
    final TallyWhat w = widget.what;
    final List<(String, String, Color?)> o = <(String, String, Color?)>[];
    String gstLine(double v) => _rs(v);
    if (w == TallyWhat.sales || w == TallyWhat.all) {
      o.add((bi('વેચાણ', 'Sales'), '${_rs(g.sales)} (${g.salesN})', null));
    }
    if (w == TallyWhat.purchase || (w == TallyWhat.all && !kSimple)) {
      o.add((bi('ખરીદી', 'Purchase'), '${_rs(g.purchase)} (${g.purchN})', null));
    }
    if (!kSimple) {
      if (w == TallyWhat.sales || w == TallyWhat.gst || w == TallyWhat.all) {
        o.add((bi('વેચાણ પર GST', 'GST on sales'), gstLine(g.gstOut), null));
      }
      if (w == TallyWhat.purchase || w == TallyWhat.gst || w == TallyWhat.all) {
        o.add((bi('ખરીદી પર GST', 'GST on purchase'), gstLine(g.gstIn), null));
      }
      if (w == TallyWhat.gst || w == TallyWhat.all) {
        o.add((g.gstNet >= 0 ? bi('GST ભરવાનો', 'GST to pay') : bi('GST પાછો લેવાનો', 'GST to get back'), gstLine(g.gstNet.abs()), g.gstNet > 0.5 ? Pal.warn : Pal.ok));
      }
    }
    if (w == TallyWhat.dues || w == TallyWhat.all) {
      o.add((bi('લેવાના', 'To receive'), _rs(g.receivable), null));
      if (!kSimple) o.add((bi('આપવાના', 'To pay'), _rs(g.payable), null));
    }
    if (w == TallyWhat.cash || (w == TallyWhat.all && kSimple)) o.add((bi('રોકડ', 'Cash'), _rs(g.cash), null));
    if (w == TallyWhat.bank || (w == TallyWhat.all && kSimple)) o.add((bi('બેંક', 'Bank'), _rs(g.bank), null));
    if (w == TallyWhat.stock) o.add((bi('સ્ટોકની કિંમત', 'Stock value'), _rs(g.stockValue), null));
    return o;
  }

  @override
  Widget build(BuildContext context) {
    final DateTime now = DateTime.now();
    final String fy = TallyStore.fyStart();
    final String from = widget.from == null ? fy : _dk(widget.from!);
    final String to = widget.to == null ? _dk(now) : _dk(widget.to!);
    final TallyGlance g = tallyGlance(from, to);
    final bool tally = Pal.tally;
    final String route = _tallyRoute(widget.what);
    final String where = widget.from == null ? bi('આ વર્ષ', 'this year') : '${_dmShort(widget.from!)} - ${_dmShort(widget.to!)}';
    final bool withPeriod = widget.what == TallyWhat.sales || widget.what == TallyWhat.purchase || widget.what == TallyWhat.gst || widget.what == TallyWhat.all;

    Widget body;
    if (!g.has) {
      body = Text(
        tallyStore.loading ? bi('Tally નો ડેટા આવે છે...', 'Tally data is coming...') : bi('Tally નો ડેટા હજી આવ્યો નથી - અહીં દબાવી જુઓ', 'No Tally data yet - tap here to see'),
        style: ts(12.5, c: Pal.muted, w: FontWeight.w600),
      );
    } else {
      body = Wrap(
        spacing: 22,
        runSpacing: 3,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: <Widget>[
          for (final (String, String, Color?) p in _pairs(g))
            Text.rich(
              TextSpan(children: <InlineSpan>[
                TextSpan(text: '${p.$1}  ', style: ts(12.5, c: Pal.muted, w: FontWeight.w600)),
                TextSpan(text: p.$2, style: ts(13.5, w: FontWeight.w800, c: p.$3 ?? Pal.ink, tab: true)),
              ]),
            ),
        ],
      );
    }

    final Widget tag = Text(
      'Tally · ${kSimple ? bi('વેચાણ (3 ફર્મ) · રોકડ / ઓનલાઇન (બીજી ફર્મ)', 'sales (3 firms) · cash / online (other firm)') : bi('બધી ફર્મ', 'all firms')}${withPeriod ? ' · $where' : ''}',
      style: ts(12, w: FontWeight.w800, c: Pal.brand),
    );
    return Padding(
      padding: EdgeInsets.only(bottom: tally ? 8 : 12),
      child: Material(
        color: tally ? Pal.surface : Pal.soft,
        shape: tally ? Border.all(color: Pal.line) : RoundedRectangleBorder(borderRadius: BorderRadius.circular(Pal.rad(14))),
        child: InkWell(
          canRequestFocus: false,
          onTap: () => app.go(route),
          hoverColor: Pal.focusFill,
          child: Padding(
            padding: EdgeInsets.fromLTRB(10, tally ? 5 : 9, 10, tally ? 6 : 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Expanded(child: tag),
                    if (g.at != null) Text('${bi('સિંક', 'synced')} ${ago(g.at!)}', style: ts(11, c: Pal.faint, w: FontWeight.w600)),
                  ],
                ),
                const SizedBox(height: 2),
                body,
              ],
            ),
          ),
        ),
      ),
    );
  }
}

String _dmShort(DateTime d) => '${d.day} ${const <String>['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][d.month - 1]}';

// ======================================================================
// Tally lists inside OUR screens (not only under the Tally button)
//   tallyRows(...)           the Tally vouchers that belong to the screen: sales -> Sales, cash / online money -> Cash book / Bank book
//   tallyPayBanner()         "N Tally payments waiting to go into the farmer khata"  -> Payments, Farmer khata
//   tallyPurchaseBanner()    "Tally purchases that are not in Pro / have another amount" -> Chit list, Home
// They show nothing when there is nothing to say, so a screen stays clean.
// ======================================================================

/// Which Tally vouchers a list shows.
enum TallyRows {
  /// sales vouchers (the three sales firms)
  sales,

  /// cash money (payment, receipt, contra paid in cash)
  cash,

  /// online money (UPI, bank, cheque)
  bank,
}

/// The newest Tally vouchers of this kind, [from] / [to] inclusive days (default: the last 30 days).
Widget tallyRows(TallyRows what, {DateTime? from, DateTime? to, int max = 6}) => _TallyRowsBox(what, from: from, to: to, max: max);

class _TallyRowsBox extends StatefulWidget {
  final TallyRows what;
  final DateTime? from;
  final DateTime? to;
  final int max;
  const _TallyRowsBox(this.what, {this.from, this.to, this.max = 6});

  @override
  State<_TallyRowsBox> createState() => _TallyRowsBoxState();
}

class _TallyRowsBoxState extends State<_TallyRowsBox> {
  @override
  void initState() {
    super.initState();
    tallyStore.addListener(_tick);
    if (live.isAdmin) tallyStore.load();
  }

  @override
  void dispose() {
    tallyStore.removeListener(_tick);
    super.dispose();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  bool _take(TVoucher v) {
    if (v.cancelled || v.optional) return false;
    switch (widget.what) {
      case TallyRows.sales:
        return v.base == 'sales';
      case TallyRows.cash:
        return kCashBase.contains(v.base) && (v.mode == 'cash' || v.base == 'contra');
      case TallyRows.bank:
        return kCashBase.contains(v.base) && v.mode != 'cash';
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!live.isAdmin) return const SizedBox.shrink();
    final DateTime now = DateTime.now();
    final String from = _dk(widget.from ?? now.subtract(const Duration(days: 30)));
    final String to = _dk(widget.to ?? now);
    final List<TVoucher> l = <TVoucher>[
      for (final TVoucher v in tallyStore.vouchers)
        if (_take(v) && _inRange(v.date, from, to)) v,
    ];
    if (l.isEmpty) return const SizedBox.shrink();
    l.sort((TVoucher a, TVoucher b) {
      final int c = b.date.compareTo(a.date);
      return c != 0 ? c : b.id.compareTo(a.id);
    });
    double sum = 0;
    for (final TVoucher v in l) {
      sum += v.amount;
    }
    final String title = widget.what == TallyRows.sales
        ? bi('Tally ના વેચાણ', 'Sales in Tally')
        : (widget.what == TallyRows.cash ? bi('Tally ની રોકડ', 'Cash in Tally') : bi('Tally ની બેંક / ઓનલાઇન', 'Bank / online in Tally'));
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Panel(
        title: title,
        sub: '${l.length} · ${_rs(sum)}',
        action: Btn(bi('બધા', 'All'), dense: true, kind: BtnKind.tonal, onTap: () => app.go('tally_live')),
        child: Column(children: <Widget>[for (final TVoucher v in l.take(widget.max)) _vTile(context, v)]),
      ),
    );
  }
}

enum _TallyLineKind { pay, purchase }

/// A line "N Tally payments are waiting to go into the farmer khata" (nothing when none).
Widget tallyPayBanner() => const _TallyLine(_TallyLineKind.pay);

/// A line about the Tally purchases of the last 7 days that are not in Pro or have another amount (nothing when all is the same).
Widget tallyPurchaseBanner() => const _TallyLine(_TallyLineKind.purchase);

class _TallyLine extends StatefulWidget {
  final _TallyLineKind kind;
  const _TallyLine(this.kind);

  @override
  State<_TallyLine> createState() => _TallyLineState();
}

class _TallyLineState extends State<_TallyLine> {
  @override
  void initState() {
    super.initState();
    tallyStore.addListener(_tick);
    if (live.isAdmin) tallyStore.load();
  }

  @override
  void dispose() {
    tallyStore.removeListener(_tick);
    super.dispose();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    if (!live.isAdmin || (tallyStore.allVouchers.isEmpty && tallyStore.ledgers.isEmpty)) return const SizedBox.shrink();
    try {
      final _Matcher mt = _matcher();
      if (widget.kind == _TallyLineKind.pay) {
        int wait = 0;
        for (final _Plan p in _buildPlan(mt)) {
          if (p.state == 'ready' || p.state == 'review') wait++;
        }
        if (wait == 0) return const SizedBox.shrink();
        return noteBox(
          'pay',
          'amber',
          bi('$wait Tally ચૂકવણી ખેડૂત ખાતામાં નાખવાની બાકી - જોવા દબાવો', '$wait Tally payments waiting to go into the farmer khata - tap to see'),
          onTap: () => app.go('tally_pay'),
        );
      }
      final String t = _today();
      final String f7 = _dk(DateTime.now().subtract(const Duration(days: 7)));
      final _Mel mel = _buildMel('', f7, t, mt);
      int notInPro = 0;
      int other = 0;
      for (final _MelRow r in mel.rows) {
        if (r.state == 'tally_only') {
          notInPro++;
        } else if (r.state == 'diff') {
          other++;
        }
      }
      if (notInPro == 0 && other == 0) return const SizedBox.shrink();
      final List<String> gu = <String>[
        if (notInPro > 0) '$notInPro ${bi('Tally ખરીદી Pro માં નથી', 'Tally purchases not in Pro')}',
        if (other > 0) '$other ${bi('માં રકમ અલગ', 'with another amount')}',
      ];
      return noteBox('cmp', 'amber', '${bi('ખરીદી મેળ (7 દિવસ)', 'Purchase check (7 days)')}: ${gu.join(' · ')}', onTap: () => app.go('tally_mel'));
    } catch (_) {
      return const SizedBox.shrink();
    }
  }
}
