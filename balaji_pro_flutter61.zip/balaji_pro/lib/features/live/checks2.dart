import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/engine.dart';
import '../../data/insights.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../data/owner_docs.dart';
import '../../data/supa.dart' show digitsOf;
import '../../widgets/charts.dart';
import '../../widgets/common.dart';
import '../../widgets/page.dart';
import 'kit.dart';
import 'kit2.dart';
import 'ui.dart';

import '../../widgets/accept.dart';
Color _pctColor(double pct) => pct >= 90 ? Pal.ok : (pct >= 70 ? Pal.warn : Pal.bad);

// ================================================================== quality
class _Q {
  final String label;
  final int ok;
  final int total;
  final int weight;
  final String route;
  const _Q(this.label, this.ok, this.total, this.weight, this.route);
  double get pct => total == 0 ? 0 : ok / total * 100;
}

class _QP {
  final String id;
  int n = 0;
  int photo = 0;
  int mobile = 0;
  int plate = 0;
  _QP(this.id);
  double get score => n == 0 ? 0 : (photo + mobile + plate) / (3 * n) * 100;
}

/// How completely the entries are filled in (photos, mobiles, vehicle numbers).
class QualityScreen extends StatefulWidget {
  const QualityScreen({super.key});

  @override
  State<QualityScreen> createState() => _QualityState();
}

class _QualityState extends State<QualityScreen> {
  RangeSel _sel = RangeSel(3);

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 800,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = _sel.period;
        final List<Chit> cs = live.chits.where((Chit c) => p.has(c.at)).toList();
        final List<Kanta> ks = live.kantas.where((Kanta k) => p.has(k.at)).toList();
        final List<MaalRow> ms = live.maals.where((MaalRow m) => p.has(m.at)).toList();

        int plateChits = 0;
        for (final Chit c in cs) {
          if (plateOk(c.vkey)) plateChits++;
        }
        int plateKantas = 0;
        for (final Kanta k in ks) {
          if (plateOk(k.vkey)) plateKantas++;
        }
        int cPhoto = 0;
        int cMobile = 0;
        int cBroker = 0;
        int cVillage = 0;
        int cBags = 0;
        for (final Chit c in cs) {
          if (c.photo.isNotEmpty) cPhoto++;
          if (digitsOf(c.mobile).length == 10) cMobile++;
          if (c.broker.isNotEmpty) cBroker++;
          if (c.village.isNotEmpty) cVillage++;
          if (c.bags > 0) cBags++;
        }
        int kSlip = 0;
        for (final Kanta k in ks) {
          if (k.slip.isNotEmpty) kSlip++;
        }
        int mSlip = 0;
        for (final MaalRow m in ms) {
          if (m.slip.isNotEmpty) mSlip++;
        }
        final List<_Q> all = <_Q>[
          _Q(bi('ચિઠ્ઠીનો ફોટો', 'Chit photo'), cPhoto, cs.length, 25, 'no_photo'),
          _Q(bi('કાંટા સ્લિપનો ફોટો', 'Kanta slip photo'), kSlip, ks.length, 15, 'no_photo'),
          _Q(bi('સાચો ગાડી નંબર (ચિઠ્ઠી)', 'Valid vehicle no. (chits)'), plateChits, cs.length, 12, 'plate_check'),
          _Q(bi('સાચો ગાડી નંબર (કાંટો)', 'Valid vehicle no. (kanta)'), plateKantas, ks.length, 8, 'plate_check'),
          _Q(bi('ખેડૂતનો મોબાઇલ', 'Farmer mobile'), cMobile, cs.length, 15, 'name_check'),
          _Q(bi('દલાલનું નામ', 'Broker name'), cBroker, cs.length, 8, ''),
          _Q(bi('બેગ સંખ્યા', 'Bag count'), cBags, cs.length, 8, 'bag_stats'),
          _Q(bi('ગામનું નામ', 'Village'), cVillage, cs.length, 4, ''),
          _Q(bi('માલ સ્લિપનો ફોટો', 'Maal slip photo'), mSlip, ms.length, 5, 'no_photo'),
        ];
        final List<_Q> qs = all.where((_Q q) => q.total > 0).toList();
        double ws = 0;
        double sc = 0;
        for (final _Q q in qs) {
          ws += q.weight;
          sc += q.weight * q.pct;
        }
        final double score = ws == 0 ? 0 : sc / ws;

        final Map<String, _QP> by = <String, _QP>{};
        for (final Chit c in cs) {
          final _QP x = by.putIfAbsent(c.by, () => _QP(c.by));
          x.n++;
          if (c.photo.isNotEmpty) x.photo++;
          if (digitsOf(c.mobile).length == 10) x.mobile++;
          if (plateOk(c.vkey)) x.plate++;
        }
        final List<_QP> people = by.values.where((_QP x) => x.n >= 5).toList();
        people.sort((_QP a, _QP b) => a.score.compareTo(b.score));

        return <Widget>[
          ScreenHeader(bi('ડેટા ગુણવત્તા', 'Data quality'), sub: p.label),
          statusBanner(),
          RangeBar(sel: _sel, presets: const <int>[2, 3, 4, 5], onChanged: (RangeSel s) => setState(() => _sel = s)),
          const SizedBox(height: 12),
          Panel(
            child: Row(
              children: <Widget>[
                ScoreRing(value: score / 100, center: '${score.round()}', sub: '/100', color: _pctColor(score), size: 110),
                const SizedBox(width: 18),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(score >= 90 ? bi('ખૂબ સરસ', 'Excellent') : (score >= 70 ? bi('સારું, સુધારી શકાય', 'Good, can improve') : bi('સુધારો જરૂરી', 'Needs work')), style: ts(17, w: FontWeight.w800, c: _pctColor(score))),
                      const SizedBox(height: 4),
                      Text('${cs.length} ${bi('ચિઠ્ઠી', 'chits')} · ${ks.length} ${bi('કાંટા', 'kanta')} · ${ms.length} ${bi('માલ', 'maal')}', style: ts(12.5, c: Pal.muted)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Panel(
            title: bi('શું કેટલું ભરાયું', 'What is filled in'),
            child: Column(
              children: <Widget>[
                for (final _Q q in qs)
                  InkWell(
                    borderRadius: BorderRadius.circular(10),
                    onTap: q.route.isEmpty ? null : () => app.go(q.route),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 7),
                      child: ProgressRow(label: q.label, value: q.pct, max: 100, color: _pctColor(q.pct), trailing: '${q.pct.round()}%', sub: q.ok == q.total ? null : '${q.total - q.ok} ${bi('ખૂટે છે', 'missing')}'),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          caption(bi('મજૂર મુજબ (ફોટો + મોબાઇલ + ગાડી નંબર)', 'By labour (photo + mobile + vehicle no.)')),
          if (people.isEmpty) Padding(padding: const EdgeInsets.all(12), child: Text(bi('પૂરતી એન્ટ્રી નથી', 'Not enough entries'), style: ts(13, c: Pal.muted))),
          for (final _QP x in people)
            lineItem(
              icon: 'user',
              tone: x.score >= 90 ? 'green' : (x.score >= 70 ? 'amber' : 'rose'),
              title: majurName(live.names, x.id),
              sub: '${x.n} ${bi('ચિઠ્ઠી', 'chits')} · ${bi('ફોટો', 'photo')} ${(x.photo / x.n * 100).round()}% · ${bi('મોબાઇલ', 'mobile')} ${(x.mobile / x.n * 100).round()}% · ${bi('નંબર', 'plate')} ${(x.plate / x.n * 100).round()}%',
              trailing: '${x.score.round()}',
              trailingColor: _pctColor(x.score),
            ),
        ];
      },
    );
  }
}

// ================================================================= bag stats
/// KG per bag: spots chits whose bag count and weight do not fit.
class BagStatsScreen extends StatefulWidget {
  const BagStatsScreen({super.key});

  @override
  State<BagStatsScreen> createState() => _BagStatsState();
}

class _FarmBag {
  final String label;
  double kg = 0;
  int bags = 0;
  int n = 0;
  _FarmBag(this.label);
  double get per => bags == 0 ? 0 : kg / bags;
}

class _BagStatsState extends State<BagStatsScreen> {
  RangeSel _sel = RangeSel(3);

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 800,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = _sel.period;
        final List<Chit> cs = live.chits.where((Chit c) => p.has(c.at)).toList();
        final List<Chit> wb = cs.where((Chit c) => c.bags > 0 && c.cmpKg > 0).toList();
        final List<double> per = <double>[for (final Chit c in wb) c.cmpKg / c.bags];
        final double med = median(per);
        final double cover = cs.isEmpty ? 0 : wb.length / cs.length * 100;
        final List<double> bins = List<double>.filled(17, 0);
        for (final double v in per) {
          int i = ((v - 20) / 5).floor();
          if (i < 0) i = 0;
          if (i > 16) i = 16;
          bins[i] += 1;
        }
        final List<Chit> odd = med <= 0 ? <Chit>[] : wb.where((Chit c) => ((c.cmpKg / c.bags) - med).abs() / med > 0.25).toList();
        odd.sort((Chit a, Chit b) => ((b.cmpKg / b.bags) - med).abs().compareTo(((a.cmpKg / a.bags) - med).abs()));
        final Map<String, _FarmBag> fm = <String, _FarmBag>{};
        for (final Chit c in wb) {
          final String k = nameKey(c.farmer);
          if (k.isEmpty) continue;
          final _FarmBag f = fm.putIfAbsent(k, () => _FarmBag(c.farmer));
          f.kg += c.cmpKg;
          f.bags += c.bags;
          f.n++;
        }
        final List<_FarmBag> fl = fm.values.where((_FarmBag f) => f.n >= 2).toList();
        fl.sort((_FarmBag a, _FarmBag b) => a.per.compareTo(b.per));

        return <Widget>[
          ScreenHeader(bi('બેગનું વજન', 'Bag weights'), sub: p.label),
          statusBanner(),
          RangeBar(sel: _sel, presets: const <int>[2, 3, 4, 5], onChanged: (RangeSel s) => setState(() => _sel = s)),
          const SizedBox(height: 12),
          metricGrid(ctx, <Widget>[
            MetricTile(label: bi('બેગ ભરેલી ચિઠ્ઠી', 'Chits with bags'), value: '${cover.round()}%', icon: 'bag', tone: cover >= 80 ? 'green' : 'amber', sub: '${wb.length} / ${cs.length}'),
            MetricTile(label: bi('વચલું વજન / બેગ', 'Median KG / bag'), value: med <= 0 ? '—' : med.toStringAsFixed(1), icon: 'weight', tone: 'blue', unit: 'KG'),
            MetricTile(label: bi('અલગ પડતી', 'Odd ones'), value: '${odd.length}', icon: 'warn', tone: odd.isEmpty ? 'green' : 'rose', sub: bi('25% થી વધુ ફરક', 'more than 25% off')),
          ], pcCols: 3),
          const SizedBox(height: 12),
          if (wb.isEmpty)
            EmptyBox(icon: 'bag', title: bi('બેગ સંખ્યા ભરેલી ચિઠ્ઠી નથી', 'No chit has a bag count'), sub: bi('ચિઠ્ઠીમાં "બેગ" ખાનું ભરો તો અહીં વિશ્લેષણ દેખાશે', 'Fill the "Bags" field on chits to see the analysis'))
          else ...<Widget>[
            Panel(
              title: bi('KG / બેગ નું વિતરણ', 'KG per bag spread'),
              sub: bi('20 KG થી શરૂ, દરેક સ્તંભ 5 KG', 'from 20 KG, each bar 5 KG'),
              child: BarChartX(
                values: bins,
                labels: <String>[for (int i = 0; i < 17; i++) (i % 2 == 0 ? '${20 + i * 5}' : '')],
                color: Pal.info,
                axisFmt: (double v) => v.round().toString(),
                valueFmt: (double v) => v.round().toString(),
                height: 170,
              ),
            ),
            if (odd.isNotEmpty) ...<Widget>[
              caption(bi('વજન / બેગ અજુગતું', 'Unusual KG per bag')),
              for (final Chit c in odd.take(8)) chitTile(ctx, c),
            ],
            if (fl.length >= 2) ...<Widget>[
              caption(bi('સૌથી હલકી બેગ (ખેડૂત મુજબ)', 'Lightest bags (by farmer)')),
              for (final _FarmBag f in fl.take(4)) lineItem(icon: 'agri', tone: 'amber', title: f.label, sub: '${f.n} ${bi('ચિઠ્ઠી', 'chits')} · ${f.bags} ${bi('બેગ', 'bags')}', trailing: '${f.per.toStringAsFixed(1)} KG'),
              caption(bi('સૌથી ભારે બેગ', 'Heaviest bags')),
              for (final _FarmBag f in fl.reversed.take(4)) lineItem(icon: 'agri', tone: 'green', title: f.label, sub: '${f.n} ${bi('ચિઠ્ઠી', 'chits')} · ${f.bags} ${bi('બેગ', 'bags')}', trailing: '${f.per.toStringAsFixed(1)} KG'),
            ],
          ],
        ];
      },
    );
  }
}

// ================================================================ deductions
class _DG {
  final String key;
  final String label;
  int n = 0;
  double gross = 0;
  double ded = 0;
  int zero = 0;
  _DG(this.key, this.label);
  double get pct => gross <= 0 ? 0 : ded / gross * 100;
}

/// Bardan + kardo taken off the gross weight: who takes how much.
class DeductionsScreen extends StatefulWidget {
  const DeductionsScreen({super.key});

  @override
  State<DeductionsScreen> createState() => _DeductionsState();
}

class _DeductionsState extends State<DeductionsScreen> {
  RangeSel _sel = RangeSel(3);
  int _dim = 0;
  static const List<Dim> _dd = <Dim>[Dim.majur, Dim.broker, Dim.farmer, Dim.village];

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 800,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = _sel.period;
        final Dim dim = _dd[_dim];
        final List<Chit> cs = live.chits.where((Chit c) => p.has(c.at) && c.gross > 0).toList();
        double gross = 0;
        double ded = 0;
        int zero = 0;
        double bardan = 0;
        int bagN = 0;
        for (final Chit c in cs) {
          gross += c.gross;
          ded += c.bardan + c.kardo;
          if (c.bardan + c.kardo <= 0) zero++;
          if (c.bags > 0) {
            bardan += c.bardan;
            bagN += c.bags;
          }
        }
        final double overall = gross <= 0 ? 0 : ded / gross * 100;
        final Map<String, _DG> m = <String, _DG>{};
        for (final Chit c in cs) {
          final String k = dimKey(dim, c);
          if (k.isEmpty) continue;
          final _DG g = m.putIfAbsent(k, () => _DG(k, dimLabel(dim, c)));
          g.n++;
          g.gross += c.gross;
          g.ded += c.bardan + c.kardo;
          if (c.bardan + c.kardo <= 0) g.zero++;
        }
        final List<_DG> list = m.values.where((_DG g) => g.n >= 3).toList();
        list.sort((_DG a, _DG b) => b.pct.compareTo(a.pct));
        bool flag(_DG g) => g.pct > overall * 1.5 && g.pct - overall > 0.3;

        return <Widget>[
          ScreenHeader(bi('બારદાન / કરદો', 'Bardan / kardo'), sub: p.label),
          statusBanner(),
          RangeBar(sel: _sel, presets: const <int>[2, 3, 4, 5], onChanged: (RangeSel s) => setState(() => _sel = s)),
          const SizedBox(height: 10),
          ChipRow(
            labels: <String>[bi('મજૂર', 'Labour'), bi('દલાલ', 'Broker'), bi('ખેડૂત', 'Farmer'), bi('ગામ', 'Village')],
            index: _dim,
            onChanged: (int i) => setState(() => _dim = i),
          ),
          const SizedBox(height: 12),
          metricGrid(ctx, <Widget>[
            MetricTile(label: bi('કુલ કપાત', 'Total deduction'), value: kgShort(ded), icon: 'down', tone: 'amber', sub: '${overall.toStringAsFixed(2)}% ${bi('ગ્રોસનું', 'of gross')}'),
            MetricTile(label: bi('કપાત વગરની', 'No deduction'), value: cs.isEmpty ? '—' : '${(zero / cs.length * 100).round()}%', icon: 'check', tone: 'slate', sub: '$zero ${bi('ચિઠ્ઠી', 'chits')}'),
            MetricTile(label: bi('બારદાન / બેગ', 'Bardan per bag'), value: bagN == 0 ? '—' : (bardan / bagN).toStringAsFixed(2), icon: 'bag', tone: 'blue', unit: 'KG'),
          ], pcCols: 3),
          const SizedBox(height: 12),
          if (list.isEmpty) EmptyBox(icon: 'down', title: bi('પૂરતી ચિઠ્ઠી નથી', 'Not enough chits')),
          for (final _DG g in list.take(40))
            lineItem(
              icon: dimIcon(dim),
              tone: flag(g) ? 'rose' : 'teal',
              title: g.label,
              sub: '${g.n} ${bi('ચિઠ્ઠી', 'chits')} · ${bi('કપાત', 'deducted')} ${grp(g.ded)} KG · ${bi('કપાત વગરની', 'none')} ${(g.zero / g.n * 100).round()}%',
              trailing: '${g.pct.toStringAsFixed(2)}%',
              trailingColor: flag(g) ? Pal.bad : null,
              trailingSub: flag(g) ? bi('વધારે', 'high') : null,
              onTap: dim == Dim.majur ? null : () => openParty(PartyRef(dim, g.key, g.label)),
            ),
        ];
      },
    );
  }
}

// ==================================================================== digits
/// Last-digit and repeated-weight check: made-up weights have a pattern.
class DigitsScreen extends StatefulWidget {
  const DigitsScreen({super.key});

  @override
  State<DigitsScreen> createState() => _DigitsState();
}

class _DigitsState extends State<DigitsScreen> {
  RangeSel _sel = RangeSel(3);
  int _src = 0;

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 800,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = _sel.period;
        final List<Chit> cs = live.chits.where((Chit c) => p.has(c.at) && c.gross > 0).toList();
        final List<Kanta> ks = live.kantas.where((Kanta k) => p.has(k.at) && k.kg > 0).toList();
        final List<double> vals = _src == 0 ? <double>[for (final Chit c in cs) c.gross] : <double>[for (final Kanta k in ks) k.kg];
        final List<int> dc = List<int>.filled(10, 0);
        int dec = 0;
        for (final double v in vals) {
          dc[v.round() % 10]++;
          if (((v * 10).round() % 10) != 0) dec++;
        }
        final int n = vals.length;
        final List<double> share = <double>[for (int i = 0; i < 10; i++) n == 0 ? 0.0 : dc[i] / n * 100];
        final double five = n == 0 ? 0 : (dc[0] + dc[5]) / n * 100;
        int best = 0;
        for (int i = 1; i < 10; i++) {
          if (share[i] > share[best]) best = i;
        }

        // per labour: share of weights ending in 0 or 5
        final Map<String, List<int>> pm = <String, List<int>>{};
        if (_src == 0) {
          for (final Chit c in cs) {
            final List<int> l = pm.putIfAbsent(c.by, () => <int>[0, 0]);
            l[0]++;
            final int d = c.gross.round() % 10;
            if (d == 0 || d == 5) l[1]++;
          }
        } else {
          for (final Kanta k in ks) {
            final List<int> l = pm.putIfAbsent(k.by, () => <int>[0, 0]);
            l[0]++;
            final int d = k.kg.round() % 10;
            if (d == 0 || d == 5) l[1]++;
          }
        }
        final List<MapEntry<String, List<int>>> pl = pm.entries.where((MapEntry<String, List<int>> e) => e.value[0] >= 8).toList();
        pl.sort((MapEntry<String, List<int>> a, MapEntry<String, List<int>> b) => (b.value[1] / b.value[0]).compareTo(a.value[1] / a.value[0]));

        // repeated weights
        final Map<int, List<Chit>> rep = <int, List<Chit>>{};
        if (_src == 0) {
          for (final Chit c in cs) {
            rep.putIfAbsent((c.gross * 10).round(), () => <Chit>[]).add(c);
          }
        }
        final List<MapEntry<int, List<Chit>>> rl = rep.entries.where((MapEntry<int, List<Chit>> e) => e.value.length >= 3).toList();
        rl.sort((MapEntry<int, List<Chit>> a, MapEntry<int, List<Chit>> b) => b.value.length.compareTo(a.value.length));

        return <Widget>[
          ScreenHeader(bi('અંકની તપાસ', 'Digit check'), sub: p.label),
          statusBanner(),
          RangeBar(sel: _sel, presets: const <int>[2, 3, 4, 5], onChanged: (RangeSel s) => setState(() => _sel = s)),
          const SizedBox(height: 10),
          ChipRow(labels: <String>[bi('ચિઠ્ઠી વજન', 'Chit weights'), bi('કાંટા વજન', 'Kanta weights')], index: _src, onChanged: (int i) => setState(() => _src = i)),
          const SizedBox(height: 12),
          if (n < 30) noteBox('info', 'blue', bi('ઓછામાં ઓછા 30 વજન હોય તો જ આ તપાસ ભરોસાપાત્ર છે (હાલ $n)', 'This check is reliable only with 30+ weights (now $n)')),
          Panel(
            title: bi('છેલ્લો અંક (સામાન્ય રીતે દરેક ~10%)', 'Last digit (normally ~10% each)'),
            sub: '$n ${bi('વજન', 'weights')} · ${bi('0 કે 5 પર પૂરા', 'ending in 0 or 5')}: ${five.toStringAsFixed(0)}% (${bi('સામાન્ય', 'normal')} ~20%)',
            child: BarChartX(
              values: share,
              labels: <String>[for (int i = 0; i < 10; i++) '$i'],
              color: Pal.info,
              highlight: n == 0 ? null : best,
              axisFmt: (double v) => '${v.round()}%',
              valueFmt: (double v) => '${v.round()}%',
              height: 190,
            ),
          ),
          const SizedBox(height: 12),
          if (n >= 30 && five > 35) noteBox('warn', 'rose', bi('ઘણા વજન 0 કે 5 પર પૂરા થાય છે - ગોળ વજન લખાતા હોઈ શકે', 'Too many weights end in 0 or 5 - they may be rounded by hand')),
          if (n >= 30 && dec == 0) noteBox('info', 'amber', bi('એક પણ વજનમાં દશાંશ નથી', 'No weight has a decimal')),
          caption(bi('0/5 પર પૂરા થતા વજન - મજૂર મુજબ', 'Weights ending in 0/5 - by labour')),
          for (final MapEntry<String, List<int>> e in pl.take(10))
            lineItem(
              icon: 'user',
              tone: e.value[1] / e.value[0] > 0.4 ? 'rose' : 'teal',
              title: majurName(live.names, e.key),
              sub: '${e.value[0]} ${bi('વજન', 'weights')}',
              trailing: '${(e.value[1] / e.value[0] * 100).round()}%',
              trailingColor: e.value[1] / e.value[0] > 0.4 ? Pal.bad : null,
            ),
          if (_src == 0) ...<Widget>[
            const SizedBox(height: 6),
            caption(bi('એક જ વજન વારંવાર', 'Same weight again and again')),
            if (rl.isEmpty) Padding(padding: const EdgeInsets.all(12), child: Text(bi('કોઈ વજન 3 વાર કે વધુ આવ્યું નથી', 'No weight repeats 3 or more times'), style: ts(13, c: Pal.muted))),
            for (final MapEntry<int, List<Chit>> e in rl.take(8))
              lineItem(
                icon: 'repeat',
                tone: 'amber',
                title: '${grp(e.key / 10, dec: 1)} KG',
                sub: <String>{for (final Chit c in e.value) c.farmer}.take(3).join(', '),
                trailing: '${e.value.length}×',
                onTap: () => openPanel(ctx, title: '${grp(e.key / 10, dec: 1)} KG', sub: '${e.value.length}×', child: Column(children: <Widget>[for (final Chit c in e.value.take(20)) chitTile(ctx, c)])),
              ),
          ],
        ];
      },
    );
  }
}

// =============================================================== plate check
class _Pl {
  final String vk;
  String label;
  int n = 0;
  DateTime last;
  _Pl(this.vk, this.label, this.last);
}

/// Wrong-looking vehicle numbers and numbers that look like the same truck.
class PlateCheckScreen extends StatefulWidget {
  const PlateCheckScreen({super.key});

  @override
  State<PlateCheckScreen> createState() => _PlateCheckState();
}

class _PlateCheckState extends State<PlateCheckScreen> {
  int _tab = 0;

  void _pair(BuildContext context, _Pl a, _Pl b) {
    openPanel(
      context,
      title: '${a.label} ≈ ${b.label}',
      sub: bi('એક જ ગાડી હોઈ શકે?', 'Could this be the same truck?'),
      width: 460,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          InfoRow(a.label, '${a.n} ${bi('વખત', 'times')} · ${dm(a.last)}'),
          InfoRow(b.label, '${b.n} ${bi('વખત', 'times')} · ${dm(b.last)}'),
          const SizedBox(height: 12),
          Btn(bi('${a.label} ની પ્રોફાઇલ', 'Profile of ${a.label}'), icon: 'truck', kind: BtnKind.outline, expand: true, onTap: () {
            Navigator.of(context).pop();
            openParty(PartyRef(Dim.vehicle, a.vk, a.label));
          }),
          const SizedBox(height: 8),
          Btn(bi('${b.label} ની પ્રોફાઇલ', 'Profile of ${b.label}'), icon: 'truck', kind: BtnKind.outline, expand: true, onTap: () {
            Navigator.of(context).pop();
            openParty(PartyRef(Dim.vehicle, b.vk, b.label));
          }),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 800,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Map<String, _Pl> m = <String, _Pl>{};
        void see(String vk, String label, DateTime at) {
          if (vk.isEmpty) return;
          _Pl? x = m[vk];
          if (x == null) {
            x = _Pl(vk, label, at);
            m[vk] = x;
          }
          x.n++;
          if (at.isAfter(x.last)) x.last = at;
        }

        for (final Chit c in live.chits) {
          see(c.vkey, c.vehicle, c.at);
        }
        for (final Kanta k in live.kantas) {
          see(k.vkey, k.vehicle, k.at);
        }
        for (final MaalRow r in live.maals) {
          see(r.vkey, r.vehicle, r.at);
        }
        final List<_Pl> all = m.values.toList();
        final List<_Pl> bad = all.where((_Pl x) => !plateOk(x.vk)).toList();
        bad.sort((_Pl a, _Pl b) => b.n.compareTo(a.n));
        final List<List<_Pl>> pairs = <List<_Pl>>[];
        for (int i = 0; i < all.length; i++) {
          for (int j = i + 1; j < all.length; j++) {
            final _Pl a = all[i];
            final _Pl b = all[j];
            if (!nearStr(a.vk, b.vk)) continue;
            final int lo = math.min(a.n, b.n);
            final int hi = math.max(a.n, b.n);
            final bool sus = !plateOk(a.vk) || !plateOk(b.vk) || (lo <= 2 && hi >= 4);
            if (sus) pairs.add(<_Pl>[a, b]);
            if (pairs.length >= 60) break;
          }
          if (pairs.length >= 60) break;
        }
        pairs.sort((List<_Pl> a, List<_Pl> b) => (b[0].n + b[1].n).compareTo(a[0].n + a[1].n));

        return <Widget>[
          ScreenHeader(bi('ગાડી નંબર તપાસ', 'Vehicle number check'), sub: '${all.length} ${bi('અલગ નંબર', 'distinct numbers')}'),
          statusBanner(),
          ChipRow(
            labels: <String>['${bi('ખોટા દેખાતા', 'Wrong-looking')} (${bad.length})', '${bi('એક જેવા', 'Look alike')} (${pairs.length})'],
            index: _tab,
            onChanged: (int i) => setState(() => _tab = i),
          ),
          const SizedBox(height: 12),
          if (_tab == 0) ...<Widget>[
            noteBox('info', 'blue', bi('સાચો નંબર: 2 અક્ષર + 1-2 અંક + 0-3 અક્ષર + 1-4 અંક (જેમ કે GJ12CT5828)', 'Valid format: 2 letters + 1-2 digits + 0-3 letters + 1-4 digits (e.g. GJ12CT5828)')),
            if (bad.isEmpty) noteBox('check', 'green', bi('બધા નંબર સાચા ફોર્મેટમાં છે', 'All numbers look valid')),
            for (final _Pl x in bad.take(50))
              lineItem(icon: 'truck', tone: 'rose', title: x.label, sub: '${x.n} ${bi('વખત', 'times')} · ${bi('છેલ્લે', 'last')} ${dm(x.last)}', onTap: () => openParty(PartyRef(Dim.vehicle, x.vk, x.label))),
          ] else ...<Widget>[
            noteBox('info', 'blue', bi('એક અક્ષરના ફરકવાળા નંબર - એક ઓછો વપરાયેલો હોય તો ભૂલ હોઈ શકે', 'Numbers one character apart - if one is rarely used it may be a typo')),
            if (pairs.isEmpty) noteBox('check', 'green', bi('કોઈ શંકાસ્પદ જોડી નથી', 'No suspicious pair')),
            for (final List<_Pl> pr in pairs.take(40))
              lineItem(icon: 'swap', tone: 'amber', title: '${pr[0].label}  ≈  ${pr[1].label}', sub: '${pr[0].n} / ${pr[1].n} ${bi('વખત', 'times')}', onTap: () => _pair(ctx, pr[0], pr[1])),
          ],
        ];
      },
    );
  }
}

// =============================================================== name check
class _FN {
  final String key;
  String label;
  String village = '';
  int n = 0;
  double kg = 0;
  _FN(this.key, this.label);
}

bool _tokenSubset(String a, String b) {
  final Set<String> ta = a.split(' ').where((String s) => s.isNotEmpty).toSet();
  final Set<String> tb = b.split(' ').where((String s) => s.isNotEmpty).toSet();
  if (ta.isEmpty || tb.isEmpty || ta.length == tb.length) return false;
  final Set<String> s = ta.length < tb.length ? ta : tb;
  final Set<String> l = ta.length < tb.length ? tb : ta;
  if (s.length < 2) return false;
  return l.containsAll(s);
}

/// Same person written two ways, one mobile for two names, wrong mobiles.
class NameCheckScreen extends StatefulWidget {
  const NameCheckScreen({super.key});

  @override
  State<NameCheckScreen> createState() => _NameCheckState();
}

class _NameCheckState extends State<NameCheckScreen> {
  int _tab = 0;

  void _open(BuildContext context, String title, List<_FN> l) {
    openPanel(
      context,
      title: title,
      width: 460,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          for (final _FN f in l) ...<Widget>[
            InfoRow(f.label, '${f.n} ${bi('ચિઠ્ઠી', 'chits')} · ${kgShort(f.kg)}'),
            Btn(bi('${f.label} ની પ્રોફાઇલ', 'Profile of ${f.label}'), icon: 'agri', kind: BtnKind.outline, dense: true, expand: true, onTap: () {
              Navigator.of(context).pop();
              openParty(PartyRef(Dim.farmer, f.key, f.label));
            }),
            const SizedBox(height: 10),
          ],
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 800,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Map<String, _FN> fm = <String, _FN>{};
        final Map<String, Set<String>> byMobile = <String, Set<String>>{};
        final Map<String, int> badMobile = <String, int>{};
        final Map<String, String> badLabel = <String, String>{};
        for (final Chit c in live.chits) {
          final String k = nameKey(c.farmer);
          if (k.isEmpty) continue;
          final _FN f = fm.putIfAbsent(k, () => _FN(k, c.farmer));
          f.n++;
          f.kg += c.cmpKg;
          if (c.village.isNotEmpty) f.village = c.village;
          final String mob = digitsOf(c.mobile);
          if (mob.isNotEmpty) {
            if (mob.length == 10 && mob.codeUnitAt(0) >= 54) {
              byMobile.putIfAbsent(mob, () => <String>{}).add(k);
            } else {
              badMobile[k] = (badMobile[k] ?? 0) + 1;
              badLabel[k] = c.mobile;
            }
          }
        }
        final List<MapEntry<String, Set<String>>> shared = byMobile.entries.where((MapEntry<String, Set<String>> e) => e.value.length >= 2).toList();
        shared.sort((MapEntry<String, Set<String>> a, MapEntry<String, Set<String>> b) => b.value.length.compareTo(a.value.length));

        final Map<String, List<_FN>> byVillage = <String, List<_FN>>{};
        for (final _FN f in fm.values) {
          if (f.village.isEmpty) continue;
          byVillage.putIfAbsent(nameKey(f.village), () => <_FN>[]).add(f);
        }
        final List<List<_FN>> similar = <List<_FN>>[];
        for (final List<_FN> l in byVillage.values) {
          for (int i = 0; i < l.length; i++) {
            for (int j = i + 1; j < l.length; j++) {
              final String a = l[i].key;
              final String b = l[j].key;
              final bool hit = (a.length >= 4 && b.length >= 4 && nearStr(a, b)) || _tokenSubset(a, b);
              if (hit) similar.add(<_FN>[l[i], l[j]]);
            }
          }
        }
        similar.sort((List<_FN> a, List<_FN> b) => (b[0].n + b[1].n).compareTo(a[0].n + a[1].n));
        final List<String> badKeys = badMobile.keys.toList();
        badKeys.sort((String a, String b) => (badMobile[b] ?? 0).compareTo(badMobile[a] ?? 0));

        final List<Widget> list = <Widget>[];
        if (_tab == 0) {
          if (shared.isEmpty) list.add(noteBox('check', 'green', bi('એક મોબાઇલ પર બે નામ નથી', 'No mobile is used for two names')));
          for (final MapEntry<String, Set<String>> e in shared.take(40)) {
            final List<_FN> l = <_FN>[for (final String k in e.value) if (fm[k] != null) fm[k]!];
            list.add(lineItem(icon: 'phone', tone: 'amber', title: e.key, sub: l.map((_FN f) => f.label).join('  ·  '), trailing: '${l.length}', onTap: () => _open(ctx, e.key, l)));
          }
        } else if (_tab == 1) {
          if (similar.isEmpty) list.add(noteBox('check', 'green', bi('મળતા નામ નથી', 'No look-alike names')));
          for (final List<_FN> pr in similar.take(40)) {
            list.add(lineItem(icon: 'users', tone: 'amber', title: '${pr[0].label}  ≈  ${pr[1].label}', sub: '${pr[0].village} · ${pr[0].n} / ${pr[1].n} ${bi('ચિઠ્ઠી', 'chits')}', onTap: () => _open(ctx, '${pr[0].label} ≈ ${pr[1].label}', pr)));
          }
        } else {
          if (badKeys.isEmpty) list.add(noteBox('check', 'green', bi('બધા મોબાઇલ સાચા દેખાય છે', 'All mobiles look valid')));
          for (final String k in badKeys.take(40)) {
            final _FN? f = fm[k];
            if (f == null) continue;
            list.add(lineItem(icon: 'phone', tone: 'rose', title: f.label, sub: '${bi('લખેલો', 'written')}: ${badLabel[k] ?? ''}', trailing: '${badMobile[k]}×', onTap: () => openParty(PartyRef(Dim.farmer, f.key, f.label))));
          }
        }

        return <Widget>[
          ScreenHeader(bi('નામ / મોબાઇલ તપાસ', 'Name / mobile check'), sub: '${fm.length} ${bi('ખેડૂત', 'farmers')}'),
          statusBanner(),
          ChipRow(
            labels: <String>['${bi('એક મોબાઇલ', 'Shared mobile')} (${shared.length})', '${bi('મળતા નામ', 'Look-alike')} (${similar.length})', '${bi('ખોટા મોબાઇલ', 'Bad mobile')} (${badKeys.length})'],
            index: _tab,
            onChanged: (int i) => setState(() => _tab = i),
          ),
          const SizedBox(height: 12),
          noteBox('info', 'blue', _tab == 0
              ? bi('એક જ મોબાઇલ બે નામે - એક જ ખેડૂતના નામની જોડણી અલગ હશે', 'One mobile under two names - maybe one farmer spelled twice')
              : (_tab == 1 ? bi('એક જ ગામમાં લગભગ સરખા નામ - ખેડૂતનો હિસાબ બે ભાગમાં વહેંચાઈ શકે', 'Almost the same name in one village - the farmer\'s totals may be split') : bi('10 અંકનો અને 6-9 થી શરૂ થતો મોબાઇલ જ સાચો ગણાય', 'A valid mobile has 10 digits and starts with 6-9'))),
          ...list,
        ];
      },
    );
  }
}

// ================================================================= chit gaps
class _Book {
  final String by;
  final List<int> nums = <int>[];
  int dup = 0;
  int text = 0;
  final List<int> missing = <int>[];
  _Book(this.by);
}

/// Chit numbers that are missing in each person's running series.
class ChitGapsScreen extends StatefulWidget {
  const ChitGapsScreen({super.key});

  @override
  State<ChitGapsScreen> createState() => _ChitGapsState();
}

class _ChitGapsState extends State<ChitGapsScreen> {
  RangeSel _sel = RangeSel(3);

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 800,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = _sel.period;
        final Map<String, _Book> books = <String, _Book>{};
        final Map<String, Set<int>> seen = <String, Set<int>>{};
        for (final Chit c in live.chits) {
          if (!p.has(c.at)) continue;
          final _Book b = books.putIfAbsent(c.by, () => _Book(c.by));
          final int? n = int.tryParse(c.no.trim());
          if (n == null) {
            b.text++;
            continue;
          }
          final Set<int> s = seen.putIfAbsent(c.by, () => <int>{});
          if (!s.add(n)) {
            b.dup++;
          } else {
            b.nums.add(n);
          }
        }
        int totalMissing = 0;
        final List<_Book> list = <_Book>[];
        for (final _Book b in books.values) {
          if (b.nums.isEmpty) continue;
          b.nums.sort();
          for (int i = 1; i < b.nums.length; i++) {
            final int gap = b.nums[i] - b.nums[i - 1];
            if (gap >= 2 && gap <= 60) {
              for (int x = b.nums[i - 1] + 1; x < b.nums[i]; x++) {
                b.missing.add(x);
              }
            }
          }
          totalMissing += b.missing.length;
          list.add(b);
        }
        list.sort((_Book a, _Book b) => b.missing.length.compareTo(a.missing.length));

        return <Widget>[
          ScreenHeader(bi('ચિઠ્ઠી નંબર શ્રેણી', 'Chit number series'), sub: p.label),
          statusBanner(),
          RangeBar(sel: _sel, presets: const <int>[2, 3, 4, 5], onChanged: (RangeSel s) => setState(() => _sel = s)),
          const SizedBox(height: 12),
          noteBox(totalMissing == 0 ? 'check' : 'warn', totalMissing == 0 ? 'green' : 'amber', totalMissing == 0 ? bi('કોઈ નંબર ખૂટતો નથી', 'No chit number is missing') : bi('કુલ $totalMissing નંબર ખૂટે છે - ચિઠ્ઠી બની નથી કે નોંધાઈ નથી?', '$totalMissing numbers are missing - not made or not entered?')),
          if (list.isEmpty) EmptyBox(icon: 'receipt', title: bi('આ સમયમાં ચિઠ્ઠી નથી', 'No chits in this period')),
          for (final _Book b in list)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Panel(
                title: majurName(live.names, b.by),
                sub: '${b.nums.first} - ${b.nums.last} · ${b.nums.length} ${bi('ચિઠ્ઠી', 'chits')}',
                action: Pill(b.missing.isEmpty ? bi('પૂરું', 'complete') : '${b.missing.length} ${bi('ખૂટે', 'missing')}', tone: b.missing.isEmpty ? 'green' : 'amber', small: true),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    if (b.missing.isNotEmpty) Text(rangesText(b.missing), style: ts(14, w: FontWeight.w700, c: Pal.warn, tab: true)),
                    if (b.dup > 0) Padding(padding: const EdgeInsets.only(top: 6), child: Text('${b.dup} ${bi('નંબર બે વાર લખાયા', 'numbers repeated')}', style: ts(12.5, c: Pal.bad))),
                    if (b.text > 0) Padding(padding: const EdgeInsets.only(top: 6), child: Text('${b.text} ${bi('નંબર અંક વગરના', 'numbers are not digits')}', style: ts(12.5, c: Pal.muted))),
                    if (b.missing.isNotEmpty) ...<Widget>[
                      const SizedBox(height: 8),
                      Btn(bi('ખૂટતા નંબર કૉપિ', 'Copy missing numbers'), icon: 'copy', kind: BtnKind.ghost, dense: true, onTap: () => copyText(rangesText(b.missing), msg: bi('કૉપિ થયું', 'Copied'))),
                    ],
                  ],
                ),
              ),
            ),
        ];
      },
    );
  }
}

// ==================================================================== RST map
/// Every RST number as a small square: present, missing or repeated.
class RstMapScreen extends StatelessWidget {
  const RstMapScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 800,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Map<int, List<Kanta>> by = <int, List<Kanta>>{};
        int text = 0;
        for (final Kanta k in live.kantas) {
          final int? n = int.tryParse(k.rst.trim());
          if (n == null) {
            text++;
            continue;
          }
          by.putIfAbsent(n, () => <Kanta>[]).add(k);
        }
        if (by.isEmpty) {
          return <Widget>[
            ScreenHeader(bi('RST નકશો', 'RST map')),
            statusBanner(),
            EmptyBox(icon: 'scale', title: bi('RST નંબરવાળી કાંટા એન્ટ્રી નથી', 'No kanta entry with an RST number')),
          ];
        }
        final List<int> ns = by.keys.toList()..sort();
        int hi = ns.last;
        int lo = ns.first;
        if (hi - lo > 599) lo = hi - 599;
        int present = 0;
        int dup = 0;
        final List<int> missing = <int>[];
        final List<Widget> cells = <Widget>[];
        for (int n = lo; n <= hi; n++) {
          final List<Kanta>? l = by[n];
          Color c;
          VoidCallback tap;
          if (l == null) {
            c = Pal.bad;
            missing.add(n);
            tap = () => app.toast('RST $n ${bi('નોંધાયો નથી', 'is missing')}');
          } else if (l.length > 1) {
            c = Pal.amber;
            dup++;
            present++;
            tap = () => showKantaDetail(ctx, l.first);
          } else {
            c = Pal.ok;
            present++;
            tap = () => showKantaDetail(ctx, l.first);
          }
          cells.add(InkWell(
            onTap: tap,
            child: Tooltip(
              message: 'RST $n',
              child: Container(
                width: 15,
                height: 15,
                decoration: BoxDecoration(color: c, borderRadius: BorderRadius.circular(3)),
              ),
            ),
          ));
        }
        return <Widget>[
          ScreenHeader(bi('RST નકશો', 'RST map'), sub: '$lo - $hi'),
          statusBanner(),
          metricGrid(ctx, <Widget>[
            MetricTile(label: bi('નોંધાયેલા', 'Present'), value: '$present', icon: 'check', tone: 'green'),
            MetricTile(label: bi('ખૂટતા', 'Missing'), value: '${missing.length}', icon: 'warn', tone: missing.isEmpty ? 'green' : 'rose'),
            MetricTile(label: bi('બે વાર', 'Repeated'), value: '$dup', icon: 'copy', tone: dup == 0 ? 'green' : 'amber'),
          ], pcCols: 3),
          const SizedBox(height: 12),
          Panel(
            title: bi('દરેક ચોરસ = એક RST', 'Each square = one RST'),
            sub: bi('લીલો = છે · લાલ = ખૂટે છે · પીળો = બે વાર', 'green = present · red = missing · amber = repeated'),
            child: Wrap(spacing: 3, runSpacing: 3, children: cells),
          ),
          const SizedBox(height: 12),
          if (missing.isNotEmpty) ...<Widget>[
            Panel(
              title: bi('ખૂટતા RST', 'Missing RST'),
              action: IconBtn('copy', size: 38, onTap: () => copyText(rangesText(missing), msg: bi('કૉપિ થયું', 'Copied'))),
              child: Text(rangesText(missing), style: ts(13.5, w: FontWeight.w700, c: Pal.bad, tab: true)),
            ),
          ],
          if (text > 0) Padding(padding: const EdgeInsets.only(top: 10), child: Text('$text ${bi('એન્ટ્રીમાં RST અંક વગરનો છે', 'entries have a non-numeric RST')}', style: ts(12, c: Pal.muted))),
        ];
      },
    );
  }
}

// ================================================================ late entry
/// Chits that were written after the truck was already weighed.
class LateEntryScreen extends StatefulWidget {
  const LateEntryScreen({super.key});

  @override
  State<LateEntryScreen> createState() => _LateEntryState();
}

class _LateEntryState extends State<LateEntryScreen> {
  RangeSel _sel = RangeSel(3);

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 800,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = _sel.period;
        final List<Trip> withKanta = live.trips.where((Trip t) => p.has(t.at) && t.kanta != null && t.chits.isNotEmpty).toList();
        final List<MapEntry<Trip, double>> lateList = <MapEntry<Trip, double>>[];
        final Map<String, int> who = <String, int>{};
        for (final Trip t in withKanta) {
          final DateTime kt = t.kanta!.at;
          double worst = 0;
          for (final Chit c in t.chits) {
            if (c.at.isAfter(kt)) {
              final double h = c.at.difference(kt).inMinutes / 60.0;
              if (h > worst) worst = h;
              who[c.by] = (who[c.by] ?? 0) + 1;
            }
          }
          if (worst > 0.25) lateList.add(MapEntry<Trip, double>(t, worst));
        }
        lateList.sort((MapEntry<Trip, double> a, MapEntry<Trip, double> b) => b.value.compareTo(a.value));
        final List<MapEntry<String, int>> wl = who.entries.toList();
        wl.sort((MapEntry<String, int> a, MapEntry<String, int> b) => b.value.compareTo(a.value));
        return <Widget>[
          ScreenHeader(bi('મોડી નોંધાયેલી ચિઠ્ઠી', 'Late chit entries'), sub: p.label),
          statusBanner(),
          RangeBar(sel: _sel, presets: const <int>[2, 3, 4, 5], onChanged: (RangeSel s) => setState(() => _sel = s)),
          const SizedBox(height: 12),
          metricGrid(ctx, <Widget>[
            MetricTile(label: bi('મોડી ચિઠ્ઠીવાળી ગાડી', 'Trips with late chits'), value: '${lateList.length}', icon: 'clock', tone: lateList.isEmpty ? 'green' : 'amber', sub: '${bi('કુલ', 'of')} ${withKanta.length}'),
            MetricTile(label: bi('સૌથી વધુ મોડું', 'Longest delay'), value: lateList.isEmpty ? '—' : hoursText(lateList.first.value), icon: 'hourglass', tone: 'rose'),
          ], pcCols: 2),
          const SizedBox(height: 12),
          if (wl.isNotEmpty) ...<Widget>[
            caption(bi('કોણ મોડી ચિઠ્ઠી લખે છે', 'Who writes chits late')),
            for (final MapEntry<String, int> e in wl.take(5)) lineItem(icon: 'user', tone: 'amber', title: majurName(live.names, e.key), trailing: '${e.value}', trailingSub: bi('ચિઠ્ઠી', 'chits')),
            const SizedBox(height: 6),
          ],
          caption(bi('ગાડીઓ', 'Trips')),
          if (lateList.isEmpty) noteBox('check', 'green', bi('કાંટા પછી કોઈ ચિઠ્ઠી લખાઈ નથી', 'No chit was written after weighing')),
          for (final MapEntry<Trip, double> e in lateList.take(25)) tripTile(ctx, e.key),
        ];
      },
    );
  }
}

// =============================================================== after hours
class _Ev {
  final DateTime at;
  final String icon;
  final String tone;
  final String title;
  final String sub;
  final String by;
  final VoidCallback onTap;
  const _Ev(this.at, this.icon, this.tone, this.title, this.sub, this.by, this.onTap);
}

bool _inNight(DateTime t, int from, int to) {
  if (from == to) return false;
  final int h = t.hour;
  return from > to ? (h >= from || h < to) : (h >= from && h < to);
}

/// Entries made at night (outside the hours the yard is open).
class AfterHoursScreen extends StatefulWidget {
  const AfterHoursScreen({super.key});

  @override
  State<AfterHoursScreen> createState() => _AfterHoursState();
}

class _AfterHoursState extends State<AfterHoursScreen> {
  late final VoidCallback _accept = () {
    _save();
  };

  RangeSel _sel = RangeSel(3);
  late final TextEditingController _from = TextEditingController(text: '${nightFrom()}');
  late final TextEditingController _to = TextEditingController(text: '${nightTo()}');

  @override
  void initState() {
    super.initState();
    AcceptHub.push(_accept);
    prefDoc.ensure().then((_) {
      if (!mounted) return;
      setState(() {
        _from.text = '${nightFrom()}';
        _to.text = '${nightTo()}';
      });
    });
  }

  @override
  void dispose() {
    _from.dispose();
    _to.dispose();
    AcceptHub.pop(_accept);
    super.dispose();
  }

  Future<void> _save() async {
    final int f = dbl(_from.text, 22).round();
    final int t = dbl(_to.text, 5).round();
    if (f < 0 || f > 23 || t < 0 || t > 23) {
      app.toast(bi('કલાક 0 થી 23 વચ્ચે લખો', 'Hours must be between 0 and 23'));
      return;
    }
    prefDoc.data['nightFrom'] = f;
    prefDoc.data['nightTo'] = t;
    await prefDoc.save();
    if (mounted) setState(() {});
    app.toast(bi('સેવ થયું', 'Saved'));
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 800,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = _sel.period;
        final int f = nightFrom();
        final int t = nightTo();
        final List<_Ev> ev = <_Ev>[];
        for (final Chit c in live.chits) {
          if (p.has(c.at) && _inNight(c.at, f, t)) {
            ev.add(_Ev(c.at, 'receipt', 'teal', '${vtxt(c.farmer)} · ${grp(c.cmpKg)} KG', '${bi('ચિઠ્ઠી', 'Chit')} #${c.no} · ${vtxt(c.vehicle)}', c.by, () => showChitDetail(ctx, c)));
          }
        }
        for (final Kanta k in live.kantas) {
          if (p.has(k.at) && _inNight(k.at, f, t)) {
            ev.add(_Ev(k.at, 'scale', 'blue', '${vtxt(k.vehicle)} · ${grp(k.kg)} KG', 'RST ${vtxt(k.rst)}', k.by, () => showKantaDetail(ctx, k)));
          }
        }
        for (final MaalRow m in live.maals) {
          if (p.has(m.at) && _inNight(m.at, f, t)) {
            ev.add(_Ev(m.at, 'bag', 'amber', '${vtxt(m.vehicle)} · ${m.bags} ${bi('બેગ', 'bags')}', m.loading ? bi('લોડિંગ', 'Loading') : bi('અનલોડિંગ', 'Unloading'), m.by, () => showMaalDetail(ctx, m)));
          }
        }
        ev.sort((_Ev a, _Ev b) => b.at.compareTo(a.at));
        final Map<String, int> who = <String, int>{};
        for (final _Ev e in ev) {
          who[e.by] = (who[e.by] ?? 0) + 1;
        }
        final List<MapEntry<String, int>> wl = who.entries.toList();
        wl.sort((MapEntry<String, int> a, MapEntry<String, int> b) => b.value.compareTo(a.value));

        return <Widget>[
          ScreenHeader(bi('રાતની એન્ટ્રી', 'Night entries'), sub: '${p.label} · ${pad2(f)}:00 - ${pad2(t)}:00'),
          statusBanner(),
          RangeBar(sel: _sel, presets: const <int>[0, 1, 2, 3], onChanged: (RangeSel s) => setState(() => _sel = s)),
          const SizedBox(height: 12),
          Panel(
            title: bi('રાતનો સમય', 'Night window'),
            sub: bi('આ કલાકો વચ્ચેની એન્ટ્રી અજુગતી ગણાય', 'Entries between these hours look odd'),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Expanded(child: FieldX(label: bi('થી (કલાક)', 'From (hour)'), controller: _from, keyboard: TextInputType.number)),
                const SizedBox(width: 10),
                Expanded(child: FieldX(label: bi('સુધી (કલાક)', 'To (hour)'), controller: _to, keyboard: TextInputType.number)),
                const SizedBox(width: 10),
                Btn(bi('સેવ', 'Save'), icon: 'check', onTap: _save),
              ],
            ),
          ),
          const SizedBox(height: 12),
          noteBox(ev.isEmpty ? 'check' : 'night', ev.isEmpty ? 'green' : 'amber', ev.isEmpty ? bi('આ સમયમાં રાતની કોઈ એન્ટ્રી નથી', 'No night entries in this period') : bi('${ev.length} એન્ટ્રી રાતના સમયે થઈ', '${ev.length} entries were made at night')),
          if (wl.isNotEmpty) ...<Widget>[
            caption(bi('કોણે', 'By whom')),
            for (final MapEntry<String, int> e in wl.take(5)) lineItem(icon: 'user', tone: 'amber', title: majurName(live.names, e.key), trailing: '${e.value}', trailingSub: bi('એન્ટ્રી', 'entries')),
            const SizedBox(height: 6),
          ],
          for (final _Ev e in ev.take(40)) lineItem(icon: e.icon, tone: e.tone, title: e.title, sub: '${e.sub} · ${majurName(live.names, e.by)}', trailing: hm(e.at), trailingSub: dayLabel(e.at), onTap: e.onTap),
        ];
      },
    );
  }
}
