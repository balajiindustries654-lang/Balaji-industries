import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/engine.dart';
import '../../data/insights.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../data/owner_docs.dart';
import '../../widgets/charts.dart';
import '../../widgets/common.dart';
import '../../widgets/page.dart';
import 'kit.dart';
import 'kit2.dart';
import 'ui.dart';

// ================================================================= calendar
/// A month as a calendar: every day coloured by how much came in.
class CalendarScreen extends StatefulWidget {
  const CalendarScreen({super.key});

  @override
  State<CalendarScreen> createState() => _CalendarState();
}

class _CalendarState extends State<CalendarScreen> {
  DateTime _month = DateTime(DateTime.now().year, DateTime.now().month, 1);
  int _metric = 0;

  double _val(DayPoint d) {
    switch (_metric) {
      case 1:
        return d.chitKg;
      case 2:
        return d.trips.toDouble();
      case 3:
        return d.mChit > 0 ? d.ghatPct.abs() : 0;
      default:
        return d.kantaKg;
    }
  }

  String _txt(double v) {
    if (v <= 0) return '';
    switch (_metric) {
      case 2:
        return '${v.round()}';
      case 3:
        return v.toStringAsFixed(1);
      default:
        return (v / 1000).toStringAsFixed(1);
    }
  }

  void _openDay(BuildContext context, DayPoint d) {
    final Period p = Period(d.day, addDays(d.day, 1));
    final Stats s = statsFor(p);
    openPanel(
      context,
      title: '${dmy(d.day)} · ${dayName(d.day)}',
      width: 460,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          InfoRow(bi('ગાડી', 'Vehicles'), '${s.trips}'),
          InfoRow(bi('ચિઠ્ઠી', 'Chits'), '${s.chits} · ${grp(s.chitKg)} KG'),
          InfoRow(bi('કાંટો', 'Kanta'), '${s.kantas} · ${grp(s.kantaKg)} KG'),
          InfoRow(bi('ઘટ / વધ', 'Loss / gain'), s.compared == 0 ? '—' : '${sk(s.ghat)} KG (${s.ghatPct.toStringAsFixed(2)}%)'),
          InfoRow(bi('માલ બેગ', 'Maal bags'), '${bi('અંદર', 'in')} ${s.bagsIn} · ${bi('બહાર', 'out')} ${s.bagsOut}'),
          InfoRow(bi('તપાસ માંગે છે', 'Needs checking'), '${s.problems}'),
          if (live.isClosed(d.day)) InfoRow(bi('દિવસ', 'Day'), bi('બંધ કરેલો', 'Closed')),
          const SizedBox(height: 14),
          Btn(bi('આ દિવસનો રિપોર્ટ કૉપિ', 'Copy this day\'s report'), icon: 'copy', kind: BtnKind.tonal, expand: true, onTap: () => copyText(buildReport(p), msg: bi('કૉપિ થયું', 'Copied'))),
        ],
      ),
    );
  }

  Widget _cell(BuildContext ctx, DayPoint? d, double mx, DateTime today) {
    if (d == null) return const SizedBox(height: 58);
    final double v = _val(d);
    final double f = mx <= 0 ? 0 : v / mx;
    final bool isToday = d.day == today;
    final bool future = d.day.isAfter(today);
    final Color base = _metric == 3 ? Pal.bad : Pal.brand;
    return InkWell(
      onTap: future ? null : () => _openDay(ctx, d),
      borderRadius: BorderRadius.circular(10),
      child: Container(
        height: 58,
        decoration: BoxDecoration(
          color: v <= 0 ? Pal.soft : alpha(base, 0.14 + 0.78 * f),
          borderRadius: BorderRadius.circular(10),
          border: isToday ? Border.all(color: Pal.brand, width: 2) : null,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text('${d.day.day}', style: ts(11, w: FontWeight.w600, c: f > 0.55 ? Colors.white70 : Pal.muted)),
            if (v > 0) Text(_txt(v), style: ts(13, w: FontWeight.w800, c: f > 0.55 ? Colors.white : Pal.ink, tab: true)),
            if (live.isClosed(d.day)) Icon(Icons.lock_rounded, size: 10, color: f > 0.55 ? Colors.white70 : Pal.faint),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 760,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final DateTime today = dayOf(DateTime.now());
        final DateTime first = _month;
        final DateTime next = DateTime(first.year, first.month + 1, 1);
        final List<DayPoint> ds = dailySeries(Period(first, next));
        double mx = 0;
        double kantaKg = 0;
        double chitKg = 0;
        int trips = 0;
        int working = 0;
        for (final DayPoint d in ds) {
          if (_val(d) > mx) mx = _val(d);
          kantaKg += d.kantaKg;
          chitKg += d.chitKg;
          trips += d.trips;
          if (d.kantas > 0) working++;
        }
        final int lead = first.weekday - 1;
        final int total = ((lead + ds.length + 6) ~/ 7) * 7;
        final List<Widget> weeks = <Widget>[];
        for (int w = 0; w < total ~/ 7; w++) {
          final List<Widget> cells = <Widget>[];
          for (int c = 0; c < 7; c++) {
            final int idx = w * 7 + c - lead;
            final DayPoint? d = (idx >= 0 && idx < ds.length) ? ds[idx] : null;
            cells.add(Expanded(child: Padding(padding: const EdgeInsets.all(2), child: _cell(ctx, d, mx, today))));
          }
          weeks.add(Row(children: cells));
        }
        final bool canNext = next.isBefore(addDays(today, 1));
        final String unit = _metric == 2 ? bi('ગાડી', 'vehicles') : (_metric == 3 ? '%' : bi('ટન', 'tons'));
        return <Widget>[
          ScreenHeader(bi('કૅલેન્ડર', 'Calendar'), sub: bi('દિવસ મુજબ કેટલો માલ આવ્યો', 'How much came in, day by day')),
          statusBanner(),
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    IconBtn('chevl', onTap: () => setState(() => _month = DateTime(first.year, first.month - 1, 1))),
                    Expanded(child: Text(monthYear(first), textAlign: TextAlign.center, style: ts(17, w: FontWeight.w800))),
                    IconBtn('chev', onTap: canNext ? () => setState(() => _month = DateTime(first.year, first.month + 1, 1)) : null),
                  ],
                ),
                const SizedBox(height: 8),
                ChipRow(
                  labels: <String>[bi('કાંટો', 'Kanta'), bi('ચિઠ્ઠી', 'Chits'), bi('ગાડી', 'Vehicles'), bi('ઘટ %', 'Loss %')],
                  index: _metric,
                  onChanged: (int i) => setState(() => _metric = i),
                ),
                const SizedBox(height: 12),
                Row(
                  children: <Widget>[
                    for (int i = 0; i < 7; i++)
                      Expanded(child: Text(L.gu ? kDayGu[i] : kDayEn[i], textAlign: TextAlign.center, style: ts(11.5, w: FontWeight.w700, c: Pal.muted))),
                  ],
                ),
                const SizedBox(height: 4),
                ...weeks,
                const SizedBox(height: 8),
                Text(bi('આંકડા: $unit · દિવસ પર ટેપ કરો', 'Numbers: $unit · tap a day'), style: ts(11.5, c: Pal.faint)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          metricGrid(ctx, <Widget>[
            MetricTile(label: bi('કાંટો', 'Kanta'), value: kgShort(kantaKg), icon: 'scale', tone: 'blue'),
            MetricTile(label: bi('ચિઠ્ઠી', 'Chits'), value: kgShort(chitKg), icon: 'receipt', tone: 'teal'),
            MetricTile(label: bi('ગાડી', 'Vehicles'), value: '$trips', icon: 'truck', tone: 'violet'),
            MetricTile(label: bi('કામના દિવસ', 'Working days'), value: '$working', icon: 'cal', tone: 'amber', sub: working == 0 ? null : '${bi('રોજ સરેરાશ', 'avg/day')} ${kgShort(kantaKg / working)}'),
          ], pcCols: 4),
        ];
      },
    );
  }
}

// ================================================================== records
class _Rec {
  final String icon;
  final String tone;
  final String title;
  final String value;
  final String sub;
  final VoidCallback? onTap;
  const _Rec(this.icon, this.tone, this.title, this.value, this.sub, [this.onTap]);
}

/// Best / worst / biggest of everything in the loaded data.
class RecordsScreen extends StatelessWidget {
  const RecordsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 760,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = lastDays(live.days);
        final List<DayPoint> ds = dailySeries(p);
        final List<_Rec> recs = <_Rec>[];

        DayPoint? bestKg;
        DayPoint? bestTrips;
        DayPoint? bestGhat;
        DayPoint? worstGhat;
        for (final DayPoint d in ds) {
          if (d.kantaKg > 0 && (bestKg == null || d.kantaKg > bestKg.kantaKg)) bestKg = d;
          if (d.trips > 0 && (bestTrips == null || d.trips > bestTrips.trips)) bestTrips = d;
          if (d.mChit >= 5000) {
            if (bestGhat == null || d.ghatPct.abs() < bestGhat.ghatPct.abs()) bestGhat = d;
            if (worstGhat == null || d.ghatPct < worstGhat.ghatPct) worstGhat = d;
          }
        }
        final DayPoint? bk = bestKg;
        if (bk != null) recs.add(_Rec('trophy', 'amber', bi('સૌથી વધુ માલનો દિવસ', 'Biggest day'), kgShort(bk.kantaKg), '${dmy(bk.day)} · ${bk.trips} ${bi('ગાડી', 'vehicles')}'));
        final DayPoint? bt = bestTrips;
        if (bt != null) recs.add(_Rec('truck', 'blue', bi('સૌથી વધુ ગાડીનો દિવસ', 'Most vehicles in a day'), '${bt.trips}', '${dmy(bt.day)} · ${kgShort(bt.kantaKg)}'));
        final DayPoint? bg = bestGhat;
        if (bg != null) recs.add(_Rec('check', 'green', bi('સૌથી ઓછી ઘટનો દિવસ', 'Cleanest day'), '${bg.ghatPct.toStringAsFixed(2)}%', '${dmy(bg.day)} · ${sk(bg.ghat)} KG'));
        final DayPoint? wg = worstGhat;
        if (wg != null && wg.ghatPct < 0) recs.add(_Rec('warn', 'rose', bi('સૌથી વધુ ઘટનો દિવસ', 'Worst loss day'), '${wg.ghatPct.toStringAsFixed(2)}%', '${dmy(wg.day)} · ${sk(wg.ghat)} KG'));

        Kanta? heavy;
        for (final Kanta k in live.kantas) {
          if (heavy == null || k.kg > heavy.kg) heavy = k;
        }
        final Kanta? hk = heavy;
        if (hk != null && hk.kg > 0) recs.add(_Rec('scale', 'violet', bi('સૌથી ભારે ગાડી', 'Heaviest load'), '${grp(hk.kg)} KG', '${hk.vehicle} · ${dmy(hk.at)}', () => showKantaDetail(ctx, hk)));

        Chit? bigChit;
        for (final Chit c in live.chits) {
          if (bigChit == null || c.cmpKg > bigChit.cmpKg) bigChit = c;
        }
        final Chit? bc = bigChit;
        if (bc != null) recs.add(_Rec('receipt', 'teal', bi('સૌથી મોટી ચિઠ્ઠી', 'Biggest chit'), '${grp(bc.cmpKg)} KG', '${bc.farmer} · ${bc.village}', () => showChitDetail(ctx, bc)));

        final List<GroupRow> tf = topBy(Dim.farmer, p);
        if (tf.isNotEmpty) recs.add(_Rec('agri', 'green', bi('સૌથી મોટો ખેડૂત', 'Top farmer'), kgShort(tf.first.kg), tf.first.label, () => openParty(PartyRef(Dim.farmer, tf.first.key, tf.first.label))));
        final List<GroupRow> tv = topBy(Dim.village, p);
        if (tv.isNotEmpty) recs.add(_Rec('place', 'orange', bi('સૌથી મોટું ગામ', 'Top village'), kgShort(tv.first.kg), tv.first.label, () => openParty(PartyRef(Dim.village, tv.first.key, tv.first.label))));
        final List<GroupRow> tb = topBy(Dim.broker, p);
        if (tb.isNotEmpty) recs.add(_Rec('handshake', 'violet', bi('સૌથી મોટો દલાલ', 'Top broker'), kgShort(tb.first.kg), tb.first.label, () => openParty(PartyRef(Dim.broker, tb.first.key, tb.first.label))));
        final List<GroupRow> tw = topBy(Dim.vehicle, p);
        if (tw.isNotEmpty) recs.add(_Rec('truck', 'blue', bi('સૌથી વધુ માલ લાવનાર ગાડી', 'Top vehicle'), kgShort(tw.first.kg), tw.first.label, () => openParty(PartyRef(Dim.vehicle, tw.first.key, tw.first.label))));

        final List<Turn> tl = turnaround(p);
        if (tl.isNotEmpty) {
          Turn fast = tl.first;
          Turn slow = tl.first;
          for (final Turn x in tl) {
            if (x.hours < fast.hours) fast = x;
            if (x.hours > slow.hours) slow = x;
          }
          recs.add(_Rec('speed', 'green', bi('સૌથી ઝડપી ગાડી', 'Fastest turnaround'), hoursText(fast.hours), fast.trip.vehicle, () => showTripDetail(ctx, fast.trip)));
          recs.add(_Rec('hourglass', 'amber', bi('સૌથી ધીમી ગાડી', 'Slowest turnaround'), hoursText(slow.hours), slow.trip.vehicle, () => showTripDetail(ctx, slow.trip)));
        }

        // most chits in one hour
        final Map<String, int> perHour = <String, int>{};
        for (final Chit c in live.chits) {
          final String k = '${dayKey(c.at)} ${pad2(c.at.hour)}';
          perHour[k] = (perHour[k] ?? 0) + 1;
        }
        String hk2 = '';
        int hv = 0;
        perHour.forEach((String k, int v) {
          if (v > hv) {
            hv = v;
            hk2 = k;
          }
        });
        if (hv > 0) recs.add(_Rec('clock', 'slate', bi('એક કલાકમાં સૌથી વધુ ચિઠ્ઠી', 'Most chits in one hour'), '$hv', hk2.replaceFirst(' ', '  ·  ') + ':00'));

        // longest run of working days
        int run = 0;
        int best = 0;
        for (final DayPoint d in ds) {
          if (d.kantas > 0) {
            run++;
            if (run > best) best = run;
          } else {
            run = 0;
          }
        }
        if (best > 1) recs.add(_Rec('fire', 'orange', bi('સતત કામના દિવસ', 'Longest working streak'), '$best ${bi('દિવસ', 'days')}', bi('રજા વગર સતત કાંટો ચાલ્યો', 'weighbridge ran without a break')));

        // most active labour
        final Map<String, int> by = <String, int>{};
        for (final Chit c in live.chits) {
          by[c.by] = (by[c.by] ?? 0) + 1;
        }
        String topBy1 = '';
        int topN = 0;
        by.forEach((String k, int v) {
          if (v > topN) {
            topN = v;
            topBy1 = k;
          }
        });
        if (topN > 0) recs.add(_Rec('users', 'teal', bi('સૌથી વધુ ચિઠ્ઠી નોંધનાર', 'Most chits entered by'), '$topN', majurName(live.names, topBy1)));

        return <Widget>[
          ScreenHeader(bi('રેકોર્ડ્સ', 'Records'), sub: bi('છેલ્લા ${live.days} દિવસના ડેટામાંથી', 'From the last ${live.days} days of data')),
          statusBanner(),
          if (recs.isEmpty) EmptyBox(icon: 'trophy', title: bi('હજી ડેટા નથી', 'No data yet')),
          for (final _Rec r in recs) lineItem(icon: r.icon, tone: r.tone, title: r.title, sub: r.sub, trailing: r.value, onTap: r.onTap),
        ];
      },
    );
  }
}

// ================================================================= forecast
/// Where the month will end, from the usual pattern of each weekday.
class ForecastScreen extends StatelessWidget {
  const ForecastScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 900,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final DateTime today = dayOf(DateTime.now());
        final DateTime ms = DateTime(today.year, today.month, 1);
        final DateTime nm = DateTime(today.year, today.month + 1, 1);
        final int dim = daysBetween(ms, nm);
        final List<DayPoint> mon = dailySeries(Period(ms, nm));

        // usual kg per weekday = last 8 weeks, zero days included
        final List<DayPoint> hist = dailySeries(Period(addDays(today, -56), today));
        final List<double> wsum = List<double>.filled(7, 0);
        final List<int> wn = List<int>.filled(7, 0);
        for (final DayPoint d in hist) {
          final int w = d.day.weekday - 1;
          wsum[w] += d.kantaKg;
          wn[w]++;
        }
        double usual(int w) => wn[w] == 0 ? 0 : wsum[w] / wn[w];

        double mtd = 0;
        double proj = 0;
        final List<double> vals = <double>[];
        final List<Color> cols = <Color>[];
        final List<String> labs = <String>[];
        for (int i = 0; i < dim; i++) {
          final DayPoint d = mon[i];
          double v;
          Color c;
          if (d.day.isAfter(today)) {
            v = usual(d.day.weekday - 1);
            c = alpha(Pal.amber, 0.55);
            proj += v;
          } else if (d.day == today) {
            final double u = usual(d.day.weekday - 1);
            v = d.kantaKg;
            mtd += d.kantaKg;
            if (u > v) proj += u - v;
            c = Pal.brand;
          } else {
            v = d.kantaKg;
            mtd += d.kantaKg;
            c = Pal.brand;
          }
          vals.add(v);
          cols.add(c);
          labs.add(axisDay(i, dim, d.day));
        }
        final double endKg = mtd + proj;
        final int left = daysBetween(today, nm) - 1;
        final double target = dailyTarget();
        final int workedDays = mon.where((DayPoint d) => d.kantaKg > 0 && !d.day.isAfter(today)).length;
        final double avg = workedDays == 0 ? 0 : mtd / workedDays;

        // last month for comparison
        final DateTime pm = DateTime(today.year, today.month - 1, 1);
        final Stats ps = statsFor(Period(pm, ms));

        return <Widget>[
          ScreenHeader(bi('મહિનાનો અંદાજ', 'Month forecast'), sub: bi('દરેક વારની સામાન્ય આવક પરથી', 'From the usual intake of each weekday')),
          statusBanner(),
          HeroCard(
            title: bi('${monthName(today.month)} ના અંતે અંદાજ', 'Expected by the end of ${monthName(today.month)}'),
            value: (endKg / 1000).toStringAsFixed(0),
            unit: bi('ટન', 'tons'),
            sub: ps.kantaKg > 0 ? bi('ગયા મહિને ${kgShort(ps.kantaKg)}', 'Last month ${kgShort(ps.kantaKg)}') : null,
            chips: <HeroChip>[
              HeroChip('trend', '${bi('અત્યાર સુધી', 'so far')} ${kgShort(mtd)}'),
              HeroChip('cal', '${bi('બાકી દિવસ', 'days left')} $left'),
              HeroChip('speed', '${bi('સરેરાશ', 'avg')} ${kgShort(avg)}/${bi('દિવસ', 'day')}'),
            ],
          ),
          const SizedBox(height: 12),
          Panel(
            title: bi('દિવસ મુજબ', 'Day by day'),
            sub: bi('ભૂરા = થઈ ગયેલા, પીળા = અંદાજ', 'teal = done, amber = expected'),
            child: MiniBars(values: vals, colors: cols, labels: labs, height: 150),
          ),
          const SizedBox(height: 12),
          metricGrid(ctx, <Widget>[
            MetricTile(label: bi('અત્યાર સુધી', 'So far'), value: kgShort(mtd), icon: 'scale', tone: 'blue'),
            MetricTile(label: bi('બાકીના દિવસનો અંદાજ', 'Expected rest'), value: kgShort(proj), icon: 'trend', tone: 'amber'),
            MetricTile(label: bi('ગયા મહિને', 'Last month'), value: kgShort(ps.kantaKg), icon: 'cal', tone: 'slate', delta: deltaOf(endKg, ps.kantaKg)),
            MetricTile(
              label: bi('ટાર્ગેટ', 'Target'),
              value: target <= 0 ? '—' : kgShort(target * dim),
              icon: 'target',
              tone: target <= 0 ? 'slate' : (endKg >= target * dim ? 'green' : 'rose'),
              sub: target <= 0 ? bi('"ટાર્ગેટ" માં સેટ કરો', 'Set it in "Target"') : '${bi('અંદાજ', 'forecast')} ${(endKg / (target * dim) * 100).round()}%',
              onTap: () => app.go('target'),
            ),
          ], pcCols: 4),
        ];
      },
    );
  }
}

// ===================================================================== pace
/// Today so far against the same weekday of the last few weeks.
class PaceScreen extends StatelessWidget {
  const PaceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 900,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final DateTime now = DateTime.now();
        final DateTime today = dayOf(now);

        // hourly kg today
        final List<double> td = List<double>.filled(24, 0);
        for (final Kanta k in live.kantas) {
          if (dayOf(k.at) == today) td[k.at.hour] += k.kg;
        }
        // usual: same weekday, up to 4 earlier weeks
        final List<double> us = List<double>.filled(24, 0);
        int weeks = 0;
        for (int w = 1; w <= 8 && weeks < 4; w++) {
          final DateTime d = addDays(today, -7 * w);
          final List<double> h = List<double>.filled(24, 0);
          double any = 0;
          for (final Kanta k in live.kantas) {
            if (dayOf(k.at) == d) {
              h[k.at.hour] += k.kg;
              any += k.kg;
            }
          }
          if (any > 0) {
            for (int i = 0; i < 24; i++) {
              us[i] += h[i];
            }
            weeks++;
          }
        }
        if (weeks > 0) {
          for (int i = 0; i < 24; i++) {
            us[i] = us[i] / weeks;
          }
        }
        double doneNow = 0;
        double usualNow = 0;
        for (int i = 0; i <= now.hour; i++) {
          doneNow += td[i];
          usualNow += i < now.hour ? us[i] : us[i] * (now.minute / 60.0);
        }
        double usualDay = 0;
        for (int i = 0; i < 24; i++) {
          usualDay += us[i];
        }
        final double ratio = usualNow > 0 ? doneNow / usualNow : 0;
        final double expectDay = ratio > 0 && usualDay > 0 ? usualDay * ratio : 0;

        int lo = 6;
        int hi = 20;
        for (int i = 0; i < 24; i++) {
          if (td[i] > 0 || us[i] > 0) {
            if (i < lo) lo = i;
            if (i > hi) hi = i;
          }
        }
        double mx = 0;
        for (int i = lo; i <= hi; i++) {
          mx = math.max(mx, math.max(td[i], us[i]));
        }
        final List<String> labs = <String>[for (int i = lo; i <= hi; i++) (i % 2 == 0 ? '$i' : '')];

        String tone = 'slate';
        String verdict = bi('સરખામણી માટે પૂરતો જૂનો ડેટા નથી', 'Not enough older data to compare');
        if (weeks > 0 && usualNow > 0) {
          if (ratio >= 1.05) {
            tone = 'green';
            verdict = bi('આજે સામાન્ય કરતાં ${((ratio - 1) * 100).round()}% વધારે', '${((ratio - 1) * 100).round()}% above usual today');
          } else if (ratio >= 0.9) {
            tone = 'teal';
            verdict = bi('આજે સામાન્ય જેવું ચાલે છે', 'About the usual pace today');
          } else {
            tone = 'amber';
            verdict = bi('આજે સામાન્ય કરતાં ${((1 - ratio) * 100).round()}% ઓછું', '${((1 - ratio) * 100).round()}% below usual today');
          }
        }

        return <Widget>[
          ScreenHeader(bi('આજનો ટ્રેક', 'Today\'s pace'), sub: bi('આજ vs ગયા ${dayName(today)}', 'Today vs earlier ${dayName(today)}s')),
          statusBanner(),
          HeroCard(
            title: bi('અત્યાર સુધી કાંટો', 'Weighed so far'),
            value: (doneNow / 1000).toStringAsFixed(1),
            unit: 'T',
            sub: weeks > 0 ? bi('સામાન્ય રીતે આ સમય સુધી ${kgShort(usualNow)}', 'Usually ${kgShort(usualNow)} by this time') : null,
            chips: <HeroChip>[
              HeroChip('clock', hm(now)),
              if (expectDay > 0) HeroChip('trend', '${bi('દિવસના અંતે', 'day-end')} ~${kgShort(expectDay)}'),
            ],
          ),
          const SizedBox(height: 12),
          noteBox('speed', tone, verdict),
          Panel(
            title: bi('આજ (લીલા)', 'Today'),
            child: MiniBars(values: <double>[for (int i = lo; i <= hi; i++) td[i]], colors: <Color>[for (int i = lo; i <= hi; i++) i == now.hour ? Pal.amber : Pal.brand], labels: labs, height: 110, maxV: mx),
          ),
          const SizedBox(height: 12),
          Panel(
            title: bi('સામાન્ય (સરેરાશ $weeks ${dayName(today)})', 'Usual (average of $weeks ${dayName(today)}s)'),
            child: MiniBars(values: <double>[for (int i = lo; i <= hi; i++) us[i]], colors: <Color>[Pal.faint], labels: labs, height: 110, maxV: mx),
          ),
        ];
      },
    );
  }
}

// ===================================================================== loads
/// How heavy the trucks are: spread, heaviest loads and loads over the limit.
class LoadsScreen extends StatefulWidget {
  const LoadsScreen({super.key});

  @override
  State<LoadsScreen> createState() => _LoadsState();
}

class _LoadsState extends State<LoadsScreen> {
  RangeSel _sel = RangeSel(3);
  late final TextEditingController _lim = TextEditingController();
  bool _seeded = false;

  @override
  void initState() {
    super.initState();
    prefDoc.addListener(_on);
    prefDoc.ensure().then((_) {
      if (mounted && !_seeded) {
        _seeded = true;
        setState(() => _lim.text = '${bigLoadKg().round()}');
      }
    });
  }

  void _on() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    prefDoc.removeListener(_on);
    _lim.dispose();
    super.dispose();
  }

  Future<void> _saveLim() async {
    final double v = dbl(_lim.text);
    if (v < 1000) {
      app.toast(bi('ઓછામાં ઓછું 1000 KG', 'At least 1000 KG'));
      return;
    }
    prefDoc.data['bigLoad'] = v;
    await prefDoc.save();
    app.toast(bi('સેવ થયું', 'Saved'));
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 900,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = _sel.period;
        final double lim = bigLoadKg();
        final List<Kanta> ks = live.kantas.where((Kanta k) => p.has(k.at) && k.kg > 0).toList();
        final List<double> kg = <double>[for (final Kanta k in ks) k.kg];
        double sum = 0;
        double mxv = 0;
        double mnv = kg.isEmpty ? 0 : kg.first;
        for (final double v in kg) {
          sum += v;
          if (v > mxv) mxv = v;
          if (v < mnv) mnv = v;
        }
        final double med = median(kg);
        const double step = 2000;
        final int nb = math.max(1, math.min(30, (mxv / step).floor() + 1));
        final List<double> bins = List<double>.filled(nb, 0);
        for (final double v in kg) {
          final int b = math.min(nb - 1, (v / step).floor());
          bins[b] += 1;
        }
        final List<Kanta> over = ks.where((Kanta k) => k.kg > lim).toList();
        over.sort((Kanta a, Kanta b) => b.kg.compareTo(a.kg));
        final List<Kanta> heavy = List<Kanta>.from(ks)..sort((Kanta a, Kanta b) => b.kg.compareTo(a.kg));

        return <Widget>[
          ScreenHeader(bi('ગાડીનો ભાર', 'Truck loads'), sub: p.label),
          statusBanner(),
          RangeBar(sel: _sel, presets: const <int>[2, 3, 4, 5], onChanged: (RangeSel s) => setState(() => _sel = s)),
          const SizedBox(height: 12),
          metricGrid(ctx, <Widget>[
            MetricTile(label: bi('ગાડી', 'Loads'), value: '${ks.length}', icon: 'truck', tone: 'blue'),
            MetricTile(label: bi('સરેરાશ ભાર', 'Average load'), value: ks.isEmpty ? '—' : kgShort(sum / ks.length), icon: 'balance', tone: 'teal', sub: '${bi('વચલો', 'median')} ${kgShort(med)}'),
            MetricTile(label: bi('સૌથી ભારે', 'Heaviest'), value: kgShort(mxv), icon: 'weight', tone: 'violet'),
            MetricTile(label: bi('સૌથી હલકી', 'Lightest'), value: kgShort(mnv), icon: 'down', tone: 'slate'),
          ], pcCols: 4),
          const SizedBox(height: 12),
          Panel(
            title: bi('કેટલી ગાડી કેટલા ટનની', 'Loads by size'),
            sub: bi('દરેક સ્તંભ = 2 ટન', 'each bar = 2 tons'),
            child: BarChartX(
              values: bins,
              labels: <String>[for (int i = 0; i < nb; i++) '${i * 2}'],
              color: Pal.info,
              axisFmt: (double v) => v.round().toString(),
              valueFmt: (double v) => '${v.round()}',
              height: 180,
            ),
          ),
          const SizedBox(height: 12),
          Panel(
            title: bi('ભારની મર્યાદા', 'Load limit'),
            sub: bi('આનાથી વધુ ભાર લાલ નિશાન', 'Heavier loads are flagged'),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Expanded(child: FieldX(label: 'KG', controller: _lim, keyboard: TextInputType.number)),
                const SizedBox(width: 10),
                Btn(bi('સેવ', 'Save'), icon: 'check', onTap: _saveLim),
              ],
            ),
          ),
          const SizedBox(height: 12),
          if (over.isNotEmpty) ...<Widget>[
            noteBox('warn', 'rose', bi('${over.length} ગાડી ${grp(lim)} KG થી વધુ ભારની', '${over.length} loads above ${grp(lim)} KG')),
            for (final Kanta k in over.take(8)) kantaTile(ctx, k),
          ] else if (ks.isNotEmpty)
            noteBox('check', 'green', bi('કોઈ ગાડી ${grp(lim)} KG થી વધુ નથી', 'No load above ${grp(lim)} KG')),
          const SizedBox(height: 4),
          caption(bi('સૌથી ભારે 5', 'Top 5 heaviest')),
          for (final Kanta k in heavy.take(5)) kantaTile(ctx, k),
        ];
      },
    );
  }
}

// ================================================================= idle gaps
class _DayGap {
  final DateTime day;
  int n = 0;
  DateTime? first;
  DateTime? last;
  int longest = 0;
  DateTime? longFrom;
  DateTime? longTo;
  int idle = 0;
  double sumGap = 0;
  _DayGap(this.day);
}

/// Times when the weighbridge stood idle between two trucks.
class IdleGapsScreen extends StatefulWidget {
  const IdleGapsScreen({super.key});

  @override
  State<IdleGapsScreen> createState() => _IdleGapsState();
}

class _IdleGapsState extends State<IdleGapsScreen> {
  RangeSel _sel = RangeSel(2);
  int _min = 30;
  static const List<int> _opts = <int>[15, 30, 60, 90];

  @override
  void initState() {
    super.initState();
    prefDoc.ensure().then((_) {
      if (!mounted) return;
      final int m = idleMinutes();
      setState(() => _min = _opts.contains(m) ? m : 30);
    });
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 900,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final Period p = _sel.period;
        final Map<String, List<Kanta>> byDay = <String, List<Kanta>>{};
        for (final Kanta k in live.kantas) {
          if (!p.has(k.at)) continue;
          byDay.putIfAbsent(dayKey(k.at), () => <Kanta>[]).add(k);
        }
        final List<_DayGap> days = <_DayGap>[];
        final List<_DayGap> flat = <_DayGap>[];
        int totalIdle = 0;
        int totalN = 0;
        double totalGaps = 0;
        int gapCount = 0;
        final List<List<DateTime>> bigGaps = <List<DateTime>>[];
        for (final MapEntry<String, List<Kanta>> e in byDay.entries) {
          final List<Kanta> l = e.value..sort((Kanta a, Kanta b) => a.at.compareTo(b.at));
          final _DayGap g = _DayGap(dayOf(l.first.at));
          g.n = l.length;
          g.first = l.first.at;
          g.last = l.last.at;
          for (int i = 1; i < l.length; i++) {
            final int gap = l[i].at.difference(l[i - 1].at).inMinutes;
            g.sumGap += gap;
            gapCount++;
            totalGaps += gap;
            if (gap >= _min) {
              g.idle += gap;
              bigGaps.add(<DateTime>[l[i - 1].at, l[i].at]);
            }
            if (gap > g.longest) {
              g.longest = gap;
              g.longFrom = l[i - 1].at;
              g.longTo = l[i].at;
            }
          }
          totalIdle += g.idle;
          totalN += g.n;
          days.add(g);
          flat.add(g);
        }
        days.sort((_DayGap a, _DayGap b) => b.day.compareTo(a.day));
        bigGaps.sort((List<DateTime> a, List<DateTime> b) => b[1].difference(b[0]).inMinutes.compareTo(a[1].difference(a[0]).inMinutes));
        String mm(int m) => m >= 60 ? '${(m / 60).toStringAsFixed(1)} ${bi('કલાક', 'h')}' : '$m ${bi('મિનિટ', 'min')}';

        return <Widget>[
          ScreenHeader(bi('કાંટો ક્યારે ખાલી', 'Idle weighbridge'), sub: p.label),
          statusBanner(),
          RangeBar(sel: _sel, presets: const <int>[0, 1, 2, 3], onChanged: (RangeSel s) => setState(() => _sel = s)),
          const SizedBox(height: 10),
          Row(
            children: <Widget>[
              Text(bi('આટલાથી વધુ ગાળો = ખાલી:', 'A gap longer than this is idle:'), style: ts(12.5, c: Pal.muted)),
              const SizedBox(width: 10),
              Seg(
                dense: true,
                labels: <String>[for (final int m in _opts) '$m'],
                index: _opts.indexOf(_min) < 0 ? 1 : _opts.indexOf(_min),
                onChanged: (int i) {
                  setState(() => _min = _opts[i]);
                  prefDoc.data['idleMin'] = _opts[i];
                  prefDoc.save();
                },
              ),
              const SizedBox(width: 6),
              Text(bi('મિનિટ', 'min'), style: ts(12.5, c: Pal.muted)),
            ],
          ),
          const SizedBox(height: 12),
          metricGrid(ctx, <Widget>[
            MetricTile(label: bi('કાંટા એન્ટ્રી', 'Entries'), value: '$totalN', icon: 'scale', tone: 'blue', sub: '${days.length} ${bi('દિવસ', 'days')}'),
            MetricTile(label: bi('સરેરાશ ગાળો', 'Average gap'), value: gapCount == 0 ? '—' : mm((totalGaps / gapCount).round()), icon: 'clock', tone: 'teal'),
            MetricTile(label: bi('ખાલી સમય', 'Idle time'), value: mm(totalIdle), icon: 'hourglass', tone: totalIdle > 120 ? 'amber' : 'green'),
            MetricTile(label: bi('મોટા ગાળા', 'Long gaps'), value: '${bigGaps.length}', icon: 'warn', tone: bigGaps.isEmpty ? 'green' : 'amber'),
          ], pcCols: 4),
          const SizedBox(height: 12),
          if (bigGaps.isNotEmpty) ...<Widget>[
            caption(bi('સૌથી લાંબા ગાળા', 'Longest gaps')),
            for (final List<DateTime> g in bigGaps.take(6))
              lineItem(
                icon: 'hourglass',
                tone: 'amber',
                title: '${hm(g[0])} → ${hm(g[1])}',
                sub: dayLabel(g[0]),
                trailing: mm(g[1].difference(g[0]).inMinutes),
              ),
          ],
          caption(bi('દિવસ મુજબ', 'Day by day')),
          if (days.isEmpty) EmptyBox(icon: 'scale', title: bi('આ સમયમાં કાંટો થયો નથી', 'No weighing in this period')),
          for (final _DayGap g in days)
            lineItem(
              icon: 'cal',
              tone: g.idle > 120 ? 'amber' : 'teal',
              title: '${dayLabel(g.day)} · ${dayName(g.day)}',
              sub: '${hm(g.first!)} - ${hm(g.last!)} · ${g.n} ${bi('એન્ટ્રી', 'entries')}${g.longest > 0 ? ' · ${bi('સૌથી લાંબો', 'longest')} ${mm(g.longest)}' : ''}',
              trailing: g.idle > 0 ? mm(g.idle) : '—',
              trailingSub: bi('ખાલી', 'idle'),
            ),
        ];
      },
    );
  }
}
