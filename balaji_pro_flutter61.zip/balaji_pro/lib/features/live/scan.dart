import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../../core/app_state.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/icons.dart';
import '../../core/palette.dart';
import '../../data/lists.dart';
import '../../data/live_store.dart';
import '../../data/scan.dart';
import '../../data/supa.dart';
import '../../widgets/common.dart';
import '../../widgets/page.dart';
import 'ui.dart';

String _commodityLabel(String code) {
  for (final List<String> c in kCommodities) {
    if (c[0] == code) return bi(c[1], c[2]);
  }
  return code;
}

/// Photo of a slip -> AI reads it (same `scan-entry` service as the web app)
/// -> the matching entry form opens already filled in.
class ScanScreen extends StatefulWidget {
  /// chit | kanta | maal
  final String kind;
  const ScanScreen({super.key, this.kind = 'chit'});

  @override
  State<ScanScreen> createState() => _ScanState();
}

class _ScanState extends State<ScanScreen> {
  late String _kind;
  String? _path;
  bool _busy = false;
  String _err = '';
  int _secs = 0;
  ScanPrefill? _res;
  bool _showBags = false;
  Timer? _tick;

  @override
  void initState() {
    super.initState();
    _kind = (widget.kind == 'kanta' || widget.kind == 'maal') ? widget.kind : 'chit';
  }

  @override
  void dispose() {
    _tick?.cancel();
    super.dispose();
  }

  int get _kindIndex => _kind == 'kanta' ? 1 : (_kind == 'maal' ? 2 : 0);

  Future<XFile?> _grab(ImageSource s) async {
    try {
      final ImageSource src = (Platform.isWindows || Platform.isLinux || Platform.isMacOS) ? ImageSource.gallery : s; // a PC has no camera picker
      return await ImagePicker().pickImage(source: src, imageQuality: 88, maxWidth: 2200, maxHeight: 2200);
    } catch (e) {
      app.toast(bi('ફોટો લઈ શકાયો નહીં', 'Could not get the photo'));
      return null;
    }
  }

  Future<void> _pick(ImageSource s) async {
    final XFile? x = await _grab(s);
    if (x == null) return;
    if (!mounted) return;
    setState(() {
      _path = x.path;
      _res = null;
      _err = '';
      _showBags = false;
    });
    await _scan();
  }

  Future<void> _scan() async {
    final String? path = _path;
    if (path == null || _busy) return;
    if (live.offline) {
      setState(() => _err = bi('સ્કેન માટે ઇન્ટરનેટ જોઈએ. નેટ આવે પછી ફરી પ્રયત્ન કરો.', 'Scanning needs internet. Try again when online.'));
      return;
    }
    setState(() {
      _busy = true;
      _err = '';
      _res = null;
      _secs = 0;
    });
    _tick?.cancel();
    _tick = Timer.periodic(const Duration(seconds: 1), (Timer t) {
      if (mounted) setState(() => _secs++);
    });
    try {
      final List<int> bytes = await File(path).readAsBytes();
      if (bytes.length > 4600000) {
        throw const SupaError('ફોટો બહુ મોટો છે - થોડો દૂરથી ફરી લો');
      }
      final Map<String, dynamic> j = await live.supa.scanEntry(ScanPrefill.serverKind(_kind), bytes);
      if (!mounted) return;
      setState(() => _res = ScanPrefill.fromReply(_kind, j, path));
    } on SupaError catch (e) {
      if (mounted) setState(() => _err = e.message);
    } catch (e) {
      if (mounted) setState(() => _err = '$e');
    } finally {
      _tick?.cancel();
      if (mounted) setState(() => _busy = false);
    }
  }

  void _open() {
    final ScanPrefill? r = _res;
    if (r == null) return;
    final String route = _kind == 'chit' ? 'chithi_new' : (_kind == 'kanta' ? 'kanta_new' : 'maal_new');
    app.go(route, arg: r);
  }

  void _reset() {
    setState(() {
      _path = null;
      _res = null;
      _err = '';
      _showBags = false;
    });
  }

  Widget _picker() {
    return Panel(
      title: bi('સ્લિપનો ફોટો', 'Slip photo'),
      sub: bi('સીધો, પૂરો અને અજવાળામાં ફોટો લો - અક્ષર સાફ દેખાય એમ', 'Straight, complete and well lit - handwriting must be readable'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Seg(
            labels: <String>[bi('ચિઠ્ઠી', 'Chit'), bi('કાંટા સ્લિપ', 'Kanta slip'), bi('માલ સ્લિપ', 'Maal slip')],
            icons: const <String>['receipt', 'scale', 'bag'],
            index: _kindIndex,
            onChanged: (int i) => setState(() {
              _kind = i == 1 ? 'kanta' : (i == 2 ? 'maal' : 'chit');
              _res = null;
              _err = '';
            }),
          ),
          const SizedBox(height: 14),
          if (_path != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.file(File(_path!), height: 240, width: double.infinity, fit: BoxFit.cover),
              ),
            ),
          Row(
            children: <Widget>[
              tExp(child: Btn(_path == null ? bi('કૅમેરા', 'Camera') : bi('ફરી ફોટો', 'Retake'), icon: 'cam', onTap: _busy ? null : () => _pick(ImageSource.camera))),
              const SizedBox(width: 10),
              tExp(child: Btn(bi('ગેલેરી', 'Gallery'), icon: 'img', kind: BtnKind.outline, onTap: _busy ? null : () => _pick(ImageSource.gallery))),
            ],
          ),
        ],
      ),
    );
  }

  Widget _progress() {
    return Panel(
      child: Column(
        children: <Widget>[
          const SizedBox(height: 6),
          SizedBox(width: 34, height: 34, child: CircularProgressIndicator(strokeWidth: 3, color: Pal.brand)),
          const SizedBox(height: 14),
          Text(bi('સ્લિપ વંચાઈ રહી છે…', 'Reading the slip…'), style: ts(16, w: FontWeight.w800)),
          const SizedBox(height: 4),
          Text('$_secs ${bi('સેકન્ડ', 'sec')}', style: ts(13, c: Pal.muted, tab: true)),
          const SizedBox(height: 8),
          Text(
            _kind == 'chit'
                ? bi('ચિઠ્ઠીમાં ઘણી બેગ હોય તો 1-2 મિનિટ લાગી શકે - એપ બંધ ન કરો', 'A chit with many bags can take 1-2 minutes - keep the app open')
                : bi('સામાન્ય રીતે 10-30 સેકન્ડ લાગે', 'Usually 10-30 seconds'),
            textAlign: TextAlign.center,
            style: ts(12.5, c: Pal.muted),
          ),
          const SizedBox(height: 6),
        ],
      ),
    );
  }

  Widget _errPanel() {
    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Icon(ic('err'), size: 20, color: Pal.bad),
              const SizedBox(width: 8),
              Expanded(child: Text(_err, style: ts(13.5, w: FontWeight.w700, c: Pal.bad))),
            ],
          ),
          const SizedBox(height: 12),
          Btn(bi('ફરી સ્કેન કરો', 'Scan again'), icon: 'refresh', kind: BtnKind.tonal, onTap: _path == null ? null : _scan),
          const SizedBox(height: 8),
          Btn(bi('હાથે ભરવા ફોર્મ ખોલો', 'Open the form and type it'), icon: 'edit', kind: BtnKind.ghost, onTap: () {
            final String route = _kind == 'chit' ? 'chithi_new' : (_kind == 'kanta' ? 'kanta_new' : 'maal_new');
            app.go(route, arg: ScanPrefill(kind: _kind, f: <String, String>{}, photo: _path, scanned: false));
          }),
        ],
      ),
    );
  }

  List<List<String>> _rows(ScanPrefill r) {
    if (_kind == 'chit') {
      return <List<String>>[
        <String>[bi('ચિઠ્ઠી નંબર', 'Chit number'), r.v('no')],
        <String>[bi('માલ', 'Material'), _commodityLabel(r.v('commodity'))],
        <String>[bi('ગાડી નંબર', 'Vehicle'), r.v('vehicle')],
        <String>[bi('ખેડૂત', 'Farmer'), r.v('farmer')],
        <String>[bi('ગામ', 'Village'), r.v('village')],
        <String>[bi('દલાલ', 'Broker'), r.v('broker')],
        <String>[bi('મોબાઇલ', 'Mobile'), r.v('mobile')],
        <String>[bi('કુલ વજન (KG)', 'Gross weight (KG)'), r.v('gross').isEmpty ? '' : cleanNum(r.v('gross'))],
      ];
    }
    if (_kind == 'kanta') {
      return <List<String>>[
        <String>['RST', r.v('rst')],
        <String>[bi('ગાડી નંબર', 'Vehicle'), r.v('vehicle')],
        <String>[bi('ચોખ્ખું વજન (KG)', 'Net weight (KG)'), r.v('kg').isEmpty ? '' : cleanNum(r.v('kg'))],
        <String>[bi('સ્લિપ પરનું નામ', 'Name on slip'), r.v('name')],
        <String>[bi('સ્લિપ પરનો મોબાઇલ', 'Mobile on slip'), r.v('mobile')],
      ];
    }
    return <List<String>>[
      <String>[bi('પ્રકાર', 'Type'), r.v('type') == 'loading' ? bi('લોડિંગ', 'Loading') : (r.v('type') == 'unloading' ? bi('અનલોડિંગ', 'Unloading') : '')],
      <String>[bi('ગાડી નંબર', 'Vehicle'), r.v('vehicle')],
      <String>[bi('બેગ', 'Bags'), r.v('bags')],
      <String>[bi('માલ', 'Material'), _commodityLabel(r.v('material'))],
      <String>[bi('તારીખ', 'Date'), r.v('date')],
      <String>[bi('માલિક', 'Owner'), r.v('owner')],
    ];
  }

  Widget _weightBox(ScanPrefill r) {
    final bool ok = r.verified;
    final String tone = ok ? 'green' : 'amber';
    final String status = ok
        ? bi('ચિઠ્ઠીના કુલ સાથે મેળ ખાય છે', 'Matches the total on the chit')
        : (r.checkStatus == 'mismatch' ? bi('બેગનો સરવાળો અને લખેલું કુલ મેળ ખાતા નથી', 'Bag sum differs from written total') : bi('વજન ચેક કરીને ભરો', 'Check the weight before saving'));
    final double? calc = r.calcTotal;
    return Panel(
      title: bi('બેગ અને વજન', 'Bags and weight'),
      action: Pill(ok ? bi('ચકાસેલ', 'Verified') : bi('ચેક કરો', 'Check'), tone: tone, icon: ok ? 'check' : 'warn', small: true),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          InfoRow(bi('બેગ મળી', 'Bags read'), '${r.bagCount}'),
          InfoRow(bi('ચિઠ્ઠી પર લખેલું કુલ', 'Total written on chit'), r.writtenTotal.isEmpty ? '—' : '${cleanNum(r.writtenTotal)} KG'),
          InfoRow(bi('એપે ગણેલું કુલ', 'Total computed'), calc == null ? '—' : '${grp(calc, dec: 2)} KG', bold: true, color: ok ? Pal.ok : Pal.warn),
          const SizedBox(height: 4),
          Text(status, style: ts(12.5, w: FontWeight.w700, c: ok ? Pal.ok : Pal.warn)),
          if (r.bagWeights.isNotEmpty) ...<Widget>[
            const SizedBox(height: 10),
            Btn(_showBags ? bi('બેગ વજન છુપાવો', 'Hide bag weights') : bi('બેગ-વાર વજન જુઓ', 'Show bag weights'), kind: BtnKind.ghost, dense: true, onTap: () => setState(() => _showBags = !_showBags)),
            if (_showBags)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: <Widget>[
                    for (int i = 0; i < r.bagWeights.length; i++)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(color: Pal.soft, borderRadius: BorderRadius.circular(8)),
                        child: Text('${i + 1}: ${r.bagWeights[i].isEmpty ? '?' : r.bagWeights[i]}', style: ts(12.5, w: FontWeight.w700, tab: true)),
                      ),
                  ],
                ),
              ),
          ],
        ],
      ),
    );
  }

  Widget _result(ScanPrefill r) {
    final List<List<String>> rows = _rows(r);
    final int found = rows.where((List<String> x) => x[1].trim().isNotEmpty).length;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Panel(
          title: bi('સ્લિપમાંથી વાંચ્યું', 'Read from the slip'),
          sub: bi('$found / ${rows.length} માહિતી મળી', '$found of ${rows.length} fields found'),
          child: Column(
            children: <Widget>[
              for (final List<String> x in rows) InfoRow(x[0], x[1].trim().isEmpty ? '—' : x[1], color: x[1].trim().isEmpty ? Pal.faint : null),
            ],
          ),
        ),
        if (_kind == 'chit' && (r.bagCount > 0 || r.writtenTotal.isNotEmpty)) ...<Widget>[const SizedBox(height: 12), _weightBox(r)],
        if (r.warnings.isNotEmpty) ...<Widget>[
          const SizedBox(height: 12),
          Surface(
            color: Pal.tone('amber').bg,
            shadow: false,
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Icon(ic('warn'), size: 18, color: Pal.tone('amber').fg),
                    const SizedBox(width: 8),
                    Text(bi('ધ્યાન રાખો', 'Please check'), style: ts(13.5, w: FontWeight.w800, c: Pal.tone('amber').fg)),
                  ],
                ),
                for (final String w in r.warnings.take(8))
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text('• $w', style: ts(12.5, w: FontWeight.w600, c: Pal.tone('amber').fg)),
                  ),
              ],
            ),
          ),
        ],
        const SizedBox(height: 14),
        Btn(bi('ફોર્મમાં ભરો અને ચેક કરો', 'Fill the form and review'), icon: 'check', expand: true, onTap: _open),
        const SizedBox(height: 8),
        Row(
          children: <Widget>[
            tExp(child: Btn(bi('ફરી સ્કેન', 'Rescan'), icon: 'refresh', kind: BtnKind.outline, onTap: _scan)),
            const SizedBox(width: 10),
            tExp(child: Btn(bi('નવી સ્લિપ', 'New slip'), icon: 'scan', kind: BtnKind.tonal, onTap: _reset)),
          ],
        ),
        if (r.text.trim().isNotEmpty) ...<Widget>[
          const SizedBox(height: 8),
          Btn(bi('વાંચેલું લખાણ કૉપિ કરો', 'Copy the read text'), icon: 'copy', kind: BtnKind.ghost, dense: true, onTap: () => copyText(r.text, msg: bi('કૉપિ થયું', 'Copied'))),
        ],
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final ScanPrefill? r = _res;
    return LiveBody(
      maxWidth: 640,
      rows: (BuildContext c) => <Widget>[
        ScreenHeader(bi('સ્લિપ સ્કેન', 'Scan a slip'), sub: bi('ફોટો પાડો - એન્ટ્રી આપમેળે ભરાઈ જાય', 'Take a photo - the entry fills itself')),
        statusBanner(),
        _picker(),
        const SizedBox(height: 12),
        if (_busy) _progress(),
        if (!_busy && _err.isNotEmpty) _errPanel(),
        if (!_busy && r != null) _result(r),
        if (!_busy && r == null && _err.isEmpty && _path == null)
          Panel(
            title: bi('કેવી રીતે કામ કરે?', 'How it works'),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                _tip('1', bi('ઉપર સ્લિપનો પ્રકાર પસંદ કરો', 'Pick the slip type above')),
                _tip('2', bi('કૅમેરાથી ફોટો પાડો', 'Take the photo with the camera')),
                _tip('3', bi('AI વાંચે - નંબર, ગાડી, વજન ભરાય', 'AI reads it - number, vehicle, weight get filled')),
                _tip('4', bi('તમે ચેક કરીને સેવ કરો (ફોટો સાથે જ સેવ થાય)', 'You check and save (the photo is saved with it)')),
              ],
            ),
          ),
      ],
    );
  }

  Widget _tip(String n, String t) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            width: 24,
            height: 24,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: Pal.tone('violet').bg, shape: BoxShape.circle),
            child: Text(n, style: ts(12, w: FontWeight.w800, c: Pal.tone('violet').fg)),
          ),
          const SizedBox(width: 10),
          Expanded(child: Text(t, style: ts(13.5, w: FontWeight.w600))),
        ],
      ),
    );
  }
}
