import 'package:flutter/material.dart';
import '../../core/device.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/engine.dart';
import '../../data/insights.dart' show PartyRef;
import '../../data/live_store.dart';
import '../../widgets/common.dart';
import '../../widgets/page.dart';
import 'kit.dart' show openParty;
import 'ui.dart';

// ====================================================================== mel
/// Chit vs weighbridge, vehicle by vehicle.
class MelScreen extends StatefulWidget {
  final int tab;
  const MelScreen({super.key, this.tab = 0});

  @override
  State<MelScreen> createState() => _MelScreenState();
}

class _MelScreenState extends State<MelScreen> {
  late int _tab = widget.tab;
  int _r = 1;
  int _n = 40;
  final TextEditingController _c = TextEditingController();
  String _q = '';

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  bool _inTab(Trip t, int i) {
    switch (i) {
      case 1:
        return t.state == TripState.diff;
      case 2:
        return t.state == TripState.noKanta || t.state == TripState.wait;
      case 3:
        return t.state == TripState.noChit;
      case 4:
        return t.state == TripState.ok;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      rows: (BuildContext ctx) {
        final bool pc = DeviceScope.isPc(ctx);
        final String q = _q.trim().toLowerCase();
        final List<Trip> inR = live.trips.where((Trip t) => inRange(_r, t.at)).toList();
        final List<int> cnt = <int>[0, 0, 0, 0, 0];
        for (final Trip t in inR) {
          for (int i = 0; i < 5; i++) {
            if (_inTab(t, i)) cnt[i]++;
          }
        }
        final List<Trip> shown = inR.where((Trip t) {
          if (!_inTab(t, _tab)) return false;
          if (q.isEmpty) return true;
          return '${t.vehicle} ${t.farmers} ${t.villages} ${t.kanta?.rst ?? ''}'.toLowerCase().contains(q);
        }).toList();

        double ck = 0;
        double kk = 0;
        double dsum = 0;
        double msum = 0;
        for (final Trip t in inR) {
          ck += t.chitKg;
          kk += t.kantaKg;
          if (t.both) {
            dsum += t.diff;
            msum += t.chitKg;
          }
        }
        final double dpct = msum > 0 ? dsum / msum * 100 : 0;

        final Widget kpis = Grid(
          cols: pc ? 4 : 2,
          gap: 12,
          children: <Widget>[
            KpiCard(label: bi('ચિઠ્ઠી કુલ', 'Chits total'), value: grp(ck), unit: 'KG', icon: 'receipt', tone: 'teal'),
            KpiCard(label: bi('કાંટો કુલ', 'Kanta total'), value: grp(kk), unit: 'KG', icon: 'scale', tone: 'blue'),
            KpiCard(
              label: bi('ફરક (મેળ થયેલ)', 'Difference (matched)'),
              value: sk(dsum),
              unit: 'KG',
              icon: 'cmp',
              tone: dsum.abs() <= live.cfg.tol(msum) ? 'green' : 'rose',
              delta: msum > 0 ? '${dpct.toStringAsFixed(2)}%' : null,
              deltaDown: dsum < 0,
            ),
            KpiCard(
              label: bi('તપાસ માંગે છે', 'Needs checking'),
              value: '${inR.where((Trip t) => t.problem).length}',
              icon: 'warn',
              tone: 'rose',
            ),
          ],
        );

        final List<String> tabs = <String>[
          '${bi('બધા', 'All')} ${cnt[0]}',
          '${bi('ફરક', 'Diff')} ${cnt[1]}',
          '${bi('કાંટો બાકી', 'No kanta')} ${cnt[2]}',
          '${bi('ચિઠ્ઠી નથી', 'No chit')} ${cnt[3]}',
          '${bi('બરાબર', 'OK')} ${cnt[4]}',
        ];

        return <Widget>[
          ScreenHeader(
            bi('મેળ · ચિઠ્ઠી vs કાંટો', 'Match · chit vs kanta'),
            sub: bi('મર્યાદા: ${live.cfg.pct}% (ઓછામાં ઓછા ${grp(live.cfg.floorKg)} KG)', 'Limit: ${live.cfg.pct}% (at least ${grp(live.cfg.floorKg)} KG)'),
            actions: <Widget>[refreshBtn()],
          ),
          statusBanner(),
          kpis,
          const SizedBox(height: 14),
          ChipRow(labels: tabs, index: _tab, onChanged: (int i) => setState(() {
                _tab = i;
                _n = 40;
              })),
          const SizedBox(height: 12),
          Wrap(
            spacing: 12,
            runSpacing: 10,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: <Widget>[
              SearchBox(hint: bi('ગાડી, ખેડૂત, ગામ, RST…', 'Vehicle, farmer, village, RST…'), controller: _c, width: pc ? 320 : double.infinity, onChanged: (String v) => setState(() {
                    _q = v;
                    _n = 40;
                  })),
              Seg(dense: true, labels: rangeLabels(), index: _r, onChanged: (int i) => setState(() {
                    _r = i;
                    _n = 40;
                  })),
            ],
          ),
          const SizedBox(height: 14),
          if (shown.isEmpty)
            EmptyBox(icon: 'cmp', title: bi('અહીં કંઈ નથી', 'Nothing here'))
          else
            for (final Trip t in shown.take(_n)) tripTile(ctx, t),
          if (_n < shown.length)
            Btn(bi('વધુ બતાવો (${shown.length - _n})', 'Show more (${shown.length - _n})'), kind: BtnKind.tonal, expand: true, onTap: () => setState(() => _n += 40)),
        ];
      },
    );
  }
}

// ================================================================ group by
String dimTitle(Dim d) {
  switch (d) {
    case Dim.vehicle:
      return bi('ગાડી પ્રમાણે', 'By vehicle');
    case Dim.farmer:
      return bi('ખેડૂત પ્રમાણે', 'By farmer');
    case Dim.village:
      return bi('ગામ પ્રમાણે', 'By village');
    case Dim.broker:
      return bi('દલાલ પ્રમાણે', 'By broker');
    case Dim.majur:
      return bi('મજૂર પ્રમાણે', 'By labour');
    case Dim.commodity:
      return bi('માલ પ્રમાણે', 'By material');
    case Dim.day:
      return bi('દિવસ પ્રમાણે', 'By day');
  }
}

/// Weight, loss (ghat) and number of trips grouped by vehicle / farmer /
/// village / broker / labour / material - shows WHERE the weight goes missing.
class GroupByScreen extends StatefulWidget {
  final Dim dim;
  const GroupByScreen(this.dim, {super.key});

  @override
  State<GroupByScreen> createState() => _GroupByState();
}

class _GroupByState extends State<GroupByScreen> {
  int _r = 2;
  late int _sort = widget.dim == Dim.day ? 3 : 0;
  int _n = 50;
  final TextEditingController _c = TextEditingController();
  String _q = '';

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 1100,
      rows: (BuildContext ctx) {
        final bool pc = DeviceScope.isPc(ctx);
        final String q = _q.trim().toLowerCase();
        final List<Trip> trips = live.trips.where((Trip t) => inRange(_r, t.at)).toList();
        List<GroupRow> rows = groupBy(trips, widget.dim, live.names);
        rows = rows.where((GroupRow r) => q.isEmpty || r.label.toLowerCase().contains(q)).toList();
        rows.sort((GroupRow a, GroupRow b) {
          if (_sort == 0) {
            // biggest percentage difference first, only vehicles that were really compared
            final int am = a.mtrips.isEmpty ? 1 : 0;
            final int bm = b.mtrips.isEmpty ? 1 : 0;
            if (am != bm) return am.compareTo(bm);
            return b.ghatPct.abs().compareTo(a.ghatPct.abs());
          }
          if (_sort == 1) return b.kg.compareTo(a.kg);
          if (_sort == 3) {
            final DateTime da = a.date ?? DateTime(2000);
            final DateTime db = b.date ?? DateTime(2000);
            return db.compareTo(da);
          }
          return a.label.toLowerCase().compareTo(b.label.toLowerCase());
        });

        double kg = 0;
        double mk = 0;
        double kk = 0;
        for (final GroupRow r in rows) {
          kg += r.kg;
          mk += r.matchedKg;
          kk += r.kantaKg;
        }
        final double gh = kk - mk;
        final double gp = mk > 0 ? gh / mk * 100 : 0;
        final bool isDay = widget.dim == Dim.day;
        final List<String> sortLabels = <String>[bi('ઘટ વધુ', 'Most loss'), bi('વજન વધુ', 'Most weight'), bi('નામ', 'Name'), if (isDay) bi('તારીખ', 'Date')];

        return <Widget>[
          ScreenHeader(dimTitle(widget.dim), sub: '${rows.length} · ${grp(kg)} KG', actions: <Widget>[refreshBtn()]),
          statusBanner(),
          Grid(cols: pc ? 4 : 2, gap: 12, children: <Widget>[
            KpiCard(label: bi('કુલ વજન (ચિઠ્ઠી)', 'Total (chits)'), value: grp(kg), unit: 'KG', icon: 'receipt', tone: 'teal'),
            KpiCard(label: bi('મેળ થયેલ', 'Matched'), value: grp(mk), unit: 'KG', icon: 'cmp', tone: 'blue'),
            KpiCard(label: bi('ઘટ / વધ', 'Loss / gain'), value: sk(gh), unit: 'KG', icon: 'scale', tone: gh.abs() <= live.cfg.tol(mk) ? 'green' : 'rose'),
            KpiCard(label: bi('ટકા', 'Percent'), value: '${gp.toStringAsFixed(2)}%', icon: 'pct', tone: gp.abs() <= live.cfg.pct ? 'green' : 'rose'),
          ]),
          const SizedBox(height: 14),
          Wrap(
            spacing: 12,
            runSpacing: 10,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: <Widget>[
              SearchBox(hint: bi('શોધો…', 'Search…'), controller: _c, width: pc ? 300 : double.infinity, onChanged: (String v) => setState(() {
                    _q = v;
                    _n = 50;
                  })),
              Seg(dense: true, labels: rangeLabels(), index: _r, onChanged: (int i) => setState(() {
                    _r = i;
                    _n = 50;
                  })),
              Seg(dense: true, labels: sortLabels, index: _sort >= sortLabels.length ? 0 : _sort, onChanged: (int i) => setState(() => _sort = i)),
            ],
          ),
          const SizedBox(height: 14),
          if (rows.isEmpty)
            EmptyBox(icon: 'bar', title: bi('ડેટા નથી', 'No data'))
          else
            for (final GroupRow r in rows.take(_n)) _rowTile(ctx, r),
          if (_n < rows.length)
            Btn(bi('વધુ બતાવો (${rows.length - _n})', 'Show more (${rows.length - _n})'), kind: BtnKind.tonal, expand: true, onTap: () => setState(() => _n += 50)),
        ];
      },
    );
  }

  Widget _rowTile(BuildContext ctx, GroupRow r) {
    final bool has = r.mtrips.isNotEmpty;
    final double tol = live.cfg.tol(r.matchedKg);
    String tone = 'slate';
    if (has) {
      if (r.ghat.abs() <= tol && r.ghatPct.abs() <= live.cfg.pct * 1.0 + 0.0001) {
        tone = 'green';
      } else {
        tone = r.ghat < 0 ? 'rose' : 'amber';
      }
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Surface(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        onTap: () => _open(ctx, r),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(r.label.isEmpty ? '—' : r.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14.5, w: FontWeight.w800)),
                  const SizedBox(height: 3),
                  Text('${r.trips.length} ${bi('ગાડી', 'trips')} · ${r.chits} ${bi('ચિઠ્ઠી', 'chits')} · ${grp(r.kg)} KG', style: ts(12.5, c: Pal.muted)),
                ],
              ),
            ),
            const SizedBox(width: 10),
            if (has)
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Text('${sk(r.ghat)} KG', style: ts(14.5, w: FontWeight.w800, c: Pal.tone(tone).fg, tab: true)),
                  const SizedBox(height: 3),
                  Pill('${r.ghatPct.toStringAsFixed(2)}%', tone: tone, small: true),
                ],
              )
            else
              Pill(bi('મેળ નથી', 'not compared'), tone: 'slate', small: true),
          ],
        ),
      ),
    );
  }

  Future<void> _open(BuildContext ctx, GroupRow r) {
    final List<Trip> l = r.trips.toList();
    l.sort((Trip a, Trip b) => b.at.compareTo(a.at));
    return openPanel(
      ctx,
      title: r.label.isEmpty ? '—' : r.label,
      sub: '${r.trips.length} ${bi('ગાડી', 'trips')} · ${grp(r.kg)} KG',
      width: 560,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          if (live.isAdmin && widget.dim != Dim.day && r.key != '-') ...<Widget>[
            Btn(bi('પ્રોફાઇલ ખોલો', 'Open profile'), icon: 'user', kind: BtnKind.tonal, onTap: () {
              Navigator.of(ctx).pop();
              openParty(PartyRef(widget.dim, r.key, r.label));
            }),
            const SizedBox(height: 10),
          ],
          if (r.mtrips.isNotEmpty) ...<Widget>[
            InfoRow(bi('મેળ થયેલ ચિઠ્ઠી', 'Matched chits'), '${grp(r.matchedKg)} KG'),
            InfoRow(bi('કાંટો', 'Kanta'), '${grp(r.kantaKg)} KG'),
            InfoRow(bi('ઘટ / વધ', 'Loss / gain'), '${sk(r.ghat)} KG (${r.ghatPct.toStringAsFixed(2)}%)', bold: true),
            const SizedBox(height: 10),
          ],
          for (final Trip t in l.take(40)) tripTile(ctx, t),
        ],
      ),
    );
  }
}
