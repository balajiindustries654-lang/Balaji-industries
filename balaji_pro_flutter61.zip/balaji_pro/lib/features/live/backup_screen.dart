import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/backup.dart';
import '../../data/live_store.dart';
import '../../data/offline.dart';
import '../../widgets/common.dart';
import '../../widgets/page.dart';
import 'field.dart';
import 'kit.dart';
import 'kit2.dart';
import 'ui.dart';

String _size(int b) => b >= 1048576 ? '${(b / 1048576).toStringAsFixed(1)} MB' : '${(b / 1024).round()} KB';

/// Backup · where the data is saved: online server, this device, and the folder on the laptop.
class LaptopBackupScreen extends StatefulWidget {
  const LaptopBackupScreen({super.key});

  @override
  State<LaptopBackupScreen> createState() => _BackupState();
}

class _BackupState extends State<LaptopBackupScreen> {
  List<BackupFile> _files = <BackupFile>[];
  int _cache = 0;
  bool _busy = false;
  final TextEditingController _path = TextEditingController();
  final TextEditingController _dir = TextEditingController();
  String _folder = '';

  @override
  void initState() {
    super.initState();
    _dir.text = LaptopBackup.customDir;
    LaptopBackup.tick.addListener(_reload);
    _reload();
  }

  @override
  void dispose() {
    LaptopBackup.tick.removeListener(_reload);
    _path.dispose();
    _dir.dispose();
    super.dispose();
  }

  Future<void> _reload() async {
    final List<BackupFile> f = await LaptopBackup.files();
    final int c = await OfflineStore.bytes();
    final String fp = (await LaptopBackup.folder())?.path ?? '';
    if (!mounted) return;
    setState(() {
      _files = f;
      _cache = c;
      _folder = fp;
    });
  }

  Future<void> _now() async {
    if (_busy) return;
    setState(() => _busy = true);
    final String? p = await LaptopBackup.backupNow();
    if (!mounted) return;
    setState(() => _busy = false);
    if (p != null) {
      app.toast(bi('કૉપી સેવ થઈ', 'Copy saved'));
    } else {
      app.toast(LaptopBackup.lastError.isNotEmpty ? LaptopBackup.lastError : bi('હજી ડેટા લોડ થયો નથી - થોડી વાર પછી ફરી કરો', 'Data is not loaded yet - try again in a moment'));
    }
  }

  Future<void> _restore(String path) async {
    final bool go = await confirmBox(
      context,
      title: bi('આ કૉપી પાછી મૂકવી?', 'Restore this copy?'),
      text: bi(
        'હાલનો હિસાબ (ચૂકવણી, વેચાણ, ખર્ચ, ભાવ, GST વગેરે) આ ફાઇલના હિસાબથી બદલાઈ જશે અને ઑનલાઇન સર્વર પર પણ બદલાશે. પહેલાં હાલનો ડેટા અલગ સુરક્ષા ફાઇલમાં સેવ થશે.',
        'The accounts (payments, sales, expenses, rates, GST ...) will be replaced by the ones in this file, also on the online server. The present data is first saved in a separate safety file.',
      ),
      yes: bi('હા, પાછું મૂકો', 'Yes, restore'),
      no: bi('ના', 'No'),
    );
    if (!go || !mounted) return;
    setState(() => _busy = true);
    try {
      final int n = await LaptopBackup.restore(path);
      app.toast(bi('$n હિસાબ ફાઇલ પાછી મૂકી', '$n documents restored'));
    } on FormatException catch (e) {
      app.toast(e.message);
    } catch (e) {
      app.toast('$e');
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _setDir() async {
    final bool ok = await LaptopBackup.setFolder(_dir.text);
    app.toast(ok ? bi('ફોલ્ડર બદલાયો', 'Folder changed') : bi('આ ફોલ્ડર વાપરી શકાતો નથી', 'This folder cannot be used'));
    await _reload();
  }

  Future<void> _open() async {
    final bool ok = await LaptopBackup.openFolder();
    if (!ok) app.toast(bi('ફોલ્ડર ખૂલ્યો નહીં', 'Could not open the folder'));
  }

  int get _keepIdx {
    switch (LaptopBackup.keepDays) {
      case 30:
        return 1;
      case 90:
        return 2;
      case 365:
        return 3;
    }
    return 0;
  }

  @override
  Widget build(BuildContext context) {
    return LiveBody(
      maxWidth: 860,
      rows: (BuildContext ctx) {
        if (!live.isAdmin) return ownerOnlyRows();
        final bool online = !live.offline && live.error.isEmpty;
        final int pend = live.pending.length;
        final DateTime? last = LaptopBackup.lastAt;
        int total = 0;
        for (final BackupFile f in _files) {
          total += f.bytes;
        }
        return <Widget>[
          ScreenHeader(bi('બેકઅપ · લેપટોપ કૉપી', 'Backup · laptop copy'), sub: bi('બધો હિસાબ ઑનલાઇન અને લેપટોપ બંનેમાં સેવ થાય છે', 'All accounts are saved online and on the laptop')),
          statusBanner(),
          Panel(
            title: bi('ડેટા ક્યાં ક્યાં સેવ થાય છે', 'Where your data is saved'),
            flush: true,
            child: Column(
              children: <Widget>[
                lineItem(
                  icon: 'cloud',
                  tone: online ? 'green' : 'amber',
                  title: bi('ઑનલાઇન સર્વર (Supabase)', 'Online server (Supabase)'),
                  sub: online
                      ? (pend > 0 ? bi('$pend એન્ટ્રી મોકલવાની બાકી', '$pend entries waiting to upload') : bi('દરેક એન્ટ્રી તરત સર્વર પર સેવ થાય છે', 'Every entry is saved to the server at once'))
                      : bi('હાલ ઑફલાઇન - ઇન્ટરનેટ આવતા જ મોકલાશે', 'Offline now - it is sent when the internet is back'),
                  trailing: online ? 'OK' : bi('ઑફલાઇન', 'Offline'),
                  trailingColor: online ? Pal.ok : Pal.warn,
                ),
                lineItem(
                  icon: 'db',
                  tone: 'blue',
                  title: bi('આ ડિવાઇસની ઑફલાઇન કૉપી', 'Offline copy on this device'),
                  sub: bi('ઇન્ટરનેટ વગર પણ ખૂલે - એપનું પોતાનું ફોલ્ડર', 'Opens without internet - the app\'s own folder'),
                  trailing: _size(_cache),
                ),
                lineItem(
                  icon: 'backup',
                  tone: LaptopBackup.supported ? 'teal' : 'slate',
                  title: bi('લેપટોપ ફોલ્ડર (ફાઇલ)', 'Laptop folder (file)'),
                  sub: LaptopBackup.supported
                      ? (last == null ? bi('હજી આ વખતે કૉપી બની નથી', 'No copy made yet in this run') : '${bi('છેલ્લી કૉપી', 'Last copy')}: ${dayLabel(last)} ${hm(last)} · ${_size(LaptopBackup.lastBytes)}')
                      : bi('આ સુવિધા Windows એપમાં ચાલે છે', 'This works in the Windows app'),
                  trailing: LaptopBackup.supported ? '${_files.length} ${bi('ફાઇલ', 'files')}' : null,
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          if (!LaptopBackup.supported)
            noteBox('info', 'blue', bi('ફોન પર ડેટા ઑનલાઇન સર્વર અને ફોનની ઑફલાઇન કૉપીમાં સેવ છે. ફાઇલ-કૉપી લેપટોપ (Windows) એપમાં બને છે.', 'On the phone the data is on the server and in the phone\'s offline copy. The file copy is made by the Windows app.'))
          else ...<Widget>[
            Row(
              children: <Widget>[
                tExp(child: _busy ? SizedBox(height: 48, child: Center(child: SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2.6, color: Pal.brand)))) : Btn(bi('હમણાં કૉપી લો', 'Back up now'), icon: 'backup', onTap: _now)),
                const SizedBox(width: 8),
                tExp(child: Btn(bi('ફોલ્ડર ખોલો', 'Open folder'), icon: 'folder', kind: BtnKind.tonal, onTap: _open)),
              ],
            ),
            const SizedBox(height: 12),
            Panel(
              title: bi('ગોઠવણ', 'Settings'),
              sub: _folder.isEmpty ? null : '${bi('ફોલ્ડર', 'Folder')}: $_folder',
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Text(bi('દરેક ફેરફાર પછી આપોઆપ કૉપી', 'Copy by itself after every change'), style: ts(13, w: FontWeight.w700)),
                  const SizedBox(height: 8),
                  Seg(
                    labels: <String>[bi('ચાલુ', 'On'), bi('બંધ', 'Off')],
                    index: LaptopBackup.auto ? 0 : 1,
                    dense: true,
                    onChanged: (int i) => LaptopBackup.setAuto(i == 0),
                  ),
                  const SizedBox(height: 14),
                  Text(bi('જૂની કૉપી કેટલી રાખવી? (Tally ની જેમ બધી એક જ ફોલ્ડરમાં)', 'How many days of copies to keep? (all in the one folder, like Tally)'), style: ts(13, w: FontWeight.w700)),
                  const SizedBox(height: 8),
                  Seg(
                    labels: <String>[bi('બધી', 'All'), bi('30 દિવસ', '30 days'), bi('90 દિવસ', '90 days'), bi('1 વર્ષ', '1 year')],
                    index: _keepIdx,
                    dense: true,
                    onChanged: (int i) => LaptopBackup.setKeepDays(const <int>[0, 30, 90, 365][i]),
                  ),
                  const SizedBox(height: 14),
                  FieldX(label: bi('બીજો ફોલ્ડર (ઇચ્છા મુજબ)', 'Another folder (optional)'), controller: _dir, hint: r'D:\Balaji Data', stacked: true),
                  const SizedBox(height: 8),
                  Btn(bi('ફોલ્ડર બદલો', 'Use this folder'), icon: 'check', kind: BtnKind.outline, dense: true, onTap: _setDir),
                ],
              ),
            ),
            const SizedBox(height: 12),
            caption('${bi('લેપટોપ પરની કૉપી', 'Copies on the laptop')} · ${_files.length} · ${_size(total)}'),
            if (_files.isEmpty) EmptyBox(icon: 'backup', title: bi('હજી કોઈ કૉપી નથી', 'No copy yet'), sub: bi('ઉપર "હમણાં કૉપી લો" દબાવો', 'Press "Back up now" above')),
            for (final BackupFile f in _files.take(60))
              lineItem(
                icon: f.name.startsWith('before-restore') ? 'undo' : 'doc',
                tone: f.name.startsWith('before-restore') ? 'amber' : 'teal',
                title: f.name,
                sub: '${dayLabel(f.at)} ${hm(f.at)} · ${_size(f.bytes)}',
                trailing: bi('પાછું મૂકો', 'Restore'),
                trailingColor: Pal.brand,
                onTap: () => _restore(f.path),
              ),
            if (_files.length > 60) Padding(padding: const EdgeInsets.all(8), child: Text(bi('બાકીની ફાઇલો ફોલ્ડરમાં જુઓ', 'Open the folder to see the rest'), style: ts(12.5, c: Pal.muted))),
            const SizedBox(height: 12),
            Panel(
              title: bi('બીજી જગ્યાની ફાઇલ પાછી મૂકો', 'Restore a file from somewhere else'),
              sub: bi('પેન-ડ્રાઇવ કે બીજા કમ્પ્યુટરની balaji-backup ફાઇલનો પાથ લખો', 'Type the path of a balaji-backup file (pen drive, another computer)'),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  FieldX(label: bi('ફાઇલનો પાથ', 'File path'), controller: _path, hint: r'E:\balaji-backup-2026-10-15.json', stacked: true),
                  const SizedBox(height: 8),
                  Btn(bi('આ ફાઇલ પાછી મૂકો', 'Restore this file'), icon: 'undo', kind: BtnKind.outline, dense: true, onTap: () => _restore(_path.text)),
                ],
              ),
            ),
            const SizedBox(height: 12),
            noteBox('info', 'blue', bi('કૉપીમાં: ચૂકવણી, વેચાણ, ખર્ચ, ભાવ, સ્ટોક-પ્રોસેસ, GST બિલ, બેંક, ટ્રેડિંગ, ફોલો-અપ અને ચિઠ્ઠી / કાંટો / માલની યાદી છે. "પાછું મૂકો" ફક્ત હિસાબની ફાઇલો પાછી મૂકે છે; ચિઠ્ઠી / કાંટો / માલ સર્વર પર જ સુરક્ષિત રહે છે.', 'A copy holds payments, sales, expenses, rates, stock-processing, GST bills, bank, trading, follow-ups and the list of chits / kanta / maal. "Restore" puts back only the accounts documents; chits / kanta / maal stay safe on the server.')),
          ],
        ];
      },
    );
  }
}
