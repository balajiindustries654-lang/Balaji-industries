import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/palette.dart';
import '../../data/books.dart';
import '../../data/insights.dart';
import '../../data/live_store.dart';
import '../../data/owner_docs.dart';
import '../../data/statements.dart';
import '../../data/trade.dart' show saleDoc;
import '../../data/vouchers.dart' show reportHtml;
import '../../widgets/accept.dart';
import '../../widgets/charts.dart';
import '../../widgets/common.dart';
import '../../widgets/page.dart';
import 'kit.dart';
import 'kit2.dart';
import 'money_screens.dart';
import 'ui.dart';
import 'voucher_screens.dart' show exportCsvOut, printOut;

// ======================================================================
// Graphs: month by month sales, purchase, expenses and result of a financial year (April to March)
// ======================================================================

const List<String> _mon = <String>['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar'];

String _mLabel(DateTime m) => '${_monName(m.month)} ${pad2(m.year % 100)}';

String _monName(int m) {
  const List<String> n = <String>['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return n[m - 1];
}

String _cr(double v) {
  final double a = v.abs();
  final String s = a >= 10000000 ? '${(a / 10000000).toStringAsFixed(2)} Cr' : (a >= 100000 ? '${(a / 100000).toStringAsFixed(2)} L' : (a >= 1000 ? '${(a / 1000).toStringAsFixed(1)} K' : a.toStringAsFixed(0)));
  return v < 0 ? '-$s' : s;
}

class GraphScreen extends StatefulWidget {
  const GraphScreen({super.key});

  @override
  State<GraphScreen> createState() => _GraphState();
}

class _GraphState extends State<GraphScreen> {
  late final VoidCallback _prn = () {
    _print();
  };
  late final VoidCallback _exp = () {
    _export();
  };

  int _yr = 0; // 0 this financial year, 1 the one before ...
  int _metric = 0; // 0 sales, 1 purchase, 2 expenses, 3 result

  @override
  void initState() {
    super.initState();
    printHub.push(_prn);
    exportHub.push(_exp);
  }

  @override
  void dispose() {
    printHub.pop(_prn);
    exportHub.pop(_exp);
    super.dispose();
  }

  DateTime _fy(int back) {
    final DateTime base = finYearStart(dateOnly(DateTime.now()));
    return DateTime(base.year - back, 4, 1);
  }

  List<List<String>> _rows(GraphYear g) {
    return <List<String>>[
      for (final MonthFig m in g.months) <String>[_mLabel(m.month), tAmt(m.sales), tAmt(m.purchase), tAmt(m.expense), tAmt(m.income), m.result.abs() < 0.005 ? '' : (m.result < 0 ? '(-) ${tAmt(m.result)}' : tAmt(m.result))],
    ];
  }

  static const List<String> _heads = <String>['Month', 'Sales', 'Purchase', 'Expenses', 'Incomes', 'Result'];

  Future<void> _print() async {
    final GraphYear g = graphYear(_fy(_yr));
    await printOut(
      reportHtml(
        title: 'Monthly Summary',
        period: 'Financial year ${finYearLabel(g.fyStart)}',
        heads: _heads,
        right: const <bool>[false, true, true, true, true, true],
        rows: _rows(g),
        total: <String>['Total', tAmt(g.sales), tAmt(g.purchase), tAmt(g.expense), tAmt(g.income), g.result < 0 ? '(-) ${tAmt(g.result)}' : tAmt(g.result)],
      ),
      'monthly-summary',
    );
  }

  Future<void> _export() async {
    final GraphYear g = graphYear(_fy(_yr));
    final StringBuffer b = StringBuffer();
    b.writeln(_heads.map(csvCell).join(','));
    for (final List<String> r in _rows(g)) {
      b.writeln(r.map(csvCell).join(','));
    }
    await exportCsvOut(b.toString(), 'monthly-summary-${dayKey(DateTime.now())}');
  }

  @override
  Widget build(BuildContext context) {
    return DocsScope(
      docs: <SyncDoc>[payDoc, saleDoc, expDoc, prefDoc],
      builder: (BuildContext _) => LiveBody(
        maxWidth: 1100,
        rows: (BuildContext ctx) {
          if (!live.isAdmin) return ownerOnlyRows();
          final DateTime fy = _fy(_yr);
          final GraphYear g = graphYear(fy);
          final bool pc = app.stagePc;
          final List<String> labels = <String>[for (final MonthFig m in g.months) _mon[g.months.indexOf(m)]];
          final DateTime now = dateOnly(DateTime.now());
          final int cur = (now.year - fy.year) * 12 + now.month - fy.month;
          final int? hi = cur >= 0 && cur < 12 ? cur : null;
          final List<double> sales = <double>[for (final MonthFig m in g.months) m.sales];
          final List<double> purchase = <double>[for (final MonthFig m in g.months) m.purchase];
          final List<double> expense = <double>[for (final MonthFig m in g.months) m.expense];
          final List<double> result = <double>[for (final MonthFig m in g.months) m.result];
          // the bars cannot go below zero: a loss month is shown as an empty bar and written under the chart
          final List<double> resultBars = <double>[for (final double v in result) v > 0 ? v : 0];
          final List<List<double>> data = <List<double>>[sales, purchase, expense, resultBars];
          final List<String> lossMonths = <String>[
            for (final MonthFig m in g.months)
              if (m.result < -0.5) '${_monName(m.month.month)} ${_cr(m.result)}',
          ];
          // this year: the line stops at the current month instead of falling to zero for the months to come
          final int upto = _yr == 0 ? (cur + 1 < 2 ? 2 : (cur + 1 > 12 ? 12 : cur + 1)) : 12;
          final List<Color> colors = <Color>[Pal.ok, Pal.info, Pal.bad, Pal.violet];
          final List<String> names = <String>[bi('વેચાણ', 'Sales'), bi('ખરીદી', 'Purchase'), bi('ખર્ચ', 'Expenses'), bi('નફો / નુકસાન', 'Result')];
          final bool empty = g.sales < 0.5 && g.purchase < 0.5 && g.expense < 0.5 && g.income < 0.5;

          // expenses by head: the six biggest, the rest together
          final List<DonutPart> parts = <DonutPart>[];
          final List<Color> pal = <Color>[Pal.bad, Pal.warn, Pal.violet, Pal.info, Pal.ok, Pal.teal];
          double rest = 0;
          for (int i = 0; i < g.heads.length; i++) {
            if (i < pal.length) {
              parts.add(DonutPart(g.heads[i].name, g.heads[i].amt, pal[i]));
            } else {
              rest += g.heads[i].amt;
            }
          }
          if (rest > 0.5) parts.add(DonutPart(bi('બીજા', 'Others'), rest, Pal.faint));

          final List<PcCol> cols = <PcCol>[
            PcCol(bi('મહિનો', 'Month'), 0),
            PcCol(bi('વેચાણ', 'Sales'), 130, right: true),
            PcCol(bi('ખરીદી', 'Purchase'), 130, right: true),
            PcCol(bi('ખર્ચ', 'Expenses'), 120, right: true),
            PcCol(bi('આવક', 'Incomes'), 120, right: true),
            PcCol(bi('પરિણામ', 'Result'), 130, right: true),
          ];
          String res(double v) => v.abs() < 0.005 ? '' : (v < 0 ? '(-) ${tAmt(v)}' : tAmt(v));
          final List<Widget> table = <Widget>[];
          if (pc) {
            table.add(pcHead(cols));
            for (final MonthFig m in g.months) {
              table.add(pcRow(cols, <Widget>[
                pcTd(_mLabel(m.month), bold: true),
                pcTd(tAmt(m.sales), num: true),
                pcTd(tAmt(m.purchase), num: true),
                pcTd(tAmt(m.expense), num: true),
                pcTd(tAmt(m.income), num: true),
                pcTd(res(m.result), num: true, bold: true, c: m.result < 0 ? Pal.bad : null),
              ]));
            }
            table.add(pcTotal(cols, bi('કુલ', 'Total'), vals: <int, String>{1: tAmt(g.sales), 2: tAmt(g.purchase), 3: tAmt(g.expense), 4: tAmt(g.income), 5: res(g.result)}));
          } else {
            for (final MonthFig m in g.months) {
              if (m.sales.abs() < 0.5 && m.purchase.abs() < 0.5 && m.expense.abs() < 0.5 && m.income.abs() < 0.5) continue;
              table.add(lineItem(
                icon: 'cal',
                tone: m.result >= 0 ? 'green' : 'rose',
                title: _mLabel(m.month),
                sub: '${bi('વેચાણ', 'Sales')} ${_cr(m.sales)} · ${bi('ખરીદી', 'Purchase')} ${_cr(m.purchase)} · ${bi('ખર્ચ', 'Exp')} ${_cr(m.expense)}',
                trailing: _cr(m.result),
                trailingSub: bi('પરિણામ', 'Result'),
              ));
            }
          }

          return <Widget>[
            ScreenHeader(bi('ગ્રાફ (માસિક)', 'Graphs'), sub: '${bi('નાણાકીય વર્ષ', 'Financial year')} ${finYearLabel(fy)}', actions: <Widget>[
              IconBtn('print', tip: bi('પ્રિન્ટ (Ctrl+P)', 'Print (Ctrl+P)'), onTap: _print),
              IconBtn('table', tip: bi('Excel (Alt+E)', 'Export to Excel (Alt+E)'), onTap: _export),
            ]),
            statusBanner(),
            ChipRow(labels: <String>[for (int i = 0; i < 3; i++) finYearLabel(_fy(i))], index: _yr, onChanged: (int i) => setState(() => _yr = i)),
            const SizedBox(height: 12),
            HeroCard(
              title: bi('વર્ષનું પરિણામ (સ્ટોક વગર)', 'Result of the year (without stock)'),
              value: inrC(g.result),
              unit: '',
              sub: '${bi('વેચાણ', 'Sales')} ${inrC(g.sales)} · ${bi('ખરીદી', 'Purchase')} ${inrC(g.purchase)}',
              chips: <HeroChip>[
                HeroChip('receipt', '${bi('ખર્ચ', 'Expenses')} ${inrC(g.expense)}'),
                HeroChip('rupee', '${bi('આવક', 'Incomes')} ${inrC(g.income)}'),
              ],
            ),
            const SizedBox(height: 12),
            if (empty) EmptyBox(icon: 'chart', title: bi('આ વર્ષમાં હજી કોઈ હિસાબ નથી', 'No accounts in this year yet')) else ...<Widget>[
              Panel(
                title: names[_metric],
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    ChipRow(labels: names, index: _metric, onChanged: (int i) => setState(() => _metric = i)),
                    const SizedBox(height: 10),
                    BarChartX(values: data[_metric], labels: labels, color: colors[_metric], highlight: hi, axisFmt: _cr, valueFmt: _cr, height: 230),
                    if (_metric == 3 && lossMonths.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text('${bi('નુકસાનવાળા મહિના', 'Loss months')}: ${lossMonths.join(' · ')}', style: ts(12.5, w: FontWeight.w700, c: Pal.bad))),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Panel(
                title: bi('વેચાણ સામે ખરીદી', 'Sales against purchase'),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    LineChartX(
                      series: <LineSeries>[LineSeries(bi('વેચાણ', 'Sales'), sales.sublist(0, upto), Pal.ok), LineSeries(bi('ખરીદી', 'Purchase'), purchase.sublist(0, upto), Pal.info)],
                      labels: labels.sublist(0, upto),
                      axisFmt: _cr,
                      height: 220,
                    ),
                    const SizedBox(height: 8),
                    Wrap(spacing: 14, runSpacing: 4, children: <Widget>[LegendDot(Pal.ok, bi('વેચાણ', 'Sales'), value: _cr(g.sales)), LegendDot(Pal.info, bi('ખરીદી', 'Purchase'), value: _cr(g.purchase))]),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              if (parts.isNotEmpty)
                Panel(
                  title: bi('ખર્ચ કયા ખાતે ગયો', 'Where the expenses went'),
                  child: Wrap(
                    spacing: 20,
                    runSpacing: 12,
                    crossAxisAlignment: WrapCrossAlignment.center,
                    children: <Widget>[
                      DonutX(parts: parts, center: _cr(g.expense), sub: bi('કુલ ખર્ચ', 'Total'), size: 160),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          for (final DonutPart d in parts) Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: LegendDot(d.color, d.label, value: _cr(d.value))),
                        ],
                      ),
                    ],
                  ),
                ),
              const SizedBox(height: 12),
              ...table,
            ],
            const SizedBox(height: 8),
            caption(bi('પરિણામ = વેચાણ − ખરીદી − ખર્ચ + આવક. આખરી સ્ટોકની કિંમત Profit & Loss A/c માં ગણાય છે.', 'Result = sales - purchase - expenses + incomes. The closing stock value is counted in the Profit & Loss A/c.')),
          ];
        },
      ),
    );
  }
}
