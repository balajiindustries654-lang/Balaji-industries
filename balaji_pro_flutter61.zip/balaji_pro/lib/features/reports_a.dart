import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/palette.dart';
import '../data/models.dart';
import '../widgets/charts.dart';
import '../widgets/datagrid.dart';
import 'entries.dart';
import 'parties.dart';
import 'report_screen.dart';
import 'report_util.dart';

// Reports for: core (followups), entries (10) and parties (6).

void _openParty(BuildContext context, Object? nameCell) {
  final Party? p = db.partyByName(nameCell.toString());
  if (p != null) app.go('party', arg: p);
}

void _openEntry(BuildContext context, Object? labelCell) {
  final Entry? e = entryByLabel(labelCell);
  if (e != null) showEntryDetail(context, e);
}

// --------------------------------------------------------------- followups
ReportOut _followups(RCtx c) {
  final List<List<Object?>> rows = <List<Object?>>[];
  double collect = 0;
  double pay = 0;
  db.receivableAging().forEach((String name, AgeBuckets b) {
    final double od = b.b1 + b.b2 + b.b3;
    if (od <= 1) return;
    final Party? p = db.partyByName(name);
    collect += od;
    rows.add(<Object?>[name, bi('વસૂલાત', 'Collect'), od, b.b3 > 0.5 ? 90 : (b.b2 > 0.5 ? 60 : 30), p?.phone, 'warn']);
  });
  for (final Party f in db.farmers) {
    final double d = db.farmerDue(f);
    if (d <= 20000) continue;
    int oldest = 0;
    for (final Entry e in db.entriesOfFarmer(f)) {
      if (e.due > 0.5) {
        final int age = db.today.difference(dateOnly(e.dt)).inDays;
        if (age > oldest) oldest = age;
      }
    }
    pay += d;
    rows.add(<Object?>[f.name, bi('ચૂકવવું', 'Pay'), d, oldest, f.phone, 'due']);
  }
  rows.sort((List<Object?> a, List<Object?> b) => (b[2] as double).compareTo(a[2] as double));
  return ReportOut(
    GridData(<Col>[
      Col(bi('પાર્ટી', 'Party'), CK.text, w: 230, bold: true),
      Col(bi('શું કરવું', 'Action'), CK.text, w: 100),
      Col(bi('રકમ', 'Amount'), CK.money, w: 140, main: true),
      Col(bi('ઉંમર (દિવસ)', 'Age (days)'), CK.count, w: 110),
      Col(bi('ફોન', 'Phone'), CK.text, w: 130),
      Col(bi('સ્થિતિ', 'Status'), CK.status, w: 110),
    ], rows),
    kpis: <KpiSpec>[
      KpiSpec(bi('વસૂલવાના', 'To collect'), inrC(collect), 'ul', 'green'),
      KpiSpec(bi('ચૂકવવાના', 'To pay'), inrC(pay), 'dl', 'rose'),
      KpiSpec(bi('કુલ ફોલો-અપ', 'Follow-ups'), '${rows.length}', 'flag', 'amber'),
    ],
    onRow: (BuildContext ctx, List<Object?> r) => _openParty(ctx, r[0]),
  );
}

// ------------------------------------------------------------ vehicle wise
ReportOut _vehicleWise(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('ગાડી નંબર', 'Vehicle'), CK.text, w: 170, bold: true),
    Col(bi('ફેરા', 'Trips'), CK.count, w: 90),
    Col(bi('બેગ', 'Bags'), CK.count, w: 100),
    Col(bi('ચોખ્ખું KG', 'Net KG'), CK.kg, w: 130),
    Col(bi('સરેરાશ KG/ફેરો', 'Avg KG/trip'), CK.kg, w: 140),
    Col(bi('રકમ', 'Amount'), CK.money, w: 150, main: true),
  ];
  if (noPurchase(c)) return purchaseNote(cols);
  final List<MapEntry<String, Agg>> l = sortedAgg(groupEntries(db.entriesInDays(c.days), (Entry e) => e.vehicle), (Agg a) => a.kg);
  final List<List<Object?>> rows = <List<Object?>>[
    for (final MapEntry<String, Agg> e in l) <Object?>[e.key, e.value.n, e.value.bags, e.value.kg, e.value.kg / e.value.n, e.value.amt],
  ];
  final List<MapEntry<String, Agg>> top = l.take(8).toList();
  return ReportOut(
    GridData(cols, rows, totals: <Object?>[bi('કુલ', 'Total'), sumCol(rows, 1), sumCol(rows, 2), sumCol(rows, 3), null, sumCol(rows, 5)]),
    kpis: <KpiSpec>[
      KpiSpec(bi('ગાડીઓ', 'Vehicles'), '${rows.length}', 'truck', 'blue'),
      KpiSpec(bi('કુલ ફેરા', 'Total trips'), grp(sumCol(rows, 1)), 'route', 'teal'),
      KpiSpec(bi('કુલ વજન', 'Total weight'), tons(sumCol(rows, 3)), 'scale', 'amber'),
      KpiSpec(bi('કુલ રકમ', 'Total value'), inrC(sumCol(rows, 5)), 'rupee', 'green'),
    ],
    chartTitle: bi('ગાડી પ્રમાણે વજન (ટન)', 'Weight by vehicle (tonnes)'),
    chart: BarChartX(
      values: <double>[for (final MapEntry<String, Agg> e in top) e.value.kg],
      labels: <String>[for (final MapEntry<String, Agg> e in top) e.key.length > 6 ? e.key.substring(e.key.length - 4) : e.key],
      color: Pal.info,
      axisFmt: axT,
      valueFmt: axT,
    ),
  );
}

// ------------------------------------------------------------ farmer wise
ReportOut _farmerWise(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('ખેડૂત', 'Farmer'), CK.text, w: 230, bold: true),
    Col(bi('ગામ', 'Village'), CK.text, w: 130),
    Col(bi('એન્ટ્રી', 'Entries'), CK.count, w: 90),
    Col(bi('ચોખ્ખું KG', 'Net KG'), CK.kg, w: 120),
    Col(bi('રકમ', 'Amount'), CK.money, w: 140, main: true),
    Col(bi('બાકી', 'Due'), CK.money, w: 130),
  ];
  if (noPurchase(c)) return purchaseNote(cols);
  final Map<String, Agg> m = groupEntries(db.entriesInDays(c.days), (Entry e) => e.farmer.name);
  final List<MapEntry<String, Agg>> l = sortedAgg(m, (Agg a) => a.amt);
  final List<List<Object?>> rows = <List<Object?>>[
    for (final MapEntry<String, Agg> e in l)
      <Object?>[e.key, db.farmerByName(e.key)?.village ?? '', e.value.n, e.value.kg, e.value.amt, e.value.due],
  ];
  final List<MapEntry<String, Agg>> top = l.take(8).toList();
  return ReportOut(
    GridData(cols, rows, totals: <Object?>[bi('કુલ', 'Total'), null, sumCol(rows, 2), sumCol(rows, 3), sumCol(rows, 4), sumCol(rows, 5)]),
    kpis: <KpiSpec>[
      KpiSpec(bi('ખેડૂતો', 'Farmers'), '${rows.length}', 'agri', 'green'),
      KpiSpec(bi('કુલ વજન', 'Total weight'), tons(sumCol(rows, 3)), 'scale', 'amber'),
      KpiSpec(bi('કુલ રકમ', 'Total value'), inrC(sumCol(rows, 4)), 'rupee', 'teal'),
      KpiSpec(bi('બાકી', 'Due'), inrC(sumCol(rows, 5)), 'clock', 'rose'),
    ],
    chartTitle: bi('ટોપ 8 ખેડૂત (રકમ)', 'Top 8 farmers by value'),
    chart: BarChartX(
      values: <double>[for (final MapEntry<String, Agg> e in top) e.value.amt],
      labels: <String>[for (final MapEntry<String, Agg> e in top) e.key.split(' ').first],
      color: Pal.ok,
      axisFmt: axC,
      valueFmt: axC,
    ),
    onRow: (BuildContext ctx, List<Object?> r) => _openParty(ctx, r[0]),
  );
}

// ----------------------------------------------------------- village wise
ReportOut _villageWise(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('ગામ', 'Village'), CK.text, w: 190, bold: true),
    Col(bi('ખેડૂત', 'Farmers'), CK.count, w: 100),
    Col(bi('એન્ટ્રી', 'Entries'), CK.count, w: 100),
    Col(bi('ચોખ્ખું KG', 'Net KG'), CK.kg, w: 130),
    Col(bi('રકમ', 'Amount'), CK.money, w: 150, main: true),
  ];
  if (noPurchase(c)) return purchaseNote(cols);
  final List<MapEntry<String, Agg>> l = sortedAgg(groupEntries(db.entriesInDays(c.days), (Entry e) => e.village), (Agg a) => a.kg);
  final List<List<Object?>> rows = <List<Object?>>[
    for (final MapEntry<String, Agg> e in l) <Object?>[e.key, e.value.farmers.length, e.value.n, e.value.kg, e.value.amt],
  ];
  final List<DonutPart> parts = <DonutPart>[];
  double other = 0;
  for (int i = 0; i < l.length; i++) {
    if (i < 5) {
      parts.add(DonutPart(l[i].key, l[i].value.kg, kSeries[i]));
    } else {
      other += l[i].value.kg;
    }
  }
  if (other > 0) parts.add(DonutPart(bi('બીજા', 'Others'), other, Pal.faint));
  final double total = sumCol(rows, 3);
  return ReportOut(
    GridData(cols, rows, totals: <Object?>[bi('કુલ', 'Total'), null, sumCol(rows, 2), total, sumCol(rows, 4)]),
    kpis: <KpiSpec>[
      KpiSpec(bi('ગામ', 'Villages'), '${rows.length}', 'place', 'orange'),
      KpiSpec(bi('કુલ વજન', 'Total weight'), tons(total), 'scale', 'amber'),
      KpiSpec(bi('કુલ રકમ', 'Total value'), inrC(sumCol(rows, 4)), 'rupee', 'teal'),
    ],
    chartTitle: bi('ક્યાંથી કેટલો માલ આવ્યો', 'Where the goods came from'),
    chart: donutLegend(parts, tons(total), bi('કુલ', 'Total'), fmt: (double v) => tons(v)),
  );
}

// ------------------------------------------------------------- grade wise
ReportOut _gradeWise(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('ગ્રેડ', 'Grade'), CK.text, w: 170, bold: true),
    Col(bi('એન્ટ્રી', 'Entries'), CK.count, w: 100),
    Col(bi('ચોખ્ખું KG', 'Net KG'), CK.kg, w: 130),
    Col(bi('સરેરાશ ભાવ/મણ', 'Avg rate/mann'), CK.money, w: 140),
    Col(bi('રકમ', 'Amount'), CK.money, w: 150, main: true),
    Col(bi('હિસ્સો', 'Share'), CK.pct, w: 90),
  ];
  if (noPurchase(c)) return purchaseNote(cols);
  final Map<String, Agg> m = groupEntries(db.entriesInDays(c.days), (Entry e) => '${e.g}');
  double total = 0;
  for (final Agg a in m.values) {
    total += a.kg;
  }
  final List<List<Object?>> rows = <List<Object?>>[];
  final List<DonutPart> parts = <DonutPart>[];
  for (int g = 0; g < 3; g++) {
    final Agg? a = m['$g'];
    if (a == null) continue;
    rows.add(<Object?>[gradeName(g), a.n, a.kg, a.avgRate, a.amt, total > 0 ? a.kg / total * 100 : 0.0]);
    parts.add(DonutPart(gradeName(g, shortName: true), a.kg, gradeColor(g)));
  }
  return ReportOut(
    GridData(cols, rows, totals: <Object?>[bi('કુલ', 'Total'), sumCol(rows, 1), total, null, sumCol(rows, 4), 100.0]),
    kpis: <KpiSpec>[
      for (int i = 0; i < rows.length; i++) KpiSpec(parts[i].label, tons(parts[i].value), 'grain', i == 0 ? 'teal' : (i == 1 ? 'amber' : 'violet')),
    ],
    chartTitle: bi('ગ્રેડ પ્રમાણે વજન', 'Weight by grade'),
    chart: donutLegend(parts, tons(total), bi('કુલ', 'Total'), fmt: (double v) => tons(v)),
  );
}

// ------------------------------------------------------------ broker wise
ReportOut _brokerWise(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('દલાલ', 'Broker'), CK.text, w: 220, bold: true),
    Col(bi('એન્ટ્રી', 'Entries'), CK.count, w: 100),
    Col(bi('ચોખ્ખું KG', 'Net KG'), CK.kg, w: 130),
    Col(bi('માલની કિંમત', 'Goods value'), CK.money, w: 150),
    Col(bi('દલાલી', 'Commission'), CK.money, w: 130, main: true),
  ];
  if (noPurchase(c)) return purchaseNote(cols);
  final List<Entry> list = db.entriesInDays(c.days).where((Entry e) => e.broker != null).toList();
  final List<MapEntry<String, Agg>> l = sortedAgg(groupEntries(list, (Entry e) => e.broker!.name), (Agg a) => a.kg);
  final List<List<Object?>> rows = <List<Object?>>[
    for (final MapEntry<String, Agg> e in l) <Object?>[e.key, e.value.n, e.value.kg, e.value.amt, e.value.comm],
  ];
  return ReportOut(
    GridData(cols, rows, totals: <Object?>[bi('કુલ', 'Total'), sumCol(rows, 1), sumCol(rows, 2), sumCol(rows, 3), sumCol(rows, 4)]),
    kpis: <KpiSpec>[
      KpiSpec(bi('દલાલ', 'Brokers'), '${rows.length}', 'handshake', 'violet'),
      KpiSpec(bi('દલાલી સાથે એન્ટ્રી', 'Entries with broker'), '${list.length}', 'list', 'blue'),
      KpiSpec(bi('કુલ દલાલી', 'Total commission'), inrC(sumCol(rows, 4)), 'pct', 'amber'),
    ],
    chartTitle: bi('દલાલ પ્રમાણે વજન (ટન)', 'Weight by broker (tonnes)'),
    chart: BarChartX(
      values: <double>[for (final MapEntry<String, Agg> e in l.take(8)) e.value.kg],
      labels: <String>[for (final MapEntry<String, Agg> e in l.take(8)) e.key.split(' ').first],
      color: Pal.violet,
      axisFmt: axT,
      valueFmt: axT,
    ),
    onRow: (BuildContext ctx, List<Object?> r) => _openParty(ctx, r[0]),
  );
}

// --------------------------------------------------------- daily register
ReportOut _dailyRegister(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('તારીખ', 'Date'), CK.date, w: 130, bold: true),
    Col(bi('એન્ટ્રી', 'Entries'), CK.count, w: 90),
    Col(bi('બેગ', 'Bags'), CK.count, w: 90),
    Col(bi('ચોખ્ખું KG', 'Net KG'), CK.kg, w: 120),
    Col(bi('રકમ', 'Amount'), CK.money, w: 140, main: true),
    Col(bi('ચૂકવેલ', 'Paid'), CK.money, w: 130),
    Col(bi('બાકી', 'Due'), CK.money, w: 130),
  ];
  if (noPurchase(c)) return purchaseNote(cols);
  final Map<DateTime, Agg> m = <DateTime, Agg>{};
  for (final Entry e in db.entriesInDays(c.days)) {
    m.putIfAbsent(dateOnly(e.dt), () => Agg()).add(e);
  }
  final List<DateTime> days = m.keys.toList()..sort((DateTime a, DateTime b) => b.compareTo(a));
  final List<List<Object?>> rows = <List<Object?>>[
    for (final DateTime d in days) <Object?>[d, m[d]!.n, m[d]!.bags, m[d]!.kg, m[d]!.amt, m[d]!.paid, m[d]!.due],
  ];
  final List<DateTime> asc = days.take(14).toList().reversed.toList();
  return ReportOut(
    GridData(cols, rows,
        totals: <Object?>[bi('કુલ', 'Total'), sumCol(rows, 1), sumCol(rows, 2), sumCol(rows, 3), sumCol(rows, 4), sumCol(rows, 5), sumCol(rows, 6)]),
    kpis: <KpiSpec>[
      KpiSpec(bi('દિવસો', 'Days'), '${rows.length}', 'cal', 'blue'),
      KpiSpec(bi('કુલ એન્ટ્રી', 'Entries'), grp(sumCol(rows, 1)), 'list', 'teal'),
      KpiSpec(bi('કુલ વજન', 'Weight'), tons(sumCol(rows, 3)), 'scale', 'amber'),
      KpiSpec(bi('કુલ રકમ', 'Value'), inrC(sumCol(rows, 4)), 'rupee', 'green'),
    ],
    chartTitle: bi('છેલ્લા 14 દિવસનું વજન (ટન)', 'Last 14 days weight (tonnes)'),
    chart: BarChartX(
      values: <double>[for (final DateTime d in asc) m[d]!.kg],
      labels: <String>[for (final DateTime d in asc) '${d.day}'],
      color: Pal.teal,
      highlight: asc.isEmpty ? null : asc.length - 1,
      axisFmt: axT,
      valueFmt: axT,
    ),
  );
}

// ----------------------------------------------------------- pending bills
ReportOut _pendingBills(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('ખેડૂત', 'Farmer'), CK.text, w: 220, bold: true),
    Col(bi('ચિઠ્ઠી', 'Slip'), CK.text, w: 90),
    Col(bi('તારીખ', 'Date'), CK.date, w: 120),
    Col(bi('રકમ', 'Amount'), CK.money, w: 130),
    Col(bi('ચૂકવેલ', 'Paid'), CK.money, w: 120),
    Col(bi('બાકી', 'Due'), CK.money, w: 130, main: true),
    Col(bi('દિવસ', 'Days'), CK.count, w: 80),
    Col(bi('સ્થિતિ', 'Status'), CK.status, w: 110),
  ];
  if (noPurchase(c)) return purchaseNote(cols);
  final List<Entry> list = db.entriesInDays(c.days).where((Entry e) => e.due > 0.5).toList();
  list.sort((Entry a, Entry b) => b.due.compareTo(a.due));
  final List<List<Object?>> rows = <List<Object?>>[
    for (final Entry e in list)
      <Object?>[e.farmer.name, '#${e.no}', e.dt, e.amount, e.paid, e.due, db.today.difference(dateOnly(e.dt)).inDays, e.status],
  ];
  int oldest = 0;
  for (final List<Object?> r in rows) {
    final int d = r[6] as int;
    if (d > oldest) oldest = d;
  }
  return ReportOut(
    GridData(cols, rows, totals: <Object?>[bi('કુલ', 'Total'), null, null, sumCol(rows, 3), sumCol(rows, 4), sumCol(rows, 5), null, null]),
    kpis: <KpiSpec>[
      KpiSpec(bi('બાકી બિલ', 'Pending bills'), '${rows.length}', 'receipt', 'rose'),
      KpiSpec(bi('કુલ બાકી', 'Total due'), inrC(sumCol(rows, 5)), 'rupee', 'amber'),
      KpiSpec(bi('સૌથી જૂનું', 'Oldest'), bi('$oldest દિવસ', '$oldest days'), 'clock', 'violet'),
    ],
    onRow: (BuildContext ctx, List<Object?> r) => _openEntry(ctx, r[1]),
  );
}

// --------------------------------------------------------------- unloading
ReportOut _unloading(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('ગાડી', 'Vehicle'), CK.text, w: 160, bold: true),
    Col(bi('તારીખ', 'Date'), CK.date, w: 120),
    Col(bi('સમય', 'Time'), CK.text, w: 80),
    Col(bi('ખેડૂત', 'Farmer'), CK.text, w: 200),
    Col(bi('ગોડાઉન', 'Godown'), CK.text, w: 120),
    Col(bi('બેગ', 'Bags'), CK.count, w: 90, main: true),
    Col(bi('ચોખ્ખું KG', 'Net KG'), CK.kg, w: 120),
    Col(bi('ચિઠ્ઠી', 'Slip'), CK.text, w: 90),
  ];
  if (noPurchase(c)) return purchaseNote(cols);
  final List<Entry> list = db.entriesInDays(c.days);
  final List<List<Object?>> rows = <List<Object?>>[
    for (final Entry e in list) <Object?>[e.vehicle, e.dt, hm(e.dt), e.farmer.name, godownName(e.godown), e.bags, e.net, '#${e.no}'],
  ];
  final List<double> perGodown = <double>[0, 0, 0];
  for (final Entry e in list) {
    perGodown[e.godown] += e.bags.toDouble();
  }
  return ReportOut(
    GridData(cols, rows, totals: <Object?>[bi('કુલ', 'Total'), null, null, null, null, sumCol(rows, 5), sumCol(rows, 6), null]),
    kpis: <KpiSpec>[
      KpiSpec(bi('કુલ બેગ', 'Total bags'), grp(sumCol(rows, 5)), 'bag', 'orange'),
      for (int g = 0; g < 3; g++) KpiSpec(godownName(g), '${grp(perGodown[g])} ${bi('બેગ', 'bags')}', 'warehouse', g == 0 ? 'teal' : (g == 1 ? 'amber' : 'violet')),
    ],
    onRow: (BuildContext ctx, List<Object?> r) => _openEntry(ctx, r[7]),
  );
}

// ------------------------------------------------------------- entry audit
ReportOut _entryAudit(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('ખેડૂત', 'Farmer'), CK.text, w: 210, bold: true),
    Col(bi('ચિઠ્ઠી', 'Slip'), CK.text, w: 90),
    Col(bi('તારીખ', 'When'), CK.date, w: 120),
    Col(bi('શું બદલાયું', 'Field'), CK.text, w: 120),
    Col(bi('પહેલાં', 'Old'), CK.text, w: 110),
    Col(bi('પછી', 'New'), CK.text, w: 110),
    Col(bi('કોણે', 'By'), CK.text, w: 110),
  ];
  if (noPurchase(c)) return purchaseNote(cols);
  const List<String> users = <String>['Owner', 'Munim', 'Operator'];
  final List<List<Object?>> rows = <List<Object?>>[];
  for (final Entry e in db.entriesInDays(c.days)) {
    if (e.no % 7 != 0) continue;
    final int k = e.no % 3;
    String field;
    String oldV;
    String newV;
    if (k == 0) {
      field = bi('ભાવ', 'Rate');
      oldV = inr(e.rate - 5);
      newV = inr(e.rate);
    } else if (k == 1) {
      field = bi('હવા (KG)', 'Hava (KG)');
      oldV = grp(e.hava + 3);
      newV = grp(e.hava);
    } else {
      field = bi('ચૂકવેલ', 'Paid');
      oldV = inr(0);
      newV = inr(e.paid);
    }
    rows.add(<Object?>[e.farmer.name, '#${e.no}', e.dt, field, oldV, newV, users[e.no % 3]]);
  }
  return ReportOut(
    GridData(cols, rows),
    kpis: <KpiSpec>[
      KpiSpec(bi('ફેરફાર', 'Changes'), '${rows.length}', 'hist', 'slate'),
      KpiSpec(bi('ભાવ ફેરફાર', 'Rate edits'), '${rows.where((List<Object?> r) => r[3] == bi('ભાવ', 'Rate')).length}', 'tag', 'amber'),
    ],
    onRow: (BuildContext ctx, List<Object?> r) => _openEntry(ctx, r[1]),
  );
}

// -------------------------------------------------------------- duplicates
ReportOut _duplicates(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('ખેડૂત', 'Farmer'), CK.text, w: 220, bold: true),
    Col(bi('તારીખ', 'Date'), CK.date, w: 120),
    Col(bi('એન્ટ્રી', 'Entries'), CK.count, w: 90),
    Col(bi('કુલ KG', 'Total KG'), CK.kg, w: 120),
    Col(bi('કારણ', 'Reason'), CK.text, w: 200),
    Col(bi('સ્થિતિ', 'Status'), CK.status, w: 100),
  ];
  if (noPurchase(c)) return purchaseNote(cols);
  final Map<String, List<Entry>> m = <String, List<Entry>>{};
  for (final Entry e in db.entriesInDays(c.days)) {
    final DateTime d = dateOnly(e.dt);
    m.putIfAbsent('${e.farmer.id}|${d.millisecondsSinceEpoch}', () => <Entry>[]).add(e);
  }
  final List<List<Object?>> rows = <List<Object?>>[];
  m.forEach((String k, List<Entry> l) {
    if (l.length < 2) return;
    double kg = 0;
    bool sameVeh = false;
    bool sameWt = false;
    for (int i = 0; i < l.length; i++) {
      kg += l[i].net;
      for (int j = i + 1; j < l.length; j++) {
        if (l[i].vehicle == l[j].vehicle) sameVeh = true;
        if ((l[i].gross - l[j].gross).abs() < 1) sameWt = true;
      }
    }
    final String reason = sameWt
        ? bi('એકસરખું વજન', 'Identical weight')
        : (sameVeh ? bi('એ જ ગાડી, એ જ દિવસ', 'Same vehicle, same day') : bi('એ જ દિવસે બે ફેરા', 'Two trips on one day'));
    rows.add(<Object?>[l.first.farmer.name, l.first.dt, l.length, kg, reason, sameWt ? 'bad' : (sameVeh ? 'warn' : 'ok')]);
  });
  rows.sort((List<Object?> a, List<Object?> b) => (b[1] as DateTime).compareTo(a[1] as DateTime));
  return ReportOut(
    GridData(cols, rows),
    kpis: <KpiSpec>[
      KpiSpec(bi('શંકાસ્પદ જૂથ', 'Flagged groups'), '${rows.length}', 'copy', 'rose'),
      KpiSpec(bi('એકસરખું વજન', 'Identical weight'), '${rows.where((List<Object?> r) => r[5] == 'bad').length}', 'warn', 'amber'),
    ],
    onRow: (BuildContext ctx, List<Object?> r) => _openParty(ctx, r[0]),
  );
}

// ------------------------------------------------------------------- aging
ReportOut _aging(RCtx c) {
  final Map<String, AgeBuckets> ag = db.receivableAging();
  final List<MapEntry<String, AgeBuckets>> l = ag.entries.toList();
  l.sort((MapEntry<String, AgeBuckets> a, MapEntry<String, AgeBuckets> b) => b.value.total.compareTo(a.value.total));
  final List<List<Object?>> rows = <List<Object?>>[
    for (final MapEntry<String, AgeBuckets> e in l) <Object?>[e.key, e.value.b0, e.value.b1, e.value.b2, e.value.b3, e.value.total],
  ];
  final double t0 = sumCol(rows, 1), t1 = sumCol(rows, 2), t2 = sumCol(rows, 3), t3 = sumCol(rows, 4);
  final double total = t0 + t1 + t2 + t3;
  return ReportOut(
    GridData(<Col>[
      Col(bi('ખરીદદાર', 'Buyer'), CK.text, w: 230, bold: true),
      Col('0–30', CK.money, w: 130),
      Col('31–60', CK.money, w: 130),
      Col('61–90', CK.money, w: 130),
      Col('90+', CK.money, w: 130),
      Col(bi('કુલ બાકી', 'Total due'), CK.money, w: 150, main: true),
    ], rows, totals: <Object?>[bi('કુલ', 'Total'), t0, t1, t2, t3, total]),
    kpis: <KpiSpec>[
      KpiSpec(bi('કુલ બાકી', 'Total receivable'), inrC(total), 'ul', 'green'),
      KpiSpec(bi('30+ દિવસ જૂનું', 'Older than 30d'), inrC(t1 + t2 + t3), 'clock', 'amber'),
      KpiSpec(bi('90+ દિવસ', '90+ days'), inrC(t3), 'alarm', 'rose'),
      KpiSpec(bi('પાર્ટી', 'Buyers'), '${rows.length}', 'store', 'blue'),
    ],
    chartTitle: bi('બાકી ઉંમર પ્રમાણે', 'By age bucket'),
    chart: donutLegend(
      <DonutPart>[
        DonutPart(bi('0–30 દિવસ', '0–30 days'), t0, Pal.ok),
        DonutPart(bi('31–60 દિવસ', '31–60 days'), t1, Pal.info),
        DonutPart(bi('61–90 દિવસ', '61–90 days'), t2, Pal.warn),
        DonutPart(bi('90+ દિવસ', '90+ days'), t3, Pal.bad),
      ],
      inrC(total),
      bi('કુલ બાકી', 'receivable'),
      fmt: (double v) => inrC(v),
    ),
    onRow: (BuildContext ctx, List<Object?> r) => _openParty(ctx, r[0]),
  );
}

// ------------------------------------------------------------ credit limit
ReportOut _creditLimit(RCtx c) {
  final List<List<Object?>> rows = <List<Object?>>[];
  for (final Party b in db.buyers) {
    final double bal = db.buyerBalance(b);
    final double used = b.creditLimit > 0 ? bal / b.creditLimit * 100 : 0;
    rows.add(<Object?>[b.name, b.creditLimit, bal, used, used > 100 ? 'over' : (used > 80 ? 'warn' : 'ok')]);
  }
  rows.sort((List<Object?> a, List<Object?> b) => (b[3] as double).compareTo(a[3] as double));
  final int over = rows.where((List<Object?> r) => r[4] == 'over').length;
  final int near = rows.where((List<Object?> r) => r[4] == 'warn').length;
  return ReportOut(
    GridData(<Col>[
      Col(bi('ખરીદદાર', 'Buyer'), CK.text, w: 240, bold: true),
      Col(bi('ક્રેડિટ લિમિટ', 'Credit limit'), CK.money, w: 150),
      Col(bi('અત્યારનું બાકી', 'Outstanding'), CK.money, w: 150, main: true),
      Col(bi('વપરાશ', 'Used'), CK.pct, w: 90),
      Col(bi('સ્થિતિ', 'Status'), CK.status, w: 130),
    ], rows),
    kpis: <KpiSpec>[
      KpiSpec(bi('લિમિટ પાર', 'Over limit'), '$over', 'warn', 'rose'),
      KpiSpec(bi('80% ઉપર', 'Above 80%'), '$near', 'shield', 'amber'),
      KpiSpec(bi('કુલ લિમિટ', 'Total limits'), inrC(sumCol(rows, 1)), 'bank', 'blue'),
      KpiSpec(bi('કુલ બાકી', 'Outstanding'), inrC(sumCol(rows, 2)), 'ul', 'green'),
    ],
    onRow: (BuildContext ctx, List<Object?> r) => _openParty(ctx, r[0]),
  );
}

// ------------------------------------------------------------------ dormant
ReportOut _dormant(RCtx c) {
  final List<List<Object?>> rows = <List<Object?>>[];
  for (final Party f in db.farmers) {
    final List<Entry> l = db.entriesOfFarmer(f);
    if (l.isEmpty) {
      rows.add(<Object?>[f.name, bi('ખેડૂત', 'Farmer'), null, null, 'new']);
      continue;
    }
    final int idle = db.today.difference(dateOnly(l.first.dt)).inDays;
    if (idle >= 10) rows.add(<Object?>[f.name, bi('ખેડૂત', 'Farmer'), l.first.dt, idle, 'idle']);
  }
  for (final Party b in db.buyers) {
    final DateTime? last = db.lastVoucherOf(b.name, 'Sales');
    if (last == null) {
      rows.add(<Object?>[b.name, bi('ખરીદદાર', 'Buyer'), null, null, 'new']);
      continue;
    }
    final int idle = db.today.difference(dateOnly(last)).inDays;
    if (idle >= 15) rows.add(<Object?>[b.name, bi('ખરીદદાર', 'Buyer'), last, idle, 'idle']);
  }
  rows.sort((List<Object?> a, List<Object?> b) => ((b[3] as int?) ?? -1).compareTo((a[3] as int?) ?? -1));
  return ReportOut(
    GridData(<Col>[
      Col(bi('પાર્ટી', 'Party'), CK.text, w: 240, bold: true),
      Col(bi('પ્રકાર', 'Type'), CK.text, w: 110),
      Col(bi('છેલ્લો વ્યવહાર', 'Last activity'), CK.date, w: 150),
      Col(bi('નિષ્ક્રિય દિવસ', 'Idle days'), CK.count, w: 130, main: true),
      Col(bi('સ્થિતિ', 'Status'), CK.status, w: 110),
    ], rows),
    kpis: <KpiSpec>[
      KpiSpec(bi('નિષ્ક્રિય પાર્ટી', 'Dormant parties'), '${rows.length}', 'moon', 'slate'),
    ],
    onRow: (BuildContext ctx, List<Object?> r) => _openParty(ctx, r[0]),
  );
}

// ------------------------------------------------------------- top parties
ReportOut _topParties(RCtx c) {
  final List<List<Object?>> rows = <List<Object?>>[];
  if (!noPurchase(c)) {
    final Map<String, Agg> m = groupEntries(db.entriesInDays(c.days), (Entry e) => e.farmer.name);
    m.forEach((String k, Agg a) => rows.add(<Object?>[k, bi('ખેડૂત', 'Farmer'), a.n, a.amt, 0.0]));
  }
  final Map<String, List<double>> bm = <String, List<double>>{};
  for (final Voucher v in db.vouchersIn(firm: c.firm, days: c.days, type: 'Sales')) {
    final List<double> x = bm.putIfAbsent(v.party, () => <double>[0, 0]);
    x[0] += 1;
    x[1] += v.total;
  }
  bm.forEach((String k, List<double> x) => rows.add(<Object?>[k, bi('ખરીદદાર', 'Buyer'), x[0].toInt(), x[1], 0.0]));
  rows.sort((List<Object?> a, List<Object?> b) => (b[3] as double).compareTo(a[3] as double));
  final double total = sumCol(rows, 3);
  for (final List<Object?> r in rows) {
    r[4] = total > 0 ? (r[3] as double) / total * 100 : 0.0;
  }
  final List<List<Object?>> top = rows.take(8).toList();
  return ReportOut(
    GridData(<Col>[
      Col(bi('પાર્ટી', 'Party'), CK.text, w: 240, bold: true),
      Col(bi('પ્રકાર', 'Type'), CK.text, w: 110),
      Col(bi('વ્યવહાર', 'Deals'), CK.count, w: 90),
      Col(bi('કુલ કિંમત', 'Value'), CK.money, w: 150, main: true),
      Col(bi('હિસ્સો', 'Share'), CK.pct, w: 90),
    ], rows),
    kpis: <KpiSpec>[
      KpiSpec(bi('પાર્ટી', 'Parties'), '${rows.length}', 'users', 'green'),
      KpiSpec(bi('કુલ વ્યવહાર', 'Total value'), inrC(total), 'rupee', 'teal'),
      if (rows.isNotEmpty) KpiSpec(bi('નંબર 1', 'No. 1'), rows.first[0].toString(), 'star', 'amber'),
    ],
    chartTitle: bi('ટોપ 8 પાર્ટી', 'Top 8 parties'),
    chart: BarChartX(
      values: <double>[for (final List<Object?> r in top) r[3] as double],
      labels: <String>[for (final List<Object?> r in top) r[0].toString().split(' ').first],
      color: Pal.amber,
      axisFmt: axC,
      valueFmt: axC,
    ),
    onRow: (BuildContext ctx, List<Object?> r) => _openParty(ctx, r[0]),
  );
}

// ------------------------------------------------------- broker commission
ReportOut _brokerCommission(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('દલાલ', 'Broker'), CK.text, w: 220, bold: true),
    Col(bi('એન્ટ્રી', 'Entries'), CK.count, w: 90),
    Col(bi('મણ', 'Mann'), CK.dec, w: 100),
    Col(bi('કુલ દલાલી', 'Commission'), CK.money, w: 140, main: true),
    Col(bi('ચૂકવેલ', 'Settled'), CK.money, w: 130),
    Col(bi('બાકી', 'Pending'), CK.money, w: 130),
  ];
  if (noPurchase(c)) return purchaseNote(cols);
  final List<Entry> list = db.entriesInDays(c.days).where((Entry e) => e.broker != null).toList();
  final Map<String, List<double>> m = <String, List<double>>{};
  for (final Entry e in list) {
    final List<double> x = m.putIfAbsent(e.broker!.name, () => <double>[0, 0, 0, 0]);
    x[0] += 1;
    x[1] += e.mann;
    x[2] += e.commission;
    if (db.today.difference(dateOnly(e.dt)).inDays > 15) x[3] += e.commission;
  }
  final List<List<Object?>> rows = <List<Object?>>[
    for (final MapEntry<String, List<double>> e in m.entries) <Object?>[e.key, e.value[0].toInt(), e.value[1], e.value[2], e.value[3], e.value[2] - e.value[3]],
  ];
  rows.sort((List<Object?> a, List<Object?> b) => (b[3] as double).compareTo(a[3] as double));
  return ReportOut(
    GridData(cols, rows, totals: <Object?>[bi('કુલ', 'Total'), sumCol(rows, 1), sumCol(rows, 2), sumCol(rows, 3), sumCol(rows, 4), sumCol(rows, 5)]),
    kpis: <KpiSpec>[
      KpiSpec(bi('કુલ દલાલી', 'Total'), inrC(sumCol(rows, 3)), 'pct', 'violet'),
      KpiSpec(bi('ચૂકવવાની બાકી', 'Pending'), inrC(sumCol(rows, 5)), 'clock', 'amber'),
    ],
    onRow: (BuildContext ctx, List<Object?> r) => _openParty(ctx, r[0]),
  );
}

// --------------------------------------------------------------- reminders
ReportOut _reminders(RCtx c) {
  final List<List<Object?>> rows = <List<Object?>>[];
  db.receivableAging().forEach((String name, AgeBuckets b) {
    final double od = b.b1 + b.b2 + b.b3;
    if (od <= 1) return;
    final Party? p = db.partyByName(name);
    final String oldest = b.b3 > 0.5 ? '90+' : (b.b2 > 0.5 ? '61–90' : '31–60');
    rows.add(<Object?>[name, p?.phone ?? '', od, oldest, b.b3 > 0.5 ? 'bad' : (b.b2 > 0.5 ? 'warn' : 'open')]);
  });
  rows.sort((List<Object?> a, List<Object?> b) => (b[2] as double).compareTo(a[2] as double));
  return ReportOut(
    GridData(<Col>[
      Col(bi('ખરીદદાર', 'Buyer'), CK.text, w: 240, bold: true),
      Col(bi('ફોન', 'Phone'), CK.text, w: 140),
      Col(bi('બાકી (30+ દિવસ)', 'Overdue (30+ d)'), CK.money, w: 160, main: true),
      Col(bi('સૌથી જૂનું', 'Oldest bucket'), CK.rtext, w: 120),
      Col(bi('સ્થિતિ', 'Status'), CK.status, w: 110),
    ], rows),
    kpis: <KpiSpec>[
      KpiSpec(bi('રિમાઇન્ડર', 'Reminders due'), '${rows.length}', 'alarm', 'rose'),
      KpiSpec(bi('વસૂલવાના', 'To collect'), inrC(sumCol(rows, 2)), 'ul', 'green'),
    ],
    onRow: (BuildContext ctx, List<Object?> r) {
      final Party? p = db.partyByName(r[0].toString());
      if (p != null) showReminder(ctx, p, r[2] as double);
    },
  );
}

final Map<String, ReportSpec> kReportsA = <String, ReportSpec>{
  'followups': ReportSpec(_followups, useDays: false, useFirm: false),
  'vehicle_wise': ReportSpec(_vehicleWise),
  'farmer_wise': ReportSpec(_farmerWise),
  'village_wise': ReportSpec(_villageWise),
  'grade_wise': ReportSpec(_gradeWise),
  'broker_wise': ReportSpec(_brokerWise),
  'daily_register': ReportSpec(_dailyRegister),
  'pending_bills': ReportSpec(_pendingBills, defaultDays: 100000),
  'unloading': ReportSpec(_unloading, defaultDays: 7),
  'entry_audit': ReportSpec(_entryAudit),
  'duplicates': ReportSpec(_duplicates, defaultDays: 90),
  'aging': ReportSpec(_aging, useDays: false, useFirm: false),
  'credit_limit': ReportSpec(_creditLimit, useDays: false, useFirm: false),
  'dormant': ReportSpec(_dormant, useDays: false, useFirm: false),
  'top_parties': ReportSpec(_topParties),
  'broker_commission': ReportSpec(_brokerCommission),
  'reminders': ReportSpec(_reminders, useDays: false, useFirm: false),
};
