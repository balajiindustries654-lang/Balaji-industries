import 'dart:async';
import 'dart:io' show Directory;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/app_state.dart';
import '../../core/device.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/icons.dart';
import '../../core/keep_awake.dart';
import '../../core/palette.dart';
import '../../core/version.dart';
import '../../data/kanta_direct.dart';
import '../../data/kanta_khata.dart';
import '../../data/kanta_log.dart';
import '../../data/kanta_sheet.dart';
import '../../data/kanta_remote.dart';
import '../../data/kanta_slip.dart';
import '../../data/kanta_usb.dart';
import '../../data/kanta_wa.dart';
import '../../data/slip_png.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../data/native_io.dart';
import '../../widgets/common.dart';
import '../../widgets/printer.dart' show openFileOnPc;
import 'kanta_print.dart';
import 'kanta_ui.dart';

// ======================================================================
// Balaji Kanta - SETTINGS (everything that is not weighing).
// The first screen of the app is only for weighing: live weight, the vehicle form, the vehicles inside, the last entry.
// Here: entries and slips (search, print again, take back), phone weighing, WhatsApp, printing, cable / COM port,
// language and log out. Opened from the "Settings" button (or F6 / Ctrl+F for the search); Esc goes back.
// ======================================================================

/// Which cards a Settings page shows: everything (classic layout) or one job of the terminal layout (View/Print, Scale, Settings).
enum KantaPart { all, entries, scale, settings }

class KantaSettings extends StatefulWidget {
  /// Open with the cursor in the search box (F6).
  final bool focusSearch;
  final KantaPart part;

  /// true: only the content (the terminal layout gives it a frame of its own - title, toolbar, weight).
  final bool embedded;
  const KantaSettings({super.key, this.focusSearch = false, this.part = KantaPart.all, this.embedded = false});

  @override
  State<KantaSettings> createState() => _KantaSettingsState();
}

class _KantaSettingsState extends State<KantaSettings> {
  Timer? _timer;
  bool _all = false;
  int _type = 0; // 0 all, 1 mill, 2 road
  List<WinPrinter> _prn = <WinPrinter>[];
  bool _prnBusy = false;
  bool _prnTried = false;
  bool _usbEpson = false; // an Epson is plugged in on USB (prints even with no Windows driver)
  final TextEditingController _find = TextEditingController();
  final FocusNode _findF = FocusNode(debugLabel: 'kanta-search');
  late final TextEditingController _head = TextEditingController(text: KantaLog.heading);
  late final TextEditingController _sub = TextEditingController(text: KantaLog.style.subtitle);
  late final TextEditingController _addr = TextEditingController(text: KantaLog.style.address);
  late final TextEditingController _phone = TextEditingController(text: KantaLog.style.phone);
  late final TextEditingController _xtra = TextEditingController(text: KantaLog.style.extra);
  late final TextEditingController _foot = TextEditingController(text: KantaLog.style.footer);
  late final TextEditingController _signL = TextEditingController(text: KantaLog.style.signL);
  late final TextEditingController _signR = TextEditingController(text: KantaLog.style.signR);
  late final TextEditingController _mill = TextEditingController(text: KantaLog.waMill);
  bool _waBusy = false;
  String _waMsg = '';
  late final TextEditingController _rstC = TextEditingController(text: kantaUsb.rstStart > 0 ? '${kantaUsb.rstStart}' : '1');
  String _rstMsg = '';

  @override
  void initState() {
    super.initState();
    kantaUsb.addListener(_tick);
    live.addListener(_tick);
    kantaRemote.addListener(_tick);
    KantaLog.tick.addListener(_tick);
    KantaWa.tick.addListener(_tick);
    KantaSheet.tick.addListener(_tick);
    if (widget.focusSearch) {
      _all = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _findF.requestFocus();
      });
    }
    if (KantaLog.printMode == 1 && DirectPrint.supported) unawaited(_findPrinters());
  }

  @override
  void dispose() {
    kantaUsb.removeListener(_tick);
    live.removeListener(_tick);
    kantaRemote.removeListener(_tick);
    KantaLog.tick.removeListener(_tick);
    KantaWa.tick.removeListener(_tick);
    KantaSheet.tick.removeListener(_tick);
    _find.dispose();
    _findF.dispose();
    _head.dispose();
    _sub.dispose();
    _addr.dispose();
    _phone.dispose();
    _xtra.dispose();
    _foot.dispose();
    _signL.dispose();
    _signR.dispose();
    _mill.dispose();
    _rstC.dispose();
    _timer?.cancel();
    super.dispose();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  Future<void> _findPrinters() async {
    setState(() {
      _prnBusy = true;
      _prnTried = true;
    });
    final List<WinPrinter> l = await DirectPrint.printers();
    final bool usb = await DirectPrint.usbEpson();
    if (!mounted) return;
    setState(() {
      _prn = l;
      _usbEpson = usb;
      _prnBusy = false;
    });
    // nothing chosen yet: take the Epson one by itself (the only dot-matrix printer in most places)
    if (KantaLog.printerName.isEmpty) {
      for (final WinPrinter w in l) {
        if (w.name.toUpperCase().contains('LX-310') || w.name.toUpperCase().contains('EPSON LX')) {
          await KantaLog.setPrinterName(w.name);
          break;
        }
      }
    }
  }

  Future<void> _logout() async {
    final bool inside = kantaUsb.inside.isNotEmpty;
    final bool? ok = await showDialog<bool>(
      context: context,
      builder: (BuildContext c) => AlertDialog(
        title: Text(bi('લૉગ આઉટ કરવું?', 'Log out?'), style: ts(17, w: FontWeight.w800)),
        content: Text(inside ? bi('અંદર ગાડી છે (પહેલું વજન લીધું). લૉગ આઉટ કરવાથી તે જશે નહીં, પણ ફરી લૉગિન કરવું પડશે.', 'A vehicle is inside (first weight taken). Logging out does not remove it, but you must log in again.') : bi('ફરી લૉગિન કરવું પડશે.', 'You must log in again.'), style: ts(14, h: 1.4)),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.of(c).pop(false), child: Text(bi('ના', 'No'), style: ts(14, w: FontWeight.w700, c: Pal.muted))),
          TextButton(onPressed: () => Navigator.of(c).pop(true), child: Text(bi('લૉગ આઉટ', 'Log out'), style: ts(14, w: FontWeight.w800, c: Pal.bad))),
        ],
      ),
    );
    if (ok != true) return;
    if (mounted) Navigator.of(context).popUntil((Route<dynamic> r) => r.isFirst);
    await live.logout();
  }

  // ------------------------------------------------------------------ weighing from the owner's phone
  String _remoteError() {
    switch (kantaRemote.errKind) {
      case 'missing':
        return bi('Supabase માં રિમોટનું SQL (supabase-kanta-remote.sql) હજી ચલાવ્યું નથી - એ પછી જ ફોનથી વજન ચાલશે.', 'The SQL for remote weighing (supabase-kanta-remote.sql) has not been run in Supabase yet - phone weighing works only after that.');
      case 'offline':
        return bi('ઇન્ટરનેટ નથી - ફોન સુધી જોડાણ થતું નથી (નેટ આવતાં જાતે ચાલશે).', 'No internet - the phone cannot be reached (it works by itself when the internet is back).');
      case 'perm':
        return bi('આ લૉગિનને પરવાનગી નથી (waybridge / admin જોઈએ): ${kantaRemote.error}', 'This login has no permission (needs waybridge / admin): ${kantaRemote.error}');
    }
    return kantaRemote.error;
  }

  Widget _remote() {
    final KantaRemoteHost h = kantaRemote;
    final String err = h.error.isEmpty ? '' : _remoteError();
    return KCard(
      icon: 'phone',
      title: bi('ફોનથી વજન (રિમોટ)', 'Weighing from the phone (remote)'),
      sub: bi('માલિક ફોનથી ગાડી તોલી શકે', 'The owner can weigh from his phone'),
      trailing: KPill(h.on ? bi('ચાલુ', 'ON') : bi('બંધ', 'OFF'), tone: h.on ? 'violet' : 'slate', dot: true),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          ChipRow(labels: <String>[bi('બંધ', 'OFF'), bi('ચાલુ', 'ON')], index: h.on ? 1 : 0, onChanged: (int i) => unawaited(h.setOn(i == 1))),
          const SizedBox(height: 8),
          Text(
            h.on
                ? bi('ચાલુ છે: માલિક Balaji Pro (ફોન) માં "કાંટો રિમોટ" ખોલી ગાડી નંબર લખી વજન લઈ શકે છે. વજન હંમેશાં કાંટા પર સ્થિર ઊભેલી ગાડીનું જ લેવાય છે અને નોંધમાં "(phone)" સાથે નામ લખાય છે.', 'ON: the owner can open "Remote Weighing" in Balaji Pro (phone), write the vehicle number and take the weight. Only a vehicle standing still on the platform is weighed, and the entry carries the name with "(phone)".')
                : bi('બંધ છે: ફોનથી કોઈ વજન નહીં લેવાય. (લાઇવ વજન માલિકને જોવા મળે છે.)', 'OFF: nothing can be weighed from a phone. (The owner can still see the live weight.)'),
            style: ts(12.5, c: h.on ? Pal.ok : Pal.muted, w: FontWeight.w700),
          ),
          if (err.isNotEmpty) ...<Widget>[const SizedBox(height: 6), Text(err, style: ts(12, c: Pal.bad, w: FontWeight.w700))],
          if (h.on && err.isEmpty) ...<Widget>[
            const SizedBox(height: 6),
            Text('${h.lastPublish == null ? bi('સર્વર પર હજી મોકલ્યું નથી', 'Not sent to the server yet') : '${bi('સર્વર પર છેલ્લું અપડેટ', 'Last update to the server')}: ${hm(h.lastPublish!)}'}${h.lastCmd.isEmpty ? '' : '\n${bi('છેલ્લો હુકમ', 'Last request')}: ${h.lastCmd}'}', style: ts(11.5, c: Pal.faint)),
          ],
        ],
      ),
    );
  }

  // ------------------------------------------------------------------ entries + history (print again later)
  static String _dm(DateTime d) {
    const List<String> mon = <String>['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return '${d.day < 10 ? '0' : ''}${d.day} ${mon[d.month - 1]}';
  }

  Widget _act(String text, VoidCallback onTap, {Color? c}) => InkWell(onTap: onTap, child: Padding(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6), child: Text(text, style: ts(13, c: c ?? Pal.brand, w: FontWeight.w800))));

  Widget _entries() {
    final DateTime n = DateTime.now();
    final bool today0 = !_all;
    final List<SlipRec> list = <SlipRec>[
      for (final SlipRec r in KantaHistory.search(_find.text, day: today0 ? n : null))
        if (_type == 0 || (_type == 1 && !r.outside) || (_type == 2 && r.outside)) r,
    ];
    final List<SlipRec> dayAll = KantaHistory.search('', day: n).where((SlipRec r) => !r.undone).toList();
    final int mill = dayAll.where((SlipRec r) => !r.outside).length;
    final List<SlipRec> road = dayAll.where((SlipRec r) => r.outside).toList();
    final double roadCh = road.fold(0.0, (double a, SlipRec r) => a + r.charges);
    final Set<String> mine = <String>{for (final SlipRec r in KantaHistory.items) r.rst};
    final List<Kanta> server = <Kanta>[
      for (final Kanta k in live.kantas)
        if (today0 && _type != 2 && k.at.year == n.year && k.at.month == n.month && k.at.day == n.day && !mine.contains(k.rst)) k,
    ]..sort((Kanta a, Kanta b) => b.at.compareTo(a.at));
    final double netToday = dayAll.fold(0.0, (double a, SlipRec r) => a + r.net);
    return KCard(
      icon: 'receipt',
      title: bi('એન્ટ્રી અને સ્લિપ', 'Entries and slips'),
      sub: bi('જૂની સ્લિપ ફરી છાપવી હોય તો "બધી" પસંદ કરી ગાડી નંબર / RST લખી શોધો.', 'To print an old slip again choose "All" and search by vehicle number / RST.'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <Widget>[
              KStat(bi('આજે મિલની', 'Mill today'), '$mill', tone: 'green'),
              KStat(bi('આજે બહારની', 'Road today'), '${road.length}', tone: 'amber'),
              KStat(bi('આજનું ચોખ્ખું', 'Net today'), '${grp(netToday, dec: 0)} KG', tone: 'blue'),
              if (roadCh > 0) KStat(bi('ચાર્જ', 'Charges'), '₹${grp(roadCh, dec: 0)}', tone: 'slate'),
            ],
          ),
          const SizedBox(height: 12),
          ChipRow(labels: <String>[bi('આજની', 'Today'), bi('બધી (history)', 'All (history)')], index: _all ? 1 : 0, onChanged: (int i) => setState(() => _all = i == 1)),
          const SizedBox(height: 8),
          ChipRow(labels: <String>[bi('બંને', 'Both'), bi('મિલની', 'Mill'), bi('બહારની', 'Road')], index: _type, onChanged: (int i) => setState(() => _type = i)),
          const SizedBox(height: 10),
          Focus(
            onKeyEvent: (FocusNode _, KeyEvent e) {
              if (e is KeyDownEvent && e.logicalKey == LogicalKeyboardKey.escape) {
                if (_find.text.isNotEmpty) {
                  _find.clear();
                  setState(() {});
                } else {
                  unawaited(Navigator.of(context).maybePop());
                }
                return KeyEventResult.handled;
              }
              return KeyEventResult.ignored;
            },
            child: FieldX(label: '${bi('શોધો (ગાડી / RST / પાર્ટી / માલ / ગામ)', 'Search (vehicle / RST / party / material / city)')}  (F6)', controller: _find, focusNode: _findF, stacked: true, onChanged: (String _) => setState(() {})),
          ),
          const SizedBox(height: 8),
          if (list.isEmpty && server.isEmpty) Text(_all || _find.text.trim().isNotEmpty ? bi('કોઈ સ્લિપ મળી નહીં.', 'No slip found.') : bi('આજે હજી કોઈ એન્ટ્રી નથી.', 'No entry yet today.'), style: ts(12.5, c: Pal.faint)),
          for (final SlipRec r in list.take(40)) _slipRow(r, n),
          if (list.length > 40) Padding(padding: const EdgeInsets.only(top: 6), child: Text(bi('પહેલી 40 દેખાય છે - શોધ વડે ઘટાડો.', 'First 40 shown - narrow it with the search.'), style: ts(11.5, c: Pal.faint))),
          if (server.isNotEmpty) ...<Widget>[
            const Divider(height: 18),
            Text(bi('સર્વર પર આજની (અહીંથી નહીં બનેલી)', 'On the server today (not made here)'), style: ts(12, w: FontWeight.w800, c: Pal.muted)),
            for (final Kanta k in server.take(20))
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 3),
                child: Row(
                  children: <Widget>[
                    SizedBox(width: 70, child: Text(k.rst.isEmpty ? '-' : 'RST ${k.rst}', style: ts(12, c: Pal.muted))),
                    Expanded(child: Text(k.vehicle.isEmpty ? '-' : k.vehicle, style: ts(13, w: FontWeight.w700))),
                    Text('${k.net == null ? '-' : grp(k.net!, dec: 0)} KG', style: ts(13, w: FontWeight.w700, tab: true)),
                    const SizedBox(width: 10),
                    Text(hm(k.at), style: ts(12, c: Pal.faint, tab: true)),
                  ],
                ),
              ),
          ],
          if (KantaLog.lastPath.isNotEmpty) ...<Widget>[
            const SizedBox(height: 8),
            Text('${bi('લેપટોપમાં કૉપી', 'Copy on this laptop')}: ${KantaLog.lastPath}', style: ts(11, c: Pal.faint)),
          ],
        ],
      ),
    );
  }

  /// One line: did the slip go on WhatsApp by itself?
  Widget _waStatus(WaJob j) {
    String t;
    Color c;
    if (j.state == 'sent') {
      t = '✓ WhatsApp ${bi('ગયું', 'sent')}${j.how == 'pic' ? ' (${bi('ફોટો', 'picture')})' : ''} · +91 ${j.to}';
      c = Pal.ok;
    } else if (j.state == 'wait') {
      t = '⏳ WhatsApp ${bi('જવાનું બાકી', 'waiting')} · +91 ${j.to}${j.err.isEmpty ? '' : ' · ${j.err}'}';
      c = Pal.warn;
    } else {
      t = '✗ WhatsApp ${bi('ગયું નથી', 'not sent')}${j.err.isEmpty ? '' : ': ${j.err}'}';
      c = Pal.bad;
    }
    return Text(t, style: ts(11.5, w: FontWeight.w700, c: c));
  }

  Widget _slipRow(SlipRec r, DateTime now) {
    final bool isToday = r.at.year == now.year && r.at.month == now.month && r.at.day == now.day;
    final Color tc = r.undone ? Pal.faint : Pal.ink;
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 3),
      padding: const EdgeInsets.fromLTRB(10, 8, 6, 4),
      decoration: BoxDecoration(border: Border.all(color: Pal.line)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Row(
            children: <Widget>[
              SizedBox(width: 62, child: Text('${_dm(r.at)}\n${hm(r.at)}', style: ts(11.5, c: Pal.muted, tab: true))),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text('${r.outside ? bi('સ્લિપ', 'Slip') : 'RST'} ${r.rst} · ${r.vehicle}${r.outside ? '  (${bi('બહારની', 'road')})' : ''}', style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.w800, color: r.outside && !r.undone ? Pal.warn : tc, decoration: r.undone ? TextDecoration.lineThrough : null)),
                    Text('${grp(r.gross, dec: 0)} − ${grp(r.tare, dec: 0)} = ${grp(r.net, dec: 0)} KG${r.charges > 0 ? ' · ₹${grp(r.charges, dec: 0)}' : ''}', style: ts(12, c: Pal.muted, tab: true)),
                    if (<String>[r.party, r.material, r.city, r.mobile].any((String t) => t.isNotEmpty)) Text(<String>[r.party, r.material, r.city, if (r.mobile.isNotEmpty) '📞 ${r.mobile}'].where((String t) => t.isNotEmpty).join(' · '), style: ts(12, c: Pal.muted)),
                    if (r.by.isNotEmpty) Text('📱 ${r.by}', style: ts(11.5, c: Pal.faint)),
                    if (!r.undone)
                      for (final WaJob wj in KantaWa.jobsOf(r.rst).reversed) _waStatus(wj),
                  ],
                ),
              ),
            ],
          ),
          if (r.undone)
            Padding(padding: const EdgeInsets.only(bottom: 4), child: Text(bi('પાછી લીધેલી (રદ)', 'Taken back (cancelled)'), style: ts(12, w: FontWeight.w800, c: Pal.bad)))
          else
            Wrap(
              children: <Widget>[
                _act(bi('પ્રિન્ટ', 'Print'), () => printSlip(r)),
                _act('WhatsApp', () => sendSlipWhatsApp(r), c: Pal.ok),
                if (slipRecipients(r).length > 1) _act('WhatsApp ${slipRecipients(r)[1].mill ? bi('મિલ', 'mill') : bi('ડ્રાઇવર', 'driver')}', () => sendSlipWhatsApp(r, which: 1), c: Pal.ok),
                if (KantaWa.jobsOf(r.rst).any((WaJob x) => x.state == 'failed')) _act(bi('ફરી મોકલો', 'Send again'), () {
                  for (final WaJob x in KantaWa.jobsOf(r.rst).where((WaJob y) => y.state == 'failed')) {
                    unawaited(KantaWa.again(x));
                  }
                }, c: Pal.warn),
                if (isToday) _act(bi('પાછું લો', 'Take back'), () => _takeBack(r), c: Pal.warn),
              ],
            ),
        ],
      ),
    );
  }

  Future<void> _takeBack(SlipRec r) async {
    final bool? ok = await showDialog<bool>(
      context: context,
      builder: (BuildContext c) => AlertDialog(
        title: Text(bi('એન્ટ્રી પાછી લેવી?', 'Take this entry back?'), style: ts(17, w: FontWeight.w800)),
        content: Text('${r.outside ? bi('સ્લિપ', 'Slip') : 'RST'} ${r.rst} · ${r.vehicle} · ${grp(r.net, dec: 0)} KG${r.outside ? '\n${bi('ફક્ત લેપટોપની સ્લિપ રદ થશે.', 'Only the laptop slip is cancelled.')}' : ''}', style: ts(14, h: 1.4)),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.of(c).pop(false), child: Text(bi('ના', 'No'), style: ts(14, w: FontWeight.w700, c: Pal.muted))),
          TextButton(onPressed: () => Navigator.of(c).pop(true), child: Text(bi('હા, પાછી લો', 'Yes, take back'), style: ts(14, w: FontWeight.w800, c: Pal.bad))),
        ],
      ),
    );
    if (ok != true) return;
    final AutoMade m = kantaUsb.made.firstWhere((AutoMade x) => x.rst == r.rst && x.vehicle == r.vehicle, orElse: () => kantaUsb.autoMadeOf(r));
    final String why = await kantaUsb.undoAuto(m);
    app.toast(why.isEmpty ? bi('પાછી લીધી', 'Taken back') : why);
  }

  // ------------------------------------------------------------------ technical (cable, speed)
  static const List<(String, int, int, int)> _modes = <(String, int, int, int)>[
    ('8N1', 8, 0, 1),
    ('7E1', 7, 2, 1),
    ('8E1', 8, 2, 1),
    ('8N2', 8, 0, 2),
  ];

  // ------------------------------------------------------------------ WhatsApp settings
  Future<void> _setWaApi(bool on) async {
    if (!on) {
      await KantaLog.setWaApi(false);
      if (mounted) setState(() => _waMsg = '');
      return;
    }
    setState(() {
      _waBusy = true;
      _waMsg = '';
    });
    final String e = await KantaWa.test();
    await KantaLog.setWaApi(e.isEmpty);
    if (!mounted) return;
    setState(() {
      _waBusy = false;
      _waMsg = e;
    });
    if (e.isEmpty) app.toast(bi('WhatsApp જોડાયું - હવે સ્લિપ જાતે જશે', 'WhatsApp connected - slips now go by themselves'));
  }

  Future<void> _waTest() async {
    setState(() {
      _waBusy = true;
      _waMsg = '';
    });
    final String e = await KantaWa.test();
    if (!mounted) return;
    setState(() {
      _waBusy = false;
      _waMsg = e;
    });
    if (e.isEmpty) app.toast('${bi('WhatsApp બરાબર છે', 'WhatsApp is fine')}: ${KantaWa.number}');
  }

  /// Shows the picture a WhatsApp slip is sent as (the same drawing as the one that goes out).
  void _showPic() {
    final SlipRec s = _sampleSlip();
    showDialog<void>(
      context: context,
      builder: (BuildContext c) => AlertDialog(
        title: Text(bi('WhatsApp પર આવો ફોટો જશે', 'This picture goes on WhatsApp'), style: ts(16, w: FontWeight.w800)),
        content: SizedBox(
          width: 640,
          child: SingleChildScrollView(child: Image.memory(slipPng(slipEpson(s, style: KantaLog.style), width: slipWidth(KantaLog.style)), fit: BoxFit.contain)),
        ),
        actions: <Widget>[TextButton(onPressed: () => Navigator.of(c).pop(), child: Text(bi('બંધ', 'Close'), style: ts(14, w: FontWeight.w700, c: Pal.muted)))],
      ),
    );
  }

  List<Widget> _waSection() {
    final bool api = KantaLog.waApi;
    return <Widget>[
      ChipRow(labels: <String>[bi('બંધ', 'Off'), bi('મિલની ગાડી', 'Mill vehicles'), bi('બધી ગાડી', 'All vehicles')], index: KantaLog.waMode, onChanged: (int i) => KantaLog.setWaMode(i)),
      const SizedBox(height: 4),
      Text(
        KantaLog.waMode == 0
            ? bi('બંધ: સ્લિપ WhatsApp પર જાતે નહીં જાય (એન્ટ્રી પરથી "WhatsApp" દબાવી શકાય).', 'Off: slips are not sent by themselves (you can still tap "WhatsApp" on an entry).')
            : bi('બીજું (ખાલી) વજન લેતાં જ સ્લિપ ગાડી પર લખેલા મોબાઇલ (કે ચિઠ્ઠીના ખેડૂતના મોબાઇલ) પર જાય છે. મોબાઇલ ન હોય તો કશું જતું નથી.', 'Right after the second (empty) weight the slip goes to the mobile written on the vehicle (or of the farmer on the chit). Nothing is sent when there is no mobile.'),
        style: ts(11.5, c: Pal.muted),
      ),
      if (KantaLog.waMode != 0) ...<Widget>[
        const SizedBox(height: 10),
        FieldX(
          label: bi('મિલનો ફિક્સ WhatsApp નંબર', 'Fixed WhatsApp number of the mill'),
          controller: _mill,
          stacked: true,
          hint: '98250 12345',
          keyboard: TextInputType.phone,
          onChanged: (String v) => unawaited(KantaLog.setWaMill(v)),
        ),
        const SizedBox(height: 4),
        Text(
          KantaLog.millNumbers.isEmpty
              ? bi('એક વાર લખી દો: મિલની દરેક ગાડીની સ્લિપ આ નંબર પર જશે, ઉપરાંત વજન વખતે લખેલા નંબર પર પણ. બહારની ગાડીની સ્લિપ ફક્ત વજન વખતે લખેલા નંબર પર જાય છે (ફિક્સ નંબર પર નહીં). એકથી વધુ નંબર હોય તો અલ્પવિરામ (,) થી જુદા કરો. બહારની ગાડી માટે ઉપર "બધી ગાડી" પસંદ કરો.', 'Write it once: the slip of every MILL vehicle goes to this number, and also to the number written at the weighing. The slip of a road vehicle goes only to the number written at the weighing (never to the fixed number). More than one number: separate with a comma (,). For road vehicles choose "All vehicles" above.')
              : '${bi('મિલની ગાડી → આ નંબર', 'Mill vehicles → this number')}: ${KantaLog.millNumbers.map((String n) => '+91 $n').join(', ')}  +  ${bi('વજન વખતે લખેલો નંબર', 'the number written at the weighing')}. ${bi('બહારની ગાડી → ફક્ત વજન વખતે લખેલો નંબર (બધી ગાડી પસંદ હોય તો).', 'Road vehicles → only the number written at the weighing (when "All vehicles" is chosen).')}',
          style: ts(11.5, c: KantaLog.millNumbers.isEmpty ? Pal.muted : Pal.ok, w: KantaLog.millNumbers.isEmpty ? FontWeight.w500 : FontWeight.w700, h: 1.35),
        ),
        if (_mill.text.trim().isNotEmpty && KantaLog.millNumbers.isEmpty) Text(bi('આ નંબર ચાલશે નહીં - 10 આંકડાનો મોબાઇલ નંબર લખો.', 'This number will not work - write a 10 digit mobile number.'), style: ts(11.5, c: Pal.bad, w: FontWeight.w700)),
        const SizedBox(height: 10),
        Text(bi('કેવી રીતે મોકલવું', 'How to send'), style: ts(12.5, w: FontWeight.w700, c: Pal.muted)),
        const SizedBox(height: 4),
        ChipRow(labels: <String>[bi('ચૅટ ખુલે (Send દબાવવું)', 'Open chat (press Send)'), bi('જાતે જાય (WhatsApp Business)', 'By itself (WhatsApp Business)')], index: api ? 1 : 0, onChanged: (int i) => unawaited(_setWaApi(i == 1))),
        const SizedBox(height: 4),
        Text(
          api
              ? bi('જાતે: કોઈએ કશું દબાવવાનું નથી. સ્લિપ સર્વર દ્વારા તમારા WhatsApp Business નંબરથી જાય છે; નેટ ન હોય તો લેપટોપમાં રહે છે અને નેટ આવતાં જાય છે. દરેક સ્લિપનું પરિણામ "kanta-wa-મહિનો.csv" માં લખાય છે.', 'By itself: nobody presses anything. The slip goes from your WhatsApp Business number through the server; without internet it waits on the laptop and goes when the internet is back. Every result is written to "kanta-wa-YYYY-MM.csv".')
              : bi('ચૅટ: દરેક ગાડી પછી WhatsApp ખુલે છે અને ફક્ત Send દબાવવું પડે (WhatsApp એપને જાતે મોકલવા દેતું નથી). ગાડી-ગાડી દબાવવું ન પડે તે માટે "જાતે જાય" પસંદ કરો - તેને WhatsApp Business Platform નું સેટઅપ જોઈએ (માર્ગદર્શિકા જુઓ).', 'Chat: WhatsApp opens after every vehicle and you only press Send (WhatsApp never lets an app send by itself). To avoid pressing for every vehicle choose "By itself" - it needs the WhatsApp Business Platform set-up (see the guide).'),
          style: ts(11.5, c: Pal.muted),
        ),
        if (_waBusy) Padding(padding: const EdgeInsets.only(top: 6), child: Text(bi('તપાસું છું…', 'Checking…'), style: ts(12.5, w: FontWeight.w700, c: Pal.brand))),
        if (_waMsg.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text('${bi('WhatsApp ચાલુ થયું નહીં', 'WhatsApp did not start')}: $_waMsg', style: ts(12.5, w: FontWeight.w700, c: Pal.bad))),
        if (api) ...<Widget>[
          const SizedBox(height: 10),
          Text(bi('WhatsApp પર સ્લિપ કેવી જાય', 'How the slip goes on WhatsApp'), style: ts(12.5, w: FontWeight.w700, c: Pal.muted)),
          const SizedBox(height: 4),
          ChipRow(labels: <String>[bi('ફોટો (પ્રિન્ટ જેવી)', 'Picture (like the print)'), bi('લખાણ', 'Writing')], index: KantaLog.waPicture ? 0 : 1, onChanged: (int i) => unawaited(KantaLog.setWaPicture(i == 0))),
          const SizedBox(height: 4),
          Text(
            KantaLog.waPicture
                ? bi('ફોટો: સ્લિપ છાપેલી સ્લિપ જેવા ચિત્ર (PNG) તરીકે જાય છે. ફોટા માટે Meta માં ફોટાવાળું ટેમ્પ્લેટ મંજૂર થયેલું જોઈએ (WHATSAPP-SETUP.md, 5c). જ્યાં સુધી તે મંજૂર નથી ત્યાં સુધી સ્લિપ લખાણ તરીકે જાય છે - કોઈ સ્લિપ ખોવાતી નથી.', 'Picture: the slip goes as a picture (PNG) that looks like the printed slip. It needs the picture template approved by Meta (WHATSAPP-SETUP.md, 5c). Until it is approved the slip goes as plain writing - no slip is lost.')
                : bi('લખાણ: સ્લિપ ટેમ્પ્લેટના લખાણ તરીકે જાય છે.', 'Writing: the slip goes as the text of the template.'),
            style: ts(11.5, c: Pal.muted),
          ),
          if (KantaLog.waPicture) ...<Widget>[
            const SizedBox(height: 6),
            Align(alignment: Alignment.centerLeft, child: Btn(bi('ફોટો કેવો દેખાશે', 'Show the picture'), icon: 'eye', kind: BtnKind.outline, dense: true, onTap: _showPic)),
          ],
          const SizedBox(height: 6),
          Text(
            '${KantaWa.number.isEmpty ? '' : '${bi('મોકલનાર', 'Sender')}: ${KantaWa.number}${KantaWa.name.isEmpty ? '' : ' (${KantaWa.name})'}\n'}${bi('આજે ગયેલી', 'Sent today')}: ${KantaWa.sentToday} · ${bi('બાકી', 'waiting')}: ${KantaWa.waiting} · ${bi('નિષ્ફળ', 'failed')}: ${KantaWa.failed}',
            style: ts(12.5, w: FontWeight.w700, c: KantaWa.setupError.isEmpty ? Pal.ok : Pal.bad),
          ),
        ],
        const SizedBox(height: 8),
        Wrap(
          spacing: 10,
          runSpacing: 8,
          children: <Widget>[
            Btn(bi('WhatsApp ટેસ્ટ કરો', 'Test WhatsApp'), icon: 'check', kind: BtnKind.outline, onTap: _waBusy ? null : _waTest),
            if (KantaWa.failed > 0)
              Btn(bi('નિષ્ફળ ફરી મોકલો', 'Send failed again'), icon: 'sync', kind: BtnKind.tonal, onTap: () {
                for (final WaJob j in KantaWa.jobs.where((WaJob x) => x.state == 'failed').toList()) {
                  unawaited(KantaWa.again(j));
                }
              }),
          ],
        ),
      ],
    ];
  }


  // ------------------------------------------------------------------ cards
  Widget _strip(String icon, String tone, String text, {VoidCallback? onTap}) {
    final Tone t = Pal.tone(tone);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: t.bg,
        borderRadius: BorderRadius.circular(Pal.rad(12)),
        child: InkWell(
          borderRadius: BorderRadius.circular(Pal.rad(12)),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Row(
              children: <Widget>[
                Icon(ic(icon), size: 18, color: t.fg),
                const SizedBox(width: 10),
                Expanded(child: Text(text, style: ts(13, w: FontWeight.w700, c: t.fg))),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _cable() {
    final KantaUsbService u = kantaUsb;
    final int mi = _modes.indexWhere(((String, int, int, int) m) => m.$2 == u.dataBits && m.$3 == u.parity && m.$4 == u.stopBits);
    return KCard(
      icon: 'scale',
      title: bi('કાંટો - કેબલ અને વજન', 'Scale - cable and weight'),
      sub: u.connected ? '${u.chosen?.label ?? ''} · ${u.modeText}' : bi('કેબલ જોડાયેલો નથી', 'Cable not connected'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
      Row(
        children: <Widget>[
          SizedBox(width: 92, child: Text('COM port', style: ts(13, w: FontWeight.w700))),
          Expanded(
            child: Align(
              alignment: Alignment.centerLeft,
              child: u.devices.isEmpty
                  ? Text(bi('કોઈ નથી', 'None'), style: ts(13, c: Pal.faint))
                  : PickX<UsbDev>(label: u.chosen?.label ?? '-', items: u.devices, text: (UsbDev d) => d.label, onSelected: u.choose),
            ),
          ),
          Btn(bi('ફરી શોધો', 'Search again'), kind: BtnKind.ghost, dense: true, onTap: u.refresh),
        ],
      ),
      const SizedBox(height: 10),
      Row(
        children: <Widget>[
          SizedBox(width: 92, child: Text(bi('સ્પીડ', 'Speed'), style: ts(13, w: FontWeight.w700))),
          Expanded(
            child: Align(
              alignment: Alignment.centerLeft,
              child: PickX<int>(label: '${u.baud} baud', items: kUsbBauds, text: (int b) => '$b', onSelected: (int b) => u.setMode(baud: b)),
            ),
          ),
        ],
      ),
      const SizedBox(height: 10),
      ChipRow(
        labels: <String>[for (final (String, int, int, int) m in _modes) m.$1],
        index: mi < 0 ? 0 : mi,
        onChanged: (int i) => u.setMode(bits: _modes[i].$2, par: _modes[i].$3, stop: _modes[i].$4),
      ),

      const SizedBox(height: 10),
      Wrap(
        spacing: 10,
        runSpacing: 8,
        children: <Widget>[
          if (u.connected || u.trying) Btn(bi('છૂટો કરો', 'Disconnect'), kind: BtnKind.outline, onTap: u.disconnect) else Btn(bi('જોડો', 'Connect'), icon: 'sync', onTap: (u.chosen != null && !u.busy) ? u.connect : null),
          Btn(bi('ડેટા ફોલ્ડર ખોલો', 'Open data folder'), icon: 'folder', kind: BtnKind.outline, onTap: () async {
            final Directory? d = await KantaLog.folder();
            if (d == null || !await openFileOnPc(d.path)) app.toast(bi('ફોલ્ડર ખુલ્યું નહીં: Documents\\Balaji Kanta', 'Could not open the folder: Documents\\Balaji Kanta'));
          }),
          Btn(bi('રિપોર્ટ કૉપી કરો', 'Copy report'), icon: 'copy', kind: BtnKind.tonal, onTap: () async {
            await Clipboard.setData(ClipboardData(text: u.report()));
            app.toast(bi('કૉપી થયું - મને મોકલો', 'Copied - send it to me'));
          }),
        ],
      ),
        ],
      ),
    );
  }

  Widget _printCard() {
    return KCard(
      icon: 'print',
      title: bi('પ્રિન્ટ', 'Printing'),
      sub: KantaLog.printMode == 1 && DirectPrint.supported ? 'Epson direct' : bi('બ્રાઉઝર પ્રિન્ટ', 'Browser print'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          const SizedBox(height: 4),
      if (DirectPrint.supported) ...<Widget>[
        Text(bi('પ્રિન્ટ રીત', 'Print method'), style: ts(12.5, w: FontWeight.w700, c: Pal.muted)),
        const SizedBox(height: 4),
        ChipRow(labels: <String>[bi('બ્રાઉઝર (કોઈ પણ પ્રિન્ટર)', 'Browser (any printer)'), bi('Epson direct (ઝડપી, ફક્ત ટેક્સ્ટ)', 'Epson direct (fast, text only)')], index: KantaLog.printMode, onChanged: (int i) {
          KantaLog.setPrintMode(i);
          if (i == 1 && !_prnTried) _findPrinters();
        }),
        const SizedBox(height: 4),
        Text(
          KantaLog.printMode == 1
              ? bi('Epson direct: સ્લિપ સીધી ડોટ-મેટ્રિક્સ પ્રિન્ટરને ટેક્સ્ટ તરીકે જાય છે - ઝડપી, અને સ્લિપ પૂરી થતાં જ કાગળ સાચી જગ્યાએ અટકે છે. ચાલે નહીં તો જાતે બ્રાઉઝરથી પ્રિન્ટ થાય છે.', 'Epson direct: the slip goes straight to the dot-matrix printer as text - fast, and the paper stops at the right place after each slip. If it fails the browser prints it instead.')
              : bi('બ્રાઉઝર: પ્રિન્ટ વિન્ડો ખુલે છે (Windows ડ્રાઇવર થકી). Epson LX-310 માટે "Epson direct" વધુ સારું.', 'Browser: the print window opens (through the Windows driver). For the Epson LX-310 "Epson direct" is better.'),
          style: ts(11.5, c: Pal.muted),
        ),
        if (KantaLog.printMode == 1) ...<Widget>[
          const SizedBox(height: 8),
          Row(
            children: <Widget>[
              SizedBox(width: 92, child: Text(bi('પ્રિન્ટર', 'Printer'), style: ts(13, w: FontWeight.w700))),
              Expanded(
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: PickX<String>(
                    label: KantaLog.printerName.isEmpty ? bi('આપોઆપ (Epson જાતે શોધશે)', 'Automatic (finds the Epson itself)') : KantaLog.printerName,
                    items: <String>['', for (final WinPrinter w in _prn) w.name],
                    text: (String n) => n.isEmpty ? bi('આપોઆપ (Epson જાતે શોધશે)', 'Automatic (finds the Epson itself)') : n,
                    onSelected: KantaLog.setPrinterName,
                  ),
                ),
              ),
              Btn(_prnBusy ? '…' : bi('શોધો', 'Find'), kind: BtnKind.ghost, dense: true, onTap: _prnBusy ? null : _findPrinters),
            ],
          ),
          if (_prnTried && !_prnBusy)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: _usbEpson
                  ? Text(bi('USB પર Epson પ્રિન્ટર મળ્યું ✓ - ડ્રાઇવર વગર પણ સીધું છપાશે.', 'Epson printer found on USB ✓ - prints straight, even with no driver.'), style: ts(11.5, w: FontWeight.w700, c: Pal.ok))
                  : (_prn.isEmpty
                      ? Text(bi('Epson મળ્યું નહીં - USB કેબલ અને પ્રિન્ટર ચાલુ (ON) છે કે જુઓ, પછી "શોધો" દબાવો. ડ્રાઇવર નાખવાની જરૂર નથી.', 'No Epson found - check the USB cable and that the printer is ON, then press Find. No driver needed.'), style: ts(11.5, c: Pal.warn))
                      : const SizedBox.shrink()),
            ),
          const SizedBox(height: 6),
          ChipRow(
            labels: <String>[bi('ન ચાલે તો ફક્ત સંદેશ', 'If it fails: only a message'), bi('ન ચાલે તો બ્રાઉઝર પેજ પણ ખોલો', 'If it fails: also open the browser page')],
            index: KantaLog.browserFallback ? 1 : 0,
            onChanged: (int i) => KantaLog.setBrowserFallback(i == 1),
          ),
          const SizedBox(height: 8),
          Text(bi('સ્લિપ પછી કાગળ કેટલો ખસે (એક સ્લિપનું પાનું)', 'How far the paper moves after a slip (one slip = one page)'), style: ts(12.5, w: FontWeight.w700, c: Pal.muted)),
          const SizedBox(height: 4),
          ChipRow(
            labels: <String>[bi('પ્રિન્ટરનું પાનું', 'Printer page'), '3 in', '4 in', '5.5 in', '8 in'],
            index: <int>[0, 18, 24, 33, 48].indexOf(KantaLog.pageLines).clamp(0, 4),
            onChanged: (int i) => KantaLog.setPageLines(<int>[0, 18, 24, 33, 48][i]),
          ),
          const SizedBox(height: 8),
          ChipRow(labels: <String>[bi('સામાન્ય છાપ', 'Normal print'), bi('ઘેરી છાપ (કાર્બન કૉપી)', 'Dark print (carbon copies)')], index: KantaLog.bold ? 1 : 0, onChanged: (int i) => KantaLog.setBold(i == 1)),
        ],
        const SizedBox(height: 10),
      ],
      ChipRow(labels: <String>[bi('Dot-matrix (Epson, સાદી)', 'Dot-matrix (Epson, plain)'), bi('સામાન્ય (A5 બૉક્સ)', 'Normal (A5 box)')], index: KantaLog.dotMatrix ? 0 : 1, onChanged: (int i) => KantaLog.setDotMatrix(i == 0)),
      const SizedBox(height: 8),
      ChipRow(labels: <String>[bi('Auto print બંધ', 'Auto print off'), bi('Auto print ચાલુ', 'Auto print on')], index: KantaLog.autoPrint ? 1 : 0, onChanged: (int i) => KantaLog.setAutoPrint(i == 1)),
      const SizedBox(height: 4),
      Text(KantaLog.printMode == 1 && DirectPrint.supported ? bi('ચાલુ હોય તો દરેક એન્ટ્રી સેવ થતાં જ સ્લિપ સીધી Epson પર છપાય છે - બીજું પેજ ખુલતું નથી. Dot-matrix માં ફક્ત અંગ્રેજી અક્ષર છપાય છે.', 'When on, the slip prints straight on the Epson as soon as the entry is saved - no other page opens. The dot-matrix slip uses English letters only.') : bi('ચાલુ હોય તો દરેક એન્ટ્રી પછી પ્રિન્ટ વિન્ડો જાતે ખુલે છે (Print દબાવવું પડે). Dot-matrix માં ફક્ત અંગ્રેજી અક્ષર છપાય છે.', 'When on, the print window opens by itself after every entry (you press Print there). The dot-matrix slip uses English letters only.'), style: ts(11.5, c: Pal.muted)),
      const SizedBox(height: 8),
      Btn(bi('ટેસ્ટ સ્લિપ છાપો', 'Print a test slip'), icon: 'print', kind: BtnKind.outline, onTap: () => printSlip(_sampleSlip())),
        ],
      ),
    );
  }


  /// A made-up slip with every line filled - for the preview and the test print.
  SlipRec _sampleSlip() {
    final DateTime n = DateTime.now();
    return SlipRec(rst: '0', vehicle: 'GJ00AB0000', party: 'Test Party', gross: 11385, tare: 1595, grossAt: n.subtract(const Duration(minutes: 20)), tareAt: n, at: n, charges: 200, mobile: '9800000000', material: 'Magfadi', city: 'Rajkot');
  }

  void _setStyle(SlipStyle st) => unawaited(KantaLog.setStyle(st));

  Widget _slipField(String label, TextEditingController c, SlipStyle Function(SlipStyle s, String v) apply, {String? hint}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: FieldX(label: label, controller: c, hint: hint, stacked: true, onChanged: (String v) => _setStyle(apply(KantaLog.style, v))),
    );
  }

  /// "Slip layout": the name, address, phone numbers and footer printed on the slip, and which lines it shows - with a preview.
  Widget _slipCard() {
    final SlipStyle st = KantaLog.style;
    final SlipRec sample = _sampleSlip();
    final String plain = slipPlain(sample, style: st);
    final int lines = plain.split('\n').length;
    final int page = KantaLog.pageLines;
    final bool tooLong = KantaLog.printMode == 1 && DirectPrint.supported && page > 0 && lines > page;
    return KCard(
      icon: 'receipt',
      title: bi('સ્લિપની ગોઠવણ', 'Slip layout'),
      sub: st.title,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          const SizedBox(height: 4),
          Text(bi('સ્લિપ પર છપાતું નામ, સરનામું, ફોન નંબર વગેરે અહીં બદલો. નીચે સ્લિપ કેવી દેખાશે તે તરત દેખાય છે. ખાલી રાખેલી લાઇન છપાતી નથી.', 'Change the name, address, phone numbers etc. printed on the slip here. The preview below shows the slip at once. A line left empty is not printed.'), style: ts(11.5, c: Pal.muted, h: 1.4)),
          const SizedBox(height: 10),
          Text(bi('સ્લિપનું ફૉર્મેટ', 'Slip format'), style: ts(12.5, w: FontWeight.w700, c: Pal.muted)),
          const SizedBox(height: 4),
          ChipRow(labels: <String>[bi('Matrix ટર્મિનલ જેવું (80 કૉલમ)', 'Like the Matrix terminal (80 columns)'), bi('નાનું (46 કૉલમ)', 'Compact (46 columns)')], index: st.layout == 1 ? 0 : 1, onChanged: (int i) => _setLayout(i == 0)),
          const SizedBox(height: 4),
          Text(st.layout == 1 ? bi('Matrix જેવું: નામ મોટા અક્ષરમાં, બે કૉલમમાં માહિતી, વજન મોટા અક્ષરમાં. Epson direct માં કાગળનું પાનું "4 in" રાખો.', 'Like the Matrix: the name in big letters, two columns of fields, the weights in big letters. For Epson direct set the paper page to "4 in".') : bi('નાનું: 46 કૉલમની સાદી સ્લિપ (નાના કાગળ માટે).', 'Compact: a plain 46 column slip (for small paper).'), style: ts(11.5, c: Pal.muted, h: 1.35)),
          const SizedBox(height: 10),
          _slipField(bi('કાંટાનું / પેઢીનું નામ', 'Weighbridge / firm name'), _head, (SlipStyle s, String v) => s.copyWith(title: v.trim().isEmpty ? 'Balaji Industries' : v.trim())),
          _slipField(bi('સરનામું (નવી લાઇન માટે | લખો)', 'Address (write | for a new line)'), _addr, (SlipStyle s, String v) => s.copyWith(address: v), hint: 'MANDVI BHUJ HIGHWAY|AT MOTA ASAMBIYA MO-9537279421'),
          _slipField(bi('ફોન નંબર', 'Phone number(s)'), _phone, (SlipStyle s, String v) => s.copyWith(phone: v), hint: 'Ph: 98250 12345, 0281 2345678'),
          _slipField(bi('બીજી લાઇન (GST નં. વગેરે)', 'One more line (GST no. etc.)'), _xtra, (SlipStyle s, String v) => s.copyWith(extra: v), hint: 'GSTIN 24AAAAA0000A1Z5'),
          _slipField(bi('સ્લિપનું શીર્ષક', 'Slip title'), _sub, (SlipStyle s, String v) => s.copyWith(subtitle: v), hint: kSlipSubtitle),
          _slipField(bi('નીચેની લાઇન (આભાર વગેરે)', 'Bottom line (thank you etc.)'), _foot, (SlipStyle s, String v) => s.copyWith(footer: v), hint: 'Thank you - Visit again'),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Expanded(child: _slipField(bi('સહી (ડાબી)', 'Signature (left)'), _signL, (SlipStyle s, String v) => s.copyWith(signL: v))),
              const SizedBox(width: 8),
              Expanded(child: _slipField(bi('સહી (જમણી)', 'Signature (right)'), _signR, (SlipStyle s, String v) => s.copyWith(signR: v))),
            ],
          ),
          Text(bi('કઈ લાઇન છપાય', 'Which lines are printed'), style: ts(12.5, w: FontWeight.w700, c: Pal.muted)),
          const SizedBox(height: 4),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <Widget>[
              _lineChip(bi('માલ', 'Material'), st.showMaterial, (bool v) => _setStyle(st.copyWith(showMaterial: v))),
              _lineChip(bi('ગામ-શહેર', 'City'), st.showCity, (bool v) => _setStyle(st.copyWith(showCity: v))),
              _lineChip(bi('મોબાઇલ', 'Mobile'), st.showMobile, (bool v) => _setStyle(st.copyWith(showMobile: v))),
              _lineChip(bi('વજનનો સમય', 'Weight times'), st.showTimes, (bool v) => _setStyle(st.copyWith(showTimes: v))),
              _lineChip(bi('સહીની જગ્યા', 'Signatures'), st.showSign, (bool v) => _setStyle(st.copyWith(showSign: v))),
            ],
          ),
          const SizedBox(height: 10),
          Text(bi('સ્લિપ આવી છપાશે', 'The slip will print like this'), style: ts(12.5, w: FontWeight.w700, c: Pal.muted)),
          const SizedBox(height: 4),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: Pal.bg, border: Border.all(color: Pal.line), borderRadius: BorderRadius.circular(8)),
            child: FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerLeft,
              child: Text(plain, style: TextStyle(fontFamily: 'Courier New', fontFamilyFallback: <String>['Consolas', 'monospace'], fontSize: 12, height: 1.25, color: Pal.ink)),
            ),
          ),
          const SizedBox(height: 4),
          Text('${bi('સ્લિપ', 'The slip is')} $lines ${bi('લાઇનની છે', 'lines long')}', style: ts(11.5, c: tooLong ? Pal.warn : Pal.faint, w: tooLong ? FontWeight.w800 : FontWeight.w500)),
          if (tooLong) Text(bi('પ્રિન્ટરનું પાનું ($page લાઇન) સ્લિપ કરતાં નાનું છે - ઉપર "સ્લિપ પછી કાગળ કેટલો ખસે" માં મોટું (4 in કે 5.5 in) પસંદ કરો, નહીં તો સ્લિપ બે પાને કપાશે.', 'The printer page ($page lines) is shorter than the slip - choose a longer one (4 in or 5.5 in) under "How far the paper moves", or the slip will be split over two pages.'), style: ts(11.5, c: Pal.warn, h: 1.35)),
          Text(bi('Dot-matrix (Epson) માં ફક્ત અંગ્રેજી અક્ષર છપાય છે; A5 બૉક્સ સ્લિપમાં ગુજરાતી પણ ચાલે. WhatsApp ની સ્લિપમાં નામ, સરનામું, ફોન અને નીચેની લાઇન પણ જાય છે.', 'Dot-matrix (Epson) prints English letters only; the A5 box slip can also show Gujarati. The WhatsApp slip also carries the name, address, phone and bottom line.'), style: ts(11.5, c: Pal.muted, h: 1.35)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <Widget>[
              Btn(bi('ટેસ્ટ સ્લિપ છાપો', 'Print a test slip'), icon: 'print', kind: BtnKind.outline, dense: true, onTap: () => printSlip(sample)),
              Btn(bi('Matrix સ્લિપ પર પાછા', 'Back to the Matrix slip'), kind: BtnKind.ghost, dense: true, tabStop: false, onTap: _resetStyle),
            ],
          ),
        ],
      ),
    );
  }

  Widget _lineChip(String label, bool on, ValueChanged<bool> set) {
    return Btn(on ? '✓ $label' : '✗ $label', kind: on ? BtnKind.tonal : BtnKind.outline, dense: true, tabStop: false, onTap: () => set(!on));
  }

  /// Switch between the compact slip and the Matrix terminal slip. The first time Matrix is chosen with the name still unwritten, the name and
  /// the address of the weighbridge as the terminal printed them are filled in (they can be changed below).
  void _setLayout(bool matrix) {
    SlipStyle n = KantaLog.style.copyWith(layout: matrix ? 1 : 0);
    if (matrix && n.title == 'Balaji Industries' && n.address.trim().isEmpty) {
      n = n.copyWith(title: SlipStyle.shree.title, address: SlipStyle.shree.address, subtitle: '');
      _head.text = n.title;
      _addr.text = n.address;
      _sub.text = '';
    }
    _setStyle(n);
  }

  // ------------------------------------------------------------------ the Google Sheet
  Widget _sheetCard() {
    final int wait = KantaSheet.waiting;
    return KCard(
      icon: 'ledger',
      title: 'Google Sheet',
      sub: KantaSheet.enabled ? (wait > 0 ? bi('$wait બાકી (નેટ આવતાં જશે)', '$wait waiting (they go when the internet is back)') : bi('ચાલુ', 'On')) : bi('બંધ', 'Off'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          const SizedBox(height: 4),
          ChipRow(labels: <String>[bi('ચાલુ', 'On'), bi('બંધ', 'Off')], index: KantaSheet.enabled ? 0 : 1, onChanged: (int i) => unawaited(KantaSheet.setEnabled(i == 0))),
          const SizedBox(height: 6),
          Text(
            bi('મિલની ગાડીનું બીજું વજન લેતાં જ આ લેપટોપ પોતે Google Sheet માં આખી લાઇન મોકલે છે (RST, ગાડી, નેટ, ગ્રોસ, ટેર, પાર્ટી, માલ, ગામ, ચાર્જ, તારીખ-સમય) - સર્વર પર સેવ થાય કે ન થાય તેની રાહ જોયા વિના. નેટ ન હોય તો લેપટોપમાં રહે છે અને નેટ આવતાં જાતે જાય છે; એક એન્ટ્રીની એક જ લાઇન. બહારની ગાડી Sheet માં જતી નથી. પરિણામ "kanta-sheet-મહિનો.csv" માં લખાય છે.', 'Right after the second weight of a MILL vehicle this laptop sends the whole line to the Google Sheet itself (RST, vehicle, net, gross, tare, party, goods, town, charges, date-time) - without waiting for the save on the server. Without internet it waits on the laptop and goes by itself when the internet is back; one line for each entry. Road vehicles do not go to the Sheet. Every result is written to "kanta-sheet-YYYY-MM.csv".'),
            style: ts(11.5, c: Pal.muted, h: 1.4),
          ),
          const SizedBox(height: 6),
          Text('${bi('આજે ગયેલી', 'Sent today')}: ${KantaSheet.sentToday} · ${bi('બાકી', 'waiting')}: $wait', style: ts(12.5, w: FontWeight.w700, c: wait > 0 ? Pal.warn : Pal.ok)),
          if (wait > 0) ...<Widget>[
            const SizedBox(height: 8),
            Align(alignment: Alignment.centerLeft, child: Btn(bi('હમણાં મોકલો', 'Send now'), icon: 'cloudup', kind: BtnKind.outline, dense: true, tabStop: false, onTap: () => unawaited(KantaSheet.pump(force: true)))),
          ],
        ],
      ),
    );
  }

  void _resetStyle() {
    // back to the layout the app starts with (the Matrix terminal slip of this weighbridge)
    const SlipStyle d = SlipStyle.shree;
    _setStyle(d);
    _head.text = d.title;
    _sub.text = d.subtitle;
    _addr.text = d.address;
    _phone.text = '';
    _xtra.text = '';
    _foot.text = '';
    _signL.text = d.signL;
    _signR.text = d.signR;
  }

  // ------------------------------------------------------------------ the look of the main screen
  Widget _layoutCard() {
    return KCard(
      icon: 'grid',
      title: bi('મુખ્ય સ્ક્રીન', 'Main screen'),
      sub: KantaLog.termUi ? bi('Matrix ટર્મિનલ જેવી (અલગ સ્ક્રીન)', 'Like the Matrix terminal (separate screens)') : bi('ક્લાસિક (એક સ્ક્રીન)', 'Classic (one screen)'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          const SizedBox(height: 4),
          ChipRow(labels: <String>[bi('Matrix ટર્મિનલ જેવી', 'Like the Matrix terminal'), bi('ક્લાસિક (એક સ્ક્રીન)', 'Classic (one screen)')], index: KantaLog.termUi ? 0 : 1, onChanged: (int i) {
            unawaited(KantaLog.setTermUi(i == 0));
            if (widget.embedded || Navigator.of(context).canPop()) Navigator.of(context).popUntil((Route<dynamic> r) => r.isFirst);
          }),
          const SizedBox(height: 10),
          Text(bi('એપ ચાલુ હોય ત્યારે લેપટોપ / સ્ક્રીન બંધ ન થાય', 'Keep the laptop / screen awake while the app is open'), style: ts(12.5, w: FontWeight.w700, c: Pal.muted)),
          const SizedBox(height: 4),
          AnimatedBuilder(
            animation: KeepAwake.tick,
            builder: (BuildContext c, Widget? w) => ChipRow(labels: <String>[bi('ચાલુ', 'On'), bi('બંધ', 'Off')], index: KeepAwake.on ? 0 : 1, onChanged: (int i) => unawaited(KeepAwake.setOn(i == 0))),
          ),
          const SizedBox(height: 6),
          Text(bi('Matrix જેવી: Home પર મોટા બટન (પહેલું વજન F1, બીજું વજન F2, મેન્યુઅલ ટેર F3 ...), દરેક કામ અલગ સ્ક્રીનમાં.', 'Like the Matrix: big buttons on Home (First weighment F1, Second weighment F2, Manual tare F3 ...), every job on its own screen.'), style: ts(11.5, c: Pal.faint)),
        ],
      ),
    );
  }

  // ------------------------------------------------------------------ the RST number
  Future<void> _setRst() async {
    final int? n = int.tryParse(_rstC.text.replaceAll(RegExp(r'[^0-9]'), ''));
    if (n == null || n < 1) {
      setState(() => _rstMsg = bi('1 કે તેથી મોટો નંબર લખો.', 'Write a number from 1 up.'));
      return;
    }
    await kantaUsb.setRstStart(n);
    if (mounted) setState(() => _rstMsg = bi('હવેની એન્ટ્રી RST $n થી શરૂ થશે.', 'The next entry will be RST $n.'));
  }

  /// The khata (charges baki per name): from which day the charges are counted.
  Widget _khataCard() {
    final DateTime f = kantaKhata.from;
    final bool all = f.year <= 2005;
    return KCard(
      icon: 'ledger',
      title: bi('ખાતું (બાકી) - ક્યારથી ગણવું', 'Khata (baki) - count from'),
      sub: all ? bi('જૂની બધી સ્લિપ ગણાય છે', 'All old slips are counted') : '${pad2(f.day)}/${pad2(f.month)}/${f.year}',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          const SizedBox(height: 4),
          Text(bi('ચાર્જ વાળી સ્લિપ આ તારીખથી "બાકી" ગણાય છે (જો વજન વખતે "રોકડા લીધા" ન કર્યું હોય). આ તારીખ પહેલાંની સ્લિપ ગણાતી નથી - જૂનું બાકી હોય તો ખાતામાં "+ નવું / જૂનું બાકી" થી લખો.', 'Slips with a charge count as "baki" from this date (unless "Cash received" was chosen at the weighing). Slips before it are not counted - write an old baki in the khata with "+ New / old baki".'), style: ts(11.5, c: Pal.muted, h: 1.4)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <Widget>[
              Btn(bi('તારીખ બદલો', 'Change the date'), icon: 'cal', kind: BtnKind.outline, dense: true, tabStop: false, onTap: () => unawaited(_pickKhataFrom())),
              Btn(bi('આજથી', 'From today'), kind: BtnKind.tonal, dense: true, tabStop: false, onTap: () => unawaited(kantaKhata.setFrom(DateTime.now()).then((_) => setState(() {})))),
              Btn(bi('જૂની બધી સ્લિપ ગણો', 'Count all old slips'), kind: BtnKind.ghost, dense: true, tabStop: false, onTap: () => unawaited(kantaKhata.setFrom(DateTime(2000)).then((_) => setState(() {})))),
            ],
          ),
        ],
      ),
    );
  }

  Future<void> _pickKhataFrom() async {
    final DateTime n = DateTime.now();
    final DateTime? d = await showDatePicker(context: context, initialDate: kantaKhata.from.year <= 2005 ? n : kantaKhata.from, firstDate: DateTime(2020), lastDate: n);
    if (d != null) {
      await kantaKhata.setFrom(d);
      if (mounted) setState(() {});
    }
  }

  Widget _rstCard() {
    final int st = kantaUsb.rstStart;
    return KCard(
      icon: 'receipt',
      title: bi('RST નંબર', 'RST number'),
      sub: st > 0 ? bi('$st થી શરૂ થયું', 'started from $st') : bi('આગળ ચાલે છે', 'continues'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          const SizedBox(height: 4),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              Expanded(child: FieldX(label: bi('પહેલો RST નંબર', 'First RST number'), controller: _rstC, stacked: true, keyboard: TextInputType.number, onSubmitted: (String _) => unawaited(_setRst()))),
              const SizedBox(width: 8),
              Btn(bi('નક્કી કરો', 'Set'), icon: 'check', kind: BtnKind.outline, onTap: () => unawaited(_setRst())),
            ],
          ),
          const SizedBox(height: 6),
          if (_rstMsg.isNotEmpty) Text(_rstMsg, style: ts(12.5, w: FontWeight.w800, c: Pal.ok)),
          Text(bi('"નક્કી કરો" દબાવ્યા પછીની એન્ટ્રીઓ આ નંબરથી ચાલે છે (પહેલાંની ટેસ્ટ એન્ટ્રી ગણાતી નથી). ખરા કામ દરમિયાન બદલશો નહીં - નંબર બેવડાઈ શકે.', 'Entries made after you tap "Set" count from this number (earlier test entries are not counted). Do not change it during real work - numbers could repeat.'), style: ts(11.5, c: Pal.faint)),
        ],
      ),
    );
  }

  Widget _waCard() {
    final List<Widget> notes = <Widget>[];
    if (KantaLog.waApi && KantaLog.waMode != 0) {
      if (KantaWa.setupError.isNotEmpty) {
        notes.add(_strip('err', 'rose', bi('WhatsApp જાતે નથી જતું: ${KantaWa.setupError} - સ્લિપ હમણાં ચૅટમાં ખુલે છે. નીચે ટેસ્ટ કરો.', 'Automatic WhatsApp is not working: ${KantaWa.setupError} - slips open the chat for now. Test it below.')));
      }
      if (KantaWa.waiting > 0) {
        notes.add(_strip('cloudup', 'blue', bi('${KantaWa.waiting} સ્લિપ WhatsApp પર જવાની બાકી (નેટ આવતાં જાતે જશે)', '${KantaWa.waiting} slips waiting for WhatsApp (they go by themselves)')));
      }
      if (KantaWa.failed > 0) {
        notes.add(_strip('err', 'amber', bi('${KantaWa.failed} સ્લિપ WhatsApp પર ગઈ નથી - અહીં દબાવો: ફરી મોકલો', '${KantaWa.failed} slips did not go on WhatsApp - tap here: send again'), onTap: () {
          for (final WaJob j in KantaWa.jobs.where((WaJob x) => x.state == 'failed').toList()) {
            unawaited(KantaWa.again(j));
          }
        }));
      }
    }
    return KCard(
      icon: 'share',
      title: 'WhatsApp',
      sub: KantaLog.waMode == 0 ? bi('બંધ', 'Off') : (KantaLog.waApi ? bi('જાતે (WhatsApp Business)', 'By itself (WhatsApp Business)') : bi('ચૅટ ખુલે', 'Opens the chat')),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          const SizedBox(height: 4),
          ...notes,
          ..._waSection(),
        ],
      ),
    );
  }

  Widget _account() {
    final Profile? me = live.me;
    return KCard(
      icon: 'user',
      title: bi('ખાતું', 'Account'),
      sub: '${me != null && me.name.isNotEmpty ? '${me.name} · ' : ''}${bi('આવૃત્તિ', 'Version')} $kAppVersion',
      child: Row(
        children: <Widget>[
          Btn(bi('ભાષા બદલો (ગુજરાતી / English)', 'Change language (ગુજરાતી / English)'), icon: 'lang', kind: BtnKind.outline, onTap: app.toggleLang),
          const SizedBox(width: 10),
          Btn(bi('લૉગ આઉટ', 'Log out'), kind: BtnKind.ghost, onTap: _logout),
        ],
      ),
    );
  }

  // ------------------------------------------------------------------ page
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints bc) {
        final bool wide = bc.maxWidth >= 900;
        final KantaPart part = widget.part;
        final Widget entries = _entries();
        final Widget cards = Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            if (part == KantaPart.all) ...<Widget>[_cable(), const SizedBox(height: 12)],
            _rstCard(),
            const SizedBox(height: 12),
            _khataCard(),
            const SizedBox(height: 12),
            _printCard(),
            const SizedBox(height: 12),
            _slipCard(),
            const SizedBox(height: 12),
            _waCard(),
            const SizedBox(height: 12),
            _sheetCard(),
            const SizedBox(height: 12),
            _remote(),
            const SizedBox(height: 12),
            _layoutCard(),
            const SizedBox(height: 12),
            _account(),
          ],
        );
        final List<Widget> body;
        if (part == KantaPart.entries) {
          body = <Widget>[entries];
        } else if (part == KantaPart.scale) {
          body = <Widget>[_cable()];
        } else if (part == KantaPart.settings) {
          body = <Widget>[cards];
        } else if (wide) {
          body = <Widget>[
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Expanded(flex: 10, child: entries),
                const SizedBox(width: 14),
                Expanded(flex: 9, child: cards),
              ],
            ),
          ];
        } else {
          body = <Widget>[entries, const SizedBox(height: 12), cards];
        }
        final EdgeInsets pad = EdgeInsets.fromLTRB(wide ? 20 : 14, 14, wide ? 20 : 14, 28);
        if (widget.embedded) {
          return DeviceScope(
            pc: wide,
            width: bc.maxWidth,
            height: bc.maxHeight,
            child: Center(child: ConstrainedBox(constraints: BoxConstraints(maxWidth: wide ? 1280 : 760), child: ListView(padding: pad, children: body))),
          );
        }
        return DeviceScope(
          pc: wide,
          width: bc.maxWidth,
          height: bc.maxHeight,
          child: CallbackShortcuts(
            bindings: <ShortcutActivator, VoidCallback>{
              const SingleActivator(LogicalKeyboardKey.escape): () => unawaited(Navigator.of(context).maybePop()),
              const SingleActivator(LogicalKeyboardKey.f6): () => _findF.requestFocus(),
              const SingleActivator(LogicalKeyboardKey.keyF, control: true): () => _findF.requestFocus(),
            },
            child: Focus(
              autofocus: true,
              child: Scaffold(
                backgroundColor: Pal.bg,
                body: SafeArea(
                  child: Center(
                    child: ConstrainedBox(
                      constraints: BoxConstraints(maxWidth: wide ? 1280 : 760),
                      child: ListView(
                        padding: pad,
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              Btn(bi('← વજન પર પાછા (Esc)', '← Back to weighing (Esc)'), kind: BtnKind.outline, onTap: () => Navigator.of(context).maybePop()),
                              const SizedBox(width: 14),
                              Expanded(child: Text(bi('સેટિંગ', 'Settings'), style: ts(22, w: FontWeight.w800, ls: -0.4))),
                            ],
                          ),
                          const SizedBox(height: 14),
                          ...body,
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
