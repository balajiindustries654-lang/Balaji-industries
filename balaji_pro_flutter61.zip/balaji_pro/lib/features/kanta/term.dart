import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/app_state.dart';
import '../../core/device.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/icons.dart';
import '../../core/palette.dart';
import '../../core/version.dart';
import '../../data/kanta_khata.dart';
import '../../data/kanta_log.dart';
import '../../data/kanta_remote.dart';
import '../../data/live_models.dart' show Profile;
import '../../shell/widgets.dart' show BrandMark;
import 'kanta_weight.dart';
import '../../data/kanta_slip.dart';
import '../../data/kanta_usb.dart';
import '../../data/live_store.dart';
import '../../widgets/common.dart';
import '../../widgets/printer.dart' show printHtml, saveCsvFile;
import '../live/reauth.dart' show showReauth;
import 'kanta_print.dart';
import 'kanta_settings.dart';
import 'kanta_ui.dart';
import 'khata_view.dart';
import 'station_card.dart';

// ======================================================================
// Balaji Kanta - the "Matrix terminal" layout.
// A Home with big buttons (like the terminal's menu); every job opens on its OWN screen with the same title bar, the live weight at the
// top right and a row of small buttons to jump to another job:
//   F1 First weighment · F2 Second weighment · F3 Manual tare (direct weighing) · F4 Scale (cable) · F5 View / Print · F6 Report ·
//   F7 Settings · F8 Calibration reminder · F9 Help      Esc = Cancel / back to Home
// The F keys are caught by the window itself (not by whatever box has the cursor), so they work from every screen.
// ======================================================================

enum TermFn { first, second, manual, scale, view, report, settings, cal, help, khata }

class TermDef {
  final TermFn fn;
  final String key;
  final LogicalKeyboardKey lk;
  final String icon;
  final String gu;
  final String en;
  final String tone;
  const TermDef(this.fn, this.key, this.lk, this.icon, this.gu, this.en, this.tone);
  String get title => bi(gu, en);
}

final List<TermDef> kTermDefs = <TermDef>[
  TermDef(TermFn.first, 'F1', LogicalKeyboardKey.f1, 'plus', 'પહેલું વજન', '1st Weighment', 'green'),
  TermDef(TermFn.second, 'F2', LogicalKeyboardKey.f2, 'check', 'બીજું વજન', '2nd Weighment', 'blue'),
  TermDef(TermFn.manual, 'F3', LogicalKeyboardKey.f3, 'edit', 'મેન્યુઅલ ટેર (સીધું વજન)', 'Manual Tare (Direct)', 'violet'),
  TermDef(TermFn.scale, 'F4', LogicalKeyboardKey.f4, 'scale', 'કાંટો / કેબલ', 'Scale / Cable', 'teal'),
  TermDef(TermFn.view, 'F5', LogicalKeyboardKey.f5, 'print', 'જુઓ / પ્રિન્ટ', 'View / Print', 'amber'),
  TermDef(TermFn.report, 'F6', LogicalKeyboardKey.f6, 'chart', 'રિપોર્ટ', 'Report', 'blue'),
  TermDef(TermFn.settings, 'F7', LogicalKeyboardKey.f7, 'gear', 'સેટિંગ', 'Settings', 'slate'),
  TermDef(TermFn.cal, 'F8', LogicalKeyboardKey.f8, 'alarm', 'કેલિબ્રેશન રિમાઇન્ડર', 'Cal Reminder', 'amber'),
  TermDef(TermFn.help, 'F9', LogicalKeyboardKey.f9, 'info', 'મદદ', 'Help', 'slate'),
  TermDef(TermFn.khata, 'F10', LogicalKeyboardKey.f10, 'ledger', 'ખાતું (બાકી)', 'Khata (Baki)', 'rose'),
];

TermDef termDef(TermFn fn) => kTermDefs.firstWhere((TermDef d) => d.fn == fn);

// ---------------------------------------------------------------------------------------------- navigation

class _TermObserver extends NavigatorObserver {
  Route<dynamic>? top;

  @override
  void didPush(Route<dynamic> route, Route<dynamic>? previousRoute) => top = route;

  @override
  void didPop(Route<dynamic> route, Route<dynamic>? previousRoute) => top = previousRoute;

  @override
  void didRemove(Route<dynamic> route, Route<dynamic>? previousRoute) {
    if (identical(top, route)) top = previousRoute;
  }

  @override
  void didReplace({Route<dynamic>? newRoute, Route<dynamic>? oldRoute}) => top = newRoute;

  /// A page (not a dialog or a menu) is on top: the F keys may change the screen.
  bool get pageOnTop => top == null || top is PageRoute<dynamic>;

  /// The terminal screen on top (null: the Home or something else).
  TermFn? get current {
    final String n = top?.settings.name ?? '';
    if (!n.startsWith('term:')) return null;
    for (final TermDef d in kTermDefs) {
      if (n == 'term:${d.fn.name}') return d.fn;
    }
    return null;
  }
}

class TermNav {
  static final GlobalKey<NavigatorState> key = GlobalKey<NavigatorState>();
  static final _TermObserver observer = _TermObserver();
  static bool _installed = false;

  /// true while the weighing screens are on (not at the login): the F keys do nothing before that.
  static bool enabled = false;

  /// Starts catching the F keys / Esc of the window (once).
  static void install() {
    if (_installed) return;
    _installed = true;
    HardwareKeyboard.instance.addHandler(_onKey);
  }

  static bool _onKey(KeyEvent e) {
    if (!enabled || !KantaLog.termUi || e is! KeyDownEvent) return false;
    final NavigatorState? nav = key.currentState;
    if (nav == null || !observer.pageOnTop) return false;
    final HardwareKeyboard hw = HardwareKeyboard.instance;
    if (hw.isControlPressed || hw.isAltPressed) return false;
    if (e.logicalKey == LogicalKeyboardKey.escape) {
      if (nav.canPop()) {
        nav.pop();
        return true;
      }
      return false;
    }
    for (final TermDef d in kTermDefs) {
      if (d.lk == e.logicalKey) {
        open(d.fn);
        return true;
      }
    }
    return false;
  }

  /// Opens the screen of a job (from the Home or from another job).
  static void open(TermFn fn, {String? pick}) {
    final NavigatorState? nav = key.currentState;
    if (nav == null) return;
    if (observer.current == fn && pick == null) return;
    nav.popUntil((Route<dynamic> r) => r.isFirst);
    nav.push(MaterialPageRoute<void>(settings: RouteSettings(name: 'term:${fn.name}'), builder: (BuildContext c) => termScreen(fn, pick: pick)));
  }

  /// Back to the Home.
  static void home() {
    key.currentState?.popUntil((Route<dynamic> r) => r.isFirst);
  }
}

Widget termScreen(TermFn fn, {String? pick}) {
  switch (fn) {
    case TermFn.first:
      return const TermFirst();
    case TermFn.second:
      return TermSecond(pick: pick);
    case TermFn.manual:
      return const TermManual();
    case TermFn.scale:
      return const TermScale();
    case TermFn.view:
      return const TermView();
    case TermFn.report:
      return const TermReport();
    case TermFn.settings:
      return const TermSettings();
    case TermFn.cal:
      return const TermCal();
    case TermFn.help:
      return const TermHelp();
    case TermFn.khata:
      return const TermKhata();
  }
}

/// "Print ticket?" (Yes / No) after an entry was made - only when "auto print" is off (then the slip is printed by itself).
Future<void> termAfterEntry(BuildContext context, AutoMade? m) async {
  if (m == null || KantaLog.autoPrint) return;
  final bool? yes = await showDialog<bool>(
    context: context,
    builder: (BuildContext c) => AlertDialog(
      title: Text(bi('સ્લિપ છાપવી?', 'Print ticket?'), style: ts(18, w: FontWeight.w800)),
      content: Text('${m.outside ? bi('સ્લિપ', 'Slip') : 'RST'} ${m.rst} · ${m.vehicle}\n${grp(m.net, dec: 0)} KG', style: ts(15, h: 1.4)),
      actions: <Widget>[
        TextButton(onPressed: () => Navigator.of(c).pop(false), child: Text(bi('ના', 'No'), style: ts(14, w: FontWeight.w700, c: Pal.muted))),
        TextButton(autofocus: true, onPressed: () => Navigator.of(c).pop(true), child: Text(bi('હા, છાપો', 'Yes, print'), style: ts(14, w: FontWeight.w800, c: Pal.brand))),
      ],
    ),
  );
  if (yes == true) await printSlip(kantaUsb.slipOf(m));
}

/// The toast after an entry (used by the second weighment and the direct weighing).
String termMadeText(AutoMade? m) {
  if (m == null) return bi('એન્ટ્રી બની', 'Entry made');
  final String head = m.outside ? '${bi('સ્લિપ બની (ફક્ત લેપટોપમાં)', 'Slip made (laptop only)')} · ${m.rst}' : '${bi('એન્ટ્રી બની', 'Entry made')} · RST ${m.rst}';
  final String small = m.net < 50 ? '\n${bi('ચોખ્ખું બહુ ઓછું છે - ખોટું લાગે તો "જુઓ / પ્રિન્ટ" માંથી "પાછું લો".', 'The net is very small - if it looks wrong use "Take back" in View / Print.')}' : '';
  return '$head · ${grp(m.net, dec: 0)} KG$small';
}

// ---------------------------------------------------------------------------------------------- the frame of a screen

/// The live weight, big, with its state (steady / moving / empty / no signal).
class TermWeight extends StatelessWidget {
  final double size;
  const TermWeight({super.key, this.size = 34});

  @override
  Widget build(BuildContext context) => ListenableBuilder(listenable: kantaUsb, builder: (BuildContext c, Widget? _) => _body());

  Widget _body() {
    final KantaUsbService u = kantaUsb;
    final double? kg = u.dec.kg;
    final bool st = kg != null && u.dec.stable;
    Color col;
    String why;
    if (!u.connected) {
      col = const Color(0xFFE5677A);
      why = bi('સિગ્નલ નથી', 'NO SIGNAL');
    } else if (kg == null) {
      col = const Color(0xFFF2B65A);
      why = bi('વજનની રાહ', 'WAITING');
    } else if (u.steadyWhy == 'low') {
      col = const Color(0xFFF2B65A);
      why = bi('કાંટો ખાલી', 'EMPTY');
    } else {
      col = st ? const Color(0xFF5BE3A0) : const Color(0xFFF2B65A);
      why = st ? bi('સ્થિર', 'STEADY') : bi('બદલાય છે', 'MOVING');
    }
    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: <Widget>[
        Container(width: 9, height: 9, margin: const EdgeInsets.only(right: 8, bottom: 9), decoration: BoxDecoration(color: col, shape: BoxShape.circle, boxShadow: <BoxShadow>[BoxShadow(color: col.withAlpha(150), blurRadius: 8)])),
        Text(kg == null ? '—' : grp(kg, dec: kg == kg.roundToDouble() ? 0 : 1), style: ts(size, w: FontWeight.w800, tab: true, ls: -1, c: kg == null ? const Color(0xFF6E9499) : Colors.white)),
        const SizedBox(width: 6),
        Padding(padding: const EdgeInsets.only(bottom: 5), child: Text('Kg', style: ts(15, w: FontWeight.w800, c: const Color(0xFF8FB7BC)))),
        const SizedBox(width: 10),
        Padding(padding: const EdgeInsets.only(bottom: 6), child: Text(why, style: ts(11, w: FontWeight.w800, c: col, ls: 0.8))),
      ],
    );
  }
}

/// The small warning strips (no internet / offline login / the copy on the laptop was not saved) - on the Home and on every screen.
List<Widget> termStrips(BuildContext context) {
  final List<Widget> l = <Widget>[];
  Widget strip(String icon, String tone, String text, {VoidCallback? onTap}) {
    final Tone t = Pal.tone(tone);
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Material(
        color: t.bg,
        borderRadius: BorderRadius.circular(Pal.rad(12)),
        child: InkWell(
          borderRadius: BorderRadius.circular(Pal.rad(12)),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(children: <Widget>[Icon(ic(icon), size: 17, color: t.fg), const SizedBox(width: 10), Expanded(child: Text(text, style: ts(12.5, w: FontWeight.w700, c: t.fg)))]),
          ),
        ),
      ),
    );
  }

  if (live.needsReauth) {
    l.add(strip('lock', 'amber', bi('ઑફલાઇન લૉગિન - ઇન્ટરનેટ આવે ત્યારે અહીં દબાવી પાસવર્ડ નાખો', 'Offline login - when the internet is back tap here and enter the password'), onTap: () => showReauth(context)));
  } else if (live.offline) {
    l.add(strip('wifioff', 'amber', bi('ઇન્ટરનેટ નથી - એન્ટ્રી લેપટોપમાં સચવાય છે અને નેટ આવતાં જાતે જશે', 'No internet - entries are kept on the laptop and go by themselves when the internet is back')));
  }
  if (KantaLog.lastError.isNotEmpty) {
    l.add(strip('err', 'rose', bi('લેપટોપમાં કૉપી સેવ થઈ નથી: ${KantaLog.lastError}', 'The copy on the laptop was not saved: ${KantaLog.lastError}')));
  }
  final DateTime? due = KantaLog.calDue;
  if (due != null) {
    final int days = due.difference(DateTime.now()).inDays;
    if (days <= 14) {
      l.add(strip('alarm', days < 0 ? 'rose' : 'amber', days < 0 ? bi('કાંટાનું કેલિબ્રેશન ${-days} દિવસ મોડું છે - અહીં દબાવો (F8)', 'The scale calibration is ${-days} days late - tap here (F8)') : bi('કાંટાનું કેલિબ્રેશન $days દિવસમાં કરવાનું છે - અહીં દબાવો (F8)', 'The scale calibration is due in $days days - tap here (F8)'), onTap: () => TermNav.open(TermFn.cal)));
    }
  }
  return l;
}

/// Title bar + live weight + the row of job buttons + the body + date / time. One frame for every screen of the terminal layout.
class TermFrame extends StatefulWidget {
  final TermFn fn;
  final Widget child;

  /// Something at the right of the bottom line (e.g. a count).
  final String? note;
  const TermFrame({super.key, required this.fn, required this.child, this.note});

  @override
  State<TermFrame> createState() => _TermFrameState();
}

class _TermFrameState extends State<TermFrame> {
  Timer? _t;

  @override
  void initState() {
    super.initState();
    kantaUsb.addListener(_tick);
    live.addListener(_tick);
    _t = Timer.periodic(const Duration(seconds: 1), (Timer _) => _tick());
  }

  @override
  void dispose() {
    _t?.cancel();
    kantaUsb.removeListener(_tick);
    live.removeListener(_tick);
    super.dispose();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  static String clock(DateTime n) {
    String p(int v) => v < 10 ? '0$v' : '$v';
    final int h12 = n.hour % 12 == 0 ? 12 : n.hour % 12;
    return '${p(n.day)}/${p(n.month)}/${n.year}   ${p(h12)}:${p(n.minute)}:${p(n.second)} ${n.hour < 12 ? 'AM' : 'PM'}';
  }

  Widget _toolbar() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: <Widget>[
          for (final TermDef d in kTermDefs)
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: Tooltip(
                message: '${d.key}  ${d.title}',
                child: InkWell(
                  onTap: () => TermNav.open(d.fn),
                  borderRadius: BorderRadius.circular(12),
                  canRequestFocus: false,
                  child: Container(
                    width: 74,
                    padding: const EdgeInsets.symmetric(vertical: 7),
                    decoration: BoxDecoration(
                      color: d.fn == widget.fn ? Pal.brand : Pal.surface,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: d.fn == widget.fn ? Pal.brand : Pal.line),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        Icon(ic(d.icon), size: 22, color: d.fn == widget.fn ? Colors.white : Pal.brand),
                        const SizedBox(height: 2),
                        Text(d.key, style: ts(11.5, w: FontWeight.w800, c: d.fn == widget.fn ? Colors.white : Pal.muted, tab: true)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final TermDef d = termDef(widget.fn);
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints bc) {
        final bool wide = bc.maxWidth >= 900;
        app.stagePc = wide;
        return DeviceScope(
          pc: wide,
          width: bc.maxWidth,
          height: bc.maxHeight,
          child: Scaffold(
            backgroundColor: Pal.bg,
            body: SafeArea(
              child: Center(
                child: ConstrainedBox(
                  constraints: BoxConstraints(maxWidth: wide ? 1280 : 760),
                  child: Padding(
                    padding: EdgeInsets.fromLTRB(wide ? 20 : 12, 12, wide ? 20 : 12, 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        Container(
                          padding: const EdgeInsets.fromLTRB(10, 8, 18, 8),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(16),
                            gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: <Color>[Color(0xFF0A2A30), Color(0xFF0F454C)]),
                          ),
                          child: Row(
                            children: <Widget>[
                              IconButton(onPressed: TermNav.home, tooltip: 'Esc', icon: Icon(ic('back'), color: Colors.white)),
                              const SizedBox(width: 4),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min,
                                  children: <Widget>[
                                    Text(d.gu, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(20, w: FontWeight.w800, c: Colors.white, ls: -0.3)),
                                    Text('${d.en}   ·   ${d.key}', style: ts(11.5, w: FontWeight.w700, c: const Color(0xFF8FB7BC), ls: 0.6)),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 12),
                              FittedBox(fit: BoxFit.scaleDown, child: TermWeight(size: wide ? 38 : 30)),
                            ],
                          ),
                        ),
                        const SizedBox(height: 8),
                        _toolbar(),
                        ...termStrips(context),
                        const SizedBox(height: 8),
                        Expanded(child: widget.child),
                        const SizedBox(height: 6),
                        Row(
                          children: <Widget>[
                            Text(clock(DateTime.now()), style: ts(12.5, w: FontWeight.w700, c: Pal.muted, tab: true)),
                            const Spacer(),
                            if (widget.note != null) Text(widget.note!, style: ts(12, c: Pal.faint)),
                            const SizedBox(width: 12),
                            Text(bi('Esc = પાછા Home પર', 'Esc = back to Home'), style: ts(12, w: FontWeight.w700, c: Pal.faint)),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

// ---------------------------------------------------------------------------------------------- First weighment / Manual tare

class TermFirst extends StatelessWidget {
  const TermFirst({super.key});

  @override
  Widget build(BuildContext context) {
    return TermFrame(
      fn: TermFn.first,
      child: ListView(
        children: <Widget>[
          StationCard(mode: StationMode.first, onDone: (bool made) => TermNav.home(), onCancel: TermNav.home),
        ],
      ),
    );
  }
}

class TermManual extends StatelessWidget {
  const TermManual({super.key});

  @override
  Widget build(BuildContext context) {
    return TermFrame(
      fn: TermFn.manual,
      child: ListView(
        children: <Widget>[
          StationCard(
            mode: StationMode.manual,
            onDone: (bool made) async {
              final AutoMade? m = kantaUsb.made.isEmpty ? null : kantaUsb.made.first;
              if (made) await termAfterEntry(TermNav.key.currentState?.overlay?.context ?? context, m);
              TermNav.home();
            },
            onCancel: TermNav.home,
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------------------------- Second weighment

class TermSecond extends StatefulWidget {
  /// The vehicle (its id inside the list) to select first.
  final String? pick;
  const TermSecond({super.key, this.pick});

  @override
  State<TermSecond> createState() => _TermSecondState();
}

class _TermSecondState extends State<TermSecond> {
  String? _id;
  bool _busy = false;
  final FocusNode _f = FocusNode(debugLabel: 'term-second');

  /// Vehicles whose baki pop-up was already shown on this screen.
  final Set<String> _bakiShown = <String>{};

  @override
  void initState() {
    super.initState();
    _id = widget.pick;
    kantaUsb.addListener(_tick);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        _f.requestFocus();
        unawaited(_bakiPopup());
      }
    });
  }

  @override
  void dispose() {
    kantaUsb.removeListener(_tick);
    _f.dispose();
    super.dispose();
  }

  /// The account (khata) of the selected vehicle.
  KhataAcc? _acc(InsideVehicle v) {
    String name = v.party;
    if (name.trim().isEmpty && !v.outside) {
      try {
        name = kantaUsb.partyProvider(v.vehicle);
      } catch (_) {}
    }
    return kantaKhata.find(name: name, mobile: v.mobile, vehicle: v.vehicle);
  }

  /// A pop-up when the selected vehicle's name has baki (once for each vehicle on this screen).
  Future<void> _bakiPopup() async {
    final InsideVehicle? v = _sel;
    if (v == null || !mounted || !_bakiShown.add(v.id)) return;
    final KhataAcc? a = _acc(v);
    if (a == null || a.baki < 0.5) return;
    await showBakiPopup(context, a);
    if (mounted) _f.requestFocus();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  InsideVehicle? get _sel {
    final List<InsideVehicle> l = kantaUsb.inside;
    if (l.isEmpty) return null;
    for (final InsideVehicle v in l) {
      if (v.id == _id) return v;
    }
    return l.first;
  }

  void _move(int d) {
    final List<InsideVehicle> l = kantaUsb.inside;
    if (l.isEmpty) return;
    final InsideVehicle? s = _sel;
    int i = s == null ? 0 : l.indexWhere((InsideVehicle x) => x.id == s.id);
    i = (i + d).clamp(0, l.length - 1).toInt();
    setState(() => _id = l[i].id);
    unawaited(_bakiPopup());
  }

  Future<void> _save() async {
    final InsideVehicle? v = _sel;
    if (v == null || _busy) return;
    setState(() => _busy = true);
    final String r = await kantaUsb.takeSecond(v);
    if (!mounted) return;
    setState(() => _busy = false);
    if (r.isEmpty) {
      final AutoMade? m = kantaUsb.made.isEmpty ? null : kantaUsb.made.first;
      app.toast(termMadeText(m));
      await termAfterEntry(context, m);
      TermNav.home();
    } else {
      app.toast(StationCardState.errText(r));
    }
  }

  Future<void> _drop() async {
    final InsideVehicle? v = _sel;
    if (v == null) return;
    final bool? ok = await showDialog<bool>(
      context: context,
      builder: (BuildContext c) => AlertDialog(
        title: Text(bi('ગાડી અંદરથી કાઢવી?', 'Remove this vehicle from inside?'), style: ts(17, w: FontWeight.w800)),
        content: Text('${v.vehicle} · ${grp(v.kg, dec: 0)} KG\n${bi('પહેલું વજન ભૂંસાશે. એન્ટ્રી બનશે નહીં.', 'Its first weight is dropped. No entry is made.')}', style: ts(14, h: 1.4)),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.of(c).pop(false), child: Text(bi('ના', 'No'), style: ts(14, w: FontWeight.w700, c: Pal.muted))),
          TextButton(onPressed: () => Navigator.of(c).pop(true), child: Text(bi('હા, કાઢો', 'Yes, remove'), style: ts(14, w: FontWeight.w800, c: Pal.bad))),
        ],
      ),
    );
    if (ok == true) kantaUsb.dropInside(v);
  }

  Widget _cell(String t, double w, {bool head = false, bool right = false, Color? c, FontWeight? fw}) {
    return SizedBox(width: w, child: Text(t, textAlign: right ? TextAlign.right : TextAlign.left, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(head ? 12 : 14, w: fw ?? (head ? FontWeight.w800 : FontWeight.w700), c: c ?? (head ? Pal.muted : Pal.ink), tab: true)));
  }

  Widget _box(String label, String value, {String tone = 'slate'}) {
    final Tone t = Pal.tone(tone);
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(color: t.bg, borderRadius: BorderRadius.circular(12)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(label, style: ts(11.5, w: FontWeight.w800, c: t.fg)),
            const SizedBox(height: 2),
            FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text('$value KG', style: ts(24, w: FontWeight.w800, c: t.fg, tab: true))),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final KantaUsbService u = kantaUsb;
    final List<InsideVehicle> l = u.inside;
    final InsideVehicle? v = _sel;
    final double? st = u.steadyKg;
    double? g, t, net;
    if (v != null && st != null && (st - v.kg).abs() >= 0.5) {
      g = st > v.kg ? st : v.kg;
      t = st > v.kg ? v.kg : st;
      net = g - t;
    }
    String fmt(double? x) => x == null ? '—' : grp(x, dec: 0);
    final Widget table = KCard(
      icon: 'truck',
      title: bi('અંદર ગયેલી ગાડી', 'Vehicles inside'),
      sub: bi('ગાડી પસંદ કરો (↑ ↓) અને Enter / સેવ', 'Pick the vehicle (↑ ↓) and press Enter / Save'),
      trailing: KPill('${l.length}', tone: l.isEmpty ? 'slate' : 'amber'),
      child: l.isEmpty
          ? Padding(padding: const EdgeInsets.symmetric(vertical: 10), child: Text(bi('કોઈ ગાડી અંદર નથી. પહેલાં "પહેલું વજન" (F1) લો.', 'No vehicle is inside. Take the "1st Weighment" (F1) first.'), style: ts(14, c: Pal.muted)))
          : SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: SizedBox(
                width: 720,
                child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Row(children: <Widget>[const SizedBox(width: 30), _cell('RST', 86, head: true), _cell(bi('ગાડી નંબર', 'Vehicle No.'), 170, head: true), _cell(bi('પહેલું KG', 'First KG'), 110, head: true, right: true), const SizedBox(width: 16), _cell(bi('સમય', 'Time'), 70, head: true), Expanded(child: _cell(bi('પાર્ટી', 'Party'), 200, head: true))]),
                const Divider(height: 10),
                for (final InsideVehicle x in l)
                  InkWell(
                    onTap: () {
                      setState(() => _id = x.id);
                      unawaited(_bakiPopup());
                    },
                    borderRadius: BorderRadius.circular(10),
                    canRequestFocus: false,
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 9),
                      decoration: BoxDecoration(color: v != null && x.id == v.id ? Pal.soft : null, borderRadius: BorderRadius.circular(10)),
                      child: Row(
                        children: <Widget>[
                          SizedBox(width: 30, child: Icon(v != null && x.id == v.id ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded, size: 18, color: Pal.brand)),
                          _cell(x.outside ? bi('બહારની', 'ROAD') : (x.rst.isEmpty ? '-' : x.rst), 86, c: x.outside ? Pal.warn : Pal.ink),
                          _cell(x.vehicle, 170),
                          _cell(grp(x.kg, dec: 0), 110, right: true),
                          const SizedBox(width: 16),
                          _cell(hm(x.at), 70, c: Pal.muted),
                          Expanded(child: _cell(x.party, 200, c: Pal.muted)),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
              ),
            ),
    );
    final Widget detail = KCard(
      icon: 'scale',
      title: v == null ? bi('બીજું વજન', 'Second weighment') : '${v.vehicle}',
      sub: v == null ? null : (v.outside ? '${bi('સ્લિપ', 'Slip')} ${u.nextRoadSlip}' : (v.rst.isEmpty ? bi('RST આપોઆપ', 'RST automatic') : 'RST ${v.rst}')),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Row(children: <Widget>[_box(bi('ગ્રોસ', 'Gross'), fmt(g), tone: 'blue'), const SizedBox(width: 10), _box(bi('ટેર', 'Tare'), fmt(t), tone: 'amber'), const SizedBox(width: 10), _box(bi('ચોખ્ખું', 'Net'), fmt(net), tone: 'green')]),
          if (v != null) ...<Widget>[
            const SizedBox(height: 8),
            Text(
              <String>[
                if (v.party.isNotEmpty) '${bi('પાર્ટી', 'Party')}: ${v.party}',
                if (v.material.isNotEmpty) '${bi('માલ', 'Material')}: ${v.material}',
                if (v.city.isNotEmpty) '${bi('ગામ', 'City')}: ${v.city}',
                if (v.mobile.isNotEmpty) '${bi('મોબાઇલ', 'Mobile')}: ${v.mobile}',
                if (v.charges > 0) '${bi('ચાર્જ', 'Charges')}: ₹${grp(v.charges, dec: 0)}',
                if (v.by.isNotEmpty) '${bi('પહેલું વજન', 'First weight by')}: ${v.by}',
              ].join('   ·   '),
              style: ts(12.5, c: Pal.muted),
            ),
          ],
          if (v != null && v.charges > 0)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text('${bi('આ વજનનો ચાર્જ', 'Charge of this weighing')}: ${inr(v.charges)}  ·  ${v.paid ? bi('રોકડા લીધા', 'cash received') : bi('બાકી - ખાતામાં લખાશે', 'baki - goes to the khata')}', style: ts(12.5, w: FontWeight.w700, c: v.paid ? Pal.ok : Pal.warn)),
            ),
          if (v != null && bakiLine(_acc(v)) != null)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text(bakiLine(_acc(v))!, style: ts(13.5, w: FontWeight.w800, c: Pal.bad)),
            ),
          const SizedBox(height: 12),
          Row(
            children: <Widget>[
              Expanded(child: Btn('${bi('સેવ (બીજું વજન)', 'Save (second weight)')}${st == null ? '' : ' · ${grp(st, dec: 0)} KG'}', icon: 'check', expand: true, onTap: (v != null && st != null && !_busy) ? _save : null)),
              const SizedBox(width: 10),
              Btn(bi('રદ (Esc)', 'Cancel (Esc)'), kind: BtnKind.outline, tabStop: false, onTap: TermNav.home),
              const SizedBox(width: 10),
              Btn(bi('ગાડી કાઢો', 'Remove'), kind: BtnKind.ghost, tabStop: false, onTap: v == null ? null : _drop),
            ],
          ),
          if (v != null && st == null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(StationCardState.steadyWhyText(), style: ts(12, c: Pal.faint))),
        ],
      ),
    );
    return TermFrame(
      fn: TermFn.second,
      child: CallbackShortcuts(
        bindings: <ShortcutActivator, VoidCallback>{
          const SingleActivator(LogicalKeyboardKey.arrowDown): () => _move(1),
          const SingleActivator(LogicalKeyboardKey.arrowUp): () => _move(-1),
          const SingleActivator(LogicalKeyboardKey.enter): () => unawaited(_save()),
          const SingleActivator(LogicalKeyboardKey.numpadEnter): () => unawaited(_save()),
        },
        child: Focus(
          focusNode: _f,
          autofocus: true,
          child: ListView(children: <Widget>[table, const SizedBox(height: 12), detail]),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------------------------- View / Print, Scale, Settings

class TermView extends StatelessWidget {
  const TermView({super.key});

  @override
  Widget build(BuildContext context) => const TermFrame(fn: TermFn.view, child: KantaSettings(part: KantaPart.entries, embedded: true, focusSearch: true));
}

class TermScale extends StatelessWidget {
  const TermScale({super.key});

  @override
  Widget build(BuildContext context) => const TermFrame(fn: TermFn.scale, child: KantaSettings(part: KantaPart.scale, embedded: true));
}

class TermSettings extends StatelessWidget {
  const TermSettings({super.key});

  @override
  Widget build(BuildContext context) => const TermFrame(fn: TermFn.settings, child: KantaSettings(part: KantaPart.settings, embedded: true));
}

// ---------------------------------------------------------------------------------------------- Report

class TermReport extends StatefulWidget {
  const TermReport({super.key});

  @override
  State<TermReport> createState() => _TermReportState();
}

class _TermReportState extends State<TermReport> {
  int _p = 0; // 0 today, 1 yesterday, 2 this month, 3 everything

  List<SlipRec> _items() {
    final DateTime n = DateTime.now();
    final DateTime t0 = DateTime(n.year, n.month, n.day);
    bool inP(DateTime at) {
      switch (_p) {
        case 0:
          return !at.isBefore(t0);
        case 1:
          return !at.isBefore(t0.subtract(const Duration(days: 1))) && at.isBefore(t0);
        case 2:
          return at.year == n.year && at.month == n.month;
        default:
          return true;
      }
    }

    return <SlipRec>[for (final SlipRec r in KantaHistory.items) if (!r.undone && inP(r.at)) r]..sort((SlipRec a, SlipRec b) => a.at.compareTo(b.at));
  }

  static const List<String> _pNames = <String>['Today', 'Yesterday', 'This-month', 'All'];

  String get _stamp {
    final DateTime n = DateTime.now();
    return '${n.year}-${pad2(n.month)}-${pad2(n.day)}';
  }

  String _csv(List<SlipRec> l) {
    final StringBuffer b = StringBuffer('Date,Time,RST/Slip,Vehicle,Party,Mobile,Material,City,Gross KG,Tare KG,Net KG,Charges Rs,Charge status,Type\n');
    String q(String s) => '"${s.replaceAll('"', '""')}"';
    double net = 0;
    double ch = 0;
    for (final SlipRec r in l) {
      net += r.net;
      ch += r.charges;
      b.writeln('${r.at.year}-${pad2(r.at.month)}-${pad2(r.at.day)},${hm(r.at)},${q(r.rst)},${q(r.vehicle)},${q(r.party)},${q(r.mobile)},${q(r.material)},${q(r.city)},${r.gross.round()},${r.tare.round()},${r.net.round()},${r.charges.round()},${r.charges <= 0 ? '' : (r.paid ? 'Cash' : 'Baki')},${r.outside ? 'ROAD' : 'MILL'}');
    }
    b.writeln('TOTAL,,${l.length} slips,,,,,,,,${net.round()},${ch.round()},,');
    return b.toString();
  }

  /// A page to print or "Save as PDF" (opens in the browser and asks to print by itself).
  String _html(List<SlipRec> l, String title) {
    String e(String s) => s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');
    final StringBuffer b = StringBuffer('<!doctype html><html><head><meta charset="utf-8"><title>${e(title)}</title><style>body{font-family:Arial,sans-serif;margin:18px;color:#111}h1{font-size:20px;margin:0 0 4px}p{margin:0 0 12px;color:#555;font-size:13px}table{border-collapse:collapse;width:100%;font-size:12px}th,td{border:1px solid #bbb;padding:4px 6px;text-align:left}th{background:#eee}td.n,th.n{text-align:right}tr.t td{font-weight:bold;background:#f6f6f6}</style></head><body>');
    b.write('<h1>Balaji Industries - Kanta Report</h1><p>${e(title)} &nbsp;|&nbsp; ${l.length} slips</p>');
    b.write('<table><tr><th>Date</th><th>Time</th><th>RST</th><th>Vehicle</th><th>Party</th><th>Material</th><th>City</th><th class="n">Gross</th><th class="n">Tare</th><th class="n">Net</th><th class="n">Charges</th><th>Status</th></tr>');
    double net = 0;
    double ch = 0;
    for (final SlipRec r in l) {
      net += r.net;
      ch += r.charges;
      b.write('<tr><td>${pad2(r.at.day)}/${pad2(r.at.month)}/${r.at.year}</td><td>${hm(r.at)}</td><td>${e(r.rst)}</td><td>${e(r.vehicle)}</td><td>${e(r.party)}</td><td>${e(r.material)}</td><td>${e(r.city)}</td><td class="n">${grp(r.gross, dec: 0)}</td><td class="n">${grp(r.tare, dec: 0)}</td><td class="n">${grp(r.net, dec: 0)}</td><td class="n">${r.charges > 0 ? grp(r.charges, dec: 0) : ''}</td><td>${r.charges <= 0 ? '' : (r.paid ? 'Cash' : 'Baki')}${r.outside ? ' (road)' : ''}</td></tr>');
    }
    b.write('<tr class="t"><td colspan="9">TOTAL (${l.length} slips)</td><td class="n">${grp(net, dec: 0)} KG</td><td class="n">${grp(ch, dec: 0)}</td><td></td></tr></table>');
    b.write('<script>window.onload=function(){setTimeout(function(){window.print()},400)}</script></body></html>');
    return b.toString();
  }

  /// Saves the report as a file that opens in Excel (Documents\Balaji Pro Reports) - on a phone the text is copied instead.
  Future<void> _download(List<SlipRec> l) async {
    final String csv = _csv(l);
    final String path = await saveCsvFile(csv, 'Kanta_Report_${_pNames[_p]}_$_stamp');
    if (path.isEmpty) {
      copyText(csv, msg: bi('ફાઇલ સેવ ન થઈ - લખાણ કૉપિ થયું (Excel માં પેસ્ટ કરો)', 'Could not save a file - the text was copied (paste it into Excel)'));
    } else {
      app.toast('${bi('ફાઇલ સેવ થઈ અને Excel માં ખુલી', 'File saved and opened in Excel')}: $path');
    }
  }

  Future<void> _print(List<SlipRec> l) async {
    final bool ok = await printHtml(_html(l, 'Kanta Report - ${_pNames[_p]} - $_stamp'), 'Kanta_Report_${_pNames[_p]}_$_stamp');
    if (!ok) app.toast(bi('પ્રિન્ટ પેજ ખુલ્યું નહીં', 'Could not open the print page'));
  }

  @override
  Widget build(BuildContext context) {
    final List<SlipRec> l = _items();
    final List<SlipRec> mill = <SlipRec>[for (final SlipRec r in l) if (!r.outside) r];
    final List<SlipRec> road = <SlipRec>[for (final SlipRec r in l) if (r.outside) r];
    double sum(Iterable<SlipRec> x) => x.fold(0.0, (double a, SlipRec r) => a + r.net);
    final double charges = l.fold(0.0, (double a, SlipRec r) => a + r.charges);
    final Map<String, double> mat = <String, double>{};
    final Map<String, int> matN = <String, int>{};
    for (final SlipRec r in l) {
      final String k = r.material.trim().isEmpty ? bi('(માલ લખ્યો નથી)', '(no material)') : r.material.trim().toUpperCase();
      mat[k] = (mat[k] ?? 0) + r.net;
      matN[k] = (matN[k] ?? 0) + 1;
    }
    final List<String> keys = mat.keys.toList()..sort((String a, String b) => mat[b]!.compareTo(mat[a]!));
    return TermFrame(
      fn: TermFn.report,
      note: bi('આ લેપટોપ પર બનેલી એન્ટ્રી', 'Entries made on this laptop'),
      child: ListView(
        children: <Widget>[
          KCard(
            icon: 'chart',
            title: bi('રિપોર્ટ', 'Report'),
            sub: '${l.length} ${bi('સ્લિપ', 'slips')}',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                ChipRow(labels: <String>[bi('આજે', 'Today'), bi('ગઈકાલે', 'Yesterday'), bi('આ મહિનો', 'This month'), bi('બધી', 'All')], index: _p, onChanged: (int i) => setState(() => _p = i)),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: <Widget>[
                    KStat(bi('કુલ ગાડી', 'Vehicles'), '${l.length}', tone: 'blue'),
                    KStat(bi('મિલની', 'Mill'), '${mill.length} · ${grp(sum(mill), dec: 0)} KG', tone: 'green'),
                    KStat(bi('બહારની', 'Road'), '${road.length} · ${grp(sum(road), dec: 0)} KG', tone: 'amber'),
                    KStat(bi('કુલ ચોખ્ખું', 'Total net'), '${grp(sum(l), dec: 0)} KG', tone: 'teal'),
                    if (charges > 0) KStat(bi('ચાર્જ', 'Charges'), '₹${grp(charges, dec: 0)}', tone: 'violet'),
                  ],
                ),
                if (keys.isNotEmpty) ...<Widget>[
                  const SizedBox(height: 14),
                  Text(bi('માલ પ્રમાણે', 'By material'), style: ts(13, w: FontWeight.w800, c: Pal.muted)),
                  const SizedBox(height: 4),
                  for (final String k in keys)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 3),
                      child: Row(children: <Widget>[Expanded(child: Text(k, style: ts(14, w: FontWeight.w700))), Text('${matN[k]} ${bi('ગાડી', 'veh')}', style: ts(12.5, c: Pal.muted)), const SizedBox(width: 14), Text('${grp(mat[k]!, dec: 0)} KG', style: ts(14, w: FontWeight.w800, tab: true))]),
                    ),
                ],
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: <Widget>[
                    Btn(bi('ડાઉનલોડ (Excel ફાઇલ)', 'Download (Excel file)'), icon: 'dl', onTap: l.isEmpty ? null : () => unawaited(_download(l))),
                    Btn(bi('પ્રિન્ટ / PDF', 'Print / PDF'), icon: 'print', kind: BtnKind.tonal, onTap: l.isEmpty ? null : () => unawaited(_print(l))),
                    Btn(bi('CSV કૉપિ', 'Copy CSV'), icon: 'copy', kind: BtnKind.outline, onTap: l.isEmpty ? null : () => copyText(_csv(l), msg: bi('કૉપિ થયું - Excel / WhatsApp માં પેસ્ટ કરો', 'Copied - paste into Excel / WhatsApp'))),
                  ],
                ),
              ],
            ),
          ),
          if (l.isNotEmpty) ...<Widget>[
            const SizedBox(height: 12),
            KCard(
              icon: 'list',
              title: bi('સ્લિપની યાદી', 'Slips'),
              child: Column(
                children: <Widget>[
                  for (final SlipRec r in l.reversed.take(60))
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Row(
                        children: <Widget>[
                          SizedBox(width: 70, child: Text(r.outside ? r.rst : 'RST ${r.rst}', style: ts(12.5, c: r.outside ? Pal.warn : Pal.muted, w: FontWeight.w700))),
                          Expanded(child: Text('${r.vehicle}${r.party.isEmpty ? '' : '  ·  ${r.party}'}${r.material.isEmpty ? '' : '  ·  ${r.material}'}', maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(13.5, w: FontWeight.w700))),
                          Text('${grp(r.gross, dec: 0)} − ${grp(r.tare, dec: 0)}', style: ts(12.5, c: Pal.muted, tab: true)),
                          const SizedBox(width: 12),
                          SizedBox(width: 92, child: Text('${grp(r.net, dec: 0)} KG', textAlign: TextAlign.right, style: ts(14, w: FontWeight.w800, tab: true))),
                          const SizedBox(width: 12),
                          Text(hm(r.at), style: ts(12, c: Pal.faint, tab: true)),
                        ],
                      ),
                    ),
                  if (l.length > 60) Padding(padding: const EdgeInsets.only(top: 6), child: Text(bi('છેલ્લી 60 દેખાય છે - બધી CSV માં આવશે.', 'The last 60 are shown - the CSV has all.'), style: ts(11.5, c: Pal.faint))),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------------------------- Calibration reminder

class TermCal extends StatefulWidget {
  const TermCal({super.key});

  @override
  State<TermCal> createState() => _TermCalState();
}

class _TermCalState extends State<TermCal> {
  late DateTime? _last = KantaLog.calLastMs > 0 ? DateTime.fromMillisecondsSinceEpoch(KantaLog.calLastMs) : null;
  late int _months = KantaLog.calMonths;
  late final TextEditingController _note = TextEditingController(text: KantaLog.calNote);

  @override
  void dispose() {
    _note.dispose();
    super.dispose();
  }

  String _d(DateTime d) => '${d.day < 10 ? '0' : ''}${d.day}/${d.month < 10 ? '0' : ''}${d.month}/${d.year}';

  Future<void> _pick() async {
    final DateTime n = DateTime.now();
    final DateTime? p = await showDatePicker(context: context, initialDate: _last ?? n, firstDate: DateTime(n.year - 5), lastDate: DateTime(n.year + 1));
    if (p != null && mounted) setState(() => _last = p);
  }

  @override
  Widget build(BuildContext context) {
    final DateTime? due = _last == null ? null : DateTime(_last!.year, _last!.month + _months, _last!.day);
    final int days = due == null ? 0 : due.difference(DateTime.now()).inDays;
    return TermFrame(
      fn: TermFn.cal,
      child: ListView(
        children: <Widget>[
          KCard(
            icon: 'alarm',
            title: bi('કાંટાનું કેલિબ્રેશન', 'Scale calibration'),
            sub: bi('છેલ્લું કેલિબ્રેશન લખો - સમય થતાં Home પર યાદ અપાશે', 'Write the last calibration - Home reminds you when it is due'),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                const SizedBox(height: 4),
                Row(
                  children: <Widget>[
                    Expanded(child: Text(_last == null ? bi('છેલ્લું કેલિબ્રેશન: લખ્યું નથી', 'Last calibration: not written') : '${bi('છેલ્લું કેલિબ્રેશન', 'Last calibration')}: ${_d(_last!)}', style: ts(15, w: FontWeight.w800))),
                    Btn(bi('તારીખ પસંદ કરો', 'Pick the date'), icon: 'cal', kind: BtnKind.outline, dense: true, onTap: _pick),
                    const SizedBox(width: 8),
                    Btn(bi('આજે', 'Today'), kind: BtnKind.tonal, dense: true, onTap: () => setState(() => _last = DateTime.now())),
                  ],
                ),
                const SizedBox(height: 12),
                Text(bi('પછીનું કેલિબ્રેશન દર', 'Next calibration every'), style: ts(12.5, w: FontWeight.w700, c: Pal.muted)),
                const SizedBox(height: 4),
                ChipRow(labels: <String>[bi('3 મહિને', '3 months'), bi('6 મહિને', '6 months'), bi('12 મહિને', '12 months')], index: _months <= 3 ? 0 : (_months <= 6 ? 1 : 2), onChanged: (int i) => setState(() => _months = <int>[3, 6, 12][i])),
                const SizedBox(height: 12),
                FieldX(label: bi('નોંધ (કોણે કર્યું, સર્ટિફિકેટ નંબર ...)', 'Note (who did it, certificate no. ...)'), controller: _note),
                if (due != null) ...<Widget>[
                  const SizedBox(height: 12),
                  Text(days < 0 ? bi('પછીનું કેલિબ્રેશન ${_d(due)} ના રોજ હતું - ${-days} દિવસ મોડું!', 'The next calibration was due on ${_d(due)} - ${-days} days late!') : bi('પછીનું કેલિબ્રેશન: ${_d(due)} ($days દિવસ પછી)', 'Next calibration: ${_d(due)} (in $days days)'), style: ts(14, w: FontWeight.w800, c: days < 0 ? Pal.bad : (days <= 14 ? Pal.warn : Pal.ok))),
                ],
                const SizedBox(height: 14),
                Row(
                  children: <Widget>[
                    Btn(bi('સેવ', 'Save'), icon: 'check', onTap: () async {
                      await KantaLog.setCal(_last, _months, _note.text);
                      app.toast(bi('સેવ થયું', 'Saved'));
                      TermNav.home();
                    }),
                    const SizedBox(width: 10),
                    Btn(bi('રદ (Esc)', 'Cancel (Esc)'), kind: BtnKind.outline, onTap: TermNav.home),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------------------------- Khata (baki)

class TermKhata extends StatelessWidget {
  const TermKhata({super.key});

  @override
  Widget build(BuildContext context) => TermFrame(fn: TermFn.khata, child: ListView(children: const <Widget>[KhataBody()]));
}

// ---------------------------------------------------------------------------------------------- Help

class TermHelp extends StatelessWidget {
  const TermHelp({super.key});

  Widget _p(String text) => Padding(padding: const EdgeInsets.only(bottom: 6), child: Text(text, style: ts(13.5, h: 1.45)));

  @override
  Widget build(BuildContext context) {
    return TermFrame(
      fn: TermFn.help,
      child: ListView(
        children: <Widget>[
          KCard(
            icon: 'info',
            title: bi('કીબોર્ડ', 'Keyboard'),
            child: Wrap(
              spacing: 22,
              runSpacing: 8,
              children: <Widget>[
                for (final TermDef d in kTermDefs) KKey(d.key, d.title),
                KKey('Esc', bi('રદ / Home પર', 'Cancel / Home')),
                KKey('Enter', bi('આગળનું ખાનું', 'Next box')),
              ],
            ),
          ),
          const SizedBox(height: 12),
          KCard(
            icon: 'info',
            title: bi('લેપટોપમાં F ચાવી ન ચાલે તો', 'If the F keys do not work on the laptop'),
            child: _p(bi('ઘણા લેપટોપમાં F1–F9 સાથે Fn દબાવવું પડે (Fn + F2). Fn Lock ચાલુ કરો તો Fn વગર ચાલશે. ત્યાં સુધી ઉપરના નાના બટનો (F1 ... F9) માઉસથી દબાવો - એ જ કામ કરે છે.', 'On many laptops you must hold Fn with F1–F9 (Fn + F2). Switch Fn Lock on and they work without Fn. Meanwhile tap the small buttons on top (F1 ... F9) - they do the same.')),
          ),
          const SizedBox(height: 12),
          KCard(
            icon: 'scale',
            title: bi('ગાડી કેવી રીતે તોલવી', 'How to weigh a vehicle'),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                _p(bi('1. ગાડી કાંટા પર ચડાવો. Home પર "પહેલું વજન" (F1) દબાવો, ગાડી નંબર લખો (મોબાઇલ, પાર્ટી, માલ, ગામ, ચાર્જ ઇચ્છા મુજબ) અને "સેવ".', '1. Drive the vehicle onto the scale. On Home press "1st Weighment" (F1), write the vehicle number (mobile, party, material, city, charges are optional) and "Save".')),
                _p(bi('2. ગાડી ખાલી કે ભરીને પાછી આવે ત્યારે "બીજું વજન" (F2): યાદીમાંથી ગાડી પસંદ કરી "સેવ". RST નંબર આપોઆપ 1, 2, 3 ... આવે છે - લખવો નથી.', '2. When the vehicle comes back (empty or loaded) press "2nd Weighment" (F2): pick it in the list and "Save". The RST number comes by itself - 1, 2, 3 ... - you never write it.')),
                _p(bi('3. ખાલી વજન (ટેર) ખબર હોય તો "મેન્યુઅલ ટેર" (F3): ગાડી નંબર અને ટેર લખો, કાંટા પરનું વજન ગ્રોસ ગણાય, એન્ટ્રી તરત બને.', '3. If the empty weight (tare) is known use "Manual Tare" (F3): write the vehicle number and the tare - the weight on the scale is the gross and the entry is made at once.')),
                _p(bi('4. બહારની (રસ્તા પરની) ગાડી: ફોર્મમાં "બહારની ગાડી" પસંદ કરો - સ્લિપ ફક્ત આ લેપટોપમાં બને (નંબર R-1, R-2 ...), સર્વરમાં જતી નથી.', '4. A road vehicle: pick "Road vehicle" in the form - the slip stays on this laptop only (numbers R-1, R-2 ...), nothing goes to the server.')),
                _p(bi('5. જૂની સ્લિપ ફરી છાપવી / WhatsApp / પાછી લેવી: "જુઓ / પ્રિન્ટ" (F5).', '5. To print an old slip again / WhatsApp / take it back: "View / Print" (F5).')),
              ],
            ),
          ),
          const SizedBox(height: 12),
          KCard(
            icon: 'ledger',
            title: bi('ચાર્જ અને ખાતું (બાકી)', 'Charges and the khata (baki)'),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                _p(bi('• ચાર્જ લખો ત્યારે નીચે "બાકી - ખાતામાં લખો" કે "રોકડા લીધા" પસંદ કરો. બાકી હોય તો તે નામના ખાતામાં ચડે છે.', '• When you write a charge pick "Baki - write in the khata" or "Cash received". Baki goes to the account of that name.')),
                _p(bi('• ખાતું નામ મુજબ બને છે. નામ ન લખ્યું હોય તો મોબાઇલ નંબરથી, તે પણ ન હોય તો ગાડી નંબરથી.', '• The account is made by name. No name: by the mobile number; no mobile either: by the vehicle number.')),
                _p(bi('• નામ / મોબાઇલ / ગાડી લખતાં બાકી હોય તો ફોર્મમાં દેખાય છે, અને "બીજું વજન" (F2) ખોલતાં પોપ-અપ આવે છે.', '• While you write a name / mobile / vehicle the baki shows in the form, and a pop-up comes when you open the "2nd Weighment" (F2).')),
                _p(bi('• પૈસા મળ્યા ત્યારે "ખાતું" (F10) ખોલી નામ દબાવો → "જમા લો". માલિકના ફોનમાં પણ આ જ બાકી દેખાય છે.', '• When money is received open the "Khata" (F10), tap the name → "Take jama". The owner sees the same baki on his phone.')),
                _p(bi('• ગણતરી ક્યારથી: Settings (F7) → "ખાતું (બાકી) - ક્યારથી ગણવું".', '• Counted from: Settings (F7) → "Khata (baki) - count from".')),
              ],
            ),
          ),
          const SizedBox(height: 12),
          KCard(
            icon: 'print',
            title: bi('સ્લિપ અને WhatsApp', 'Slip and WhatsApp'),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                _p(bi('• કાંટાનું નામ, સરનામું, ફોન નંબર, નીચેની લાઇન અને કઈ લાઇન છપાય તે: Settings (F7) → "સ્લિપની ગોઠવણ" (નીચે સ્લિપ કેવી દેખાશે તે તરત દેખાય છે).', '• The name of the weighbridge, address, phone numbers, bottom line and which lines are printed: Settings (F7) → "Slip layout" (the preview shows the slip at once).')),
                _p(bi('• મિલની ગાડીની સ્લિપ WhatsApp પર મિલના ફિક્સ નંબર પર અને વજન વખતે લખેલા નંબર પર જાય છે. ફિક્સ નંબર એક વાર Settings (F7) → WhatsApp માં લખો.', '• The slip of a MILL vehicle goes on WhatsApp to the fixed mill number and to the number written at the weighing. Write the fixed number once in Settings (F7) → WhatsApp.')),
                _p(bi('• બહારની ગાડીની સ્લિપ ફક્ત વજન વખતે લખેલા નંબર પર જાય છે (એ માટે WhatsApp માં "બધી ગાડી" પસંદ કરો).', '• The slip of a road vehicle goes only to the number written at the weighing (choose "All vehicles" in WhatsApp for that).')),
              ],
            ),
          ),
          const SizedBox(height: 12),
          KCard(
            icon: 'wifioff',
            title: bi('ઇન્ટરનેટ ન હોય તો', 'Without internet'),
            child: _p(bi('વજન, RST, સેવ, સ્લિપ પ્રિન્ટ, ખાતું અને રિપોર્ટ - બધું આ લેપટોપ પર ચાલે છે. એન્ટ્રી લેપટોપમાં સચવાય છે અને ઇન્ટરનેટ આવતાં જાતે સર્વર પર જાય છે (ઉપર "ઇન્ટરનેટ નથી" પટ્ટી દેખાય). ફોનથી વજન અને WhatsApp માટે ઇન્ટરનેટ જોઈએ.', 'Weighing, RST, save, slip printing, khata and report all work on this laptop. Entries are kept on the laptop and go to the server by themselves when the internet is back (the "No internet" strip shows on top). Weighing from the phone and WhatsApp need the internet.')),
          ),
          const SizedBox(height: 12),
          KCard(
            icon: 'warn',
            title: bi('કાંટો જોડાતો નથી?', 'The scale does not connect?'),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                _p(bi('• "કાંટો / કેબલ" (F4) ખોલો - કેબલ કેમ તૂટ્યો તે કારણ ત્યાં લખાય છે. "Copy report" દબાવી મને મોકલો.', '• Open "Scale / Cable" (F4) - the reason the cable stopped is written there. Press "Copy report" and send it.')),
                _p(bi('• Windows Device Manager ના Ports માં "USB Serial Port (COM..)" દેખાવું જોઈએ. ન દેખાય તો કેબલ ફરી લગાવો / બીજા USB માં લગાવો.', '• In the Windows Device Manager under Ports "USB Serial Port (COM..)" must be there. If it is not, plug the cable again / into another USB socket.')),
                _p(bi('• "Access denied" આવે તો બીજું Balaji Kanta window કે ટર્મિનલનો બીજો પ્રોગ્રામ ખુલ્લો છે - બંધ કરો.', '• "Access denied" means another Balaji Kanta window or another terminal program holds the port - close it.')),
              ],
            ),
          ),
          const SizedBox(height: 12),
          KCard(
            icon: 'phone',
            title: bi('મદદ માટે', 'Help'),
            child: _p('Balaji Industries · +91 94264 52158'),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------------------------- Home

/// The Home of the terminal layout: the live weight, one big button per job (with its F key), the vehicles inside, the last entry.
class KantaHome extends StatefulWidget {
  const KantaHome({super.key});

  @override
  State<KantaHome> createState() => _KantaHomeState();
}

class _KantaHomeState extends State<KantaHome> {
  Timer? _t;

  @override
  void initState() {
    super.initState();
    kantaUsb.addListener(_tick);
    live.addListener(_tick);
    kantaRemote.addListener(_tick);
    KantaLog.tick.addListener(_tick);
    _t = Timer.periodic(const Duration(seconds: 30), (Timer _) => _tick());
  }

  @override
  void dispose() {
    _t?.cancel();
    kantaUsb.removeListener(_tick);
    live.removeListener(_tick);
    kantaRemote.removeListener(_tick);
    KantaLog.tick.removeListener(_tick);
    super.dispose();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  Widget _brand(bool wide) {
    final Profile? me = live.me;
    final KantaUsbService u = kantaUsb;
    final DateTime n = DateTime.now();
    const List<String> wd = <String>['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    final List<Widget> pills = <Widget>[
      if (u.connected) KPill('${bi('કાંટો', 'Scale')} · ${u.chosen?.id ?? ''}', tone: u.junkPort ? 'amber' : 'green', dot: true) else KPill(bi('કાંટો જોડાયેલો નથી', 'Scale offline'), tone: 'rose', dot: true),
      if (live.offline) KPill(bi('ઑફલાઇન', 'Offline'), tone: 'amber', icon: 'wifioff') else if (live.pending.isNotEmpty) KPill('${live.pending.length} ${bi('મોકલવાની બાકી', 'to upload')}', tone: 'blue', icon: 'cloudup'),
    ];
    final Widget brand = Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        const BrandMark(size: 44),
        const SizedBox(width: 12),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(kAppTitle, style: ts(20, w: FontWeight.w800, ls: -0.4)),
            Text('${me != null && me.name.isNotEmpty ? '${me.name} · ' : ''}${wd[n.weekday - 1]} ${n.day}/${n.month}/${n.year}', style: ts(12, c: Pal.muted)),
          ],
        ),
      ],
    );
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(color: Pal.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: Pal.line), boxShadow: const <BoxShadow>[BoxShadow(color: Color(0x0F0B2C33), blurRadius: 18, offset: Offset(0, 6))]),
      child: wide
          ? Row(children: <Widget>[brand, const SizedBox(width: 18), Expanded(child: Wrap(spacing: 8, runSpacing: 8, alignment: WrapAlignment.end, children: pills))])
          : Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: <Widget>[brand, const SizedBox(height: 10), Wrap(spacing: 8, runSpacing: 8, children: pills)]),
    );
  }

  Widget _tile(TermDef d, {required int badge}) {
    final Tone t = Pal.tone(d.tone);
    return InkWell(
      onTap: () => TermNav.open(d.fn),
      borderRadius: BorderRadius.circular(18),
      child: Container(
        height: 112,
        padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
        decoration: BoxDecoration(
          color: Pal.surface,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Pal.line),
          boxShadow: const <BoxShadow>[BoxShadow(color: Color(0x0F0B2C33), blurRadius: 16, offset: Offset(0, 5))],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                Container(width: 44, height: 44, decoration: BoxDecoration(color: t.bg, borderRadius: BorderRadius.circular(14)), child: Icon(ic(d.icon), size: 25, color: t.fg)),
                const Spacer(),
                if (badge > 0) ...<Widget>[KPill('$badge', tone: 'amber'), const SizedBox(width: 6)],
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(color: Pal.surface2, borderRadius: BorderRadius.circular(7), border: Border.all(color: Pal.line, width: 1.2)),
                  child: Text(d.key, style: ts(12, w: FontWeight.w800, c: Pal.ink, tab: true)),
                ),
              ],
            ),
            const Spacer(),
            Text(d.gu, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(15.5, w: FontWeight.w800, ls: -0.2)),
            Text(d.en, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(11.5, w: FontWeight.w600, c: Pal.muted)),
          ],
        ),
      ),
    );
  }

  Widget _tiles(double width) {
    final int cols = width >= 640 ? 3 : 2;
    final int inside = kantaUsb.inside.length;
    final List<Widget> rows = <Widget>[];
    for (int i = 0; i < kTermDefs.length; i += cols) {
      final List<Widget> r = <Widget>[];
      for (int j = i; j < i + cols; j++) {
        if (r.isNotEmpty) r.add(const SizedBox(width: 12));
        r.add(Expanded(child: j < kTermDefs.length ? _tile(kTermDefs[j], badge: kTermDefs[j].fn == TermFn.second ? inside : (kTermDefs[j].fn == TermFn.khata ? kantaKhata.owingCount : 0)) : const SizedBox()));
      }
      if (rows.isNotEmpty) rows.add(const SizedBox(height: 12));
      rows.add(Row(children: r));
    }
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: rows);
  }

  Widget _insideCard() {
    final List<InsideVehicle> l = kantaUsb.inside;
    if (l.isEmpty) return const SizedBox();
    return KCard(
      icon: 'truck',
      title: bi('અંદર ગયેલી ગાડી', 'Vehicles inside'),
      sub: bi('ગાડી દબાવો = બીજું વજન', 'Tap a vehicle = second weighment'),
      trailing: KPill('${l.length}', tone: 'amber'),
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        children: <Widget>[
          for (final InsideVehicle v in l)
            InkWell(
              onTap: () => TermNav.open(TermFn.second, pick: v.id),
              borderRadius: BorderRadius.circular(12),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(color: Pal.soft, borderRadius: BorderRadius.circular(12)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Text(v.vehicle, style: ts(15, w: FontWeight.w800, tab: true)),
                    Text('${v.outside ? bi('બહારની', 'Road') : (v.rst.isEmpty ? 'RST' : 'RST ${v.rst}')} · ${grp(v.kg, dec: 0)} KG · ${hm(v.at)}', style: ts(11.5, c: Pal.muted, tab: true)),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints bc) {
        final bool wide = bc.maxWidth >= 900;
        app.stagePc = wide;
        final Widget left = Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            KantaWeightCard(),
            if (kantaUsb.inside.isNotEmpty) ...<Widget>[const SizedBox(height: 12), _insideCard()],
            if (kantaUsb.made.isNotEmpty) ...<Widget>[const SizedBox(height: 12), LastEntryCard(keys: false)],
          ],
        );
        final double inner = wide ? (bc.maxWidth - 40).clamp(0, 1240).toDouble() * 0.5 : bc.maxWidth - 28;
        return DeviceScope(
          pc: wide,
          width: bc.maxWidth,
          height: bc.maxHeight,
          child: Scaffold(
            backgroundColor: Pal.bg,
            body: SafeArea(
              child: Center(
                child: ConstrainedBox(
                  constraints: BoxConstraints(maxWidth: wide ? 1280 : 760),
                  child: ListView(
                    padding: EdgeInsets.fromLTRB(wide ? 20 : 14, 14, wide ? 20 : 14, 28),
                    children: <Widget>[
                      _brand(wide),
                      ...termStrips(context),
                      const SizedBox(height: 12),
                      if (wide)
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Expanded(flex: 10, child: left),
                            const SizedBox(width: 14),
                            Expanded(flex: 11, child: _tiles(inner)),
                          ],
                        )
                      else ...<Widget>[
                        left,
                        const SizedBox(height: 12),
                        _tiles(inner),
                      ],
                      const SizedBox(height: 14),
                      Wrap(
                        spacing: 18,
                        runSpacing: 6,
                        children: <Widget>[
                          for (final TermDef d in kTermDefs) KKey(d.key, d.title),
                          KKey('Esc', bi('પાછા Home પર', 'Back to Home')),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
