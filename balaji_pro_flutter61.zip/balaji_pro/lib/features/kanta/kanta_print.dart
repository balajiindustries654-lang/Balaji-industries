import 'dart:async';
import '../../core/app_state.dart';
import '../../core/i18n.dart';
import '../../data/kanta_direct.dart';
import '../../data/kanta_log.dart';
import '../../data/kanta_slip.dart';
import '../../data/kanta_wa.dart';
import '../../widgets/common.dart' show copyText;
import '../../widgets/launch.dart' show whatsappText;
import '../../widgets/printer.dart' show printHtml;

/// What to tell the operator when the printer did not take the slip (the technical reason is added at the end).
String printWhy(String why) {
  if (why.contains('NOPRINTER')) {
    return bi('Epson પ્રિન્ટર મળ્યું નહીં - USB કેબલ અને પ્રિન્ટર ચાલુ (ON) છે કે જુઓ', 'Epson printer not found - check the USB cable and that the printer is ON');
  }
  return why;
}

/// Prints a slip. On the Windows laptop ("Epson direct", the default) the plain text with printer codes goes straight to the dot-matrix
/// printer - it finds the Epson by itself (a Windows queue, or the USB printer even when no driver is installed) and no print window
/// opens. If it fails a short message is shown and the slip stays in the entry list to print again; the browser's print window only
/// opens when the operator switched the browser method on (or "also open the browser" in Settings).
Future<void> printSlip(SlipRec r) async {
  if (KantaLog.printMode == 1 && DirectPrint.supported) {
    final String why = await DirectPrint.send(
      escpBytes(slipEpson(r, style: KantaLog.style), pageLines: KantaLog.pageLines, bold: KantaLog.bold, width: slipWidth(KantaLog.style)),
      printer: KantaLog.printerName,
    );
    if (why.isEmpty) {
      app.toast(bi('પ્રિન્ટરને મોકલ્યું', 'Sent to the printer'));
      return;
    }
    app.toast('${bi('સ્લિપ છપાઈ નહીં', 'The slip did not print')}: ${printWhy(why)}');
    if (!KantaLog.browserFallback) return;
  }
  final bool ok = await printHtml(slipHtml(r, style: KantaLog.style, dot: KantaLog.dotMatrix), 'kanta-slip-${r.rst}');
  if (!ok) copyText(slipPlain(r, style: KantaLog.style), msg: bi('પ્રિન્ટ વિન્ડો ખુલી નહીં - સ્લિપનું લખાણ કૉપિ થયું', 'Could not open the print window - the slip text was copied'));
}

/// The first number the slip goes to ('' when none): the one written at the weighing, else (mill vehicles) the farmer on the chit,
/// else the fixed mill number. See [slipRecipients] for all of them.
String slipPhone(SlipRec r) {
  final List<SlipTo> l = slipRecipients(r);
  return l.isEmpty ? '' : l.first.number;
}

/// Sends the slip on WhatsApp: the chat of that number opens with the slip typed in (WhatsApp always wants one press of Send).
/// [which]: the 1st (0) or 2nd (1) number of [slipRecipients] - a mill vehicle goes to the driver / farmer and to the fixed mill number.
/// [auto]: it opened by itself after the weighing - with no number it only says so (nobody is picked for the operator).
Future<void> sendSlipWhatsApp(SlipRec r, {bool auto = false, int which = 0}) async {
  final List<SlipTo> to = slipRecipients(r);
  final String phone = which < to.length ? to[which].number : '';
  if (auto && phone.isEmpty) {
    app.toast(bi('WhatsApp: ${r.vehicle} નો મોબાઇલ નંબર નથી - એન્ટ્રી પરથી "WhatsApp" દબાવો', 'WhatsApp: no mobile number for ${r.vehicle} - tap "WhatsApp" on the entry'));
    return;
  }
  await whatsappText(slipTextOf(r, style: KantaLog.style), phone: phone);
  if (auto && to.length > 1) {
    app.toast(bi('બીજો નંબર (${to[1].mill ? 'મિલ' : 'ડ્રાઇવર'}) ${to[1].number}: એન્ટ્રી પરથી બીજું "WhatsApp" દબાવો', 'Second number (${to[1].mill ? 'mill' : 'driver'}) ${to[1].number}: tap the 2nd "WhatsApp" on the entry'));
  }
}

/// After every entry: "auto print" prints the slip by itself; "WhatsApp" sends the slip to the driver / farmer and - for mill vehicles - to the
/// fixed mill number: by itself through the WhatsApp Business Platform when that is set up and tested (nothing to press per vehicle),
/// else the chat opens with the slip typed in.
void kantaPrintHook() {
  KantaLog.afterEntry = (SlipRec r) {
    if (KantaLog.autoPrint) unawaited(printSlip(r));
    if (r.undone) return;
    if (!(KantaLog.waMode == 2 || (KantaLog.waMode == 1 && !r.outside))) return;
    if (KantaLog.waApi && KantaWa.ready) {
      final List<SlipTo> to = slipRecipients(r);
      if (to.isEmpty) {
        app.toast(bi('WhatsApp: ${r.vehicle} નો મોબાઇલ નંબર નથી - સ્લિપ ગઈ નથી', 'WhatsApp: no mobile number for ${r.vehicle} - slip not sent'));
        return;
      }
      unawaited(KantaWa.submitAll(r));
      return;
    }
    if (r.by.isEmpty) unawaited(sendSlipWhatsApp(r, auto: true));
  };
}
