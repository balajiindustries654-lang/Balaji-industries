import 'package:flutter/material.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/icons.dart';
import '../../core/palette.dart';
import '../../data/kanta_usb.dart';
import '../../widgets/common.dart';

// ======================================================================
// The dark live-weight panel of Balaji Kanta (big weight, steady / moving / empty, the cable and what is wrong with it).
// Used on the classic one-screen layout and on the Home screen of the terminal layout.
// ======================================================================
class KantaWeightCard extends StatelessWidget {
  /// The vehicle number typed in the box (the net so far of that vehicle is shown under the weight).
  final String typedKey;
  const KantaWeightCard({super.key, this.typedKey = ''});

  /// The card redraws by itself whenever the scale / cable changes - so it is right even when the page around it is a `const`
  /// (a const widget is never rebuilt by its parent: the Home screen once showed "cable not connected" for ever).
  @override
  Widget build(BuildContext context) => ListenableBuilder(listenable: kantaUsb, builder: (BuildContext c, Widget? _) => _body());

  Widget _body() {
    final KantaUsbService u = kantaUsb;
    final double? kg = u.dec.kg;
    final bool st = kg != null && u.dec.stable;
    const Color green = Color(0xFF5BE3A0);
    const Color amber = Color(0xFFF2B65A);
    const Color rose = Color(0xFFE5677A);
    const Color dim = Color(0xFF8FB7BC);
    String status;
    Color glow;
    if (!u.connected) {
      status = u.trying || u.busy ? bi('જોડાય છે…', 'CONNECTING…') : bi('સિગ્નલ નથી', 'NO SIGNAL');
      glow = rose;
    } else if (kg == null) {
      status = bi('વજનની રાહ', 'WAITING');
      glow = amber;
    } else if (u.steadyWhy == 'low') {
      // 0 on the platform (nothing standing on it): no weight to take
      status = bi('કાંટો ખાલી', 'EMPTY');
      glow = amber;
    } else {
      status = st ? bi('સ્થિર', 'STEADY') : bi('બદલાય છે', 'MOVING');
      glow = st ? green : amber;
    }
    // the vehicle in the box (or the only one inside): what the net would be if it were weighed now
    InsideVehicle? box;
    final String key = typedKey;
    if (key.isNotEmpty) {
      for (final InsideVehicle x in u.inside) {
        if (x.vehicle.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '') == key) box = x;
      }
    }
    box ??= u.inside.length == 1 ? u.inside.first : null;
    return Container(
      padding: const EdgeInsets.fromLTRB(22, 16, 22, 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: <Color>[Color(0xFF0A2A30), Color(0xFF0F454C)]),
        boxShadow: const <BoxShadow>[BoxShadow(color: Color(0x330B2C33), blurRadius: 24, offset: Offset(0, 10))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(ic('scale'), size: 16, color: dim),
              const SizedBox(width: 8),
              Text(bi('લાઇવ વજન', 'LIVE WEIGHT'), style: ts(11.5, w: FontWeight.w800, c: dim, ls: 1.6)),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 5),
                decoration: BoxDecoration(color: glow.withAlpha(41), borderRadius: BorderRadius.circular(99), border: Border.all(color: glow.withAlpha(140))),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Container(width: 8, height: 8, decoration: BoxDecoration(color: glow, shape: BoxShape.circle, boxShadow: <BoxShadow>[BoxShadow(color: glow.withAlpha(179), blurRadius: 8)])),
                    const SizedBox(width: 8),
                    Text(status, style: ts(11.5, w: FontWeight.w800, c: glow, ls: 0.8)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              Flexible(child: FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(kg == null ? '—' : grp(kg, dec: kg == kg.roundToDouble() ? 0 : 1), style: ts(86, w: FontWeight.w800, tab: true, ls: -2, c: kg == null ? const Color(0xFF4F7378) : (st ? Colors.white : const Color(0xFFE9D9B0)))))),
              const SizedBox(width: 10),
              Padding(padding: const EdgeInsets.only(bottom: 16), child: Text('KG', style: ts(22, w: FontWeight.w800, c: dim))),
            ],
          ),
          const SizedBox(height: 4),
          Row(
            children: <Widget>[
              Container(width: 8, height: 8, decoration: BoxDecoration(color: u.connected ? green : rose, shape: BoxShape.circle)),
              const SizedBox(width: 8),
              Expanded(child: Text(u.connected ? '${u.chosen?.label ?? ''} · ${u.modeText}' : bi('કેબલ જોડાયેલો નથી', 'Cable not connected'), maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12, w: FontWeight.w600, c: dim))),
            ],
          ),
          if (u.connected && kg == null && u.connectedAt != null && DateTime.now().difference(u.connectedAt!).inSeconds >= 6) ...<Widget>[
            const SizedBox(height: 8),
            Text(
              u.dec.bytes == 0
                  ? bi('કેબલ જોડાયો છે પણ ટર્મિનલ તરફથી હજી કોઈ ડેટા આવ્યો નથી. ટર્મિનલ ચાલુ છે? કાંટા પર થોડું વજન મૂકી જુઓ (કેટલાક ટર્મિનલ 0 વજને કંઈ મોકલતા નથી).', 'The cable is connected but no data has come from the terminal yet. Is it on? Try some weight on the scale (some terminals send nothing at 0).')
                  : bi('ડેટા આવે છે (${u.dec.bytes} બાઇટ) પણ વજન સમજાતું નથી. સેટિંગ → કાંટા કેબલ → "Copy report" મોકલો.', 'Data is coming (${u.dec.bytes} bytes) but no weight could be read. Send Settings → Scale cable → "Copy report".'),
              style: ts(12, c: const Color(0xFFF2B65A), w: FontWeight.w700),
            ),
          ],
          if (u.junkPort) ...<Widget>[
            const SizedBox(height: 8),
            Text(bi('આ કાંટાનું પોર્ટ નથી (લેપટોપનું Intel SOL). કાંટાનો USB-RS232 કેબલ લેપટોપમાં લગાવો - જાતે બદલાઈ જશે.', 'This is not the weighbridge port (the laptop\'s own Intel SOL). Plug the weighbridge USB-RS232 cable into the laptop - it switches by itself.'), style: ts(12.5, w: FontWeight.w700, c: const Color(0xFFFFB3BE))),
          ],
          if (!u.connected) ...<Widget>[
            const SizedBox(height: 10),
            if (u.devices.isEmpty || !u.hasRealCable)
              Text(bi('કાંટાનો કેબલ દેખાતો નથી. USB-RS232 કેબલ લેપટોપમાં લગાવો (જાતે શોધાશે). લગાવેલો હોય છતાં ન દેખાય તો ઉપર જમણે "સેટિંગ" ખોલી COM પોર્ટ જાતે પસંદ કરો.', 'The weighbridge cable is not found. Plug the USB-RS232 cable into the laptop (it is found by itself). If it is plugged in and still not shown, open "Settings" (top right) and pick the COM port by hand.'), style: ts(12.5, c: const Color(0xFFB7D3D6)))
            else
              Btn(bi('જોડો', 'Connect'), icon: 'sync', expand: true, onTap: u.busy ? null : u.connect),
            if (u.error.isNotEmpty) ...<Widget>[const SizedBox(height: 8), Text(u.error, style: ts(12, c: const Color(0xFFFFB3BE)))],
          ],
          if (box != null && kg != null && u.steadyKg != null && (kg - box.kg).abs() >= 1) ...<Widget>[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(color: const Color(0x1F5BE3A0), borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0x555BE3A0))),
              child: Row(
                children: <Widget>[
                  Expanded(child: Text('${box.vehicle} · ${bi('પહેલું', '1st')} ${grp(box.kg, dec: 0)} KG', style: ts(12.5, w: FontWeight.w700, c: const Color(0xFFBFE9D4), tab: true))),
                  Text('${bi('ચોખ્ખું', 'NET')} ${grp((kg - box.kg).abs(), dec: 0)} KG', style: ts(15, w: FontWeight.w800, c: green, tab: true)),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}
