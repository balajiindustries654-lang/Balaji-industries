import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/app_state.dart';
import '../../core/device.dart';
import '../../core/i18n.dart';
import '../../core/icons.dart';
import '../../core/palette.dart';
import '../../core/version.dart';
import '../../data/kanta_khata.dart';
import '../../data/kanta_log.dart';
import '../../data/kanta_sheet.dart';
import '../../data/kanta_remote.dart';
import '../../data/kanta_usb.dart';
import '../../data/kanta_wa.dart';
import '../../data/live_models.dart';
import '../../data/live_store.dart';
import '../../shell/widgets.dart' show BrandMark;
import '../../widgets/common.dart';
import '../live/login.dart';
import '../live/reauth.dart' show showReauth;
import 'kanta_print.dart';
import 'kanta_weight.dart';
import 'kanta_ui.dart';
import 'station_card.dart';
import 'kanta_settings.dart';
import 'term.dart';

// ======================================================================
// Balaji Kanta - the small app of the weighbridge operator (Windows laptop at the weighbridge).
//   login (own account) -> live weight from the terminal cable -> vehicle number -> first / second weight -> entry
//   (saved online, a copy in Documents\Balaji Kanta) -> WhatsApp slip.
// No accounts, parties, Tally or reports - those stay in Balaji Pro (owner).
// ======================================================================

class KantaRoot extends StatelessWidget {
  const KantaRoot({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: app,
      builder: (BuildContext context, Widget? child) {
        return MaterialApp(
          title: kAppTitle,
          debugShowCheckedModeBanner: false,
          theme: buildTheme(),
          scaffoldMessengerKey: app.messengerKey,
          navigatorKey: TermNav.key,
          navigatorObservers: <NavigatorObserver>[TermNav.observer],
          home: const KantaGate(),
        );
      },
    );
  }
}

/// splash -> login -> (blocked) -> the weighing screen
class KantaGate extends StatelessWidget {
  const KantaGate({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: live,
      builder: (BuildContext context, Widget? child) {
        if (live.booting) return const SplashScreen();
        if (!live.signedIn) return const LoginScreen();
        final Profile? me = live.me;
        if (me == null || !me.approved || me.isFarmer) return const BlockedScreen();
        return const KantaScreen();
      },
    );
  }
}

class KantaScreen extends StatefulWidget {
  const KantaScreen({super.key});

  @override
  State<KantaScreen> createState() => _KantaScreenState();
}

class _KantaScreenState extends State<KantaScreen> {
  final GlobalKey<StationCardState> _station = GlobalKey<StationCardState>();
  Timer? _timer;
  Timer? _khataTimer;
  int _ticks = 0;

  @override
  void initState() {
    super.initState();
    TermNav.install();
    TermNav.enabled = true;
    kantaUsb.addListener(_tick);
    live.addListener(_tick);
    kantaRemote.addListener(_tick);
    KantaLog.tick.addListener(_tick);
    KantaWa.tick.addListener(_tick);
    unawaited(KantaWa.load());
    // the Google Sheet row of every mill entry is written by this laptop itself, at the moment of the weighing
    KantaSheet.install();
    unawaited(KantaSheet.load());
    // the khata (charges baki per name): built from the slips of this laptop, pushed to the server for the owner's phone
    kantaKhata.host = true;
    unawaited(kantaKhata.load().then((_) => kantaKhata.sync()));
    KantaLog.tick.addListener(_khataChanged);
    _khataTimer = Timer.periodic(const Duration(seconds: 60), (Timer _) => unawaited(kantaKhata.sync()));
    // the cable: found and connected by itself, and again by itself if it was pulled out
    _timer = Timer.periodic(const Duration(seconds: 6), (Timer _) async {
      // entries that waited because the internet was down go as soon as it is back (every 30 s)
      if (++_ticks % 5 == 0 && live.pending.isNotEmpty && !live.offline && !live.needsReauth) unawaited(live.flush());
      final KantaUsbService u = kantaUsb;
      if (!mounted || !u.possible || u.net || u.busy || u.scanning) return;
      if (u.connected) {
        // a laptop port that is not the weighbridge (Intel SOL) is open: keep looking for the real USB cable
        if (u.junkPort) await u.refresh(quiet: true);
        return;
      }
      await u.refresh(quiet: true);
      if (mounted && u.autoOk && !u.connected && !u.busy) await u.connect();
    });
  }

  @override
  void dispose() {
    TermNav.enabled = false;
    kantaUsb.removeListener(_tick);
    live.removeListener(_tick);
    kantaRemote.removeListener(_tick);
    KantaLog.tick.removeListener(_tick);
    KantaWa.tick.removeListener(_tick);
    _timer?.cancel();
    _khataTimer?.cancel();
    KantaLog.tick.removeListener(_khataChanged);
    super.dispose();
  }

  void _khataChanged() {
    kantaKhata.rebuild();
    kantaKhata.schedulePush();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  // ------------------------------------------------------------------ top bar
  Widget _top(bool wide) {
    final Profile? me = live.me;
    final KantaUsbService u = kantaUsb;
    final DateTime n = DateTime.now();
    const List<String> wd = <String>['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    // only what the weighing needs: the scale - and the internet only when something is wrong (all else is in Settings)
    final List<Widget> pills = <Widget>[
      if (u.connected) KPill('${bi('કાંટો', 'Scale')} · ${u.chosen?.id ?? ''}', tone: u.junkPort ? 'amber' : 'green', dot: true) else KPill(bi('કાંટો જોડાયેલો નથી', 'Scale offline'), tone: 'rose', dot: true),
      if (live.offline) KPill(bi('ઑફલાઇન', 'Offline'), tone: 'amber', icon: 'wifioff') else if (live.pending.isNotEmpty) KPill('${live.pending.length} ${bi('મોકલવાની બાકી', 'to upload')}', tone: 'blue', icon: 'cloudup'),
    ];
    final Widget brand = Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        const BrandMark(size: 44),
        const SizedBox(width: 12),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(kAppTitle, style: ts(20, w: FontWeight.w800, ls: -0.4)),
            Text('${me != null && me.name.isNotEmpty ? '${me.name} · ' : ''}${wd[n.weekday - 1]} ${n.day}/${n.month}/${n.year}', style: ts(12, c: Pal.muted)),
          ],
        ),
      ],
    );
    final Widget actions = Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Btn(bi('સેટિંગ', 'Settings'), icon: 'gear', kind: BtnKind.ghost, dense: true, tabStop: false, onTap: _openSettings),
      ],
    );
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(color: Pal.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: Pal.line), boxShadow: const <BoxShadow>[BoxShadow(color: Color(0x0F0B2C33), blurRadius: 18, offset: Offset(0, 6))]),
      child: wide
          ? Row(
              children: <Widget>[
                brand,
                const SizedBox(width: 18),
                Expanded(child: Wrap(spacing: 8, runSpacing: 8, alignment: WrapAlignment.end, children: pills)),
                const SizedBox(width: 12),
                actions,
              ],
            )
          : Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Row(children: <Widget>[Expanded(child: brand), actions]),
                const SizedBox(height: 10),
                Wrap(spacing: 8, runSpacing: 8, children: pills),
              ],
            ),
    );
  }

  // ------------------------------------------------------------------ small status strips
  Widget _strip(String icon, String tone, String text, {VoidCallback? onTap}) {
    final Tone t = Pal.tone(tone);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: t.bg,
        borderRadius: BorderRadius.circular(Pal.rad(12)),
        child: InkWell(
          borderRadius: BorderRadius.circular(Pal.rad(12)),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Row(
              children: <Widget>[
                Icon(ic(icon), size: 18, color: t.fg),
                const SizedBox(width: 10),
                Expanded(child: Text(text, style: ts(13, w: FontWeight.w700, c: t.fg))),
              ],
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> _strips() {
    // main screen: only what can lose a weighing. The phone / WhatsApp notes live in Settings.
    final List<Widget> l = <Widget>[];
    if (live.needsReauth) {
      l.add(_strip('lock', 'amber', bi('ઑફલાઇન લૉગિન - ઇન્ટરનેટ આવે ત્યારે અહીં દબાવી પાસવર્ડ નાખો (બાકી એન્ટ્રી જશે)', 'Offline login - when the internet is back tap here and enter the password (waiting entries are sent)'), onTap: () => showReauth(context)));
    } else if (live.offline) {
      l.add(_strip('wifioff', 'amber', bi('ઇન્ટરનેટ નથી - એન્ટ્રી લેપટોપમાં સચવાય છે અને નેટ આવતાં જાતે જશે', 'No internet - entries are kept on the laptop and go by themselves when the internet is back')));
    }
    if (KantaLog.lastError.isNotEmpty) {
      l.add(_strip('err', 'rose', bi('લેપટોપમાં કૉપી સેવ થઈ નથી: ${KantaLog.lastError}', 'The copy on the laptop was not saved: ${KantaLog.lastError}')));
    }
    return l;
  }

  // ------------------------------------------------------------------ keys
  void _printLast() {
    final KantaUsbService u = kantaUsb;
    if (u.made.isEmpty) {
      app.toast(bi('હજી કોઈ એન્ટ્રી બની નથી', 'No entry has been made yet'));
      return;
    }
    unawaited(printSlip(u.slipOf(u.made.first)));
  }

  void _waLast() {
    final KantaUsbService u = kantaUsb;
    if (u.made.isEmpty) {
      app.toast(bi('હજી કોઈ એન્ટ્રી બની નથી', 'No entry has been made yet'));
      return;
    }
    unawaited(sendSlipWhatsApp(u.slipOf(u.made.first)));
  }

  /// Everything that is not weighing: entries and slips (search, print again), phone weighing, WhatsApp, cable, printing, language, log out.
  void _openSettings({bool search = false}) {
    if (KantaLog.termUi) {
      TermNav.open(search ? TermFn.view : TermFn.settings);
      return;
    }
    unawaited(Navigator.of(context).push(MaterialPageRoute<void>(builder: (BuildContext c) => KantaSettings(focusSearch: search))));
  }

  Widget _keys() {
    final List<Widget> k = <Widget>[
      KKey('F2', bi('પહેલું વજન', 'First weight')),
      KKey('F3', bi('બીજું વજન', 'Second weight')),
      KKey('F4', bi('મિલ / બહારની', 'Mill / Road')),
      KKey('F8', bi('સીધું વજન', 'Direct')),
      KKey('F5', bi('પ્રિન્ટ', 'Print')),
      KKey('Enter', bi('આગળનું ખાનું', 'Next box')),
      KKey('Esc', bi('સાફ', 'Clear')),
    ];
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(color: Pal.surface2, borderRadius: BorderRadius.circular(12), border: Border.all(color: Pal.line)),
      child: Wrap(spacing: 18, runSpacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: k),
    );
  }

  @override
  Widget build(BuildContext context) {
    // like the Matrix terminal: a Home with big buttons, every job on its own screen (the old one-screen layout stays as a choice in Settings)
    if (KantaLog.termUi) return const KantaHome();
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints bc) {
        final bool wide = bc.maxWidth >= 900;
        app.stagePc = wide;
        final KantaUsbService u = kantaUsb;
        final Widget inside = InsideCard(onSecond: (InsideVehicle v) => _station.currentState?.second(v) ?? Future<void>.value(), busy: _station.currentState?.busy ?? false);
        final Widget left = Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: <Widget>[KantaWeightCard(typedKey: _station.currentState?.typedKey ?? ''), const SizedBox(height: 12), StationCard(key: _station)]);
        final Widget right = Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            inside,
            if (u.made.isNotEmpty) ...<Widget>[const SizedBox(height: 12), LastEntryCard()],
          ],
        );
        return DeviceScope(
          pc: wide,
          width: bc.maxWidth,
          height: bc.maxHeight,
          child: CallbackShortcuts(
            bindings: <ShortcutActivator, VoidCallback>{
              const SingleActivator(LogicalKeyboardKey.f2): () => unawaited(_station.currentState?.first() ?? Future<void>.value()),
              const SingleActivator(LogicalKeyboardKey.f3): () => unawaited(_station.currentState?.secondOfBox() ?? Future<void>.value()),
              const SingleActivator(LogicalKeyboardKey.f4): () => _station.currentState?.toggleMode(),
              const SingleActivator(LogicalKeyboardKey.f5): _printLast,
              const SingleActivator(LogicalKeyboardKey.f6): () => _openSettings(search: true),
              const SingleActivator(LogicalKeyboardKey.f7): _waLast,
              const SingleActivator(LogicalKeyboardKey.f8): () => unawaited(_station.currentState?.direct() ?? Future<void>.value()),
              const SingleActivator(LogicalKeyboardKey.keyP, control: true): _printLast,
              const SingleActivator(LogicalKeyboardKey.keyF, control: true): () => _openSettings(search: true),
            },
            child: Focus(
              autofocus: true,
              child: Scaffold(
                backgroundColor: Pal.bg,
                body: SafeArea(
                  child: Center(
                    child: ConstrainedBox(
                      constraints: BoxConstraints(maxWidth: wide ? 1280 : 760),
                      child: ListView(
                        padding: EdgeInsets.fromLTRB(wide ? 20 : 14, 14, wide ? 20 : 14, 28),
                        children: <Widget>[
                          _top(wide),
                          if (wide) ...<Widget>[const SizedBox(height: 12), _keys()],
                          const SizedBox(height: 12),
                          ..._strips(),
                          if (wide)
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Expanded(flex: 11, child: left),
                                const SizedBox(width: 14),
                                Expanded(flex: 10, child: right),
                              ],
                            )
                          else ...<Widget>[
                            left,
                            const SizedBox(height: 12),
                            right,
                          ],
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
