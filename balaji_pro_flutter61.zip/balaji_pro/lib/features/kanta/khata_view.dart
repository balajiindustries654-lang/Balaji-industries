import 'dart:async';
import 'package:flutter/material.dart';
import '../../core/app_state.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/icons.dart';
import '../../core/palette.dart';
import '../../data/kanta_khata.dart';
import '../../widgets/common.dart';
import '../../widgets/launch.dart' show whatsappText;
import '../../widgets/printer.dart' show saveCsvFile;
import 'kanta_ui.dart';

// ======================================================================
// The khata (weighing charges) - the list of names with their baki, the statement of one name, "Jama" (money received).
// Used by the Kanta app (screen F10) and by the owner's Balaji Pro (phone / PC): the same data, see data/kanta_khata.dart.
// ======================================================================

String _dm(DateTime d) => '${pad2(d.day)}/${pad2(d.month)}';
String _dmy(DateTime d) => '${pad2(d.day)}/${pad2(d.month)}/${d.year}';

/// A short line for a form: "Baki ₹450 (3 weighings)" - null when nothing is owed.
String? bakiLine(KhataAcc? a) {
  if (a == null || a.baki < 0.5) return null;
  return '${bi('આ નામનું બાકી', 'Baki of this name')}: ${inr(a.baki)}${a.count > 0 ? '  ·  ${a.count - a.paidCount} ${bi('વજન બાકી', 'weighings on baki')}' : ''}';
}

/// The text to send on WhatsApp to ask for the baki.
String khataReminderText(KhataAcc a) {
  final List<String> l = <String>[
    '*Balaji Industries - Kanta khata*',
    '${bi('નામ', 'Name')}: ${a.label}',
    '${bi('બાકી', 'Baki')}: ${inr(a.baki)}',
  ];
  int n = 0;
  for (final KhataLine x in a.lines) {
    if (x.paid) continue;
    if (n == 0) l.add('');
    l.add('${_dm(x.at)}  ${x.vehicle}  ${inr(x.charge)}');
    if (++n >= 12) break;
  }
  l.add('');
  l.add(bi('કૃપા કરીને ચૂકવી દેશો. આભાર.', 'Please pay at your convenience. Thank you.'));
  return l.join('\n');
}

String khataStatementText(KhataAcc a) {
  final List<String> l = <String>['Balaji Industries - Kanta khata', '${a.label}${a.mobile.isEmpty || a.name.isEmpty ? '' : '  (${a.mobile})'}', ''];
  for (final KhataLine x in a.lines) {
    l.add('${_dmy(x.at)}  RST ${x.rst}  ${x.vehicle}  ${inr(x.charge)}  ${x.paid ? bi('રોકડા', 'cash') : bi('બાકી', 'baki')}');
  }
  for (final KhataPay p in a.pays) {
    l.add('${_dmy(p.at)}  ${p.isCredit ? bi('જમા', 'Jama') : bi('બાકી નાખ્યું', 'Baki added')}  ${inr(p.amount)}${p.note.isEmpty ? '' : '  ${p.note}'}');
  }
  l.add('');
  l.add('${bi('બાકી', 'Baki')}: ${inr(a.baki)}');
  return l.join('\n');
}

// ---------------------------------------------------------------------------------------------- Jama dialog

/// Writes money received (Jama) on an account - or, with [acc] null, opens a new account with an opening baki. true = saved.
Future<bool> showKhataPay(BuildContext context, {KhataAcc? acc, bool opening = false}) async {
  final bool? ok = await showDialog<bool>(context: context, builder: (BuildContext c) => _PayDialog(acc: acc, opening: opening));
  return ok == true;
}

class _PayDialog extends StatefulWidget {
  final KhataAcc? acc;
  final bool opening;
  const _PayDialog({required this.acc, required this.opening});

  @override
  State<_PayDialog> createState() => _PayDialogState();
}

class _PayDialogState extends State<_PayDialog> {
  late final TextEditingController _name = TextEditingController(text: widget.acc?.name ?? '');
  late final TextEditingController _mobile = TextEditingController(text: widget.acc?.mobile ?? '');
  late final TextEditingController _amt = TextEditingController(text: widget.acc != null && !widget.opening && widget.acc!.baki >= 0.5 ? widget.acc!.baki.round().toString() : '');
  final TextEditingController _note = TextEditingController();
  late int _kind = widget.opening || widget.acc == null ? 1 : 0; // 0 jama, 1 baki nakho
  String _err = '';
  bool _busy = false;

  @override
  void dispose() {
    _name.dispose();
    _mobile.dispose();
    _amt.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_busy) return;
    final double a = double.tryParse(_amt.text.replaceAll(',', '').trim()) ?? 0;
    if (a <= 0) {
      setState(() => _err = bi('રકમ લખો', 'Write the amount'));
      return;
    }
    String key;
    String name;
    String mobile;
    if (widget.acc != null) {
      key = widget.acc!.key;
      name = widget.acc!.name;
      mobile = widget.acc!.mobile;
    } else {
      final KhataAcc? ex = kantaKhata.find(name: _name.text, mobile: _mobile.text);
      if (ex != null) {
        key = ex.key;
        name = ex.name;
        mobile = ex.mobile;
      } else {
        key = khataKey(_name.text, _mobile.text, '', const <String, String>{});
        name = _name.text.trim().toUpperCase();
        mobile = mobile10(_mobile.text);
        if (key.isEmpty) {
          setState(() => _err = bi('નામ કે મોબાઇલ નંબર લખો', 'Write a name or a mobile number'));
          return;
        }
      }
    }
    setState(() => _busy = true);
    final String r = await kantaKhata.addPay(key: key, name: name, mobile: mobile, amount: a, kind: _kind == 0 ? 'cr' : 'dr', note: _note.text);
    if (!mounted) return;
    if (r.isNotEmpty) {
      setState(() {
        _busy = false;
        _err = r;
      });
      return;
    }
    app.toast(_kind == 0 ? '${bi('જમા લખ્યું', 'Jama written')}: ${inr(a)}' : '${bi('બાકી લખ્યું', 'Baki written')}: ${inr(a)}');
    Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    final KhataAcc? a = widget.acc;
    return AlertDialog(
      title: Text(a == null ? bi('નવું ખાતું / જૂનું બાકી', 'New account / old baki') : a.label, style: ts(18, w: FontWeight.w800)),
      content: SizedBox(
        width: 380,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              if (a != null) Padding(padding: const EdgeInsets.only(bottom: 10), child: Text('${bi('અત્યારે બાકી', 'Baki now')}: ${inr(a.baki)}', style: ts(15, w: FontWeight.w800, c: a.baki >= 0.5 ? Pal.bad : Pal.ok))),
              if (a == null) ...<Widget>[
                FieldX(label: bi('નામ', 'Name'), controller: _name, autofocus: true, stacked: true),
                const SizedBox(height: 10),
                FieldX(label: bi('મોબાઇલ (નામ ન હોય તો)', 'Mobile (when there is no name)'), controller: _mobile, keyboard: TextInputType.phone, stacked: true),
                const SizedBox(height: 10),
              ] else if (!widget.opening)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: ChipRow(labels: <String>[bi('જમા (પૈસા મળ્યા)', 'Jama (money received)'), bi('બાકી નાખો', 'Add baki')], index: _kind, onChanged: (int i) => setState(() => _kind = i)),
                ),
              FieldX(label: _kind == 0 ? bi('મળેલી રકમ ₹', 'Amount received ₹') : bi('બાકી રકમ ₹', 'Baki amount ₹'), controller: _amt, keyboard: TextInputType.number, prefix: '₹', autofocus: a != null, stacked: true, onSubmitted: (String _) => _save()),
              const SizedBox(height: 10),
              FieldX(label: bi('નોંધ (ઇચ્છા મુજબ)', 'Note (optional)'), controller: _note, stacked: true, onSubmitted: (String _) => _save()),
              if (_err.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_err, style: ts(12.5, w: FontWeight.w700, c: Pal.bad))),
            ],
          ),
        ),
      ),
      actions: <Widget>[
        TextButton(onPressed: () => Navigator.of(context).pop(false), child: Text(bi('રદ', 'Cancel'), style: ts(14, w: FontWeight.w700, c: Pal.muted))),
        TextButton(onPressed: _busy ? null : _save, child: Text(bi('સેવ', 'Save'), style: ts(14, w: FontWeight.w800, c: Pal.brand))),
      ],
    );
  }
}

// ---------------------------------------------------------------------------------------------- the pop-up at the weighing

/// "This name has baki" - shown when a vehicle of that name is being weighed (Enter = OK).
Future<void> showBakiPopup(BuildContext context, KhataAcc a) async {
  await showDialog<void>(
    context: context,
    builder: (BuildContext c) => AlertDialog(
      icon: Icon(ic('warn'), color: Pal.warn, size: 34),
      title: Text(a.label, textAlign: TextAlign.center, style: ts(19, w: FontWeight.w800)),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Text(bi('બાકી', 'Baki'), style: ts(13, w: FontWeight.w700, c: Pal.muted)),
          Text(inr(a.baki), style: ts(34, w: FontWeight.w800, c: Pal.bad, tab: true)),
          const SizedBox(height: 6),
          if (a.mobile.isNotEmpty && a.name.isNotEmpty) Text(a.mobile, style: ts(13, c: Pal.muted)),
          if (a.count > a.paidCount) Text('${a.count - a.paidCount} ${bi('વજનના ચાર્જ બાકી', 'weighings on baki')}', style: ts(13, c: Pal.muted)),
          if (a.pays.isNotEmpty) Text('${bi('છેલ્લું જમા', 'Last jama')}: ${_dm(a.pays.first.at)} · ${inr(a.pays.first.amount)}', style: ts(12.5, c: Pal.faint)),
        ],
      ),
      actionsAlignment: MainAxisAlignment.center,
      actions: <Widget>[
        TextButton(
          onPressed: () async {
            Navigator.of(c).pop();
            await showKhataPay(context, acc: a);
          },
          child: Text(bi('જમા લો', 'Take jama'), style: ts(14, w: FontWeight.w800, c: Pal.brand)),
        ),
        TextButton(autofocus: true, onPressed: () => Navigator.of(c).pop(), child: Text('OK', style: ts(14, w: FontWeight.w800, c: Pal.ink))),
      ],
    ),
  );
}

// ---------------------------------------------------------------------------------------------- the list

class KhataBody extends StatefulWidget {
  const KhataBody({super.key});

  @override
  State<KhataBody> createState() => _KhataBodyState();
}

class _KhataBodyState extends State<KhataBody> {
  final TextEditingController _q = TextEditingController();
  int _filter = 0; // 0 baki vala, 1 badha
  String? _open;
  Timer? _t;

  @override
  void initState() {
    super.initState();
    kantaKhata.addListener(_tick);
    unawaited(kantaKhata.load().then((_) => kantaKhata.sync()));
    _t = Timer.periodic(const Duration(seconds: 30), (Timer _) => unawaited(kantaKhata.sync()));
  }

  @override
  void dispose() {
    _t?.cancel();
    kantaKhata.removeListener(_tick);
    _q.dispose();
    super.dispose();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  List<KhataAcc> _list() {
    final String q = _q.text.trim().toLowerCase();
    final String qd = q.replaceAll(RegExp(r'[^a-z0-9]'), '');
    return <KhataAcc>[
      for (final KhataAcc a in kantaKhata.accs)
        if ((_filter == 1 || a.baki >= 0.5) && (q.isEmpty || a.label.toLowerCase().contains(q) || a.name.toLowerCase().contains(q) || (qd.isNotEmpty && (a.mobile.contains(qd) || a.vehicle.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '').contains(qd))))) a,
    ];
  }

  String _csv() {
    String q(String s) => '"${s.replaceAll('"', '""')}"';
    final StringBuffer b = StringBuffer('Name,Mobile,Weighings with charge,Cash received at weighing Rs,Charges on baki Rs,Old baki added Rs,Jama Rs,BAKI Rs,Last\n');
    double tot = 0;
    for (final KhataAcc a in kantaKhata.accs) {
      if (a.baki >= 0.5) tot += a.baki;
      b.writeln('${q(a.label)},${q(a.mobile)},${a.count},${a.paidNow.round()},${a.unpaid.round()},${a.dr.round()},${a.jama.round()},${a.baki.round()},${a.last == null ? '' : _dmy(a.last!)}');
    }
    b.writeln('TOTAL BAKI,,,,,,,${tot.round()},');
    return b.toString();
  }

  Future<void> _download() async {
    final DateTime n = DateTime.now();
    final String csv = _csv();
    final String path = await saveCsvFile(csv, 'Kanta_Khata_${n.year}-${pad2(n.month)}-${pad2(n.day)}');
    if (path.isEmpty) {
      copyText(csv, msg: bi('ફાઇલ સેવ ન થઈ - લખાણ કૉપિ થયું (Excel માં પેસ્ટ કરો)', 'Could not save a file - the text was copied (paste it into Excel)'));
    } else {
      app.toast('${bi('ફાઇલ સેવ થઈ અને Excel માં ખુલી', 'File saved and opened in Excel')}: $path');
    }
  }

  Widget _summary() {
    final KantaKhata k = kantaKhata;
    final String upd = k.remoteAt == null ? '' : '${bi('લેપટોપથી છેલ્લે', 'Last from the laptop')}: ${_dm(k.remoteAt!)} ${hm(k.remoteAt!)}';
    return KCard(
      icon: 'ledger',
      title: bi('કાંટા ખાતું (ચાર્જ બાકી)', 'Weighbridge khata (charges baki)'),
      sub: k.host ? '${bi('ગણતરી શરૂ', 'Counted from')}: ${_dmy(k.from)}' : upd,
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          IconBtn('dl', tip: bi('ડાઉનલોડ (Excel)', 'Download (Excel)'), size: 38, onTap: k.accs.isEmpty ? null : () => unawaited(_download())),
          IconBtn('refresh', tip: bi('તાજું કરો', 'Refresh'), size: 38, onTap: () => unawaited(k.sync())),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: <Widget>[
              KStat(bi('કુલ બાકી', 'Total baki'), inr(k.totalBaki), tone: k.totalBaki >= 0.5 ? 'rose' : 'green'),
              KStat(bi('બાકી વાળા', 'Names owing'), '${k.owingCount}', tone: 'amber'),
              KStat(bi('કુલ ખાતાં', 'Accounts'), '${k.accs.length}', tone: 'slate'),
            ],
          ),
          if (k.error.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text(bi('સર્વર સાથે મેળ થયો નથી (ઇન્ટરનેટ?) - જે છે તે બતાવ્યું.', 'Could not sync with the server (internet?) - showing what we have.'), style: ts(12, w: FontWeight.w700, c: Pal.warn))),
          const SizedBox(height: 12),
          Row(
            children: <Widget>[
              Expanded(child: SearchBox(hint: bi('નામ / મોબાઇલ / ગાડી શોધો', 'Search name / mobile / vehicle'), controller: _q, onChanged: (String _) => setState(() {}))),
              const SizedBox(width: 10),
              Btn(bi('+ નવું / જૂનું બાકી', '+ New / old baki'), kind: BtnKind.outline, dense: true, tabStop: false, onTap: () => unawaited(showKhataPay(context, opening: true).then((bool _) => _tick()))),
            ],
          ),
          const SizedBox(height: 10),
          ChipRow(labels: <String>[bi('બાકી વાળા', 'Owing'), bi('બધા', 'All')], index: _filter, onChanged: (int i) => setState(() => _filter = i)),
        ],
      ),
    );
  }

  Widget _row(KhataAcc a) {
    final bool open = _open == a.key;
    final bool owes = a.baki >= 0.5;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(color: Pal.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: open ? Pal.brand : Pal.line, width: open ? 1.5 : 1)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () => setState(() => _open = open ? null : a.key),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
              child: Row(
                children: <Widget>[
                  Container(width: 38, height: 38, decoration: BoxDecoration(color: owes ? Pal.tone('rose').bg : Pal.tone('green').bg, borderRadius: BorderRadius.circular(12)), child: Icon(ic(a.name.isNotEmpty ? 'user' : (a.mobile.isNotEmpty ? 'phone' : 'truck')), size: 20, color: owes ? Pal.tone('rose').fg : Pal.tone('green').fg)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(a.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(15, w: FontWeight.w800)),
                        Text(
                          <String>[
                            if (a.name.isNotEmpty && a.mobile.isNotEmpty) a.mobile,
                            '${a.count} ${bi('વજન', 'weighings')}',
                            if (a.last != null) _dm(a.last!),
                          ].join('  ·  '),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: ts(11.5, c: Pal.muted),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: <Widget>[
                      Text(owes ? inr(a.baki) : '✓', style: ts(owes ? 18 : 16, w: FontWeight.w800, c: owes ? Pal.bad : Pal.ok, tab: true)),
                      Text(owes ? bi('બાકી', 'baki') : bi('ચૂકતે', 'clear'), style: ts(10.5, w: FontWeight.w700, c: Pal.faint)),
                    ],
                  ),
                ],
              ),
            ),
          ),
          if (open) _detail(a),
        ],
      ),
    );
  }

  Widget _detail(KhataAcc a) {
    final List<Widget> lines = <Widget>[];
    for (final KhataLine x in a.lines.take(20)) {
      lines.add(Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(
          children: <Widget>[
            SizedBox(width: 48, child: Text(_dm(x.at), style: ts(12.5, c: Pal.muted, tab: true))),
            SizedBox(width: 56, child: Text('RST ${x.rst}', maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12, c: Pal.faint, tab: true))),
            Expanded(child: Text(x.vehicle, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(13, w: FontWeight.w700))),
            Text(inr(x.charge), style: ts(13, w: FontWeight.w800, tab: true)),
            const SizedBox(width: 8),
            SizedBox(width: 44, child: Text(x.paid ? bi('રોકડા', 'cash') : bi('બાકી', 'baki'), textAlign: TextAlign.right, style: ts(11.5, w: FontWeight.w800, c: x.paid ? Pal.ok : Pal.warn))),
          ],
        ),
      ));
    }
    final List<Widget> pays = <Widget>[
      for (final KhataPay p in a.pays)
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 2),
          child: Row(
            children: <Widget>[
              SizedBox(width: 48, child: Text(_dm(p.at), style: ts(12.5, c: Pal.muted, tab: true))),
              Expanded(child: Text('${p.isCredit ? bi('જમા', 'Jama') : bi('બાકી નાખ્યું', 'Baki added')}${p.note.isEmpty ? '' : '  ·  ${p.note}'}${p.by.isEmpty ? '' : '  ·  ${p.by}'}', maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12.5, c: Pal.muted))),
              Text('${p.isCredit ? '−' : '+'} ${inr(p.amount)}', style: ts(13, w: FontWeight.w800, c: p.isCredit ? Pal.ok : Pal.bad, tab: true)),
              IconBtn('trash', tip: bi('કાઢી નાખો', 'Delete'), size: 34, onTap: () => unawaited(_deletePay(p))),
            ],
          ),
        ),
    ];
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          const Divider(height: 14),
          Text(
            '${bi('બાકી ચાર્જ', 'Charges on baki')} ${inr(a.unpaid)}${a.dr > 0 ? '  +  ${bi('જૂનું બાકી', 'old baki')} ${inr(a.dr)}' : ''}  −  ${bi('જમા', 'jama')} ${inr(a.jama)}  =  ${inr(a.baki)}${a.paidNow > 0 ? '\n${bi('વજન વખતે રોકડા મળ્યા', 'Cash received at the weighing')}: ${inr(a.paidNow)} (${a.paidCount})' : ''}',
            style: ts(12.5, c: Pal.muted, h: 1.4),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <Widget>[
              Btn(bi('જમા લો', 'Take jama'), icon: 'check', dense: true, tabStop: false, onTap: () => unawaited(showKhataPay(context, acc: a).then((bool _) => _tick()))),
              if (a.baki >= 0.5) Btn(bi('WhatsApp યાદ', 'WhatsApp reminder'), icon: 'share', kind: BtnKind.tonal, dense: true, tabStop: false, onTap: () => unawaited(whatsappText(khataReminderText(a), phone: a.mobile))),
              Btn(bi('હિસાબ કૉપિ', 'Copy statement'), icon: 'copy', kind: BtnKind.outline, dense: true, tabStop: false, onTap: () => copyText(khataStatementText(a), msg: bi('કૉપિ થયું', 'Copied'))),
            ],
          ),
          if (lines.isNotEmpty) ...<Widget>[const SizedBox(height: 10), Text(bi('વજન (ચાર્જ સાથે)', 'Weighings (with charges)'), style: ts(12, w: FontWeight.w800, c: Pal.muted)), ...lines],
          if (lines.isEmpty && a.count > 0) Padding(padding: const EdgeInsets.only(top: 8), child: Text(bi('વજનની યાદી ફક્ત બાકી વાળા ખાતાં માટે ફોન પર આવે છે.', 'The list of weighings comes to the phone only for accounts that owe.'), style: ts(11.5, c: Pal.faint))),
          if (pays.isNotEmpty) ...<Widget>[const SizedBox(height: 10), Text(bi('જમા / જૂનું બાકી', 'Jama / old baki'), style: ts(12, w: FontWeight.w800, c: Pal.muted)), ...pays],
        ],
      ),
    );
  }

  Future<void> _deletePay(KhataPay p) async {
    final bool? ok = await showDialog<bool>(
      context: context,
      builder: (BuildContext c) => AlertDialog(
        title: Text(bi('આ નોંધ કાઢી નાખવી?', 'Delete this entry?'), style: ts(17, w: FontWeight.w800)),
        content: Text('${p.isCredit ? bi('જમા', 'Jama') : bi('બાકી નાખ્યું', 'Baki added')} ${inr(p.amount)} · ${_dmy(p.at)}', style: ts(14)),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.of(c).pop(false), child: Text(bi('ના', 'No'), style: ts(14, w: FontWeight.w700, c: Pal.muted))),
          TextButton(onPressed: () => Navigator.of(c).pop(true), child: Text(bi('હા, કાઢો', 'Yes, delete'), style: ts(14, w: FontWeight.w800, c: Pal.bad))),
        ],
      ),
    );
    if (ok == true) await kantaKhata.removePay(p.id);
  }

  @override
  Widget build(BuildContext context) {
    final List<KhataAcc> l = _list();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        _summary(),
        const SizedBox(height: 12),
        if (l.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 24),
            child: Text(
              kantaKhata.accs.isEmpty ? bi('હજી કોઈ ખાતું નથી. ચાર્જ વાળું વજન "બાકી" તરીકે લેશો ત્યારે નામ મુજબ ખાતું આપોઆપ બનશે.', 'No account yet. When a weighing with a charge is saved as "baki" the account of that name is made by itself.') : bi('કોઈ બાકી નથી ✓', 'Nothing is owed ✓'),
              textAlign: TextAlign.center,
              style: ts(14, c: Pal.muted, h: 1.4),
            ),
          ),
        for (final KhataAcc a in l.take(300)) _row(a),
      ],
    );
  }
}
