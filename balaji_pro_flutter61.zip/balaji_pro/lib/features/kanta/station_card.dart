import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/app_state.dart';
import '../../core/fmt.dart';
import '../../core/i18n.dart';
import '../../core/icons.dart';
import '../../core/palette.dart';
import '../../data/kanta_khata.dart';
import '../../data/kanta_log.dart';
import '../../data/kanta_people.dart';
import '../../data/kanta_slip.dart';
import '../../data/kanta_usb.dart';
import '../../data/kanta_wa.dart';
import '../../data/lists.dart' show kCommodities;
import '../../data/live_store.dart';
import '../../widgets/common.dart';
import '../live/field.dart' show PickChips;
import '../live/ui.dart' show SuggestField;
import 'kanta_print.dart';
import 'kanta_ui.dart';
import 'khata_view.dart';

/// The weighing station: vehicle -> first weight -> (the vehicle goes, comes back) -> second weight -> entry.
/// Everything works from the keyboard like the Matrix terminal: Enter = next box, F2 = first weight, F3 = second weight,
/// F4 = mill / road vehicle, Esc = clear the boxes.
/// Where the station card is used: [classic] the one-screen layout (first weight form + direct weighing box); [first] the First Weighment
/// screen of the terminal layout; [manual] its Manual Tare (direct weighing) screen.
enum StationMode { classic, first, manual }

class StationCard extends StatefulWidget {
  final StationMode mode;

  /// Called after a first weight / an entry was saved ([madeEntry]: an entry (slip) was made) - the terminal layout then leaves the screen.
  final void Function(bool madeEntry)? onDone;

  /// Called by Cancel (terminal layout: back to Home).
  final VoidCallback? onCancel;
  const StationCard({super.key, this.mode = StationMode.classic, this.onDone, this.onCancel});

  @override
  State<StationCard> createState() => StationCardState();
}

String _norm(String s) => s.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');

/// Letters a dot-matrix printer cannot print (Gujarati ...).
bool _hasNonAscii(String s) => s.runes.any((int c) => c > 126);

class StationCardState extends State<StationCard> {
  final TextEditingController _veh = TextEditingController();
  final TextEditingController _mobile = TextEditingController();
  final TextEditingController _party = TextEditingController();
  final TextEditingController _material = TextEditingController();
  final TextEditingController _city = TextEditingController();
  final TextEditingController _charges = TextEditingController();
  final TextEditingController _tare = TextEditingController();
  final FocusNode _vehF = FocusNode(debugLabel: 'station-vehicle');
  bool _busy = false;

  /// The charges were taken in cash at the weighing (false: baki - goes to the khata of the name).
  bool _paid = KantaLog.chargePaid;

  /// false: the mill's own vehicle (entry goes to the app / server); true: a vehicle from the road (laptop only).
  bool _out = false;

  /// The vehicle number the boxes were last filled for (asked once per number) and a note about it.
  String _filledKey = '';
  String _note = '';

  bool get busy => _busy;

  /// The typed vehicle number without spaces / dashes (the screen shows its first weight and the net so far).
  String get typedKey => _norm(_veh.text);

  bool get isRoad => _out;

  /// The RST number the next mill vehicle gets (shown in the title bar of the terminal screens).
  String _rstNext = '';

  Future<void> _loadRst() async {
    try {
      final String r = await kantaUsb.peekRst();
      if (mounted) setState(() => _rstNext = r);
    } catch (_) {}
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _vehF.requestFocus();
    });
    unawaited(_loadRst());
  }

  @override
  void dispose() {
    for (final TextEditingController c in <TextEditingController>[_veh, _mobile, _party, _material, _city, _charges, _tare]) {
      c.dispose();
    }
    _vehF.dispose();
    super.dispose();
  }

  static String errText(String e) {
    if (e == 'vehicle') return bi('પહેલાં ગાડી નંબર લખો', 'Write the vehicle number first');
    if (e == 'no steady weight') return steadyWhyText();
    if (e == 'tare') return bi('ટેર (ખાલી ગાડીનું વજન) KG માં લખો', 'Write the tare (empty weight) in KG');
    if (e == 'tare high') {
      final double? v = kantaUsb.dec.kg;
      return bi('ટેર કાંટા પરના વજન (${v == null ? '-' : grp(v, dec: 0)} KG) કરતાં ઓછું હોવું જોઈએ', 'The tare must be less than the weight on the scale (${v == null ? '-' : grp(v, dec: 0)} KG)');
    }
    if (e == 'same weight') return bi('આ વજન પહેલા વજન જેટલું જ છે. ગાડી ખાલી (કે ભરેલી) થઈને ફરી આવે ત્યારે દબાવો.', 'This weight is the same as the first one. Tap when the vehicle has come back empty (or loaded).');
    return e;
  }

  /// In words: why a weight cannot be taken now (the live weight, the minimum, moving...). Never empty.
  static String steadyWhyText() {
    final KantaUsbService u = kantaUsb;
    final double? v = u.dec.kg;
    final String now = v == null ? '' : grp(v, dec: v == v.roundToDouble() ? 0 : 1);
    final String min = grp(u.minKg, dec: 0);
    switch (u.steadyWhy) {
      case 'not connected':
        return bi('કાંટો જોડાયેલો નથી (કેબલ તપાસો).', 'The scale is not connected (check the cable).');
      case 'no weight':
        return bi('કાંટા પરથી વજન આવતું નથી.', 'No weight is coming from the scale.');
      case 'low':
        return u.minKg <= 0
            ? bi('કાંટા પર વજન નથી ($now KG). ગાડી કાંટા પર ચડાવો.', 'Nothing is on the scale ($now KG). Drive the vehicle onto it.')
            : bi('કાંટા પર $now KG છે - ઓછામાં ઓછું $min KG જોઈએ.', 'The scale shows $now KG - at least $min KG is needed.');
      case 'moving':
        return bi('વજન હજી બદલાય છે ($now KG) - 2-3 સેકન્ડ સ્થિર થવા દો.', 'The weight is still moving ($now KG) - let it settle for 2-3 seconds.');
    }
    return bi('વજન સ્થિર છે.', 'The weight is steady.');
  }

  // ------------------------------------------------------------------ keyboard / form helpers
  void focusVehicle() {
    if (mounted) _vehF.requestFocus();
  }

  /// F4: mill vehicle <-> road vehicle.
  void toggleMode() => setState(() => _out = !_out);

  /// Esc: empties every box and goes back to the vehicle number.
  void clear() {
    for (final TextEditingController c in <TextEditingController>[_veh, _mobile, _party, _material, _city, _charges, _tare]) {
      c.clear();
    }
    _filledKey = '';
    _note = '';
    if (mounted) setState(() {});
    focusVehicle();
  }

  // ------------------------------------------------------------------ suggestions
  /// Vehicle numbers worth offering: the ones waiting for the weighbridge, then the ones weighed lately.
  List<String> _vehicles() {
    final KantaUsbService u = kantaUsb;
    final List<String> out = <String>[];
    final Set<String> seen = <String>{};
    void add(String v) {
      final String t = v.trim().toUpperCase();
      if (t.isEmpty) return;
      if (u.inside.any((InsideVehicle x) => x.vehicle.toUpperCase() == t)) return;
      if (seen.add(_norm(t))) out.add(t);
    }

    if (_out) {
      for (final SlipRec r in KantaHistory.items.take(300)) {
        if (r.outside) add(r.vehicle);
      }
    } else {
      for (final String v in u.waitingVehicles) {
        add(v);
      }
      try {
        for (final k in live.kantas.take(120)) {
          add(k.vehicle);
        }
      } catch (_) {}
      for (final SlipRec r in KantaHistory.items.take(200)) {
        if (!r.outside) add(r.vehicle);
      }
    }
    return out;
  }

  /// Names the weighbridge already knows (slips of the laptop, server entries, chits, khata) - a part of a name is enough to find it.
  List<String> _parties() => KantaPeople.names();

  List<String> _materials() {
    final List<String> l = <String>[for (final List<String> c in kCommodities) if (c[0] != 'Other') c[0]];
    for (final String h in KantaHistory.recent((SlipRec r) => r.material)) {
      if (!l.any((String x) => x.toLowerCase() == h.toLowerCase())) l.add(h);
    }
    return l;
  }

  List<String> _cities() => KantaPeople.cities();

  /// A vehicle number -> the party that weighed with it last (the small grey line in the list).
  Map<String, String> _vehHints(List<String> vehicles) {
    final Map<String, String> h = <String, String>{};
    for (final String v in vehicles) {
      final String p = KantaPeople.partyOfVehicle(v);
      if (p.isNotEmpty) h[v] = p;
    }
    return h;
  }

  /// A name was chosen from the list: the mobile number, town and goods of its last weighing are filled in (only into empty boxes).
  void _partyPicked(String name) {
    bool any = false;
    void fill(TextEditingController c, String v) {
      if (c.text.trim().isEmpty && v.trim().isNotEmpty) {
        c.text = v.trim();
        any = true;
      }
    }

    final String k = name.trim().toLowerCase();
    SlipRec? r;
    for (final SlipRec x in KantaHistory.items) {
      if (!x.undone && x.party.trim().toLowerCase() == k) {
        r = x;
        break;
      }
    }
    fill(_mobile, KantaPeople.mobileOfName(name));
    if (r != null) {
      fill(_mobile, r.mobile);
      fill(_city, r.city);
      fill(_material, r.material);
    }
    if (any) _note = bi('આ નામની છેલ્લી વખતની વિગત ભરી', 'Filled from the last visit of this name');
    setState(() {});
  }

  /// A mobile number was chosen from the list: its name is filled in (only into an empty box).
  void _mobilePicked(String mobile) {
    final String n = KantaPeople.nameOfMobile(mobile);
    if (_party.text.trim().isEmpty && n.isNotEmpty) {
      _party.text = n;
      _note = bi('આ નંબરનું નામ ભર્યું', 'Filled the name of this number');
      _partyPicked(n);
      return;
    }
    setState(() {});
  }

  /// A vehicle came again: the party, goods, town and mobile of its last weighing are filled in (only into empty boxes).
  void _vehChanged(String t) {
    final String k = _norm(t);
    if (k.length < 6) {
      _filledKey = '';
      _note = '';
    } else if (k != _filledKey) {
      _filledKey = k;
      _note = '';
      final SlipRec? r = KantaHistory.lastOf(t);
      if (r != null) {
        bool any = false;
        void fill(TextEditingController c, String v) {
          if (c.text.trim().isEmpty && v.trim().isNotEmpty) {
            c.text = v.trim();
            any = true;
          }
        }

        // a mill vehicle with a chit gets the farmer of the chit on the slip by itself - do not fill an old name over it
        final bool chitParty = !_out && kantaUsb.partyProvider(t).isNotEmpty;
        if (!chitParty) fill(_party, r.party);
        fill(_material, r.material);
        fill(_city, r.city);
        fill(_mobile, r.mobile);
        if (any) _note = '${bi('છેલ્લી વખતની વિગત ભરી', 'Filled from the last visit')} · ${r.at.day}/${r.at.month}';
      }
    }
    setState(() {});
  }

  // ------------------------------------------------------------------ the two weighings
  /// First weight (F2).
  Future<void> first() async {
    if (_busy) return;
    final String v = _veh.text.trim().toUpperCase();
    final String mob = _mobile.text.replaceAll(RegExp(r'[^0-9]'), '');
    if (v.isNotEmpty && mob.isNotEmpty && mob.length != 10) {
      app.toast(bi('મોબાઇલ નંબર 10 આંકડાનો જોઈએ', 'The mobile number must have 10 digits'));
      return;
    }
    setState(() => _busy = true);
    final double ch = double.tryParse(_charges.text.replaceAll(',', '').trim()) ?? 0;
    final String r = await kantaUsb.takeFirst(v, outside: _out, party: _party.text, charges: ch, paid: _paid, mobile: mob, material: _material.text, city: _city.text);
    if (!mounted) return;
    setState(() => _busy = false);
    if (r.isEmpty) {
      app.toast('${bi('પહેલું વજન લીધું', 'First weight taken')}: $v');
      clear();
      unawaited(_loadRst());
      widget.onDone?.call(false);
    } else {
      app.toast(errText(r));
    }
  }

  /// Direct weighing (F8): the tare is written by hand, the weight on the platform is the gross, the entry is made at once.
  Future<void> direct() async {
    if (_busy) return;
    final String v = _veh.text.trim().toUpperCase();
    final String mob = _mobile.text.replaceAll(RegExp(r'[^0-9]'), '');
    if (v.isNotEmpty && mob.isNotEmpty && mob.length != 10) {
      app.toast(bi('મોબાઇલ નંબર 10 આંકડાનો જોઈએ', 'The mobile number must have 10 digits'));
      return;
    }
    final double tare = double.tryParse(_tare.text.replaceAll(',', '').trim()) ?? 0;
    final double ch = double.tryParse(_charges.text.replaceAll(',', '').trim()) ?? 0;
    setState(() => _busy = true);
    final String r = await kantaUsb.takeDirect(v, tare, outside: _out, party: _party.text, charges: ch, paid: _paid, mobile: mob, material: _material.text, city: _city.text);
    if (!mounted) return;
    setState(() => _busy = false);
    if (r.isEmpty) {
      final AutoMade? m = kantaUsb.made.isEmpty ? null : kantaUsb.made.first;
      app.toast(m == null ? bi('એન્ટ્રી બની', 'Entry made') : '${m.outside ? bi('સ્લિપ બની (ફક્ત લેપટોપમાં)', 'Slip made (laptop only)') : bi('એન્ટ્રી બની', 'Entry made')} · ${m.outside ? '' : 'RST '}${m.rst} · ${grp(m.net, dec: 0)} KG');
      clear();
      unawaited(_loadRst());
      widget.onDone?.call(true);
    } else {
      app.toast(errText(r));
    }
  }

  /// Second weight (F3) of the vehicle in the box, or the only one that is inside.
  Future<void> secondOfBox() async {
    final KantaUsbService u = kantaUsb;
    final String key = typedKey;
    InsideVehicle? v;
    if (key.isNotEmpty) {
      for (final InsideVehicle x in u.inside) {
        if (_norm(x.vehicle) == key) v = x;
      }
    }
    v ??= u.inside.length == 1 ? u.inside.first : null;
    if (v == null) {
      app.toast(u.inside.isEmpty ? bi('કોઈ ગાડી અંદર નથી', 'No vehicle is inside') : bi('કઈ ગાડી? ગાડી નંબર લખો કે જમણી બાજુ ગાડી પર "બીજું વજન લો" દબાવો', 'Which vehicle? Write its number or tap "Take second weight" on the vehicle at the right'));
      return;
    }
    await second(v);
  }

  Future<void> second(InsideVehicle v) async {
    if (_busy) return;
    setState(() => _busy = true);
    final String r = await kantaUsb.takeSecond(v);
    if (!mounted) return;
    setState(() => _busy = false);
    if (r.isEmpty) {
      final AutoMade? m = kantaUsb.made.isEmpty ? null : kantaUsb.made.first;
      final String small = (m != null && m.net < 50) ? '\n${bi('ચોખ્ખું બહુ ઓછું છે - ખોટું લાગે તો એન્ટ્રીમાંથી "પાછું લો".', 'The net is very small - if it looks wrong, use "Take back" on the entry.')}' : '';
      final String head = m == null
          ? bi('એન્ટ્રી બની', 'Entry made')
          : (m.outside ? '${bi('સ્લિપ બની (ફક્ત લેપટોપમાં)', 'Slip made (laptop only)')} · ${m.rst} · ${grp(m.net, dec: 0)} KG' : '${bi('એન્ટ્રી બની', 'Entry made')} · RST ${m.rst} · ${grp(m.net, dec: 0)} KG');
      app.toast('$head$small');
      _veh.clear();
      _filledKey = '';
      _note = '';
      setState(() {});
      focusVehicle();
      unawaited(_loadRst());
      widget.onDone?.call(true);
    } else {
      app.toast(errText(r));
    }
  }

  // ------------------------------------------------------------------ look
  Widget _seg(String icon, String text, String key, bool on, VoidCallback onTap) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        canRequestFocus: false,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 140),
          padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 10),
          decoration: BoxDecoration(color: on ? Pal.brand : Pal.soft, borderRadius: BorderRadius.circular(12)),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(ic(icon), size: 18, color: on ? Colors.white : Pal.brand),
              const SizedBox(width: 8),
              Flexible(child: Text(text, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(13.5, w: FontWeight.w800, c: on ? Colors.white : Pal.brand))),
              if (on) ...<Widget>[
                const SizedBox(width: 8),
                Text(key, style: ts(11, w: FontWeight.w800, c: const Color(0xB3FFFFFF))),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _pair(Widget a, Widget b, bool two) {
    if (!two) return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: <Widget>[a, const SizedBox(height: 12), b]);
    return Row(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[Expanded(child: a), const SizedBox(width: 14), Expanded(child: b)]);
  }

  @override
  Widget build(BuildContext context) {
    final KantaUsbService u = kantaUsb;
    final double? st = u.steadyKg;
    final String vtxt = _veh.text.trim();
    final bool canFirst = vtxt.isNotEmpty && st != null && !_busy;
    final String chitParty = (!_out && vtxt.isNotEmpty) ? kantaUsb.partyProvider(vtxt) : '';
    final String chitMobile = (!_out && vtxt.isNotEmpty) ? kantaUsb.mobileProvider(vtxt) : '';
    final String mob = _mobile.text.replaceAll(RegExp(r'[^0-9]'), '');
    final bool badMob = mob.isNotEmpty && mob.length != 10;
    final bool ascii = KantaLog.printMode == 1 && (_hasNonAscii(_party.text) || _hasNonAscii(_material.text) || _hasNonAscii(_city.text));
    final List<String> vehs = _vehicles();
    final List<String> quick = vtxt.isEmpty ? vehs.take(8).toList() : const <String>[];
    final double chargeVal = double.tryParse(_charges.text.replaceAll(',', '').trim()) ?? 0;
    final KhataAcc? ka = kantaKhata.find(name: _party.text.trim().isNotEmpty ? _party.text : chitParty, mobile: _mobile.text, vehicle: vtxt);
    final String? bakiTxt = bakiLine(ka);
    final bool two = MediaQuery.of(context).size.width >= 720; // two boxes side by side on a laptop screen
    return Focus(
      canRequestFocus: false,
      skipTraversal: true,
      onKeyEvent: (FocusNode n, KeyEvent e) {
        if (e is KeyDownEvent && e.logicalKey == LogicalKeyboardKey.escape) {
          clear();
          return KeyEventResult.handled;
        }
        return KeyEventResult.ignored;
      },
      child: KCard(
        icon: 'scale',
        title: widget.mode == StationMode.manual ? bi('મેન્યુઅલ ટેર (સીધું વજન)', 'Manual Tare (direct weighing)') : (widget.mode == StationMode.first ? bi('પહેલું વજન', 'First weighment') : bi('ગાડી તોલો', 'Weigh a vehicle')),
        sub: widget.mode == StationMode.manual
            ? bi('ટેર હાથે લખો - કાંટા પરનું વજન ગ્રોસ ગણાશે, એન્ટ્રી તરત બનશે', 'Write the tare by hand - the weight on the scale counts as gross, the entry is made at once')
            : (widget.mode == StationMode.first
                ? bi('ગાડી કાંટા પર ઊભી રાખો → ગાડી નંબર લખો → સેવ. પછી ગાડી જાય, ખાલી થઈને આવે ત્યારે "બીજું વજન" (F2).', 'Vehicle on the scale → write the number → Save. When it comes back empty use "Second weighment" (F2).')
                : bi('પહેલું વજન (F2) → ગાડી જાય, ખાલી થઈને આવે → બીજું વજન (F3)', 'First weight (F2) → the vehicle goes and comes back → second weight (F3)')),
        trailing: KPill(_out ? '${bi('સ્લિપ', 'Slip')} ${u.nextRoadSlip}' : (widget.mode != StationMode.classic && _rstNext.isNotEmpty ? 'RST $_rstNext' : bi('RST આપોઆપ', 'RST automatic')), tone: _out ? 'amber' : 'green', icon: 'receipt'),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Row(
              children: <Widget>[
                _seg('factory', bi('મિલની ગાડી', 'Mill vehicle'), 'F4', !_out, () => setState(() => _out = false)),
                const SizedBox(width: 10),
                _seg('road', bi('બહારની ગાડી', 'Road vehicle'), 'F4', _out, () => setState(() => _out = true)),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              _out
                  ? bi('સ્લિપ ફક્ત આ લેપટોપમાં સેવ થાય છે - એપ / સર્વરમાં જતી નથી (નંબર R-1, R-2…).', 'The slip is saved on this laptop only - it does not go to the app / server (numbers R-1, R-2…).')
                  : bi('એન્ટ્રી તરત એપ / સર્વર પર (RST આપોઆપ) અને લેપટોપમાં કૉપી સેવ થાય છે.', 'The entry goes to the app / server at once (RST automatic) and a copy is saved on this laptop.'),
              style: ts(12, w: FontWeight.w700, c: _out ? Pal.warn : Pal.ok),
            ),
            const SizedBox(height: 14),
            _pair(
              SuggestField(label: '${bi('ગાડી નંબર', 'Vehicle number')} *', controller: _veh, options: vehs, hints: _vehHints(vehs), hint: 'GJ03AB1234', focusNode: _vehF, onChanged: _vehChanged),
              SuggestField(
                label: bi('મોબાઇલ નંબર', 'Mobile number'),
                controller: _mobile,
                options: KantaPeople.mobiles(),
                hints: KantaPeople.mobileHints(),
                keyboard: TextInputType.phone,
                prefix: '+91',
                hint: chitMobile.isEmpty ? '' : chitMobile,
                onPick: _mobilePicked,
                onChanged: (String _) => setState(() {}),
              ),
              two,
            ),
            if (quick.isNotEmpty) ...<Widget>[
              const SizedBox(height: 8),
              PickChips(title: bi('રાહ જોતી ગાડી', 'Vehicles waiting'), values: quick, onPick: (String v) {
                _veh.text = v;
                _vehChanged(v);
              }),
            ],
            if (_note.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text(_note, style: ts(11.5, w: FontWeight.w700, c: Pal.info))),
            if (badMob) Padding(padding: const EdgeInsets.only(top: 6), child: Text(bi('મોબાઇલ નંબર 10 આંકડાનો જોઈએ', 'The mobile number needs 10 digits'), style: ts(11.5, w: FontWeight.w700, c: Pal.bad))),
            const SizedBox(height: 12),
            _pair(
              SuggestField(label: bi('સપ્લાયર / પાર્ટી', 'Supplier / party'), controller: _party, options: _parties(), hints: KantaPeople.nameHints(), onPick: _partyPicked, onChanged: (String _) => setState(() {})),
              SuggestField(label: bi('માલ', 'Material'), controller: _material, options: _materials(), onChanged: (String _) => setState(() {})),
              two,
            ),
            if (bakiTxt != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(color: Pal.tone('amber').bg, borderRadius: BorderRadius.circular(12)),
                  child: Row(
                    children: <Widget>[
                      Icon(ic('warn'), size: 18, color: Pal.tone('amber').fg),
                      const SizedBox(width: 10),
                      Expanded(child: Text(bakiTxt, style: ts(13.5, w: FontWeight.w800, c: Pal.tone('amber').fg))),
                      Btn(bi('જમા લો', 'Take jama'), kind: BtnKind.outline, dense: true, tabStop: false, onTap: () => unawaited(showKhataPay(context, acc: ka).then((bool _) {
                        if (mounted) setState(() {});
                      }))),
                    ],
                  ),
                ),
              ),
            if (chitParty.isNotEmpty && _party.text.trim().isEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text('${bi('ચિઠ્ઠી મુજબ પાર્ટી (સ્લિપ પર આવશે)', 'Party on the chit (goes on the slip)')}: $chitParty', style: ts(11.5, w: FontWeight.w700, c: Pal.muted))),
            const SizedBox(height: 12),
            _pair(
              SuggestField(label: bi('ગામ / શહેર', 'City / village'), controller: _city, options: _cities(), onChanged: (String _) => setState(() {})),
              FieldX(
                label: bi('ચાર્જ ₹', 'Charges ₹'),
                controller: _charges,
                keyboard: TextInputType.number,
                prefix: '₹',
                onChanged: (String _) => setState(() {}),
                onSubmitted: (String _) => first(),
              ),
              two,
            ),
            if (chargeVal > 0) ...<Widget>[
              const SizedBox(height: 10),
              Text(bi('આ ચાર્જ', 'This charge'), style: ts(12.5, w: FontWeight.w700, c: Pal.muted)),
              const SizedBox(height: 4),
              ChipRow(
                labels: <String>[bi('બાકી - ખાતામાં લખો', 'Baki - write in the khata'), bi('રોકડા લીધા', 'Cash received')],
                index: _paid ? 1 : 0,
                onChanged: (int i) {
                  setState(() => _paid = i == 1);
                  unawaited(KantaLog.setChargePaid(_paid));
                },
              ),
            ],
            if (ascii) Padding(padding: const EdgeInsets.only(top: 8), child: Text(bi('ધ્યાન: Epson dot-matrix સ્લિપ પર ગુજરાતી અક્ષર "?" છપાશે - સ્લિપ માટે અંગ્રેજી અક્ષરમાં લખો.', 'Note: Gujarati letters print as "?" on the Epson dot-matrix slip - write in English letters for the printed slip.'), style: ts(11.5, w: FontWeight.w700, c: Pal.warn))),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 6,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: <Widget>[
                KPill(bi('ગ્રોસ / ટેર: આપોઆપ (ભારે = ગ્રોસ)', 'Gross / Tare: automatic (heavier = Gross)'), tone: 'slate', icon: 'balance'),
              ],
            ),
            if (widget.mode == StationMode.manual) ...<Widget>[
              const SizedBox(height: 12),
              FieldX(label: bi('ટેર KG (ખાલી ગાડીનું વજન)', 'Tare KG (empty weight)'), controller: _tare, keyboard: TextInputType.number, onChanged: (String _) => setState(() {}), onSubmitted: (String _) => direct()),
            ],
            const SizedBox(height: 14),
            Row(
              children: <Widget>[
                Expanded(
                  child: widget.mode == StationMode.manual
                      ? Btn(
                          '${bi('સેવ (સીધું વજન)', 'Save (direct weighing)')}${st == null ? '' : ' · ${grp(st, dec: 0)} KG'}',
                          icon: 'check',
                          expand: true,
                          onTap: (vtxt.isNotEmpty && st != null && !_busy && (double.tryParse(_tare.text.replaceAll(',', '').trim()) ?? 0) > 0) ? direct : null,
                        )
                      : Btn(
                          widget.mode == StationMode.first ? '${bi('સેવ (પહેલું વજન)', 'Save (first weight)')}${st == null ? '' : ' · ${grp(st, dec: 0)} KG'}' : '${bi('પહેલું વજન લો', 'Take first weight')}${st == null ? '' : ' · ${grp(st, dec: 0)} KG'}   (F2)',
                          icon: widget.mode == StationMode.first ? 'check' : 'plus',
                          expand: true,
                          onTap: canFirst ? first : null,
                        ),
                ),
                const SizedBox(width: 10),
                if (widget.mode == StationMode.classic) Btn(bi('સાફ (Esc)', 'Clear (Esc)'), kind: BtnKind.ghost, tabStop: false, onTap: clear) else Btn(bi('રદ (Esc)', 'Cancel (Esc)'), kind: BtnKind.outline, tabStop: false, onTap: () {
                  clear();
                  widget.onCancel?.call();
                }),
              ],
            ),
            if (!canFirst && !_busy) Padding(padding: const EdgeInsets.only(top: 8), child: Text(vtxt.isEmpty ? bi('ગાડી નંબર લખો', 'Write the vehicle number') : steadyWhyText(), style: ts(12, c: Pal.faint))),
            if (widget.mode == StationMode.classic) const SizedBox(height: 16),
            if (widget.mode == StationMode.classic) Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Pal.soft, borderRadius: BorderRadius.circular(12), border: Border.all(color: Pal.line)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Text(bi('સીધું વજન (Manual Tare)', 'Direct weighing (Manual Tare)'), style: ts(14, w: FontWeight.w800)),
                  const SizedBox(height: 2),
                  Text(bi('ખાલી ગાડીનું વજન (ટેર) હાથે લખો - કાંટા પરનું વજન ગ્રોસ ગણાશે અને એન્ટ્રી તરત બનશે (ગાડીએ પાછા આવવું નહીં પડે).', 'Write the empty weight (tare) by hand - the weight on the scale counts as gross and the entry is made at once (the vehicle does not come back).'), style: ts(11.5, c: Pal.muted)),
                  const SizedBox(height: 8),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: <Widget>[
                      Expanded(child: FieldX(label: bi('ટેર KG', 'Tare KG'), controller: _tare, keyboard: TextInputType.number, onChanged: (String _) => setState(() {}), onSubmitted: (String _) => direct())),
                      const SizedBox(width: 10),
                      Btn(
                        '${bi('સીધું વજન લો', 'Direct weighing')}${st == null ? '' : ' · ${grp(st, dec: 0)} KG'}   (F8)',
                        icon: 'check',
                        kind: BtnKind.tonal,
                        onTap: (vtxt.isNotEmpty && st != null && !_busy && (double.tryParse(_tare.text.replaceAll(',', '').trim()) ?? 0) > 0) ? direct : null,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ======================================================================
// Vehicles inside (first weight taken) and the entry that was just made. They sit in the right column of the screen.
// ======================================================================

/// "Vehicles inside": first weight taken, waiting for the second.
class InsideCard extends StatelessWidget {
  /// Takes the second weight of that vehicle.
  final Future<void> Function(InsideVehicle v) onSecond;
  final bool busy;
  const InsideCard({super.key, required this.onSecond, this.busy = false});

  Future<void> _drop(BuildContext context, InsideVehicle v) async {
    final bool? ok = await showDialog<bool>(
      context: context,
      builder: (BuildContext c) => AlertDialog(
        title: Text(bi('ગાડી અંદરથી કાઢવી?', 'Remove this vehicle from inside?'), style: ts(17, w: FontWeight.w800)),
        content: Text('${v.vehicle} · ${grp(v.kg, dec: 0)} KG\n${bi('પહેલું વજન ભૂંસાશે (ફાઇલમાં નોંધ રહેશે). એન્ટ્રી બનશે નહીં.', 'Its first weight is dropped (it stays in the first-weight file). No entry is made.')}', style: ts(14, h: 1.4)),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.of(c).pop(false), child: Text(bi('ના', 'No'), style: ts(14, w: FontWeight.w700, c: Pal.muted))),
          TextButton(onPressed: () => Navigator.of(c).pop(true), child: Text(bi('હા, કાઢો', 'Yes, remove'), style: ts(14, w: FontWeight.w800, c: Pal.bad))),
        ],
      ),
    );
    if (ok == true) kantaUsb.dropInside(v);
  }

  @override
  Widget build(BuildContext context) {
    final KantaUsbService u = kantaUsb;
    final double? st = u.steadyKg;
    final DateTime now = DateTime.now();
    return KCard(
      icon: 'truck',
      title: bi('અંદર ગયેલી ગાડી', 'Vehicles inside'),
      sub: bi('પહેલું વજન લીધું - બીજા વજનની રાહ', 'First weight taken - waiting for the second'),
      trailing: KPill('${u.inside.length}', tone: u.inside.isEmpty ? 'slate' : 'amber'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          if (u.inside.isEmpty) Padding(padding: const EdgeInsets.only(bottom: 6), child: Text(bi('હમણાં કોઈ ગાડી અંદર નથી. ગાડી તોલવા ડાબી બાજુ ગાડી નંબર લખી પહેલું વજન (F2) લો.', 'No vehicle is inside now. To weigh one write its number on the left and take the first weight (F2).'), style: ts(12.5, c: Pal.faint))),
          for (final InsideVehicle v in u.inside.take(12))
            Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Pal.surface2, borderRadius: BorderRadius.circular(12), border: Border.all(color: Pal.line)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Expanded(child: Text(v.vehicle, style: ts(18, w: FontWeight.w800, c: v.outside ? Pal.warn : Pal.ink, tab: true))),
                      if (v.outside) Padding(padding: const EdgeInsets.only(right: 8), child: KPill(bi('બહારની', 'ROAD'), tone: 'amber')),
                      InkWell(onTap: () => _drop(context, v), child: Padding(padding: const EdgeInsets.all(6), child: Icon(ic('close'), size: 16, color: Pal.faint))),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text('${bi('પહેલું', '1st')}: ${grp(v.kg, dec: 0)} KG · ${hm(v.at)} (${_ago(now.difference(v.at))})', style: ts(12.5, w: FontWeight.w700, c: Pal.muted, tab: true)),
                  if (<String>[v.party, v.material, v.city, v.mobile].any((String s) => s.isNotEmpty))
                    Padding(
                      padding: const EdgeInsets.only(top: 3),
                      child: Text(<String>[v.party, v.material, v.city, if (v.mobile.isNotEmpty) '📞 ${v.mobile}', if (v.charges > 0) '₹${grp(v.charges, dec: 0)}'].where((String s) => s.isNotEmpty).join(' · '), style: ts(12, c: Pal.muted)),
                    ),
                  if (v.by.isNotEmpty) Text('📱 ${v.by}', style: ts(11.5, c: Pal.faint)),
                  if (st != null && (st - v.kg).abs() >= 1)
                    Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Text('${bi('હમણાં તોલો તો ચોખ્ખું', 'Net if weighed now')}: ${grp((st - v.kg).abs(), dec: 0)} KG', style: ts(13, w: FontWeight.w800, c: Pal.ok, tab: true)),
                    ),
                  const SizedBox(height: 8),
                  Btn(
                    st == null ? bi('બીજું વજન લો (F3)', 'Take second weight (F3)') : '${bi('બીજું વજન લો', 'Take second weight')} · ${grp(st, dec: 0)} KG${u.inside.length == 1 ? '  (F3)' : ''}',
                    icon: 'check',
                    kind: BtnKind.tonal,
                    expand: true,
                    onTap: (st != null && !busy && (st - v.kg).abs() >= 1) ? () => onSecond(v) : null,
                  ),
                  // why the button is grey - written under it, so it is never a guess
                  if (st == null)
                    Padding(padding: const EdgeInsets.only(top: 6), child: Text(StationCardState.steadyWhyText(), style: ts(12, w: FontWeight.w700, c: Pal.warn)))
                  else if ((st - v.kg).abs() < 1)
                    Padding(padding: const EdgeInsets.only(top: 6), child: Text(bi('આ વજન પહેલા વજન (${grp(v.kg, dec: 0)} KG) જેટલું જ છે - ગાડી ખાલી થઈને (કે ભરેલી) આવે ત્યારે લો.', 'This weight is exactly the first one (${grp(v.kg, dec: 0)} KG) - take it when the vehicle comes back empty (or loaded).'), style: ts(12, w: FontWeight.w700, c: Pal.warn))),
                ],
              ),
            ),
        ],
      ),
    );
  }

  static String _ago(Duration d) {
    if (d.inMinutes < 1) return '0m';
    if (d.inHours < 1) return '${d.inMinutes}m';
    if (d.inHours < 48) return '${d.inHours}h ${d.inMinutes % 60}m';
    return '${d.inDays}d';
  }
}

/// "Last entry": the entry that was just made, with Print and WhatsApp.
class LastEntryCard extends StatelessWidget {
  /// Show the old F5 / F7 key names on the buttons (the classic one-screen layout; in the terminal layout those keys open other screens).
  final bool keys;
  const LastEntryCard({super.key, this.keys = true});

  /// Redraws by itself (a const LastEntryCard is never rebuilt by its parent: it would keep showing the first entry of the day).
  @override
  Widget build(BuildContext context) => ListenableBuilder(listenable: Listenable.merge(<Listenable>[kantaUsb, KantaLog.tick]), builder: (BuildContext c, Widget? _) => _body());

  Widget _body() {
    final KantaUsbService u = kantaUsb;
    if (u.made.isEmpty) return const SizedBox.shrink();
    final AutoMade m = u.made.first;
    final SlipRec r = u.slipOf(m);
    final List<SlipTo> to = slipRecipients(r);
    return KCard(
      icon: 'check',
      title: bi('છેલ્લી એન્ટ્રી', 'Last entry'),
      sub: '${hm(m.at)} · ${m.outside ? bi('ફક્ત લેપટોપ', 'laptop only') : bi('સર્વર પર', 'on the server')}',
      accent: Pal.ok,
      trailing: KPill('${m.outside ? bi('સ્લિપ', 'Slip') : 'RST'} ${m.rst}', tone: 'green'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text(m.vehicle, style: ts(20, w: FontWeight.w800, tab: true)),
          const SizedBox(height: 4),
          Row(
            children: <Widget>[
              Text('${grp(m.gross, dec: 0)} − ${grp(m.tare, dec: 0)} = ', style: ts(14, c: Pal.muted, tab: true)),
              Text('${grp(m.net, dec: 0)} KG', style: ts(20, w: FontWeight.w800, c: Pal.ok, tab: true)),
            ],
          ),
          if (<String>[r.party, r.material, r.city].any((String s) => s.isNotEmpty))
            Padding(padding: const EdgeInsets.only(top: 4), child: Text(<String>[r.party, r.material, r.city].where((String s) => s.isNotEmpty).join(' · '), style: ts(12.5, c: Pal.muted))),
          const SizedBox(height: 10),
          Row(
            children: <Widget>[
              Expanded(child: Btn('${bi('પ્રિન્ટ', 'Print')}${keys ? ' (F5)' : ''}', icon: 'print', kind: BtnKind.tonal, expand: true, onTap: () => printSlip(r))),
              const SizedBox(width: 8),
              Expanded(child: Btn('WhatsApp${to.length > 1 ? ' ${to[0].mill ? bi('મિલ', 'mill') : bi('ડ્રાઇવર', 'driver')}' : ''}${keys ? ' (F7)' : ''}', icon: 'share', kind: BtnKind.tonal, expand: true, onTap: () => sendSlipWhatsApp(r))),
              if (to.length > 1) ...<Widget>[
                const SizedBox(width: 8),
                Expanded(child: Btn('WhatsApp ${to[1].mill ? bi('મિલ', 'mill') : bi('ડ્રાઇવર', 'driver')}', icon: 'share', kind: BtnKind.tonal, expand: true, onTap: () => sendSlipWhatsApp(r, which: 1))),
              ],
            ],
          ),
          ListenableBuilder(
            listenable: KantaWa.tick,
            builder: (BuildContext context, Widget? _) {
              final List<Widget> rows = <Widget>[];
              final List<WaJob> js = KantaWa.jobsOf(r.rst);
              final bool auto = KantaLog.waApi && KantaWa.ready && KantaLog.waMode != 0;
              String who(String n, bool mill) => '${mill ? '${bi('મિલ', 'Mill')} ' : ''}+91 $n';
              Widget row(String t, Color c) => Padding(padding: const EdgeInsets.only(top: 6), child: Text(t, style: ts(11.5, c: c, w: c == Pal.faint ? FontWeight.w500 : FontWeight.w700)));
              if (to.isEmpty && js.isEmpty) {
                rows.add(row(bi('WhatsApp: મોબાઇલ નંબર નથી - દબાવો તો કોને મોકલવું તે WhatsApp પૂછશે', 'WhatsApp: no mobile number - WhatsApp will ask whom to send to'), Pal.faint));
              }
              for (final SlipTo t in to) {
                WaJob? j;
                for (final WaJob x in js) {
                  if (x.to == t.number) j = x;
                }
                if (j != null && j.state == 'sent') {
                  rows.add(row('✓ WhatsApp ${bi('ગયું', 'sent')}${j.how == 'pic' ? ' (${bi('ફોટો', 'picture')})' : ''}: ${who(t.number, t.mill)}', Pal.ok));
                } else if (j != null && j.state == 'wait') {
                  rows.add(row('⏳ WhatsApp ${bi('જવાનું બાકી', 'waiting')}: ${who(t.number, t.mill)}${j.err.isEmpty ? '' : ' · ${j.err}'}', Pal.warn));
                } else if (j != null) {
                  rows.add(row('✗ WhatsApp ${bi('ગયું નથી', 'not sent')}: ${who(t.number, t.mill)}${j.err.isEmpty ? '' : ' · ${j.err}'}', Pal.bad));
                } else if (auto) {
                  rows.add(row('${bi('WhatsApp જાતે જશે', 'WhatsApp goes by itself')}: ${who(t.number, t.mill)}', Pal.faint));
                } else {
                  rows.add(row('${bi('WhatsApp આ નંબર પર', 'WhatsApp goes to')}: ${who(t.number, t.mill)}', Pal.faint));
                }
              }
              // a job for a number that is not on the list any more (the settings changed after the entry)
              for (final WaJob j in js) {
                if (to.any((SlipTo t) => t.number == j.to)) continue;
                final Color c = j.state == 'sent' ? Pal.ok : (j.state == 'wait' ? Pal.warn : Pal.bad);
                rows.add(row('${j.state == 'sent' ? '✓' : (j.state == 'wait' ? '⏳' : '✗')} WhatsApp: +91 ${j.to}', c));
              }
              return Column(crossAxisAlignment: CrossAxisAlignment.start, children: rows);
            },
          ),
        ],
      ),
    );
  }
}
