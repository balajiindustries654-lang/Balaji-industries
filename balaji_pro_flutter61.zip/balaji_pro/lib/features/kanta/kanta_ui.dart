import 'package:flutter/material.dart';
import '../../core/icons.dart';
import '../../core/palette.dart';

// ======================================================================
// Small building blocks of the Balaji Kanta operator screen (cards, status pills, keyboard hints).
// One look for the whole screen: white cards with a title bar, a dark live-weight panel, quiet pills.
// ======================================================================

/// A card with a title bar (icon, title, small line, something on the right) and the content under it.
class KCard extends StatelessWidget {
  final String? icon;
  final String title;
  final String? sub;
  final Widget? trailing;
  final Widget child;
  final EdgeInsets padding;

  /// A thin coloured line on the top edge (e.g. green for the entry that was just made).
  final Color? accent;
  const KCard({super.key, this.icon, required this.title, this.sub, this.trailing, required this.child, this.padding = const EdgeInsets.fromLTRB(16, 2, 16, 16), this.accent});

  @override
  Widget build(BuildContext context) {
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: Pal.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Pal.line),
        boxShadow: const <BoxShadow>[BoxShadow(color: Color(0x0F0B2C33), blurRadius: 18, offset: Offset(0, 6))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          if (accent != null) Container(height: 3, color: accent),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 12, 10),
            child: Row(
              children: <Widget>[
                if (icon != null) ...<Widget>[
                  Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(color: Pal.soft, borderRadius: BorderRadius.circular(10)),
                    child: Icon(ic(icon!), size: 18, color: Pal.brand),
                  ),
                  const SizedBox(width: 10),
                ],
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(title, style: ts(15.5, w: FontWeight.w800, ls: -0.2)),
                      if (sub != null && sub!.isNotEmpty) Text(sub!, style: ts(11.5, c: Pal.muted)),
                    ],
                  ),
                ),
                if (trailing != null) trailing!,
              ],
            ),
          ),
          Padding(padding: padding, child: child),
        ],
      ),
    );
  }
}

/// A small rounded status label ("Scale COM4", "Online ...") in one of the palette tones.
class KPill extends StatelessWidget {
  final String text;
  final String tone;
  final String? icon;
  final bool dot;
  const KPill(this.text, {super.key, this.tone = 'slate', this.icon, this.dot = false});

  @override
  Widget build(BuildContext context) {
    final Tone t = Pal.tone(tone);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(color: t.bg, borderRadius: BorderRadius.circular(99)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          if (dot) Container(width: 8, height: 8, margin: const EdgeInsets.only(right: 7), decoration: BoxDecoration(color: t.fg, shape: BoxShape.circle)),
          if (icon != null) Padding(padding: const EdgeInsets.only(right: 6), child: Icon(ic(icon!), size: 14, color: t.fg)),
          Flexible(child: Text(text, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12, w: FontWeight.w700, c: t.fg))),
        ],
      ),
    );
  }
}

/// A key cap with its meaning:  [F2] First weight.
class KKey extends StatelessWidget {
  final String keys;
  final String label;
  const KKey(this.keys, this.label, {super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
          decoration: BoxDecoration(color: Pal.surface, borderRadius: BorderRadius.circular(6), border: Border.all(color: Pal.line, width: 1.2), boxShadow: const <BoxShadow>[BoxShadow(color: Color(0x1A0B2C33), offset: Offset(0, 2))]),
          child: Text(keys, style: ts(11.5, w: FontWeight.w800, c: Pal.ink, tab: true)),
        ),
        const SizedBox(width: 6),
        Text(label, style: ts(12, w: FontWeight.w600, c: Pal.muted)),
      ],
    );
  }
}

/// A number tile ("Mill 12", "Net 84,200 KG").
class KStat extends StatelessWidget {
  final String label;
  final String value;
  final String tone;
  const KStat(this.label, this.value, {super.key, this.tone = 'slate'});

  @override
  Widget build(BuildContext context) {
    final Tone t = Pal.tone(tone);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(color: t.bg, borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Text(label, style: ts(11, w: FontWeight.w700, c: t.fg)),
          const SizedBox(height: 2),
          Text(value, style: ts(17, w: FontWeight.w800, c: t.fg, tab: true)),
        ],
      ),
    );
  }
}
