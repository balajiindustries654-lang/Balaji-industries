import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/palette.dart';
import '../data/mock_db.dart';
import '../data/models.dart';
import '../widgets/charts.dart';
import '../widgets/datagrid.dart';
import 'report_screen.dart';
import 'report_util.dart';
import 'tally.dart';

// Reports for: tally (14) and accounts (8).

void _openVoucher(BuildContext ctx, List<Object?> r, int noIdx, int firmIdx) {
  final Voucher? v = voucherByRef(r[noIdx], r[firmIdx]);
  if (v != null) showVoucherDetail(ctx, v);
}

void _openParty(BuildContext ctx, Object? nameCell) {
  final Party? p = db.partyByName(nameCell.toString());
  if (p != null) app.go('party', arg: p);
}

Set<String> _namesOf(Firm? firm, String group) {
  return db.ledgersOf(firm).where((LedgerAcc l) => l.group == group).map((LedgerAcc l) => l.name).toSet();
}

String _gradeOf(Voucher v) => v.grade < 0 ? '' : gradeName(v.grade, shortName: true);

// ---------------------------------------------------------- voucher register
ReportOut _voucherRegister(RCtx c) {
  final List<Voucher> list = db.vouchersIn(firm: c.firm, days: c.days);
  final List<List<Object?>> rows = <List<Object?>>[
    for (final Voucher v in list) <Object?>[v.party, v.no, v.type, v.firm.short, v.date, v.total],
  ];
  double sales = 0, rec = 0, pay = 0;
  for (final Voucher v in list) {
    if (v.type == 'Sales') sales += v.total;
    if (v.type == 'Receipt') rec += v.amount;
    if (v.type == 'Payment') pay += v.amount;
  }
  return ReportOut(
    GridData(<Col>[
      Col(bi('વિગત', 'Particulars'), CK.text, w: 230, bold: true),
      Col(bi('વાઉચર નં.', 'Voucher no.'), CK.text, w: 110),
      Col(bi('પ્રકાર', 'Type'), CK.status, w: 110),
      Col(bi('ફર્મ', 'Firm'), CK.text, w: 120),
      Col(bi('તારીખ', 'Date'), CK.date, w: 120),
      Col(bi('રકમ', 'Amount'), CK.money, w: 140, main: true),
    ], rows),
    kpis: <KpiSpec>[
      KpiSpec(bi('કુલ વાઉચર', 'Vouchers'), grp(rows.length), 'ledger', 'violet'),
      KpiSpec(bi('વેચાણ', 'Sales'), inrC(sales), 'cart', 'green'),
      KpiSpec(bi('રસીદ', 'Receipts'), inrC(rec), 'dl', 'teal'),
      KpiSpec(bi('ચૂકવણી', 'Payments'), inrC(pay), 'pay', 'rose'),
    ],
    onRow: (BuildContext ctx, List<Object?> r) => _openVoucher(ctx, r, 1, 3),
  );
}

// ------------------------------------------------------------- ledger group
ReportOut _ledgerGroup(RCtx c) {
  final List<List<Object?>> rows = <List<Object?>>[];
  double dr = 0, cr = 0;
  for (final String g in kGroupOrder) {
    double o = 0, d = 0, k = 0, cl = 0;
    int n = 0;
    for (final LedgerAcc l in db.ledgersOf(c.firm)) {
      if (l.group != g) continue;
      n++;
      o += l.opening;
      d += l.dr;
      k += l.cr;
      cl += l.closing;
    }
    if (n == 0) continue;
    dr += d;
    cr += k;
    rows.add(<Object?>[g, n, drcr(o), d, k, drcr(cl)]);
  }
  return ReportOut(
    GridData(<Col>[
      Col(bi('ગ્રુપ', 'Group'), CK.text, w: 220, bold: true),
      Col(bi('લેજર', 'Ledgers'), CK.count, w: 90),
      Col(bi('શરૂઆત', 'Opening'), CK.rtext, w: 150),
      Col(bi('ઉધાર', 'Debit'), CK.money, w: 150),
      Col(bi('જમા', 'Credit'), CK.money, w: 150),
      Col(bi('બાકી', 'Closing'), CK.rtext, w: 160, main: true),
    ], rows),
    kpis: <KpiSpec>[
      KpiSpec(bi('કુલ ઉધાર', 'Total debit'), inrC(dr), 'up', 'violet'),
      KpiSpec(bi('કુલ જમા', 'Total credit'), inrC(cr), 'down', 'teal'),
      KpiSpec(bi('ગ્રુપ', 'Groups'), '${rows.length}', 'tree', 'blue'),
    ],
    onRow: (BuildContext ctx, List<Object?> r) => app.go('tally_ledgers', arg: r[0]),
  );
}

// ------------------------------------------------------------ trial balance
ReportOut _trialBalance(RCtx c) {
  final List<LedgerAcc> l = db.ledgersOf(c.firm);
  double o = 0, d = 0, k = 0, cl = 0;
  final List<List<Object?>> rows = <List<Object?>>[];
  for (final LedgerAcc a in l) {
    o += a.opening;
    d += a.dr;
    k += a.cr;
    cl += a.closing;
    rows.add(<Object?>[a.name, a.group, drcr(a.opening), a.dr, a.cr, drcr(a.closing)]);
  }
  final bool ok = cl.abs() < 1;
  return ReportOut(
    GridData(<Col>[
      Col(bi('લેજર', 'Ledger'), CK.text, w: 220, bold: true),
      Col(bi('ગ્રુપ', 'Group'), CK.text, w: 170),
      Col(bi('શરૂઆત', 'Opening'), CK.rtext, w: 150),
      Col(bi('ઉધાર', 'Debit'), CK.money, w: 140),
      Col(bi('જમા', 'Credit'), CK.money, w: 140),
      Col(bi('બાકી', 'Closing'), CK.rtext, w: 160, main: true),
    ], rows, totals: <Object?>[bi('કુલ', 'Total'), null, drcr(o), d, k, drcr(cl)]),
    kpis: <KpiSpec>[
      KpiSpec(bi('કુલ ઉધાર', 'Total debit'), inrC(d), 'up', 'violet'),
      KpiSpec(bi('કુલ જમા', 'Total credit'), inrC(k), 'down', 'teal'),
      KpiSpec(bi('ટ્રાયલ બેલેન્સ', 'Trial balance'), ok ? bi('મેળ ✓', 'Tallied ✓') : bi('ફરક', 'Difference'), 'balance', ok ? 'green' : 'rose'),
    ],
    onRow: (BuildContext ctx, List<Object?> r) {
      for (final LedgerAcc a in l) {
        if (a.name == r[0]) {
          app.go('ledger', arg: a);
          return;
        }
      }
    },
  );
}

// ---------------------------------------------------------- cash / bank book
ReportOut _book(RCtx c, String group, bool bank) {
  final Set<String> names = _namesOf(c.firm, group);
  double opening = 0;
  for (final LedgerAcc l in db.ledgersOf(c.firm)) {
    if (l.group == group) opening += l.opening;
  }
  final List<Voucher> all = db.vouchersIn(firm: c.firm).where((Voucher v) => names.contains(v.dr) || names.contains(v.cr)).toList();
  all.sort((Voucher a, Voucher b) {
    final int x = a.date.compareTo(b.date);
    return x != 0 ? x : a.id.compareTo(b.id);
  });
  double bal = opening;
  double openAtStart = opening;
  double tin = 0, tout = 0;
  final List<List<Object?>> asc = <List<Object?>>[];
  final Map<DateTime, double> endOfDay = <DateTime, double>{};
  for (final Voucher v in all) {
    final bool inn = names.contains(v.dr);
    final bool out = names.contains(v.cr);
    if (inn) bal += v.amount;
    if (out) bal -= v.amount;
    final bool inPeriod = db.today.difference(dateOnly(v.date)).inDays < c.days;
    if (!inPeriod) {
      openAtStart = bal;
      continue;
    }
    if (inn && !out) tin += v.amount;
    if (out && !inn) tout += v.amount;
    asc.add(<Object?>[inn ? v.cr : v.dr, v.date, v.no, v.firm.short, (inn && !out) ? v.amount : null, (out && !inn) ? v.amount : null, bal]);
    endOfDay[dateOnly(v.date)] = bal;
  }
  final List<List<Object?>> rows = asc.reversed.toList();
  final List<DateTime> dk = endOfDay.keys.toList()..sort();
  final List<DateTime> lastDays = dk.length > 30 ? dk.sublist(dk.length - 30) : dk;
  return ReportOut(
    GridData(<Col>[
      Col(bi('વિગત', 'Particulars'), CK.text, w: 230, bold: true),
      Col(bi('તારીખ', 'Date'), CK.date, w: 120),
      Col(bi('વાઉચર', 'Voucher'), CK.text, w: 100),
      Col(bi('ફર્મ', 'Firm'), CK.text, w: 110),
      Col(bank ? bi('જમા (આવ્યા)', 'Deposits') : bi('આવક', 'Receipts'), CK.money, w: 140),
      Col(bank ? bi('ઉપાડ (ગયા)', 'Withdrawals') : bi('જાવક', 'Payments'), CK.money, w: 140),
      Col(bi('બેલેન્સ', 'Balance'), CK.money, w: 150, main: true),
    ], rows, totals: <Object?>[bi('કુલ', 'Total'), null, null, null, tin, tout, asc.isEmpty ? openAtStart : bal]),
    kpis: <KpiSpec>[
      KpiSpec(bi('શરૂઆતનું', 'Opening'), inrC(openAtStart), 'book', 'slate'),
      KpiSpec(bi('કુલ આવક', 'Total in'), inrC(tin), 'ul', 'green'),
      KpiSpec(bi('કુલ જાવક', 'Total out'), inrC(tout), 'dl', 'rose'),
      KpiSpec(bi('અંતિમ બેલેન્સ', 'Closing'), inrC(asc.isEmpty ? openAtStart : bal), bank ? 'bank' : 'wallet', 'teal'),
    ],
    chartTitle: bi('દિવસના અંતે બેલેન્સ', 'End-of-day balance'),
    chart: lastDays.length < 2
        ? const SizedBox(height: 40)
        : LineChartX(
            series: <LineSeries>[LineSeries(bi('બેલેન્સ', 'Balance'), <double>[for (final DateTime d in lastDays) endOfDay[d]!], bank ? Pal.info : Pal.amber)],
            labels: <String>[for (final DateTime d in lastDays) '${d.day}'],
            axisFmt: axC,
          ),
    onRow: (BuildContext ctx, List<Object?> r) => _openVoucher(ctx, r, 2, 3),
  );
}

ReportOut _cashBook(RCtx c) => _book(c, 'Cash-in-Hand', false);
ReportOut _bankBook(RCtx c) => _book(c, 'Bank Accounts', true);

// --------------------------------------------------------------- receivables
ReportOut _receivables(RCtx c) {
  final List<LedgerAcc> l = db.ledgersOf(c.firm).where((LedgerAcc a) => a.group == 'Sundry Debtors' && a.closing > 0.5).toList();
  l.sort((LedgerAcc a, LedgerAcc b) => b.closing.compareTo(a.closing));
  final List<List<Object?>> rows = <List<Object?>>[];
  for (final LedgerAcc a in l) {
    final DateTime? lr = db.lastVoucherOf(a.name, 'Receipt');
    rows.add(<Object?>[a.name, a.firm.short, a.closing, db.lastVoucherOf(a.name, 'Sales'), lr, lr == null ? null : db.today.difference(dateOnly(lr)).inDays]);
  }
  final List<List<Object?>> top = rows.take(8).toList();
  return ReportOut(
    GridData(<Col>[
      Col(bi('ખરીદદાર', 'Buyer'), CK.text, w: 240, bold: true),
      Col(bi('ફર્મ', 'Firm'), CK.text, w: 120),
      Col(bi('બાકી', 'Outstanding'), CK.money, w: 150, main: true),
      Col(bi('છેલ્લું વેચાણ', 'Last sale'), CK.date, w: 130),
      Col(bi('છેલ્લી રસીદ', 'Last receipt'), CK.date, w: 130),
      Col(bi('રસીદને દિવસ', 'Days since'), CK.count, w: 110),
    ], rows, totals: <Object?>[bi('કુલ', 'Total'), null, sumCol(rows, 2), null, null, null]),
    kpis: <KpiSpec>[
      KpiSpec(bi('કુલ લેણાં', 'Total receivable'), inrC(sumCol(rows, 2)), 'ul', 'green'),
      KpiSpec(bi('ખરીદદાર', 'Buyers'), '${rows.length}', 'store', 'blue'),
      if (rows.isNotEmpty) KpiSpec(bi('સૌથી મોટું', 'Largest'), inrC(rows.first[2] as double), 'star', 'amber'),
    ],
    chartTitle: bi('ટોપ 8 બાકી', 'Top 8 outstanding'),
    chart: BarChartX(
      values: <double>[for (final List<Object?> r in top) r[2] as double],
      labels: <String>[for (final List<Object?> r in top) r[0].toString().split(' ').first],
      color: Pal.ok,
      axisFmt: axC,
      valueFmt: axC,
    ),
    onRow: (BuildContext ctx, List<Object?> r) => _openParty(ctx, r[0]),
  );
}

// ----------------------------------------------------------------- payables
ReportOut _payables(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('ખેડૂત', 'Farmer'), CK.text, w: 240, bold: true),
    Col(bi('ગામ', 'Village'), CK.text, w: 140),
    Col(bi('ચૂકવવાના', 'Payable'), CK.money, w: 150, main: true),
    Col(bi('સૌથી જૂનું (દિવસ)', 'Oldest (days)'), CK.count, w: 140),
    Col(bi('સ્થિતિ', 'Status'), CK.status, w: 110),
  ];
  if (noPurchase(c)) return purchaseNote(cols);
  final List<LedgerAcc> l = db.ledgersOf(c.firm).where((LedgerAcc a) => a.group == 'Sundry Creditors' && a.closing < -0.5).toList();
  l.sort((LedgerAcc a, LedgerAcc b) => a.closing.compareTo(b.closing));
  final List<List<Object?>> rows = <List<Object?>>[];
  for (final LedgerAcc a in l) {
    final Party? p = db.farmerByName(a.name);
    int oldest = 0;
    if (p != null) {
      for (final Entry e in db.entriesOfFarmer(p)) {
        if (e.due > 0.5) {
          final int age = db.today.difference(dateOnly(e.dt)).inDays;
          if (age > oldest) oldest = age;
        }
      }
    }
    rows.add(<Object?>[a.name, p?.village ?? '', -a.closing, oldest, oldest > 30 ? 'bad' : (oldest > 10 ? 'warn' : 'due')]);
  }
  return ReportOut(
    GridData(cols, rows, totals: <Object?>[bi('કુલ', 'Total'), null, sumCol(rows, 2), null, null]),
    kpis: <KpiSpec>[
      KpiSpec(bi('કુલ દેવું', 'Total payable'), inrC(sumCol(rows, 2)), 'dl', 'rose'),
      KpiSpec(bi('ખેડૂત', 'Farmers'), '${rows.length}', 'agri', 'green'),
      if (rows.isNotEmpty) KpiSpec(bi('સૌથી મોટું', 'Largest'), inrC(rows.first[2] as double), 'star', 'amber'),
    ],
    onRow: (BuildContext ctx, List<Object?> r) => _openParty(ctx, r[0]),
  );
}

// ---------------------------------------------------------- sales register
ReportOut _salesRegister(RCtx c) {
  final List<Voucher> list = db.vouchersIn(firm: c.firm, days: c.days, type: 'Sales');
  final List<List<Object?>> rows = <List<Object?>>[
    for (final Voucher v in list) <Object?>[v.party, v.no, v.firm.short, v.date, _gradeOf(v), v.kg, v.amount, v.gst, v.total],
  ];
  final Map<DateTime, double> byDay = <DateTime, double>{};
  for (final Voucher v in list) {
    byDay[dateOnly(v.date)] = (byDay[dateOnly(v.date)] ?? 0) + v.total;
  }
  final List<DateTime> dk = byDay.keys.toList()..sort();
  final List<DateTime> last = dk.length > 14 ? dk.sublist(dk.length - 14) : dk;
  return ReportOut(
    GridData(<Col>[
      Col(bi('ખરીદદાર', 'Buyer'), CK.text, w: 230, bold: true),
      Col(bi('ઇનવોઇસ', 'Invoice'), CK.text, w: 100),
      Col(bi('ફર્મ', 'Firm'), CK.text, w: 110),
      Col(bi('તારીખ', 'Date'), CK.date, w: 120),
      Col(bi('ગ્રેડ', 'Grade'), CK.text, w: 90),
      Col('KG', CK.kg, w: 110),
      Col(bi('કિંમત', 'Taxable'), CK.money, w: 130),
      Col('GST', CK.money, w: 110),
      Col(bi('કુલ', 'Total'), CK.money, w: 140, main: true),
    ], rows, totals: <Object?>[bi('કુલ', 'Total'), null, null, null, null, sumCol(rows, 5), sumCol(rows, 6), sumCol(rows, 7), sumCol(rows, 8)]),
    kpis: <KpiSpec>[
      KpiSpec(bi('બિલ', 'Invoices'), '${rows.length}', 'receipt', 'green'),
      KpiSpec(bi('કુલ વેચાણ', 'Total sales'), inrC(sumCol(rows, 8)), 'cart', 'teal'),
      KpiSpec(bi('વજન', 'Weight'), tons(sumCol(rows, 5)), 'scale', 'amber'),
      KpiSpec('GST', inrC(sumCol(rows, 7)), 'percentbox', 'violet'),
    ],
    chartTitle: bi('દિવસ પ્રમાણે વેચાણ', 'Sales by day'),
    chart: BarChartX(
      values: <double>[for (final DateTime d in last) byDay[d]!],
      labels: <String>[for (final DateTime d in last) '${d.day}'],
      color: Pal.ok,
      axisFmt: axC,
      valueFmt: axC,
    ),
    onRow: (BuildContext ctx, List<Object?> r) => _openVoucher(ctx, r, 1, 2),
  );
}

// ------------------------------------------------------- purchase register
ReportOut _purchaseRegister(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('ખેડૂત', 'Farmer'), CK.text, w: 230, bold: true),
    Col(bi('વાઉચર', 'Voucher'), CK.text, w: 100),
    Col(bi('તારીખ', 'Date'), CK.date, w: 120),
    Col(bi('ગ્રેડ', 'Grade'), CK.text, w: 90),
    Col('KG', CK.kg, w: 110),
    Col(bi('રકમ', 'Amount'), CK.money, w: 150, main: true),
  ];
  if (noPurchase(c)) return purchaseNote(cols);
  final List<Voucher> list = db.vouchersIn(firm: Firm.balaji, days: c.days, type: 'Purchase');
  final List<List<Object?>> rows = <List<Object?>>[
    for (final Voucher v in list) <Object?>[v.party, v.no, v.date, _gradeOf(v), v.kg, v.amount],
  ];
  return ReportOut(
    GridData(cols, rows, totals: <Object?>[bi('કુલ', 'Total'), null, null, null, sumCol(rows, 4), sumCol(rows, 5)]),
    kpis: <KpiSpec>[
      KpiSpec(bi('ખરીદી વાઉચર', 'Purchase vouchers'), '${rows.length}', 'bag', 'violet'),
      KpiSpec(bi('કુલ વજન', 'Weight'), tons(sumCol(rows, 4)), 'scale', 'amber'),
      KpiSpec(bi('કુલ ખરીદી', 'Total purchase'), inrC(sumCol(rows, 5)), 'rupee', 'teal'),
    ],
    onRow: (BuildContext ctx, List<Object?> r) => _openVoucher(ctx, r, 1, 1),
  );
}

// -------------------------------------------------------------- GST summary
ReportOut _gstSummary(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('મહિનો', 'Period'), CK.text, w: 150, bold: true),
    Col(bi('ફર્મ', 'Firm'), CK.text, w: 190),
    Col(bi('બિલ', 'Invoices'), CK.count, w: 90),
    Col(bi('કરપાત્ર રકમ', 'Taxable'), CK.money, w: 150),
    Col('CGST', CK.money, w: 120),
    Col('SGST', CK.money, w: 120),
    Col(bi('કુલ GST', 'Total GST'), CK.money, w: 140, main: true),
  ];
  if (c.firm == Firm.balaji) return gstNote(cols);
  final Map<String, List<double>> m = <String, List<double>>{};
  final Map<String, DateTime> when = <String, DateTime>{};
  final Map<String, Firm> who = <String, Firm>{};
  for (final Voucher v in db.vouchersIn(firm: c.firm, days: c.days, type: 'Sales')) {
    if (!v.firm.paka) continue;
    final String k = '${v.date.year * 100 + v.date.month}|${v.firm.index}';
    final List<double> x = m.putIfAbsent(k, () => <double>[0, 0, 0]);
    x[0] += 1;
    x[1] += v.amount;
    x[2] += v.gst;
    when[k] = DateTime(v.date.year, v.date.month, 1);
    who[k] = v.firm;
  }
  final List<String> keys = m.keys.toList();
  keys.sort((String a, String b) => when[b]!.compareTo(when[a]!));
  final List<List<Object?>> rows = <List<Object?>>[
    for (final String k in keys) <Object?>[monthYear(when[k]!), who[k]!.title, m[k]![0].toInt(), m[k]![1], m[k]![2] / 2, m[k]![2] / 2, m[k]![2]],
  ];
  return ReportOut(
    GridData(cols, rows, totals: <Object?>[bi('કુલ', 'Total'), null, sumCol(rows, 2), sumCol(rows, 3), sumCol(rows, 4), sumCol(rows, 5), sumCol(rows, 6)]),
    kpis: <KpiSpec>[
      KpiSpec(bi('કરપાત્ર વેચાણ', 'Taxable sales'), inrC(sumCol(rows, 3)), 'cart', 'teal'),
      KpiSpec(bi('કુલ GST', 'Total GST'), inrC(sumCol(rows, 6)), 'percentbox', 'amber'),
      KpiSpec(bi('બિલ', 'Invoices'), grp(sumCol(rows, 2)), 'receipt', 'violet'),
    ],
  );
}

// ------------------------------------------------------------- cost centre
ReportOut _costCentre(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('ગોડાઉન', 'Godown'), CK.text, w: 170, bold: true),
    Col(bi('આવક KG', 'Inward KG'), CK.kg, w: 130),
    Col(bi('આવક કિંમત', 'Inward value'), CK.money, w: 150),
    Col(bi('અત્યારનો સ્ટોક KG', 'Stock KG'), CK.kg, w: 150),
    Col(bi('સ્ટોક કિંમત', 'Stock value'), CK.money, w: 150, main: true),
  ];
  if (noPurchase(c)) return purchaseNote(cols);
  final Map<String, Agg> m = groupEntries(db.entriesInDays(c.days), (Entry e) => '${e.godown}');
  final List<List<Object?>> rows = <List<Object?>>[];
  final List<DonutPart> parts = <DonutPart>[];
  for (int g = 0; g < 3; g++) {
    double kg = 0, val = 0;
    for (final StockRow s in db.stock) {
      if (s.godown == g) {
        kg += s.kg;
        val += s.value;
      }
    }
    final Agg? a = m['$g'];
    rows.add(<Object?>[godownName(g), a?.kg ?? 0.0, a?.amt ?? 0.0, kg, val]);
    parts.add(DonutPart(godownName(g), val, kSeries[g]));
  }
  return ReportOut(
    GridData(cols, rows, totals: <Object?>[bi('કુલ', 'Total'), sumCol(rows, 1), sumCol(rows, 2), sumCol(rows, 3), sumCol(rows, 4)]),
    kpis: <KpiSpec>[
      KpiSpec(bi('કુલ સ્ટોક', 'Total stock'), tons(sumCol(rows, 3)), 'box', 'orange'),
      KpiSpec(bi('સ્ટોક કિંમત', 'Stock value'), inrC(sumCol(rows, 4)), 'rupee', 'green'),
    ],
    chartTitle: bi('ગોડાઉન પ્રમાણે કિંમત', 'Value by godown'),
    chart: donutLegend(parts, inrC(sumCol(rows, 4)), bi('સ્ટોક', 'stock'), fmt: (double v) => inrC(v)),
  );
}

// ------------------------------------------------------------ app vs Tally
ReportOut _appVsTally(RCtx c) {
  final List<Col> cols = <Col>[
    Col(bi('તારીખ', 'Date'), CK.date, w: 130, bold: true),
    Col(bi('એપ (ચિઠ્ઠી)', 'App (slips)'), CK.money, w: 160),
    Col(bi('ટેલી (ખરીદી)', 'Tally (purchase)'), CK.money, w: 160),
    Col(bi('ફરક', 'Difference'), CK.money, w: 140, main: true),
    Col(bi('સ્થિતિ', 'Status'), CK.status, w: 110),
  ];
  if (noPurchase(c)) return purchaseNote(cols);
  final Map<DateTime, List<double>> m = <DateTime, List<double>>{};
  for (final Entry e in db.entriesInDays(c.days)) {
    m.putIfAbsent(dateOnly(e.dt), () => <double>[0, 0])[0] += e.amount;
  }
  for (final Voucher v in db.vouchersIn(firm: Firm.balaji, days: c.days, type: 'Purchase')) {
    m.putIfAbsent(dateOnly(v.date), () => <double>[0, 0])[1] += v.amount;
  }
  final List<DateTime> days = m.keys.toList()..sort((DateTime a, DateTime b) => b.compareTo(a));
  final List<List<Object?>> rows = <List<Object?>>[];
  int okDays = 0;
  for (final DateTime d in days) {
    final double diff = m[d]![0] - m[d]![1];
    final bool ok = diff.abs() < 1;
    if (ok) okDays++;
    rows.add(<Object?>[d, m[d]![0], m[d]![1], diff, ok ? 'match' : 'diff']);
  }
  return ReportOut(
    GridData(cols, rows, totals: <Object?>[bi('કુલ', 'Total'), sumCol(rows, 1), sumCol(rows, 2), sumCol(rows, 3), null]),
    kpis: <KpiSpec>[
      KpiSpec(bi('મેળ ખાતા દિવસ', 'Matched days'), '$okDays', 'check', 'green'),
      KpiSpec(bi('ફરકવાળા દિવસ', 'Mismatched days'), '${rows.length - okDays}', 'warn', rows.length - okDays == 0 ? 'slate' : 'rose'),
      KpiSpec(bi('કુલ ફરક', 'Net difference'), inrC(sumCol(rows, 3)), 'cmp', 'violet'),
    ],
  );
}

// --------------------------------------------------------- firm comparison
ReportOut _tallyFirms(RCtx c) {
  final List<List<Object?>> rows = <List<Object?>>[];
  for (final Firm f in Firm.values) {
    double sales = 0, gst = 0, rec = 0, pay = 0;
    for (final Voucher v in db.vouchersIn(firm: f, days: c.days)) {
      if (v.type == 'Sales') {
        sales += v.amount;
        gst += v.gst;
      }
      if (v.type == 'Receipt') rec += v.amount;
      if (v.type == 'Payment') pay += v.amount;
    }
    rows.add(<Object?>[f.title, sales, gst, rec, pay, db.cashBalance(f) + db.bankBalance(f), db.receivable(f), db.netProfit(f, days: c.days)]);
  }
  return ReportOut(
    GridData(<Col>[
      Col(bi('ફર્મ', 'Firm'), CK.text, w: 210, bold: true),
      Col(bi('વેચાણ', 'Sales'), CK.money, w: 140),
      Col('GST', CK.money, w: 110),
      Col(bi('રસીદ', 'Receipts'), CK.money, w: 140),
      Col(bi('ચૂકવણી', 'Payments'), CK.money, w: 140),
      Col(bi('રોકડ + બેંક', 'Cash + Bank'), CK.money, w: 150),
      Col(bi('લેણાં', 'Receivable'), CK.money, w: 140),
      Col(bi('નફો', 'Profit'), CK.money, w: 140, main: true),
    ], rows, totals: <Object?>[
      bi('કુલ', 'Total'),
      sumCol(rows, 1),
      sumCol(rows, 2),
      sumCol(rows, 3),
      sumCol(rows, 4),
      sumCol(rows, 5),
      sumCol(rows, 6),
      sumCol(rows, 7),
    ]),
    kpis: <KpiSpec>[
      for (int i = 0; i < rows.length; i++) KpiSpec(Firm.values[i].short, inrC(rows[i][7] as double), 'store', Firm.values[i].tone),
    ],
    chartTitle: bi('ફર્મ પ્રમાણે વેચાણ', 'Sales by firm'),
    chart: BarChartX(
      values: <double>[for (final List<Object?> r in rows) r[1] as double],
      labels: <String>[for (final Firm f in Firm.values) f.short],
      color: Pal.amber,
      axisFmt: axC,
      valueFmt: axC,
    ),
  );
}

// ------------------------------------------------------- journal and contra
ReportOut _journalReg(RCtx c) {
  final List<Voucher> list = db.vouchersIn(firm: c.firm, days: c.days).where((Voucher v) => v.type == 'Journal' || v.type == 'Contra').toList();
  final List<List<Object?>> rows = <List<Object?>>[
    for (final Voucher v in list) <Object?>[v.party, v.no, v.type, v.firm.short, v.date, v.dr, v.cr, v.amount],
  ];
  return ReportOut(
    GridData(<Col>[
      Col(bi('વિગત', 'Particulars'), CK.text, w: 200, bold: true),
      Col(bi('વાઉચર', 'Voucher'), CK.text, w: 100),
      Col(bi('પ્રકાર', 'Type'), CK.status, w: 110),
      Col(bi('ફર્મ', 'Firm'), CK.text, w: 110),
      Col(bi('તારીખ', 'Date'), CK.date, w: 120),
      Col(bi('ઉધાર (Dr)', 'Debit'), CK.text, w: 170),
      Col(bi('જમા (Cr)', 'Credit'), CK.text, w: 170),
      Col(bi('રકમ', 'Amount'), CK.money, w: 130, main: true),
    ], rows, totals: <Object?>[bi('કુલ', 'Total'), null, null, null, null, null, null, sumCol(rows, 7)]),
    kpis: <KpiSpec>[
      KpiSpec(bi('વાઉચર', 'Vouchers'), '${rows.length}', 'swap', 'violet'),
      KpiSpec(bi('કુલ રકમ', 'Total'), inrC(sumCol(rows, 7)), 'rupee', 'teal'),
    ],
    onRow: (BuildContext ctx, List<Object?> r) => _openVoucher(ctx, r, 1, 3),
  );
}

// =============================================================== ACCOUNTS

ReportOut _expenses(RCtx c) {
  final Map<String, String> grp0 = <String, String>{for (final LedgerAcc l in db.ledgers) l.name: l.group};
  final Map<String, List<double>> m = <String, List<double>>{};
  for (final Voucher v in db.vouchersIn(firm: c.firm, days: c.days)) {
    if (v.type == 'Sales') continue;
    final String? g = grp0[v.dr];
    if (g != 'Direct Expenses' && g != 'Indirect Expenses') continue;
    final List<double> x = m.putIfAbsent(v.dr, () => <double>[0, 0]);
    x[0] += 1;
    x[1] += v.amount;
  }
  final List<MapEntry<String, List<double>>> l = m.entries.toList();
  l.sort((MapEntry<String, List<double>> a, MapEntry<String, List<double>> b) => b.value[1].compareTo(a.value[1]));
  double total = 0;
  for (final MapEntry<String, List<double>> e in l) {
    total += e.value[1];
  }
  final List<List<Object?>> rows = <List<Object?>>[
    for (final MapEntry<String, List<double>> e in l)
      <Object?>[e.key, grp0[e.key] == 'Direct Expenses' ? bi('સીધો ખર્ચ', 'Direct') : bi('આડકતરો ખર્ચ', 'Indirect'), e.value[0].toInt(), e.value[1], total > 0 ? e.value[1] / total * 100 : 0.0],
  ];
  final List<DonutPart> parts = <DonutPart>[];
  double other = 0;
  for (int i = 0; i < l.length; i++) {
    if (i < 5) {
      parts.add(DonutPart(l[i].key, l[i].value[1], kSeries[i]));
    } else {
      other += l[i].value[1];
    }
  }
  if (other > 0) parts.add(DonutPart(bi('બીજા', 'Others'), other, Pal.faint));
  return ReportOut(
    GridData(<Col>[
      Col(bi('ખર્ચનું ખાતું', 'Expense head'), CK.text, w: 230, bold: true),
      Col(bi('પ્રકાર', 'Type'), CK.text, w: 130),
      Col(bi('વાઉચર', 'Vouchers'), CK.count, w: 100),
      Col(bi('રકમ', 'Amount'), CK.money, w: 150, main: true),
      Col(bi('હિસ્સો', 'Share'), CK.pct, w: 90),
    ], rows, totals: <Object?>[bi('કુલ', 'Total'), null, sumCol(rows, 2), total, 100.0]),
    kpis: <KpiSpec>[
      KpiSpec(bi('કુલ ખર્ચ', 'Total expenses'), inrC(total), 'wallet', 'rose'),
      KpiSpec(bi('ખર્ચના હેડ', 'Heads'), '${rows.length}', 'folder', 'slate'),
      if (rows.isNotEmpty) KpiSpec(bi('સૌથી મોટો', 'Largest'), rows.first[0].toString(), 'star', 'amber'),
    ],
    chartTitle: bi('ખર્ચ વહેંચણી', 'Expense split'),
    chart: donutLegend(parts, inrC(total), bi('કુલ', 'total'), fmt: (double v) => inrC(v)),
  );
}

ReportOut _payments(RCtx c) {
  final List<Voucher> list = db.vouchersIn(firm: c.firm, days: c.days, type: 'Payment');
  double cash = 0, bank = 0;
  for (final Voucher v in list) {
    if (v.cash) {
      cash += v.amount;
    } else {
      bank += v.amount;
    }
  }
  final List<List<Object?>> rows = <List<Object?>>[
    for (final Voucher v in list) <Object?>[v.party, v.no, v.date, v.firm.short, v.cash ? bi('રોકડ', 'Cash') : bi('બેંક', 'Bank'), v.amount],
  ];
  return ReportOut(
    GridData(<Col>[
      Col(bi('કોને', 'Paid to'), CK.text, w: 230, bold: true),
      Col(bi('વાઉચર', 'Voucher'), CK.text, w: 100),
      Col(bi('તારીખ', 'Date'), CK.date, w: 120),
      Col(bi('ફર્મ', 'Firm'), CK.text, w: 110),
      Col(bi('રીત', 'Mode'), CK.text, w: 100),
      Col(bi('રકમ', 'Amount'), CK.money, w: 140, main: true),
    ], rows, totals: <Object?>[bi('કુલ', 'Total'), null, null, null, null, sumCol(rows, 5)]),
    kpis: <KpiSpec>[
      KpiSpec(bi('કુલ ચૂકવણી', 'Total paid'), inrC(cash + bank), 'pay', 'rose'),
      KpiSpec(bi('રોકડ', 'Cash'), inrC(cash), 'wallet', 'amber'),
      KpiSpec(bi('બેંક', 'Bank'), inrC(bank), 'bank', 'blue'),
      KpiSpec(bi('વાઉચર', 'Vouchers'), '${rows.length}', 'ledger', 'slate'),
    ],
    onRow: (BuildContext ctx, List<Object?> r) => _openVoucher(ctx, r, 1, 3),
  );
}

ReportOut _receipts(RCtx c) {
  final List<Voucher> list = db.vouchersIn(firm: c.firm, days: c.days, type: 'Receipt');
  final List<List<Object?>> rows = <List<Object?>>[
    for (final Voucher v in list) <Object?>[v.party, v.no, v.date, v.firm.short, v.narration, v.amount],
  ];
  final Map<DateTime, double> byDay = <DateTime, double>{};
  for (final Voucher v in list) {
    byDay[dateOnly(v.date)] = (byDay[dateOnly(v.date)] ?? 0) + v.amount;
  }
  final List<DateTime> dk = byDay.keys.toList()..sort();
  final List<DateTime> last = dk.length > 14 ? dk.sublist(dk.length - 14) : dk;
  return ReportOut(
    GridData(<Col>[
      Col(bi('કોની પાસેથી', 'Received from'), CK.text, w: 230, bold: true),
      Col(bi('વાઉચર', 'Voucher'), CK.text, w: 100),
      Col(bi('તારીખ', 'Date'), CK.date, w: 120),
      Col(bi('ફર્મ', 'Firm'), CK.text, w: 110),
      Col(bi('રીત', 'Mode'), CK.text, w: 130),
      Col(bi('રકમ', 'Amount'), CK.money, w: 140, main: true),
    ], rows, totals: <Object?>[bi('કુલ', 'Total'), null, null, null, null, sumCol(rows, 5)]),
    kpis: <KpiSpec>[
      KpiSpec(bi('કુલ રસીદ', 'Total received'), inrC(sumCol(rows, 5)), 'dl', 'green'),
      KpiSpec(bi('વાઉચર', 'Vouchers'), '${rows.length}', 'ledger', 'slate'),
    ],
    chartTitle: bi('દિવસ પ્રમાણે રસીદ', 'Receipts by day'),
    chart: BarChartX(
      values: <double>[for (final DateTime d in last) byDay[d]!],
      labels: <String>[for (final DateTime d in last) '${d.day}'],
      color: Pal.ok,
      axisFmt: axC,
      valueFmt: axC,
    ),
    onRow: (BuildContext ctx, List<Object?> r) => _openVoucher(ctx, r, 1, 3),
  );
}

bool _isBank(String n) => n.endsWith('Current A/c');

ReportOut _reconcile(RCtx c) {
  final List<Voucher> list = db.vouchersIn(firm: c.firm, days: c.days).where((Voucher v) => _isBank(v.dr) || _isBank(v.cr)).toList();
  double pendIn = 0, pendOut = 0;
  final List<List<Object?>> rows = <List<Object?>>[];
  for (final Voucher v in list) {
    final bool inn = _isBank(v.dr);
    final bool recent = db.today.difference(dateOnly(v.date)).inDays <= 15;
    final bool pend = recent && v.id % 11 == 0;
    if (pend) {
      if (inn) {
        pendIn += v.amount;
      } else {
        pendOut += v.amount;
      }
    }
    rows.add(<Object?>[inn ? v.cr : v.dr, v.no, v.date, v.firm.short, inn ? bi('જમા', 'In') : bi('ઉપાડ', 'Out'), v.amount, pend ? 'pending' : 'cleared']);
  }
  final double book = db.bankBalance(c.firm);
  return ReportOut(
    GridData(<Col>[
      Col(bi('વિગત', 'Particulars'), CK.text, w: 220, bold: true),
      Col(bi('વાઉચર', 'Voucher'), CK.text, w: 100),
      Col(bi('તારીખ', 'Date'), CK.date, w: 120),
      Col(bi('ફર્મ', 'Firm'), CK.text, w: 110),
      Col(bi('દિશા', 'Direction'), CK.text, w: 100),
      Col(bi('રકમ', 'Amount'), CK.money, w: 140, main: true),
      Col(bi('બેંકમાં', 'In bank'), CK.status, w: 110),
    ], rows),
    kpis: <KpiSpec>[
      KpiSpec(bi('બુક પ્રમાણે બેલેન્સ', 'Balance as per books'), inrC(book), 'book', 'violet'),
      KpiSpec(bi('જમા બાકી', 'Deposits not cleared'), inrC(pendIn), 'ul', 'amber'),
      KpiSpec(bi('ઉપાડ બાકી', 'Withdrawals not cleared'), inrC(pendOut), 'dl', 'rose'),
      KpiSpec(bi('બેંક પ્રમાણે બેલેન્સ', 'Balance as per bank'), inrC(book - pendIn + pendOut), 'bank', 'blue'),
    ],
    onRow: (BuildContext ctx, List<Object?> r) => _openVoucher(ctx, r, 1, 3),
  );
}

ReportOut _chequeReg(RCtx c) {
  final List<Voucher> list = db.vouchersIn(firm: c.firm, days: c.days, type: 'Payment').where((Voucher v) => _isBank(v.cr)).toList();
  double pend = 0;
  int pn = 0;
  final List<List<Object?>> rows = <List<Object?>>[];
  for (final Voucher v in list) {
    final bool cleared = db.today.difference(dateOnly(v.date)).inDays > 4;
    if (!cleared) {
      pend += v.amount;
      pn++;
    }
    rows.add(<Object?>[v.party, '${200000 + v.id * 13}', v.date, v.firm.short, v.amount, cleared ? 'cleared' : 'pending']);
  }
  return ReportOut(
    GridData(<Col>[
      Col(bi('કોને', 'Payee'), CK.text, w: 230, bold: true),
      Col(bi('ચેક નં.', 'Cheque no.'), CK.text, w: 110),
      Col(bi('તારીખ', 'Date'), CK.date, w: 120),
      Col(bi('ફર્મ', 'Firm'), CK.text, w: 110),
      Col(bi('રકમ', 'Amount'), CK.money, w: 140, main: true),
      Col(bi('સ્થિતિ', 'Status'), CK.status, w: 110),
    ], rows),
    kpis: <KpiSpec>[
      KpiSpec(bi('ચેક / ટ્રાન્સફર', 'Cheques issued'), '${rows.length}', 'quote', 'amber'),
      KpiSpec(bi('વટાવવાના બાકી', 'Not cleared'), '$pn', 'clock', 'rose'),
      KpiSpec(bi('બાકી રકમ', 'Pending amount'), inrC(pend), 'rupee', 'violet'),
    ],
  );
}

ReportOut _profitLot(RCtx c) {
  final Map<int, double> avg = <int, double>{};
  for (final StockRow s in db.stock) {
    avg[s.g] = s.rate;
  }
  final List<Voucher> list = db.vouchersIn(firm: c.firm, days: c.days, type: 'Sales').where((Voucher v) => v.grade >= 0).toList();
  final List<List<Object?>> rows = <List<Object?>>[];
  for (final Voucher v in list) {
    final double cost = v.kg / 20 * (avg[v.grade] ?? db.rates[v.grade]);
    final double profit = v.amount - cost;
    rows.add(<Object?>[v.party, v.no, v.date, _gradeOf(v), v.kg, v.amount, cost, profit, v.amount > 0 ? profit / v.amount * 100 : 0.0]);
  }
  final List<List<Object?>> asc = rows.take(12).toList().reversed.toList();
  final double sale = sumCol(rows, 5);
  final double profit = sumCol(rows, 7);
  return ReportOut(
    GridData(<Col>[
      Col(bi('ખરીદદાર', 'Buyer'), CK.text, w: 220, bold: true),
      Col(bi('વાઉચર', 'Voucher'), CK.text, w: 100),
      Col(bi('તારીખ', 'Date'), CK.date, w: 120),
      Col(bi('ગ્રેડ', 'Grade'), CK.text, w: 90),
      Col('KG', CK.kg, w: 110),
      Col(bi('વેચાણ', 'Sale'), CK.money, w: 130),
      Col(bi('અંદાજિત ખર્ચ', 'Est. cost'), CK.money, w: 130),
      Col(bi('નફો', 'Profit'), CK.money, w: 130, main: true),
      Col(bi('માર્જિન', 'Margin'), CK.pct, w: 90),
    ], rows, totals: <Object?>[bi('કુલ', 'Total'), null, null, null, sumCol(rows, 4), sale, sumCol(rows, 6), profit, sale > 0 ? profit / sale * 100 : 0.0]),
    kpis: <KpiSpec>[
      KpiSpec(bi('કુલ નફો', 'Total profit'), inrC(profit), 'trend', profit >= 0 ? 'green' : 'rose'),
      KpiSpec(bi('માર્જિન', 'Margin'), pct(sale > 0 ? profit / sale * 100 : 0), 'pct', 'amber'),
      KpiSpec(bi('લોટ', 'Lots'), '${rows.length}', 'layers', 'blue'),
    ],
    chartTitle: bi('છેલ્લા 12 લોટનો નફો', 'Profit of last 12 lots'),
    chart: BarChartX(
      values: <double>[for (final List<Object?> r in asc) (r[7] as double) < 0 ? 0.0 : r[7] as double],
      labels: <String>[for (final List<Object?> r in asc) '${(r[2] as DateTime).day}'],
      color: Pal.ok,
      axisFmt: axC,
      valueFmt: axC,
    ),
    onRow: (BuildContext ctx, List<Object?> r) => _openVoucher(ctx, r, 1, 1),
  );
}

ReportOut _marginTrend(RCtx c) {
  DateTime weekOf(DateTime d) {
    final DateTime x = dateOnly(d);
    return x.subtract(Duration(days: x.weekday - 1));
  }

  final Map<DateTime, List<double>> m = <DateTime, List<double>>{}; // [buyAmt, buyKg, sellAmt, sellKg]
  for (final Entry e in db.entriesInDays(c.days)) {
    final List<double> x = m.putIfAbsent(weekOf(e.dt), () => <double>[0, 0, 0, 0]);
    x[0] += e.amount;
    x[1] += e.net;
  }
  for (final Voucher v in db.vouchersIn(firm: Firm.balaji, days: c.days, type: 'Sales')) {
    final List<double> x = m.putIfAbsent(weekOf(v.date), () => <double>[0, 0, 0, 0]);
    x[2] += v.amount;
    x[3] += v.kg;
  }
  final List<DateTime> wk = m.keys.toList()..sort();
  final List<List<Object?>> asc = <List<Object?>>[];
  for (final DateTime w in wk) {
    final List<double> x = m[w]!;
    if (x[1] <= 0 || x[3] <= 0) continue;
    final double buy = x[0] / (x[1] / 20);
    final double sell = x[2] / (x[3] / 20);
    asc.add(<Object?>[dm(w), buy, sell, sell - buy, buy > 0 ? (sell - buy) / buy * 100 : 0.0]);
  }
  final List<List<Object?>> rows = asc.reversed.toList();
  final List<List<Object?>> chartRows = asc.length > 12 ? asc.sublist(asc.length - 12) : asc;
  return ReportOut(
    GridData(<Col>[
      Col(bi('સપ્તાહ (શરૂઆત)', 'Week of'), CK.text, w: 160, bold: true),
      Col(bi('ખરીદ ભાવ/મણ', 'Buy rate/mann'), CK.money, w: 150),
      Col(bi('વેચાણ ભાવ/મણ', 'Sell rate/mann'), CK.money, w: 150),
      Col(bi('માર્જિન/મણ', 'Margin/mann'), CK.money, w: 140, main: true),
      Col(bi('માર્જિન %', 'Margin %'), CK.pct, w: 100),
    ], rows),
    kpis: <KpiSpec>[
      if (rows.isNotEmpty) KpiSpec(bi('આ સપ્તાહનું માર્જિન', 'Latest margin/mann'), inr(rows.first[3] as double), 'trend', 'green'),
      if (rows.isNotEmpty) KpiSpec(bi('માર્જિન %', 'Margin %'), pct(rows.first[4] as double), 'pct', 'amber'),
    ],
    chartTitle: bi('ખરીદ vs વેચાણ ભાવ (પ્રતિ મણ)', 'Buy vs sell rate (per mann)'),
    chart: chartRows.length < 2
        ? const SizedBox(height: 40)
        : LineChartX(
            series: <LineSeries>[
              LineSeries(bi('ખરીદ', 'Buy'), <double>[for (final List<Object?> r in chartRows) r[1] as double], Pal.violet),
              LineSeries(bi('વેચાણ', 'Sell'), <double>[for (final List<Object?> r in chartRows) r[2] as double], Pal.ok),
            ],
            labels: <String>[for (final List<Object?> r in chartRows) r[0].toString()],
            axisFmt: axC,
          ),
  );
}

ReportOut _budget(RCtx c) {
  const Map<String, double> plan = <String, double>{
    'Hamali': 45000,
    'Transport Charges': 60000,
    'Weighing Charges': 4000,
    'Salary': 85000,
    'Electricity': 20000,
    'Office Rent': 15000,
    'Accountant Fees': 8000,
    'Bank Charges': 1500,
    'Discount Allowed': 10000,
  };
  final DateTime now = db.today;
  final Map<String, double> actual = <String, double>{};
  for (final Voucher v in db.vouchersIn(firm: c.firm)) {
    if (v.type == 'Sales') continue;
    if (v.date.year != now.year || v.date.month != now.month) continue;
    if (!plan.containsKey(v.dr)) continue;
    actual[v.dr] = (actual[v.dr] ?? 0) + v.amount;
  }
  final List<List<Object?>> rows = <List<Object?>>[];
  plan.forEach((String k, double b) {
    final double a = actual[k] ?? 0;
    final double used = b > 0 ? a / b * 100 : 0;
    rows.add(<Object?>[k, b, a, b - a, used, used > 100 ? 'over' : (used > 80 ? 'warn' : 'ok')]);
  });
  rows.sort((List<Object?> a, List<Object?> b) => (b[4] as double).compareTo(a[4] as double));
  return ReportOut(
    GridData(<Col>[
      Col(bi('ખર્ચનું ખાતું', 'Head'), CK.text, w: 220, bold: true),
      Col(bi('બજેટ (મહિનો)', 'Budget (month)'), CK.money, w: 150),
      Col(bi('અત્યાર સુધી', 'Actual'), CK.money, w: 150),
      Col(bi('બચત / વધારે', 'Remaining'), CK.money, w: 150, main: true),
      Col(bi('વપરાશ', 'Used'), CK.pct, w: 90),
      Col(bi('સ્થિતિ', 'Status'), CK.status, w: 130),
    ], rows, totals: <Object?>[bi('કુલ', 'Total'), sumCol(rows, 1), sumCol(rows, 2), sumCol(rows, 3), null, null]),
    kpis: <KpiSpec>[
      KpiSpec(bi('બજેટ', 'Budget'), inrC(sumCol(rows, 1)), 'tune', 'blue'),
      KpiSpec(bi('વપરાયેલ', 'Spent'), inrC(sumCol(rows, 2)), 'wallet', 'amber'),
      KpiSpec(bi('વધારે ખર્ચ', 'Over budget'), '${rows.where((List<Object?> r) => r[5] == 'over').length}', 'warn', 'rose'),
    ],
  );
}

final Map<String, ReportSpec> kReportsB = <String, ReportSpec>{
  'voucher_register': ReportSpec(_voucherRegister),
  'ledger_group': ReportSpec(_ledgerGroup, useDays: false),
  'trial_balance': ReportSpec(_trialBalance, useDays: false),
  'cash_book': ReportSpec(_cashBook),
  'bank_book': ReportSpec(_bankBook),
  'receivables': ReportSpec(_receivables, useDays: false),
  'payables': ReportSpec(_payables, useDays: false),
  'sales_register': ReportSpec(_salesRegister),
  'purchase_register': ReportSpec(_purchaseRegister),
  'gst_summary': ReportSpec(_gstSummary, defaultDays: 90),
  'cost_centre': ReportSpec(_costCentre),
  'app_vs_tally': ReportSpec(_appVsTally, defaultDays: 7),
  'tally_firms': ReportSpec(_tallyFirms, useFirm: false),
  'journal_reg': ReportSpec(_journalReg, defaultDays: 90),
  'expenses': ReportSpec(_expenses),
  'payments': ReportSpec(_payments),
  'receipts': ReportSpec(_receipts),
  'reconcile': ReportSpec(_reconcile, defaultDays: 30),
  'cheque_reg': ReportSpec(_chequeReg),
  'profit_lot': ReportSpec(_profitLot),
  'margin_trend': ReportSpec(_marginTrend, defaultDays: 90),
  'budget': ReportSpec(_budget, useDays: false),
};
