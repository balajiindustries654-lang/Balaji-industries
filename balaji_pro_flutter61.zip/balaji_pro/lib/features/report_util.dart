import 'package:flutter/material.dart';
import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/palette.dart';
import '../data/mock_db.dart';
import '../data/models.dart';
import '../widgets/charts.dart';
import '../widgets/datagrid.dart';
import 'report_screen.dart';

/// Shortcut to the (demo) data layer.
MockDb get db => MockDb.I;

const List<Color> kSeries = <Color>[Pal.teal, Pal.amber, Pal.info, Pal.violet, Pal.ok, Pal.bad];

Color gradeColor(int g) => g == 0 ? Pal.teal : (g == 1 ? Pal.amber : Pal.violet);

String axT(double v) => '${(v / 1000).round()}T';
String axC(double v) => inrC(v);

/// Aggregate of purchase entries.
class Agg {
  int n = 0;
  double kg = 0;
  double bags = 0;
  double amt = 0;
  double paid = 0;
  double hava = 0;
  double gross = 0;
  double comm = 0;
  final Set<int> farmers = <int>{};

  double get due => amt - paid;
  double get avgRate => kg > 0 ? amt / (kg / 20) : 0;
  double get mann => kg / 20;

  void add(Entry e) {
    n++;
    kg += e.net;
    bags += e.bags;
    amt += e.amount;
    paid += e.paid;
    hava += e.hava;
    gross += e.gross;
    comm += e.commission;
    farmers.add(e.farmer.id);
  }
}

Map<String, Agg> groupEntries(List<Entry> list, String Function(Entry) key) {
  final Map<String, Agg> m = <String, Agg>{};
  for (final Entry e in list) {
    m.putIfAbsent(key(e), () => Agg()).add(e);
  }
  return m;
}

List<MapEntry<String, Agg>> sortedAgg(Map<String, Agg> m, double Function(Agg) f) {
  final List<MapEntry<String, Agg>> l = m.entries.toList();
  l.sort((MapEntry<String, Agg> a, MapEntry<String, Agg> b) => f(b.value).compareTo(f(a.value)));
  return l;
}

/// Purchases are taken only in Balaji New (the two GST firms never buy).
bool noPurchase(RCtx c) => c.firm != null && c.firm!.paka;

ReportOut purchaseNote(List<Col> cols) {
  return ReportOut(
    GridData(cols, <List<Object?>>[]),
    note: bi('ખરીદી ફક્ત Balaji New માં લેવાય છે.', 'Purchases are taken only in Balaji New.'),
  );
}

ReportOut stockNote(List<Col> cols) {
  return ReportOut(
    GridData(cols, <List<Object?>>[]),
    note: bi('સ્ટોક ફક્ત Balaji New નો છે.', 'Stock is tracked in Balaji New only.'),
  );
}

ReportOut gstNote(List<Col> cols) {
  return ReportOut(
    GridData(cols, <List<Object?>>[]),
    note: bi('GST ફક્ત Patel / Shreenathji માં.', 'GST applies to Patel / Shreenathji only.'),
  );
}

String drcr(double v) => v.abs() < 0.5 ? '₹0' : '${inr(v.abs())} ${v >= 0 ? 'Dr' : 'Cr'}';

/// Finds an entry from a "#1234" cell.
Entry? entryByLabel(Object? v) {
  if (v == null) return null;
  final String s = v.toString();
  final int? no = int.tryParse(s.startsWith('#') ? s.substring(1) : s);
  if (no == null) return null;
  for (final Entry e in db.entries) {
    if (e.no == no) return e;
  }
  return null;
}

/// Finds a voucher from a voucher-no cell and the firm short name cell.
Voucher? voucherByRef(Object? no, Object? firmShort) {
  for (final Voucher v in db.vouchers) {
    if (v.no == no && v.firm.short == firmShort) return v;
  }
  return null;
}

Widget legendWrap(List<DonutPart> parts, {String Function(double)? fmt}) {
  final String Function(double) f = fmt ?? (double v) => grp(v);
  return Wrap(
    spacing: 16,
    runSpacing: 6,
    children: <Widget>[for (final DonutPart p in parts) LegendDot(p.color, p.label, value: f(p.value))],
  );
}

Widget donutLegend(List<DonutPart> parts, String center, String sub, {String Function(double)? fmt}) {
  final String Function(double) f = fmt ?? (double v) => grp(v);
  return Wrap(
    spacing: 26,
    runSpacing: 14,
    crossAxisAlignment: WrapCrossAlignment.center,
    children: <Widget>[
      DonutX(parts: parts, center: center, sub: sub),
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          for (final DonutPart p in parts)
            Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: LegendDot(p.color, p.label, value: f(p.value))),
        ],
      ),
    ],
  );
}

/// Sum helpers for totals rows.
double sumCol(List<List<Object?>> rows, int i) {
  double s = 0;
  for (final List<Object?> r in rows) {
    final Object? v = r[i];
    if (v is num) s += v.toDouble();
  }
  return s;
}
