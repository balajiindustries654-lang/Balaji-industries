import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/device.dart';
import '../core/fmt.dart';
import '../core/i18n.dart';
import '../core/icons.dart';
import '../core/palette.dart';
import '../data/mock_db.dart';
import '../data/models.dart';
import '../widgets/charts.dart';
import '../widgets/common.dart';
import '../widgets/page.dart';

MockDb get _db => MockDb.I;

// ---------------------------------------------------------------- Rate board
class RateBoardScreen extends StatelessWidget {
  const RateBoardScreen({super.key});

  double _prevRate(int g) {
    for (int back = 1; back <= 6; back++) {
      final DateTime d = _db.today.subtract(Duration(days: back));
      double amt = 0, kg = 0;
      for (final Entry e in _db.entries) {
        if (e.g == g && sameDay(e.dt, d)) {
          amt += e.amount;
          kg += e.net;
        }
      }
      if (kg > 0) return amt / (kg / 20);
    }
    return _db.rates[g];
  }

  List<double> _series(int g) {
    final List<double> out = <double>[];
    double carry = _db.rates[g];
    for (int back = 13; back >= 0; back--) {
      final DateTime d = _db.today.subtract(Duration(days: back));
      double amt = 0, kg = 0;
      for (final Entry e in _db.entries) {
        if (e.g == g && sameDay(e.dt, d)) {
          amt += e.amount;
          kg += e.net;
        }
      }
      if (kg > 0) carry = amt / (kg / 20);
      out.add(carry);
    }
    return out;
  }

  Widget _card(int g) {
    final double r = _db.rates[g];
    final double chg = r - _prevRate(g);
    final Tone t = Pal.tone(g == 0 ? 'teal' : (g == 1 ? 'amber' : 'violet'));
    Widget step(String label, double d) {
      return Expanded(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 3),
          child: Btn(label, kind: d > 0 ? BtnKind.tonal : BtnKind.outline, expand: true, onTap: () {
            _db.rates[g] = r + d;
            app.bump();
          }),
        ),
      );
    }

    return Surface(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              IconChip('grain', tone: g == 0 ? 'teal' : (g == 1 ? 'amber' : 'violet'), size: 42),
              const SizedBox(width: 12),
              Expanded(child: Text(gradeName(g), style: ts(15.5, w: FontWeight.w800))),
              DeltaChip('${chg >= 0 ? '+' : '-'}${inr(chg.abs())}', down: chg < 0),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            crossAxisAlignment: CrossAxisAlignment.baseline,
            textBaseline: TextBaseline.alphabetic,
            children: <Widget>[
              Text(inr(r), style: ts(34, w: FontWeight.w800, tab: true, ls: -1, c: t.fg)),
              const SizedBox(width: 6),
              Text('/ 20 KG', style: ts(13, w: FontWeight.w700, c: Pal.muted)),
            ],
          ),
          Text('${inr(r / 20, dec: 2)} / KG', style: ts(13, c: Pal.muted, tab: true)),
          const SizedBox(height: 12),
          SizedBox(height: 44, width: double.infinity, child: Spark(values: _series(g), color: t.fg, fill: true)),
          const SizedBox(height: 14),
          Row(children: <Widget>[step('-10', -10), step('-5', -5), step('+5', 5), step('+10', 10)]),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    final String msg = <String>[
      '${bi('આજનો ભાવ', "Today's rate")} · ${dmy(_db.today)}',
      for (int g = 0; g < 3; g++) '${gradeName(g, shortName: true)}: ${inr(_db.rates[g])} / 20 KG',
    ].join('\n');
    return ScreenScroll(
      maxWidth: 1200,
      children: <Widget>[
        ScreenHeader(bi('ભાવ બોર્ડ', 'Rate board'), actions: <Widget>[Btn(bi('WhatsApp લખાણ', 'WhatsApp text'), icon: 'chat', kind: BtnKind.tonal, onTap: () => copyText(msg))]),
        if (pc)
          Grid(cols: 3, gap: 14, children: <Widget>[for (int g = 0; g < 3; g++) _card(g)])
        else ...<Widget>[
          for (int g = 0; g < 3; g++) ...<Widget>[_card(g), const SizedBox(height: 12)],
          Btn(bi('WhatsApp લખાણ કૉપિ', 'Copy WhatsApp text'), icon: 'chat', kind: BtnKind.tonal, expand: true, onTap: () => copyText(msg)),
        ],
      ],
    );
  }
}

// ------------------------------------------------------------------- Heatmap
class HeatmapScreen extends StatefulWidget {
  const HeatmapScreen({super.key});

  @override
  State<HeatmapScreen> createState() => _HeatmapScreenState();
}

class _HeatmapScreenState extends State<HeatmapScreen> {
  int _metric = 0;
  int _period = 1;

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    final int days = _period == 0 ? 30 : 90;
    final List<List<double>> data = List<List<double>>.generate(7, (int i) => List<double>.filled(10, 0));
    for (final Entry e in _db.entriesInDays(days)) {
      final int h = e.dt.hour - 8;
      if (h < 0 || h > 9) continue;
      data[e.dt.weekday - 1][h] += _metric == 0 ? 1 : e.net / 1000;
    }
    int br = 0, bc = 0;
    double best = 0;
    for (int r = 0; r < 7; r++) {
      for (int c = 0; c < 10; c++) {
        if (data[r][c] > best) {
          best = data[r][c];
          br = r;
          bc = c;
        }
      }
    }
    final Widget seg = Seg(dense: true, labels: <String>[bi('એન્ટ્રી', 'Entries'), bi('વજન', 'Weight')], index: _metric, onChanged: (int i) => setState(() => _metric = i));
    final Widget per = Seg(dense: true, labels: <String>[bi('30 દિવસ', '30d'), bi('90 દિવસ', '90d')], index: _period, onChanged: (int i) => setState(() => _period = i));
    return ScreenScroll(
      maxWidth: 1100,
      children: <Widget>[
        ScreenHeader(bi('સમય હીટમેપ', 'Time heatmap'), actions: <Widget>[seg, per]),
        if (!pc) ...<Widget>[Row(children: <Widget>[Expanded(child: seg)]), const SizedBox(height: 8), Row(children: <Widget>[Expanded(child: per)]), const SizedBox(height: 12)],
        if (best > 0)
          Padding(
            padding: const EdgeInsets.only(bottom: 14),
            child: Surface(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: <Widget>[
                  IconChip('bolt', tone: 'amber', size: 42),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(bi('સૌથી વ્યસ્ત સમય', 'Busiest slot'), style: ts(12.5, c: Pal.muted, w: FontWeight.w600)),
                        Text('${(L.gu ? kDayGu : kDayEn)[br]} · ${pad2(bc + 8)}:00', style: ts(18, w: FontWeight.w800)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        Panel(
          child: HeatGrid(
            data: data,
            rowLabels: <String>[for (int i = 0; i < 7; i++) (L.gu ? kDayGu : kDayEn)[i]],
            colLabels: <String>[for (int h = 8; h <= 17; h++) '$h'],
            color: Pal.teal,
            height: pc ? 340 : 290,
          ),
        ),
      ],
    );
  }
}

// -------------------------------------------------------------------- What-if
class WhatIfScreen extends StatefulWidget {
  const WhatIfScreen({super.key});

  @override
  State<WhatIfScreen> createState() => _WhatIfScreenState();
}

class _WhatIfScreenState extends State<WhatIfScreen> {
  double _buy = 0;
  double _sell = 0;
  double _vol = 0;

  Widget _slider(String label, double v, double min, double max, int div, String Function(double) fmt, ValueChanged<double> on) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Row(
          children: <Widget>[
            Expanded(child: Text(label, style: ts(13.5, w: FontWeight.w700))),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(color: Pal.soft, borderRadius: BorderRadius.circular(99)),
              child: Text(fmt(v), style: ts(13.5, w: FontWeight.w800, c: Pal.brand, tab: true)),
            ),
          ],
        ),
        Slider(value: v, min: min, max: max, divisions: div, activeColor: Pal.brand, inactiveColor: Pal.line, onChanged: on),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    double buyKg = 0, buyAmt = 0, sellKg = 0, sellAmt = 0;
    for (final Entry e in _db.entriesInDays(30)) {
      buyKg += e.net;
      buyAmt += e.amount;
    }
    for (final Voucher v in _db.vouchersIn(firm: Firm.balaji, days: 30, type: 'Sales')) {
      sellKg += v.kg;
      sellAmt += v.amount;
    }
    final double f = 1 + _vol / 100;
    final double buy2 = buyAmt * f + _buy * (buyKg * f / 20);
    final double sell2 = sellAmt * f + _sell * (sellKg * f / 20);
    final double m1 = sellAmt - buyAmt;
    final double m2 = sell2 - buy2;
    final double diff = m2 - m1;

    final Widget controls = Panel(
      child: Column(
        children: <Widget>[
          _slider(bi('ખરીદ ભાવ ફેરફાર (/મણ)', 'Buy rate change (/mann)'), _buy, -100, 100, 40, (double v) => '${v >= 0 ? '+' : ''}${v.round()}', (double v) => setState(() => _buy = v)),
          _slider(bi('વેચાણ ભાવ ફેરફાર (/મણ)', 'Sell rate change (/mann)'), _sell, -100, 100, 40, (double v) => '${v >= 0 ? '+' : ''}${v.round()}', (double v) => setState(() => _sell = v)),
          _slider(bi('માલની માત્રા ફેરફાર', 'Volume change'), _vol, -30, 30, 30, (double v) => '${v >= 0 ? '+' : ''}${v.round()}%', (double v) => setState(() => _vol = v)),
          const SizedBox(height: 4),
          Btn(bi('ફરી સેટ', 'Reset'), icon: 'undo', kind: BtnKind.tonal, expand: true, onTap: () => setState(() {
                _buy = 0;
                _sell = 0;
                _vol = 0;
              })),
        ],
      ),
    );

    Widget line(String l, String a, String b, {bool strong = false}) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          children: <Widget>[
            Expanded(flex: 3, child: Text(l, style: ts(13.5, w: strong ? FontWeight.w800 : FontWeight.w600, c: strong ? Pal.ink : Pal.muted))),
            Expanded(flex: 3, child: Text(a, textAlign: TextAlign.right, style: ts(13.5, tab: true, c: Pal.muted))),
            Expanded(flex: 3, child: Text(b, textAlign: TextAlign.right, style: ts(strong ? 15 : 13.5, w: FontWeight.w800, tab: true))),
          ],
        ),
      );
    }

    final Widget result = Panel(
      title: bi('છેલ્લા 30 દિવસ પર અસર', 'Impact on the last 30 days'),
      child: Column(
        children: <Widget>[
          Row(
            children: <Widget>[
              const Expanded(flex: 3, child: SizedBox()),
              Expanded(flex: 3, child: Text(bi('અત્યારે', 'Now'), textAlign: TextAlign.right, style: ts(12, w: FontWeight.w700, c: Pal.faint))),
              Expanded(flex: 3, child: Text(bi('આ ફેરફારથી', 'Scenario'), textAlign: TextAlign.right, style: ts(12, w: FontWeight.w700, c: Pal.brand))),
            ],
          ),
          line(bi('ખરીદી', 'Purchases'), inrC(buyAmt), inrC(buy2)),
          line(bi('વેચાણ', 'Sales'), inrC(sellAmt), inrC(sell2)),
          divider(),
          line(bi('માર્જિન', 'Margin'), inrC(m1), inrC(m2), strong: true),
          const SizedBox(height: 10),
          Surface(
            color: diff >= 0 ? Pal.tone('green').bg : Pal.tone('rose').bg,
            border: false,
            shadow: false,
            padding: const EdgeInsets.all(14),
            child: Row(
              children: <Widget>[
                Icon(ic(diff >= 0 ? 'arrowup' : 'arrowdown'), size: 22, color: diff >= 0 ? Pal.tone('green').fg : Pal.tone('rose').fg),
                const SizedBox(width: 10),
                Expanded(child: Text(diff >= 0 ? bi('નફામાં વધારો', 'Profit increases') : bi('નફામાં ઘટાડો', 'Profit falls'), style: ts(14, w: FontWeight.w700, c: diff >= 0 ? Pal.tone('green').fg : Pal.tone('rose').fg))),
                Text(inrC(diff.abs()), style: ts(18, w: FontWeight.w800, tab: true, c: diff >= 0 ? Pal.tone('green').fg : Pal.tone('rose').fg)),
              ],
            ),
          ),
        ],
      ),
    );

    return ScreenScroll(
      maxWidth: 1100,
      children: <Widget>[
        ScreenHeader(bi('What-if ભાવ', 'What-if rate')),
        SplitPane(children: pc ? <Widget>[controls, result] : <Widget>[result, controls]),
      ],
    );
  }
}

// -------------------------------------------------------------------- Health
class HealthScreen extends StatelessWidget {
  const HealthScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final bool pc = DeviceScope.isPc(context);
    final double cash = _db.cashBalance(null) + _db.bankBalance(null);
    final double pay = _db.payable(null);
    final double liquidity = (cash / (pay < 1 ? 1 : pay) / 2 * 100).clamp(0.0, 100.0).toDouble();

    double ag = 0, old = 0;
    _db.receivableAging().forEach((String k, AgeBuckets b) {
      ag += b.total;
      old += b.b1 + b.b2 + b.b3;
    });
    final double collection = ag > 0 ? (100 - old / ag * 100).clamp(0.0, 100.0).toDouble() : 100;

    double sellKg = 0, sellAmt = 0, buyAmt = 0;
    for (final Voucher v in _db.vouchersIn(firm: Firm.balaji, days: 30, type: 'Sales')) {
      sellKg += v.kg;
      sellAmt += v.amount;
    }
    for (final Entry e in _db.entriesInDays(30)) {
      buyAmt += e.amount;
    }
    final double daily = sellKg / 30;
    final double cover = daily > 0 ? _db.stockKg(null) / daily : 30;
    final double stockScore = (cover / 30 * 100).clamp(0.0, 100.0).toDouble();
    final double margin = sellAmt > 0 ? (sellAmt - buyAmt) / sellAmt * 100 : 0;
    final double marginScore = (margin * 10).clamp(0.0, 100.0).toDouble();
    final double dueShare = buyAmt > 0 ? pay / buyAmt * 100 : 0;
    final double dueScore = (100 - dueShare).clamp(0.0, 100.0).toDouble();

    final List<List<Object>> items = <List<Object>>[
      <Object>[bi('રોકડની સ્થિતિ', 'Liquidity'), liquidity, 'wallet', '${inrC(cash)} / ${inrC(pay)}'],
      <Object>[bi('વસૂલાત', 'Collections'), collection, 'ul', pct(ag > 0 ? 100 - old / ag * 100 : 100, dec: 0)],
      <Object>[bi('સ્ટોક ચાલે', 'Stock cover'), stockScore, 'box', bi('${cover.round()} દિવસ', '${cover.round()} days')],
      <Object>[bi('માર્જિન', 'Margin'), marginScore, 'trend', pct(margin)],
      <Object>[bi('ખેડૂતનું દેવું', 'Farmer dues'), dueScore, 'agri', pct(dueShare, dec: 0)],
    ];
    double score = 0;
    for (final List<Object> i in items) {
      score += i[1] as double;
    }
    score /= items.length;
    final String tone = score >= 75 ? 'green' : (score >= 50 ? 'amber' : 'rose');
    final Color c = Pal.tone(tone).fg;
    final String verdict = score >= 75 ? bi('સારું', 'Healthy') : (score >= 50 ? bi('મધ્યમ', 'Fair') : bi('ધ્યાન આપો', 'Needs attention'));

    final Widget gauge = Panel(
      child: Column(
        children: <Widget>[
          Center(child: DonutX(parts: <DonutPart>[DonutPart('', score, c), DonutPart('', 100 - score, Pal.line)], center: '${score.round()}', sub: '/ 100', size: 190, thickness: 18)),
          const SizedBox(height: 14),
          Pill(verdict, tone: tone),
        ],
      ),
    );
    final Widget list = Panel(
      child: Column(
        children: <Widget>[
          for (final List<Object> i in items)
            Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: ProgressRow(
                label: i[0] as String,
                value: i[1] as double,
                max: 100,
                color: (i[1] as double) >= 75 ? Pal.ok : ((i[1] as double) >= 50 ? Pal.warn : Pal.bad),
                trailing: i[3] as String,
              ),
            ),
        ],
      ),
    );

    return ScreenScroll(
      maxWidth: 1100,
      children: <Widget>[
        ScreenHeader(bi('ધંધાનો સ્વાસ્થ્ય સ્કોર', 'Business health')),
        SplitPane(flex: const <int>[2, 3], children: <Widget>[gauge, list]),
        if (!pc) const SizedBox(height: 4),
      ],
    );
  }
}
