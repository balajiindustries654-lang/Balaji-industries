import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'core/app_state.dart';
import 'core/errlog.dart';
import 'core/i18n.dart';
import 'core/keep_awake.dart';
import 'data/backup.dart';
import 'data/debit.dart';
import 'data/kanta_auto.dart';
import 'data/kanta_usb.dart';
import 'data/live_store.dart';
import 'data/vno.dart';
import 'shell/host.dart';

/// A friendly card instead of the grey "error" box when one widget fails.
Widget _friendlyError(FlutterErrorDetails d) {
  return Material(
    color: const Color(0xFFFFF4E5),
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Text(
              bi('આ ભાગ બતાવવામાં ભૂલ આવી. પાછા જાઓ અને ફરી ખોલો.', 'This part could not be shown. Go back and open it again.'),
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Color(0xFF8A5A00)),
            ),
            const SizedBox(height: 6),
            Text(
              ErrLog.shortText(d.exception, max: 110),
              textAlign: TextAlign.center,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 11, color: Color(0xFF8A5A00)),
            ),
          ],
        ),
      ),
    ),
  );
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  FlutterError.onError = (FlutterErrorDetails d) {
    if (kDebugMode) FlutterError.presentError(d);
    // layout noise (overflow stripes) is not a failed action - everything else is told to the person
    final String t = d.exceptionAsString();
    final String lib = d.library ?? '';
    final bool noise = lib == 'rendering library' || t.contains('overflowed');
    ErrLog.report(d.exception, d.stack, where: lib, toast: !noise);
  };
  PlatformDispatcher.instance.onError = (Object e, StackTrace s) {
    ErrLog.report(e, s);
    return true;
  };
  ErrorWidget.builder = _friendlyError;
  await app.loadPrefs();
  unawaited(KeepAwake.start());
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Color(0xFF071F24),
    statusBarIconBrightness: Brightness.light,
    statusBarBrightness: Brightness.dark,
  ));
  runApp(const AppRoot());
  live.boot();
  kantaAuto.load();
  kantaUsb.load();
  debitStartNudge();
  laptopBackupStart();
  voucherNumberingStart();
}
