// Where dart:ffi does not exist (the web): nothing to do.
void winAwake(bool on) {}
