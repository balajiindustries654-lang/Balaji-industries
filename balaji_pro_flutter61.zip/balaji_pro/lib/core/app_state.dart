import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../data/models.dart';
import 'flags.dart';
import 'i18n.dart';
import 'palette.dart';

enum ViewMode { auto, phone, pc }

class NavEntry {
  final String id;
  final Object? arg;
  const NavEntry(this.id, [this.arg]);
}

/// Global UI state: view mode (phone / PC / auto), theme, language, firm filter
/// and a tiny navigation stack (no router package needed).
class AppState extends ChangeNotifier {
  ViewMode viewMode = ViewMode.auto;
  bool dark = false;
  double textScale = 1.0; // 0.9 .. 1.3, the owner's choice of letter size
  double pcZoom = 0.85; // PC only: whole screen zoom (0.7 .. 1.2). Smaller = more on screen, less bulky
  bool pcZoomAuto = true; // true until the person picks a zoom: 85% on a scaled (125%+) Windows screen, else 100%
  double zoomEff = 1.0; // zoom really in use right now (set by the host while laying out the PC stage)
  final List<String> favs = <String>[]; // screens starred by this person (shown first on the home)
  Firm? firm; // null => all companies
  final List<NavEntry> stack = <NavEntry>[const NavEntry('dashboard')];
  final Set<String> pins = <String>{'entries', 'daybook', 'trial_balance', 'cash_book', 'receivables'};
  final List<String> recent = <String>[];
  final Set<String> votes = <String>{};
  bool sidebarCollapsed = false;
  bool tallyMode = true; // PC: Tally Prime style shell and skin
  bool simple = true; // simple mode: only the daily account of the raw material (core/flags.dart)
  bool stagePc = false; // set by the host: current layout is PC
  bool tallyOnline = true;
  bool syncing = false;
  double syncProgress = 0;
  DateTime lastSync = DateTime.now().subtract(const Duration(minutes: 7));
  int rev = 0; // bumped when data changes

  // ---- security / backup / day close
  bool pinOn = false;
  String pin = '';
  bool locked = false;

  /// How long the app may stay out of sight (seconds) before it asks for the PIN again. Also used when the app is opened fresh.
  int lockAfterSec = 900;

  /// Called when the "ask the PIN after ..." time is changed (the store saves it).
  void Function(int)? onLockAfterChanged;

  void setLockAfter(int sec) {
    lockAfterSec = sec;
    final void Function(int)? cb = onLockAfterChanged;
    if (cb != null) cb(sec);
    notifyListeners();
  }

  bool autoBackup = true;
  DateTime lastBackup = DateTime.now().subtract(const Duration(hours: 3));
  bool dayClosed = false;

  /// Called whenever the PIN is set or removed (the store saves it).
  void Function(String)? onPinChanged;

  void setPin(String p) {
    pin = p;
    pinOn = p.length == 4;
    final void Function(String)? cb = onPinChanged;
    if (cb != null) cb(p);
    notifyListeners();
  }

  void clearPin() {
    pin = '';
    pinOn = false;
    locked = false;
    final void Function(String)? cb = onPinChanged;
    if (cb != null) cb('');
    notifyListeners();
  }

  void lock() {
    if (!pinOn) return;
    locked = true;
    notifyListeners();
  }

  bool unlock(String p) {
    if (p != pin) return false;
    locked = false;
    notifyListeners();
    return true;
  }

  void setAutoBackup(bool v) {
    autoBackup = v;
    notifyListeners();
  }

  void markBackup() {
    lastBackup = DateTime.now();
    notifyListeners();
  }

  void setDayClosed(bool v) {
    dayClosed = v;
    notifyListeners();
  }

  final GlobalKey<ScaffoldMessengerState> messengerKey = GlobalKey<ScaffoldMessengerState>();

  NavEntry get cur => stack.last;
  String get current => stack.last.id;
  Object? get arg => stack.last.arg;
  bool get canBack => stack.length > 1;

  void go(String id, {Object? arg, bool root = false}) {
    if (root) stack.clear();
    if (stack.isNotEmpty && stack.last.id == id && stack.last.arg == arg) return;
    stack.add(NavEntry(id, arg));
    if (stack.length > 40) stack.removeAt(0);
    recent.remove(id);
    recent.insert(0, id);
    if (recent.length > 8) recent.removeLast();
    notifyListeners();
  }

  /// Replaces the argument of the open screen (the screen is built again with it, the stack stays as it is).
  void setArg(Object? a) {
    if (stack.isEmpty) return;
    stack[stack.length - 1] = NavEntry(stack.last.id, a);
    notifyListeners();
  }

  void back() {
    if (stack.length > 1) {
      stack.removeLast();
      notifyListeners();
    }
  }

  void setFirm(Firm? f) {
    firm = f;
    notifyListeners();
  }

  void setSimple(bool v) {
    simple = v;
    kSimple = v;
    notifyListeners();
    savePrefs();
  }

  void setTally(bool v) {
    tallyMode = v;
    notifyListeners();
    savePrefs();
  }

  void setView(ViewMode m) {
    viewMode = m;
    notifyListeners();
    savePrefs();
  }

  void toggleDark() {
    dark = !dark;
    Pal.dark = dark;
    notifyListeners();
    savePrefs();
  }

  void setDark(bool v) {
    dark = v;
    Pal.dark = v;
    notifyListeners();
    savePrefs();
  }

  void toggleLang() {
    L.gu = !L.gu;
    notifyListeners();
    savePrefs();
  }

  void setPcZoom(double v) {
    final double z = v < 0.7 ? 0.7 : (v > 1.2 ? 1.2 : v);
    pcZoom = (z * 100).round() / 100;
    pcZoomAuto = false;
    notifyListeners();
    savePrefs();
  }

  /// Back to the automatic zoom.
  Future<void> resetPcZoom() async {
    pcZoomAuto = true;
    notifyListeners();
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.remove('ui_zoom');
    } catch (_) {}
  }

  void nudgeZoom(double step) => setPcZoom(pcZoom + step);

  void setTextScale(double v) {
    textScale = v < 0.8 ? 0.8 : (v > 1.5 ? 1.5 : v);
    notifyListeners();
    savePrefs();
  }

  /// Remembers theme, language, view and letter size on this phone.
  Future<void> loadPrefs() async {
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      dark = p.getBool('ui_dark') ?? dark;
      Pal.dark = dark;
      final bool? gu = p.getBool('ui_gu');
      if (gu != null) L.gu = gu;
      final int? vm = p.getInt('ui_view');
      if (vm != null && vm >= 0 && vm < ViewMode.values.length) viewMode = ViewMode.values[vm];
      textScale = p.getDouble('ui_text') ?? 1.0;
      final double? pz = p.getDouble('ui_zoom');
      if (pz != null && pz >= 0.7 && pz <= 1.2) {
        pcZoom = pz;
        pcZoomAuto = false;
      }
      simple = p.getBool('ui_simple') ?? true;
      kSimple = simple;
      tallyMode = p.getBool('ui_tally') ?? true;
      if (p.getBool('ui_tally_mig2') != true) {
        // one time: older builds could leave the PC look on "Modern" with no way back
        tallyMode = true;
        await p.setBool('ui_tally', true);
        await p.setBool('ui_tally_mig2', true);
      }
      favs
        ..clear()
        ..addAll(p.getStringList('ui_favs') ?? <String>[]);
    } catch (_) {}
    notifyListeners();
  }

  Future<void> savePrefs() async {
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setBool('ui_dark', dark);
      await p.setBool('ui_gu', L.gu);
      await p.setInt('ui_view', viewMode.index);
      await p.setDouble('ui_text', textScale);
      if (!pcZoomAuto) await p.setDouble('ui_zoom', pcZoom);
      await p.setBool('ui_tally', tallyMode);
      await p.setBool('ui_simple', simple);
      await p.setStringList('ui_favs', favs);
    } catch (_) {}
  }

  bool isFav(String id) => favs.contains(id);

  void toggleFav(String id) {
    if (!favs.remove(id)) favs.add(id);
    notifyListeners();
    savePrefs();
  }

  void togglePin(String id) {
    if (!pins.remove(id)) pins.add(id);
    notifyListeners();
  }

  void toggleVote(String id) {
    if (!votes.remove(id)) votes.add(id);
    notifyListeners();
  }

  void toggleSidebar() {
    sidebarCollapsed = !sidebarCollapsed;
    notifyListeners();
  }

  void bump() {
    rev++;
    notifyListeners();
  }

  void setTallyOnline(bool v) {
    tallyOnline = v;
    notifyListeners();
  }

  /// Simulated read-only fetch from the Tally agent (demo).
  Future<void> syncNow() async {
    if (syncing) return;
    syncing = true;
    syncProgress = 0;
    notifyListeners();
    for (int i = 1; i <= 10; i++) {
      await Future<void>.delayed(const Duration(milliseconds: 150));
      syncProgress = i / 10;
      notifyListeners();
    }
    syncing = false;
    lastSync = DateTime.now();
    notifyListeners();
  }

  void toast(String msg) {
    final ScaffoldMessengerState? m = messengerKey.currentState;
    if (m == null) return;
    m.hideCurrentSnackBar();
    final Widget content = Text(msg, style: ts(14, c: Colors.white, w: FontWeight.w600));
    final ShapeBorder shape = RoundedRectangleBorder(borderRadius: BorderRadius.circular(12));
    m.showSnackBar(stagePc
        ? SnackBar(
            content: content,
            behavior: SnackBarBehavior.floating,
            backgroundColor: const Color(0xFF12353A),
            duration: const Duration(milliseconds: 2200),
            width: 380,
            shape: shape,
          )
        : SnackBar(
            content: content,
            behavior: SnackBarBehavior.floating,
            backgroundColor: const Color(0xFF12353A),
            duration: const Duration(milliseconds: 2200),
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 90),
            shape: shape,
          ));
  }
}

final AppState app = AppState();
