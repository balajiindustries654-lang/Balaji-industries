/// Tiny bilingual helper. Gujarati is the default UI language.
class L {
  static bool gu = true;
}

/// Pick Gujarati or English text.
String bi(String g, String e) => L.gu ? g : e;

const List<String> kMonthGu = <String>[
  'જાન્યુ', 'ફેબ્રુ', 'માર્ચ', 'એપ્રિલ', 'મે', 'જૂન',
  'જુલાઈ', 'ઑગસ્ટ', 'સપ્ટે', 'ઑક્ટો', 'નવે', 'ડિસે',
];
const List<String> kMonthEn = <String>[
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
];
// index = DateTime.weekday - 1 (Mon..Sun)
const List<String> kDayGu = <String>['સોમ', 'મંગળ', 'બુધ', 'ગુરુ', 'શુક્ર', 'શનિ', 'રવિ'];
const List<String> kDayEn = <String>['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
