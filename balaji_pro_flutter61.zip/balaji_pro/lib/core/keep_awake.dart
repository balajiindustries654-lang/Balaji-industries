import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'keep_awake_stub.dart' if (dart.library.ffi) 'keep_awake_win.dart';

/// "As long as the app is open, the phone / the PC / the weighbridge laptop does not go to sleep and the screen does not turn off."
///  - Windows (Balaji Pro on the PC, Balaji Kanta on the weighbridge laptop): SetThreadExecutionState (keep_awake_win.dart)
///  - Android: the screen-on flag of the window, set through a tiny channel that ci/build.sh adds to MainActivity
///    (if that part is missing the call is simply ignored)
/// One switch in Settings (default ON). Nothing else in the app depends on this.
class KeepAwake {
  static bool on = true;
  static final ValueNotifier<int> tick = ValueNotifier<int>(0);
  static const MethodChannel _ch = MethodChannel('balaji/awake');
  static Timer? _t;
  static bool _started = false;

  /// Reads the switch and starts keeping awake. Never throws.
  static Future<void> start() async {
    if (_started) return;
    _started = true;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      on = p.getBool('keep_awake') ?? true;
    } catch (_) {}
    apply();
  }

  static Future<void> setOn(bool v) async {
    on = v;
    tick.value++;
    apply();
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setBool('keep_awake', v);
    } catch (_) {}
  }

  static void apply() {
    _t?.cancel();
    _t = null;
    if (kIsWeb) return;
    winAwake(on);
    if (defaultTargetPlatform == TargetPlatform.android) {
      try {
        unawaited(_ch.invokeMethod<bool>('set', on).catchError((Object _) => false));
      } catch (_) {}
    }
    // Windows forgets the request if the thread that made it changes: ask again every half minute
    if (on) _t = Timer.periodic(const Duration(seconds: 30), (Timer _) => winAwake(true));
  }
}
