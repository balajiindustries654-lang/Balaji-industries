import 'dart:async';
import 'package:flutter/foundation.dart';
import 'app_state.dart';
import 'fmt.dart';
import 'i18n.dart';

/// Remembers the last errors of the app. A button that "does nothing" used to fail without a word (a release build
/// hides errors); now the reason is shown for a moment and kept in App diagnostics, so it can be sent and fixed.
class ErrLog {
  static final List<String> items = <String>[];
  static final ValueNotifier<int> tick = ValueNotifier<int>(0);
  static String _lastText = '';
  static DateTime _lastAt = DateTime.fromMillisecondsSinceEpoch(0);

  /// First line of the error, cut to a readable length.
  static String shortText(Object error, {int max = 150}) {
    String s = '$error'.trim();
    final int nl = s.indexOf('\n');
    if (nl > 0) s = s.substring(0, nl);
    if (s.length > max) s = '${s.substring(0, max)}...';
    return s;
  }

  /// A lost internet connection is normal for this app (it works offline) - it is noted but not shown.
  static bool _network(String m) {
    final String s = m.toLowerCase();
    return s.contains('socketexception') ||
        s.contains('clientexception') ||
        s.contains('timeoutexception') ||
        s.contains('handshakeexception') ||
        s.contains('failed host lookup') ||
        s.contains('connection closed') ||
        s.contains('connection reset') ||
        s.contains('network is unreachable');
  }

  /// Notes an error. [where] says which action it came from (for example "F5").
  static void report(Object error, StackTrace? stack, {String where = '', bool toast = true}) {
    final String msg = shortText(error);
    final DateTime now = DateTime.now();
    final String line = '${hm(now)} ${where.isEmpty ? '' : '[$where] '}$msg';
    items.insert(0, line);
    if (items.length > 40) items.removeLast();
    debugPrint('Balaji Pro error: $line');
    if (stack != null) debugPrint('$stack');
    scheduleMicrotask(() {
      tick.value = tick.value + 1;
    });
    if (!toast || _network(msg)) return;
    // the same error is not shown again and again, and never more than one box every 3 seconds
    if (msg == _lastText && now.difference(_lastAt).inSeconds < 10) return;
    if (now.difference(_lastAt).inSeconds < 3) return;
    _lastText = msg;
    _lastAt = now;
    scheduleMicrotask(() {
      try {
        app.toast('${bi('ભૂલ', 'Error')}: $msg');
      } catch (_) {
        // nothing more to do
      }
    });
  }

  /// Runs [f]; when it fails the error is shown instead of vanishing.
  static void guard(String where, void Function() f) {
    try {
      f();
    } catch (e, s) {
      report(e, s, where: where);
    }
  }

  /// Runs an async action (a save). When it fails the error is shown and false comes back, so the form can open its button again.
  static Future<bool> attempt(String where, Future<void> Function() f) async {
    try {
      await f();
      return true;
    } catch (e, s) {
      report(e, s, where: where);
      return false;
    }
  }

  /// All noted errors as text (for the diagnostics report).
  static String text() => items.join('\n');
}
