import 'package:flutter/material.dart';

/// Gujarati-capable font fallback chain (Android has Noto Sans Gujarati,
/// Windows has Nirmala UI / Shruti).
const List<String> kFontFallback = <String>[
  'Noto Sans Gujarati',
  'Nirmala UI',
  'Shruti',
  'Roboto',
  'Segoe UI',
];

class Tone {
  final Color fg;
  final Color bg;
  const Tone(this.fg, this.bg);
}

/// Brand palette. `Pal.dark` is flipped by [AppState.toggleDark]; the whole
/// tree is rebuilt, so plain static getters are enough.
class Pal {
  static bool dark = false;

  /// Tally Prime skin (PC only): flat panels, thin dark borders, square corners.
  static bool tally = false;

  /// Corner radius that turns square in the Tally skin.
  static double rad(double v) => tally ? (v >= 50 ? 2.0 : (v > 4 ? 3.0 : v)) : v;

  // ---- brand ----
  static const Color teal = Color(0xFF087F83);
  static const Color tealDark = Color(0xFF065E62);
  static const Color tealLight = Color(0xFF3FB6B0);
  static const Color amber = Color(0xFFE8A33D);
  static const Color ink900 = Color(0xFF0B1F22);

  // ---- semantic ----
  static const Color ok = Color(0xFF1E9E57);
  static const Color warn = Color(0xFFD9870B);
  static const Color bad = Color(0xFFD6455A);
  static const Color info = Color(0xFF2D6BDB);
  static const Color violet = Color(0xFF6C4FC9);

  // ---- theme aware surfaces ----
  static Color get bg => dark ? const Color(0xFF0A1719) : (tally ? const Color(0xFFE6ECF0) : const Color(0xFFF2F6F7));
  static Color get surface => dark ? const Color(0xFF112427) : const Color(0xFFFFFFFF);
  static Color get surface2 => dark ? const Color(0xFF16302F) : (tally ? const Color(0xFFF3F6F8) : const Color(0xFFF6FAFA));
  static Color get line => dark ? (tally ? const Color(0xFF3A5A5E) : const Color(0xFF223C3F)) : (tally ? const Color(0xFFAFBEC8) : const Color(0xFFE2EAEB));
  static Color get ink => dark ? const Color(0xFFE8F3F3) : const Color(0xFF12292D);
  static Color get muted => dark ? const Color(0xFF8FAAAD) : const Color(0xFF64797C);
  static Color get faint => dark ? const Color(0xFF5E7B7E) : const Color(0xFF93A7AA);
  static Color get brand => dark ? const Color(0xFF2FB3B0) : (tally ? const Color(0xFF0B4F7A) : teal);
  static Color get soft => dark ? const Color(0xFF123A3B) : (tally ? const Color(0xFFDCE8F0) : const Color(0xFFE5F4F4));
  static Color get hover => dark ? const Color(0xFF173032) : (tally ? const Color(0xFFEFF4F7) : const Color(0xFFF1F7F7));
  static Color get scrim => const Color(0x8C081C20);

  // ---- keyboard focus (Tally style: the active line is highlighted in yellow) ----
  static Color get focusFill => dark ? const Color(0xFF4A4012) : const Color(0xFFFFF0A6);
  static Color get focusLine => dark ? const Color(0xFFFFD84D) : const Color(0xFFB88700);
  static Color get vHead => dark ? const Color(0xFF06141A) : const Color(0xFF0A3D62);

  // sidebar / top strip
  static Color get side => dark ? const Color(0xFF081315) : const Color(0xFF0B2C33);
  static Color get sideText => const Color(0xFFA9C4C8);
  static Color get strip => dark ? const Color(0xFF050E10) : const Color(0xFF071F24);

  static Tone tone(String name) {
    switch (name) {
      case 'amber':
        return dark
            ? const Tone(Color(0xFFF2B65A), Color(0xFF3A2C12))
            : const Tone(Color(0xFFB4721A), Color(0xFFFDF0D9));
      case 'blue':
        return dark
            ? const Tone(Color(0xFF7FA9F2), Color(0xFF14284A))
            : const Tone(Color(0xFF2B66CF), Color(0xFFE4EDFC));
      case 'green':
        return dark
            ? const Tone(Color(0xFF5CCB8A), Color(0xFF123A27))
            : const Tone(Color(0xFF2B8A4A), Color(0xFFE2F4E6));
      case 'violet':
        return dark
            ? const Tone(Color(0xFFB39BF0), Color(0xFF2A2150))
            : const Tone(Color(0xFF6B46C1), Color(0xFFEEE7FB));
      case 'rose':
        return dark
            ? const Tone(Color(0xFFF08A98), Color(0xFF451B22))
            : const Tone(Color(0xFFC23A4B), Color(0xFFFDE7E9));
      case 'orange':
        return dark
            ? const Tone(Color(0xFFF2985A), Color(0xFF3F2410))
            : const Tone(Color(0xFFC25E14), Color(0xFFFDEBDD));
      case 'slate':
        return dark
            ? const Tone(Color(0xFFA9BDC0), Color(0xFF1C2F32))
            : const Tone(Color(0xFF4D6468), Color(0xFFEAF0F1));
      default:
        return dark
            ? const Tone(Color(0xFF55CFC9), Color(0xFF123A3B))
            : const Tone(Color(0xFF087F83), Color(0xFFE1F3F3));
    }
  }

  /// status -> tone name
  static String statusTone(String s) {
    switch (s) {
      case 'paid':
      case 'ok':
      case 'live':
      case 'done':
      case 'match':
      case 'active':
      case 'on':
      case 'cleared':
      case 'Receipt':
      case 'Sales':
        return 'green';
      case 'part':
      case 'beta':
      case 'warn':
      case 'low':
      case 'open':
      case 'pending':
      case 'Journal':
        return 'amber';
      case 'due':
      case 'bad':
      case 'over':
      case 'high':
      case 'diff':
      case 'Payment':
        return 'rose';
      case 'new':
        return 'blue';
      case 'idle':
      case 'off':
        return 'slate';
      case 'Purchase':
        return 'violet';
      case 'Contra':
        return 'blue';
      case 'soon':
        return 'slate';
      default:
        return 'teal';
    }
  }
}

/// Text style helper. Always uses the Gujarati fallback chain and (optionally)
/// tabular figures so that amounts line up in columns.
TextStyle ts(double size,
    {FontWeight w = FontWeight.w500,
    Color? c,
    double? h,
    double? ls,
    bool tab = false,
    TextDecoration? deco}) {
  return TextStyle(
    fontSize: size,
    fontWeight: w,
    color: c ?? Pal.ink,
    height: h,
    letterSpacing: ls,
    fontFamilyFallback: kFontFallback,
    fontFeatures: tab ? const <FontFeature>[FontFeature.tabularFigures()] : null,
    decoration: deco,
  );
}

BoxDecoration cardDeco({Color? color, double r = 14, bool border = true, bool shadow = true}) {
  return BoxDecoration(
    color: color ?? Pal.surface,
    borderRadius: BorderRadius.circular(Pal.rad(r)),
    border: border ? Border.all(color: Pal.line) : null,
    boxShadow: (shadow && !Pal.dark && !Pal.tally)
        ? const <BoxShadow>[BoxShadow(color: Color(0x0D0B2C33), blurRadius: 14, offset: Offset(0, 4))]
        : null,
  );
}

ThemeData buildTheme() {
  final bool d = Pal.dark;
  final ColorScheme cs = ColorScheme.fromSeed(
    seedColor: Pal.teal,
    brightness: d ? Brightness.dark : Brightness.light,
  ).copyWith(
    primary: Pal.brand,
    onPrimary: Colors.white,
    secondary: Pal.amber,
    onSecondary: Colors.black,
    error: Pal.bad,
    onError: Colors.white,
    surface: Pal.surface,
    onSurface: Pal.ink,
  );
  return ThemeData(
    useMaterial3: true,
    brightness: d ? Brightness.dark : Brightness.light,
    colorScheme: cs,
    scaffoldBackgroundColor: Pal.bg,
    canvasColor: Pal.surface,
    splashFactory: InkRipple.splashFactory,
  );
}
