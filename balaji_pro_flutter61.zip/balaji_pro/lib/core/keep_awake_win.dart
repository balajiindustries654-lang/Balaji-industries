import 'dart:ffi';
import 'dart:io' show Platform;

// Windows: SetThreadExecutionState tells Windows "this app is in use" - the PC / the weighbridge laptop does not go to sleep and the
// screen stays on, as long as the app runs. Nothing is installed; it is one call of kernel32.dll.
const int _esContinuous = 0x80000000;
const int _esSystemRequired = 0x00000001;
const int _esDisplayRequired = 0x00000002;

typedef _NativeFn = Uint32 Function(Uint32);
typedef _DartFn = int Function(int);

_DartFn? _fn;
bool _failed = false;

void winAwake(bool on) {
  if (_failed || !Platform.isWindows) return;
  try {
    _fn ??= DynamicLibrary.open('kernel32.dll').lookupFunction<_NativeFn, _DartFn>('SetThreadExecutionState');
    _fn!(on ? (_esContinuous | _esSystemRequired | _esDisplayRequired) : _esContinuous);
  } catch (_) {
    _failed = true;
  }
}
