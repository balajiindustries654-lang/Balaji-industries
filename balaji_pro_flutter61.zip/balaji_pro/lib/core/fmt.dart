import 'i18n.dart';

/// Indian digit grouping: 1234567.5 -> 12,34,567 (dec = decimals).
String grp(num v, {int dec = 0}) {
  final bool neg = v < 0;
  final double a = v.abs().toDouble();
  final String fixed = a.toStringAsFixed(dec);
  final List<String> parts = fixed.split('.');
  final String ip = parts[0];
  String out;
  if (ip.length <= 3) {
    out = ip;
  } else {
    final String last3 = ip.substring(ip.length - 3);
    String rest = ip.substring(0, ip.length - 3);
    final List<String> groups = <String>[];
    while (rest.length > 2) {
      groups.insert(0, rest.substring(rest.length - 2));
      rest = rest.substring(0, rest.length - 2);
    }
    if (rest.isNotEmpty) groups.insert(0, rest);
    out = '${groups.join(',')},$last3';
  }
  if (dec > 0 && parts.length > 1) out = '$out.${parts[1]}';
  return neg ? '-$out' : out;
}

/// ₹1,23,456
String inr(num v, {int dec = 0}) {
  final String s = grp(v.abs(), dec: dec);
  return v < 0 ? '-₹$s' : '₹$s';
}

/// Compact: ₹1.25 Cr / ₹12.3 L / ₹45.2 K / ₹999
String inrC(num v) {
  final double a = v.abs().toDouble();
  final String sign = v < 0 ? '-' : '';
  if (a >= 10000000) return '$sign₹${(a / 10000000).toStringAsFixed(2)} Cr';
  if (a >= 100000) return '$sign₹${(a / 100000).toStringAsFixed(2)} L';
  if (a >= 10000) return '$sign₹${(a / 1000).toStringAsFixed(1)} K';
  return '$sign₹${grp(a)}';
}

String kgs(num v) => '${grp(v)} KG';

/// weight in tonnes with 1 decimal
String tons(num kg) => '${(kg / 1000).toStringAsFixed(1)} T';

String pct(num v, {int dec = 1}) => '${v.toStringAsFixed(dec)}%';

String pad2(int n) => n < 10 ? '0$n' : '$n';

String monthName(int m) => (L.gu ? kMonthGu : kMonthEn)[m - 1];

String dayName(DateTime d) => (L.gu ? kDayGu : kDayEn)[d.weekday - 1];

/// 10 ઑક્ટો 2026
String dmy(DateTime d) => '${d.day} ${monthName(d.month)} ${d.year}';

/// 10 ઑક્ટો
String dm(DateTime d) => '${d.day} ${monthName(d.month)}';

/// 18:40
String hm(DateTime d) => '${pad2(d.hour)}:${pad2(d.minute)}';

String monthYear(DateTime d) => '${monthName(d.month)} ${d.year}';

DateTime dateOnly(DateTime d) => DateTime(d.year, d.month, d.day);

bool sameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

/// આજે / ગઈકાલે / 8 ઑક્ટો
String dayLabel(DateTime d) {
  final DateTime t = dateOnly(DateTime.now());
  final int diff = t.difference(dateOnly(d)).inDays;
  if (diff == 0) return bi('આજે', 'Today');
  if (diff == 1) return bi('ગઈકાલે', 'Yesterday');
  return dm(d);
}

String ago(DateTime d) {
  final Duration x = DateTime.now().difference(d);
  if (x.inMinutes < 1) return bi('હમણાં જ', 'just now');
  if (x.inMinutes < 60) return bi('${x.inMinutes} મિનિટ પહેલાં', '${x.inMinutes} min ago');
  if (x.inHours < 24) return bi('${x.inHours} કલાક પહેલાં', '${x.inHours} h ago');
  return bi('${x.inDays} દિવસ પહેલાં', '${x.inDays} d ago');
}

String initialOf(String name) {
  final String t = name.trim();
  if (t.isEmpty) return '?';
  return String.fromCharCodes(<int>[t.runes.first]);
}

String csvCell(Object? v) {
  final String s = (v ?? '').toString();
  if (s.contains(',') || s.contains('"') || s.contains('\n')) {
    return '"${s.replaceAll('"', '""')}"';
  }
  return s;
}

// ------------------------------------------------------------ TallyPrime style
const List<String> _tMon = <String>['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/// 15-Oct-26 (the date column of TallyPrime reports)
String tDate(DateTime d) => '${d.day}-${_tMon[d.month - 1]}-${pad2(d.year % 100)}';

/// 15-Oct-2026
String tDateFull(DateTime d) => '${d.day}-${_tMon[d.month - 1]}-${d.year}';

/// 12,34,567.50 - no symbol, always two decimals (blank for zero)
String tAmt(num v) => v.abs() < 0.005 ? '' : grp(v.abs(), dec: 2);

/// A debit-positive balance as Tally writes it: 12,34,567.50 Dr / 12,34,567.50 Cr
String tDr(num v) => v.abs() < 0.005 ? '0.00' : (v > 0 ? '${grp(v, dec: 2)} Dr' : '${grp(-v, dec: 2)} Cr');

/// A credit-positive balance as Tally writes it
String tCr(num v) => tDr(-v);
