import 'package:flutter/material.dart';

/// Tells every widget whether it is currently laid out for PC (desktop) or
/// phone. The value is decided by the view-mode toggle at the very top of the
/// app (Phone / PC / Auto), so both layouts can be previewed on any device.
class DeviceScope extends InheritedWidget {
  final bool pc;
  final double width;
  final double height;

  const DeviceScope({
    super.key,
    required this.pc,
    required this.width,
    required this.height,
    required super.child,
  });

  static DeviceScope of(BuildContext context) {
    final DeviceScope? s = context.dependOnInheritedWidgetOfExactType<DeviceScope>();
    return s ?? DeviceScope(pc: false, width: 400, height: 800, child: const SizedBox());
  }

  static bool isPc(BuildContext context) => of(context).pc;

  @override
  bool updateShouldNotify(DeviceScope old) => pc != old.pc || width != old.width || height != old.height;
}

/// Column count helper for card grids.
int gridCols(double width, {double min = 260, int max = 6}) {
  int c = (width / min).floor();
  if (c < 1) c = 1;
  if (c > max) c = max;
  return c;
}
