/// Shown in the title bar and in App diagnostics, so it is clear which build is running. Keep it equal to pubspec.yaml.
const String kAppVersion = '1.27.0+61';

/// Name of the running app: "Balaji Pro" (owner) or "Balaji Kanta" (weighbridge operator app, lib/main_kanta.dart).
String kAppTitle = 'Balaji Pro';
