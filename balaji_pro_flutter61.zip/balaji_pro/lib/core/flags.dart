/// The GST part of the app that WE make (GST invoices, GSTR-1 return, "GST paid to Govt" expense head).
/// The GST that comes from Tally (Tally data > GST, Tally GST Estimate) is always shown.
/// It is switched OFF for now - the books are the plain (kachha) books only. Nothing is deleted: set this to
/// `true` and every GST screen, button and menu line comes back.
const bool kGstOn = false;

/// Screens that belong to the GST part.
const Set<String> kGstScreens = <String>{'gst_bill', 'gstr1'};

/// SIMPLE MODE (the owner's choice, ON by default): the app shows only what the daily account of the raw material (kacha mal) needs -
/// chits, kanta, maal, farmer khata and payments, expenses, cash / bank book, day account, sales and what the buyers owe, stock, rates,
/// and the Tally parts that matter (payments, purchase check, day book). Everything else is only HIDDEN from menus, lists, search and
/// buttons - nothing is deleted. Settings > "Simple mode" OFF brings every screen back.
bool kSimple = true;

/// The screens of the simple mode (the ids of features/registry.dart, plus a few ids of menu lines that are not screens).
const Set<String> kSimpleKeep = <String>{
  // the day
  'dashboard', 'biz_home', 'hub', 'today', 'alerts', 'search', 'mel', 'transit', 'rates', 'purchase',
  // entries
  'chithi', 'chithi_new', 'kanta', 'kanta_new', 'maal', 'maal_new', 'maal_stock', 'daily', 'scan',
  // accounts of the raw material
  'khedut_khata', 'payments', 'expenses', 'cashbook', 'bank_book', 'day_account', 'weight_bill', 'brokerage', 'wages', 'month_close',
  'my_daybook', 'my_ledger', 'statement', 'export_money',
  // selling and what the buyers owe
  'sales', 'buyer_khata', 'collection', 'stock_live',
  // Tally (read only): what to add to the farmer khata, the purchase check, the day book
  'tally_pay', 'tally_mel', 'tally_live',
  // weighbridge
  'kanta_remote', 'kanta_khata',
  // checks that matter, settings
  'bad_entries', 'history', 'reviewed', 'parties', 'export', 'calc', 'help', 'diagnostics', 'settings', 'offline_queue', 'backup',
  // voucher forms / menu lines that are not screens (see tally_shell.dart)
  'v_payment', 'v_receipt', 'v_sales', 'v_expense', 'v_open_farmer', 'v_open_buyer', 'v_stock_open', 'v_calc', 'v_configure', 'v_lock', 'v_quit',
  'dbk_SAL', 'dbk_PUR', 'dbk_PAY', 'dbk_RCT', 'dbk_EXP',
};

bool _gstOk(String id) => kGstOn || !kGstScreens.contains(id);

/// False for a screen that is not shown (GST while GST is off; everything outside the list while simple mode is on).
/// An empty id (a menu line that is not a screen) is always shown.
bool screenOn(String id) {
  if (id.isEmpty) return true;
  if (!_gstOk(id)) return false;
  if (kSimple && !kSimpleKeep.contains(id)) return false;
  return true;
}

/// The same for a person who is not the owner: workers keep their screens, simple mode is only for the owner's menus.
bool screenOnFor(String id, bool admin) => admin ? screenOn(id) : (id.isEmpty || _gstOk(id));
