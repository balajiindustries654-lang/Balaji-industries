import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'core/app_state.dart';
import 'core/errlog.dart';
import 'core/keep_awake.dart';
import 'core/version.dart';
import 'data/kanta_log.dart';
import 'data/kanta_remote.dart';
import 'data/kanta_usb.dart';
import 'data/serial_decode.dart' show settleMinKg, settleNeedStable;
import 'data/live_store.dart';
import 'features/kanta/kanta_app.dart';
import 'features/kanta/kanta_print.dart';

/// Balaji Kanta - the operator's app for the weighbridge laptop.
/// Built with:  flutter build windows --release -t lib/main_kanta.dart   (see ci/win_kanta.ps1)
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  kAppTitle = 'Balaji Kanta';
  settleMinKg = 0; // like Matrix: any weight can be taken (no minimum) ...
  settleNeedStable = false; // ... also when it is not standing still
  FlutterError.onError = (FlutterErrorDetails d) {
    if (kDebugMode) FlutterError.presentError(d);
    final String t = d.exceptionAsString();
    final String lib = d.library ?? '';
    final bool noise = lib == 'rendering library' || t.contains('overflowed');
    ErrLog.report(d.exception, d.stack, where: lib, toast: !noise);
  };
  PlatformDispatcher.instance.onError = (Object e, StackTrace s) {
    ErrLog.report(e, s);
    return true;
  };
  await app.loadPrefs();
  unawaited(KeepAwake.start());
  runApp(const KantaRoot());
  live.boot();
  kantaPrintHook();
  KantaLog.start();
  kantaUsb.autoStart();
  kantaRemote.start();
}
