import 'dart:convert';
import 'dart:io' show ZLibDecoder;
import 'dart:typed_data';

// ======================================================================
// Weighbridge slips (Matrix "Intelligent Terminal" and similar)
//  - reads the REPORT file the terminal exports to a pen drive (CSV / text / XLSX), which has NO header line:
//      Sr | RST | Date | Vehicle | Mobile | Supplier | Material | City | Gross | Tare | Net | Charge
//  - the same slip reader is used for lines that arrive over the RS232 cable
//  - pure Dart (no Flutter) so it can be tested alone
//  - a weighing with only ONE weight (the second weight is still to come: "------" in the file, or tare 0)
//    is "partial": it is shown, but never sent to the app until the second weight is there
// ======================================================================

/// One weighbridge slip as read from a file or from the cable. 0 = not known.
class WbSlip {
  final String rst;
  final String vehicle;
  final String mobile;
  final String party;
  final String material;
  final String city;
  final double gross;
  final double tare;
  final double net;
  final double charge;
  final DateTime? at;
  final bool hasTime;
  const WbSlip({
    this.rst = '',
    this.vehicle = '',
    this.mobile = '',
    this.party = '',
    this.material = '',
    this.city = '',
    this.gross = 0,
    this.tare = 0,
    this.net = 0,
    this.charge = 0,
    this.at,
    this.hasTime = false,
  });

  /// Both weights are there.
  bool get complete => gross > 0 && tare > 0 && net > 0;

  /// There is a net weight, so the weighing is finished and can be sent.
  bool get ready => net > 0;

  /// One weight is there, the other is still to come (or only "------" in the file): not finished yet.
  bool get partial => net <= 0 && (gross > 0 || tare > 0);

  /// Gross - tare does not give the net (the terminal's own sum is used, but the owner is told).
  bool get odd => gross > 0 && tare > 0 && net > 0 && (gross - tare - net).abs() > 1.5;

  @override
  String toString() => 'WbSlip($rst $vehicle $gross/$tare/$net ${party.isEmpty ? '' : party})';
}

/// A whole file read as slips.
class WbScan {
  final List<WbSlip> slips;
  final int lines; // non-empty lines of the file
  final double? totalCharge; // the "Total ---->" line of the file, when there is one
  final DateTime? first;
  final DateTime? last;
  const WbScan(this.slips, this.lines, this.totalCharge, this.first, this.last);

  /// Enough lines look like slips to say "this is a weighbridge report".
  bool get looksRight => slips.length >= 2 && slips.length * 100 >= lines * 55;
  int get partialCount => slips.where((WbSlip s) => s.partial).length;
  double get chargeSum {
    double t = 0;
    for (final WbSlip s in slips) {
      t += s.charge;
    }
    return t;
  }
}

const double _kMaxWeight = 200000;

final RegExp _dateRe = RegExp(r'(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4}|\d{2})(?!\d)');
final RegExp _timeRe = RegExp(r'(?<!\d)(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(am|pm)?', caseSensitive: false);
final RegExp _dashRe = RegExp(r'^[\-–—_*.\s]{2,}$');

/// dd/mm/yyyy (Indian order). Null when it cannot be a date.
DateTime? wbDate(String raw) {
  final RegExpMatch? m = _dateRe.firstMatch(raw);
  if (m == null) return null;
  final int d = int.parse(m[1]!);
  final int mo = int.parse(m[2]!);
  int y = int.parse(m[3]!);
  if (y < 100) y += 2000;
  if (mo < 1 || mo > 12 || d < 1 || d > 31 || y < 2000 || y > 2100) return null;
  return DateTime(y, mo, d);
}

/// The time part of "14/10/2026 08:15" or "08:15 PM".
({int h, int m})? wbTime(String raw) {
  final RegExpMatch? m = _timeRe.firstMatch(raw);
  if (m == null) return null;
  int h = int.parse(m[1]!);
  final int mi = int.parse(m[2]!);
  final String ap = (m[4] ?? '').toLowerCase();
  if (ap == 'pm' && h < 12) h += 12;
  if (ap == 'am' && h == 12) h = 0;
  if (h > 23 || mi > 59) return null;
  return (h: h, m: mi);
}

double? _num(String raw) {
  final String t = raw.trim().replaceAll(RegExp(r'\s+'), '').replaceAll(',', '');
  if (t.isEmpty || !RegExp(r'^\d+(\.\d+)?$').hasMatch(t)) return null;
  return double.tryParse(t);
}

/// A cell that can be a weight: a number, or a dash line (= not weighed yet).
({bool ok, double v}) _weightCell(String raw) {
  final String s = raw.trim();
  if (s.isEmpty) return (ok: false, v: 0);
  if (_dashRe.hasMatch(s)) return (ok: true, v: 0);
  final double? n = _num(s);
  if (n != null && n <= _kMaxWeight) return (ok: true, v: n);
  return (ok: false, v: 0);
}

String _cleanText(String raw) {
  final String s = raw.trim().replaceAll(RegExp(r'\s+'), ' ');
  if (s.isEmpty) return '';
  // names the terminal could not write come out as / * - symbols: nothing readable
  if (!RegExp(r'[A-Za-z0-9઀-૿]').hasMatch(s)) return '';
  if (RegExp(r'^[xX]{3,}$').hasMatch(s)) return '';
  return s;
}

bool _isMobile(String s) {
  final String d = s.replaceAll(RegExp(r'[\s\-+]'), '');
  return RegExp(r'^\d{7,13}$').hasMatch(d);
}

class _Read {
  final double gross;
  final double tare;
  final double net;
  final double charge;
  final String mobile;
  final String party;
  final String material;
  final String city;
  const _Read(this.gross, this.tare, this.net, this.charge, this.mobile, this.party, this.material, this.city);

  /// The three weights fit together: gross - tare = net, or only one weight is there, or only the net.
  bool get consistent {
    final double g = gross;
    final double t = tare;
    final double n = net;
    if (g > 0 && t > 0 && n > 0) return (g - t - n).abs() <= 1.5;
    if (g > 0 && t <= 0) return n <= 0 || (n - g).abs() < 0.5;
    if (g <= 0 && t > 0) return n <= 0;
    if (g <= 0 && t <= 0) return n > 0;
    return false;
  }
}

/// One row of cells -> slip. Null when the row is not a slip (title line, "Total" line, empty line).
WbSlip? wbSlipFromCells(List<String> cells) {
  final List<String> c = <String>[for (final String x in cells) x.trim().replaceAll('"', '')];
  int di = -1;
  for (int i = 0; i < c.length; i++) {
    if (wbDate(c[i]) != null) {
      di = i;
      break;
    }
  }
  if (di < 0) return null;
  final DateTime day = wbDate(c[di])!;
  // time: in the date cell, or in the next cell
  ({int h, int m})? tm = wbTime(c[di].replaceFirst(_dateRe, ' '));
  int vi = di + 1;
  if (tm == null && vi < c.length && RegExp(r'^\d{1,2}:\d{2}').hasMatch(c[vi])) {
    tm = wbTime(c[vi]);
    vi++;
  }
  if (vi >= c.length) return null;
  // the vehicle is the cell after the date; when that is empty, the first plate-like cell after it
  String veh = c[vi];
  if (veh.isEmpty) {
    for (int k = vi + 1; k < c.length && k < vi + 3; k++) {
      if (RegExp(r'^[A-Za-z]{1,3}[\s\-]?\d{1,2}').hasMatch(c[k])) {
        veh = c[k];
        vi = k;
        break;
      }
    }
  }
  // RST: the nearest all-digit cell before the date
  String rst = '';
  for (int k = di - 1; k >= 0; k--) {
    if (RegExp(r'^\d{1,9}$').hasMatch(c[k])) {
      rst = c[k];
      break;
    }
  }
  // candidate 1: the weights are the last cells of the row (gross, tare, net, charge), counted from the right
  _Read? tail;
  {
    int end = c.length;
    while (end > vi + 1 && c[end - 1].isEmpty) {
      end--;
    }
    final List<double> w = <double>[];
    int firstW = end;
    for (int k = end - 1; k > vi && w.length < 4; k--) {
      final ({bool ok, double v}) x = _weightCell(c[k]);
      if (!x.ok) break;
      w.insert(0, x.v);
      firstW = k;
    }
    if (w.length >= 3) {
      final List<String> mid = <String>[for (int k = vi + 1; k < firstW && k < c.length; k++) c[k]];
      List<String> txt = mid;
      String mob = '';
      if (mid.isNotEmpty && (mid.length >= 4 || _isMobile(mid[0]))) {
        mob = _isMobile(mid[0]) ? mid[0].replaceAll(RegExp(r'[\s\-]'), '') : '';
        txt = mid.sublist(1);
      }
      String t(int i) => i < txt.length ? _cleanText(txt[i]) : '';
      tail = _Read(w[0], w[1], w[2], w.length >= 4 ? w[3] : 0, mob, t(0), t(1), t(2));
    }
  }
  // candidate 2: the usual 12-column layout (vehicle, mobile, supplier, material, city, gross, tare, net, charge)
  _Read? fixed;
  if (c.length >= vi + 8) {
    final ({bool ok, double v}) g = _weightCell(c[vi + 5]);
    final ({bool ok, double v}) t = _weightCell(c[vi + 6]);
    final ({bool ok, double v}) n = _weightCell(c[vi + 7]);
    if ((g.ok || c[vi + 5].isEmpty) && (t.ok || c[vi + 6].isEmpty) && (n.ok || c[vi + 7].isEmpty)) {
      double ch = 0;
      if (c.length > vi + 8) {
        final ({bool ok, double v}) x = _weightCell(c[vi + 8]);
        if (x.ok) ch = x.v;
      }
      fixed = _Read(g.v, t.v, n.v, ch, _isMobile(c[vi + 1]) ? c[vi + 1].replaceAll(RegExp(r'[\s\-]'), '') : '', _cleanText(c[vi + 2]), _cleanText(c[vi + 3]), _cleanText(c[vi + 4]));
    }
  }
  final _Read? pick = (tail != null && tail.consistent) ? tail : ((fixed != null && fixed.consistent) ? fixed : (tail ?? fixed));
  if (pick == null) return null;
  double gross = pick.gross;
  double tare = pick.tare;
  double net = pick.net;
  final double charge = pick.charge;
  final String mobile = pick.mobile;
  final String party = pick.party;
  final String material = pick.material;
  final String city = pick.city;
  if (net <= 0 && gross > 0 && tare > 0 && gross > tare) net = gross - tare;
  // first weight only: the terminal shows net = gross and tare 0
  if (tare <= 0 && gross > 0 && (net - gross).abs() < 0.5) net = 0;
  if (gross <= 0 && tare <= 0 && net <= 0) return null;
  final String vehicle = veh.toUpperCase().replaceAll(RegExp(r'[\s\-]'), '');
  DateTime at = day;
  bool hasTime = false;
  if (tm != null) {
    at = DateTime(day.year, day.month, day.day, tm.h, tm.m);
    hasTime = true;
  }
  return WbSlip(
    rst: rst,
    vehicle: vehicle,
    mobile: mobile,
    party: party,
    material: material,
    city: city,
    gross: gross,
    tare: tare,
    net: net,
    charge: charge,
    at: at,
    hasTime: hasTime,
  );
}

/// Reads a table of cells as slips (the Matrix report has no header line, so every row is tried).
WbScan wbScan(List<List<String>> table) {
  final List<WbSlip> out = <WbSlip>[];
  int lines = 0;
  double? total;
  for (final List<String> r in table) {
    if (r.every((String x) => x.trim().isEmpty)) continue;
    final String first = r.firstWhere((String x) => x.trim().isNotEmpty, orElse: () => '').toLowerCase();
    if (first.startsWith('total')) {
      for (int k = r.length - 1; k >= 0; k--) {
        final double? v = _num(r[k]);
        if (v != null) {
          total = v;
          break;
        }
      }
      continue;
    }
    lines++;
    final WbSlip? s = wbSlipFromCells(r);
    if (s != null) out.add(s);
  }
  DateTime? lo;
  DateTime? hi;
  for (final WbSlip s in out) {
    final DateTime? a = s.at;
    if (a == null) continue;
    if (lo == null || a.isBefore(lo)) lo = a;
    if (hi == null || a.isAfter(hi)) hi = a;
  }
  return WbScan(out, lines, total, lo, hi);
}

// ----------------------------------------------------------------------
// Files
// ----------------------------------------------------------------------

/// The text of a file: UTF-8, UTF-16 (with BOM) or Latin-1.
String wbDecodeText(List<int> b) {
  if (b.length >= 2 && b[0] == 0xFF && b[1] == 0xFE) {
    final List<int> u = <int>[for (int i = 2; i + 1 < b.length; i += 2) b[i] | (b[i + 1] << 8)];
    return String.fromCharCodes(u);
  }
  if (b.length >= 2 && b[0] == 0xFE && b[1] == 0xFF) {
    final List<int> u = <int>[for (int i = 2; i + 1 < b.length; i += 2) (b[i] << 8) | b[i + 1]];
    return String.fromCharCodes(u);
  }
  try {
    String s = utf8.decode(b);
    if (s.isNotEmpty && s.codeUnitAt(0) == 0xFEFF) s = s.substring(1);
    return s;
  } catch (_) {
    return latin1.decode(b);
  }
}

/// A file is an Excel (.xlsx) file when it is a zip.
bool wbIsXlsx(List<int> b) => b.length > 4 && b[0] == 0x50 && b[1] == 0x4B && b[2] == 0x03 && b[3] == 0x04;

/// The old binary Excel (.xls) file (read by xls_read.dart).
bool wbIsOldXls(List<int> b) => b.length > 8 && b[0] == 0xD0 && b[1] == 0xCF && b[2] == 0x11 && b[3] == 0xE0;

int _u16(Uint8List d, int o) => d[o] | (d[o + 1] << 8);
int _u32(Uint8List d, int o) => d[o] | (d[o + 1] << 8) | (d[o + 2] << 16) | (d[o + 3] << 24);

/// Reads the files of a zip: name -> bytes. Only what is asked for (by name test) is unpacked.
Map<String, Uint8List> _unzip(Uint8List d, bool Function(String name) want) {
  int eocd = -1;
  for (int i = d.length - 22; i >= 0 && i >= d.length - 70000; i--) {
    if (d[i] == 0x50 && d[i + 1] == 0x4B && d[i + 2] == 0x05 && d[i + 3] == 0x06) {
      eocd = i;
      break;
    }
  }
  if (eocd < 0) throw const FormatException('zip');
  final int n = _u16(d, eocd + 10);
  int p = _u32(d, eocd + 16);
  final Map<String, Uint8List> out = <String, Uint8List>{};
  for (int i = 0; i < n; i++) {
    if (p + 46 > d.length || _u32(d, p) != 0x02014B50) break;
    final int method = _u16(d, p + 10);
    final int csize = _u32(d, p + 20);
    final int nlen = _u16(d, p + 28);
    final int xlen = _u16(d, p + 30);
    final int clen = _u16(d, p + 32);
    final int lho = _u32(d, p + 42);
    final String name = utf8.decode(d.sublist(p + 46, p + 46 + nlen), allowMalformed: true);
    p += 46 + nlen + xlen + clen;
    if (!want(name)) continue;
    if (lho + 30 > d.length) continue;
    final int ln = _u16(d, lho + 26);
    final int lx = _u16(d, lho + 28);
    final int s = lho + 30 + ln + lx;
    if (s + csize > d.length) continue;
    final Uint8List raw = Uint8List.sublistView(d, s, s + csize);
    if (method == 0) {
      out[name] = Uint8List.fromList(raw);
    } else if (method == 8) {
      out[name] = Uint8List.fromList(ZLibDecoder(raw: true).convert(raw));
    }
  }
  return out;
}

String _xmlText(String s) {
  return s.replaceAllMapped(RegExp(r'&(#x[0-9a-fA-F]+|#\d+|amp|lt|gt|quot|apos);'), (Match m) {
    final String e = m[1]!;
    switch (e) {
      case 'amp':
        return '&';
      case 'lt':
        return '<';
      case 'gt':
        return '>';
      case 'quot':
        return '"';
      case 'apos':
        return "'";
    }
    final int? cp = e.startsWith('#x') ? int.tryParse(e.substring(2), radix: 16) : int.tryParse(e.substring(1));
    return cp == null ? '' : String.fromCharCode(cp);
  });
}

int _colIndex(String ref) {
  int c = 0;
  for (int i = 0; i < ref.length; i++) {
    final int u = ref.codeUnitAt(i);
    if (u >= 65 && u <= 90) {
      c = c * 26 + (u - 64);
    } else if (u >= 97 && u <= 122) {
      c = c * 26 + (u - 96);
    } else {
      break;
    }
  }
  return c - 1;
}

/// The style numbers (s="..") of cells that show a date: built-in date formats and custom ones with d / m / y.
Set<int> _dateStyles(String? xml) {
  final Set<int> out = <int>{};
  if (xml == null) return out;
  final Set<int> customDate = <int>{};
  for (final RegExpMatch m in RegExp(r'<numFmt\b[^>]*?numFmtId="(\d+)"[^>]*?formatCode="([^"]*)"').allMatches(xml)) {
    final String code = _xmlText(m[2]!).replaceAll(RegExp(r'"[^"]*"|\[[^\]]*\]|\\.'), '');
    if (RegExp(r'[dmyDMY]').hasMatch(code) && !RegExp(r'0\.0|#').hasMatch(code)) customDate.add(int.parse(m[1]!));
  }
  final RegExpMatch? cx = RegExp(r'<cellXfs\b[^>]*>(.*?)</cellXfs>', dotAll: true).firstMatch(xml);
  if (cx == null) return out;
  int i = 0;
  for (final RegExpMatch m in RegExp(r'<xf\b([^>]*?)(?:/>|>)').allMatches(cx[1]!)) {
    final int? id = int.tryParse(RegExp(r'numFmtId="(\d+)"').firstMatch(m[1]!)?[1] ?? '');
    if (id != null && ((id >= 14 && id <= 22) || (id >= 45 && id <= 47) || customDate.contains(id))) out.add(i);
    i++;
  }
  return out;
}

/// Excel day number -> dd/mm/yyyy (with the time when there is a fraction).
String _serialDate(double v) {
  final DateTime d = DateTime.utc(1899, 12, 30).add(Duration(seconds: (v * 86400).round()));
  String t2(int x) => x.toString().padLeft(2, '0');
  final String day = '${t2(d.day)}/${t2(d.month)}/${d.year}';
  return (d.hour != 0 || d.minute != 0) ? '$day ${t2(d.hour)}:${t2(d.minute)}' : day;
}

/// The first sheet of an .xlsx file as a table of text cells.
List<List<String>> wbXlsxTable(List<int> bytes) {
  final Uint8List d = bytes is Uint8List ? bytes : Uint8List.fromList(bytes);
  final Map<String, Uint8List> z = _unzip(d, (String n) => n == 'xl/sharedStrings.xml' || n == 'xl/styles.xml' || RegExp(r'^xl/worksheets/sheet\d+\.xml$').hasMatch(n));
  final List<String> sheets = z.keys.where((String k) => k.startsWith('xl/worksheets/')).toList()..sort((String a, String b) => a.length != b.length ? a.length - b.length : a.compareTo(b));
  if (sheets.isEmpty) throw const FormatException('no sheet');
  final List<String> shared = <String>[];
  final Uint8List? ss = z['xl/sharedStrings.xml'];
  if (ss != null) {
    final String x = utf8.decode(ss, allowMalformed: true);
    for (final RegExpMatch si in RegExp(r'<si\b[^>]*>(.*?)</si>', dotAll: true).allMatches(x)) {
      final StringBuffer b = StringBuffer();
      for (final RegExpMatch t in RegExp(r'<t\b[^>]*>(.*?)</t>', dotAll: true).allMatches(si[1]!)) {
        b.write(_xmlText(t[1]!));
      }
      shared.add(b.toString());
    }
  }
  final Uint8List? stx = z['xl/styles.xml'];
  final Set<int> dateSt = _dateStyles(stx == null ? null : utf8.decode(stx, allowMalformed: true));
  final String xml = utf8.decode(z[sheets.first]!, allowMalformed: true);
  final List<List<String>> table = <List<String>>[];
  for (final RegExpMatch row in RegExp(r'<row\b[^>]*?(?:/>|>(.*?)</row>)', dotAll: true).allMatches(xml)) {
    final String body = row[1] ?? '';
    final List<String> cells = <String>[];
    int next = 0;
    for (final RegExpMatch cm in RegExp(r'<c\b([^>]*?)(?:/>|>(.*?)</c>)', dotAll: true).allMatches(body)) {
      final String attrs = cm[1] ?? '';
      final String inner = cm[2] ?? '';
      final RegExpMatch? rm = RegExp(r'\br="([A-Za-z]+)\d+"').firstMatch(attrs);
      final int col = rm == null ? next : _colIndex(rm[1]!);
      final String type = RegExp(r'\bt="([^"]*)"').firstMatch(attrs)?[1] ?? '';
      String val = '';
      if (type == 'inlineStr') {
        final StringBuffer b = StringBuffer();
        for (final RegExpMatch t in RegExp(r'<t\b[^>]*>(.*?)</t>', dotAll: true).allMatches(inner)) {
          b.write(_xmlText(t[1]!));
        }
        val = b.toString();
      } else {
        final String? v = RegExp(r'<v>(.*?)</v>', dotAll: true).firstMatch(inner)?[1];
        if (v != null) {
          if (type == 's') {
            final int? ix = int.tryParse(v.trim());
            val = ix != null && ix >= 0 && ix < shared.length ? shared[ix] : '';
          } else {
            val = _xmlText(v);
            final int? st = int.tryParse(RegExp(r'\bs="(\d+)"').firstMatch(attrs)?[1] ?? '');
            final double? dv = double.tryParse(val);
            if (dv != null && st != null && dateSt.contains(st) && (type.isEmpty || type == 'n')) {
              val = _serialDate(dv);
            } else if (RegExp(r'^\d+\.0+$').hasMatch(val)) {
              // 2825.0 -> 2825
              val = val.substring(0, val.indexOf('.'));
            }
          }
        }
      }
      while (cells.length < col) {
        cells.add('');
      }
      if (cells.length == col) {
        cells.add(val);
      } else {
        cells[col] = val;
      }
      next = col + 1;
    }
    table.add(cells);
  }
  return table;
}
