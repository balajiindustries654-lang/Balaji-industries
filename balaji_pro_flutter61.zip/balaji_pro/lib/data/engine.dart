import 'dart:math' as math;
import '../core/fmt.dart';
import '../core/i18n.dart';
import 'live_models.dart';

// ====================================================================== cfg
/// Limits used to decide whether a vehicle is OK or not. Saved in the shared
/// `app_settings` table (key `flutter_match`) so every phone uses the same.
class MatchCfg {
  double pct; // allowed difference in % of the chit weight
  double floorKg; // ... but never less than this many kg
  int waitH; // hours to wait for a weighbridge entry after the chit
  int windowH; // longest gap between a chit and its weighbridge entry
  List<String> direct; // commodities that go straight to the mill (no kanta here)

  MatchCfg({this.pct = 0.5, this.floorKg = 100, this.waitH = 12, this.windowH = 36, List<String>? direct})
      : direct = direct ?? <String>['aeranda', 'એરંડા', 'castor'];

  double tol(double w) => math.max(floorKg, w * pct / 100);

  bool isDirect(String commodity) {
    final String c = commodity.toLowerCase();
    if (c.isEmpty) return false;
    for (final String d in direct) {
      final String x = d.toLowerCase().trim();
      if (x.isNotEmpty && c.contains(x)) return true;
    }
    return false;
  }

  factory MatchCfg.fromJson(Map<String, dynamic> j) {
    final MatchCfg d = MatchCfg();
    final Object? dir = j['direct'];
    return MatchCfg(
      pct: dbl(j['pct'], d.pct),
      floorKg: dbl(j['floor'], d.floorKg),
      waitH: dbl(j['wait'], d.waitH.toDouble()).round(),
      windowH: dbl(j['window'], d.windowH.toDouble()).round(),
      direct: dir is List ? dir.map((dynamic e) => '$e').toList() : null,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'pct': pct,
        'floor': floorKg,
        'wait': waitH,
        'window': windowH,
        'direct': direct,
      };
}

String sk(double v) {
  if (v.abs() < 0.5) return '0';
  return '${v > 0 ? '+' : '-'}${grp(v.abs())}';
}

// ===================================================================== trips
enum TripState { ok, diff, noKanta, wait, noChit, direct }

class Trip {
  final String vk;
  final String vehicle;
  final List<Chit> chits;
  final Kanta? kanta;
  final TripState state;
  final double chitKg;
  final double kantaKg;
  final double tol;
  final DateTime at;

  Trip(this.vk, this.vehicle, this.chits, this.kanta, this.state, this.chitKg, this.kantaKg, this.tol, this.at);

  bool get both => kanta != null && chits.isNotEmpty;
  double get diff => both ? kantaKg - chitKg : 0;
  double get diffPct => both && chitKg > 0 ? diff / chitKg * 100 : 0;
  bool get problem => state == TripState.diff || state == TripState.noKanta || state == TripState.noChit;

  String get farmers {
    final List<String> l = <String>[];
    for (final Chit c in chits) {
      if (c.farmer.isNotEmpty && !l.contains(c.farmer)) l.add(c.farmer);
    }
    return l.join(', ');
  }

  String get villages {
    final List<String> l = <String>[];
    for (final Chit c in chits) {
      if (c.village.isNotEmpty && !l.contains(c.village)) l.add(c.village);
    }
    return l.join(', ');
  }

  String get commodity {
    for (final Chit c in chits) {
      if (c.commodity.isNotEmpty) return c.commodity;
    }
    return '';
  }
}

class _Draft {
  final List<Chit> chits;
  final Kanta? kanta;
  _Draft(this.chits, this.kanta);
}

/// Pairs chits with weighbridge entries, vehicle by vehicle, in time order.
/// One kanta closes the load: all chits entered for that vehicle shortly
/// before it (one truck may carry several farmers) are added together.
List<Trip> buildTrips(List<Chit> chits, List<Kanta> kantas, MatchCfg cfg, DateTime now) {
  final Map<String, List<Chit>> cm = <String, List<Chit>>{};
  final Map<String, List<Kanta>> km = <String, List<Kanta>>{};
  for (final Chit c in chits) {
    cm.putIfAbsent(c.vkey, () => <Chit>[]).add(c);
  }
  for (final Kanta k in kantas) {
    km.putIfAbsent(k.vkey, () => <Kanta>[]).add(k);
  }
  final Set<String> keys = <String>{...cm.keys, ...km.keys};
  final List<Trip> out = <Trip>[];

  for (final String vk in keys) {
    final List<Chit> cs = List<Chit>.from(cm[vk] ?? <Chit>[]);
    cs.sort((Chit a, Chit b) => a.at.compareTo(b.at));
    final List<Kanta> ks = List<Kanta>.from(km[vk] ?? <Kanta>[]);
    ks.sort((Kanta a, Kanta b) => a.at.compareTo(b.at));

    final List<_Draft> drafts = <_Draft>[];
    final List<Chit> open = <Chit>[];
    int ci = 0;
    for (final Kanta kt in ks) {
      while (ci < cs.length && !cs[ci].at.isAfter(kt.at)) {
        open.add(cs[ci]);
        ci++;
      }
      final List<Chit> take = <Chit>[];
      DateTime prev = kt.at;
      int cut = open.length; // open[0..cut) are older and not part of this load
      for (int i = open.length - 1; i >= 0; i--) {
        final Chit c = open[i];
        final int gap = prev.difference(c.at).inMinutes;
        final int lim = take.isEmpty ? cfg.windowH * 60 : cfg.waitH * 60;
        if (gap <= lim) {
          take.insert(0, c);
          prev = c.at;
          cut = i;
        } else {
          break;
        }
      }
      for (int i = 0; i < cut; i++) {
        drafts.add(_Draft(<Chit>[open[i]], null));
      }
      drafts.add(_Draft(take, kt));
      open.clear();
    }
    while (ci < cs.length) {
      open.add(cs[ci]);
      ci++;
    }
    // chits still waiting for a weighbridge entry: group the ones entered close together
    List<Chit> grp = <Chit>[];
    for (final Chit c in open) {
      if (grp.isNotEmpty && c.at.difference(grp.last.at).inMinutes > cfg.waitH * 60) {
        drafts.add(_Draft(grp, null));
        grp = <Chit>[];
      }
      grp.add(c);
    }
    if (grp.isNotEmpty) drafts.add(_Draft(grp, null));

    // chit written a little AFTER the weighbridge entry (late entry)
    for (final _Draft d in List<_Draft>.from(drafts)) {
      final Kanta? kt = d.kanta;
      if (kt == null || d.chits.isNotEmpty) continue;
      for (final _Draft o in List<_Draft>.from(drafts)) {
        if (o.kanta != null || o.chits.isEmpty) continue;
        final DateTime first = o.chits.first.at;
        if (first.isAfter(kt.at) && first.difference(kt.at).inHours <= 12) {
          d.chits.addAll(o.chits);
          drafts.remove(o);
          break;
        }
      }
    }

    for (final _Draft d in drafts) {
      final Kanta? kt = d.kanta;
      final List<Chit> l = d.chits;
      double ck = 0;
      for (final Chit c in l) {
        ck += c.cmpKg;
      }
      final double kk = kt == null ? 0 : kt.kg;
      final double tol = cfg.tol(ck);
      TripState st;
      DateTime at;
      String veh;
      if (kt == null) {
        at = l.last.at;
        veh = l.first.vehicle;
        bool allDirect = true;
        for (final Chit c in l) {
          if (!cfg.isDirect(c.commodity)) allDirect = false;
        }
        if (allDirect) {
          st = TripState.direct;
        } else if (now.difference(l.last.at).inMinutes < cfg.waitH * 60) {
          st = TripState.wait;
        } else {
          st = TripState.noKanta;
        }
      } else {
        at = kt.at;
        veh = kt.vehicle.isNotEmpty ? kt.vehicle : (l.isNotEmpty ? l.first.vehicle : '');
        if (l.isEmpty) {
          st = TripState.noChit;
        } else if (kk <= 0 || ck <= 0) {
          st = TripState.diff;
        } else {
          st = (kk - ck).abs() <= tol ? TripState.ok : TripState.diff;
        }
      }
      out.add(Trip(vk, veh, l, kt, st, ck, kk, tol, at));
    }
  }
  out.sort((Trip a, Trip b) => b.at.compareTo(a.at));
  return out;
}

// ================================================================== group by
enum Dim { vehicle, farmer, village, broker, majur, commodity, day }

class GroupRow {
  final String key;
  String label;
  int chits = 0;
  double kg = 0;
  double matchedKg = 0;
  double kantaKg = 0;
  final Set<Trip> trips = <Trip>{};
  final Set<Trip> mtrips = <Trip>{};
  DateTime? date;

  GroupRow(this.key, this.label);

  double get ghat => kantaKg - matchedKg;
  double get ghatPct => matchedKg > 0 ? ghat / matchedKg * 100 : 0;
}

String majurName(Map<String, String> names, String uid) {
  if (uid.isEmpty) return '—';
  final String? n = names[uid];
  if (n != null && n.isNotEmpty) return n;
  return uid.length > 6 ? uid.substring(0, 6) : uid;
}

List<GroupRow> groupBy(List<Trip> trips, Dim dim, Map<String, String> names) {
  final Map<String, GroupRow> m = <String, GroupRow>{};
  GroupRow row(String key, String label, [DateTime? date]) {
    final GroupRow r = m.putIfAbsent(key, () => GroupRow(key, label));
    if (date != null) r.date = date;
    return r;
  }

  for (final Trip t in trips) {
    if (t.chits.isEmpty) {
      if (dim == Dim.vehicle) {
        row(t.vk.isEmpty ? '-' : t.vk, t.vehicle.isEmpty ? '—' : t.vehicle).trips.add(t);
      } else if (dim == Dim.day) {
        final DateTime d = dayOf(t.at);
        row('${d.year}-${d.month}-${d.day}', dm(d), d).trips.add(t);
      }
      continue;
    }
    for (final Chit c in t.chits) {
      String key = '';
      String label = '';
      DateTime? date;
      switch (dim) {
        case Dim.vehicle:
          key = c.vkey;
          label = c.vehicle;
          break;
        case Dim.farmer:
          key = nameKey(c.farmer);
          label = c.farmer;
          break;
        case Dim.village:
          key = nameKey(c.village);
          label = c.village;
          break;
        case Dim.broker:
          key = nameKey(c.broker);
          label = c.broker;
          break;
        case Dim.majur:
          key = c.by;
          label = majurName(names, c.by);
          break;
        case Dim.commodity:
          key = nameKey(c.commodity);
          label = c.commodity;
          break;
        case Dim.day:
          date = dayOf(t.at);
          key = '${date.year}-${date.month}-${date.day}';
          label = dm(date);
          break;
      }
      if (key.isEmpty) {
        key = '-';
        label = '—';
      }
      final GroupRow r = row(key, label, date);
      r.chits++;
      r.kg += c.cmpKg;
      r.trips.add(t);
      if (t.both && t.kantaKg > 0 && t.chitKg > 0) {
        final double share = c.cmpKg / t.chitKg;
        r.matchedKg += c.cmpKg;
        r.kantaKg += t.kantaKg * share;
        r.mtrips.add(t);
      }
    }
  }
  return m.values.toList();
}

// ====================================================================== audit
enum Rule { mismatch, noKanta, noChit, rstGap, dup, photo, odd, pattern }

class Finding {
  final Rule rule;
  final int sev; // 0 info, 1 check, 2 problem
  final String Function() title;
  final String Function() detail;
  final DateTime at;
  final Trip? trip;
  final Chit? chit;
  final Kanta? kanta;
  final MaalRow? maal;

  Finding(this.rule, this.sev, this.title, this.detail, this.at, {this.trip, this.chit, this.kanta, this.maal});
}

String ruleName(Rule r) {
  switch (r) {
    case Rule.mismatch:
      return bi('વજન ફરક', 'Weight difference');
    case Rule.noKanta:
      return bi('કાંટો નથી', 'No kanta');
    case Rule.noChit:
      return bi('ચિઠ્ઠી નથી', 'No chit');
    case Rule.rstGap:
      return bi('RST ગુમ', 'RST missing');
    case Rule.dup:
      return bi('ડુપ્લિકેટ', 'Duplicate');
    case Rule.photo:
      return bi('ફોટો નથી', 'No photo');
    case Rule.odd:
      return bi('અજુગતી વિગત', 'Odd value');
    case Rule.pattern:
      return bi('શંકાસ્પદ પેટર્ન', 'Suspicious pattern');
  }
}

String tripTitle(Trip t) => t.vehicle.isEmpty ? '—' : t.vehicle;

List<Finding> runAudit({
  required List<Chit> chits,
  required List<Kanta> kantas,
  required List<MaalRow> maals,
  required List<Trip> trips,
  required MatchCfg cfg,
  required Map<String, String> names,
  required DateTime now,
}) {
  final List<Finding> out = <Finding>[];

  // ---- 1) per vehicle: difference / no kanta / no chit
  for (final Trip t in trips) {
    if (t.state == TripState.diff) {
      out.add(Finding(
        Rule.mismatch,
        t.diff.abs() > t.tol * 2 ? 2 : 1,
        () => '${tripTitle(t)}: ${bi('ફરક', 'Diff')} ${sk(t.diff)} KG',
        () => '${bi('કાંટો', 'Kanta')} ${grp(t.kantaKg)} · ${bi('ચિઠ્ઠી', 'Chit')} ${grp(t.chitKg)} (${t.diffPct.toStringAsFixed(2)}%) · ${t.farmers}',
        t.at,
        trip: t,
      ));
    } else if (t.state == TripState.noKanta) {
      final int hrs = now.difference(t.chits.last.at).inHours;
      out.add(Finding(
        Rule.noKanta,
        2,
        () => '${tripTitle(t)}: ${bi('કાંટો નથી', 'no kanta entry')}',
        () => '${t.farmers} · ${grp(t.chitKg)} KG · ${bi('$hrs કલાક થયા', '$hrs h ago')}',
        t.at,
        trip: t,
      ));
    } else if (t.state == TripState.noChit) {
      final Kanta k = t.kanta!;
      out.add(Finding(
        Rule.noChit,
        2,
        () => '${tripTitle(t)}: ${bi('ચિઠ્ઠી બની નથી', 'no chit made')}',
        () => 'RST ${k.rst.isEmpty ? '-' : k.rst} · ${bi('કાંટો', 'Kanta')} ${grp(k.kg)} KG',
        t.at,
        trip: t,
        kanta: k,
      ));
    }
  }

  // ---- 2) RST numbers missing in the series
  final Map<int, Kanta> byNo = <int, Kanta>{};
  final DateTime since = now.subtract(const Duration(days: 60));
  for (final Kanta k in kantas) {
    if (k.at.isBefore(since)) continue;
    final String r = k.rst.trim();
    if (r.isEmpty || !RegExp(r'^[0-9]+$').hasMatch(r)) continue;
    final int? n = int.tryParse(r);
    if (n != null) byNo[n] = k;
  }
  final List<int> nos = byNo.keys.toList()..sort();
  for (int i = 1; i < nos.length; i++) {
    final int a = nos[i - 1];
    final int b = nos[i];
    final int gapN = b - a - 1;
    if (gapN >= 1 && gapN <= 40) {
      final Kanta ka = byNo[a]!;
      final Kanta kb = byNo[b]!;
      final String range = gapN == 1 ? '${a + 1}' : '${a + 1}-${b - 1}';
      out.add(Finding(
        Rule.rstGap,
        2,
        () => 'RST $range ${bi('ગુમ', 'missing')}',
        () => '$a (${dm(ka.at)} ${hm(ka.at)}) → $b (${dm(kb.at)} ${hm(kb.at)})',
        kb.at,
        kanta: kb,
      ));
    }
  }

  // ---- 3) duplicates
  final Map<String, List<Chit>> cno = <String, List<Chit>>{};
  for (final Chit c in chits) {
    if (c.no.isNotEmpty) cno.putIfAbsent(c.no, () => <Chit>[]).add(c);
  }
  cno.forEach((String no, List<Chit> l) {
    if (l.length > 1) {
      l.sort((Chit a, Chit b) => b.at.compareTo(a.at));
      out.add(Finding(
        Rule.dup,
        2,
        () => '${bi('ચિઠ્ઠી નં.', 'Chit no.')} $no ${bi('${l.length} વાર', 'x${l.length}')}',
        () => l.map((Chit c) => '${c.farmer} ${c.vehicle} ${grp(c.cmpKg)}').join(' | '),
        l.first.at,
        chit: l.first,
      ));
    }
  });
  final Map<String, List<Kanta>> kno = <String, List<Kanta>>{};
  for (final Kanta k in kantas) {
    if (k.rst.isNotEmpty) kno.putIfAbsent(k.rst, () => <Kanta>[]).add(k);
  }
  kno.forEach((String no, List<Kanta> l) {
    if (l.length > 1) {
      l.sort((Kanta a, Kanta b) => b.at.compareTo(a.at));
      out.add(Finding(
        Rule.dup,
        2,
        () => 'RST $no ${bi('${l.length} વાર', 'x${l.length}')}',
        () => l.map((Kanta k) => '${k.vehicle} ${grp(k.kg)}').join(' | '),
        l.first.at,
        kanta: l.first,
      ));
    }
  });
  final Map<String, List<Chit>> same = <String, List<Chit>>{};
  for (final Chit c in chits) {
    if (c.vkey.isEmpty || c.cmpKg <= 0) continue;
    final DateTime d = dayOf(c.at);
    same.putIfAbsent('${c.vkey}|${d.year}-${d.month}-${d.day}|${c.cmpKg}|${nameKey(c.farmer)}', () => <Chit>[]).add(c);
  }
  same.forEach((String k, List<Chit> l) {
    if (l.length > 1 && !(cno[l.first.no] != null && l.every((Chit c) => c.no == l.first.no))) {
      l.sort((Chit a, Chit b) => b.at.compareTo(a.at));
      out.add(Finding(
        Rule.dup,
        1,
        () => '${l.first.vehicle}: ${bi('એક જ ખેડૂત અને વજન ફરી', 'same farmer and weight again')}',
        () => '${l.first.farmer} · ${grp(l.first.cmpKg)} KG · ${l.map((Chit c) => '#${c.no}').join(', ')}',
        l.first.at,
        chit: l.first,
      ));
    }
  });

  // ---- 4) photo missing
  for (final Chit c in chits) {
    if (c.photo.isEmpty) {
      out.add(Finding(Rule.photo, 1, () => '${bi('ચિઠ્ઠી', 'Chit')} #${c.no}: ${bi('ફોટો નથી', 'no photo')}', () => '${c.farmer} · ${c.vehicle}', c.at, chit: c));
    }
  }
  for (final Kanta k in kantas) {
    if (k.slip.isEmpty) {
      out.add(Finding(Rule.photo, 1, () => 'RST ${k.rst}: ${bi('સ્લિપ ફોટો નથી', 'no slip photo')}', () => '${k.vehicle} · ${grp(k.kg)} KG', k.at, kanta: k));
    }
  }
  for (final MaalRow m in maals) {
    if (m.slip.isEmpty) {
      out.add(Finding(Rule.photo, 0, () => '${bi('માલ', 'Maal')} ${m.vehicle}: ${bi('સ્લિપ ફોટો નથી', 'no slip photo')}', () => '${m.material} · ${m.bags} ${bi('બેગ', 'bags')}', m.at, maal: m));
    }
  }

  // ---- 5) odd values
  for (final Chit c in chits) {
    final List<String> why = <String>[];
    if (c.net <= 0) why.add(bi('ચોખ્ખું વજન 0 કે ઓછું', 'net weight 0 or less'));
    if (c.net > c.gross + 0.5 && c.gross > 0) why.add(bi('ચોખ્ખું > કુલ', 'net more than gross'));
    if (c.gross > 0 && (c.gross < 200 || c.gross > 60000)) why.add(bi('કુલ વજન અજુગતું', 'odd gross weight'));
    if (c.vehicle.isEmpty) why.add(bi('ગાડી નંબર નથી', 'no vehicle number'));
    if (c.gross > 0 && c.kardo > c.gross * 0.08) why.add(bi('કરદો બહુ વધારે', 'kardo very high'));
    if (why.isNotEmpty) {
      out.add(Finding(Rule.odd, 1, () => '${bi('ચિઠ્ઠી', 'Chit')} #${c.no}: ${why.join(', ')}', () => '${c.farmer} · ${c.vehicle} · ${grp(c.gross)} KG', c.at, chit: c));
    }
  }
  for (final Kanta k in kantas) {
    final List<String> why = <String>[];
    if (k.kg <= 0) why.add(bi('વજન નથી', 'no weight'));
    if (k.kg > 0 && (k.kg < 500 || k.kg > 80000)) why.add(bi('વજન અજુગતું', 'odd weight'));
    if (k.vehicle.isEmpty) why.add(bi('ગાડી નંબર નથી', 'no vehicle number'));
    if (why.isNotEmpty) {
      out.add(Finding(Rule.odd, 1, () => 'RST ${k.rst}: ${why.join(', ')}', () => '${k.vehicle} · ${grp(k.kg)} KG', k.at, kanta: k));
    }
  }
  for (final MaalRow m in maals) {
    if (m.bags <= 0 || m.vehicle.isEmpty) {
      out.add(Finding(Rule.odd, 0, () => '${bi('માલ એન્ટ્રી', 'Maal entry')}: ${m.bags <= 0 ? bi('બેગ 0', 'bags 0') : bi('ગાડી નંબર નથી', 'no vehicle')}', () => '${m.material} · ${m.owner}', m.at, maal: m));
    }
  }

  // ---- 6) patterns (who / which vehicle loses weight again and again)
  void ghatPattern(Dim dim, String who) {
    for (final GroupRow r in groupBy(trips, dim, names)) {
      if (r.mtrips.length < 3 || r.key == '-') continue;
      if (r.ghatPct.abs() < cfg.pct) continue;
      final bool loss = r.ghat < 0;
      final int sev = r.ghatPct.abs() >= cfg.pct * 2 ? 2 : 1;
      out.add(Finding(
        Rule.pattern,
        sev,
        () => '$who ${r.label}: ${loss ? bi('સરેરાશ ઘટ', 'average loss') : bi('કાંટો વધારે', 'kanta higher')} ${r.ghatPct.toStringAsFixed(2)}%',
        () => '${r.mtrips.length} ${bi('ગાડી', 'trips')} · ${bi('ચિઠ્ઠી', 'Chit')} ${grp(r.matchedKg)} → ${bi('કાંટો', 'Kanta')} ${grp(r.kantaKg)} (${sk(r.ghat)} KG)',
        now,
      ));
    }
  }

  ghatPattern(Dim.majur, bi('મજૂર', 'Labour'));
  ghatPattern(Dim.vehicle, bi('ગાડી', 'Vehicle'));

  final Map<String, List<Chit>> byMajur = <String, List<Chit>>{};
  for (final Chit c in chits) {
    if (c.by.isNotEmpty && c.gross > 0) byMajur.putIfAbsent(c.by, () => <Chit>[]).add(c);
  }
  byMajur.forEach((String uid, List<Chit> l) {
    if (l.length >= 6) {
      int round = 0;
      for (final Chit c in l) {
        if (c.gross % 50 == 0) round++;
      }
      if (round / l.length >= 0.6) {
        out.add(Finding(
          Rule.pattern,
          1,
          () => '${bi('મજૂર', 'Labour')} ${majurName(names, uid)}: ${bi('ગોળ વજન વધારે', 'many round weights')}',
          () => '${bi('$round / ${l.length} ચિઠ્ઠીમાં વજન 50 ના ગુણાંકમાં', '$round of ${l.length} chits are multiples of 50 kg')}',
          now,
        ));
      }
    }
    final Map<double, int> freq = <double, int>{};
    for (final Chit c in l) {
      freq[c.gross] = (freq[c.gross] ?? 0) + 1;
    }
    freq.forEach((double w, int n) {
      if (n >= 3) {
        out.add(Finding(
          Rule.pattern,
          1,
          () => '${bi('મજૂર', 'Labour')} ${majurName(names, uid)}: ${grp(w)} KG ${bi('$n વાર', 'x$n')}',
          () => bi('એક જ વજન વારંવાર - ખરેખર તોલ્યું છે?', 'the same weight again and again - really weighed?'),
          now,
        ));
      }
    });
  });

  out.sort((Finding a, Finding b) {
    final int s = b.sev.compareTo(a.sev);
    if (s != 0) return s;
    return b.at.compareTo(a.at);
  });
  return out;
}

// ============================================================ finding identity
/// A stable key for a finding, used by "mark as checked".
String findingKey(Finding f) {
  final String r = '${f.rule.index}';
  final Trip? t = f.trip;
  if (t != null) {
    return 'T$r|${t.kanta?.id ?? ''}|${t.chits.isEmpty ? '' : t.chits.first.id}';
  }
  if (f.chit != null) return 'C$r|${f.chit!.id}';
  if (f.kanta != null) return 'K$r|${f.kanta!.id}';
  if (f.maal != null) return 'M$r|${f.maal!.id}';
  return 'X$r|${f.title()}';
}
