import 'dart:convert';

/// One finished weighing (what the slip shows). Kept on the laptop for ever by the Kanta app (so it can be printed again later).
class SlipRec {
  final String rst;
  final String vehicle;
  final String party;
  final double gross;
  final double tare;
  final DateTime grossAt;
  final DateTime tareAt;
  final DateTime at;

  /// The entry was taken back (deleted on the server) - the slip must not be used.
  bool undone;

  /// A vehicle from the road: the slip exists on the laptop only (never sent to the app / server).
  final bool outside;

  /// Charges in rupees (road vehicles; 0 = none).
  final double charges;

  /// The charges were paid in cash at the weighing (false: they are "baki" and go to the khata of the name).
  final bool paid;

  /// Who weighed it from a phone (remote weighing); empty when it was done at the laptop.
  final String by;

  /// Driver / supplier mobile, the goods and the town written at the weighing (all optional).
  final String mobile;
  final String material;
  final String city;

  SlipRec({required this.rst, required this.vehicle, required this.party, required this.gross, required this.tare, required this.grossAt, required this.tareAt, required this.at, this.undone = false, this.outside = false, this.charges = 0, this.paid = false, this.by = '', this.mobile = '', this.material = '', this.city = ''});

  double get net => gross - tare;

  Map<String, Object> toJson() => <String, Object>{
        'rst': rst,
        'v': vehicle,
        'p': party,
        'g': gross,
        't': tare,
        'ga': grossAt.millisecondsSinceEpoch,
        'ta': tareAt.millisecondsSinceEpoch,
        'at': at.millisecondsSinceEpoch,
        if (outside) 'o': 1,
        if (charges > 0) 'c': charges,
        if (paid) 'pd': 1,
        if (by.isNotEmpty) 'by': by,
        if (mobile.isNotEmpty) 'mb': mobile,
        if (material.isNotEmpty) 'mt': material,
        if (city.isNotEmpty) 'ci': city,
      };

  static SlipRec? fromJson(Object? j) {
    if (j is! Map) return null;
    try {
      final double g = (j['g'] as num).toDouble();
      final double t = (j['t'] as num).toDouble();
      return SlipRec(
        rst: '${j['rst'] ?? ''}',
        vehicle: '${j['v'] ?? ''}',
        party: '${j['p'] ?? ''}',
        gross: g,
        tare: t,
        grossAt: DateTime.fromMillisecondsSinceEpoch((j['ga'] as num).toInt()),
        tareAt: DateTime.fromMillisecondsSinceEpoch((j['ta'] as num).toInt()),
        at: DateTime.fromMillisecondsSinceEpoch((j['at'] as num).toInt()),
        outside: j['o'] == 1 || j['o'] == true,
        charges: j['c'] is num ? (j['c'] as num).toDouble() : 0,
        paid: j['pd'] == 1 || j['pd'] == true,
        by: '${j['by'] ?? ''}',
        mobile: '${j['mb'] ?? ''}',
        material: '${j['mt'] ?? ''}',
        city: '${j['ci'] ?? ''}',
      );
    } catch (_) {
      return null;
    }
  }

  String toLine() => jsonEncode(toJson());
}

String _two(int n) => n < 10 ? '0$n' : '$n';
String _hm(DateTime d) => '${_two(d.hour)}:${_two(d.minute)}';
String _dmy(DateTime d) => '${_two(d.day)}-${_two(d.month)}-${d.year}';

String _kg(double v) {
  final String t = v.round().toString();
  final StringBuffer b = StringBuffer();
  for (int i = 0; i < t.length; i++) {
    if (i > 0 && (t.length - i) % 3 == 0) b.write(',');
    b.write(t[i]);
  }
  return b.toString();
}

String _esc(String s) => s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');

/// The default second line of the slip (also the "unchanged" marker: the A5 box then shows its bilingual line).
const String kSlipSubtitle = 'WEIGHBRIDGE SLIP';
const String kSlipSignL = 'Driver sign';
const String kSlipSignR = 'Operator sign';

/// How a slip looks: the name of the weighbridge, address, phone numbers, a footer line, which lines are shown and the signature labels.
/// The defaults give exactly the slip the app always printed. Kept by the Kanta app in its settings (KantaLog.style).
class SlipStyle {
  /// First line (the name of the weighbridge / firm).
  final String title;

  /// Second line ('' = none).
  final String subtitle;

  /// Address (one or two lines - long text wraps by itself), phone number(s) and one more line (GSTIN, licence no ...). All optional.
  final String address;
  final String phone;
  final String extra;

  /// A line under the signatures ("Thank you", "No claim after the vehicle leaves" ...).
  final String footer;

  /// Signature labels; [showSign] false: no signature space at all.
  final String signL;
  final String signR;
  final bool showSign;

  /// Lines that can be left out of the print.
  final bool showMaterial;
  final bool showCity;
  final bool showMobile;
  final bool showTimes;

  /// 0: compact slip, 46 columns (small paper); 1: the format of the Matrix terminal slip, 80 columns (two columns of fields, weights in
  /// big letters) - see [slipMatrix]. The A5 box slip of the browser is the same for both.
  final int layout;

  const SlipStyle({
    this.title = 'Balaji Industries',
    this.subtitle = kSlipSubtitle,
    this.address = '',
    this.phone = '',
    this.extra = '',
    this.footer = '',
    this.signL = kSlipSignL,
    this.signR = kSlipSignR,
    this.showSign = true,
    this.showMaterial = true,
    this.showCity = true,
    this.showMobile = true,
    this.showTimes = true,
    this.layout = 0,
  });

  /// The slip of the weighbridge as the Matrix terminal printed it (the format the owner gave): name, two address lines, fields in two columns.
  static const SlipStyle shree = SlipStyle(
    title: 'SHREE BALAJI WEIGHBRIDGE',
    subtitle: '',
    address: 'MANDVI BHUJ HIGHWAY|AT MOTA ASAMBIYA MO-9537279421',
    layout: 1,
  );

  SlipStyle copyWith({String? title, String? subtitle, String? address, String? phone, String? extra, String? footer, String? signL, String? signR, bool? showSign, bool? showMaterial, bool? showCity, bool? showMobile, bool? showTimes, int? layout}) {
    return SlipStyle(
      title: title ?? this.title,
      subtitle: subtitle ?? this.subtitle,
      address: address ?? this.address,
      phone: phone ?? this.phone,
      extra: extra ?? this.extra,
      footer: footer ?? this.footer,
      signL: signL ?? this.signL,
      signR: signR ?? this.signR,
      showSign: showSign ?? this.showSign,
      showMaterial: showMaterial ?? this.showMaterial,
      showCity: showCity ?? this.showCity,
      showMobile: showMobile ?? this.showMobile,
      showTimes: showTimes ?? this.showTimes,
      layout: layout ?? this.layout,
    );
  }

  Map<String, Object> toJson() => <String, Object>{
        't': title,
        'st': subtitle,
        'ad': address,
        'ph': phone,
        'ex': extra,
        'ft': footer,
        'sl': signL,
        'sr': signR,
        'sg': showSign ? 1 : 0,
        'mt': showMaterial ? 1 : 0,
        'ci': showCity ? 1 : 0,
        'mb': showMobile ? 1 : 0,
        'tm': showTimes ? 1 : 0,
        'ly': layout,
      };

  static SlipStyle fromJson(Object? j) {
    if (j is! Map) return const SlipStyle();
    String s(String k, String d) => j[k] is String ? j[k] as String : d;
    bool b(String k) => j[k] == null ? true : (j[k] == 1 || j[k] == true);
    final String t = s('t', 'Balaji Industries').trim();
    return SlipStyle(
      title: t.isEmpty ? 'Balaji Industries' : t,
      subtitle: s('st', kSlipSubtitle),
      address: s('ad', ''),
      phone: s('ph', ''),
      extra: s('ex', ''),
      footer: s('ft', ''),
      signL: s('sl', kSlipSignL),
      signR: s('sr', kSlipSignR),
      showSign: b('sg'),
      showMaterial: b('mt'),
      showCity: b('ci'),
      showMobile: b('mb'),
      showTimes: b('tm'),
      layout: j['ly'] is num ? (j['ly'] as num).toInt().clamp(0, 1).toInt() : 0,
    );
  }

  /// The address / phone / extra lines the WhatsApp text and the A5 slip show (empty ones left out).
  List<String> get infoLines => <String>[
        if (address.trim().isNotEmpty) address.split(RegExp(r'[|\n]')).map((String a) => a.replaceAll(RegExp(r'\s+'), ' ').trim()).where((String a) => a.isNotEmpty).join(', '),
        if (phone.trim().isNotEmpty) phone.replaceAll(RegExp(r'\s+'), ' ').trim(),
        if (extra.trim().isNotEmpty) extra.replaceAll(RegExp(r'\s+'), ' ').trim(),
      ];

  /// The address as lines for the printed slip: a line change ("|" or Enter) starts a new line, a long line wraps (at most 3 lines in all).
  List<String> addressLines(int w) {
    final List<String> pieces = address.split(RegExp(r'[|\n]')).map((String a) => a.replaceAll(RegExp(r'\s+'), ' ').trim()).where((String a) => a.isNotEmpty).toList();
    final List<String> out = <String>[];
    for (final String p in pieces) {
      for (final String l in slipWrap(p, w, maxLines: pieces.length == 1 ? 2 : 1)) {
        if (out.length < 3) out.add(l);
      }
    }
    return out;
  }
}

/// How many characters wide the printed slip is (the Epson page: 46 compact, 80 Matrix).
int slipWidth(SlipStyle st) => st.layout == 1 ? 80 : 46;

/// The WhatsApp text of a slip.
String slipTextOf(SlipRec r, {String heading = 'Balaji Industries', SlipStyle? style}) {
  final SlipStyle st = style ?? SlipStyle(title: heading);
  return <String>[
    '*${st.title} - Kanta slip*',
    '${r.outside ? 'Slip' : 'RST'}: ${r.rst}',
    'Gadi: ${r.vehicle}',
    if (r.party.isNotEmpty) 'Party: ${r.party}',
    if (r.material.isNotEmpty) 'Material: ${r.material}',
    if (r.city.isNotEmpty) 'City: ${r.city}',
    if (r.mobile.isNotEmpty) 'Mobile: ${r.mobile}',
    'Gross: ${_kg(r.gross)} KG (${_hm(r.grossAt)})',
    'Tare: ${_kg(r.tare)} KG (${_hm(r.tareAt)})',
    '*Net: ${_kg(r.net)} KG*',
    if (r.charges > 0) 'Charges: Rs ${_kg(r.charges)}',
    'Date: ${_dmy(r.at)} ${_hm(r.at)}',
    ...st.infoLines,
    if (st.footer.trim().isNotEmpty) st.footer.replaceAll(RegExp(r'\s+'), ' ').trim(),
  ].join('\n');
}

/// The values that go into the {{1}} {{2}} ... of the WhatsApp slip template (the order is set on the server: secret WA_VARS).
/// Plain one-line texts - WhatsApp templates do not take new lines.
Map<String, String> slipVars(SlipRec r, {SlipStyle? style}) {
  String one(String v) => v.replaceAll(RegExp(r'\s+'), ' ').trim();
  final SlipStyle st = style ?? const SlipStyle();
  return <String, String>{
    'rst': one(r.rst),
    'vehicle': one(r.vehicle),
    'party': one(r.party),
    'material': one(r.material),
    'city': one(r.city),
    'mobile': one(r.mobile),
    'gross': _kg(r.gross),
    'tare': _kg(r.tare),
    'net': _kg(r.net),
    'charges': r.charges > 0 ? _kg(r.charges) : '',
    'day': _dmy(r.at),
    'time': _hm(r.at),
    'date': '${_dmy(r.at)} ${_hm(r.at)}',
    'kanta': one(st.title),
    'kaddress': one(st.address),
    'kphone': one(st.phone),
    'kfooter': one(st.footer),
  };
}

String _padR(String s, int n) => s.length >= n ? s : s + ' ' * (n - s.length);
String _padL(String s, int n) => s.length >= n ? s : ' ' * (n - s.length) + s;
String _center(String s, int n) => s.length >= n ? s : ' ' * ((n - s.length) ~/ 2) + s;

/// Cuts [text] into at most [maxLines] lines of [w] characters (at spaces where possible); the rest is dropped.
List<String> slipWrap(String text, int w, {int maxLines = 2}) {
  final String t = text.replaceAll(RegExp(r'\s+'), ' ').trim();
  if (t.isEmpty) return const <String>[];
  final List<String> out = <String>[];
  String rest = t;
  while (rest.isNotEmpty && out.length < maxLines) {
    if (rest.length <= w) {
      out.add(rest);
      rest = '';
      break;
    }
    int cut = rest.lastIndexOf(' ', w);
    if (cut < w ~/ 2) cut = w;
    out.add(rest.substring(0, cut).trim());
    rest = rest.substring(cut).trim();
  }
  return out;
}

/// Plain monospaced slip for a dot-matrix printer (Epson LX / LQ): English letters only, no boxes or pictures, 46 characters wide.
String slipPlain(SlipRec r, {String heading = 'Balaji Industries', SlipStyle? style}) {
  final SlipStyle st = style ?? SlipStyle(title: heading);
  if (st.layout == 1) return slipMatrix(r, st, wide: false);
  const int w = 46;
  final String line = '-' * w;
  final String gw = _padL(_kg(r.gross), 8);
  final String tw = _padL(_kg(r.tare), 8);
  final String nw = _padL(_kg(r.net), 8);
  // material and town share one line (a 3 inch slip has no room for more); the mobile only when it was written
  String mt = st.showMaterial ? r.material.trim() : '';
  String ct = st.showCity ? r.city.trim() : '';
  if (mt.isNotEmpty && ct.isNotEmpty) {
    if (mt.length > 15) mt = mt.substring(0, 15);
    if (ct.length > 14) ct = ct.substring(0, 14);
  }
  final String mtLine = mt.isNotEmpty && ct.isNotEmpty ? '${_padR('Material : $mt', 26)}City: $ct' : (mt.isNotEmpty ? 'Material : $mt' : (ct.isNotEmpty ? 'City     : $ct' : ''));
  final bool mobile = st.showMobile && r.mobile.trim().isNotEmpty;
  final bool extra = mtLine.isNotEmpty || mobile;
  final String sub = st.subtitle.trim();
  final String tm = st.showTimes ? '  ${_dmy(r.grossAt)} ${_hm(r.grossAt)}' : '';
  final String tt = st.showTimes ? '  ${_dmy(r.tareAt)} ${_hm(r.tareAt)}' : '';
  final String sl = st.signL.trim();
  final String sr = st.signR.trim();
  return <String>[
    _center(st.title.length > w ? st.title.substring(0, w).toUpperCase() : st.title.toUpperCase(), w),
    for (final String a in st.addressLines(w)) _center(a, w),
    for (final String a in slipWrap(st.phone, w, maxLines: 1)) _center(a, w),
    for (final String a in slipWrap(st.extra, w, maxLines: 1)) _center(a, w),
    if (sub.isNotEmpty) _center(sub.length > w ? sub.substring(0, w).toUpperCase() : sub.toUpperCase(), w),
    if (r.undone) _center('*** CANCELLED ***', w),
    line,
    '${_padR('${r.outside ? 'Slip No  ' : 'RST No   '}: ${r.rst}', 26)}Date: ${_dmy(r.at)}',
    '${_padR('Vehicle  : ${r.vehicle}', 26)}Time: ${_hm(r.at)}',
    if (r.party.isNotEmpty) 'Party    : ${r.party}',
    if (mtLine.isNotEmpty) mtLine,
    if (mobile) 'Mobile   : ${r.mobile.trim()}',
    line,
    'Gross Wt : $gw KG$tm',
    'Tare Wt  : $tw KG$tt',
    line,
    'NET Wt   : $nw KG',
    if (r.charges > 0) 'Charges  : Rs ${_padL(_kg(r.charges), 8)}',
    line,
    if (st.showSign) ...<String>[
      if (!extra) '',
      '',
      '${_padR(sl.length > 22 ? sl.substring(0, 22) : sl, 24)}${sr.length > 22 ? sr.substring(0, 22) : sr}',
    ],
    for (final String f in slipWrap(st.footer, w)) _center(f, w),
  ].join('\n');
}

/// The text for the Epson printer: like [slipPlain], but the Matrix layout carries the markers that switch the big letters on / off
/// (\u0001 ... \u0002 around the weights; kanta_direct.dart turns them into the printer codes).
String slipEpson(SlipRec r, {SlipStyle? style}) {
  final SlipStyle st = style ?? const SlipStyle();
  return st.layout == 1 ? slipMatrix(r, st, wide: true) : slipPlain(r, style: st);
}

String _hm12(DateTime d) {
  final int h = d.hour % 12 == 0 ? 12 : d.hour % 12;
  return '${_two(h)}:${_two(d.minute)} ${d.hour < 12 ? 'AM' : 'PM'}';
}

String _dmySlash(DateTime d) => '${_two(d.day)}/${_two(d.month)}/${d.year}';

/// The slip as the Matrix terminal printed it (80 columns, the format the owner gave):
///
///            SHREE BALAJI WEIGHBRIDGE                (big letters)
///               MANDVI BHUJ HIGHWAY
///           AT MOTA ASAMBIYA MO-9537279421
///
///   RST NO          : 115                  Vehicle No.    : GJ12BZ0238
///   MOBILE NUMBE    :                      Supplier       : ASFAK SIRVA
///   MATIRIAL        : MAGFADI              City           : MANDVI
///   ------------------------------------------------------------------------------
///   GROSS           :     5010 Kg          Date:05/10/2026   05:56 PM       (weights in big letters)
///   TARE            :     1935 Kg          Date:05/10/2026   06:44 PM
///   NET             :     3075 Kg
///   ------------------------------------------------------------------------------
///   Charges(1):Rs      50
///   ------------------------------------------------------------------------------
///   Operator Signature :
///
/// [wide]: put the big-letter markers around the weights (for the printer); without them the same text is plain (preview, browser, clipboard).
String slipMatrix(SlipRec r, SlipStyle st, {required bool wide}) {
  const int w = 80;
  const int rc = 40; // the second column starts here
  String up(String v) => v.replaceAll(RegExp(r'\s+'), ' ').trim().toUpperCase();

  String cut(String v, int n) => v.length > n ? v.substring(0, n) : v;
  // a label (15 wide), ": " and the value
  String cell(String label, String value, int width) => cut('${_padR(label, 15)}: ${value}', width);
  String two(String l1, String v1, String l2, String v2) => '${_padR(cell(l1, v1, rc - 2), rc)}${cell(l2, v2, w - rc)}'.trimRight();
  // a weight: label, ": ", the number in big letters (6 big characters = 12 columns), " Kg" - 32 columns whether the letters are big or not
  String weight(String label, double kg) {
    final String n = kg.round().toString();
    final bool big = n.length <= 6;
    final String num = _padL(n, big ? 6 : 12);
    final String body = wide && big ? '\u0001$num\u0002' : (big ? _padL(n, 12) : num);
    return '${_padR(label, 15)}: $body Kg';
  }

  // the date and time of the weighing in the second column (column 40); the weight on the left always fills 32 columns
  String withTime(String left, DateTime at) => st.showTimes ? '$left${' ' * (rc - 32)}Date:${_dmySlash(at)}   ${_hm12(at)}' : left;
  final String sub = st.subtitle.trim();
  final String sep = '-' * 78;
  final String mat = st.showMaterial ? up(r.material) : '';
  final String cty = st.showCity ? up(r.city) : '';
  final String mob = st.showMobile ? r.mobile.trim() : '';
  final List<String> head = <String>[
    for (final String a in st.addressLines(w)) _center(up(a), w),
    for (final String a in slipWrap(st.phone, w, maxLines: 1)) _center(a, w),
    for (final String a in slipWrap(st.extra, w, maxLines: 1)) _center(a, w),
    if (sub.isNotEmpty && sub != kSlipSubtitle) _center(sub.toUpperCase(), w),
  ];
  final String title = st.title.length > 40 ? st.title.substring(0, 40) : st.title;
  final String sl = st.signR.trim() == kSlipSignR || st.signR.trim().isEmpty ? 'Operator Signature' : st.signR.trim();
  return <String>[
    // for the printer the first line is the plain name: kanta_direct.dart prints it in big letters, centred
    wide ? title.toUpperCase() : _center(title.toUpperCase(), w),
    ...head,
    if (r.undone) _center('*** CANCELLED ***', w),
    '',
    two(r.outside ? 'SLIP NO' : 'RST NO', r.rst, 'Vehicle No.', r.vehicle),
    two('MOBILE NUMBE', mob, 'Supplier', up(r.party)),
    two('MATIRIAL', mat, 'City', cty),
    sep,
    withTime(weight('GROSS', r.gross), r.grossAt),
    withTime(weight('TARE', r.tare), r.tareAt),
    weight('NET', r.net),
    sep,
    if (r.charges > 0) ...<String>['Charges(1):Rs${_padL(r.charges.round().toString(), 5)}', sep],
    if (st.showSign) '$sl :',
    for (final String f in slipWrap(st.footer, w)) _center(f, w),
  ].join('\n');
}

/// A page for the printer (opens in the browser and asks to print by itself; "Save as PDF" works too).
/// [dot]: plain monospaced text for a dot-matrix printer; otherwise a boxed A5 page with Gujarati labels.
String slipHtml(SlipRec r, {String heading = 'Balaji Industries', bool dot = true, SlipStyle? style}) {
  final SlipStyle st = style ?? SlipStyle(title: heading);
  if (dot) {
    return '<!doctype html><html><head><meta charset="utf-8"><title>Kanta slip RST ${_esc(r.rst)}</title><style>'
        '@page{margin:6mm}body{margin:0}pre{font-family:"Courier New",Courier,monospace;font-size:${st.layout == 1 ? '9.5' : '13'}pt;font-weight:bold;line-height:1.3;margin:0;color:#000}'
        '</style></head><body onload="setTimeout(function(){window.print()},300)"><pre>${_esc(slipPlain(r, style: st))}</pre></body></html>';
  }
  String row(String l, String v, {String cls = ''}) => '<tr class="$cls"><td class="l">${_esc(l)}</td><td>${v}</td></tr>';
  final StringBuffer b = StringBuffer();
  b.write('<!doctype html><html><head><meta charset="utf-8"><title>Kanta slip RST ${_esc(r.rst)}</title><style>');
  b.write('@page{size:A5 landscape;margin:8mm}body{font-family:"Segoe UI",Arial,sans-serif;color:#000;margin:0}');
  b.write('.box{border:2px solid #000;padding:14px 20px}h1{font-size:24px;margin:0;text-align:center}');
  b.write('.sub{text-align:center;font-size:14px;margin:2px 0 12px}.info{text-align:center;font-size:13px;margin:2px 0}table{width:100%;border-collapse:collapse;font-size:17px}');
  b.write('td{padding:6px 4px;border-bottom:1px solid #999}td.l{width:34%;font-weight:600}');
  b.write('tr.net td{font-size:24px;font-weight:800;border-top:2px solid #000;border-bottom:2px solid #000}');
  b.write('.void{color:#b00020;font-weight:800;text-align:center;font-size:20px;margin:8px 0}');
  b.write('.sig{display:flex;justify-content:space-between;margin-top:36px;font-size:13px}.sig div{border-top:1px solid #000;padding-top:4px;min-width:160px;text-align:center}');
  b.write('.foot{text-align:center;font-size:13px;margin-top:10px}');
  b.write('</style></head><body onload="setTimeout(function(){window.print()},300)"><div class="box">');
  b.write('<h1>${_esc(st.title)}</h1>');
  for (final String a in st.infoLines) {
    b.write('<div class="info">${_esc(a)}</div>');
  }
  final String sub = st.subtitle.trim() == kSlipSubtitle ? 'Weighbridge slip / કાંટા ચિઠ્ઠી' : st.subtitle.trim();
  b.write('<div class="sub">${_esc(sub)}</div>');
  if (r.undone) b.write('<div class="void">CANCELLED / રદ</div>');
  b.write('<table>');
  b.write(row(r.outside ? 'Slip No' : 'RST No', '<b>${_esc(r.rst)}</b>'));
  b.write(row('Date / તારીખ', '${_dmy(r.at)} &nbsp; ${_hm(r.at)}'));
  b.write(row('Vehicle / ગાડી નં', '<b>${_esc(r.vehicle)}</b>'));
  if (r.party.isNotEmpty) b.write(row('Party / પાર્ટી', _esc(r.party)));
  if (st.showMaterial && r.material.isNotEmpty) b.write(row('Material / માલ', _esc(r.material)));
  if (st.showCity && r.city.isNotEmpty) b.write(row('City / ગામ-શહેર', _esc(r.city)));
  if (st.showMobile && r.mobile.isNotEmpty) b.write(row('Mobile / મોબાઇલ', _esc(r.mobile)));
  b.write(row('Gross / ગ્રોસ', '${_kg(r.gross)} KG${st.showTimes ? ' &nbsp; <small>${_dmy(r.grossAt)} ${_hm(r.grossAt)}</small>' : ''}'));
  b.write(row('Tare / ટેર', '${_kg(r.tare)} KG${st.showTimes ? ' &nbsp; <small>${_dmy(r.tareAt)} ${_hm(r.tareAt)}</small>' : ''}'));
  b.write(row('Net / ચોખ્ખું', '${_kg(r.net)} KG', cls: 'net'));
  if (r.charges > 0) b.write(row('Charges / ભાડું', 'Rs ${_kg(r.charges)}'));
  b.write('</table>');
  if (st.showSign) {
    final String l = st.signL.trim() == kSlipSignL ? 'Driver' : st.signL.trim();
    final String rr = st.signR.trim() == kSlipSignR ? 'Weighbridge operator' : st.signR.trim();
    b.write('<div class="sig"><div>${_esc(l)}</div><div>${_esc(rr)}</div></div>');
  }
  if (st.footer.trim().isNotEmpty) b.write('<div class="foot">${_esc(st.footer.replaceAll(RegExp(r'\s+'), ' ').trim())}</div>');
  b.write('</div></body></html>');
  return b.toString();
}
