import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';

/// Error from the Supabase backend. [network] is true when the phone could not
/// reach the server at all (no internet) - such saves are queued and retried.
class SupaError implements Exception {
  final String message;
  final int status;
  final bool network;
  final String code;
  const SupaError(this.message, {this.status = 0, this.network = false, this.code = ''});

  @override
  String toString() => message;
}

class _Resp {
  final int status;
  final String body;
  final HttpHeaders headers;
  _Resp(this.status, this.body, this.headers);

  bool get ok => status >= 200 && status < 300;

  dynamic json() {
    if (body.trim().isEmpty) return null;
    try {
      return jsonDecode(body);
    } catch (_) {
      return null;
    }
  }
}

String digitsOf(String s) => s.replaceAll(RegExp(r'[^0-9]'), '');

/// Thin Supabase client (Auth + PostgREST + Storage) over dart:io.
class Supa {
  static const String url = 'https://tiugeimmfevelnuddhbr.supabase.co';
  static const String key = 'sb_publishable_vFtxD2etw0CsoEPA2ouIFQ_PhO_s8qU';
  static const String sheetUrl =
      'https://script.google.com/macros/s/AKfycby6i7QPgsQojqB7qJr5kZe8KQB0yHkqh69aldpHEKGzS-gAerQZqceqdLV26jevpbJNvA/exec';

  String? access;
  String? refresh;
  DateTime? expires;
  String uid = '';
  VoidCallback? onExpired;
  VoidCallback? onSession;

  final HttpClient _http = HttpClient()..connectionTimeout = const Duration(seconds: 15);
  Future<bool>? _refreshing;

  static String emailOf(String mobile) => 'u${digitsOf(mobile)}@users.balajiindustries.app';

  bool get hasSession => access != null;

  // ------------------------------------------------------------- transport
  Future<_Resp> _send(
    String method,
    Uri uri, {
    Object? body,
    Map<String, String>? headers,
    List<int>? bytes,
    bool auth = true,
    bool follow = true,
    Duration wait = const Duration(seconds: 45),
  }) async {
    try {
      final HttpClientRequest req = await _http.openUrl(method, uri).timeout(const Duration(seconds: 20));
      req.followRedirects = follow;
      req.headers.set('apikey', key);
      if (auth && access != null) req.headers.set('Authorization', 'Bearer $access');
      if (headers != null) {
        headers.forEach((String k, String v) => req.headers.set(k, v));
      }
      if (bytes != null) {
        req.add(bytes);
      } else if (body != null) {
        req.headers.set('Content-Type', 'application/json');
        req.add(utf8.encode(jsonEncode(body)));
      }
      final HttpClientResponse res = await req.close().timeout(wait);
      final Uint8List data = await consolidateHttpClientResponseBytes(res).timeout(wait + const Duration(seconds: 15));
      return _Resp(res.statusCode, utf8.decode(data, allowMalformed: true), res.headers);
    } on SocketException catch (e) {
      throw SupaError('Internet નથી (${e.message})', network: true);
    } on TimeoutException {
      throw const SupaError('Internet ધીમું છે - સમય પૂરો', network: true);
    } on HandshakeException {
      throw const SupaError('સુરક્ષિત કનેક્શન બન્યું નહીં', network: true);
    } on HttpException catch (e) {
      throw SupaError('કનેક્શન ભૂલ: ${e.message}', network: true);
    }
  }

  SupaError _err(_Resp r) {
    String msg = 'Error ${r.status}';
    String code = '';
    final dynamic j = r.json();
    if (j is Map) {
      final Object? m = j['message'] ?? j['msg'] ?? j['error_description'] ?? j['error'];
      if (m != null) msg = '$m';
      final Object? c = j['code'] ?? j['error_code'];
      if (c != null) code = '$c';
    } else if (r.body.isNotEmpty && r.body.length < 200) {
      msg = r.body;
    }
    return SupaError(msg, status: r.status, code: code);
  }

  // ------------------------------------------------------------------ auth
  void _apply(Map<dynamic, dynamic> m) {
    access = m['access_token'] as String?;
    refresh = m['refresh_token'] as String?;
    final num? exp = m['expires_in'] as num?;
    expires = DateTime.now().add(Duration(seconds: exp == null ? 3600 : exp.toInt()));
    final Object? u = m['user'];
    if (u is Map && u['id'] != null) uid = '${u['id']}';
    final VoidCallback? cb = onSession;
    if (cb != null) cb();
  }

  Future<void> signIn(String mobile, String password) async {
    final _Resp r = await _send(
      'POST',
      Uri.parse('$url/auth/v1/token?grant_type=password'),
      body: <String, String>{'email': emailOf(mobile), 'password': password},
      auth: false,
    );
    final dynamic j = r.json();
    if (!r.ok || j is! Map) {
      final SupaError e = _err(r);
      final String m = e.message.toLowerCase();
      if (m.contains('invalid login') || m.contains('invalid_credentials')) {
        throw SupaError('મોબાઇલ અથવા પાસવર્ડ ખોટો છે', status: e.status, code: e.code);
      }
      throw e;
    }
    _apply(j);
  }

  /// Restores a saved session from its refresh token.
  Future<bool> restore(String refreshToken) async {
    refresh = refreshToken;
    return refreshSession();
  }

  Future<bool> refreshSession() {
    final Future<bool>? busy = _refreshing;
    if (busy != null) return busy;
    final Future<bool> f = _doRefresh();
    _refreshing = f;
    f.whenComplete(() => _refreshing = null);
    return f;
  }

  Future<bool> _doRefresh() async {
    final String? rt = refresh;
    if (rt == null) return false;
    final _Resp r = await _send(
      'POST',
      Uri.parse('$url/auth/v1/token?grant_type=refresh_token'),
      body: <String, String>{'refresh_token': rt},
      auth: false,
    );
    final dynamic j = r.json();
    if (r.ok && j is Map) {
      _odd4xx = 0;
      _apply(j);
      return true;
    }
    if (r.status >= 500 || r.status == 429 || r.status == 408) {
      // server busy / down: treated like "no internet" so nobody is logged out for it
      throw SupaError('સર્વર હમણાં જવાબ આપતું નથી (${r.status})', status: r.status, network: true);
    }
    if (r.status >= 400 && r.status < 500) {
      // Only an answer that says "this login is dead" logs the person out at once. Any other odd 4xx (a gateway hiccup, a proxy) is
      // treated like "no internet" for the first few times - nobody is thrown to the login screen for a hiccup.
      if (_refreshDead(r) || ++_odd4xx >= 3) {
        _odd4xx = 0;
        access = null;
        refresh = null;
        final VoidCallback? cb = onExpired;
        if (cb != null) cb();
        return false;
      }
      throw SupaError('લૉગિન તપાસ હમણાં ન થઈ (${r.status})', status: r.status, network: true);
    }
    return false;
  }

  int _odd4xx = 0;

  /// True when Supabase says the saved login (refresh token / session) is finished for good.
  bool _refreshDead(_Resp r) {
    final String t = '${r.body}'.toLowerCase();
    for (final String k in <String>[
      'refresh_token_not_found',
      'refresh_token_already_used',
      'invalid refresh token',
      'refresh token not found',
      'already used',
      'session_not_found',
      'session_expired',
      'invalid_grant',
      'user_not_found',
      'user_banned',
    ]) {
      if (t.contains(k)) return true;
    }
    return false;
  }

  Future<void> _fresh() async {
    final DateTime? e = expires;
    if (access == null || e == null) return;
    if (DateTime.now().isAfter(e.subtract(const Duration(seconds: 60)))) {
      await refreshSession();
    }
  }

  void clear() {
    access = null;
    refresh = null;
    expires = null;
    uid = '';
  }

  Future<_Resp> _authed(
    String method,
    Uri uri, {
    Object? body,
    Map<String, String>? headers,
    List<int>? bytes,
    Duration wait = const Duration(seconds: 45),
  }) async {
    await _fresh();
    _Resp r = await _send(method, uri, body: body, headers: headers, bytes: bytes, wait: wait);
    if (r.status == 401 && refresh != null) {
      if (await refreshSession()) {
        r = await _send(method, uri, body: body, headers: headers, bytes: bytes, wait: wait);
      }
    }
    return r;
  }

  // ------------------------------------------------------------------ rest
  Uri _rest(String table, Map<String, String> q) {
    return Uri.parse('$url/rest/v1/$table').replace(queryParameters: q);
  }

  List<Map<String, dynamic>> _rows(_Resp r) {
    final dynamic j = r.json();
    if (j is! List) return <Map<String, dynamic>>[];
    final List<Map<String, dynamic>> out = <Map<String, dynamic>>[];
    for (final dynamic e in j) {
      if (e is Map) out.add(Map<String, dynamic>.from(e));
    }
    return out;
  }

  Future<List<Map<String, dynamic>>> select(String table, Map<String, String> q, {int offset = 0, int limit = 1000}) async {
    final Map<String, String> p = <String, String>{...q, 'limit': '$limit', 'offset': '$offset'};
    final _Resp r = await _authed('GET', _rest(table, p));
    if (!r.ok) throw _err(r);
    return _rows(r);
  }

  /// Reads every page (1000 rows each) up to [maxRows].
  Future<List<Map<String, dynamic>>> selectAll(String table, Map<String, String> q, {int maxRows = 30000}) async {
    final List<Map<String, dynamic>> all = <Map<String, dynamic>>[];
    int off = 0;
    while (off < maxRows) {
      final List<Map<String, dynamic>> page = await select(table, q, offset: off, limit: 1000);
      all.addAll(page);
      if (page.length < 1000) break;
      off += 1000;
    }
    return all;
  }

  Future<Map<String, dynamic>> insert(String table, Map<String, dynamic> row) async {
    final _Resp r = await _authed(
      'POST',
      _rest(table, <String, String>{}),
      body: row,
      headers: <String, String>{'Prefer': 'return=representation'},
    );
    if (!r.ok) throw _err(r);
    final List<Map<String, dynamic>> l = _rows(r);
    return l.isEmpty ? <String, dynamic>{} : l.first;
  }

  Future<Map<String, dynamic>> upsert(String table, Map<String, dynamic> row, String conflict) async {
    final _Resp r = await _authed(
      'POST',
      _rest(table, <String, String>{'on_conflict': conflict}),
      body: row,
      headers: <String, String>{'Prefer': 'resolution=merge-duplicates,return=representation'},
    );
    if (!r.ok) throw _err(r);
    final List<Map<String, dynamic>> l = _rows(r);
    return l.isEmpty ? <String, dynamic>{} : l.first;
  }

  Future<List<Map<String, dynamic>>> update(String table, Map<String, String> filter, Map<String, dynamic> patch) async {
    final _Resp r = await _authed(
      'PATCH',
      _rest(table, filter),
      body: patch,
      headers: <String, String>{'Prefer': 'return=representation'},
    );
    if (!r.ok) throw _err(r);
    return _rows(r);
  }

  /// Deletes the rows matching [filter]; returns the rows that were removed.
  Future<List<Map<String, dynamic>>> delete(String table, Map<String, String> filter) async {
    final _Resp r = await _authed(
      'DELETE',
      _rest(table, filter),
      headers: <String, String>{'Prefer': 'return=representation'},
    );
    if (!r.ok) throw _err(r);
    return _rows(r);
  }

  Future<dynamic> rpc(String fn, Map<String, dynamic> args) async {
    final _Resp r = await _authed('POST', Uri.parse('$url/rest/v1/rpc/$fn'), body: args);
    if (!r.ok) throw _err(r);
    return r.json();
  }

  // --------------------------------------------------------------- storage
  String publicUrl(String bucket, String path) {
    final String p = path.split('/').map(Uri.encodeComponent).join('/');
    return '$url/storage/v1/object/public/${Uri.encodeComponent(bucket)}/$p';
  }

  Future<String> uploadPhoto(String bucket, String path, List<int> bytes) async {
    final String p = path.split('/').map(Uri.encodeComponent).join('/');
    final Uri u = Uri.parse('$url/storage/v1/object/${Uri.encodeComponent(bucket)}/$p');
    final _Resp r = await _authed(
      'POST',
      u,
      bytes: bytes,
      headers: <String, String>{'Content-Type': 'image/jpeg', 'Cache-Control': 'max-age=3600', 'x-upsert': 'false'},
    );
    if (!r.ok) throw _err(r);
    return publicUrl(bucket, path);
  }

  // ------------------------------------------------------------- slip scan
  /// Sends a slip photo to the same `scan-entry` function the web app uses.
  /// [kind] is worker | waybridge | maal_entry. The server may take ~2 minutes.
  Future<Map<String, dynamic>> scanEntry(String kind, List<int> jpeg) async {
    final Map<String, dynamic> body = <String, dynamic>{
      'kind': kind,
      'target': 'gu',
      'mimeType': 'image/jpeg',
      'image': base64Encode(jpeg),
    };
    final _Resp r = await _authed(
      'POST',
      Uri.parse('$url/functions/v1/scan-entry'),
      body: body,
      wait: const Duration(seconds: 135),
    );
    final dynamic j = r.json();
    if (!r.ok) {
      String m = 'Scan ભૂલ (${r.status})';
      if (j is Map && j['error'] != null) m = '${j['error']}';
      if (r.status == 404) m = 'Scan સેવા ચાલુ નથી (scan-entry deploy કરવું પડશે)';
      throw SupaError(m, status: r.status);
    }
    if (j is! Map) throw const SupaError('Scan નો જવાબ સમજાયો નહીં');
    return Map<String, dynamic>.from(j);
  }

  // ------------------------------------------------------------ WhatsApp
  /// The `send-whatsapp` function (WhatsApp Business Platform): body {to, params} sends the slip template, {test: true} only checks the set-up.
  /// Returns the function's answer {ok, id | error, configured ...}; throws only when the function cannot be reached.
  Future<Map<String, dynamic>> sendWhatsApp(Map<String, dynamic> body) async {
    final _Resp r = await _authed('POST', Uri.parse('$url/functions/v1/send-whatsapp'), body: body, wait: const Duration(seconds: 30));
    if (r.status == 404) throw const SupaError('send-whatsapp is not deployed in Supabase yet', status: 404);
    return waAnswer(r.status, r.json());
  }

  /// What the `send-whatsapp` function (or the platform in front of it) answered, as {ok, kind, error ...}.
  /// An answer of the platform itself (login expired, not allowed, server trouble): 403 = this login may not send, the rest is worth a retry.
  static Map<String, dynamic> waAnswer(int status, dynamic j) {
    final bool good = status >= 200 && status < 300;
    if (j is Map) {
      final Map<String, dynamic> m = Map<String, dynamic>.from(j);
      if (!good) {
        m['ok'] = false;
        m['kind'] ??= status == 403 ? 'setup' : 'retry';
        m['error'] ??= m['message'] ?? 'WhatsApp HTTP $status';
      }
      return m;
    }
    if (good) throw SupaError('WhatsApp answer not understood ($status)', status: status);
    return <String, dynamic>{'ok': false, 'kind': status == 403 ? 'setup' : 'retry', 'error': 'WhatsApp HTTP $status'};
  }

  // ------------------------------------------------------------ diagnostics
  /// How fast the server answers and whether the `scan-entry` function exists.
  /// Keys: restOk(bool) restMs(int) restMsg(String) scan(String: ok|missing|error) scanMs(int)
  Future<Map<String, Object>> health() async {
    final Map<String, Object> out = <String, Object>{};
    final Stopwatch w = Stopwatch()..start();
    try {
      final _Resp r = await _authed('GET', _rest('app_settings', <String, String>{'select': 'key', 'limit': '1'}));
      out['restOk'] = r.ok;
      out['restMsg'] = r.ok ? 'OK' : 'Error ${r.status}';
    } on SupaError catch (e) {
      out['restOk'] = false;
      out['restMsg'] = e.message;
    }
    out['restMs'] = w.elapsedMilliseconds;
    w
      ..reset()
      ..start();
    try {
      final _Resp r = await _authed(
        'POST',
        Uri.parse('$url/functions/v1/scan-entry'),
        body: <String, dynamic>{'kind': 'worker'},
        wait: const Duration(seconds: 20),
      );
      out['scan'] = r.status == 404 ? 'missing' : (r.status >= 500 ? 'error' : 'ok');
    } on SupaError catch (_) {
      out['scan'] = 'error';
    }
    out['scanMs'] = w.elapsedMilliseconds;
    return out;
  }

  // ----------------------------------------------------- best-effort extras
  /// Same admin push notification the web app sends. Never throws.
  Future<void> notifyAdmin(String type, String title, String body) async {
    try {
      await _authed(
        'POST',
        Uri.parse('$url/functions/v1/send-push-notification'),
        body: <String, String>{'type': type, 'title': title, 'body': body},
      );
    } catch (_) {}
  }

  /// Posts a row to the Google Sheet and says whether the Sheet took it (any answer of the script - it answers with a redirect or a page;
  /// false when there was no internet / no answer). Throws nothing.
  Future<bool> sheetTry(Map<String, dynamic> data) async {
    try {
      final _Resp r = await _send(
        'POST',
        Uri.parse(sheetUrl),
        bytes: utf8.encode(jsonEncode(data)),
        headers: <String, String>{'Content-Type': 'text/plain;charset=utf-8'},
        auth: false,
        follow: false,
        wait: const Duration(seconds: 30),
      );
      return r.status > 0 && r.status < 400;
    } catch (_) {
      return false;
    }
  }

  /// Same Google Sheet backup row the web app writes. Never throws.
  Future<void> sheet(Map<String, dynamic> data) async {
    try {
      await _send(
        'POST',
        Uri.parse(sheetUrl),
        bytes: utf8.encode(jsonEncode(data)),
        headers: <String, String>{'Content-Type': 'text/plain;charset=utf-8'},
        auth: false,
        follow: false,
      );
    } catch (_) {}
  }
}
