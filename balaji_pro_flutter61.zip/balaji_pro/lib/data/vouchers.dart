import '../core/fmt.dart';
import '../core/i18n.dart';
import 'contra.dart';
import 'gst.dart' show gstInvoices, GstInv;
import 'insights.dart';
import 'live_models.dart';
import 'live_store.dart';
import 'money.dart';
import 'trade.dart';
import 'vno.dart' show payCode, saleCode;

// ======================================================================
// Vouchers, the TallyPrime way
//   One list of every voucher of the business (purchase chits, payments, receipts, sales, journals,
//   expenses and income) with a voucher type, a voucher number and the debit / credit it makes in the
//   ledger of its party. Day Book, ledgers and the trial balance are all worked out from it.
// ======================================================================

class VType {
  final String code;
  final String letter;
  final String gu;
  final String en;
  final String full; // name on the printed voucher
  const VType(this.code, this.letter, this.gu, this.en, this.full);
  String get name => bi(gu, en);
}

const List<VType> kVTypes = <VType>[
  VType('PUR', 'C', 'ખરીદ', 'Purchase', 'Purchase Voucher'),
  VType('PAY', 'P', 'ચૂકવણી', 'Payment', 'Payment Voucher'),
  VType('RCT', 'R', 'રસીદ', 'Receipt', 'Receipt Voucher'),
  VType('SAL', 'S', 'વેચાણ', 'Sales', 'Sales Voucher'),
  VType('JRN', 'J', 'જર્નલ', 'Journal', 'Journal Voucher'),
  VType('EXP', 'E', 'ખર્ચ', 'Expense', 'Expense Voucher'),
  VType('INC', 'I', 'આવક', 'Income', 'Income Voucher'),
  VType('CON', 'T', 'કોન્ટ્રા', 'Contra', 'Contra Voucher'),
  VType('CNT', 'N', 'ક્રેડિટ નોટ', 'Credit Note', 'Credit Note'),
  VType('DNT', 'D', 'ડેબિટ નોટ', 'Debit Note', 'Debit Note'),
];

VType vTypeOf(String code) {
  for (final VType t in kVTypes) {
    if (t.code == code) return t;
  }
  return kVTypes[1];
}

/// "Day Book" for all vouchers, "Payment Register", "Sales Register" ... for one voucher type (the TallyPrime register names).
String registerName(String code) {
  if (code.isEmpty) return bi('ડે બુક', 'Day Book');
  final VType t = vTypeOf(code);
  return bi('${t.gu} રજિસ્ટર', '${t.en} Register');
}

class Vch {
  final String id; // id of the entry ('' for a chit)
  final String src; // pay | sale | exp | chit | contra
  final String type; // PUR PAY RCT SAL JRN EXP INC CON
  final int no;
  final String chitNo;
  final DateTime date;
  final DateTime at;
  final String party; // the Particulars of the Day Book
  final String partyKey;
  final String dim; // farmer | buyer | head | contra
  final double dr; // debit made in the ledger of the party
  final double cr; // credit made in the ledger of the party
  final String contra; // the other side: Cash, Bank, Sales ...
  final String mode;
  final String ref;
  final String note;
  final String kind; // the kind code stored in the entry
  final bool noRate;
  final Object? raw;

  /// GST kept inside the amount of a sale written from a GST bill (Duties & Taxes, not income).
  final double tax;
  const Vch({
    required this.id,
    required this.src,
    required this.type,
    required this.no,
    required this.date,
    required this.at,
    required this.party,
    required this.partyKey,
    required this.dim,
    required this.dr,
    required this.cr,
    required this.contra,
    this.chitNo = '',
    this.mode = '',
    this.ref = '',
    this.note = '',
    this.kind = '',
    this.noRate = false,
    this.raw,
    this.tax = 0,
  });

  VType get vt => vTypeOf(type);
  double get amt => dr > 0 ? dr : cr;

  /// The Vch No. column: the number of the voucher ('' while it has none yet)
  String get number => src == 'chit' ? chitNo : (no > 0 ? '$no' : '');
}

String _contraOf(String mode) => payModeLabel(mode);

/// GST of every tax bill: key "buyer|bill no" -> tax. A sale written from a GST bill carries the same bill number.
Map<String, double> _gstTaxByBill() {
  final Map<String, double> m = <String, double>{};
  for (final GstInv i in gstInvoices()) {
    if (i.cancelled || !i.isTax) continue;
    final double t = i.calc.tax;
    if (t <= 0) continue;
    m['${nameKey(i.party)}|${i.no}'] = t;
  }
  return m;
}

/// Every voucher, oldest first (date, then time of entry).
List<Vch> allVouchers({bool chits = true}) {
  final List<Vch> out = <Vch>[];
  for (final PayItem p in payItems()) {
    final bool paid = p.kind == 'pay' || p.kind == 'adv';
    final String type = payCode(p.kind, jt: p.jt);
    double dr = 0;
    double cr = 0;
    if (paid) {
      dr = p.amt;
    } else if (p.kind == 'recv') {
      cr = p.amt;
    } else if (p.amt >= 0) {
      cr = p.amt;
    } else {
      dr = -p.amt;
    }
    out.add(Vch(
      id: p.id,
      src: 'pay',
      type: type,
      no: p.no,
      date: p.date,
      at: p.at,
      party: p.label,
      partyKey: p.key,
      dim: 'farmer',
      dr: dr,
      cr: cr,
      contra: type == 'DNT' ? bi('ખરીદ પરત', 'Purchase Returns') : (type == 'JRN' ? bi('જર્નલ', 'Journal') : _contraOf(p.mode)),
      mode: p.mode,
      ref: p.ref,
      note: p.note,
      kind: p.kind,
      raw: p,
    ));
  }
  final List<SaleItem> sales = saleItems();
  Map<String, double>? gstMap;
  for (final SaleItem s in sales) {
    final String type = saleCode(s.kind, jt: s.jt);
    double tax = 0;
    if (s.kind == 'sale' && s.bill.isNotEmpty) {
      gstMap ??= _gstTaxByBill();
      tax = gstMap['${s.key}|${s.bill}'] ?? 0;
      if (tax > s.amt) tax = s.amt > 0 ? s.amt : 0;
    }
    double dr = 0;
    double cr = 0;
    if (s.kind == 'sale') {
      dr = s.amt;
    } else if (s.kind == 'recv') {
      cr = s.amt;
    } else if (s.amt >= 0) {
      dr = s.amt;
    } else {
      cr = -s.amt;
    }
    out.add(Vch(
      id: s.id,
      src: 'sale',
      type: type,
      no: s.no,
      date: s.date,
      at: s.at,
      party: s.buyer,
      partyKey: s.key,
      dim: 'buyer',
      dr: dr,
      cr: cr,
      contra: type == 'SAL' ? bi('વેચાણ', 'Sales') : (type == 'RCT' ? _contraOf(s.mode) : (type == 'CNT' ? bi('વેચાણ પરત', 'Sales Returns') : bi('જર્નલ', 'Journal'))),
      mode: s.mode,
      ref: s.ref,
      note: s.note,
      kind: s.kind,
      raw: s,
      tax: tax,
    ));
  }
  for (final ExpItem e in expItems()) {
    final bool inn = e.isIn;
    out.add(Vch(
      id: e.id,
      src: 'exp',
      type: inn ? 'INC' : 'EXP',
      no: e.no,
      date: e.date,
      at: e.at,
      party: expCatLabel(e.cat),
      partyKey: e.cat,
      dim: 'head',
      dr: inn ? 0 : e.amt,
      cr: inn ? e.amt : 0,
      contra: _contraOf(e.mode),
      mode: e.mode,
      ref: e.ref,
      note: e.note,
      kind: e.kind,
      raw: e,
    ));
  }
  // contra: the particulars is the account that is debited, the "against" is the account that is credited
  for (final ContraItem c in contraItems()) {
    out.add(Vch(
      id: c.id,
      src: 'contra',
      type: 'CON',
      no: c.no,
      date: c.date,
      at: c.at,
      party: c.dep ? contraBankName() : contraCashName(),
      partyKey: '',
      dim: 'contra',
      dr: c.amt,
      cr: 0,
      contra: c.dep ? contraCashName() : contraBankName(),
      ref: c.ref,
      note: c.note,
      kind: c.dep ? 'dep' : 'wd',
      raw: c,
    ));
  }
  if (chits) {
    for (final Chit c in live.chits) {
      final double? amt = chitAmount(c);
      out.add(Vch(
        id: c.id,
        src: 'chit',
        type: 'PUR',
        no: 0,
        chitNo: c.no,
        date: dayOf(c.at),
        at: c.at,
        party: c.farmer,
        partyKey: nameKey(c.farmer),
        dim: 'farmer',
        dr: 0,
        cr: amt ?? 0,
        contra: bi('ખરીદ', 'Purchase'),
        note: '${c.commodity} · ${grp(payKg(c))} KG',
        noRate: amt == null,
        raw: c,
      ));
    }
  }
  out.sort((Vch a, Vch b) {
    final int c = a.date.compareTo(b.date);
    return c != 0 ? c : a.at.compareTo(b.at);
  });
  return out;
}

/// Duties & Taxes (GST) of a period: the tax collected in sales (credit) against the GST paid to the Government (debit).
class GstDuty {
  double opening = 0; // credit positive: still to be paid on the first day
  double collected = 0;
  double paid = 0;
  double get closing => opening + collected - paid;
}

GstDuty gstDuty(Period p) {
  final GstDuty d = GstDuty();
  for (final Vch v in allVouchers(chits: false)) {
    double c = 0;
    double pd = 0;
    if (v.type == 'SAL' && v.tax > 0) {
      c = v.tax;
    } else if (v.type == 'EXP' && v.partyKey == kGstHead) {
      pd = v.dr;
    } else {
      continue;
    }
    if (v.date.isBefore(p.from)) {
      d.opening += c - pd;
    } else if (v.date.isBefore(p.to)) {
      d.collected += c;
      d.paid += pd;
    }
  }
  return d;
}

/// The vouchers that make up the ledger of one farmer / buyer (same counting as the farmer and buyer ledgers).
List<Vch> ledgerVouchers(String dim, String key) {
  final DateTime from = khataFrom();
  final List<Vch> out = <Vch>[];
  for (final Vch v in allVouchers()) {
    if (v.dim != dim || v.partyKey != key) continue;
    if (!inLedger(v, from)) continue;
    out.add(v);
  }
  return out;
}

/// Whether a voucher counts in the ledger (farmer ledgers count from the "ledger starts" day, as the farmer screens do).
bool inLedger(Vch v, DateTime khataStart) {
  if (v.dim == 'farmer') {
    if (v.src == 'chit' && v.date.isBefore(khataStart)) return false;
    if (v.src == 'pay' && v.kind != 'open' && v.date.isBefore(khataStart)) return false;
  }
  return true;
}

// ------------------------------------------------------------ amount in words
const List<String> _ones = <String>[
  '', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen', //
];
const List<String> _tens = <String>['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

String _two(int n) {
  if (n < 20) return _ones[n];
  final int u = n % 10;
  return u == 0 ? _tens[n ~/ 10] : '${_tens[n ~/ 10]} ${_ones[u]}';
}

String _three(int n) {
  final int h = n ~/ 100;
  final int r = n % 100;
  final String a = h > 0 ? '${_ones[h]} Hundred' : '';
  final String b = r > 0 ? _two(r) : '';
  if (a.isEmpty) return b;
  return b.isEmpty ? a : '$a $b';
}

String _words(int n) {
  if (n <= 0) return 'Zero';
  int x = n;
  final List<String> parts = <String>[];
  final int cr = x ~/ 10000000;
  x = x % 10000000;
  final int lk = x ~/ 100000;
  x = x % 100000;
  final int th = x ~/ 1000;
  x = x % 1000;
  if (cr > 0) parts.add('${_words(cr)} Crore');
  if (lk > 0) parts.add('${_two(lk)} Lakh');
  if (th > 0) parts.add('${_two(th)} Thousand');
  if (x > 0) parts.add(_three(x));
  return parts.join(' ');
}

/// "Rupees Twenty Five Thousand Only" (Indian lakh / crore words)
String amountInWords(double amt) {
  final double a = amt.abs();
  int rupees = a.floor();
  int paise = ((a - rupees) * 100).round();
  if (paise >= 100) {
    rupees += 1;
    paise = 0;
  }
  final String p = paise > 0 ? ' and ${_two(paise)} Paise' : '';
  return 'Rupees ${_words(rupees)}$p Only';
}

// ------------------------------------------------------------------- printing
String htmlEsc(String s) => s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');

const String _css = '''
body{font-family:"Segoe UI","Nirmala UI","Shruti",Arial,sans-serif;font-size:12px;color:#111;margin:18px}
h1{font-size:18px;margin:0;text-align:center}
h2{font-size:14px;margin:2px 0;text-align:center;font-weight:600}
.sub{text-align:center;color:#444;margin-bottom:10px}
table{border-collapse:collapse;width:100%}
th{border-top:1px solid #000;border-bottom:1px solid #000;padding:4px 6px;text-align:left;font-weight:700}
td{padding:3px 6px;border-bottom:1px solid #ddd;vertical-align:top}
.r{text-align:right;white-space:nowrap}
.b td{font-weight:700}
.t td{font-weight:700;border-top:1px solid #000;border-bottom:2px solid #000}
.sig{display:flex;justify-content:space-between;margin-top:60px}
.sig div{border-top:1px solid #000;padding-top:4px;min-width:130px;text-align:center}
@media print{body{margin:8mm}}
''';

/// A report in the TallyPrime layout: company, report name, period, a table, an optional total line.
/// [bold] holds the indexes of rows that are written in bold.
String reportHtml({
  required String title,
  required String period,
  required List<String> heads,
  required List<bool> right,
  required List<List<String>> rows,
  List<String>? total,
  Set<int> bold = const <int>{},
}) {
  final StringBuffer b = StringBuffer();
  b.write('<!doctype html><html><head><meta charset="utf-8"><title>${htmlEsc(title)}</title><style>$_css</style></head><body>');
  b.write('<h1>Balaji Industries</h1><h2>${htmlEsc(title)}</h2><div class="sub">${htmlEsc(period)}</div><table><tr>');
  for (int i = 0; i < heads.length; i++) {
    b.write('<th${right[i] ? ' class="r"' : ''}>${htmlEsc(heads[i])}</th>');
  }
  b.write('</tr>');
  for (int k = 0; k < rows.length; k++) {
    b.write(bold.contains(k) ? '<tr class="b">' : '<tr>');
    for (int i = 0; i < heads.length && i < rows[k].length; i++) {
      b.write('<td${right[i] ? ' class="r"' : ''}>${htmlEsc(rows[k][i])}</td>');
    }
    b.write('</tr>');
  }
  if (total != null) {
    b.write('<tr class="t">');
    for (int i = 0; i < heads.length && i < total.length; i++) {
      b.write('<td${right[i] ? ' class="r"' : ''}>${htmlEsc(total[i])}</td>');
    }
    b.write('</tr>');
  }
  b.write('</table><script>window.onload=function(){window.print();}</script></body></html>');
  return b.toString();
}

/// One voucher on paper, like the voucher print of TallyPrime.
String voucherHtml(Vch v, {String curBal = ''}) {
  final StringBuffer b = StringBuffer();
  final String head = v.vt.full;
  b.write('<!doctype html><html><head><meta charset="utf-8"><title>${htmlEsc(head)}</title><style>$_css</style></head><body>');
  b.write('<h1>Balaji Industries</h1><h2>${htmlEsc(head)}</h2>');
  b.write('<table style="margin-top:12px"><tr><td style="border:0"><b>No. :</b> ${htmlEsc(v.src == 'chit' ? v.chitNo : (v.no > 0 ? '${v.vt.letter}-${v.no}' : ''))}</td>');
  b.write('<td class="r" style="border:0"><b>Dated :</b> ${tDateFull(v.date)}</td></tr></table>');
  if (v.vt.code == 'PAY' || v.vt.code == 'RCT' || v.vt.code == 'EXP' || v.vt.code == 'INC') {
    b.write('<p><b>${v.vt.code == 'PAY' || v.vt.code == 'EXP' ? 'Paid by' : 'Received in'} :</b> ${htmlEsc(v.contra)}${v.ref.isEmpty ? '' : ' &nbsp; (${htmlEsc(v.ref)})'}</p>');
  }
  if (v.vt.code == 'CON') {
    b.write('<p><b>${v.kind == 'dep' ? 'Cash deposited into the bank' : 'Cash withdrawn from the bank'}</b>${v.ref.isEmpty ? '' : ' &nbsp; (${htmlEsc(v.ref)})'}</p>');
  }
  if (v.vt.code == 'CNT' || v.vt.code == 'DNT') {
    b.write('<p><b>${v.vt.code == 'CNT' ? 'Sales return from' : 'Purchase return to'} :</b> ${htmlEsc(v.party)}${v.ref.isEmpty ? '' : ' &nbsp; <b>Against :</b> ${htmlEsc(v.ref)}'}</p>');
  }
  b.write('<table><tr><th>Particulars</th><th class="r">Amount</th></tr>');
  final String side = v.dr > 0 ? 'Dr' : 'Cr';
  b.write('<tr><td><b>${htmlEsc(v.party)}</b>${v.note.isEmpty ? '' : '<br><small>${htmlEsc(v.note)}</small>'}</td><td class="r"><b>${tAmt(v.amt)} $side</b></td></tr>');
  // a contra moves money between two accounts: Tally prints both sides
  if (v.vt.code == 'CON') b.write('<tr><td><b>${htmlEsc(v.contra)}</b></td><td class="r"><b>${tAmt(v.amt)} Cr</b></td></tr>');
  // a note has two sides too: the party and the Purchase / Sales Returns account
  if (v.vt.code == 'CNT' || v.vt.code == 'DNT') b.write('<tr><td><b>${htmlEsc(v.vt.code == 'CNT' ? 'Sales Returns' : 'Purchase Returns')}</b></td><td class="r"><b>${tAmt(v.amt)} ${v.dr > 0 ? 'Cr' : 'Dr'}</b></td></tr>');
  if (curBal.isNotEmpty) b.write('<tr><td colspan="2"><small>Cur Bal : ${htmlEsc(curBal)}</small></td></tr>');
  b.write('<tr class="t"><td>Total</td><td class="r">${tAmt(v.amt)}</td></tr></table>');
  b.write('<p><b>Amount (in words) :</b> ${htmlEsc(amountInWords(v.amt))}</p>');
  if (v.note.isNotEmpty && v.src != 'chit') b.write('<p><b>Narration :</b> ${htmlEsc(v.note)}</p>');
  b.write('<div class="sig"><div>Prepared by</div><div>Checked by</div><div>Authorised Signatory</div><div>Receiver\'s Signature</div></div>');
  b.write('<script>window.onload=function(){window.print();}</script></body></html>');
  return b.toString();
}

/// CSV of a list of vouchers (opens in Excel).
String vouchersCsv(List<Vch> l) {
  final StringBuffer b = StringBuffer();
  b.writeln('Date,Particulars,Vch Type,Vch No.,Debit,Credit,Mode,Ref,Narration');
  for (final Vch v in l) {
    b.writeln('${tDateFull(v.date)},${csvCell(v.party)},${v.vt.en},${v.number},${v.dr > 0 ? v.dr.toStringAsFixed(2) : ''},${v.cr > 0 ? v.cr.toStringAsFixed(2) : ''},${v.mode},${csvCell(v.ref)},${csvCell(v.note)}');
  }
  return b.toString();
}

/// Same voucher list for a period.
List<Vch> vouchersIn(Period p, {String type = ''}) {
  final List<Vch> out = <Vch>[];
  for (final Vch v in allVouchers()) {
    if (!p.has(v.date)) continue;
    if (type.isNotEmpty && v.type != type) continue;
    out.add(v);
  }
  return out;
}

/// One voucher by its entry id (src = pay | sale | exp | contra); null when it is gone.
Vch? voucherById(String src, String id) {
  for (final Vch v in allVouchers(chits: false)) {
    if (v.src == src && v.id == id) return v;
  }
  return null;
}
