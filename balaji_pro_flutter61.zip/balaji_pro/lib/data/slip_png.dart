import 'dart:convert';
import 'dart:io' show ZLibEncoder;
import 'dart:typed_data';
import 'slip_font.dart';

// ======================================================================
// The slip as a PICTURE (PNG) - what goes on WhatsApp instead of plain writing: it looks like the printed slip.
//  - input: the same text the Epson prints (see slipEpson): one line per row, "\u0001 ... \u0002" = big (double width) letters
//  - drawn with its own small font (slip_font.dart), so it needs no font, no Flutter and no printer: pure Dart, tested alone
//  - black letters on white paper, a thin frame; 12 x 24 pixels per letter, so the Matrix slip (80 columns) is about 1000 pixels wide
// ======================================================================

const int kPicPad = 24;
const int _ink = 20;

Uint8List? _glyphBytes;
Uint8List _glyphs() => _glyphBytes ??= base64Decode(kSlipFontB64);

/// Draws [text] as a grey-scale PNG, the way the printer prints it (escpBytes): the first line in big letters, centred on a paper
/// [width] letters wide (only when it fits twice over - [wideHeading]); a short slip is never drawn narrower than [width].
/// [compress] false writes an uncompressed file (used when the platform has no zlib; also by tests).
Uint8List slipPng(String text, {int width = 46, bool wideHeading = true, bool compress = true}) {
  const int cw = kSlipFontCols, ch = kSlipFontRows;
  final int minCols = width;
  final List<List<_Cell>> rows = <List<_Cell>>[];
  final List<String> src = text.replaceAll('\r', '').split('\n');
  for (int li = 0; li < src.length; li++) {
    final String raw = src[li];
    final List<_Cell> row = <_Cell>[];
    if (li == 0 && wideHeading && raw.trim().isNotEmpty && raw.trim().length * 2 <= width) {
      final String h = raw.trim();
      final int pad = (width - h.length * 2) ~/ 2;
      for (int i = 0; i < pad; i++) {
        row.add(const _Cell(32, false));
      }
      for (final int u in h.runes) {
        row.add(_Cell((u < 32 || u > 126) ? 63 : u, true));
      }
      rows.add(row);
      continue;
    }
    bool big = false;
    for (final int u in raw.runes) {
      if (u == 1) {
        big = true;
        continue;
      }
      if (u == 2) {
        big = false;
        continue;
      }
      int c = u == 9 ? 32 : u;
      if (c < 32 || c > 126) c = 63; // anything else (a letter the font does not have) is a "?", like on the printer
      row.add(_Cell(c, big));
    }
    rows.add(row);
  }
  while (rows.length > 1 && rows.last.isEmpty) {
    rows.removeLast();
  }
  int cols = minCols;
  for (final List<_Cell> r in rows) {
    int w = 0;
    for (final _Cell c in r) {
      w += c.big ? 2 : 1;
    }
    if (w > cols) cols = w;
  }
  if (cols < 1) cols = 1;
  final int w = cols * cw + 2 * kPicPad;
  final int h = rows.length * ch + 2 * kPicPad;
  final Uint8List px = Uint8List(w * h)..fillRange(0, w * h, 255);
  final Uint8List g = _glyphs();
  for (int ry = 0; ry < rows.length; ry++) {
    int x0 = kPicPad;
    final int y0 = kPicPad + ry * ch;
    for (final _Cell c in rows[ry]) {
      final int base = (c.code - 32) * cw * ch;
      if (c.code != 32) {
        for (int y = 0; y < ch; y++) {
          final int o = (y0 + y) * w;
          if (!c.big) {
            for (int x = 0; x < cw; x++) {
              final int a = g[base + y * cw + x];
              if (a != 0) _paint(px, o + x0 + x, a);
            }
          } else {
            // double width: every pixel column twice, like the printer doubles its dots
            for (int x = 0; x < cw * 2; x++) {
              final int a = g[base + y * cw + x ~/ 2];
              if (a != 0) _paint(px, o + x0 + x, a);
            }
          }
        }
      }
      x0 += c.big ? cw * 2 : cw;
    }
  }
  // the paper edge
  for (int x = 0; x < w; x++) {
    px[x] = 170;
    px[(h - 1) * w + x] = 170;
  }
  for (int y = 0; y < h; y++) {
    px[y * w] = 170;
    px[y * w + w - 1] = 170;
  }
  // PNG scan lines: a filter byte (0 = none) in front of every row
  final Uint8List raw = Uint8List((w + 1) * h);
  for (int y = 0; y < h; y++) {
    raw.setRange(y * (w + 1) + 1, (y + 1) * (w + 1), px, y * w);
  }
  Uint8List z;
  try {
    if (!compress) throw UnsupportedError('stored');
    z = Uint8List.fromList(ZLibEncoder(level: 9).convert(raw));
  } catch (_) {
    z = zlibStored(raw);
  }
  final BytesBuilder out = BytesBuilder();
  out.add(const <int>[137, 80, 78, 71, 13, 10, 26, 10]);
  final ByteData ihdr = ByteData(13)
    ..setUint32(0, w)
    ..setUint32(4, h)
    ..setUint8(8, 8) // 8 bits
    ..setUint8(9, 0); // grey scale
  _chunk(out, 'IHDR', ihdr.buffer.asUint8List());
  _chunk(out, 'IDAT', z);
  _chunk(out, 'IEND', Uint8List(0));
  return out.toBytes();
}

class _Cell {
  final int code;
  final bool big;
  const _Cell(this.code, this.big);
}

void _paint(Uint8List px, int i, int a) {
  // letters never overlap, so the new ink simply darkens the white paper
  final int v = 255 - (a * (255 - _ink)) ~/ 255;
  if (v < px[i]) px[i] = v;
}

void _chunk(BytesBuilder out, String type, Uint8List data) {
  final List<int> t = type.codeUnits;
  final ByteData len = ByteData(4)..setUint32(0, data.length);
  out.add(len.buffer.asUint8List());
  out.add(t);
  out.add(data);
  int c = 0xFFFFFFFF;
  c = _crc(c, t);
  c = _crc(c, data);
  final ByteData crc = ByteData(4)..setUint32(0, c ^ 0xFFFFFFFF);
  out.add(crc.buffer.asUint8List());
}

List<int>? _crcTable;
int _crc(int c, List<int> d) {
  final List<int> t = _crcTable ??= List<int>.generate(256, (int n) {
    int x = n;
    for (int k = 0; k < 8; k++) {
      x = (x & 1) != 0 ? 0xEDB88320 ^ (x >> 1) : x >> 1;
    }
    return x;
  });
  for (final int b in d) {
    c = t[(c ^ b) & 0xFF] ^ (c >> 8);
  }
  return c;
}

/// zlib data without compression (stored blocks): bigger, but needs nothing from the platform.
Uint8List zlibStored(Uint8List raw) {
  final BytesBuilder o = BytesBuilder();
  o.add(const <int>[0x78, 0x01]);
  int p = 0;
  do {
    final int n = (raw.length - p) > 65535 ? 65535 : raw.length - p;
    final bool last = p + n >= raw.length;
    o.add(<int>[last ? 1 : 0, n & 255, n >> 8, (~n) & 255, ((~n) >> 8) & 255]);
    o.add(Uint8List.sublistView(raw, p, p + n));
    p += n;
  } while (p < raw.length);
  int a = 1, b = 0;
  for (final int x in raw) {
    a = (a + x) % 65521;
    b = (b + a) % 65521;
  }
  final ByteData ad = ByteData(4)..setUint32(0, (b << 16) | a);
  o.add(ad.buffer.asUint8List());
  return o.toBytes();
}
