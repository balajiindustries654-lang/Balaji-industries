import '../core/fmt.dart';
import '../core/i18n.dart';
import 'books.dart';
import 'insights.dart';
import 'money.dart';
import 'owner_docs.dart';
import 'trade.dart';
import 'vouchers.dart';

// ======================================================================
// Financial statements, the TallyPrime way
//   Profit & Loss A/c, Balance Sheet, Group Summary, Bank Book and Outstandings (Receivables / Payables),
//   all worked out from the same vouchers as the Day Book, the Ledgers and the Trial Balance.
//   Stock is counted in KG only, so the opening / closing stock VALUE is typed in by the owner once for a
//   financial year (it is saved with the other owner settings).
// ======================================================================

// ------------------------------------------------------------ stock value
String _fyKey(DateTime fyStart) => '${fyStart.year}';

double _stockVal(DateTime fyStart, String k) {
  final Object? m = prefDoc.data['stockVal'];
  if (m is Map) {
    final Object? e = m[_fyKey(fyStart)];
    if (e is Map) {
      final Object? v = e[k];
      if (v is num) return v.toDouble();
      if (v is String) return double.tryParse(v) ?? 0;
    }
  }
  return 0;
}

/// Value of the stock on 1 April of the financial year that starts on [fyStart].
double stockValueOpen(DateTime fyStart) => _stockVal(fyStart, 'o');

/// Value of the stock at the end of that financial year (or as on today for the running year).
double stockValueClose(DateTime fyStart) => _stockVal(fyStart, 'c');

Future<void> setStockValues(DateTime fyStart, double open, double close) {
  return prefDoc.commit(() {
    final Map<String, dynamic> m = prefDoc.map('stockVal');
    m[_fyKey(fyStart)] = <String, dynamic>{'o': open, 'c': close};
  });
}

/// Valuation rate (Rs per 20 KG) typed for one stock item; 0 when none.
double stockRateOf(String key) {
  final Object? m = prefDoc.data['stockRate'];
  if (m is Map) {
    final Object? v = m[key];
    if (v is num) return v.toDouble();
    if (v is String) return double.tryParse(v) ?? 0;
  }
  return 0;
}

Future<void> setStockRates(Map<String, double> rates) {
  return prefDoc.commit(() {
    final Map<String, dynamic> m = prefDoc.map('stockRate');
    for (final MapEntry<String, double> e in rates.entries) {
      if (e.value <= 0) {
        m.remove(e.key);
      } else {
        m[e.key] = e.value;
      }
    }
  });
}

/// The rate used to value a stock item: the typed valuation rate, else the latest rate of the Price List (0 when neither).
double stockRateEff(StockLine r, DateTime day) {
  final double own = stockRateOf(r.key);
  if (own > 0) return own;
  return rateFor(r.label, day) ?? 0;
}

/// Closing value of one stock item (never below zero).
double stockLineValue(StockLine r, DateTime day) {
  if (r.left <= 0) return 0;
  return r.left / 20 * stockRateEff(r, day);
}

/// Closing stock value worked out from the stock quantity and the rates (Rs per 20 KG).
double suggestedStockValue(DateTime day) {
  double t = 0;
  for (final StockLine r in stockRows()) {
    t += stockLineValue(r, day);
  }
  return t;
}

// ------------------------------------------------------------ profit & loss
class PlLine {
  final String name;
  final double amt; // always positive
  final LedgerRef? ref;
  final String go;
  final String arg;
  const PlLine(this.name, this.amt, {this.ref, this.go = '', this.arg = ''});
}

class PlReport {
  final Period period;
  final DateTime fyStart;
  final bool stockUsed; // the stock values count only when the period starts on 1 April
  final double openStock;
  final double closeStock;
  final double purchase;
  final double sales;
  final List<PlLine> expenses;
  final List<PlLine> incomes;
  const PlReport(this.period, this.fyStart, this.stockUsed, this.openStock, this.closeStock, this.purchase, this.sales, this.expenses, this.incomes);

  double get tradingDr => openStock + purchase;
  double get tradingCr => sales + closeStock;

  /// + profit, - loss
  double get gross => tradingCr - tradingDr;

  double get expTotal {
    double t = 0;
    for (final PlLine l in expenses) {
      t += l.amt;
    }
    return t;
  }

  double get incTotal {
    double t = 0;
    for (final PlLine l in incomes) {
      t += l.amt;
    }
    return t;
  }

  /// + profit, - loss
  double get net => gross + incTotal - expTotal;
}

PlReport plReport(Period p) {
  final DateTime fy = finYearStart(p.lastDay);
  final bool used = sameDay(p.from, fy);
  final double os = used ? stockValueOpen(fy) : 0;
  final double cs = used ? stockValueClose(fy) : 0;
  final DateTime kf = khataFrom();
  double purchase = 0;
  double sales = 0;
  final Map<String, double> exp = <String, double>{};
  final Map<String, double> inc = <String, double>{};
  for (final Vch v in allVouchers()) {
    if (!p.has(v.date)) continue;
    if (v.src == 'chit') {
      if (!inLedger(v, kf)) continue;
      purchase += v.cr;
    } else if (v.type == 'SAL') {
      sales += v.dr - v.tax;
    } else if (v.type == 'DNT') {
      purchase -= v.dr; // purchase return: the farmer owes us less, the purchases shrink
    } else if (v.type == 'CNT') {
      sales -= v.cr; // sales return: the buyer owes us less, the sales shrink
    } else if (v.type == 'EXP') {
      if (v.partyKey == kGstHead) continue; // GST paid to the Government is not a cost
      exp[v.partyKey] = (exp[v.partyKey] ?? 0) + v.dr;
    } else if (v.type == 'INC') {
      inc[v.partyKey] = (inc[v.partyKey] ?? 0) + v.cr;
    }
  }
  List<PlLine> lines(Map<String, double> m) {
    final List<PlLine> l = <PlLine>[
      for (final MapEntry<String, double> e in m.entries)
        if (e.value.abs() >= 0.005) PlLine(expCatLabel(e.key), e.value, ref: LedgerRef('head', e.key, expCatLabel(e.key))),
    ];
    l.sort((PlLine a, PlLine b) => b.amt.compareTo(a.amt));
    return l;
  }

  return PlReport(p, fy, used, os, cs, purchase, sales, lines(exp), lines(inc));
}

// ------------------------------------------------------------ bank
class BankFig {
  double opening = 0; // Dr positive
  double dr = 0; // received
  double cr = 0; // paid
  double get closing => opening + dr - cr;
}

/// Bank / UPI / cheque movements (everything that is not cash) for a period.
BankFig bankFig(Period p) {
  final BankFig f = BankFig();
  for (final Vch v in allVouchers(chits: false)) {
    if (v.type == 'CON') {
      // contra: cash deposited comes into the bank, cash withdrawn goes out
      final bool dep = v.kind == 'dep';
      if (v.date.isBefore(p.from)) {
        f.opening += dep ? v.amt : -v.amt;
      } else if (v.date.isBefore(p.to)) {
        if (dep) {
          f.dr += v.amt;
        } else {
          f.cr += v.amt;
        }
      }
      continue;
    }
    if (v.mode.isEmpty || v.mode == 'cash' || v.type == 'JRN') continue;
    final bool inn = v.type == 'RCT' || v.type == 'INC';
    final bool out = v.type == 'PAY' || v.type == 'EXP';
    if (!inn && !out) continue;
    final double a = v.amt;
    if (v.date.isBefore(p.from)) {
      f.opening += inn ? a : -a;
    } else if (v.date.isBefore(p.to)) {
      if (inn) {
        f.dr += a;
      } else {
        f.cr += a;
      }
    }
  }
  return f;
}

/// The bank vouchers of a period, oldest first.
List<Vch> bankVouchers(Period p) {
  final List<Vch> out = <Vch>[];
  for (final Vch v in allVouchers(chits: false)) {
    if (!p.has(v.date)) continue;
    if (v.type == 'CON') {
      out.add(v);
      continue;
    }
    if (v.mode.isEmpty || v.mode == 'cash' || v.type == 'JRN') continue;
    if (v.type == 'RCT' || v.type == 'INC' || v.type == 'PAY' || v.type == 'EXP') out.add(v);
  }
  return out;
}

bool isMoneyIn(Vch v) => v.type == 'RCT' || v.type == 'INC' || (v.type == 'CON' && v.kind == 'dep');

// ------------------------------------------------------------ cash book
/// Cash received (debit) and paid (credit) in a period, with the opening balance (same figures as the trial balance).
BankFig cashFig(Period p) {
  final BankFig f = BankFig();
  f.opening = cashOpening(p.from);
  for (final CashLine l in cashLines()) {
    if (!p.has(l.date)) continue;
    if (l.isIn) {
      f.dr += l.amt;
    } else {
      f.cr += l.amt;
    }
  }
  return f;
}

/// The vouchers that moved cash in a period, oldest first (payments, receipts, expenses, incomes and contra).
List<Vch> cashVouchers(Period p) {
  final DateTime? sd = cashSeedDate();
  final List<Vch> out = <Vch>[];
  for (final Vch v in allVouchers(chits: false)) {
    if (!p.has(v.date)) continue;
    if (sd != null && v.date.isBefore(sd)) continue;
    if (v.type == 'CON') {
      out.add(v);
      continue;
    }
    if (v.mode != 'cash') continue;
    if (v.type == 'RCT' || v.type == 'INC' || v.type == 'PAY' || v.type == 'EXP') out.add(v);
  }
  return out;
}

/// Cash comes in with a receipt, an income, or a withdrawal from the bank.
bool isCashIn(Vch v) => v.type == 'RCT' || v.type == 'INC' || (v.type == 'CON' && v.kind == 'wd');

// ------------------------------------------------------------ balance sheet
class BsLine {
  final String name;
  final double c; // credit positive: + liability, - asset
  final List<TbLine> kids;
  final String go;
  final String arg;
  const BsLine(this.name, this.c, {this.kids = const <TbLine>[], this.go = '', this.arg = ''});

  double get amt => c.abs();
}

class BsReport {
  final DateTime asOn; // last day
  final DateTime fyStart;
  final List<BsLine> liabilities;
  final List<BsLine> assets;
  final double diff; // + : the difference is shown on the assets side, - : on the liabilities side
  final double total;
  final bool stockMissing;
  const BsReport(this.asOn, this.fyStart, this.liabilities, this.assets, this.diff, this.total, this.stockMissing);
}

/// Balance Sheet as on the last day of the period.
BsReport balanceSheet(Period p) {
  final DateTime kf = khataFrom();
  final DateTime fy = finYearStart(p.lastDay);
  final Period upTo = Period(DateTime(2000), p.to);
  final double os = stockValueOpen(fy);
  final double cs = stockValueClose(fy);

  List<TbLine> partyKids(List<LedgerSum> l) {
    final List<TbLine> k = <TbLine>[];
    for (final LedgerSum s in l) {
      final double c = s.closing;
      if (c.abs() < 0.005) continue;
      k.add(TbLine(s.ref.name, c > 0 ? c : 0, c < 0 ? -c : 0, ref: s.ref));
    }
    k.sort((TbLine a, TbLine b) => (b.dr + b.cr).compareTo(a.dr + a.cr));
    return k;
  }

  final List<LedgerSum> fm = ledgerList('farmer', upTo);
  final List<LedgerSum> by = ledgerList('buyer', upTo);
  double fmNet = 0; // Dr positive
  for (final LedgerSum s in fm) {
    fmNet += s.closing;
  }
  double byNet = 0;
  for (final LedgerSum s in by) {
    byNet += s.closing;
  }

  // profit and loss up to the date, split at the start of the financial year
  double plBefore = 0;
  double plNow = 0;
  double bank = 0;
  double journal = 0;
  for (final Vch v in allVouchers()) {
    final bool before = v.date.isBefore(fy);
    final bool upto = v.date.isBefore(p.to);
    if (!upto) continue;
    if (v.type == 'CON') {
      bank += v.kind == 'dep' ? v.amt : -v.amt;
      continue;
    }
    if (v.src == 'chit' && !inLedger(v, kf)) continue;
    double pl = 0;
    if (v.src == 'chit') {
      pl = -v.cr;
    } else if (v.type == 'SAL') {
      pl = v.dr - v.tax;
    } else if (v.type == 'DNT') {
      pl = v.dr;
    } else if (v.type == 'CNT') {
      pl = -v.cr;
    } else if (v.type == 'EXP') {
      pl = v.partyKey == kGstHead ? 0 : -v.dr;
    } else if (v.type == 'INC') {
      pl = v.cr;
    } else if (v.type == 'JRN' && inLedger(v, kf)) {
      journal += v.dr - v.cr;
    }
    if (before) {
      plBefore += pl;
    } else {
      plNow += pl;
    }
    if (v.mode.isNotEmpty && v.mode != 'cash' && v.type != 'JRN') {
      if (v.type == 'RCT' || v.type == 'INC') bank += v.amt;
      if (v.type == 'PAY' || v.type == 'EXP') bank -= v.amt;
    }
  }
  final double cash = cashOpening(p.to);
  final double seed = cashSeedDate() == null ? 0 : cashSeed();
  final double duty = gstDuty(upTo).closing; // credit positive

  final List<BsLine> items = <BsLine>[];
  final List<TbLine> plKids = <TbLine>[
    TbLine(bi('શરૂઆતનું બાકી', 'Opening Balance'), (plBefore + os) < 0 ? -(plBefore + os) : 0, (plBefore + os) > 0 ? plBefore + os : 0),
    TbLine(bi('ચાલુ પીરિયડ', 'Current Period'), (plNow + cs - os) < 0 ? -(plNow + cs - os) : 0, (plNow + cs - os) > 0 ? plNow + cs - os : 0, go: 'profit_loss'),
  ];
  // the order here is the order on the page
  if (seed.abs() >= 0.005) items.add(BsLine(bi('મૂડી ખાતું (શરૂઆતની રોકડ)', 'Capital Account (opening cash)'), seed));
  if (journal.abs() >= 0.005) items.add(BsLine(bi('જર્નલ / જૂના બાકી (ઓપનિંગ)', 'Opening Balances (journal)'), journal));
  if (fm.isNotEmpty && fmNet.abs() >= 0.005) items.add(BsLine(bi('સુંદરી લેણદાર (ખેડૂત)', 'Sundry Creditors (Farmers)'), -fmNet, kids: partyKids(fm)));
  if (duty.abs() >= 0.005) items.add(BsLine(bi('ડ્યુટી અને ટેક્સ (GST)', 'Duties & Taxes (GST)'), duty));
  final double plAll = plBefore + plNow + cs;
  if (plAll.abs() >= 0.005) items.add(BsLine(bi('નફો-નુકસાન ખાતું', 'Profit & Loss A/c'), plAll, kids: plKids, go: 'profit_loss'));
  if (cs.abs() >= 0.005) items.add(BsLine(bi('આખરી સ્ટોક (Closing Stock)', 'Closing Stock'), -cs, go: 'stock_live'));
  if (by.isNotEmpty && byNet.abs() >= 0.005) items.add(BsLine(bi('સુંદરી દેવાદાર (ખરીદનાર)', 'Sundry Debtors (Buyers)'), -byNet, kids: partyKids(by)));
  if (cash.abs() >= 0.005) items.add(BsLine(bi('રોકડ (Cash-in-hand)', 'Cash-in-hand'), -cash, go: 'cashbook'));
  if (bank.abs() >= 0.005) items.add(BsLine(bi('બેંક ખાતા (Bank Accounts)', 'Bank Accounts'), -bank, go: 'bank_book'));

  final List<BsLine> liab = <BsLine>[];
  final List<BsLine> asset = <BsLine>[];
  double lt = 0;
  double at = 0;
  for (final BsLine l in items) {
    if (l.c >= 0) {
      liab.add(l);
      lt += l.c;
    } else {
      asset.add(l);
      at += -l.c;
    }
  }
  final double diff = lt - at; // + : assets are short
  final double total = lt > at ? lt : at;
  return BsReport(p.lastDay, fy, liab, asset, diff.abs() < 0.5 ? 0 : diff, total, cs.abs() < 0.005 && os.abs() < 0.005);
}

// ------------------------------------------------------------ group summary
class GroupLine {
  final String name;
  final double opening; // Dr positive
  final double dr;
  final double cr;
  final String go; // screen to open
  final String arg;
  const GroupLine(this.name, this.opening, this.dr, this.cr, {this.go = '', this.arg = ''});

  double get closing => opening + dr - cr;
}

/// Group Summary for a period: opening balance, debit, credit and closing balance of every group of ledgers.
List<GroupLine> groupSummary(Period p) {
  final List<GroupLine> out = <GroupLine>[];
  double sumOf(List<LedgerSum> l, double Function(LedgerSum) f) {
    double t = 0;
    for (final LedgerSum s in l) {
      t += f(s);
    }
    return t;
  }

  final List<LedgerSum> fm = ledgerList('farmer', p);
  final List<LedgerSum> by = ledgerList('buyer', p);
  if (fm.isNotEmpty) out.add(GroupLine(bi('સુંદરી લેણદાર (ખેડૂત)', 'Sundry Creditors (Farmers)'), sumOf(fm, (LedgerSum s) => s.opening), sumOf(fm, (LedgerSum s) => s.dr), sumOf(fm, (LedgerSum s) => s.cr), go: 'my_ledger', arg: 'farmer'));
  if (by.isNotEmpty) out.add(GroupLine(bi('સુંદરી દેવાદાર (ખરીદનાર)', 'Sundry Debtors (Buyers)'), sumOf(by, (LedgerSum s) => s.opening), sumOf(by, (LedgerSum s) => s.dr), sumOf(by, (LedgerSum s) => s.cr), go: 'my_ledger', arg: 'buyer'));

  // cash
  double cin = 0;
  double cout = 0;
  for (final CashLine l in cashLines()) {
    if (!p.has(l.date)) continue;
    if (l.isIn) {
      cin += l.amt;
    } else {
      cout += l.amt;
    }
  }
  final double cOpen = cashOpening(p.from);
  if (cOpen.abs() >= 0.005 || cin > 0 || cout > 0) out.add(GroupLine(bi('રોકડ (Cash-in-hand)', 'Cash-in-hand'), cOpen, cin, cout, go: 'cashbook'));
  final BankFig b = bankFig(p);
  if (b.opening.abs() >= 0.005 || b.dr > 0 || b.cr > 0) out.add(GroupLine(bi('બેંક ખાતા (Bank Accounts)', 'Bank Accounts'), b.opening, b.dr, b.cr, go: 'bank_book'));

  final GstDuty gd = gstDuty(p);
  if (gd.opening.abs() >= 0.005 || gd.collected > 0 || gd.paid > 0) out.add(GroupLine(bi('ડ્યુટી અને ટેક્સ (GST)', 'Duties & Taxes (GST)'), -gd.opening, gd.paid, gd.collected, go: 'gstr1'));

  final PlReport r = plReport(p);
  if (r.purchase.abs() >= 0.005) out.add(GroupLine(bi('ખરીદ ખાતું', 'Purchase Accounts'), 0, r.purchase, 0, go: 'my_daybook', arg: 'PUR'));
  if (r.sales.abs() >= 0.005) out.add(GroupLine(bi('વેચાણ ખાતું', 'Sales Accounts'), 0, 0, r.sales, go: 'my_daybook', arg: 'SAL'));
  if (r.expTotal.abs() >= 0.005) out.add(GroupLine(bi('ખર્ચ (Indirect Expenses)', 'Indirect Expenses'), 0, r.expTotal, 0, go: 'my_daybook', arg: 'EXP'));
  if (r.incTotal.abs() >= 0.005) out.add(GroupLine(bi('આવક (Indirect Incomes)', 'Indirect Incomes'), 0, 0, r.incTotal, go: 'my_daybook', arg: 'INC'));
  return out;
}

// ------------------------------------------------------------ outstandings
class OutLine {
  final LedgerRef ref;
  final double balance; // positive amount outstanding
  final DateTime? last; // date of the last voucher
  final List<double> age; // 0-30, 31-60, 61-90, over 90 days
  const OutLine(this.ref, this.balance, this.last, this.age);
}

List<double> _ageing(List<Vch> vs, bool debitSide, double bal, DateTime asOn) {
  final List<double> out = <double>[0, 0, 0, 0];
  double rest = bal;
  for (int i = vs.length - 1; i >= 0 && rest > 0.005; i--) {
    final Vch v = vs[i];
    final double a = debitSide ? v.dr : v.cr;
    if (a <= 0) continue;
    final double take = a < rest ? a : rest;
    final int days = daysBetween(v.date, asOn);
    final int k = days <= 30 ? 0 : (days <= 60 ? 1 : (days <= 90 ? 2 : 3));
    out[k] += take;
    rest -= take;
  }
  if (rest > 0.005) out[3] += rest; // balance carried from before the first voucher
  return out;
}

/// Receivables (buyers who owe us, debit balance) or Payables (farmers we owe, credit balance) as on the last day of the period,
/// with the ageing of each balance (the balance is counted against the newest bills first).
List<OutLine> outstandings(bool receivables, DateTime asOn) {
  final String dim = receivables ? 'buyer' : 'farmer';
  final Period upTo = Period(DateTime(2000), addDays(asOn, 1));
  final Map<String, List<Vch>> by = <String, List<Vch>>{};
  final DateTime kf = khataFrom();
  for (final Vch v in allVouchers()) {
    if (v.dim != dim || v.partyKey.isEmpty || !inLedger(v, kf) || !upTo.has(v.date)) continue;
    by.putIfAbsent(v.partyKey, () => <Vch>[]).add(v);
  }
  final List<OutLine> out = <OutLine>[];
  for (final LedgerSum s in ledgerList(dim, upTo)) {
    final double bal = receivables ? s.closing : -s.closing;
    if (bal < 0.005) continue;
    final List<Vch> vs = by[s.ref.key] ?? <Vch>[];
    out.add(OutLine(s.ref, bal, vs.isEmpty ? null : vs.last.date, _ageing(vs, receivables, bal, asOn)));
  }
  out.sort((OutLine a, OutLine b) => b.balance.compareTo(a.balance));
  return out;
}

// ------------------------------------------------------------ ratio analysis
/// The figures of the Ratio Analysis of TallyPrime: principal groups and principal ratios for a period.
class RatioReport {
  final Period period;
  final bool stockUsed; // opening / closing stock count only when the period starts on 1 April
  final bool stockMissing;
  final double cash; // Dr positive
  final double bank; // Dr positive
  final double receivables; // debit balances of farmers / buyers
  final double payables; // credit balances of farmers / buyers
  final double stock; // closing stock value
  final double openStock;
  final double sales;
  final double purchase;
  final double gross; // + profit, - loss
  final double net; // + profit, - loss
  final double expenses;
  const RatioReport({
    required this.period,
    required this.stockUsed,
    required this.stockMissing,
    required this.cash,
    required this.bank,
    required this.receivables,
    required this.payables,
    required this.stock,
    required this.openStock,
    required this.sales,
    required this.purchase,
    required this.gross,
    required this.net,
    required this.expenses,
  });

  int get days => period.days;

  double get currentAssets => (cash > 0 ? cash : 0) + (bank > 0 ? bank : 0) + receivables + stock;

  double get currentLiabilities => payables + (cash < 0 ? -cash : 0) + (bank < 0 ? -bank : 0);

  double get workingCapital => currentAssets - currentLiabilities;

  /// Current assets for one rupee of current liabilities (null when there are no liabilities).
  double? get currentRatio => currentLiabilities < 0.5 ? null : currentAssets / currentLiabilities;

  /// Same without the stock.
  double? get quickRatio => currentLiabilities < 0.5 ? null : (currentAssets - stock) / currentLiabilities;

  double? get grossPct => sales < 0.5 ? null : gross / sales * 100;

  double? get netPct => sales < 0.5 ? null : net / sales * 100;

  double? get expensePct => sales < 0.5 ? null : expenses / sales * 100;

  /// Days of sales that are still to be received.
  double? get receivableDays => sales < 0.5 ? null : receivables / sales * days;

  /// Days of purchases that are still to be paid.
  double? get payableDays => purchase < 0.5 ? null : payables / purchase * days;

  /// Cost of goods sold / average stock (only when both stock values are entered).
  double? get inventoryTurnover {
    if (!stockUsed) return null;
    final double avg = (openStock + stock) / 2;
    if (avg < 0.5) return null;
    final double cogs = openStock + purchase - stock;
    return cogs <= 0 ? null : cogs / avg;
  }
}

RatioReport ratioReport(Period p) {
  final PlReport pl = plReport(p);
  final DateTime fy = finYearStart(p.lastDay);
  final Period upTo = Period(DateTime(2000), p.to);
  double rec = 0;
  double pay = 0;
  for (final String dim in <String>['farmer', 'buyer']) {
    for (final LedgerSum s in ledgerList(dim, upTo)) {
      final double c = s.closing;
      if (c > 0.005) rec += c;
      if (c < -0.005) pay += -c;
    }
  }
  final double gstLeft = gstDuty(upTo).closing; // GST still to be paid is a current liability
  if (gstLeft > 0.005) pay += gstLeft;
  if (gstLeft < -0.005) rec += -gstLeft;
  final double cs = stockValueClose(fy);
  final double os = stockValueOpen(fy);
  return RatioReport(
    period: p,
    stockUsed: pl.stockUsed,
    stockMissing: cs.abs() < 0.005 && os.abs() < 0.005,
    cash: cashOpening(p.to),
    bank: bankFig(upTo).closing,
    receivables: rec,
    payables: pay,
    stock: cs,
    openStock: pl.stockUsed ? pl.openStock : 0,
    sales: pl.sales,
    purchase: pl.purchase,
    gross: pl.gross,
    net: pl.net,
    expenses: pl.expTotal,
  );
}

// ------------------------------------------------------------ monthly figures (graphs)
class MonthFig {
  final DateTime month; // 1st of the month
  double purchase = 0;
  double sales = 0;
  double expense = 0;
  double income = 0;
  MonthFig(this.month);

  /// Sales - purchase - expenses + incomes of the month (the stock values are not part of a month).
  double get result => sales - purchase - expense + income;
}

class GraphYear {
  final DateTime fyStart;
  final List<MonthFig> months; // April ... March
  final List<PlLine> heads; // expenses of the year by head, biggest first
  const GraphYear(this.fyStart, this.months, this.heads);

  double get sales => _sum((MonthFig m) => m.sales);
  double get purchase => _sum((MonthFig m) => m.purchase);
  double get expense => _sum((MonthFig m) => m.expense);
  double get income => _sum((MonthFig m) => m.income);
  double get result => sales - purchase - expense + income;

  double _sum(double Function(MonthFig) f) {
    double t = 0;
    for (final MonthFig m in months) {
      t += f(m);
    }
    return t;
  }
}

/// Purchases, sales, expenses and incomes of every month of the financial year that starts on [fyStart] (one pass over the vouchers).
GraphYear graphYear(DateTime fyStart) {
  final List<MonthFig> months = <MonthFig>[for (int i = 0; i < 12; i++) MonthFig(DateTime(fyStart.year, fyStart.month + i, 1))];
  final DateTime end = DateTime(fyStart.year + 1, fyStart.month, 1);
  final DateTime kf = khataFrom();
  final Map<String, double> exp = <String, double>{};
  for (final Vch v in allVouchers()) {
    if (v.date.isBefore(fyStart) || !v.date.isBefore(end)) continue;
    final int i = (v.date.year - fyStart.year) * 12 + v.date.month - fyStart.month;
    if (i < 0 || i > 11) continue;
    final MonthFig m = months[i];
    if (v.src == 'chit') {
      if (!inLedger(v, kf)) continue;
      m.purchase += v.cr;
    } else if (v.type == 'SAL') {
      m.sales += v.dr - v.tax;
    } else if (v.type == 'DNT') {
      m.purchase -= v.dr;
    } else if (v.type == 'CNT') {
      m.sales -= v.cr;
    } else if (v.type == 'EXP') {
      if (v.partyKey == kGstHead) continue;
      m.expense += v.dr;
      exp[v.partyKey] = (exp[v.partyKey] ?? 0) + v.dr;
    } else if (v.type == 'INC') {
      m.income += v.cr;
    }
  }
  final List<PlLine> heads = <PlLine>[
    for (final MapEntry<String, double> e in exp.entries)
      if (e.value.abs() >= 0.005) PlLine(expCatLabel(e.key), e.value, ref: LedgerRef('head', e.key, expCatLabel(e.key))),
  ];
  heads.sort((PlLine a, PlLine b) => b.amt.compareTo(a.amt));
  return GraphYear(fyStart, months, heads);
}
