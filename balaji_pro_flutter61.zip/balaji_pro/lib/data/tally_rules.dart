// ======================================================================
// Which Tally vouchers Balaji Pro shows (the owner's rule, simple mode ON):
//   - the three firms Patel Enterprises, Shreenathji Enterprises and Balaji Industries: ONLY the sales
//   - the other firm (the one used for cash / online money): ONLY cash and online transactions (payment, receipt, contra)
//   - purchases of every firm are never listed as transactions: they are kept apart and only used to CHECK whether the purchase
//     is already made in Pro (a chit). Pro never makes a purchase from a Tally voucher, so there can be no double purchase.
// With simple mode OFF everything the PC Agent copied is shown, as before. Nothing is deleted either way.
// ======================================================================

/// The Tally firms (ids of tally_vouchers.firm) that are sales-only.
const Set<String> kOwnFirms = <String>{'patel', 'shreenathji', 'balaji'};

/// Voucher types (Tally "base" types) that are cash / online money.
const Set<String> kCashBase = <String>{'payment', 'receipt', 'contra'};

/// Is this voucher shown as a transaction? [simple] false = everything.
bool tallyKeepVoucher({required String firm, required String base, required bool simple}) {
  if (!simple) return true;
  if (kOwnFirms.contains(firm)) return base == 'sales';
  return kCashBase.contains(base);
}

/// Purchases are kept for the purchase check in every firm (also when they are not shown as transactions).
bool tallyIsPurchase(String base) => base == 'purchase';

/// "Patel" / "Shreenathji" / "Balaji" are sales firms; anything else is the cash / online firm.
bool tallyIsCashFirm(String firm) => firm.isNotEmpty && !kOwnFirms.contains(firm);
