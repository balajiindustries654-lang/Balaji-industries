/// Real business records, read from Supabase (chiththis / waybridge_entries /
/// maal_entries / user_profiles).

double dbl(Object? v, [double d = 0]) {
  if (v is num) return v.toDouble();
  if (v is String) return double.tryParse(v.trim().replaceAll(',', '')) ?? d;
  return d;
}

double? dblN(Object? v) {
  if (v == null) return null;
  if (v is num) return v.toDouble();
  if (v is String) return double.tryParse(v.trim().replaceAll(',', ''));
  return null;
}

String str(Object? v) => v == null ? '' : '$v'.trim();

DateTime? parseTs(Object? v) {
  if (v == null) return null;
  final DateTime? d = DateTime.tryParse('$v');
  return d?.toLocal();
}

/// No vehicle carries more than this in one go, so a bigger weight is a typing
/// mistake. Such entries are kept out of every total (and shown for clean-up).
const double kMaxLoadKg = 100000;

/// Same idea for the number of bags in one entry.
const int kMaxBags = 20000;

/// GJ03 AB 1234 -> GJ03AB1234 (used to match the same vehicle everywhere).
String vehicleKey(String v) => v.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');

String nameKey(String v) => v.toLowerCase().replaceAll(RegExp(r'\s+'), ' ').trim();

DateTime dayOf(DateTime d) => DateTime(d.year, d.month, d.day);

// ------------------------------------------------------------------ profile
class Profile {
  final String id;
  final String name;
  final String mobile;
  final String role;
  final bool approved;
  const Profile(this.id, this.name, this.mobile, this.role, this.approved);

  factory Profile.fromJson(Map<String, dynamic> j) {
    final Object? ap = j['approved'];
    return Profile(
      str(j['id']),
      str(j['full_name']),
      str(j['mobile']),
      str(j['role']),
      ap == null ? true : (ap == true || ap == 'true'),
    );
  }

  bool get isAdmin => role == 'admin';
  bool get isFarmer => role == 'farmer';
  bool get isStaff => role == 'worker' || role == 'waybridge' || role == 'maal_entry';
}

// -------------------------------------------------------------------- chithi
class Chit {
  final String id;
  final String no;
  final String commodity;
  final String broker;
  final String village;
  final String vehicle;
  final String farmer;
  final String mobile;
  final double gross;
  final double bardan;
  final double kardo;
  final double net;
  final int bags;
  final String photo;
  final String by;
  final DateTime at;

  const Chit({
    required this.id,
    required this.no,
    required this.commodity,
    required this.broker,
    required this.village,
    required this.vehicle,
    required this.farmer,
    required this.mobile,
    required this.gross,
    required this.bardan,
    required this.kardo,
    required this.net,
    required this.bags,
    required this.photo,
    required this.by,
    required this.at,
  });

  factory Chit.fromJson(Map<String, dynamic> j) {
    return Chit(
      id: str(j['id']),
      no: str(j['chiththi_number']),
      commodity: str(j['commodity_type']),
      broker: str(j['broker_name']),
      village: str(j['village_name']),
      vehicle: str(j['vehicle_number']),
      farmer: str(j['farmer_name']),
      mobile: str(j['farmer_mobile']),
      gross: dbl(j['gross_weight_kg']),
      bardan: dbl(j['bardan_kg']),
      kardo: dbl(j['kardo_kg']),
      net: dbl(j['weight_kg']),
      bags: dbl(j['bag_count']).round(),
      photo: str(j['chiththi_photo_url']),
      by: str(j['created_by']),
      at: parseTs(j['created_at']) ?? DateTime.now(),
    );
  }

  String get vkey => vehicleKey(vehicle);

  /// Weight that is comparable with the weighbridge (field weight incl. bags).
  double get cmpKg => gross > 0 ? gross : net;

  /// A weight or bag count that cannot be real.
  bool get insane => gross > kMaxLoadKg || net > kMaxLoadKg || bardan > kMaxLoadKg || kardo > kMaxLoadKg || bags > kMaxBags;
}

// -------------------------------------------------------------------- kanta
class Kanta {
  final String id;
  final String rst;
  final String vehicle;
  final double? total;
  final double? net;
  final String slip;
  final String by;
  final String name;
  final DateTime at;

  /// Written by Balaji Kanta at the weighing (empty on older entries): gross / tare, supplier, goods, town, mobile, charges.
  final double? gross;
  final double? tare;
  final String party;
  final String material;
  final String city;
  final String mobile;
  final double charges;

  const Kanta({
    required this.id,
    required this.rst,
    required this.vehicle,
    required this.total,
    required this.net,
    required this.slip,
    required this.by,
    required this.name,
    required this.at,
    this.gross,
    this.tare,
    this.party = '',
    this.material = '',
    this.city = '',
    this.mobile = '',
    this.charges = 0,
  });

  factory Kanta.fromJson(Map<String, dynamic> j) {
    return Kanta(
      id: str(j['id']),
      rst: str(j['rst_no']),
      vehicle: str(j['vehicle_number']),
      total: dblN(j['total_weight_kg']),
      net: dblN(j['net_weight_kg']),
      slip: str(j['slip_url']),
      by: str(j['created_by']),
      name: str(j['name']),
      at: parseTs(j['created_at']) ?? DateTime.now(),
      gross: dblN(j['gross_kg']),
      tare: dblN(j['tare_kg']),
      party: str(j['party_name']),
      material: str(j['material']),
      city: str(j['city']),
      mobile: str(j['party_mobile']),
      charges: dblN(j['charges_rs']) ?? 0,
    );
  }

  String get vkey => vehicleKey(vehicle);
  double get kg => (net != null && net! > 0) ? net! : (total ?? 0);

  /// A weight that cannot be real.
  bool get insane => (net ?? 0) > kMaxLoadKg || (total ?? 0) > kMaxLoadKg;
}

// --------------------------------------------------------------------- maal
class MaalRow {
  final String id;
  final String type; // loading | unloading
  final String vehicle;
  final int bags;
  final String material;
  final String owner;
  final String godown;
  final String slip;
  final String by;
  final DateTime date;
  final DateTime at;

  /// Dana (size / grade) of the goods: '50-60' ... '90-100', 'Fadiya', 'Damage' ('' = not told).
  final String dana;

  const MaalRow({
    required this.id,
    required this.type,
    required this.vehicle,
    required this.bags,
    required this.material,
    required this.owner,
    required this.godown,
    required this.slip,
    required this.by,
    required this.date,
    required this.at,
    this.dana = '',
  });

  factory MaalRow.fromJson(Map<String, dynamic> j) {
    final DateTime created = parseTs(j['created_at']) ?? DateTime.now();
    DateTime d = created;
    final String ed = str(j['entry_date']);
    if (ed.length >= 10) {
      final DateTime? p = DateTime.tryParse(ed.substring(0, 10));
      if (p != null) d = p;
    }
    return MaalRow(
      id: str(j['id']),
      type: str(j['entry_type']).toLowerCase(),
      vehicle: str(j['vehicle_number']),
      bags: dbl(j['bags']).round(),
      material: str(j['material_type']),
      owner: str(j['owner_name']),
      godown: str(j['godown']),
      slip: str(j['slip_url']),
      by: str(j['created_by']),
      date: d,
      at: created,
      dana: str(j['dana']),
    );
  }

  bool get loading => type == 'loading';
  String get vkey => vehicleKey(vehicle);

  /// A bag count that cannot be real.
  bool get insane => bags > kMaxBags;
}
