import '../core/i18n.dart';
import 'insights.dart' show dayKey;
import 'live_models.dart' show dbl, dayOf;
import 'owner_docs.dart';

// ======================================================================
// Contra vouchers (TallyPrime F4): money moving between Cash and Bank
//   deposit    = cash deposited into the bank  (Cash goes down, Bank goes up)
//   withdrawal = cash taken out of the bank    (Bank goes down, Cash goes up)
// One shared document `flutter_contra`: { items: [ {id, no, date, dep, amt, ref, note, at} ] }
// A contra changes the Cash Book and the Bank Book only - no party ledger, no profit or loss.
// ======================================================================

final SyncDoc contraDoc = SyncDoc('flutter_contra');

class ContraItem {
  final String id;
  final int no; // voucher number
  final DateTime date;
  final DateTime at;
  final bool dep; // true = cash deposited into the bank, false = cash withdrawn from the bank
  final double amt;
  final String ref; // cheque / slip number
  final String note;
  const ContraItem(this.id, this.no, this.date, this.at, this.dep, this.amt, this.ref, this.note);
}

String contraCashName() => bi('રોકડ', 'Cash');

String contraBankName() => bi('બેંક ખાતું', 'Bank A/c');

/// Newest first.
List<ContraItem> contraItems() {
  final List<ContraItem> out = <ContraItem>[];
  for (final Map<String, dynamic> m in contraDoc.list('items')) {
    final DateTime? d = DateTime.tryParse('${m['date'] ?? ''}');
    if (d == null) continue;
    out.add(ContraItem(
      '${m['id'] ?? ''}',
      dbl(m['no']).round(),
      dayOf(d),
      DateTime.tryParse('${m['at'] ?? ''}') ?? d,
      m['dep'] != false,
      dbl(m['amt']),
      '${m['ref'] ?? ''}',
      '${m['note'] ?? ''}',
    ));
  }
  out.sort((ContraItem a, ContraItem b) {
    final int c = b.date.compareTo(a.date);
    return c != 0 ? c : b.at.compareTo(a.at);
  });
  return out;
}

int _maxNo() {
  int best = 0;
  for (final Map<String, dynamic> m in contraDoc.list('items')) {
    final int n = dbl(m['no']).round();
    if (n > best) best = n;
  }
  return best;
}

/// The number the next contra voucher gets.
int nextContraNo() => _maxNo() + 1;

Future<void> addContra({required bool dep, required double amt, required DateTime date, String ref = '', String note = ''}) {
  return contraDoc.commit(() {
    final int no = _maxNo() + 1;
    contraDoc.list('items').add(<String, dynamic>{
      'id': '${DateTime.now().microsecondsSinceEpoch}',
      'no': no,
      'date': dayKey(date),
      'dep': dep,
      'amt': amt,
      'ref': ref.trim(),
      'note': note.trim(),
      'at': DateTime.now().toIso8601String(),
    });
  });
}

Future<void> updateContra(String id, {required bool dep, required double amt, required DateTime date, String ref = '', String note = ''}) {
  return contraDoc.commit(() {
    for (final Map<String, dynamic> m in contraDoc.list('items')) {
      if ('${m['id']}' != id) continue;
      m['date'] = dayKey(date);
      m['dep'] = dep;
      m['amt'] = amt;
      m['ref'] = ref.trim();
      m['note'] = note.trim();
      m['alt'] = DateTime.now().toIso8601String();
    }
  });
}

Future<void> removeContra(String id) {
  return contraDoc.commit(() {
    contraDoc.list('items').removeWhere((Map<String, dynamic> m) => '${m['id']}' == id);
  });
}
