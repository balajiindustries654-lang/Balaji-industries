import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ======================================================================
// Offline support
//  - OfflineStore.write / read : big JSON copies of the data (chits, kanta, maal, Tally ...)
//    kept as files inside the app's private folder, so everything can be opened without internet.
//  - OfflineStore.saveCred / checkCred : "offline login". After a successful online login the
//    phone / PC keeps a salted PBKDF2 hash of the password (never the password itself) and the
//    profile, so the same person can log in again later without internet.
// ======================================================================

String _enc(Object? o) => jsonEncode(o);
Object? _dec(String s) => jsonDecode(s);

/// PBKDF2-HMAC-SHA256, one block (32 bytes). args = [password, saltBase64, iterations]. Returns base64.
String _pbkdfJob(List<String> a) {
  final List<int> salt = base64Decode(a[1]);
  final int iters = int.parse(a[2]);
  final Hmac mac = Hmac(sha256, utf8.encode(a[0]));
  List<int> u = mac.convert(<int>[...salt, 0, 0, 0, 1]).bytes;
  final Uint8List t = Uint8List.fromList(u);
  for (int i = 1; i < iters; i++) {
    u = mac.convert(u).bytes;
    for (int j = 0; j < t.length; j++) {
      t[j] ^= u[j];
    }
  }
  return base64Encode(t);
}

String _digits(String s) => s.replaceAll(RegExp(r'[^0-9]'), '');

/// Result of an offline login try.
class OfflineLogin {
  final bool hasCred; // this device has a saved login for that mobile number
  final bool ok; // the password matched
  final bool locked; // too many wrong tries for the moment
  final String uid;
  final Map<String, dynamic> profile;
  const OfflineLogin({this.hasCred = false, this.ok = false, this.locked = false, this.uid = '', this.profile = const <String, dynamic>{}});
}

class OfflineStore {
  static const int _iters = 15000;
  static Directory? _dir;
  static bool _failed = false;
  static int _wrong = 0;
  static DateTime _lockUntil = DateTime.fromMillisecondsSinceEpoch(0);

  static Future<Directory?> _root() async {
    if (_dir != null) return _dir;
    if (_failed) return null;
    try {
      final Directory base = await getApplicationSupportDirectory();
      final Directory d = Directory('${base.path}${Platform.pathSeparator}offline');
      if (!await d.exists()) await d.create(recursive: true);
      _dir = d;
      return d;
    } catch (_) {
      _failed = true;
      return null;
    }
  }

  static String _safe(String k) => k.replaceAll(RegExp(r'[^A-Za-z0-9_.-]'), '_');

  /// Saves [data] (plain JSON: maps, lists, strings, numbers) under [key]. Never throws.
  static Future<void> write(String key, Object? data) async {
    try {
      final Directory? d = await _root();
      if (d == null) return;
      final String text = await compute(_enc, data);
      final String base = '${d.path}${Platform.pathSeparator}${_safe(key)}';
      final File tmp = File('$base.tmp');
      await tmp.writeAsString(text, flush: true);
      final File f = File('$base.json');
      if (await f.exists()) await f.delete();
      await tmp.rename(f.path);
    } catch (_) {}
  }

  /// The saved JSON of [key], or null when there is none.
  static Future<Object?> read(String key) async {
    try {
      final Directory? d = await _root();
      if (d == null) return null;
      final String base = '${d.path}${Platform.pathSeparator}${_safe(key)}';
      File f = File('$base.json');
      if (!await f.exists()) {
        f = File('$base.tmp');
        if (!await f.exists()) return null;
      }
      final String text = await f.readAsString();
      if (text.isEmpty) return null;
      return await compute(_dec, text);
    } catch (_) {
      return null;
    }
  }

  /// Size (bytes) of all saved copies.
  static Future<int> bytes() async {
    int n = 0;
    try {
      final Directory? d = await _root();
      if (d == null) return 0;
      await for (final FileSystemEntity e in d.list()) {
        if (e is File) n += await e.length();
      }
    } catch (_) {}
    return n;
  }

  /// Deletes every saved copy and every saved offline login of this device.
  static Future<void> clearAll() async {
    try {
      final Directory? d = await _root();
      if (d != null) {
        await for (final FileSystemEntity e in d.list()) {
          if (e is File) await e.delete();
        }
      }
    } catch (_) {}
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      for (final String k in p.getKeys().toList()) {
        if (k.startsWith('oc_')) await p.remove(k);
      }
    } catch (_) {}
  }

  // ------------------------------------------------------------ offline login
  static Future<void> saveCred(String mobile, String pass, String uid, Map<String, dynamic> profile) async {
    try {
      final Random r = Random.secure();
      final String salt = base64Encode(<int>[for (int i = 0; i < 16; i++) r.nextInt(256)]);
      final String h = await compute(_pbkdfJob, <String>[pass, salt, '$_iters']);
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setString(
        'oc_${_digits(mobile)}',
        jsonEncode(<String, dynamic>{'u': uid, 's': salt, 'h': h, 'n': _iters, 'me': profile}),
      );
    } catch (_) {}
  }

  static Future<void> dropCred(String mobile) async {
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.remove('oc_${_digits(mobile)}');
    } catch (_) {}
  }

  static Future<bool> hasCred(String mobile) async {
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      return (p.getString('oc_${_digits(mobile)}') ?? '').isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  /// Checks the password against the hash saved at the last online login.
  static Future<OfflineLogin> checkCred(String mobile, String pass) async {
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      final String raw = p.getString('oc_${_digits(mobile)}') ?? '';
      if (raw.isEmpty) return const OfflineLogin();
      if (DateTime.now().isBefore(_lockUntil)) return const OfflineLogin(hasCred: true, locked: true);
      final Object? j = jsonDecode(raw);
      if (j is! Map) return const OfflineLogin();
      final String h = await compute(_pbkdfJob, <String>[pass, '${j['s']}', '${j['n'] ?? _iters}']);
      if (h != '${j['h']}') {
        _wrong++;
        if (_wrong >= 5) {
          _wrong = 0;
          _lockUntil = DateTime.now().add(const Duration(seconds: 60));
        }
        return const OfflineLogin(hasCred: true);
      }
      _wrong = 0;
      final Object? me = j['me'];
      return OfflineLogin(
        hasCred: true,
        ok: true,
        uid: '${j['u']}',
        profile: me is Map ? Map<String, dynamic>.from(me) : <String, dynamic>{},
      );
    } catch (_) {
      return const OfflineLogin();
    }
  }
}
