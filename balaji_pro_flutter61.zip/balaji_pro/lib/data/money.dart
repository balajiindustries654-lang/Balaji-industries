import '../core/i18n.dart';
import '../core/flags.dart';
import 'contra.dart';
import 'insights.dart';
import 'live_models.dart';
import 'live_store.dart';
import 'owner_docs.dart';
import 'trade.dart';
import 'vno.dart';

/// Money side of the business: what the farmers are owed, what was paid,
/// the expenses and the cash in hand. Everything is kept in the owner's shared
/// documents (see owner_docs.dart) and worked out from the real chits.

// ---------------------------------------------------------------- settings
/// Purchases are counted from this day (older dues go in as an opening balance).
DateTime khataFrom() {
  final Object? v = prefDoc.data['khataFrom'];
  final DateTime? d = v == null ? null : DateTime.tryParse('$v');
  if (d != null) return dayOf(d);
  final DateTime n = DateTime.now();
  return DateTime(n.year, n.month, 1);
}

bool khataFromSet() => prefDoc.data['khataFrom'] != null;

Future<void> setKhataFrom(DateTime d) {
  return prefDoc.commit(() {
    prefDoc.data['khataFrom'] = dayKey(d);
  });
}

/// 0 = farmers are paid on the net weight (after bardan and kardo),
/// 1 = on the full weight.
int payOn() => prefDoc.num0('payOn', 0).round();

Future<void> setPayOn(int v) {
  return prefDoc.commit(() {
    prefDoc.data['payOn'] = v;
  });
}

/// The weight a chit is paid on.
double payKg(Chit c) {
  if (payOn() == 1) return c.cmpKg;
  return c.net > 0 ? c.net : c.cmpKg;
}

/// Rupees for one chit (null when no rate is set for that material and day).
double? chitAmount(Chit c) {
  final double? r = rateFor(c.commodity.trim(), c.at);
  if (r == null) return null;
  return payKg(c) / 20 * r;
}

// ---------------------------------------------------------------- payments
class PayItem {
  final String id;
  final String key;
  final String label;
  final DateTime date;
  final double amt;
  final String kind; // pay | adv | recv | open
  final String mode; // cash | upi | bank | cheque
  final String note;
  final DateTime at;
  final int no; // voucher number (0 = not numbered yet)
  final String ref; // UTR / cheque number
  final String jt; // journal type of an 'open' entry: '' = plain journal, 'dn' = Debit Note (purchase return)
  const PayItem(this.id, this.key, this.label, this.date, this.amt, this.kind, this.mode, this.note, this.at, {this.no = 0, this.ref = '', this.jt = ''});

  /// How much this entry changes what we owe the farmer.
  double get effect => (kind == 'pay' || kind == 'adv') ? -amt : amt;
}

const List<List<String>> kPayKinds = <List<String>>[
  <String>['pay', 'ચૂકવ્યા', 'Paid'],
  <String>['adv', 'એડવાન્સ / ઉપાડ', 'Advance'],
  <String>['recv', 'પાછા લીધા', 'Taken back'],
  <String>['open', 'જૂનું બાકી', 'Old balance'],
];

const List<List<String>> kPayModes = <List<String>>[
  <String>['cash', 'રોકડ', 'Cash'],
  <String>['upi', 'UPI', 'UPI'],
  <String>['bank', 'બેંક', 'Bank'],
  <String>['cheque', 'ચેક', 'Cheque'],
];

String payKindLabel(String code) {
  for (final List<String> k in kPayKinds) {
    if (k[0] == code) return bi(k[1], k[2]);
  }
  return code;
}

/// Name of a payment-document entry, a Debit Note being told apart from a plain journal.
String payItemLabel(PayItem p) => p.jt == 'dn' ? bi('ડેબિટ નોટ (ખરીદ પરત)', 'Debit Note (purchase return)') : payKindLabel(p.kind);

String payModeLabel(String code) {
  for (final List<String> k in kPayModes) {
    if (k[0] == code) return bi(k[1], k[2]);
  }
  return code;
}

List<PayItem> payItems() {
  final List<PayItem> out = <PayItem>[];
  for (final Map<String, dynamic> m in payDoc.list('items')) {
    final DateTime? d = DateTime.tryParse('${m['date'] ?? ''}');
    if (d == null) continue;
    out.add(PayItem(
      '${m['id'] ?? ''}',
      '${m['key'] ?? ''}',
      '${m['label'] ?? ''}',
      dayOf(d),
      dbl(m['amt']),
      '${m['kind'] ?? 'pay'}',
      '${m['mode'] ?? 'cash'}',
      '${m['note'] ?? ''}',
      DateTime.tryParse('${m['at'] ?? ''}') ?? d,
      no: vnoOf(m['no']),
      ref: '${m['ref'] ?? ''}',
      jt: '${m['jt'] ?? ''}',
    ));
  }
  out.sort((PayItem a, PayItem b) {
    final int c = b.date.compareTo(a.date);
    return c != 0 ? c : b.at.compareTo(a.at);
  });
  return out;
}

Future<void> addPayItem({
  required String key,
  required String label,
  required double amt,
  required String kind,
  required String mode,
  required DateTime date,
  String note = '',
  String ref = '',
  String jt = '',
}) async {
  await ensureVoucherNumbers();
  await payDoc.commit(() {
    final List<Map<String, dynamic>> l = payDoc.list('items');
    l.add(<String, dynamic>{
      'id': '${DateTime.now().microsecondsSinceEpoch}',
      'key': key,
      'label': label,
      'date': dayKey(date),
      'amt': amt,
      'kind': kind,
      'mode': mode,
      'note': note.trim(),
      'ref': ref.trim(),
      if (jt.isNotEmpty) 'jt': jt,
      'no': nextVoucherNo(payCode(kind, jt: jt)),
      'at': DateTime.now().toIso8601String(),
    });
  });
}

/// Alter a payment voucher (keeps its id, number and time of entry).
Future<void> updatePayItem(
  String id, {
  required String key,
  required String label,
  required double amt,
  required String kind,
  required String mode,
  required DateTime date,
  String note = '',
  String ref = '',
}) {
  return payDoc.commit(() {
    for (final Map<String, dynamic> m in payDoc.list('items')) {
      if ('${m['id']}' != id) continue;
      m['key'] = key;
      m['label'] = label;
      m['date'] = dayKey(date);
      m['amt'] = amt;
      m['kind'] = kind;
      m['mode'] = mode;
      m['note'] = note.trim();
      m['ref'] = ref.trim();
      m['alt'] = DateTime.now().toIso8601String();
    }
  });
}

Future<void> removePayItem(String id) {
  return payDoc.commit(() {
    payDoc.list('items').removeWhere((Map<String, dynamic> m) => '${m['id']}' == id);
  });
}

// ----------------------------------------------------------- farmer accounts
class FarmerAcct {
  final String key;
  String label;
  double purchase = 0;
  double paid = 0;
  double adv = 0;
  double recv = 0;
  double open = 0;
  double kg = 0;
  double noRateKg = 0;
  int chits = 0;
  DateTime? lastChit;
  DateTime? lastPay;
  FarmerAcct(this.key, this.label);

  /// What we still owe the farmer (negative = he owes us).
  double get balance => purchase + open + recv - paid - adv;
  double get given => paid + adv;
}

Map<String, FarmerAcct> farmerAccts() {
  final DateTime from = khataFrom();
  final Map<String, FarmerAcct> m = <String, FarmerAcct>{};
  FarmerAcct acctOf(String k, String label) => m.putIfAbsent(k, () => FarmerAcct(k, label));
  for (final Chit c in live.chits) {
    if (c.at.isBefore(from)) continue;
    final String k = nameKey(c.farmer);
    if (k.isEmpty) continue;
    final FarmerAcct a = acctOf(k, c.farmer);
    a.chits++;
    final double kg = payKg(c);
    a.kg += kg;
    final double? amt = chitAmount(c);
    if (amt == null) {
      a.noRateKg += kg;
    } else {
      a.purchase += amt;
    }
    final DateTime? lc = a.lastChit;
    if (lc == null || c.at.isAfter(lc)) a.lastChit = c.at;
  }
  for (final PayItem p in payItems()) {
    if (p.kind != 'open' && p.date.isBefore(from)) continue;
    final FarmerAcct a = acctOf(p.key, p.label);
    if (p.kind == 'pay') {
      a.paid += p.amt;
    } else if (p.kind == 'adv') {
      a.adv += p.amt;
    } else if (p.kind == 'recv') {
      a.recv += p.amt;
    } else {
      a.open += p.amt;
    }
    final DateTime? lp = a.lastPay;
    if (p.kind != 'open' && (lp == null || p.date.isAfter(lp))) a.lastPay = p.date;
  }
  return m;
}

/// Latest mobile number written on a chit of this farmer ('' when none).
String farmerMobile(String key) {
  DateTime at = DateTime(2000);
  String best = '';
  for (final Chit c in live.chits) {
    if (nameKey(c.farmer) != key) continue;
    final String d = c.mobile.replaceAll(RegExp(r'[^0-9]'), '');
    if (d.length >= 10 && c.at.isAfter(at)) {
      at = c.at;
      best = d.substring(d.length - 10);
    }
  }
  return best;
}

// ----------------------------------------------------------------- expenses
class ExpItem {
  final String id;
  final DateTime date;
  final double amt;
  final String cat;
  final String note;
  final String kind; // out | in
  final String mode; // cash | upi | bank | cheque
  final DateTime at;
  final int no; // voucher number (0 = not numbered yet)
  final String ref; // UTR / cheque number
  const ExpItem(this.id, this.date, this.amt, this.cat, this.note, this.kind, this.mode, this.at, {this.no = 0, this.ref = ''});
  bool get isIn => kind == 'in';
}

/// The expense head that stands for "GST paid to the Government" (a payment against Duties & Taxes, not a cost).
const String kGstHead = 'gst';

const List<List<String>> kExpCats = <List<String>>[
  <String>['labour', 'મજૂરી', 'Labour'],
  <String>['freight', 'ભાડું', 'Freight'],
  <String>['diesel', 'ડીઝલ', 'Diesel'],
  <String>['power', 'લાઇટ બિલ', 'Electricity'],
  <String>['salary', 'પગાર', 'Salary'],
  <String>['tea', 'ચા-નાસ્તો', 'Tea & snacks'],
  <String>['repair', 'રિપેર', 'Repair'],
  <String>['broker', 'દલાલી', 'Brokerage'],
  <String>['other', 'બીજું', 'Other'],
  <String>['gst', 'GST ભરણું (સરકારને)', 'GST paid to Govt'],
];

/// The expense heads shown when a new expense is entered (the GST head is left out while GST is off).
List<List<String>> get kExpCatsShown => kGstOn ? kExpCats : <List<String>>[for (final List<String> k in kExpCats) if (k[0] != kGstHead) k];

/// Where money received comes from.
const List<List<String>> kInCats = <List<String>>[
  <String>['sale', 'વેચાણથી', 'From sales'],
  <String>['loan', 'ઉધાર / લોન', 'Loan'],
  <String>['inother', 'બીજી આવક', 'Other income'],
];

String expCatLabel(String code) {
  for (final List<String> k in kExpCats) {
    if (k[0] == code) return bi(k[1], k[2]);
  }
  for (final List<String> k in kInCats) {
    if (k[0] == code) return bi(k[1], k[2]);
  }
  return code;
}

List<ExpItem> expItems() {
  final List<ExpItem> out = <ExpItem>[];
  for (final Map<String, dynamic> m in expDoc.list('items')) {
    final DateTime? d = DateTime.tryParse('${m['date'] ?? ''}');
    if (d == null) continue;
    out.add(ExpItem(
      '${m['id'] ?? ''}',
      dayOf(d),
      dbl(m['amt']),
      '${m['cat'] ?? 'other'}',
      '${m['note'] ?? ''}',
      '${m['kind'] ?? 'out'}',
      '${m['mode'] ?? 'cash'}',
      DateTime.tryParse('${m['at'] ?? ''}') ?? d,
      no: vnoOf(m['no']),
      ref: '${m['ref'] ?? ''}',
    ));
  }
  out.sort((ExpItem a, ExpItem b) {
    final int c = b.date.compareTo(a.date);
    return c != 0 ? c : b.at.compareTo(a.at);
  });
  return out;
}

Future<void> addExpItem({
  required double amt,
  required String cat,
  required String kind,
  required String mode,
  required DateTime date,
  String note = '',
  String ref = '',
}) async {
  await ensureVoucherNumbers();
  await expDoc.commit(() {
    final List<Map<String, dynamic>> l = expDoc.list('items');
    l.add(<String, dynamic>{
      'id': '${DateTime.now().microsecondsSinceEpoch}',
      'date': dayKey(date),
      'amt': amt,
      'cat': cat,
      'note': note.trim(),
      'ref': ref.trim(),
      'kind': kind,
      'mode': mode,
      'no': nextVoucherNo(expCode(kind)),
      'at': DateTime.now().toIso8601String(),
    });
  });
}

/// Alter an expense / income voucher (keeps its id, number and time of entry).
Future<void> updateExpItem(
  String id, {
  required double amt,
  required String cat,
  required String kind,
  required String mode,
  required DateTime date,
  String note = '',
  String ref = '',
}) {
  return expDoc.commit(() {
    for (final Map<String, dynamic> m in expDoc.list('items')) {
      if ('${m['id']}' != id) continue;
      m['date'] = dayKey(date);
      m['amt'] = amt;
      m['cat'] = cat;
      m['kind'] = kind;
      m['mode'] = mode;
      m['note'] = note.trim();
      m['ref'] = ref.trim();
      m['alt'] = DateTime.now().toIso8601String();
    }
  });
}

Future<void> removeExpItem(String id) {
  return expDoc.commit(() {
    expDoc.list('items').removeWhere((Map<String, dynamic> m) => '${m['id']}' == id);
  });
}

// -------------------------------------------------------------------- cash
class CashLine {
  final DateTime date;
  final DateTime at;
  final String title;
  final String sub;
  final double amt;
  final bool isIn;
  const CashLine(this.date, this.at, this.title, this.sub, this.amt, this.isIn);
}

double cashSeed() => prefDoc.num0('cashOpen', 0);

DateTime? cashSeedDate() {
  final Object? v = prefDoc.data['cashOpenDate'];
  if (v == null) return null;
  final DateTime? d = DateTime.tryParse('$v');
  return d == null ? null : dayOf(d);
}

Future<void> setCashSeed(double amt, DateTime day) {
  return prefDoc.commit(() {
    prefDoc.data['cashOpen'] = amt;
    prefDoc.data['cashOpenDate'] = dayKey(day);
  });
}

/// Every movement of cash (not bank / UPI): payments to farmers, expenses and
/// money received.
List<CashLine> cashLines() {
  final List<CashLine> out = <CashLine>[];
  for (final PayItem p in payItems()) {
    if (p.mode != 'cash' || p.kind == 'open') continue;
    final bool inn = p.kind == 'recv';
    out.add(CashLine(p.date, p.at, p.label, '${payKindLabel(p.kind)}${p.note.isEmpty ? '' : ' · ${p.note}'}', p.amt, inn));
  }
  for (final ExpItem e in expItems()) {
    if (e.mode != 'cash') continue;
    out.add(CashLine(e.date, e.at, expCatLabel(e.cat), e.note, e.amt, e.isIn));
  }
  for (final SaleItem x in saleItems()) {
    if (x.kind != 'recv' || x.mode != 'cash') continue;
    out.add(CashLine(x.date, x.at, x.buyer, '${bi('ખરીદનાર પાસેથી', 'From buyer')}${x.note.isEmpty ? '' : ' · ${x.note}'}', x.amt, true));
  }
  // contra: cash deposited into the bank goes out of the cash, cash taken from the bank comes in
  for (final ContraItem c in contraItems()) {
    out.add(CashLine(c.date, c.at, contraBankName(), '${bi('કોન્ટ્રા', 'Contra')}${c.note.isEmpty ? '' : ' · ${c.note}'}', c.amt, !c.dep));
  }
  out.sort((CashLine a, CashLine b) => a.at.compareTo(b.at));
  return out;
}

/// Cash in hand at the start of [day].
double cashOpening(DateTime day) {
  final DateTime? sd = cashSeedDate();
  double bal = sd == null ? 0 : cashSeed();
  for (final CashLine l in cashLines()) {
    if (sd != null && l.date.isBefore(sd)) continue;
    if (!l.date.isBefore(day)) continue;
    bal += l.isIn ? l.amt : -l.amt;
  }
  return bal;
}

// --------------------------------------------------------- brokerage, wages
/// Brokerage in Rs per 20 KG for all brokers unless one has his own rate.
double brokerRateDefault() => prefDoc.num0('brokerRate', 0);

double brokerRateOf(String key) {
  final Object? m = prefDoc.data['brokerRates'];
  if (m is Map) {
    final Object? v = m[key];
    if (v is num) return v.toDouble();
    if (v is String) return double.tryParse(v) ?? brokerRateDefault();
  }
  return brokerRateDefault();
}

bool brokerHasOwnRate(String key) {
  final Object? m = prefDoc.data['brokerRates'];
  return m is Map && m[key] != null;
}

Future<void> setBrokerDefault(double r) {
  return prefDoc.commit(() {
    prefDoc.data['brokerRate'] = r;
  });
}

Future<void> setBrokerRate(String key, double? r) {
  return prefDoc.commit(() {
    final Map<String, dynamic> m = prefDoc.map('brokerRates');
    if (r == null) {
      m.remove(key);
    } else {
      m[key] = r;
    }
  });
}

/// Labour rate per bag: unloading (in) and loading (out).
double wageIn() => prefDoc.num0('wageIn', 0);
double wageOut() => prefDoc.num0('wageOut', 0);

Future<void> setWages(double inRate, double outRate) {
  return prefDoc.commit(() {
    prefDoc.data['wageIn'] = inRate;
    prefDoc.data['wageOut'] = outRate;
  });
}

/// Wages for a set of maal entries.
double wagesOf(Iterable<MaalRow> rows) {
  double t = 0;
  for (final MaalRow m in rows) {
    t += m.bags * (m.loading ? wageOut() : wageIn());
  }
  return t;
}
