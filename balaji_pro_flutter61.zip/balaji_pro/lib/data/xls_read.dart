import 'dart:convert';
import 'dart:typed_data';

// ======================================================================
// The old Excel file (.xls, BIFF8) - what many weighbridge terminals / programs export.
//  - pure Dart, no plug-in: reads the OLE2 container, then the cells of the first sheet
//  - text, numbers, RK numbers and dates are read; formulas give their last result
//  - anything that cannot be read throws a FormatException (the screen says "save as CSV")
// ======================================================================

int _u16(Uint8List d, int o) => d[o] | (d[o + 1] << 8);
int _u32(Uint8List d, int o) => (d[o] | (d[o + 1] << 8) | (d[o + 2] << 16) | (d[o + 3] << 24)) & 0xFFFFFFFF;

const int _endChain = 0xFFFFFFFE;

/// The bytes of one stream of an OLE2 (compound) file.
Uint8List _oleStream(Uint8List d, bool Function(String name) want) {
  if (d.length < 512) throw const FormatException('ole');
  final int ss = 1 << _u16(d, 0x1E);
  final int ms = 1 << _u16(d, 0x20);
  final int nFat = _u32(d, 0x2C);
  final int dirStart = _u32(d, 0x30);
  final int cutoff = _u32(d, 0x38);
  final int miniFatStart = _u32(d, 0x3C);
  final int difatStart = _u32(d, 0x44);
  final int nDifat = _u32(d, 0x48);
  int off(int sid) => (sid + 1) * ss;
  if (ss < 128 || ss > 65536) throw const FormatException('ole');

  // the sectors that hold the FAT
  final List<int> fatSecs = <int>[];
  for (int i = 0; i < 109 && fatSecs.length < nFat; i++) {
    final int v = _u32(d, 0x4C + i * 4);
    if (v < 0xFFFFFFF0) fatSecs.add(v);
  }
  int ds = difatStart;
  for (int n = 0; n < nDifat && ds < 0xFFFFFFF0 && fatSecs.length < nFat; n++) {
    final int o = off(ds);
    if (o + ss > d.length) break;
    for (int i = 0; i < ss ~/ 4 - 1 && fatSecs.length < nFat; i++) {
      final int v = _u32(d, o + i * 4);
      if (v < 0xFFFFFFF0) fatSecs.add(v);
    }
    ds = _u32(d, o + ss - 4);
  }
  final List<int> fat = <int>[];
  for (final int s in fatSecs) {
    final int o = off(s);
    if (o + ss > d.length) break;
    for (int i = 0; i < ss ~/ 4; i++) {
      fat.add(_u32(d, o + i * 4));
    }
  }

  Uint8List chain(int start, int size) {
    final BytesBuilder b = BytesBuilder(copy: false);
    int s = start;
    int guard = 0;
    while (s < 0xFFFFFFF0 && s < fat.length && guard++ < 1000000) {
      final int o = off(s);
      if (o + ss > d.length) {
        if (o < d.length) b.add(Uint8List.sublistView(d, o, d.length));
        break;
      }
      b.add(Uint8List.sublistView(d, o, o + ss));
      s = fat[s];
    }
    final Uint8List all = b.toBytes();
    return size >= 0 && size < all.length ? Uint8List.sublistView(all, 0, size) : all;
  }

  // the directory
  final Uint8List dir = chain(dirStart, -1);
  int rootStart = _endChain;
  int rootSize = 0;
  int wbStart = -1;
  int wbSize = 0;
  for (int o = 0; o + 128 <= dir.length; o += 128) {
    final int nameLen = _u16(dir, o + 64);
    if (nameLen < 2 || nameLen > 64) continue;
    final String name = String.fromCharCodes(<int>[for (int i = 0; i < nameLen ~/ 2 - 1; i++) _u16(dir, o + i * 2)]);
    final int type = dir[o + 66];
    final int start = _u32(dir, o + 116);
    final int size = _u32(dir, o + 120);
    if (type == 5) {
      rootStart = start;
      rootSize = size;
    } else if (type == 2 && wbStart < 0 && want(name)) {
      wbStart = start;
      wbSize = size;
    }
  }
  if (wbStart < 0) throw const FormatException('no workbook');
  if (wbSize >= cutoff) return chain(wbStart, wbSize);

  // a small stream lives in the "mini stream"
  final Uint8List mini = chain(rootStart, rootSize);
  final Uint8List miniFatBytes = chain(miniFatStart, -1);
  final List<int> miniFat = <int>[for (int i = 0; i + 4 <= miniFatBytes.length; i += 4) _u32(miniFatBytes, i)];
  final BytesBuilder b = BytesBuilder(copy: false);
  int s = wbStart;
  int guard = 0;
  while (s < 0xFFFFFFF0 && s < miniFat.length && guard++ < 100000) {
    final int o = s * ms;
    if (o + ms > mini.length) break;
    b.add(Uint8List.sublistView(mini, o, o + ms));
    s = miniFat[s];
  }
  final Uint8List all = b.toBytes();
  return wbSize < all.length ? Uint8List.sublistView(all, 0, wbSize) : all;
}

class _Rec {
  final int id;
  final Uint8List data;
  const _Rec(this.id, this.data);
}

/// Reads strings of the shared string table, whose records may be cut by CONTINUE records.
class _Cur {
  final List<Uint8List> chunks;
  int c = 0;
  int p = 0;
  _Cur(this.chunks);

  bool get done => c >= chunks.length;

  void _norm() {
    while (c < chunks.length && p >= chunks[c].length) {
      c++;
      p = 0;
    }
  }

  int u8() {
    _norm();
    if (done) throw const FormatException('sst');
    return chunks[c][p++];
  }

  int u16() {
    final int a = u8();
    return a | (u8() << 8);
  }

  int u32() {
    final int a = u16();
    return a | (u16() << 16);
  }

  void skip(int n) {
    while (n > 0) {
      _norm();
      if (done) throw const FormatException('sst');
      final int take = (chunks[c].length - p) < n ? chunks[c].length - p : n;
      p += take;
      n -= take;
    }
  }

  /// [cch] characters; when the record ends inside the text, the next record starts with a new "wide" flag byte.
  String chars(int cch, bool wide) {
    final StringBuffer b = StringBuffer();
    int left = cch;
    while (left > 0) {
      if (p >= chunks[c].length) {
        c++;
        p = 0;
        if (done) throw const FormatException('sst');
        wide = (chunks[c][p++] & 1) == 1;
        continue;
      }
      final int avail = chunks[c].length - p;
      final int n = wide ? (avail ~/ 2 < left ? avail ~/ 2 : left) : (avail < left ? avail : left);
      if (n == 0) {
        // one byte of a wide char left at the end: join it with the next record
        c++;
        p = 0;
        if (done) throw const FormatException('sst');
        wide = (chunks[c][p++] & 1) == 1;
        continue;
      }
      for (int i = 0; i < n; i++) {
        if (wide) {
          b.writeCharCode(chunks[c][p] | (chunks[c][p + 1] << 8));
          p += 2;
        } else {
          b.writeCharCode(chunks[c][p++]);
        }
      }
      left -= n;
    }
    return b.toString();
  }
}

String _sstString(_Cur r) {
  final int cch = r.u16();
  final int flags = r.u8();
  final bool wide = (flags & 1) == 1;
  final bool ext = (flags & 4) != 0;
  final bool rich = (flags & 8) != 0;
  final int runs = rich ? r.u16() : 0;
  final int extLen = ext ? r.u32() : 0;
  final String s = r.chars(cch, wide);
  if (runs > 0) r.skip(runs * 4);
  if (extLen > 0) r.skip(extLen);
  return s;
}

/// A string inside one record (LABEL, STRING): length, flags, characters.
String _recString(Uint8List d, int o, bool biff8) {
  if (!biff8) {
    final int n = _u16(d, o);
    return latin1.decode(d.sublist(o + 2, o + 2 + n));
  }
  final int cch = _u16(d, o);
  final int flags = d[o + 2];
  int p = o + 3;
  if ((flags & 8) != 0) p += 2;
  if ((flags & 4) != 0) p += 4;
  if ((flags & 1) == 1) {
    return String.fromCharCodes(<int>[for (int i = 0; i < cch && p + i * 2 + 1 < d.length; i++) _u16(d, p + i * 2)]);
  }
  return latin1.decode(d.sublist(p, p + cch > d.length ? d.length : p + cch));
}

double _rk(int v) {
  double x;
  if ((v & 2) != 0) {
    int i = v >> 2;
    if ((i & 0x20000000) != 0) i -= 0x40000000;
    x = i.toDouble();
  } else {
    final ByteData bd = ByteData(8);
    bd.setUint32(4, v & 0xFFFFFFFC, Endian.little);
    bd.setUint32(0, 0, Endian.little);
    x = bd.getFloat64(0, Endian.little);
  }
  if ((v & 1) != 0) x /= 100;
  return x;
}

String _numText(double v) {
  if (v == v.roundToDouble() && v.abs() < 1e15) return v.toInt().toString();
  return v.toString();
}

String _serialDateText(double v) {
  final DateTime d = DateTime.utc(1899, 12, 30).add(Duration(seconds: (v * 86400).round()));
  String t2(int x) => x.toString().padLeft(2, '0');
  final String day = '${t2(d.day)}/${t2(d.month)}/${d.year}';
  return (d.hour != 0 || d.minute != 0) ? '$day ${t2(d.hour)}:${t2(d.minute)}' : day;
}

bool _isDateFmt(int id, Map<int, String> custom) {
  if ((id >= 14 && id <= 22) || (id >= 45 && id <= 47)) return true;
  final String? code = custom[id];
  if (code == null) return false;
  final String c = code.replaceAll(RegExp(r'"[^"]*"|\[[^\]]*\]|\\.'), '');
  return RegExp(r'[dmyDMY]').hasMatch(c) && !RegExp(r'0\.0|#').hasMatch(c);
}

/// The first sheet of an old .xls file as a table of text cells.
List<List<String>> wbXlsTable(List<int> bytes) {
  final Uint8List d = bytes is Uint8List ? bytes : Uint8List.fromList(bytes);
  final Uint8List wb = _oleStream(d, (String n) => n.toLowerCase() == 'workbook' || n.toLowerCase() == 'book');

  // all records
  final List<_Rec> recs = <_Rec>[];
  final List<int> starts = <int>[];
  int p = 0;
  while (p + 4 <= wb.length) {
    final int id = _u16(wb, p);
    final int len = _u16(wb, p + 2);
    if (p + 4 + len > wb.length) break;
    starts.add(p);
    recs.add(_Rec(id, Uint8List.sublistView(wb, p + 4, p + 4 + len)));
    p += 4 + len;
  }

  bool biff8 = true;
  final Map<int, String> fmts = <int, String>{};
  final List<int> xfFmt = <int>[];
  final List<String> sst = <String>[];
  int sheetStart = -1;

  // workbook globals (up to the first sheet)
  int i = 0;
  for (; i < recs.length; i++) {
    final _Rec r = recs[i];
    if (r.id == 0x809 && r.data.length >= 2) {
      biff8 = _u16(r.data, 0) >= 0x0600;
    } else if (r.id == 0x85 && r.data.length >= 8 && sheetStart < 0) {
      final int type = r.data[5];
      if (type == 0) sheetStart = _u32(r.data, 0);
    } else if (r.id == 0x41E && r.data.length >= 4) {
      final int id = _u16(r.data, 0);
      try {
        fmts[id] = _recString(r.data, 2, biff8);
      } catch (_) {}
    } else if (r.id == 0xE0 && r.data.length >= 4) {
      xfFmt.add(_u16(r.data, 2));
    } else if (r.id == 0xFC && biff8) {
      // the string table: this record + the CONTINUE records after it
      final List<Uint8List> chunks = <Uint8List>[Uint8List.sublistView(r.data, 8)];
      int j = i + 1;
      while (j < recs.length && recs[j].id == 0x3C) {
        chunks.add(recs[j].data);
        j++;
      }
      final int unique = _u32(r.data, 4);
      final _Cur cur = _Cur(chunks);
      try {
        for (int k = 0; k < unique; k++) {
          sst.add(_sstString(cur));
        }
      } catch (_) {}
      i = j - 1;
    } else if (r.id == 0x0A) {
      break;
    }
  }
  if (sheetStart < 0) throw const FormatException('no sheet');

  // the cells of the first sheet
  int k = starts.indexOf(sheetStart);
  if (k < 0) throw const FormatException('sheet position');
  final Map<int, Map<int, String>> cells = <int, Map<int, String>>{};
  int depth = 0;
  int lastFormulaRow = -1;
  int lastFormulaCol = -1;
  String cellVal(double v, int xf) {
    final int fid = xf >= 0 && xf < xfFmt.length ? xfFmt[xf] : 0;
    return _isDateFmt(fid, fmts) ? _serialDateText(v) : _numText(v);
  }

  void put(int row, int col, String v) {
    (cells[row] ??= <int, String>{})[col] = v;
  }

  for (; k < recs.length; k++) {
    final _Rec r = recs[k];
    final Uint8List x = r.data;
    if (r.id == 0x809) {
      depth++;
      if (depth > 1) break;
    } else if (r.id == 0x0A) {
      break;
    } else if (r.id == 0xFD && x.length >= 10) {
      final int ix = _u32(x, 6);
      put(_u16(x, 0), _u16(x, 2), ix < sst.length ? sst[ix] : '');
    } else if (r.id == 0x204 && x.length >= 8) {
      try {
        put(_u16(x, 0), _u16(x, 2), _recString(x, 6, biff8));
      } catch (_) {}
    } else if (r.id == 0x203 && x.length >= 14) {
      put(_u16(x, 0), _u16(x, 2), cellVal(ByteData.sublistView(x, 6, 14).getFloat64(0, Endian.little), _u16(x, 4)));
    } else if (r.id == 0x27E && x.length >= 10) {
      put(_u16(x, 0), _u16(x, 2), cellVal(_rk(_u32(x, 6)), _u16(x, 4)));
    } else if (r.id == 0xBD && x.length >= 6) {
      final int row = _u16(x, 0);
      final int c0 = _u16(x, 2);
      final int n = (x.length - 6) ~/ 6;
      for (int q = 0; q < n; q++) {
        final int o = 4 + q * 6;
        put(row, c0 + q, cellVal(_rk(_u32(x, o + 2)), _u16(x, o)));
      }
    } else if (r.id == 0x06 && x.length >= 14) {
      final int row = _u16(x, 0);
      final int col = _u16(x, 2);
      if (x[12] == 0xFF && x[13] == 0xFF) {
        // text result follows in a STRING record
        lastFormulaRow = row;
        lastFormulaCol = col;
      } else {
        put(row, col, cellVal(ByteData.sublistView(x, 6, 14).getFloat64(0, Endian.little), _u16(x, 4)));
      }
    } else if (r.id == 0x207 && lastFormulaRow >= 0) {
      try {
        put(lastFormulaRow, lastFormulaCol, _recString(x, 0, biff8));
      } catch (_) {}
      lastFormulaRow = -1;
    }
  }

  if (cells.isEmpty) return <List<String>>[];
  final List<int> rows = cells.keys.toList()..sort();
  final List<List<String>> out = <List<String>>[];
  int prev = rows.first;
  for (final int rw in rows) {
    while (prev < rw && out.length < 100000) {
      out.add(<String>[]);
      prev++;
    }
    final Map<int, String> m = cells[rw]!;
    final int width = m.keys.fold<int>(0, (int a, int b) => b > a ? b : a) + 1;
    out.add(<String>[for (int c = 0; c < width; c++) m[c] ?? '']);
    prev = rw + 1;
  }
  return out;
}

// ----------------------------------------------------------------------
// Some programs save a web page (HTML table) or an Excel-2003 XML file and call it ".xls".
// ----------------------------------------------------------------------

String _entities(String s) {
  return s.replaceAllMapped(RegExp(r'&(#x?[0-9a-fA-F]+|[a-zA-Z]+);'), (Match m) {
    final String e = m[1]!;
    if (e.startsWith('#x') || e.startsWith('#X')) {
      final int? v = int.tryParse(e.substring(2), radix: 16);
      return v == null || v <= 0 || v > 0x10FFFF ? '' : String.fromCharCode(v);
    }
    if (e.startsWith('#')) {
      final int? v = int.tryParse(e.substring(1));
      return v == null || v <= 0 || v > 0x10FFFF ? '' : String.fromCharCode(v);
    }
    switch (e.toLowerCase()) {
      case 'nbsp':
        return ' ';
      case 'amp':
        return '&';
      case 'lt':
        return '<';
      case 'gt':
        return '>';
      case 'quot':
        return '"';
      case 'apos':
        return "'";
    }
    return m[0]!;
  });
}

String _tagText(String s) => _entities(s.replaceAll(RegExp(r'<[^>]*>'), '')).replaceAll(RegExp(r'\s+'), ' ').trim();

/// The text is a web page with a table.
bool wbIsHtmlTable(String t) => RegExp(r'<tr[\s>]', caseSensitive: false).hasMatch(t) && RegExp(r'<t[dh][\s>]', caseSensitive: false).hasMatch(t);

/// The text is an Excel-2003 "XML spreadsheet".
bool wbIsSheetXml(String t) => t.contains('urn:schemas-microsoft-com:office:spreadsheet') && RegExp(r'<(ss:)?Row[\s>]', caseSensitive: false).hasMatch(t);

/// The rows of the first HTML table.
List<List<String>> wbHtmlTable(String html) {
  final List<List<String>> out = <List<String>>[];
  for (final RegExpMatch r in RegExp(r'<tr[^>]*>(.*?)</tr\s*>', caseSensitive: false, dotAll: true).allMatches(html)) {
    final List<String> row = <String>[];
    for (final RegExpMatch c in RegExp(r'<t[dh]([^>]*)>(.*?)(?=</t[dh]\s*>|<t[dh][\s>]|$)', caseSensitive: false, dotAll: true).allMatches(r[1]!)) {
      row.add(_tagText(c[2]!));
      final RegExpMatch? span = RegExp(r'colspan\s*=\s*"?(\d+)', caseSensitive: false).firstMatch(c[1] ?? '');
      final int n = span == null ? 1 : (int.tryParse(span[1]!) ?? 1).clamp(1, 50).toInt();
      for (int i = 1; i < n; i++) {
        row.add('');
      }
    }
    if (row.isNotEmpty) out.add(row);
    if (out.length >= 100000) break;
  }
  return out;
}

/// The rows of the first sheet of an Excel-2003 XML file.
List<List<String>> wbSheetXmlTable(String xml) {
  final List<List<String>> out = <List<String>>[];
  final RegExpMatch? ws = RegExp(r'<(?:ss:)?Worksheet[\s>].*?(?:</(?:ss:)?Worksheet\s*>|$)', caseSensitive: false, dotAll: true).firstMatch(xml);
  final String body = ws == null ? xml : ws[0]!;
  for (final RegExpMatch r in RegExp(r'<(?:ss:)?Row[^>]*?(?:/>|>(.*?)</(?:ss:)?Row\s*>)', caseSensitive: false, dotAll: true).allMatches(body)) {
    final List<String> row = <String>[];
    for (final RegExpMatch c in RegExp(r'<(?:ss:)?Cell([^>]*?)(?:/>|>(.*?)</(?:ss:)?Cell\s*>)', caseSensitive: false, dotAll: true).allMatches(r[1] ?? '')) {
      final RegExpMatch? idx = RegExp(r'(?:ss:)?Index\s*=\s*"(\d+)"', caseSensitive: false).firstMatch(c[1] ?? '');
      if (idx != null) {
        final int at = (int.tryParse(idx[1]!) ?? 1) - 1;
        while (row.length < at && row.length < 500) {
          row.add('');
        }
      }
      row.add(_tagText(c[2] ?? ''));
    }
    out.add(row);
    if (out.length >= 100000) break;
  }
  return out;
}
