import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'kanta_log.dart';
import 'kanta_slip.dart';
import 'kanta_usb.dart';
import 'live_store.dart';
import 'supa.dart';

// ======================================================================
// Remote weighing: the owner weighs from his PHONE, the weighbridge LAPTOP (Balaji Kanta) does it.
//
//   laptop  --(every few seconds)-->  table kanta_live   live weight, vehicles inside, last slips, "remote ON/OFF"
//   phone   --(a tap)------------->   table kanta_cmd    "first weight of GJ.. when the platform shows 11,385 kg"
//   laptop  reads the new command, takes the weight that STANDS STILL on the platform, answers done / error
//
// Safety:
//  - the laptop does it only when the operator has switched "Remote weighing" ON (a switch on the laptop itself)
//  - the phone sends the weight it SAW; the laptop refuses when the platform shows something else now (+-40 kg)
//  - a command older than 90 s is never run (the laptop may have been offline); each command is claimed once only
//  - who did it from the phone is written on the slip history and in the CSV of the laptop
//  - the weight is always the steady weight of the same terminal (same rules as at the laptop)
// ======================================================================

const String kRemoteStation = 'main';

/// The phone may differ from the platform by this much (kg) between "seen" and "taken".
const double kRemoteTolKg = 40;

double _d(Object? v, [double d = 0]) => v is num ? v.toDouble() : (double.tryParse('$v') ?? d);
String _s(Object? v) => v == null ? '' : '$v';
DateTime? _t(Object? v) => v == null ? null : DateTime.tryParse('$v')?.toLocal();
bool _b(Object? v) => v == true || v == 1 || v == 'true';

/// A vehicle that had its first weight and waits for the second one (as the phone sees it).
class RemoteInside {
  final String id;
  final String vehicle;
  final double kg;
  final DateTime at;
  final bool outside;
  final String party;
  final double charges;
  final String by;

  /// The mobile number written at the weighing and whether the charges were taken in cash (otherwise they are baki in the khata).
  final String mobile;
  final bool paid;
  const RemoteInside(this.id, this.vehicle, this.kg, this.at, {this.outside = false, this.party = '', this.charges = 0, this.by = '', this.mobile = '', this.paid = false});

  Map<String, Object> toJson() => <String, Object>{'id': id, 'v': vehicle, 'kg': kg, 'at': at.millisecondsSinceEpoch, 'o': outside ? 1 : 0, 'p': party, 'c': charges, 'by': by, if (mobile.isNotEmpty) 'mb': mobile, if (paid) 'pd': 1};

  static RemoteInside? fromJson(Object? j) {
    if (j is! Map) return null;
    final double kg = _d(j['kg']);
    final int ms = _d(j['at']).toInt();
    if (kg <= 0 || _s(j['id']).isEmpty) return null;
    return RemoteInside(_s(j['id']), _s(j['v']), kg, DateTime.fromMillisecondsSinceEpoch(ms), outside: _b(j['o']), party: _s(j['p']), charges: _d(j['c']), by: _s(j['by']), mobile: _s(j['mb']), paid: _b(j['pd']));
  }
}

/// A finished slip as the phone sees it (the last few).
class RemoteDone {
  final String rst;
  final String vehicle;
  final String party;
  final double gross;
  final double tare;
  final DateTime grossAt;
  final DateTime tareAt;
  final DateTime at;
  final bool outside;
  final bool undone;

  /// The laptop can still take this one back (it was made since the app was opened).
  final bool undoable;
  final double charges;
  final String by;
  const RemoteDone(this.rst, this.vehicle, this.party, this.gross, this.tare, this.grossAt, this.tareAt, this.at, {this.outside = false, this.undone = false, this.undoable = false, this.charges = 0, this.by = ''});

  double get net => gross - tare;

  Map<String, Object> toJson() => <String, Object>{
        'rst': rst,
        'v': vehicle,
        'p': party,
        'g': gross,
        't': tare,
        'ga': grossAt.millisecondsSinceEpoch,
        'ta': tareAt.millisecondsSinceEpoch,
        'at': at.millisecondsSinceEpoch,
        'o': outside ? 1 : 0,
        'u': undone ? 1 : 0,
        'uo': undoable ? 1 : 0,
        'c': charges,
        'by': by,
      };

  static RemoteDone? fromJson(Object? j) {
    if (j is! Map) return null;
    DateTime ms(Object? v) => DateTime.fromMillisecondsSinceEpoch(_d(v).toInt());
    return RemoteDone(_s(j['rst']), _s(j['v']), _s(j['p']), _d(j['g']), _d(j['t']), ms(j['ga']), ms(j['ta']), ms(j['at']), outside: _b(j['o']), undone: _b(j['u']), undoable: _b(j['uo']), charges: _d(j['c']), by: _s(j['by']));
  }

  /// The slip (for the WhatsApp text on the phone).
  SlipRec toSlip() => SlipRec(rst: rst, vehicle: vehicle, party: party, gross: gross, tare: tare, grossAt: grossAt, tareAt: tareAt, at: at, undone: undone, outside: outside, charges: charges, by: by);
}

/// The row the laptop keeps up to date (table kanta_live).
class RemoteLive {
  /// What the terminal shows now (null: laptop is not connected to the terminal).
  final double? kg;
  final bool stable;

  /// The weight stands still and is 100 kg or more - a weighing can be taken now.
  final bool steady;
  final bool connected;
  final bool remoteOn;
  final List<RemoteInside> inside;
  final List<RemoteDone> recent;
  final String operatorName;
  final int beat;
  final DateTime? updatedAt;
  const RemoteLive({this.kg, this.stable = false, this.steady = false, this.connected = false, this.remoteOn = false, this.inside = const <RemoteInside>[], this.recent = const <RemoteDone>[], this.operatorName = '', this.beat = 0, this.updatedAt});

  static RemoteLive fromRow(Map<String, dynamic> r) {
    final Object? w = r['weight_kg'];
    final List<RemoteInside> ins = <RemoteInside>[];
    final Object? i = r['inside'];
    if (i is List) {
      for (final Object? e in i) {
        final RemoteInside? x = RemoteInside.fromJson(e);
        if (x != null) ins.add(x);
      }
    }
    final List<RemoteDone> rec = <RemoteDone>[];
    final Object? c = r['recent'];
    if (c is List) {
      for (final Object? e in c) {
        final RemoteDone? x = RemoteDone.fromJson(e);
        if (x != null) rec.add(x);
      }
    }
    return RemoteLive(
      kg: w is num ? w.toDouble() : null,
      stable: _b(r['stable']),
      steady: _b(r['steady']),
      connected: _b(r['connected']),
      remoteOn: _b(r['remote_on']),
      inside: ins,
      recent: rec,
      operatorName: _s(r['operator_name']),
      beat: _d(r['beat']).toInt(),
      updatedAt: _t(r['updated_at']),
    );
  }
}

/// One command from the phone (table kanta_cmd).
class RemoteCmd {
  final String id;

  /// first | second | drop | undo
  final String kind;
  final String vehicle;

  /// second / drop: id of the vehicle inside; undo: the slip (RST) number; first: 'direct:<tare kg>' = direct weighing (tare written by hand).
  final String target;
  final bool outside;
  final String party;
  final double charges;

  /// The weight the person SAW on the phone (0: not checked).
  final double seenKg;
  final String byName;
  final String status;
  final String result;
  final double? kg;
  final String rst;
  final DateTime createdAt;
  const RemoteCmd({this.id = '', required this.kind, this.vehicle = '', this.target = '', this.outside = false, this.party = '', this.charges = 0, this.seenKg = 0, this.byName = '', this.status = 'new', this.result = '', this.kg, this.rst = '', required this.createdAt});

  Map<String, dynamic> toRow() => <String, dynamic>{
        'kind': kind,
        'vehicle': vehicle,
        'target': target,
        'outside': outside,
        'party': party,
        'charges': charges,
        'seen_kg': seenKg,
        'by_name': byName,
      };

  static RemoteCmd fromRow(Map<String, dynamic> r) {
    final Object? k = r['kg'];
    return RemoteCmd(
      id: _s(r['id']),
      kind: _s(r['kind']),
      vehicle: _s(r['vehicle']),
      target: _s(r['target']),
      outside: _b(r['outside']),
      party: _s(r['party']),
      charges: _d(r['charges']),
      seenKg: _d(r['seen_kg']),
      byName: _s(r['by_name']),
      status: _s(r['status']),
      result: _s(r['result']),
      kg: k is num ? k.toDouble() : null,
      rst: _s(r['rst']),
      createdAt: _t(r['created_at']) ?? DateTime.now(),
    );
  }
}

/// What came of a command.
class RemoteResult {
  final bool ok;

  /// '' when ok, otherwise a short code: remote off | stale | vehicle | no steady weight | changed | same weight | not inside | cannot undo | timeout | ...
  final String code;
  final double? kg;
  final String rst;
  const RemoteResult(this.ok, this.code, {this.kg, this.rst = ''});
}

/// The server side of it (replaced in tests).
abstract class RemoteApi {
  Future<Map<String, dynamic>> putLive(Map<String, dynamic> row);
  Future<RemoteLive?> getLive();
  Future<List<RemoteCmd>> newCmds();

  /// Takes the command for this laptop (new -> working). false: somebody else was quicker / it is gone.
  Future<bool> claim(String id);
  Future<void> finish(String id, {required bool ok, String result = '', double? kg, String rst = ''});
  Future<RemoteCmd> send(RemoteCmd c);
  Future<RemoteCmd?> cmd(String id);
  Future<void> cleanup(DateTime before);
}

class SupaRemoteApi implements RemoteApi {
  @override
  Future<Map<String, dynamic>> putLive(Map<String, dynamic> row) => live.supa.upsert('kanta_live', row, 'id');

  @override
  Future<RemoteLive?> getLive() async {
    final List<Map<String, dynamic>> r = await live.supa.select('kanta_live', <String, String>{'select': '*', 'id': 'eq.$kRemoteStation'}, limit: 1);
    return r.isEmpty ? null : RemoteLive.fromRow(r.first);
  }

  @override
  Future<List<RemoteCmd>> newCmds() async {
    final List<Map<String, dynamic>> r = await live.supa.select('kanta_cmd', <String, String>{'select': '*', 'status': 'eq.new', 'order': 'created_at.asc'}, limit: 10);
    return <RemoteCmd>[for (final Map<String, dynamic> x in r) RemoteCmd.fromRow(x)];
  }

  @override
  Future<bool> claim(String id) async {
    final List<Map<String, dynamic>> r = await live.supa.update('kanta_cmd', <String, String>{'id': 'eq.$id', 'status': 'eq.new'}, <String, dynamic>{'status': 'working'});
    return r.isNotEmpty;
  }

  @override
  Future<void> finish(String id, {required bool ok, String result = '', double? kg, String rst = ''}) async {
    await live.supa.update('kanta_cmd', <String, String>{'id': 'eq.$id'}, <String, dynamic>{
      'status': ok ? 'done' : 'error',
      'result': result,
      'kg': kg,
      'rst': rst,
      'done_at': DateTime.now().toUtc().toIso8601String(),
    });
  }

  @override
  Future<RemoteCmd> send(RemoteCmd c) async => RemoteCmd.fromRow(await live.supa.insert('kanta_cmd', c.toRow()));

  @override
  Future<RemoteCmd?> cmd(String id) async {
    final List<Map<String, dynamic>> r = await live.supa.select('kanta_cmd', <String, String>{'select': '*', 'id': 'eq.$id'}, limit: 1);
    return r.isEmpty ? null : RemoteCmd.fromRow(r.first);
  }

  @override
  Future<void> cleanup(DateTime before) async {
    await live.supa.delete('kanta_cmd', <String, String>{'created_at': 'lt.${before.toUtc().toIso8601String()}'});
  }
}

/// Is this error "the SQL for remote weighing was not run yet"?
bool remoteTableMissing(SupaError e) {
  final String m = '${e.message} ${e.code}'.toLowerCase();
  return e.status == 404 || e.code == 'PGRST205' || e.code == '42P01' || m.contains('schema cache') || m.contains('kanta_live') || m.contains('kanta_cmd');
}

// ----------------------------------------------------------------------------------------------- laptop

/// The laptop (Balaji Kanta): publishes the live state and carries out the commands of the phone.
class KantaRemoteHost extends ChangeNotifier {
  KantaRemoteHost(this.usb, this.api);

  final KantaUsbService usb;
  RemoteApi api;

  /// Is the user signed in (replaced in tests).
  bool Function() ready = () => live.signedIn;
  String Function() operatorName = () {
    try {
      return live.me?.name ?? '';
    } catch (_) {
      return '';
    }
  };

  /// The last slips, newest first (replaced in tests).
  List<SlipRec> Function() recentProvider = () => KantaHistory.items.take(8).toList();

  /// The operator's switch (kept on the laptop).
  bool on = false;

  /// '' | missing (SQL not run) | offline | perm | other
  String errKind = '';
  String error = '';
  DateTime? lastPublish;
  String lastCmd = '';
  int cmdsDone = 0;
  int cmdsRefused = 0;

  Duration skew = Duration.zero;
  Timer? _timer;
  bool _busy = false;
  bool _loaded = false;
  String _lastSig = '';
  DateTime _lastPub = DateTime.fromMillisecondsSinceEpoch(0);
  DateTime _lastPoll = DateTime.fromMillisecondsSinceEpoch(0);
  DateTime _lastClean = DateTime.fromMillisecondsSinceEpoch(0);
  DateTime _hold = DateTime.fromMillisecondsSinceEpoch(0);
  int _beat = 0;
  final List<(String, bool, String, double?, String)> _finishQ = <(String, bool, String, double?, String)>[];

  Future<void> load() async {
    if (_loaded) return;
    _loaded = true;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      on = p.getBool('kr_on') ?? false;
    } catch (_) {}
    notifyListeners();
  }

  /// Starts the background work (once a second it looks whether anything is due).
  void start() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (Timer _) => unawaited(tick()));
    unawaited(load().then((_) => tick()));
  }

  void stop() {
    _timer?.cancel();
    _timer = null;
  }

  Future<void> setOn(bool v) async {
    on = v;
    _lastSig = '';
    _lastPub = DateTime.fromMillisecondsSinceEpoch(0);
    _hold = DateTime.fromMillisecondsSinceEpoch(0);
    notifyListeners();
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setBool('kr_on', v);
    } catch (_) {}
    usb.note(v ? 'REMOTE weighing from phone: ON' : 'REMOTE weighing from phone: OFF', v ? 'ok' : 'info');
    await tick();
  }

  String _sig() {
    final double? kg = usb.connected ? usb.dec.kg : null;
    final String rec = recentProvider().take(8).map((SlipRec r) => '${r.rst}${r.undone ? 'u' : ''}').join(',');
    return '$on|${usb.connected}|${usb.dec.stable}|${kg == null ? '-' : (kg / 5).round()}|${usb.steadyKg != null}|${usb.inside.map((InsideVehicle v) => v.id).join(',')}|$rec';
  }

  /// Same rule as on the laptop: only today's entries can be taken back.
  bool _undoable(SlipRec r) {
    final DateTime n = DateTime.now();
    return !r.undone && r.at.year == n.year && r.at.month == n.month && r.at.day == n.day;
  }

  String _chitParty(String vehicle) {
    try {
      return usb.partyProvider(vehicle);
    } catch (_) {
      return '';
    }
  }

  Map<String, dynamic> _row() {
    final double? kg = usb.connected ? usb.dec.kg : null;
    final List<SlipRec> rec = recentProvider().take(8).toList();
    _beat = _beat < DateTime.now().millisecondsSinceEpoch ~/ 1000 ? DateTime.now().millisecondsSinceEpoch ~/ 1000 : _beat + 1;
    return <String, dynamic>{
      'id': kRemoteStation,
      'weight_kg': kg,
      'stable': usb.connected && usb.dec.stable,
      'steady': usb.steadyKg != null,
      'connected': usb.connected,
      'remote_on': on,
      'inside': <Object>[for (final InsideVehicle v in usb.inside) RemoteInside(v.id, v.vehicle, v.kg, v.at, outside: v.outside, party: v.party.isNotEmpty ? v.party : (v.outside ? '' : _chitParty(v.vehicle)), charges: v.charges, by: v.by, mobile: v.mobile, paid: v.paid).toJson()],
      'recent': <Object>[
        for (final SlipRec r in rec)
          RemoteDone(r.rst, r.vehicle, r.party, r.gross, r.tare, r.grossAt, r.tareAt, r.at, outside: r.outside, undone: r.undone, undoable: _undoable(r), charges: r.charges, by: r.by).toJson(),
      ],
      'operator_name': operatorName(),
      'beat': _beat,
    };
  }

  /// One round: sends the finished answers, publishes when due, takes the new commands. Never throws.
  Future<void> tick({DateTime? now}) async {
    if (_busy) return;
    final DateTime t = now ?? DateTime.now();
    if (t.isBefore(_hold) || !ready()) return;
    _busy = true;
    try {
      await _flushFinished();
      final bool due = t.difference(_lastPub) >= Duration(seconds: on ? 10 : 25);
      final String sig = _sig();
      final bool changed = sig != _lastSig && t.difference(_lastPub) >= const Duration(milliseconds: 1500);
      if (due || changed) {
        final Map<String, dynamic> r = await api.putLive(_row());
        _lastSig = sig;
        _lastPub = t;
        lastPublish = DateTime.now();
        final DateTime? su = _t(r['updated_at']);
        if (su != null) skew = su.difference(DateTime.now());
      }
      if (on && t.difference(_lastPoll) >= const Duration(milliseconds: 2500)) {
        _lastPoll = t;
        final List<RemoteCmd> cmds = await api.newCmds();
        for (final RemoteCmd c in cmds) {
          await _run(c);
        }
      }
      if (t.difference(_lastClean) >= const Duration(hours: 6)) {
        _lastClean = t;
        try {
          await api.cleanup(DateTime.now().subtract(const Duration(days: 3)));
        } catch (_) {}
      }
      if (error.isNotEmpty) {
        error = '';
        errKind = '';
        notifyListeners();
      }
    } on SupaError catch (e) {
      _fail(e, t);
    } catch (e) {
      errKind = 'other';
      error = '$e';
      _hold = t.add(const Duration(seconds: 15));
      notifyListeners();
    } finally {
      _busy = false;
    }
  }

  void _fail(SupaError e, DateTime t) {
    if (remoteTableMissing(e)) {
      errKind = 'missing';
      _hold = t.add(const Duration(seconds: 60));
    } else if (e.network) {
      errKind = 'offline';
      _hold = t.add(const Duration(seconds: 8));
    } else if (e.status == 401 || e.status == 403) {
      errKind = 'perm';
      _hold = t.add(const Duration(seconds: 30));
    } else {
      errKind = 'other';
      _hold = t.add(const Duration(seconds: 15));
    }
    error = e.message;
    notifyListeners();
  }

  Future<void> _flushFinished() async {
    while (_finishQ.isNotEmpty) {
      final (String, bool, String, double?, String) f = _finishQ.first;
      await api.finish(f.$1, ok: f.$2, result: f.$3, kg: f.$4, rst: f.$5);
      _finishQ.removeAt(0);
    }
  }

  /// Carries out one command of the phone.
  Future<void> _run(RemoteCmd c) async {
    if (!await api.claim(c.id)) return;
    final String name = c.byName.trim();
    final String who = name.isEmpty ? 'phone' : '$name (phone)';
    final int age = DateTime.now().add(skew).difference(c.createdAt).inSeconds;
    String err = '';
    double? kg;
    String rst = '';
    if (!on) {
      err = 'remote off';
    } else if (age > 90) {
      err = 'stale';
    } else {
      final double? st = usb.steadyKg;
      kg = st ?? (usb.connected ? usb.dec.kg : null);
      String checkWeight() {
        if (st == null) return 'no steady weight';
        if (c.seenKg > 0 && (st - c.seenKg).abs() > kRemoteTolKg) return 'changed';
        return '';
      }

      InsideVehicle? find() {
        for (final InsideVehicle v in usb.inside) {
          if (v.id == c.target) return v;
        }
        return null;
      }

      switch (c.kind) {
        case 'first':
          if (c.vehicle.trim().isEmpty) {
            err = 'vehicle';
          } else {
            err = checkWeight();
            if (err.isEmpty) {
              // the target carries the extras (the server only knows first / second / drop / undo): "direct:<tare>" = direct weighing,
              // a trailing ":paid" = the charges were paid in cash
              final bool paid = c.target.endsWith(':paid') || c.target == 'paid';
              final String tg = c.target.endsWith(':paid') ? c.target.substring(0, c.target.length - 5) : (c.target == 'paid' ? '' : c.target);
              if (tg.startsWith('direct:')) {
                // direct weighing: the tare was written by hand on the phone
                err = await usb.takeDirect(c.vehicle, double.tryParse(tg.substring(7)) ?? 0, outside: c.outside, party: c.party, charges: c.charges, paid: paid, by: who);
                if (err.isEmpty && usb.made.isNotEmpty) rst = usb.made.first.rst;
              } else {
                err = await usb.takeFirst(c.vehicle, outside: c.outside, party: c.party, charges: c.charges, paid: paid, by: who);
              }
            }
          }
        case 'second':
          final InsideVehicle? v = find();
          if (v == null) {
            err = 'not inside';
          } else {
            err = checkWeight();
            if (err.isEmpty) {
              err = await usb.takeSecond(v, by: who);
              if (err.isEmpty && usb.made.isNotEmpty) rst = usb.made.first.rst;
            }
          }
        case 'drop':
          final InsideVehicle? v = find();
          if (v == null) {
            err = 'not inside';
          } else {
            usb.dropInside(v);
          }
        case 'undo':
          AutoMade? m;
          for (final AutoMade x in usb.made) {
            if (x.rst == c.target && !x.undone) m = x;
          }
          if (m == null) {
            // made before the app was reopened: rebuilt from the slip history
            for (final SlipRec r in recentProvider()) {
              if (r.rst == c.target && _undoable(r)) {
                m = usb.autoMadeOf(r);
                break;
              }
            }
          }
          if (m == null) {
            err = 'cannot undo';
          } else {
            rst = m.rst;
            err = await usb.undoAuto(m);
          }
        default:
          err = 'unknown command';
      }
    }
    if (err.isEmpty) {
      cmdsDone++;
    } else {
      cmdsRefused++;
    }
    lastCmd = '${c.kind} ${c.vehicle.isEmpty ? c.target : c.vehicle} · $who · ${err.isEmpty ? 'OK' : err}';
    usb.note('PHONE ${c.kind} ${c.vehicle.isEmpty ? c.target : c.vehicle} · $who → ${err.isEmpty ? 'done' : 'refused: $err'}', err.isEmpty ? 'ok' : 'warn');
    _lastSig = ''; // publish the new state at once
    _finishQ.add((c.id, err.isEmpty, err, kg, rst));
    notifyListeners();
    await _flushFinished();
  }
}

// -------------------------------------------------------------------------------------------------- phone

/// The phone (Balaji Pro, owner): reads the live state and sends commands.
class KantaRemoteClient extends ChangeNotifier {
  KantaRemoteClient(this.api);

  RemoteApi api;
  RemoteLive? row;
  String errKind = '';
  String error = '';
  DateTime? fetchedAt;
  Timer? _t;
  int _users = 0;
  bool _busy = false;
  int _beat = -1;
  DateTime _beatAt = DateTime.fromMillisecondsSinceEpoch(0);

  /// The laptop is on line: its row was refreshed lately (by the clock, or the beat counter moved while we watch).
  bool get online {
    final RemoteLive? r = row;
    if (r == null) return false;
    if (DateTime.now().difference(_beatAt).inSeconds < 40 && _beatAt.millisecondsSinceEpoch > 0) return true;
    final DateTime? u = r.updatedAt;
    return u != null && DateTime.now().difference(u).inSeconds.abs() <= 60;
  }

  /// A weighing can be asked for now.
  bool get canWeigh => online && row != null && row!.remoteOn && row!.connected && row!.steady;

  /// Screens call this when they open / close; the polling runs while at least one is open.
  void attach() {
    _users++;
    if (_t == null) {
      unawaited(poll());
      _t = Timer.periodic(const Duration(seconds: 2), (Timer _) => unawaited(poll()));
    }
  }

  void detach() {
    _users--;
    if (_users <= 0) {
      _users = 0;
      _t?.cancel();
      _t = null;
    }
  }

  Future<void> poll() async {
    if (_busy) return;
    _busy = true;
    try {
      final RemoteLive? r = await api.getLive();
      if (r != null) {
        if (_beat >= 0 && r.beat != _beat) _beatAt = DateTime.now();
        _beat = r.beat;
      }
      row = r;
      fetchedAt = DateTime.now();
      errKind = '';
      error = '';
    } on SupaError catch (e) {
      errKind = remoteTableMissing(e) ? 'missing' : (e.network ? 'offline' : ((e.status == 401 || e.status == 403) ? 'perm' : 'other'));
      error = e.message;
    } catch (e) {
      errKind = 'other';
      error = '$e';
    } finally {
      _busy = false;
      notifyListeners();
    }
  }

  /// Sends a command and waits (up to [wait]) for the laptop's answer.
  Future<RemoteResult> send(RemoteCmd c, {Duration wait = const Duration(seconds: 25), Duration step = const Duration(milliseconds: 900)}) async {
    final RemoteCmd sent;
    try {
      sent = await api.send(c);
    } on SupaError catch (e) {
      return RemoteResult(false, remoteTableMissing(e) ? 'missing' : (e.network ? 'offline' : 'perm: ${e.message}'));
    } catch (e) {
      return RemoteResult(false, 'error: $e');
    }
    if (sent.id.isEmpty) return const RemoteResult(false, 'error: no id');
    final DateTime end = DateTime.now().add(wait);
    while (DateTime.now().isBefore(end)) {
      await Future<void>.delayed(step);
      try {
        final RemoteCmd? x = await api.cmd(sent.id);
        if (x != null && (x.status == 'done' || x.status == 'error')) {
          unawaited(poll());
          return RemoteResult(x.status == 'done', x.status == 'done' ? '' : (x.result.isEmpty ? 'error' : x.result), kg: x.kg, rst: x.rst);
        }
      } catch (_) {}
    }
    return const RemoteResult(false, 'timeout');
  }
}

/// The laptop's service (Balaji Kanta) and the phone's client (Balaji Pro).
final KantaRemoteHost kantaRemote = KantaRemoteHost(kantaUsb, SupaRemoteApi());
final KantaRemoteClient remoteClient = KantaRemoteClient(SupaRemoteApi());
