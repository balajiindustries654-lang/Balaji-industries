import 'dart:typed_data';
import 'matrix_slip.dart';

// ======================================================================
// What comes in over the RS232 cable of the weighbridge terminal
//  - pure Dart (no Flutter, no USB): bytes in, lines / live weight / finished slips out
//  - three kinds of output are understood:
//      1. a live weight, line after line ("ST,GS,  5065 kg", "+005065", "WT: 5065")
//      2. a printed slip (RST, Vehicle, Gross, Tare, Net ... on separate lines)
//      3. one line that is a whole slip, like a line of the report file (263,14/10/2026,GJ12..,5065,2240,2825)
//  - everything that arrives is also kept as text + hex so the real format can be seen and fitted exactly
// ======================================================================

/// Labels that mark a live weight line.
const Set<String> _liveLabels = <String>{'', 'ST', 'US', 'GS', 'NT', 'WT', 'W', 'S', 'M', 'KG', 'SG', 'OL', 'LW'};

/// Labels that belong to a printed slip (Gross / Tare / Net), not to a live weight.
const Set<String> _slipLabels = <String>{'G', 'T', 'N', 'GW', 'TW', 'NW'};

final RegExp _wLine = RegExp(r'^((?:[A-Za-z]{1,3}[\s,:;=]*){0,2})([+\-=])?\s*(\d{1,7}(?:\.\d{1,3})?)\s*(kg|kgs|t)?\s*$', caseSensitive: false);

/// A line like "ST,GS,  5065 kg": the weight, the label in front of it, and whether the scale says it is steady.
({double v, String label, bool? steady})? serialWeightLine(String raw) {
  final String s = raw.trim();
  if (s.isEmpty || s.length > 30) return null;
  final RegExpMatch? m = _wLine.firstMatch(s);
  if (m == null) return null;
  final List<String> toks = <String>[for (final RegExpMatch x in RegExp(r'[A-Za-z]{1,3}').allMatches(m[1] ?? '')) x[0]!.toUpperCase()];
  // "kg" is not a label when it comes after the number, here only in front
  for (final String t in toks) {
    if (!_liveLabels.contains(t) && !_slipLabels.contains(t)) return null;
  }
  double v = double.tryParse(m[3]!) ?? -1;
  if (v < 0) return null;
  if ((m[4] ?? '').toLowerCase() == 't') v *= 1000;
  if (v > 200000) return null;
  bool? steady;
  if (toks.contains('ST')) steady = true;
  if (toks.contains('US')) steady = false;
  final String label = toks.isEmpty ? '' : toks.last;
  return (v: v, label: toks.any(_slipLabels.contains) ? toks.firstWhere(_slipLabels.contains) : label, steady: steady);
}

final RegExp _plateRe = RegExp(r'\b[A-Za-z]{2}[\s\-]?\d{1,2}[\s\-]?[A-Za-z]{1,3}[\s\-]?\d{3,4}\b');

String _grab(String text, String pattern) {
  final RegExpMatch? m = RegExp(pattern, caseSensitive: false).firstMatch(text);
  return m == null ? '' : (m[1] ?? '').trim();
}

double _grabNum(String text, String pattern) => double.tryParse(_grab(text, pattern)) ?? 0;

String _fieldText(String text, String names) {
  final String v = _grab(text, '(?:$names)\\s*[:=\\-]\\s*([^\\n\\r]{1,40})');
  if (!RegExp(r'[A-Za-z0-9઀-૿]').hasMatch(v)) return '';
  return v;
}

/// The lines of one printed slip -> slip. Null when it is not a slip.
WbSlip? serialSlipFromText(List<String> lines) {
  final String text = lines.join('\n');
  if (text.trim().length < 8) return null;
  final String rst = _grab(text, r'(?:\brst\b|\br\.\s?s\.\s?t\.?|\bsr\.?\s*no\b|\bsl\.?\s*no\b|\bserial\b|\btkt\b|\bticket\b|\bslip\b|\btoken\b)\s*(?:no\.?|number|#)?\s*[:=\-.]?\s*(\d{1,9})');
  String veh = _grab(text, r'(?:vehicle|veh\.?|truck|lorry|gadi|vahan)\s*(?:no\.?|number|#)?\s*[:=\-.]?\s*([A-Za-z]{1,3}[\s\-]?\d{1,2}[\s\-]?[A-Za-z]{0,3}[\s\-]?\d{0,4})');
  if (veh.isEmpty) veh = _plateRe.firstMatch(text)?[0] ?? '';
  veh = veh.toUpperCase().replaceAll(RegExp(r'[\s\-]'), '');
  double gross = _grabNum(text, r'gross(?:\s*(?:wt|weight))?\.?\s*(?:\(kg\))?\s*[:=\-]?\s*(\d+(?:\.\d+)?)');
  double tare = _grabNum(text, r'tare(?:\s*(?:wt|weight))?\.?\s*(?:\(kg\))?\s*[:=\-]?\s*(\d+(?:\.\d+)?)');
  double net = _grabNum(text, r'\bnet(?:\s*(?:wt|weight))?\.?\s*(?:\(kg\))?\s*[:=\-]?\s*(\d+(?:\.\d+)?)');
  if (gross <= 0) gross = _grabNum(text, r'(?:1st|first)\s*(?:wt|weight)\.?\s*[:=\-]?\s*(\d+(?:\.\d+)?)');
  if (tare <= 0) tare = _grabNum(text, r'(?:2nd|second)\s*(?:wt|weight)\.?\s*[:=\-]?\s*(\d+(?:\.\d+)?)');
  // lines like "GW: 5065" that the live-weight reader left for the slip
  if (gross <= 0) gross = _grabNum(text, r'^\s*(?:gw|g)\s*[:=]?\s*(\d+(?:\.\d+)?)\s*(?:kg)?\s*$');
  if (tare <= 0) tare = _grabNum(text, r'^\s*(?:tw|t)\s*[:=]?\s*(\d+(?:\.\d+)?)\s*(?:kg)?\s*$');
  if (net <= 0) net = _grabNum(text, r'^\s*(?:nw|n)\s*[:=]?\s*(\d+(?:\.\d+)?)\s*(?:kg)?\s*$');
  if ((rst.isEmpty && veh.isEmpty) || (gross <= 0 && tare <= 0 && net <= 0)) return null;
  if (net <= 0 && gross > 0 && tare > 0 && gross > tare) net = gross - tare;
  // first weight only: a printed "TARE 0, NET = GROSS" is not a finished weighing
  if (tare <= 0 && gross > 0 && (net - gross).abs() < 0.5) net = 0;
  DateTime? day;
  final RegExpMatch? dm = RegExp(r'\d{1,2}[/\-.]\d{1,2}[/\-.]\d{2,4}').firstMatch(text);
  if (dm != null) day = wbDate(dm[0]!);
  final ({int h, int m})? tm = wbTime(text.replaceAll(RegExp(r'\d{1,2}[/\-.]\d{1,2}[/\-.]\d{2,4}'), ' '));
  DateTime? at = day;
  if (day != null && tm != null) at = DateTime(day.year, day.month, day.day, tm.h, tm.m);
  return WbSlip(
    rst: rst,
    vehicle: veh,
    party: _fieldText(text, r'party|supplier|customer|name'),
    material: _fieldText(text, r'material|item|commodity|product'),
    city: _fieldText(text, r'city|place|village'),
    gross: gross,
    tare: tare,
    net: net,
    at: at,
    hasTime: day != null && tm != null,
  );
}

/// One line that is a whole slip (a line of the report file): separated by , ; tab | or by 2+ spaces.
WbSlip? serialSlipFromLine(String line) {
  if (!RegExp(r'\d{1,2}[/\-.]\d{1,2}[/\-.]\d{2,4}').hasMatch(line)) return null;
  final List<List<String>> tries = <List<String>>[
    if (line.split(',').length >= 5) line.split(','),
    if (line.split(';').length >= 5) line.split(';'),
    if (line.split('\t').length >= 5) line.split('\t'),
    if (line.split('|').length >= 5) line.split('|'),
    line.trim().split(RegExp(r'\s{2,}')),
    line.trim().split(RegExp(r'\s+')),
  ];
  for (final List<String> c in tries) {
    if (c.length < 5) continue;
    final WbSlip? s = wbSlipFromCells(c);
    if (s != null && (s.rst.isNotEmpty || s.vehicle.isNotEmpty)) return s;
  }
  return null;
}

/// How much of the bytes is readable text (0..1). The right baud rate gives a high number.
double serialTextScore(List<int> b) {
  if (b.length < 6) return 0;
  int good = 0;
  for (final int x in b) {
    if ((x >= 0x20 && x <= 0x7E) || x == 0x0D || x == 0x0A || x == 0x09 || x == 0x02 || x == 0x03 || x == 0x0C) good++;
  }
  return good / b.length;
}

/// A weight that stayed the same for a few seconds (a vehicle standing on the platform).
class SettledWeight {
  final DateTime at;
  final double kg;

  /// One "stay" = the time between two empty-platform moments (id = when it began, 0 = not known).
  /// Inside one stay a new settled weight (e.g. the driver stepped out: -70 kg) replaces the old one.
  final int stay;

  /// A weighbridge entry was already made from this weight.
  bool used = false;
  SettledWeight(this.at, this.kg, [this.stay = 0, this.used = false]);
}

/// Below this the platform counts as empty (the indicator often shows 10-15 kg at rest). This is the default;
/// the operator can lower it in Settings (e.g. for a test with a small weight) - see [settleMinKg].
const double kSettleMinKg = 100;

/// The minimum weight in use now (kg). 100 in Balaji Pro (the "steady weights" list of the owner). Balaji Kanta sets it to 0
/// (lib/main_kanta.dart): like the Matrix terminal it takes ANY weight that stands still - only 0 (nothing on the platform) is "empty".
double settleMinKg = kSettleMinKg;

/// True in Balaji Pro: a weight can be taken only when it stands still. Balaji Kanta sets it to false (lib/main_kanta.dart):
/// like the Matrix terminal it takes the weight that is on the display when the button is pressed, steady or not.
bool settleNeedStable = true;

/// The weight may move this much (kg) and still count as the same.
const double kSettleBandKg = 10;

/// ... for this long (milliseconds).
const int kSettleHoldMs = 3000;

/// A different settled weight is only reported again after a change of at least this much (or an empty platform).
const double kSettleRearmKg = 30;

/// Bytes in -> lines, live weight and slips out.
class SerialDecoder {
  SerialDecoder({this.maxLines = 300});
  final int maxLines;

  /// The lines that arrived (newest last). Equal lines one after the other are kept once: [runs] says how often.
  /// (A weight indicator repeats the same weight dozens of times a second.)
  final List<String> lines = <String>[];
  final List<int> runs = <int>[];

  /// Lines that are NOT a weight (slip text, headers ...). Kept on their own so a flood of weight lines cannot push
  /// them out: "hh:mm:ss  text".
  final List<String> others = <String>[];

  /// Weight lines per second, about (0 = not known yet).
  double rate = 0;
  int _rateN = 0;
  DateTime? _rateAt;
  int bytes = 0;

  /// Bytes with value 0 (this terminal sends runs of 10 of them now and then between lines; they are ignored).
  int nulBytes = 0;
  int lineCount = 0;
  int weightLines = 0;
  int slipLines = 0;
  DateTime? lastByteAt;

  /// The live weight (kg) and whether it is steady.
  double? kg;
  bool stable = false;
  DateTime? kgAt;

  final List<int> _hex = <int>[];
  final StringBuffer _cur = StringBuffer();
  final List<String> _t = <String>[];
  DateTime? _tAt;
  double? _lastKg;
  DateTime? _sameSince;
  bool _skipEsc = false;
  final List<WbSlip> _ready = <WbSlip>[];

  // settled-weight detector
  final List<SettledWeight> _settled = <SettledWeight>[];
  double _wLo = 0;
  double _wHi = 0;
  DateTime? _wSince;
  bool _wDone = false;
  bool _wArmed = true;
  double _wEmitKg = 0;
  int _stayId = 0;

  /// Control bytes that arrive between the lines (runs of 00, 1B ...), newest last: "hh:mm:ss  00 x10".
  /// A terminal may send such a signal when a key is pressed / a slip is printed - kept to find out.
  final List<String> signals = <String>[];
  final List<String> _newSignals = <String>[];
  final List<int> _ctl = <int>[];
  DateTime? _ctlAt;
  bool _ctlEsc = false;

  /// The raw bytes of the last non-weight lines (hex), to see control characters.
  final List<String> othersHex = <String>[];
  final List<int> _curBytes = <int>[];

  /// The last bytes as hex, 16 per line.
  String hexTail([int n = 128]) {
    final List<int> h = _hex.length > n ? _hex.sublist(_hex.length - n) : _hex;
    final StringBuffer b = StringBuffer();
    for (int i = 0; i < h.length; i++) {
      b.write(h[i].toRadixString(16).padLeft(2, '0').toUpperCase());
      b.write((i % 16 == 15) ? '\n' : ' ');
    }
    return b.toString().trimRight();
  }

  /// The lines for the screen / the report: "0002080  x240" when the same line came 240 times in a row.
  List<String> get shownLines => <String>[for (int i = 0; i < lines.length; i++) runs[i] > 1 ? '${lines[i]}  x${runs[i]}' : lines[i]];

  /// All received lines as plain text (for copy / share).
  String logText() => shownLines.join('\n');

  /// Weights that stood still, since the last call.
  List<SettledWeight> takeSettled() {
    final List<SettledWeight> o = List<SettledWeight>.from(_settled);
    _settled.clear();
    return o;
  }

  /// Forget everything that was received.
  void clear() {
    lines.clear();
    runs.clear();
    others.clear();
    signals.clear();
    _newSignals.clear();
    _ctl.clear();
    _ctlAt = null;
    _ctlEsc = false;
    othersHex.clear();
    _curBytes.clear();
    rate = 0;
    _rateN = 0;
    _rateAt = null;
    _settled.clear();
    _wSince = null;
    _wDone = false;
    _wArmed = true;
    _stayId = 0;
    _hex.clear();
    _cur.clear();
    _t.clear();
    _ready.clear();
    bytes = 0;
    nulBytes = 0;
    lineCount = 0;
    weightLines = 0;
    slipLines = 0;
    kg = null;
    stable = false;
    kgAt = null;
    _lastKg = null;
    _sameSince = null;
  }

  void feed(List<int> data, DateTime now) {
    if (data.isEmpty) return;
    lastByteAt = now;
    for (final int b in data) {
      bytes++;
      if (b == 0) nulBytes++;
      if (_ctlEsc) {
        if (_ctl.length < 64) _ctl.add(b); // the byte after ESC belongs to the signal
        _ctlEsc = false;
      } else if (b < 0x20 && b != 0x0A && b != 0x0D && b != 0x09) {
        if (_ctl.length < 64) _ctl.add(b);
        _ctlAt ??= now;
        if (b == 0x1B) _ctlEsc = true;
      } else {
        _flushSignal();
      }
      _hex.add(b);
      if (_hex.length > 256) _hex.removeRange(0, _hex.length - 256);
      if (_skipEsc) {
        _skipEsc = false;
        continue;
      }
      if (b != 0x0A && b != 0x0D && b != 0 && _curBytes.length < 40) _curBytes.add(b);
      if (b == 0x0A || b == 0x0D || b == 0x02 || b == 0x03) {
        _endLine(now);
      } else if (b == 0x0C) {
        _endLine(now);
        _flushSlip();
      } else if (b == 0x1B) {
        _skipEsc = true;
      } else if (b == 0x09) {
        _cur.write(' ');
      } else if (b >= 0x20 && b <= 0x7E) {
        _cur.writeCharCode(b);
      }
    }
  }

  void _flushSignal() {
    final DateTime? at = _ctlAt;
    if (_ctl.isEmpty || at == null) {
      _ctl.clear();
      _ctlAt = null;
      return;
    }
    final StringBuffer b = StringBuffer();
    int i = 0;
    while (i < _ctl.length) {
      int j = i;
      while (j < _ctl.length && _ctl[j] == _ctl[i]) {
        j++;
      }
      if (b.isNotEmpty) b.write(' ');
      b.write(_ctl[i].toRadixString(16).padLeft(2, '0').toUpperCase());
      if (j - i > 1) b.write(' x${j - i}');
      i = j;
    }
    final String t = '${_hh(at)}  ${b.toString()}';
    signals.add(t);
    if (signals.length > 100) signals.removeRange(0, signals.length - 100);
    _newSignals.add(b.toString());
    _ctl.clear();
    _ctlAt = null;
  }

  /// The signals (control bytes) that came since the last call.
  List<String> takeSignals() {
    final List<String> o = List<String>.from(_newSignals);
    _newSignals.clear();
    return o;
  }

  /// Call about once a second: closes a line / slip that has stopped coming.
  void poll(DateTime now) {
    final DateTime? lb = lastByteAt;
    if (_ctl.isNotEmpty && lb != null && now.difference(lb).inMilliseconds > 400) _flushSignal();
    if (_cur.isNotEmpty && lb != null && now.difference(lb).inMilliseconds > 400) _endLine(now);
    final DateTime? ta = _tAt;
    if (_t.isNotEmpty && ta != null && now.difference(ta).inMilliseconds > 2500) _flushSlip();
    _checkSettle(now);
    if (kgAt != null && now.difference(kgAt!).inSeconds > 6) {
      kg = null;
      stable = false;
    }
  }

  /// The slips that were finished since the last call.
  List<WbSlip> take() {
    final List<WbSlip> o = List<WbSlip>.from(_ready);
    _ready.clear();
    return o;
  }

  void _endLine(DateTime now) {
    final String t = _cur.toString().trim();
    _cur.clear();
    final List<int> raw = List<int>.from(_curBytes);
    _curBytes.clear();
    if (t.isEmpty) return;
    _line(t, now, raw);
  }

  static String _hh(DateTime d) => '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}:${d.second.toString().padLeft(2, '0')}';

  void _addLine(String t) {
    if (lines.isNotEmpty && lines.last == t) {
      runs[runs.length - 1]++;
      return;
    }
    lines.add(t);
    runs.add(1);
    if (lines.length > maxLines) {
      lines.removeRange(0, lines.length - maxLines);
      runs.removeRange(0, runs.length - maxLines);
    }
  }

  void _addOther(String t, DateTime now, List<int> raw) {
    others.add('${_hh(now)}  $t');
    if (others.length > 400) others.removeRange(0, others.length - 400);
    othersHex.add(raw.take(24).map((int x) => x.toRadixString(16).padLeft(2, '0').toUpperCase()).join(' '));
    if (othersHex.length > 40) othersHex.removeRange(0, othersHex.length - 40);
  }

  void _line(String t, DateTime now, [List<int> raw = const <int>[]]) {
    _addLine(t);
    lineCount++;
    final WbSlip? one = serialSlipFromLine(t);
    if (one != null) {
      _addOther(t, now, raw);
      _flushSlip();
      _ready.add(one);
      slipLines++;
      return;
    }
    final ({double v, String label, bool? steady})? w = serialWeightLine(t);
    if (w != null && !_slipLabels.contains(w.label)) {
      weightLines++;
      _tickRate(now);
      _setKg(w.v, w.steady, now);
      return;
    }
    _addOther(t, now, raw);
    _t.add(t);
    _tAt = now;
    slipLines++;
    if (_t.length > 60) _t.removeRange(0, _t.length - 60);
  }

  void _setKg(double v, bool? steady, DateTime now) {
    kg = v;
    kgAt = now;
    if (_lastKg == v) {
      _sameSince ??= now;
    } else {
      _lastKg = v;
      _sameSince = now;
    }
    stable = steady ?? (v > 0 && now.difference(_sameSince!).inMilliseconds >= 1500);
    _track(v, now);
  }

  void _tickRate(DateTime now) {
    final DateTime? a = _rateAt;
    if (a == null) {
      _rateAt = now;
      _rateN = 0;
      return;
    }
    _rateN++;
    final int ms = now.difference(a).inMilliseconds;
    if (ms >= 3000) {
      rate = _rateN * 1000 / ms;
      _rateAt = now;
      _rateN = 0;
    }
  }

  /// Follows the weight: the same (within [kSettleBandKg]) for [kSettleHoldMs] -> one settled weight.
  void _track(double v, DateTime now) {
    if (v <= 0 || v < settleMinKg) {
      _wArmed = true; // the platform is empty
      _wSince = null;
      _stayId = 0;
      return;
    }
    if (_stayId == 0) _stayId = now.millisecondsSinceEpoch;
    if (_wSince == null) {
      _wLo = v;
      _wHi = v;
      _wSince = now;
      _wDone = false;
      return;
    }
    final double lo = v < _wLo ? v : _wLo;
    final double hi = v > _wHi ? v : _wHi;
    if (hi - lo > kSettleBandKg) {
      _wLo = v;
      _wHi = v;
      _wSince = now;
      _wDone = false;
      return;
    }
    _wLo = lo;
    _wHi = hi;
    _checkSettle(now);
  }

  void _checkSettle(DateTime now) {
    final DateTime? since = _wSince;
    if (since == null || _wDone) return;
    if (now.difference(since).inMilliseconds < kSettleHoldMs) return;
    final double mid = (_wLo + _wHi) / 2;
    if (!_wArmed && (mid - _wEmitKg).abs() < kSettleRearmKg) return;
    _wDone = true;
    _wArmed = false;
    _wEmitKg = mid;
    _settled.add(SettledWeight(now, kg ?? mid, _stayId));
  }

  void _flushSlip() {
    if (_t.isEmpty) return;
    final WbSlip? s = serialSlipFromText(_t);
    _t.clear();
    _tAt = null;
    if (s != null) _ready.add(s);
  }

  // ------------------------------------------------------------------ test feeds (no hardware needed)

  /// A truck driving on: the live weight goes up and stays.
  static Uint8List demoLive(double target, {int steps = 6, bool steadyWord = false}) {
    final StringBuffer b = StringBuffer();
    for (int i = 1; i <= steps; i++) {
      final double v = target * i / steps;
      b.write('${steadyWord && i == steps ? 'ST' : 'US'},GS,${v.round().toString().padLeft(7)} kg\r\n');
    }
    for (int i = 0; i < 4; i++) {
      b.write('ST,GS,${target.round().toString().padLeft(7)} kg\r\n');
    }
    return Uint8List.fromList(b.toString().codeUnits);
  }

  /// A printed slip.
  static Uint8List demoSlip({String rst = '368', String vehicle = 'GJ12AB1234', double gross = 6200, double tare = 2450}) {
    final String s = 'BALAJI INDUSTRIES\r\nRST NO : $rst\r\nDATE : 17/10/2026  TIME : 20:30\r\nVEHICLE NO : $vehicle\r\nMATERIAL : MAGFADI\r\nGROSS WT : ${gross.round()} kg\r\nTARE WT : ${tare.round()} kg\r\nNET WT : ${(gross - tare).round()} kg\r\n\f';
    return Uint8List.fromList(s.codeUnits);
  }
}
