import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'kanta_log.dart';
import 'kanta_slip.dart';
import 'live_models.dart' show vehicleKey;
import 'live_store.dart';
import 'supa.dart' show SupaError;

// ======================================================================
// The Google Sheet row of every mill entry, written by the weighbridge laptop ITSELF at the moment of the weighing.
// It does not wait for the server: whatever happens with the save on the server (duplicate RST, slow internet ...), the row for the Sheet
// is made when the second weight is taken. No internet: it waits on the laptop (kept over a restart) and goes by itself when the internet
// is back - once for every entry. Every result is written to kanta-sheet-YYYY-MM.csv in the Balaji Kanta folder.
// ======================================================================

/// One row waiting to go to the Sheet / already gone.
class SheetJob {
  final String key;
  final String rst;
  final String vehicle;
  final Map<String, dynamic> data;
  final int at;

  /// wait | sent
  String state;
  int tries;
  int next;
  int doneAt;
  String err;

  SheetJob({required this.key, required this.rst, required this.vehicle, required this.data, required this.at, this.state = 'wait', this.tries = 0, this.next = 0, this.doneAt = 0, this.err = ''});

  Map<String, Object> toJson() => <String, Object>{'k': key, 'rst': rst, 'v': vehicle, 'd': data, 'at': at, 's': state, 'n': tries, 'x': next, 'dn': doneAt, 'e': err};

  static SheetJob? fromJson(Object? j) {
    if (j is! Map) return null;
    try {
      final Object? d = j['d'];
      return SheetJob(
        key: '${j['k']}',
        rst: '${j['rst'] ?? ''}',
        vehicle: '${j['v'] ?? ''}',
        data: d is Map ? Map<String, dynamic>.from(d) : <String, dynamic>{},
        at: (j['at'] as num).toInt(),
        state: '${j['s'] ?? 'wait'}',
        tries: (j['n'] as num?)?.toInt() ?? 0,
        next: (j['x'] as num?)?.toInt() ?? 0,
        doneAt: (j['dn'] as num?)?.toInt() ?? 0,
        err: '${j['e'] ?? ''}',
      );
    } catch (_) {
      return null;
    }
  }
}

String _two(int n) => n < 10 ? '0$n' : '$n';

/// The row the Google Sheet gets for a slip (the same row the Balaji Industries app writes for a weighbridge entry).
Map<String, dynamic> sheetRowOf(SlipRec r) {
  Object kg(double v) => v == v.roundToDouble() ? v.round() : v;
  return <String, dynamic>{
    'type': 'Waybridge',
    'name': r.party,
    'mobile': r.mobile,
    'rst_no': r.rst,
    'vehicle_number': r.vehicle,
    'net_weight': kg(r.net),
    'slip_url': '',
    'gross_weight': kg(r.gross),
    'tare_weight': kg(r.tare),
    'party': r.party,
    'material': r.material,
    'city': r.city,
    'charges': r.charges > 0 ? kg(r.charges) : '',
    'date': '${_two(r.at.day)}-${_two(r.at.month)}-${r.at.year}',
    'time': '${_two(r.at.hour)}:${_two(r.at.minute)}',
  };
}

class KantaSheet {
  KantaSheet._();

  /// Goes up whenever a row or the state changes (screens listen).
  static final ValueNotifier<int> tick = ValueNotifier<int>(0);

  /// Newest first. Rows that went are kept for a while (so the same entry is never written twice).
  static final List<SheetJob> jobs = <SheetJob>[];
  static const int keep = 400;

  /// On / off for this laptop (Settings > Google Sheet). Off: nothing is written to the Sheet from here.
  static bool enabled = true;

  /// How a row is sent: true = the Sheet took it. The default posts to the Google Apps Script; tests replace it.
  static Future<bool> Function(Map<String, dynamic> row) sender = _liveSend;
  static DateTime Function() clock = DateTime.now;
  static List<Duration> backoff = const <Duration>[Duration(seconds: 30), Duration(minutes: 2), Duration(minutes: 10), Duration(minutes: 30), Duration(hours: 2)];

  static Timer? _timer;
  static bool _busy = false;
  static bool _loaded = false;

  static Future<bool> _liveSend(Map<String, dynamic> row) => live.supa.sheetTry(row);

  static int get waiting => jobs.where((SheetJob j) => j.state == 'wait').length;
  static int get sentToday {
    final DateTime n = clock();
    final int from = DateTime(n.year, n.month, n.day).millisecondsSinceEpoch;
    return jobs.where((SheetJob j) => j.state == 'sent' && j.doneAt >= from).length;
  }

  /// The laptop writes the Sheet rows itself: the entries saved on the server do not write them a second time.
  static void install() {
    live.kantaSheetHandled = true;
    KantaLog.onSlipMade = (SlipRec r) {
      if (!r.outside && !r.undone) unawaited(submit(r));
    };
  }

  static Future<void> load() async {
    if (_loaded) return;
    _loaded = true;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      enabled = p.getBool('ksh_on') ?? true;
      final String? raw = p.getString('ksh_jobs');
      if (raw != null) {
        final Object? j = jsonDecode(raw);
        if (j is List) {
          for (final Object? e in j) {
            final SheetJob? x = SheetJob.fromJson(e);
            if (x != null) jobs.add(x);
          }
        }
      }
    } catch (_) {}
    tick.value++;
    if (waiting > 0) _arm();
  }

  static Future<void> setEnabled(bool v) async {
    enabled = v;
    tick.value++;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setBool('ksh_on', v);
    } catch (_) {}
    if (v) unawaited(pump());
  }

  static Future<void> _save() async {
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setString('ksh_jobs', jsonEncode(jobs.map((SheetJob j) => j.toJson()).toList()));
    } catch (_) {}
  }

  static String keyOf(SlipRec r) => '${r.rst}|${vehicleKey(r.vehicle)}|${r.at.millisecondsSinceEpoch}';

  /// Puts the row of this entry into the queue and sends it at once. The same entry is never queued twice.
  static Future<SheetJob?> submit(SlipRec r) async {
    await load();
    if (!enabled) return null;
    final String k = keyOf(r);
    for (final SheetJob j in jobs) {
      if (j.key == k) return j;
    }
    final SheetJob j = SheetJob(key: k, rst: r.rst, vehicle: r.vehicle, data: sheetRowOf(r), at: clock().millisecondsSinceEpoch);
    jobs.insert(0, j);
    _trim();
    tick.value++;
    await _save();
    unawaited(pump());
    return j;
  }

  static void _trim() {
    while (jobs.length > keep) {
      // the oldest one that already went; a waiting row is never dropped
      final int i = jobs.lastIndexWhere((SheetJob j) => j.state == 'sent');
      if (i < 0) break;
      jobs.removeAt(i);
    }
  }

  static void _arm() {
    _timer ??= Timer.periodic(const Duration(seconds: 30), (Timer t) {
      if (waiting == 0) {
        t.cancel();
        _timer = null;
        return;
      }
      unawaited(pump());
    });
  }

  /// Tries every row that is due, oldest first. [force]: also the ones that wait for their next try.
  static Future<void> pump({bool force = false}) async {
    if (_busy) return;
    _busy = true;
    try {
      bool more = true;
      while (more) {
        more = false;
        final int now = clock().millisecondsSinceEpoch;
        final List<SheetJob> due = jobs.where((SheetJob j) => j.state == 'wait' && (force || j.next <= now)).toList()..sort((SheetJob a, SheetJob b) => a.at.compareTo(b.at));
        if (due.isEmpty || !enabled) break;
        final SheetJob j = due.first;
        await _try(j);
        if (j.state == 'sent' || force && j.tries < 2) more = true;
        if (j.state != 'sent') break; // the internet is down: the others would fail the same way
      }
    } finally {
      _busy = false;
      if (waiting > 0) _arm();
      tick.value++;
    }
  }

  static Future<void> _try(SheetJob j) async {
    j.tries++;
    bool ok = false;
    String err = '';
    try {
      ok = await sender(j.data);
      if (!ok) err = 'The Sheet did not answer';
    } on SupaError catch (e) {
      err = e.message;
    } catch (e) {
      err = '$e';
    }
    final DateTime now = clock();
    if (ok) {
      j.state = 'sent';
      j.err = '';
      j.doneAt = now.millisecondsSinceEpoch;
      await _log(j, 'SENT');
    } else {
      j.err = err;
      final Duration w = backoff[(j.tries - 1).clamp(0, backoff.length - 1).toInt()];
      j.next = now.add(w).millisecondsSinceEpoch;
      if (j.tries == 1) await _log(j, 'WAITING (will be sent again)');
    }
    tick.value++;
    await _save();
  }

  static Future<void> _log(SheetJob j, String status) async {
    final DateTime at = clock();
    await KantaLog.appendFile(
      'kanta-sheet',
      at,
      'Date,Time,RST,Vehicle,Status,Tries,Note',
      '${at.year}-${_two(at.month)}-${_two(at.day)},${_two(at.hour)}:${_two(at.minute)},${KantaLog.csv(j.rst)},${KantaLog.csv(j.vehicle)},$status,${j.tries},${KantaLog.csv(j.err)}',
    );
  }

  /// For tests: forget everything in memory.
  static void reset() {
    _timer?.cancel();
    _timer = null;
    _busy = false;
    _loaded = false;
    jobs.clear();
    enabled = true;
  }
}
