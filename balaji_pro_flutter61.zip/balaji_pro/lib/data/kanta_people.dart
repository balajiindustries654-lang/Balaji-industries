import '../core/i18n.dart';
import 'kanta_khata.dart';
import 'kanta_log.dart';
import 'kanta_slip.dart';
import 'live_models.dart' show nameKey, vehicleKey;
import 'live_store.dart';

// ======================================================================
// The people the weighbridge already knows: names, mobile numbers, towns and vehicle numbers from the slips of the laptop, the weighbridge
// entries on the server, the chits and the khata. They fill the suggestion lists of the weighing forms - a part of a name / number is enough.
// ======================================================================

class KantaPeople {
  KantaPeople._();

  static String _sig = '';
  static List<String> _names = const <String>[];
  static Map<String, String> _nameHint = const <String, String>{};
  static List<String> _mobiles = const <String>[];
  static Map<String, String> _mobileHint = const <String, String>{};
  static List<String> _cities = const <String>[];
  static Map<String, String> _vehHint = const <String, String>{};
  static Map<String, String> _mobileOfName = const <String, String>{};
  static Map<String, String> _nameOfMobile = const <String, String>{};

  static String _mob(String s) {
    final String d = s.replaceAll(RegExp(r'[^0-9]'), '');
    return d.length < 10 ? '' : d.substring(d.length - 10);
  }

  static void _build() {
    int chits = 0;
    int kantas = 0;
    try {
      chits = live.chits.length;
      kantas = live.kantas.length;
    } catch (_) {}
    final String sig = '${KantaHistory.items.length}/$kantas/$chits/${kantaKhata.accs.length}/${kantaKhata.accs.fold<int>(0, (int a, KhataAcc x) => a + (x.baki * 10).round())}';
    if (sig == _sig) return;
    _sig = sig;

    final List<String> names = <String>[];
    final Map<String, String> nameShown = <String, String>{}; // nameKey -> the text as written (first = newest)
    final Map<String, String> mobOfName = <String, String>{};
    final List<String> mobiles = <String>[];
    final Map<String, String> mobName = <String, String>{};
    final List<String> cities = <String>[];
    final Set<String> cityKeys = <String>{};
    final Map<String, String> vehParty = <String, String>{};

    void addName(String raw, String mobile) {
      final String t = raw.trim();
      if (t.isEmpty) return;
      final String k = nameKey(t);
      if (!nameShown.containsKey(k)) {
        nameShown[k] = t;
        names.add(t);
      }
      final String m = _mob(mobile);
      if (m.isNotEmpty) {
        mobOfName.putIfAbsent(k, () => m);
        if (!mobName.containsKey(m)) {
          mobName[m] = t;
          mobiles.add(m);
        }
      }
    }

    void addMobile(String mobile, String name) {
      final String m = _mob(mobile);
      if (m.isEmpty) return;
      if (!mobName.containsKey(m)) {
        mobName[m] = name.trim();
        mobiles.add(m);
      } else if (mobName[m]!.isEmpty && name.trim().isNotEmpty) {
        mobName[m] = name.trim();
      }
    }

    void addCity(String c) {
      final String t = c.trim();
      if (t.isEmpty) return;
      if (cityKeys.add(nameKey(t))) cities.add(t);
    }

    for (final SlipRec r in KantaHistory.items.take(2500)) {
      if (r.undone) continue;
      addName(r.party, r.mobile);
      addMobile(r.mobile, r.party);
      addCity(r.city);
      if (r.party.trim().isNotEmpty) vehParty.putIfAbsent(vehicleKey(r.vehicle), () => r.party.trim());
    }
    try {
      for (final k in live.kantas.take(1500)) {
        final String nm = k.party.trim().isNotEmpty ? k.party : k.name;
        addName(nm, k.mobile);
        addMobile(k.mobile, nm);
        addCity(k.city);
        if (nm.trim().isNotEmpty) vehParty.putIfAbsent(vehicleKey(k.vehicle), () => nm.trim());
      }
    } catch (_) {}
    try {
      for (final c in live.chits.take(1500)) {
        addName(c.farmer, c.mobile);
        addMobile(c.mobile, c.farmer);
        addCity(c.village);
      }
    } catch (_) {}
    final Map<String, String> bakiOf = <String, String>{};
    for (final KhataAcc a in kantaKhata.accs) {
      if (a.name.isNotEmpty) addName(a.name, a.mobile);
      if (a.baki >= 0.5) bakiOf[nameKey(a.label)] = '${_baki(a.baki)}';
    }

    final Map<String, String> nh = <String, String>{};
    for (final String n in names) {
      final String k = nameKey(n);
      final List<String> p = <String>[];
      final String? b = bakiOf[k];
      if (b != null) p.add(b);
      final String? m = mobOfName[k];
      if (m != null) p.add(m);
      if (p.isNotEmpty) nh[n] = p.join('  ·  ');
    }
    final Map<String, String> mh = <String, String>{};
    for (final String m in mobiles) {
      final String n = mobName[m] ?? '';
      final String? b = n.isEmpty ? null : bakiOf[nameKey(n)];
      final String t = <String>[if (n.isNotEmpty) n, if (b != null) b].join('  ·  ');
      if (t.isNotEmpty) mh[m] = t;
    }
    _names = names;
    _nameHint = nh;
    _mobiles = mobiles;
    _mobileHint = mh;
    _cities = cities;
    _vehHint = vehParty;
    _mobileOfName = mobOfName;
    _nameOfMobile = mobName;
  }

  static String _baki(double v) => '${bi('બાકી', 'baki')} ₹${v.round()}';

  /// Names (newest first). The hint of a name is its mobile number and, when it owes, its baki.
  static List<String> names() {
    _build();
    return _names;
  }

  static Map<String, String> nameHints() {
    _build();
    return _nameHint;
  }

  /// Mobile numbers (newest first). The hint of a number is the name that goes with it.
  static List<String> mobiles() {
    _build();
    return _mobiles;
  }

  static Map<String, String> mobileHints() {
    _build();
    return _mobileHint;
  }

  static List<String> cities() {
    _build();
    return _cities;
  }

  /// The party that weighed with this vehicle last ('' when unknown) - the hint of a vehicle number.
  static String partyOfVehicle(String vehicle) {
    _build();
    return _vehHint[vehicleKey(vehicle)] ?? '';
  }

  /// The mobile number this name had last ('' when unknown).
  static String mobileOfName(String name) {
    _build();
    return _mobileOfName[nameKey(name)] ?? '';
  }

  /// The name that goes with a mobile number ('' when unknown).
  static String nameOfMobile(String mobile) {
    _build();
    final String m = _mob(mobile);
    return m.isEmpty ? '' : (_nameOfMobile[m] ?? '');
  }
}
