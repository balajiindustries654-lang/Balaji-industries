import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'engine.dart' show Trip, TripState;
import 'kanta_auto.dart';
import 'kanta_pair.dart';
import 'kanta_slip.dart';
import 'live_models.dart' show Kanta, parseTs, vehicleKey;
import 'live_store.dart';
import 'matrix_slip.dart';
import 'native_io.dart';
import 'serial_decode.dart';
import 'supa.dart' show SupaError;

// ======================================================================
// Weighbridge terminal -> USB-to-RS232 cable -> OTG -> phone -> app
//  - two ways in: (1) the USB plug-in inside the app, (2) a "network bridge" app from the Play Store (TCPUART transparent
//    Bridge) that reads the USB cable and gives the data on a TCP port of the phone; this app then reads 127.0.0.1:port.
//    The second way needs no plug-in at all (plain dart:io socket), so it also works in every build and on the laptop.
//  - one service for the whole app: it keeps reading while the owner looks at other screens
//  - bytes -> SerialDecoder -> live weight + finished slips -> weighbridge entries (same as typing them)
//  - an unfinished slip (first weight only) is shown but not saved until the second weight is there
//  - a slip that is already in the app (same RST / same vehicle, weight and day) is never saved twice
//  - the settings stay on this phone only
// ======================================================================

/// One line of "what happened".
class UsbEvent {
  final DateTime at;
  final String text;

  /// ok | warn | info
  final String tone;
  const UsbEvent(this.at, this.text, this.tone);
}

/// A vehicle that was weighed once (usually loaded) and is still inside, waiting for its second weighing.
class InsideVehicle {
  final String id;
  final String vehicle;
  final double kg;
  final DateTime at;

  /// A vehicle from the road (not the mill's): its slip stays on the laptop and is never sent to the app / server.
  final bool outside;
  final String party;
  final double charges;

  /// Who took the first weight from a phone (empty: at the laptop itself).
  final String by;

  /// Written at the weighing (all optional): driver / supplier mobile, the goods, the town.
  final String mobile;
  final String material;
  final String city;

  /// The RST number reserved for this vehicle at its first weighing (like the Matrix terminal: the number is known from the start).
  /// Empty for a road vehicle (its slip number R-n is given at the second weighing) and for vehicles remembered by an older version.
  final String rst;

  /// The charges were paid in cash at the first weighing (otherwise they are "baki" in the khata of the name).
  final bool paid;
  const InsideVehicle(this.id, this.vehicle, this.kg, this.at, {this.outside = false, this.party = '', this.charges = 0, this.by = '', this.mobile = '', this.material = '', this.city = '', this.rst = '', this.paid = false});
}

/// An entry the app made by itself from two weights and a waiting vehicle.
class AutoMade {
  final DateTime at;
  final String rst;
  final String vehicle;
  final double gross;
  final double tare;
  final double chitKg;
  final SettledWeight wGross;
  final SettledWeight wTare;
  bool undone = false;

  /// A vehicle from the road: kept on the laptop only (no entry in the app / server).
  final bool outside;
  final String party;
  final double charges;

  /// Who weighed it from a phone (empty: at the laptop itself).
  final String by;
  final String mobile;
  final String material;
  final String city;
  final bool paid;
  AutoMade(this.at, this.rst, this.vehicle, this.gross, this.tare, this.chitKg, this.wGross, this.wTare, {this.outside = false, this.party = '', this.charges = 0, this.by = '', this.mobile = '', this.material = '', this.city = '', this.paid = false});
  double get net => gross - tare;
}

/// A TCP connection used like a serial session (data in, data out).
class _TcpSession implements UsbSession {
  final Socket sock;
  final StreamController<Uint8List> ctl = StreamController<Uint8List>.broadcast();
  StreamSubscription<Uint8List>? sub;

  _TcpSession(this.sock) {
    sub = sock.listen((Uint8List d) {
      if (!ctl.isClosed) ctl.add(d);
    }, onError: (Object e) {
      if (!ctl.isClosed) ctl.addError(e);
    }, onDone: () {
      if (!ctl.isClosed) ctl.close();
    }, cancelOnError: false);
  }

  @override
  Stream<Uint8List> get data => ctl.stream;

  @override
  Future<void> write(List<int> bytes) async {
    sock.add(bytes);
    await sock.flush();
  }

  @override
  Future<void> close() async {
    try {
      await sub?.cancel();
    } catch (_) {}
    try {
      sock.destroy();
    } catch (_) {}
    if (!ctl.isClosed) await ctl.close();
  }
}

const List<int> kUsbBauds = <int>[1200, 2400, 4800, 9600, 19200, 38400, 57600, 115200];

// ---- the live data of the app, as the weight matcher needs it (tests use their own) ----

bool _liveReady() => live.signedIn && live.loadedAt != null && !live.needsReauth;

List<PairTrip> _liveTrips() => <PairTrip>[
      for (final Trip t in live.trips)
        if (t.kanta == null && t.chits.isNotEmpty && t.state != TripState.direct && t.chitKg > 0) PairTrip(t.vk, t.vehicle, t.chitKg, t.tol, t.at),
    ];

/// The next RST number: one more than the highest in the app (and in the server, when it can be reached).
/// When the owner chose a start number ([KantaUsbService.rstStart]) only the entries made after he chose it count (the older ones are
/// test weighings), and the first number is that start number.
Future<String> _liveNextRst() async {
  final int start = kantaUsb.rstStart;
  final DateTime since = DateTime.fromMillisecondsSinceEpoch(kantaUsb.rstSinceMs);
  bool counts(DateTime at) => start <= 0 || !at.isBefore(since);
  int best = start > 0 ? start - 1 : 0;
  for (final Kanta k in live.kantas) {
    if (!counts(k.at)) continue;
    final int? n = int.tryParse(k.rst.trim());
    if (n != null && n > best) best = n;
  }
  for (final InsideVehicle x in kantaUsb.inside) {
    // numbers already reserved for vehicles that are inside
    final int? n = int.tryParse(x.rst.trim());
    if (n != null && n > best) best = n;
  }
  for (final PendingItem p in live.pending) {
    if (p.kind != 'kanta') continue;
    if (!counts(parseTs(p.queuedAt) ?? DateTime.now())) continue;
    final int? n = int.tryParse('${p.row['rst_no'] ?? ''}'.trim());
    if (n != null && n > best) best = n;
  }
  // the server's last numbers: only when the internet is there, and never longer than a few seconds - the weighing must not wait for it
  // (without internet the numbers known on this laptop - saved entries, waiting entries, vehicles inside - are enough)
  if (!live.offline) {
    try {
      final Map<String, String> q = <String, String>{'select': 'rst_no,created_at', 'order': 'created_at.desc', 'rst_no': 'not.is.null'};
      if (start > 0) q['created_at'] = 'gte.${since.toUtc().toIso8601String()}';
      final List<Map<String, dynamic>> rows = await live.supa.select('waybridge_entries', q, limit: 100).timeout(const Duration(seconds: 4));
      for (final Map<String, dynamic> r in rows) {
        final int? n = int.tryParse('${r['rst_no'] ?? ''}'.trim());
        if (n != null && n > best) best = n;
      }
    } catch (_) {}
    // a number that is already used on the server (an old test entry, the owner's phone ...) would give "duplicate key" at the save:
    // take the first one that is free
    try {
      best = await live.firstFreeRst(best + 1).timeout(const Duration(seconds: 5)) - 1;
    } catch (_) {}
  }
  return '${best + 1}';
}

Future<SaveResult> _liveSubmit(Map<String, dynamic> row) => live.submit('kanta', row);

/// Does the table waybridge_entries have the extra columns (gross, tare, party, mobile, material, city, charges)?
/// A select of them works only when all exist. Throws when the answer is unclear (no internet).
Future<bool> _liveExtrasProbe() async {
  if (!live.signedIn) throw StateError('not signed in');
  try {
    await live.supa.select('waybridge_entries', <String, String>{'select': 'gross_kg,tare_kg,party_name,party_mobile,material,city,charges_rs'}, limit: 1);
    return true;
  } on SupaError catch (e) {
    if (e.network || e.status >= 500 || e.status == 401 || e.status == 403) rethrow;
    return false;
  }
}

/// The mobile number of the farmer on the chit of a vehicle (the slip can go to him on WhatsApp); '' when unknown.
String _liveMobileOf(String vehicle) {
  try {
    final String k = vehicleKey(vehicle);
    for (final Trip t in live.trips) {
      if (t.vk != k) continue;
      for (final c in t.chits) {
        final String d = c.mobile.replaceAll(RegExp(r'[^0-9]'), '');
        if (d.length >= 10) return d.substring(d.length - 10);
      }
    }
  } catch (_) {}
  return '';
}

/// The party / farmer name(s) of the chits of a vehicle (for the slip text); '' when unknown.
String _livePartyOf(String vehicle) {
  try {
    final String k = vehicleKey(vehicle);
    for (final Trip t in live.trips) {
      if (t.vk == k && t.farmers.isNotEmpty) return t.farmers;
    }
  } catch (_) {}
  return '';
}

/// How likely a COM port is the weighbridge cable: > 0 a USB-serial adapter (FTDI, Prolific, CH340, CP210x ...), 0 unknown,
/// < 0 a port that can never be the weighbridge (Intel "Active Management Technology - SOL", Bluetooth). The laptop's own virtual
/// ports often have the lowest COM number, so "the first port" is a wrong guess.
int usbPortScore(UsbDev d) {
  final String t = '${d.label} ${d.id}'.toLowerCase();
  if (t.contains('active management') || t.contains('serial over lan') || t.contains('bluetooth') || RegExp(r'\bsol\b').hasMatch(t)) return -100;
  for (final String k in <String>['ftdi', 'usb', 'prolific', 'pl2303', 'ch340', 'ch341', 'cp210', 'silicon lab', 'uart', 'rs232', 'rs-232', 'serial converter']) {
    if (t.contains(k)) return 100;
  }
  return 0;
}

class KantaUsbService extends ChangeNotifier {
  /// The list of cables and the way to open one (tests replace them).
  static Future<List<UsbDev>> Function() lister = usbDevices;
  static Future<UsbSession> Function(UsbDev d, {required int baud, int dataBits, int stopBits, int parity}) opener = usbConnect;

  final SerialDecoder dec = SerialDecoder();
  List<UsbDev> devices = <UsbDev>[];
  UsbDev? chosen;
  String _savedDev = ''; // the COM port that gave weight before (a real cable) - used again first
  String? _connId; // the port that is open now
  bool _connJunk = false; // ... and it cannot be a weighbridge (Intel SOL, Bluetooth)

  /// True when a port that can not be the weighbridge is open (the screen says so).
  bool get junkPort => connected && !net && _connJunk;

  /// A port that may be the weighbridge exists (not only Intel SOL / Bluetooth).
  bool get hasRealCable => devices.any((UsbDev d) => usbPortScore(d) >= 0);

  /// The chosen port is fine for connecting by itself.
  bool get autoOk => chosen != null && usbPortScore(chosen!) >= 0;
  int baud = 9600;
  int dataBits = 8;
  int stopBits = 1;
  int parity = 0; // 0 none, 1 odd, 2 even
  bool auto = false;

  /// true: read from a network bridge app (TCP) instead of the USB plug-in
  bool net = false;
  String host = '127.0.0.1';
  int port = 2000;
  bool connected = false;

  /// When the cable / bridge was opened (the screen says so when nothing has come from the terminal for a while).
  DateTime? connectedAt;
  bool busy = false;
  bool scanning = false;
  String error = '';
  String progress = '';
  final List<UsbEvent> log = <UsbEvent>[];

  /// First weight only (second weight still to come).
  final List<KantaRow> waiting = <KantaRow>[];

  /// Finished slips that are not saved yet (auto-save is off).
  final List<KantaRow> ready = <KantaRow>[];
  int savedCount = 0;

  /// Weights that stayed still for a few seconds (newest first): the vehicle standing on the platform.
  final List<SettledWeight> weighs = <SettledWeight>[];

  /// The ones the person ticked (at most two: gross and tare).
  final List<SettledWeight> picked = <SettledWeight>[];

  /// true: when two weights and exactly one waiting vehicle fit each other the entry is saved without a tap.
  bool autoW = false;

  /// The RST number the owner chose to start from (0 = continue after the highest one) and the moment he chose it: entries made
  /// before that moment (test weighings) are not counted when the next number is worked out. The first run gives "start from 1".
  int rstStart = 0;
  int rstSinceMs = 0;

  /// Vehicles that had their first weighing and wait for the second one (newest first).
  final List<InsideVehicle> inside = <InsideVehicle>[];

  /// Last slip number given to a vehicle from the road (their own series: R-1, R-2, ...).
  int _outNo = 0;

  /// Entries made by itself (newest first, only until the app is closed).
  final List<AutoMade> made = <AutoMade>[];
  bool _matching = false;
  final List<(double, DateTime)> _taken = <(double, DateTime)>[];
  DateTime _autoBlockUntil = DateTime.fromMillisecondsSinceEpoch(0);

  // the live data of the app; replaced in tests
  List<PairTrip> Function() tripsProvider = _liveTrips;
  Future<String> Function() nextRstProvider = _liveNextRst;
  String Function(String vehicle) partyProvider = _livePartyOf;

  /// The farmer's mobile of the vehicle's chit (tests replace it).
  String Function(String vehicle) mobileProvider = _liveMobileOf;

  /// Called after every entry made at the weighing station (the Kanta app keeps a copy of it in a file on the laptop).
  void Function(AutoMade m)? onEntryMade;

  /// Called after an entry made here was taken back.
  void Function(AutoMade m)? onEntryUndone;

  /// Called after every first weight taken at the weighing station (vehicle, kg, time).
  void Function(String vehicle, double kg, DateTime at, bool outside)? onFirstTaken;
  Future<SaveResult> Function(Map<String, dynamic> row) submitter = _liveSubmit;
  bool Function() liveReady = _liveReady;

  String _lastSig = '';
  DateTime _lastSigAt = DateTime.fromMillisecondsSinceEpoch(0);
  DateTime _lastNotify = DateTime.fromMillisecondsSinceEpoch(0);
  Timer? _notifyT;

  bool _loaded = false;
  bool _want = false;
  UsbSession? _s;
  StreamSubscription<Uint8List>? _sub;
  Timer? _poll;
  Timer? _retry;
  final Set<String> _inflight = <String>{};
  bool _demo = false;

  /// The laptop (Windows) reads a COM port through PowerShell - no plug-in.
  bool get winCom => !kIsWeb && Platform.isWindows;

  /// A cable can be read directly by this build: the USB plug-in on an Android phone, or a COM port on the Windows laptop.
  bool get possible => !kIsWeb && ((kUsbPlugin && Platform.isAndroid) || Platform.isWindows);

  /// The network way works everywhere except the web page.
  bool get netPossible => !kIsWeb;

  /// Waiting for the bridge app / cable to come back (will try again by itself).
  bool get trying => _want && !connected;

  /// Something can be started now.
  bool get canStart => net ? netPossible : (possible && chosen != null);

  void _add(String text, String tone) {
    log.add(UsbEvent(DateTime.now(), text, tone));
    if (log.length > 120) log.removeRange(0, log.length - 120);
  }

  /// A line in the event list (used by the remote-weighing service).
  void note(String text, [String tone = 'info']) {
    _add(text, tone);
    notifyListeners();
  }

  Future<void> load() async {
    if (_loaded) return;
    _loaded = true;
    bool hasRst = false;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      final String raw = p.getString('kusb') ?? '';
      if (raw.isNotEmpty) {
        final Object? j = jsonDecode(raw);
        if (j is Map) {
          baud = _i(j['baud'], 9600);
          dataBits = _i(j['bits'], 8) == 7 ? 7 : 8;
          stopBits = _i(j['stop'], 1) == 2 ? 2 : 1;
          parity = _i(j['par'], 0).clamp(0, 2);
          auto = j['auto'] == true;
          _want = j['want'] == true;
          if (j.containsKey('net')) net = j['net'] == true;
          autoW = j['autow'] == true;
          if (j.containsKey('rstn')) {
            rstStart = _i(j['rstn'], 0).clamp(0, 99999999).toInt();
            rstSinceMs = _i(j['rsts'], 0);
            hasRst = true;
          }
          final String h = '${j['host'] ?? ''}'.trim();
          if (h.isNotEmpty) host = h;
          port = _i(j['port'], 2000).clamp(1, 65535).toInt();
          _savedDev = '${j['dev'] ?? ''}'.trim().toUpperCase();
        }
      }
    } catch (_) {}
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      final String raw = p.getString('kusbw') ?? '';
      if (raw.isNotEmpty) {
        final Object? j = jsonDecode(raw);
        if (j is List) {
          for (final Object? e in j) {
            if (e is List && e.length >= 2) {
              final int ms = _i(e[0], 0);
              final double kg = double.tryParse('${e[1]}') ?? 0;
              if (ms > 0 && kg > 0) weighs.add(SettledWeight(DateTime.fromMillisecondsSinceEpoch(ms), kg, e.length >= 3 ? _i(e[2], 0) : 0, e.length >= 4 && e[3] == true));
            }
          }
        }
      }
    } catch (_) {}
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      final String raw = p.getString('kusbi') ?? '';
      if (raw.isNotEmpty) {
        final Object? j = jsonDecode(raw);
        if (j is List) {
          for (final Object? e in j) {
            if (e is List && e.length >= 4) {
              final int ms = _i(e[2], 0);
              final double kg = double.tryParse('${e[1]}') ?? 0;
              if (ms > 0 && kg > 0) {
                inside.add(InsideVehicle('${e[3]}', '${e[0]}', kg, DateTime.fromMillisecondsSinceEpoch(ms),
                    outside: e.length >= 5 && (e[4] == 1 || e[4] == true), party: e.length >= 6 ? '${e[5]}' : '', charges: e.length >= 7 ? (double.tryParse('${e[6]}') ?? 0) : 0, by: e.length >= 8 ? '${e[7]}' : '',
                    mobile: e.length >= 9 ? '${e[8]}' : '', material: e.length >= 10 ? '${e[9]}' : '', city: e.length >= 11 ? '${e[10]}' : '', rst: e.length >= 12 ? '${e[11]}' : '', paid: e.length >= 13 && (e[12] == 1 || e[12] == true)));
              }
            }
          }
        }
      }
    } catch (_) {}
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      _outNo = p.getInt('kusbo') ?? 0;
      _extrasSaved = p.getBool('kxok') ?? false;
    } catch (_) {}
    // first run of the version that has this setting: the numbers start from 1 (the weighings made until now were tests)
    if (!hasRst) {
      rstStart = 1;
      rstSinceMs = DateTime.now().millisecondsSinceEpoch;
      unawaited(save());
    }
    // a build without the USB plug-in can only use the network way
    if (!possible && netPossible) net = true;
    notifyListeners();
    if (_want && net && netPossible) {
      await connect();
    } else if (_want && possible) {
      await refresh();
      if (autoOk) await connect();
    }
  }

  /// For the operator's app: finds the cable and connects by itself (the first COM port / USB cable), and keeps trying.
  Future<void> autoStart() async {
    await load();
    if (!possible || net || connected || busy) return;
    await refresh();
    if (autoOk && !connected && !busy) await connect();
  }

  int _i(Object? v, int d) {
    if (v is num) return v.toInt();
    return int.tryParse('${v ?? ''}') ?? d;
  }

  Future<void> save() async {
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setString('kusb', jsonEncode(<String, dynamic>{'baud': baud, 'bits': dataBits, 'stop': stopBits, 'par': parity, 'auto': auto, 'want': _want, 'net': net, 'host': host, 'port': port, 'autow': autoW, 'dev': _savedDev, 'rstn': rstStart, 'rsts': rstSinceMs}));
    } catch (_) {}
    notifyListeners();
  }

  /// The owner chooses the RST number to start from: the next entry gets [n] (older entries are not counted any more).
  Future<void> setRstStart(int n) async {
    rstStart = n < 1 ? 1 : n;
    rstSinceMs = DateTime.now().millisecondsSinceEpoch;
    await save();
  }

  /// "9600 8N1"
  String get modeText => net ? '$host:$port' : '$baud $dataBits${parity == 0 ? 'N' : (parity == 1 ? 'O' : 'E')}$stopBits';

  /// Chooses where the data comes from: false = USB plug-in, true = network bridge app.
  Future<void> setSource(bool network) async {
    if (network == net) return;
    final bool was = connected;
    await _closeSession();
    _retry?.cancel();
    _retry = null;
    net = network;
    error = '';
    if (!was) _want = false;
    await save();
    if (was) await connect();
  }

  /// The address of the bridge app (normally 127.0.0.1 and the port that app shows).
  Future<void> setNet(String h, int p) async {
    host = h.trim().isEmpty ? '127.0.0.1' : h.trim();
    port = p.clamp(1, 65535).toInt();
    await save();
  }

  /// [quiet]: the screen searches again every few seconds by itself - then nothing is touched (no error text wiped,
  /// no redraw) unless the list of cables really changed.
  Future<void> refresh({bool quiet = false}) async {
    try {
      final List<UsbDev> l = await lister();
      if (quiet) {
        final String a = devices.map((UsbDev d) => d.id).join(',');
        final String b = l.map((UsbDev d) => d.id).join(',');
        if (a == b) return;
      }
      devices = l;
      final String? keep = chosen?.id;
      UsbDev? kept, saved, best;
      for (final UsbDev d in l) {
        if (d.id == keep) kept = d;
        if (_savedDev.isNotEmpty && d.id == _savedDev) saved = d;
        if (best == null || usbPortScore(d) > usbPortScore(best)) best = d;
      }
      // the cable that worked before, else the one in use, else the best looking one; a port that can never be the weighbridge
      // (Intel SOL, Bluetooth) gives way to a real cable
      UsbDev? pick = saved ?? kept ?? best;
      if (saved == null && pick != null && best != null && usbPortScore(pick) < usbPortScore(best)) pick = best;
      chosen = pick;
      error = '';
      // connected to a port that can not be the weighbridge and a real cable has appeared: switch to it
      final UsbDev? c = chosen;
      final bool swap = !net && connected && !busy && !scanning && _connJunk && c != null && usbPortScore(c) > 0 && c.id != _connId;
      if (swap) {
        _add('USB cable found (${c.label}) - leaving ${_connId ?? 'the old port'}', 'info');
        notifyListeners();
        await connect();
        return;
      }
    } catch (e) {
      if (quiet) return;
      error = '$e';
    }
    notifyListeners();
  }

  /// The person picked a port by hand: it is used again next time. When another port is open it is switched.
  void choose(UsbDev d) {
    chosen = d;
    _savedDev = d.id.toUpperCase();
    notifyListeners();
    unawaited(save());
    if (!net && connected && !busy && d.id != _connId) unawaited(connect());
  }

  Future<void> connect() async {
    if (busy) return;
    final UsbDev? d = chosen;
    if (!net && d == null) {
      error = 'no device';
      notifyListeners();
      return;
    }
    if (net && !netPossible) {
      error = 'The network way does not work in a web page';
      notifyListeners();
      return;
    }
    busy = true;
    error = '';
    if (net) _want = true; // the network way keeps trying until the person taps Stop
    notifyListeners();
    await _closeSession();
    try {
      final UsbSession s;
      if (net) {
        final Socket sk = await Socket.connect(host, port, timeout: const Duration(seconds: 6));
        try {
          sk.setOption(SocketOption.tcpNoDelay, true);
        } catch (_) {}
        s = _TcpSession(sk);
      } else {
        s = await opener(d!, baud: baud, dataBits: dataBits, stopBits: stopBits, parity: parity);
      }
      _s = s;
      _sub = s.data.listen(_onData, onError: (Object e) => _lost('$e'), onDone: () async {
        // the reader ended: give PowerShell a moment to tell why (the real cause is shown on the screen), unless this session was replaced
        if (!net) await Future<void>.delayed(const Duration(milliseconds: 400));
        if (!identical(_s, s)) return;
        _lost(net ? '' : winLastEnd);
      }, cancelOnError: false);
      connected = true;
      connectedAt = DateTime.now();
      _want = true;
      _connId = net ? null : d!.id;
      _connJunk = !net && usbPortScore(d!) < 0;
      // a recognised USB cable that opened is remembered (Windows may give the cable another COM number on another USB socket: then the best looking one is found again)
      if (!net && usbPortScore(d!) > 0) _savedDev = d.id.toUpperCase();
      _poll?.cancel();
      _poll = Timer.periodic(const Duration(seconds: 1), (Timer _) => _tick());
      _add(net ? 'bridge $host:$port' : '${d!.label} · $modeText', 'ok');
      await save();
    } catch (e) {
      connected = false;
      error = '$e';
      _add('$e', 'warn');
      if (net && _want) _scheduleRetry();
    }
    busy = false;
    notifyListeners();
  }

  /// The network way keeps trying again every few seconds (the bridge app may be started later).
  void _scheduleRetry() {
    _retry?.cancel();
    _retry = Timer(Duration(seconds: net ? 5 : 2), () async {
      if (!_want || connected || busy) return;
      if (net) {
        await connect();
      } else {
        await refresh();
        if (_want && !connected && autoOk) await connect();
      }
    });
  }

  Future<void> _closeSession() async {
    _poll?.cancel();
    _poll = null;
    try {
      await _sub?.cancel();
    } catch (_) {}
    _sub = null;
    try {
      await _s?.close();
    } catch (_) {}
    _s = null;
    connected = false;
    _connId = null;
    _connJunk = false;
  }

  Future<void> disconnect() async {
    _want = false;
    _retry?.cancel();
    _retry = null;
    await _closeSession();
    _add('disconnected', 'info');
    await save();
  }

  void _lost(String why) {
    if (!connected) return;
    connected = false;
    error = why.isEmpty ? (net ? 'The bridge app closed the connection' : 'The cable was pulled out') : (net ? why : 'The cable stopped: $why');
    _add(error, 'warn');
    _poll?.cancel();
    _poll = null;
    notifyListeners();
    if (_want) _scheduleRetry();
  }

  void _onData(Uint8List b) {
    dec.feed(b, DateTime.now());
    _drain(false);
    _softNotify();
  }

  /// A weight indicator sends dozens of lines a second: redraw the screen at most about 4 times a second.
  void _softNotify() {
    final DateTime now = DateTime.now();
    if (now.difference(_lastNotify).inMilliseconds >= 250) {
      _lastNotify = now;
      notifyListeners();
      return;
    }
    _notifyT ??= Timer(const Duration(milliseconds: 250), () {
      _notifyT = null;
      _lastNotify = DateTime.now();
      notifyListeners();
    });
  }

  void _tick() {
    dec.poll(DateTime.now());
    _drain(false);
    if (autoW && !_matching && weighs.any((SettledWeight w) => !w.used)) unawaited(autoMatch());
    notifyListeners();
  }

  void _drain(bool demo) {
    final List<WbSlip> l = dec.take();
    for (final WbSlip s in l) {
      unawaited(_handle(s, demo));
    }
    for (final String g in dec.takeSignals()) {
      if (demo) continue;
      final DateTime now = DateTime.now();
      // the same signal again within 5 s is not written to the events again (a terminal that frames every line would flood it)
      if (g == _lastSig && now.difference(_lastSigAt).inSeconds < 5) continue;
      _lastSig = g;
      _lastSigAt = now;
      _add('terminal signal: $g', 'info');
    }
    final List<SettledWeight> sw = dec.takeSettled();
    if (!demo) {
      for (final SettledWeight w in sw) {
        _addWeigh(w);
      }
    }
  }

  void _addWeigh(SettledWeight w) {
    if (_taken.any(((double, DateTime) t) => (t.$1 - w.kg).abs() < 15 && w.at.difference(t.$2).inSeconds.abs() < 90)) w.used = true;
    if (weighs.isNotEmpty && (weighs.first.kg - w.kg).abs() < 0.5 && w.at.difference(weighs.first.at).inSeconds.abs() < 3) return;
    if (weighs.isNotEmpty && w.stay != 0 && weighs.first.stay == w.stay) {
      // the same vehicle is still standing there and the weight moved a little (the driver stepped out ...): the last one counts
      final SettledWeight old = weighs.first;
      weighs[0] = w;
      final int i = picked.indexWhere((SettledWeight x) => x.at == old.at && x.kg == old.kg);
      if (i >= 0) picked[i] = w;
      _add('stable weight ${old.kg.round()} → ${w.kg.round()} KG (same vehicle, still on the platform)', 'ok');
    } else {
      weighs.insert(0, w);
      if (weighs.length > 30) weighs.removeRange(30, weighs.length);
      _add('stable weight ${w.kg.round()} KG', 'ok');
    }
    unawaited(_saveWeighs());
    if (autoW) unawaited(autoMatch());
  }

  /// Clear-cut fits between the weights and the vehicles waiting for the weighbridge (to show, or to save by itself).
  List<AutoPair> get suggestions {
    try {
      if (!liveReady()) return const <AutoPair>[];
      return autoPairs(weighs, tripsProvider(), DateTime.now());
    } catch (_) {
      return const <AutoPair>[];
    }
  }

  /// The slip of an entry made here (what is printed / sent on WhatsApp / kept for ever by the Kanta app).
  SlipRec slipOf(AutoMade m) {
    String party = m.party;
    // a mill vehicle: the name written at the weighing wins, else the farmer of its chit
    if (!m.outside && party.trim().isEmpty) {
      try {
        party = partyProvider(m.vehicle);
      } catch (_) {}
    }
    return SlipRec(rst: m.rst, vehicle: m.vehicle, party: party, gross: m.gross, tare: m.tare, grossAt: m.wGross.at, tareAt: m.wTare.at, at: m.at, outside: m.outside, charges: m.charges, paid: m.paid, by: m.by, mobile: m.mobile, material: m.material, city: m.city);
  }

  /// The entry of an old slip (read from the history), so that it can be taken back even after the app was reopened.
  AutoMade autoMadeOf(SlipRec r) => AutoMade(r.at, r.rst, r.vehicle, r.gross, r.tare, 0, SettledWeight(r.grossAt, r.gross), SettledWeight(r.tareAt, r.tare), outside: r.outside, party: r.party, charges: r.charges, paid: r.paid, by: r.by, mobile: r.mobile, material: r.material, city: r.city);

  /// The text of the weighing slip of an entry made here (to send on WhatsApp).
  String slipText(AutoMade m) => slipTextOf(slipOf(m));

  /// Vehicles that have chits and are waiting for the weighbridge (not yet inside), to pick from at the weighing station.
  List<String> get waitingVehicles {
    try {
      if (!liveReady()) return const <String>[];
      final Set<String> inKeys = <String>{for (final InsideVehicle v in inside) vehicleKey(v.vehicle)};
      final Set<String> seen = <String>{};
      final List<String> out = <String>[];
      for (final PairTrip t in tripsProvider()) {
        final String k = vehicleKey(t.vehicle);
        if (k.isEmpty || inKeys.contains(k) || !seen.add(k)) continue;
        out.add(t.vehicle);
      }
      return out;
    } catch (_) {
      return const <String>[];
    }
  }

  Future<void> setAutoW(bool v) async {
    autoW = v;
    await save();
    notifyListeners();
    if (v) unawaited(autoMatch());
  }

  /// Saves the clear-cut fits as weighbridge entries (only when [autoW] is on). Called for every new weight and every few seconds.
  Future<int> autoMatch() async {
    if (!autoW || _matching || DateTime.now().isBefore(_autoBlockUntil)) return 0;
    _matching = true;
    int n = 0;
    try {
      for (final AutoPair p in suggestions) {
        if (await _saveAuto(p)) n++;
      }
    } finally {
      _matching = false;
    }
    if (n > 0) notifyListeners();
    return n;
  }

  Future<bool> _saveAuto(AutoPair p) async {
    final String vk = vehicleKey(p.trip.vehicle);
    final double net = p.net;
    // already in the app (made by hand meanwhile)? then only mark the weights as used
    final DateTime now = DateTime.now();
    final bool known = live.kantas.any((Kanta k) => k.vkey == vk && (k.kg - net).abs() < 1 && k.at.year == now.year && k.at.month == now.month && k.at.day == now.day);
    if (known) {
      p.gross.used = true;
      p.tare.used = true;
      unawaited(_saveWeighs());
      return false;
    }
    final String rst = await nextRstProvider();
    final SaveResult r = await submitter(<String, dynamic>{
      'rst_no': rst,
      'vehicle_number': p.trip.vehicle.trim(),
      'total_weight_kg': net,
      'net_weight_kg': net,
    });
    if (!r.ok) {
      _add('auto entry not saved (${p.trip.vehicle}): ${r.error}', 'warn');
      _autoBlockUntil = DateTime.now().add(const Duration(seconds: 60));
      return false;
    }
    p.gross.used = true;
    p.tare.used = true;
    unawaited(_saveWeighs());
    savedCount++;
    made.insert(0, AutoMade(now, rst, p.trip.vehicle, p.gross.kg, p.tare.kg, p.trip.chitKg, p.gross, p.tare));
    if (made.length > 20) made.removeRange(20, made.length);
    _add('AUTO entry RST $rst · ${p.trip.vehicle} · ${net.round()} KG (${p.gross.kg.round()} − ${p.tare.kg.round()}, chit ${p.trip.chitKg.round()})${r.queued ? ' · will be sent when online' : ''}', 'ok');
    return true;
  }

  /// Takes an automatic entry back (the wrong vehicle?): deletes it and frees the two weights. Returns '' when done.
  Future<String> undoAuto(AutoMade m) async {
    String why = '';
    Kanta? found;
    for (final Kanta k in live.kantas) {
      if (!m.outside && k.rst == m.rst && k.vkey == vehicleKey(m.vehicle)) {
        found = k;
        break;
      }
    }
    if (m.outside) {
      // nothing was sent anywhere: only the laptop slip is cancelled
    } else if (found != null) {
      why = await live.deleteEntry('kanta', found.id);
    } else {
      final int i = live.pending.indexWhere((PendingItem p) => p.kind == 'kanta' && '${p.row['rst_no'] ?? ''}' == m.rst);
      if (i >= 0) {
        live.dropPending(live.pending[i]); // also saved, so it does not come back after a restart
        live.rederive();
      } else {
        why = 'not found - delete it in the weighbridge list';
      }
    }
    if (why.isEmpty) {
      m.wGross.used = false;
      m.wTare.used = false;
      m.undone = true;
      made.remove(m);
      _add('AUTO entry RST ${m.rst} · ${m.vehicle} taken back', 'info');
      try {
        onEntryUndone?.call(m);
      } catch (_) {}
      unawaited(_saveWeighs());
      notifyListeners();
    }
    return why;
  }

  // ------------------------------------------------------------------ weighing station (details entered here)

  /// The weight on the platform when it stands still (null when empty, moving or not connected).
  double? get steadyKg {
    final double? v = dec.kg;
    if (!connected || v == null || (settleNeedStable && !dec.stable) || v <= 0 || v < settleMinKg) return null;
    return v;
  }

  /// Why there is no steady weight right now: '' (there is one), 'not connected', 'no weight', 'low' or 'moving'.
  String get steadyWhy {
    if (!connected) return 'not connected';
    final double? v = dec.kg;
    if (v == null) return 'no weight';
    if (v <= 0 || v < settleMinKg) return 'low';
    if (settleNeedStable && !dec.stable) return 'moving';
    return '';
  }

  /// The smallest weight that counts as something on the platform (0 in Balaji Kanta: any weight that stands still).
  double get minKg => settleMinKg;

  Future<void> _saveInside() async {
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setString('kusbi', jsonEncode(<List<Object>>[for (final InsideVehicle v in inside) <Object>[v.vehicle, v.kg, v.at.millisecondsSinceEpoch, v.id, v.outside ? 1 : 0, v.party, v.charges, v.by, v.mobile, v.material, v.city, v.rst, v.paid ? 1 : 0]]));
    } catch (_) {}
  }

  /// A weight of the list that is the same as [kg] and was caught lately is "used" (it must not be matched again).
  void _markUsedNear(double kg, DateTime around) {
    // the weight may be caught a moment later (it must stand still 3 s): remember it as taken
    _taken.add((kg, around));
    if (_taken.length > 20) _taken.removeAt(0);
    for (final SettledWeight w in weighs) {
      if (!w.used && (w.kg - kg).abs() < 15 && w.at.difference(around).inMinutes.abs() <= 10) {
        w.used = true;
        break;
      }
    }
    unawaited(_saveWeighs());
  }

  // ------------------------------------------------------------------ extra columns on the server
  /// Replaced by tests. Asks the server whether the table waybridge_entries has the extra columns.
  Future<bool> Function() extrasProbe = _liveExtrasProbe;
  bool? _extrasOk;
  DateTime _extrasAt = DateTime.fromMillisecondsSinceEpoch(0);

  /// True when the server table has gross_kg, tare_kg, party_name, party_mobile, material, city and charges_rs
  /// (the SQL file supabase-kanta-fields.sql). Asked once; a "no" is asked again after 5 minutes (the SQL may be run meanwhile).
  Future<bool> serverHasExtras() async {
    final bool? known = _extrasOk;
    if (known == true) return true;
    if (known == false && DateTime.now().difference(_extrasAt).inMinutes < 5) return false;
    // no internet: cannot ask - trust the answer of the last time (kept on this laptop), so an entry made offline carries its extras too
    if (offlineNow()) return _extrasSaved;
    try {
      final bool ok = await extrasProbe().timeout(const Duration(seconds: 4));
      _extrasOk = ok;
      _extrasAt = DateTime.now();
      if (ok != _extrasSaved) {
        _extrasSaved = ok;
        try {
          final SharedPreferences p = await SharedPreferences.getInstance();
          await p.setBool('kxok', ok);
        } catch (_) {}
      }
      return ok;
    } catch (_) {
      // an unclear answer: ask again next time; meanwhile the last answer counts
      _extrasOk = null;
      return _extrasSaved;
    }
  }

  /// The last answer about the extra columns (kept over restarts, for the times there is no internet).
  bool _extrasSaved = false;

  /// Is the internet known to be down (replaced in tests).
  bool Function() offlineNow = () => live.offline;

  /// The slip number the next road vehicle will get ("R-12").
  String get nextRoadSlip => 'R-${_outNo + 1}';

  /// The RST number the next mill vehicle will get (shown on the first-weighing screen). Reserved numbers of vehicles inside are skipped.
  Future<String> peekRst() async {
    String r = await nextRstProvider();
    int guard = 0;
    while (inside.any((InsideVehicle x) => x.rst == r) && guard++ < 500) {
      r = '${(int.tryParse(r) ?? 0) + 1}';
    }
    return r;
  }

  Future<String> _reserveRst() => peekRst();

  /// First weighing of a vehicle (gross when it comes loaded). Returns '' when done, otherwise the reason.
  /// [outside]: a vehicle from the road - its weighing stays on the laptop (with [party] and [charges] of its own).
  /// [by]: the person who took it from a phone (remote weighing); empty at the laptop.
  /// [mobile], [material], [city]: what the operator wrote at the weighing (optional; they go on the slip and into the laptop files).
  Future<String> takeFirst(String vehicle, {bool outside = false, String party = '', double charges = 0, bool paid = false, String by = '', String mobile = '', String material = '', String city = ''}) async {
    final String v = vehicle.trim().toUpperCase();
    if (v.isEmpty) return 'vehicle';
    final double? kg = steadyKg;
    if (kg == null) return 'no steady weight';
    inside.removeWhere((InsideVehicle x) => vehicleKey(x.vehicle) == vehicleKey(v));
    final DateTime now = DateTime.now();
    final String rst = outside ? '' : await _reserveRst();
    inside.insert(0, InsideVehicle('${now.microsecondsSinceEpoch}', v, kg, now, outside: outside, party: party.trim(), charges: charges, by: by, mobile: mobile.trim(), material: material.trim(), city: city.trim(), rst: rst, paid: paid));
    _markUsedNear(kg, now);
    _add('first weight $v ${kg.round()} KG - inside${outside ? ' (road vehicle)' : ' · RST $rst'}${by.isEmpty ? '' : ' · $by'}', 'ok');
    try {
      onFirstTaken?.call(v, kg, now, outside);
    } catch (_) {}
    await _saveInside();
    notifyListeners();
    return '';
  }

  /// Direct weighing (the Matrix terminal's "Manual Tare"): the tare (empty weight) is written by hand, the weight on the platform now is the
  /// gross, and the entry is made at once - the vehicle does not have to go and come back. Returns '' when done, otherwise the reason.
  Future<String> takeDirect(String vehicle, double tareKg, {bool outside = false, String party = '', double charges = 0, bool paid = false, String by = '', String mobile = '', String material = '', String city = ''}) async {
    final String v = vehicle.trim().toUpperCase();
    if (v.isEmpty) return 'vehicle';
    if (tareKg <= 0) return 'tare';
    final double? kg = steadyKg;
    if (kg == null) return 'no steady weight';
    if (kg <= tareKg) return 'tare high';
    final DateTime now = DateTime.now();
    final InsideVehicle iv = InsideVehicle('${now.microsecondsSinceEpoch}', v, tareKg, now, outside: outside, party: party.trim(), charges: charges, by: by, mobile: mobile.trim(), material: material.trim(), city: city.trim(), paid: paid);
    inside.removeWhere((InsideVehicle x) => vehicleKey(x.vehicle) == vehicleKey(v));
    inside.insert(0, iv);
    final String r = await takeSecond(iv);
    if (r.isNotEmpty) {
      inside.removeWhere((InsideVehicle x) => x.id == iv.id);
      notifyListeners();
    } else {
      _add('DIRECT weighing $v · tare ${tareKg.round()} KG written by hand · gross ${kg.round()} KG', 'ok');
    }
    return r;
  }

  /// Second weighing: net = bigger - smaller. Saves the weighbridge entry (online, or queued when offline).
  Future<String> takeSecond(InsideVehicle v, {String by = ''}) async {
    final double? kg = steadyKg;
    if (kg == null) return 'no steady weight';
    if ((kg - v.kg).abs() < 0.5) return 'same weight'; // exactly the same: the vehicle has not moved, a net of 0 means nothing
    final double g = kg > v.kg ? kg : v.kg;
    final double t = kg > v.kg ? v.kg : kg;
    final double net = g - t;
    final DateTime now = DateTime.now();
    final String who = <String>{if (v.by.isNotEmpty) v.by, if (by.isNotEmpty) by}.join(' + ');
    if (v.outside) {
      // a vehicle from the road: only on this laptop (own slip number), nothing goes to the app / server
      _outNo++;
      try {
        final SharedPreferences p = await SharedPreferences.getInstance();
        await p.setInt('kusbo', _outNo);
      } catch (_) {}
      final String no = 'R-$_outNo';
      inside.removeWhere((InsideVehicle x) => x.id == v.id);
      _markUsedNear(kg, now);
      made.insert(0, AutoMade(now, no, v.vehicle, g, t, 0, SettledWeight(v.at, g), SettledWeight(now, t), outside: true, party: v.party, charges: v.charges, paid: v.paid, by: who, mobile: v.mobile, material: v.material, city: v.city));
      if (made.length > 20) made.removeRange(20, made.length);
      try {
        onEntryMade?.call(made.first);
      } catch (_) {}
      _add('ROAD vehicle slip $no · ${v.vehicle} · ${net.round()} KG (${g.round()} − ${t.round()}) - laptop only', 'ok');
      await _saveInside();
      notifyListeners();
      return '';
    }
    final String rst = v.rst.isNotEmpty ? v.rst : await nextRstProvider();
    final Map<String, dynamic> row = <String, dynamic>{
      'rst_no': rst,
      'vehicle_number': v.vehicle,
      'total_weight_kg': net,
      'net_weight_kg': net,
    };
    // gross / tare / party / material / city / mobile / charges go to the server too - only when its table has those columns
    // (supabase-kanta-fields.sql was run); otherwise they stay on the laptop (slip + files) and nothing can fail
    if (await serverHasExtras()) {
      row['gross_kg'] = g;
      row['tare_kg'] = t;
      if (v.party.isNotEmpty) row['party_name'] = v.party;
      if (v.mobile.isNotEmpty) row['party_mobile'] = v.mobile;
      if (v.material.isNotEmpty) row['material'] = v.material;
      if (v.city.isNotEmpty) row['city'] = v.city;
      if (v.charges > 0) row['charges_rs'] = v.charges;
    }
    final SaveResult r = await submitter(row);
    if (!r.ok) {
      _add('entry not saved (${v.vehicle}): ${r.error}', 'warn');
      return r.error.isEmpty ? 'not saved' : r.error;
    }
    // the server may have given another number (the one asked for was already used there)
    final String asked = rst;
    final String rstNo = r.rst.isNotEmpty ? r.rst : asked;
    if (rstNo != asked) _add('RST $asked was already used on the server - ${v.vehicle} got RST $rstNo', 'warn');
    inside.removeWhere((InsideVehicle x) => x.id == v.id);
    _markUsedNear(kg, now);
    savedCount++;
    made.insert(0, AutoMade(now, rstNo, v.vehicle, g, t, 0, SettledWeight(v.at, g), SettledWeight(now, t), by: who, party: v.party, charges: v.charges, paid: v.paid, mobile: v.mobile, material: v.material, city: v.city));
    if (made.length > 20) made.removeRange(20, made.length);
    try {
      onEntryMade?.call(made.first);
    } catch (_) {}
    _add('ENTRY RST $rstNo · ${v.vehicle} · ${net.round()} KG (${g.round()} − ${t.round()})${r.queued ? ' · will be sent when online' : ''}', 'ok');
    await _saveInside();
    notifyListeners();
    return '';
  }

  void dropInside(InsideVehicle v) {
    inside.removeWhere((InsideVehicle x) => x.id == v.id);
    unawaited(_saveInside());
    notifyListeners();
  }

  /// Ticks the last two weights (loaded + empty).
  void pickLastTwo() {
    if (weighs.length < 2) return;
    picked
      ..clear()
      ..add(weighs[1])
      ..add(weighs[0]);
    notifyListeners();
  }

  Future<void> _saveWeighs() async {
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setString('kusbw', jsonEncode(<List<Object>>[for (final SettledWeight w in weighs) <Object>[w.at.millisecondsSinceEpoch, w.kg, w.stay, w.used]]));
    } catch (_) {}
  }

  /// Tick / untick a captured weight (the last two ticks are kept: gross and tare).
  void togglePick(SettledWeight w) {
    final int i = picked.indexWhere((SettledWeight x) => x.at == w.at && x.kg == w.kg);
    if (i >= 0) {
      picked.removeAt(i);
    } else {
      picked.add(w);
      if (picked.length > 2) picked.removeAt(0);
    }
    notifyListeners();
  }

  bool isPicked(SettledWeight w) => picked.any((SettledWeight x) => x.at == w.at && x.kg == w.kg);

  void removeWeigh(SettledWeight w) {
    weighs.removeWhere((SettledWeight x) => x.at == w.at && x.kg == w.kg);
    picked.removeWhere((SettledWeight x) => x.at == w.at && x.kg == w.kg);
    unawaited(_saveWeighs());
    notifyListeners();
  }

  void clearWeighs() {
    weighs.clear();
    picked.clear();
    unawaited(_saveWeighs());
    notifyListeners();
  }

  /// Test input, no cable needed. A demo slip is never saved.
  void demoFeed(Uint8List b) {
    _drain(false);
    _demo = true;
    dec.feed(b, DateTime.now());
    dec.poll(DateTime.now().add(const Duration(seconds: 5)));
    _drain(true);
    _demo = false;
    notifyListeners();
  }

  bool get demoNow => _demo;

  Future<void> _handle(WbSlip s, bool demo) async {
    final KantaRow r = KantaRow.fromSlip(s);
    final String what = 'RST ${r.rst.isEmpty ? '-' : r.rst} · ${r.vehicle.isEmpty ? '-' : r.vehicle}';
    if (!r.ok) {
      if (r.partial) {
        waiting.removeWhere((KantaRow w) => w.key == r.key);
        waiting.insert(0, r);
        if (waiting.length > 20) waiting.removeLast();
        _add('$what · ${demo ? '[demo] ' : ''}first weight only (${r.gross > 0 ? '${r.gross.round()}' : 'tare ${r.tare.round()}'} KG) - waiting for the second weight', 'info');
      } else {
        _add('$what · could not be read', 'warn');
      }
      notifyListeners();
      return;
    }
    waiting.removeWhere((KantaRow w) => w.key == r.key || (w.vehicle == r.vehicle && w.rst.isEmpty));
    if (demo) {
      _add('[demo] $what · ${r.weight.round()} KG - a demo slip is never saved', 'info');
      notifyListeners();
      return;
    }
    if (kantaAuto.seen.contains(r.key) || kantaKnown(r)) {
      _add('$what · ${r.weight.round()} KG - already in the app', 'info');
      notifyListeners();
      return;
    }
    if (_inflight.contains(r.key)) return;
    if (auto) {
      _inflight.add(r.key);
      final int n = await kantaAuto.send(<KantaRow>[r]);
      _inflight.remove(r.key);
      if (n == 1) {
        savedCount++;
        _add('$what · ${r.weight.round()} KG - saved', 'ok');
      } else {
        _add('$what · not saved: ${kantaAuto.msg}', 'warn');
        _keepReady(r);
      }
    } else {
      _keepReady(r);
      _add('$what · ${r.weight.round()} KG - ready, tap Save', 'ok');
    }
    notifyListeners();
  }

  void _keepReady(KantaRow r) {
    if (ready.any((KantaRow x) => x.key == r.key)) return;
    ready.insert(0, r);
    if (ready.length > 40) ready.removeLast();
  }

  /// Saves the slips that are waiting for a tap (auto-save off).
  Future<int> saveReady() async {
    if (ready.isEmpty) return 0;
    final List<KantaRow> l = List<KantaRow>.from(ready);
    final int n = await kantaAuto.send(l);
    if (n > 0) {
      savedCount += n;
      ready.removeWhere((KantaRow x) => kantaAuto.seen.contains(x.key));
      _add('$n saved', 'ok');
    } else if (kantaAuto.msg.isNotEmpty) {
      _add('not saved: ${kantaAuto.msg}', 'warn');
    }
    notifyListeners();
    return n;
  }

  void dropReady(KantaRow r) {
    ready.removeWhere((KantaRow x) => x.key == r.key);
    kantaAuto.seen.add(r.key);
    kantaAuto.save();
    notifyListeners();
  }

  Future<void> setAuto(bool v) async {
    auto = v;
    await save();
    if (v && ready.isNotEmpty) await saveReady();
  }

  Future<void> setMode({int? baud, int? bits, int? stop, int? par}) async {
    if (baud != null) this.baud = baud;
    if (bits != null) dataBits = bits;
    if (stop != null) stopBits = stop;
    if (par != null) parity = par;
    await save();
    if (connected) await connect();
  }

  /// Tries every usual speed for a few seconds and keeps the one that gives readable text.
  /// Returns a short sentence about the result.
  Future<String> findSpeed() async {
    if (net || chosen == null || scanning) return 'no device';
    final bool was = connected || _want;
    scanning = true;
    notifyListeners();
    await _closeSession();
    String best = '';
    double bestScore = 0;
    int bestBytes = 0;
    int bestBaud = baud;
    int total = 0;
    try {
      for (final int b in <int>[9600, 19200, 4800, 2400, 1200, 38400, 57600, 115200]) {
        progress = '$b ...';
        notifyListeners();
        final List<int> got = <int>[];
        UsbSession? s;
        StreamSubscription<Uint8List>? sub;
        try {
          s = await opener(chosen!, baud: b, dataBits: dataBits, stopBits: stopBits, parity: parity);
          sub = s.data.listen(got.addAll);
          await Future<void>.delayed(const Duration(milliseconds: 3000));
        } catch (e) {
          error = '$e';
        }
        try {
          await sub?.cancel();
          await s?.close();
        } catch (_) {}
        total += got.length;
        final double sc = serialTextScore(got);
        if (got.length >= 6 && sc > bestScore + 0.001 && sc >= 0.85) {
          bestScore = sc;
          bestBaud = b;
          bestBytes = got.length;
          best = String.fromCharCodes(got.where((int x) => x >= 0x20 && x <= 0x7E).take(40));
        }
        if (sc >= 0.97 && got.length >= 12) break;
      }
    } finally {
      scanning = false;
      progress = '';
    }
    String res;
    if (bestBytes > 0) {
      baud = bestBaud;
      await save();
      res = '$bestBaud: "$best"';
      _add('speed $bestBaud · $bestBytes bytes · "$best"', 'ok');
    } else if (total == 0) {
      res = 'nothing came';
      _add('no data came at any speed', 'warn');
    } else {
      res = 'garbage only';
      _add('data came but no speed gave readable text', 'warn');
    }
    if (was) await connect();
    notifyListeners();
    return res;
  }

  /// Everything seen, to copy and send for fitting the exact format.
  String report() {
    final StringBuffer b = StringBuffer();
    b.writeln('Balaji Pro USB capture · ${net ? 'network bridge' : modeText} · ${net ? '$host:$port' : (chosen?.label ?? '-')}');
    b.writeln('bytes ${dec.bytes} · lines ${dec.lineCount} · weight lines ${dec.weightLines} · other lines ${dec.others.length} · NUL bytes ${dec.nulBytes}${dec.rate > 0 ? ' · about ${dec.rate.toStringAsFixed(0)} weight lines/second' : ''}');
    b.writeln('--- other lines (NOT a weight: slip text, headers ...) ---');
    b.writeln(dec.others.isEmpty ? '(none - only weight lines came)' : dec.others.join('\n'));
    if (dec.othersHex.isNotEmpty) {
      b.writeln('--- other lines (hex) ---');
      b.writeln(dec.othersHex.join('\n'));
    }
    b.writeln('--- signals (control bytes between lines, e.g. 00 x10) ---');
    b.writeln(dec.signals.isEmpty ? '(none)' : dec.signals.join('\n'));
    b.writeln('--- stable weights ---');
    b.writeln(weighs.isEmpty ? '(none)' : weighs.reversed.map((SettledWeight w) => '${w.at.hour.toString().padLeft(2, '0')}:${w.at.minute.toString().padLeft(2, '0')}:${w.at.second.toString().padLeft(2, '0')}  ${w.kg.round()} KG').join('\n'));
    b.writeln('--- weight lines (the same line in a row is written once: "x240" = 240 times) ---');
    b.writeln(dec.logText());
    b.writeln('--- last bytes (hex) ---');
    b.writeln(dec.hexTail(256));
    return b.toString();
  }

  void clearCapture() {
    dec.clear();
    waiting.clear();
    notifyListeners();
  }
}

final KantaUsbService kantaUsb = KantaUsbService();
