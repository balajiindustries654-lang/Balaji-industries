import 'insights.dart';
import 'money.dart';
import '../core/i18n.dart';
import 'vouchers.dart';

// ======================================================================
// Books of account, the TallyPrime way
//   Ledger (Dr / Cr with opening and closing balance) and the Trial Balance, worked out from the vouchers.
//   Debit / Credit rule: a farmer ledger is credited by a purchase and debited by a payment; a buyer ledger is
//   debited by a sale and credited by a receipt; an expense debits its head, an income credits it.
// ======================================================================

class LedgerRef {
  final String dim; // farmer | buyer | head
  final String key;
  final String name;
  const LedgerRef(this.dim, this.key, this.name);
}

/// One ledger for a period: opening balance, the vouchers of the period and the closing balance. Dr is positive, Cr is negative.
class Ledger {
  final LedgerRef ref;
  final Period period;
  final double opening;
  final List<Vch> rows;
  final double dr;
  final double cr;
  const Ledger(this.ref, this.period, this.opening, this.rows, this.dr, this.cr);

  double get closing => opening + dr - cr;
}

Ledger buildLedger(LedgerRef ref, Period p) {
  double open = 0;
  double dr = 0;
  double cr = 0;
  final List<Vch> rows = <Vch>[];
  for (final Vch v in ledgerVouchers(ref.dim, ref.key)) {
    if (v.date.isBefore(p.from)) {
      open += v.dr - v.cr;
    } else if (v.date.isBefore(p.to)) {
      rows.add(v);
      dr += v.dr;
      cr += v.cr;
    }
  }
  return Ledger(ref, p, open, rows, dr, cr);
}

/// A line of the list of ledgers (name, period debit / credit and the closing balance).
class LedgerSum {
  final LedgerRef ref;
  double opening = 0;
  double dr = 0;
  double cr = 0;
  int count = 0;
  LedgerSum(this.ref);

  double get closing => opening + dr - cr;
}

String _headName(String key) => expCatLabel(key);

/// All ledgers of one kind (farmer | buyer | head) with their totals for the period.
List<LedgerSum> ledgerList(String dim, Period p) {
  final DateTime from = khataFrom();
  final Map<String, LedgerSum> m = <String, LedgerSum>{};
  for (final Vch v in allVouchers()) {
    if (v.dim != dim || v.partyKey.isEmpty) continue;
    if (!inLedger(v, from)) continue;
    final LedgerSum s = m.putIfAbsent(v.partyKey, () => LedgerSum(LedgerRef(dim, v.partyKey, dim == 'head' ? _headName(v.partyKey) : v.party)));
    if (v.date.isBefore(p.from)) {
      s.opening += v.dr - v.cr;
    } else if (v.date.isBefore(p.to)) {
      s.dr += v.dr;
      s.cr += v.cr;
      s.count++;
    }
  }
  final List<LedgerSum> out = m.values.toList();
  out.sort((LedgerSum a, LedgerSum b) => a.ref.name.toLowerCase().compareTo(b.ref.name.toLowerCase()));
  return out;
}

// ---------------------------------------------------------------- financial year
/// 1 April of the financial year that [d] falls in.
DateTime finYearStart(DateTime d) => d.month >= 4 ? DateTime(d.year, 4, 1) : DateTime(d.year - 1, 4, 1);

String finYearLabel(DateTime start) {
  final String a = '${start.year}';
  final String b = '${(start.year + 1) % 100}'.padLeft(2, '0');
  return '$a-$b';
}

// ---------------------------------------------------------------- trial balance
class TbLine {
  final String name;
  final double dr;
  final double cr;
  final LedgerRef? ref; // a ledger to open
  final String go; // a screen to open (cashbook, daybook)
  final String arg; // argument for it
  final List<TbLine> kids;
  const TbLine(this.name, this.dr, this.cr, {this.ref, this.go = '', this.arg = '', this.kids = const <TbLine>[]});
}

class TrialBal {
  final List<TbLine> lines;
  final double dr;
  final double cr;
  final double diff; // + = credit is more (shown on the debit side), - = debit is more
  const TrialBal(this.lines, this.dr, this.cr, this.diff);
}

TbLine _side(String name, double net, {LedgerRef? ref, String go = '', String arg = '', List<TbLine> kids = const <TbLine>[]}) {
  return TbLine(name, net > 0 ? net : 0, net < 0 ? -net : 0, ref: ref, go: go, arg: arg, kids: kids);
}

/// Trial balance for a period: ledgers, cash and bank are the closing balance on the last day; purchases, sales, expenses and
/// incomes are the totals of the period; the profit / loss of the earlier periods is carried in "Profit & Loss A/c (opening)".
TrialBal trialBalance(Period p) {
  final DateTime kf = khataFrom();
  final List<Vch> all = allVouchers();
  final Period upTo = Period(DateTime(2000), p.to);

  // sundry creditors (farmers) and debtors (buyers)
  List<TbLine> partyKids(String dim) {
    final List<TbLine> k = <TbLine>[];
    for (final LedgerSum s in ledgerList(dim, upTo)) {
      final double c = s.closing;
      if (c.abs() < 0.005) continue;
      k.add(_side(s.ref.name, c, ref: s.ref));
    }
    k.sort((TbLine a, TbLine b) => (b.dr + b.cr).compareTo(a.dr + a.cr));
    return k;
  }

  double net(List<TbLine> k) {
    double t = 0;
    for (final TbLine x in k) {
      t += x.dr - x.cr;
    }
    return t;
  }

  final List<TbLine> farmers = partyKids('farmer');
  final List<TbLine> buyers = partyKids('buyer');

  // profit and loss accounts
  double purchase = 0;
  double sales = 0;
  double plBefore = 0; // credit positive
  final Map<String, double> exp = <String, double>{};
  final Map<String, double> inc = <String, double>{};
  // cash, bank, journals
  double bank = 0;
  double journal = 0; // debit positive: what the parties got through journals
  for (final Vch v in all) {
    final bool before = v.date.isBefore(p.from);
    final bool inP = !before && v.date.isBefore(p.to);
    final bool upto = v.date.isBefore(p.to);
    if (v.type == 'CON') {
      // contra: cash deposited comes into the bank, cash withdrawn goes out (the cash side is in the cash book)
      if (upto) bank += v.kind == 'dep' ? v.amt : -v.amt;
      continue;
    }
    if (!inLedger(v, kf)) {
      // not in a party ledger: kept out of the books, like the farmer screens do
      if (v.src == 'chit') continue;
    }
    if (v.src == 'chit') {
      if (before) plBefore -= v.cr;
      if (inP) purchase += v.cr;
    } else if (v.type == 'SAL') {
      if (before) plBefore += v.dr - v.tax;
      if (inP) sales += v.dr - v.tax;
    } else if (v.type == 'DNT') {
      if (before) plBefore += v.dr;
      if (inP) purchase -= v.dr;
    } else if (v.type == 'CNT') {
      if (before) plBefore -= v.cr;
      if (inP) sales -= v.cr;
    } else if (v.type == 'EXP') {
      if (v.partyKey != kGstHead) {
        if (before) plBefore -= v.dr;
        if (inP) exp[v.partyKey] = (exp[v.partyKey] ?? 0) + v.dr;
      }
    } else if (v.type == 'INC') {
      if (before) plBefore += v.cr;
      if (inP) inc[v.partyKey] = (inc[v.partyKey] ?? 0) + v.cr;
    } else if (v.type == 'JRN') {
      if (upto && inLedger(v, kf)) journal += v.dr - v.cr;
    }
    if (upto && v.mode.isNotEmpty && v.mode != 'cash' && v.type != 'JRN') {
      final bool moneyIn = v.type == 'RCT' || v.type == 'INC';
      final bool moneyOut = v.type == 'PAY' || v.type == 'EXP';
      if (moneyIn) bank += v.amt;
      if (moneyOut) bank -= v.amt;
    }
  }
  final double cash = cashOpening(p.to);
  final double duty = gstDuty(upTo).closing; // credit positive

  final List<TbLine> out = <TbLine>[];
  if (farmers.isNotEmpty) out.add(_side(bi('સુંદરી લેણદાર (ખેડૂત)', 'Sundry Creditors (Farmers)'), net(farmers), kids: farmers));
  if (buyers.isNotEmpty) out.add(_side(bi('સુંદરી દેવાદાર (ખરીદનાર)', 'Sundry Debtors (Buyers)'), net(buyers), kids: buyers));
  if (cash.abs() >= 0.005) out.add(_side(bi('રોકડ (Cash-in-hand)', 'Cash-in-hand'), cash, go: 'cashbook'));
  if (bank.abs() >= 0.005) out.add(_side(bi('બેંક / UPI / ચેક', 'Bank / UPI / Cheque'), bank));
  if (duty.abs() >= 0.005) out.add(_side(bi('ડ્યુટી અને ટેક્સ (GST)', 'Duties & Taxes (GST)'), -duty));
  if (purchase.abs() >= 0.005) out.add(_side(bi('ખરીદ ખાતું', 'Purchase Accounts'), purchase, go: 'my_daybook', arg: 'PUR'));
  if (sales.abs() >= 0.005) out.add(_side(bi('વેચાણ ખાતું', 'Sales Accounts'), -sales, go: 'my_daybook', arg: 'SAL'));
  if (exp.isNotEmpty) {
    final List<TbLine> k = <TbLine>[
      for (final MapEntry<String, double> e in exp.entries) _side(expCatLabel(e.key), e.value, ref: LedgerRef('head', e.key, expCatLabel(e.key))),
    ];
    k.sort((TbLine a, TbLine b) => b.dr.compareTo(a.dr));
    out.add(_side(bi('ખર્ચ (Indirect Expenses)', 'Indirect Expenses'), net(k), kids: k));
  }
  if (inc.isNotEmpty) {
    final List<TbLine> k = <TbLine>[
      for (final MapEntry<String, double> e in inc.entries) _side(expCatLabel(e.key), -e.value, ref: LedgerRef('head', e.key, expCatLabel(e.key))),
    ];
    k.sort((TbLine a, TbLine b) => b.cr.compareTo(a.cr));
    out.add(_side(bi('આવક (Indirect Incomes)', 'Indirect Incomes'), net(k), kids: k));
  }
  if (plBefore.abs() >= 0.005) out.add(_side(bi('નફો-નુકસાન ખાતું (શરૂઆતનું)', 'Profit & Loss A/c (opening)'), -plBefore));
  if (journal.abs() >= 0.005) out.add(_side(bi('જર્નલ / જૂના બાકી (ઓપનિંગ)', 'Opening balances (journal)'), -journal));
  final double seed = cashSeedDate() == null ? 0 : cashSeed();
  if (seed.abs() >= 0.005) out.add(_side(bi('મૂડી (શરૂઆતની રોકડ)', 'Capital (opening cash)'), -seed));

  double dr = 0;
  double cr = 0;
  for (final TbLine l in out) {
    dr += l.dr;
    cr += l.cr;
  }
  final double diff = cr - dr; // + : credit is more, the difference is shown on the debit side
  return TrialBal(out, dr, cr, diff);
}
