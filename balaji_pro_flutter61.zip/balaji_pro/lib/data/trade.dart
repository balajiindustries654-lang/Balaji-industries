import '../core/i18n.dart';
import 'engine.dart';
import 'insights.dart';
import 'live_models.dart';
import 'live_store.dart';
import 'owner_docs.dart';
import 'vno.dart';

/// Sales to buyers, processing batches and the stock worked out from them.
/// Everything is kept in two shared documents (see [SyncDoc]).

final SyncDoc saleDoc = SyncDoc('flutter_sales');
final SyncDoc procDoc = SyncDoc('flutter_process');

String _k(String s) => s.trim().toLowerCase().replaceAll(RegExp(r'\s+'), ' ');

/// Grade names offered when nothing was typed before: [gu, en].
const List<List<String>> kGradeDefaults = <List<String>>[
  <String>['દાણા', 'Kernel'],
  <String>['દાણા 2', 'Kernel 2'],
  <String>['ભુકો', 'Broken'],
  <String>['ફોતરાં', 'Husk'],
  <String>['કચરો', 'Waste'],
];

// ------------------------------------------------------------------- sales
class SaleItem {
  final String id;
  final DateTime date;
  final String buyer;
  final String key;
  final String kind; // sale | recv | open
  final String src; // raw | out ('' when not a sale)
  final String item; // material code (raw) or grade name (out)
  final double kg;
  final int bags;
  final double rate; // Rs per 20 kg
  final double amt;
  final String vehicle;
  final String bill;
  final String mode;
  final String note;
  final DateTime at;
  final int no; // voucher number (0 = not numbered yet)
  final String ref; // UTR / cheque number
  final String jt; // journal type of an 'open' entry: '' = plain journal, 'cn' = Credit Note (sales return)
  const SaleItem({
    required this.id,
    required this.date,
    required this.buyer,
    required this.key,
    required this.kind,
    required this.src,
    required this.item,
    required this.kg,
    required this.bags,
    required this.rate,
    required this.amt,
    required this.vehicle,
    required this.bill,
    required this.mode,
    required this.note,
    required this.at,
    this.no = 0,
    this.ref = '',
    this.jt = '',
  });

  bool get isSale => kind == 'sale';

  /// How much this entry changes what the buyer owes us.
  double get effect => kind == 'recv' ? -amt : amt;
}

List<SaleItem> saleItems() {
  final List<SaleItem> out = <SaleItem>[];
  for (final Map<String, dynamic> m in saleDoc.list('items')) {
    final DateTime? d = DateTime.tryParse('${m['date'] ?? ''}');
    if (d == null) continue;
    final String buyer = '${m['buyer'] ?? ''}';
    out.add(SaleItem(
      id: '${m['id'] ?? ''}',
      date: dayOf(d),
      buyer: buyer,
      key: '${m['key'] ?? nameKey(buyer)}',
      kind: '${m['kind'] ?? 'sale'}',
      src: '${m['src'] ?? ''}',
      item: '${m['item'] ?? ''}',
      kg: dbl(m['kg']),
      bags: dbl(m['bags']).round(),
      rate: dbl(m['rate']),
      amt: dbl(m['amt']),
      vehicle: '${m['vehicle'] ?? ''}',
      bill: '${m['bill'] ?? ''}',
      mode: '${m['mode'] ?? 'cash'}',
      note: '${m['note'] ?? ''}',
      at: DateTime.tryParse('${m['at'] ?? ''}') ?? d,
      no: vnoOf(m['no']),
      ref: '${m['ref'] ?? ''}',
      jt: '${m['jt'] ?? ''}',
    ));
  }
  out.sort((SaleItem a, SaleItem b) {
    final int c = b.date.compareTo(a.date);
    return c != 0 ? c : b.at.compareTo(a.at);
  });
  return out;
}

Future<void> addSale({
  required String buyer,
  required String kind,
  required DateTime date,
  required double amt,
  String src = '',
  String item = '',
  double kg = 0,
  int bags = 0,
  double rate = 0,
  String vehicle = '',
  String bill = '',
  String mode = 'cash',
  String note = '',
  String ref = '',
  String jt = '',
}) async {
  await ensureVoucherNumbers();
  await saleDoc.commit(() {
    final List<Map<String, dynamic>> l = saleDoc.list('items');
    l.add(<String, dynamic>{
      if (jt.isNotEmpty) 'jt': jt,
      'no': nextVoucherNo(saleCode(kind, jt: jt)),
      'ref': ref.trim(),
      'id': '${DateTime.now().microsecondsSinceEpoch}',
      'date': dayKey(date),
      'buyer': buyer.trim(),
      'key': nameKey(buyer),
      'kind': kind,
      'src': src,
      'item': item.trim(),
      'kg': kg,
      'bags': bags,
      'rate': rate,
      'amt': amt,
      'vehicle': vehicle.trim(),
      'bill': bill.trim(),
      'mode': mode,
      'note': note.trim(),
      'at': DateTime.now().toIso8601String(),
    });
  });
}

/// Alter a sale / receipt / journal voucher (keeps its id, number and time of entry).
Future<void> updateSale(
  String id, {
  required String buyer,
  required DateTime date,
  required double amt,
  String src = '',
  String item = '',
  double kg = 0,
  int bags = 0,
  double rate = 0,
  String vehicle = '',
  String bill = '',
  String mode = 'cash',
  String note = '',
  String ref = '',
}) {
  return saleDoc.commit(() {
    for (final Map<String, dynamic> m in saleDoc.list('items')) {
      if ('${m['id']}' != id) continue;
      m['date'] = dayKey(date);
      m['buyer'] = buyer.trim();
      m['key'] = nameKey(buyer);
      m['src'] = src;
      m['item'] = item.trim();
      m['kg'] = kg;
      m['bags'] = bags;
      m['rate'] = rate;
      m['amt'] = amt;
      m['vehicle'] = vehicle.trim();
      m['bill'] = bill.trim();
      m['mode'] = mode;
      m['note'] = note.trim();
      m['ref'] = ref.trim();
      m['alt'] = DateTime.now().toIso8601String();
    }
  });
}

// ---------------------------------------------------------------- credit limit
/// Credit limit of a buyer in Rs (0 = none). A sale that takes the balance above it asks for confirmation.
double buyerLimit(String key) {
  final Object? m = prefDoc.data['buyerLimit'];
  if (m is! Map) return 0;
  final Object? v = m[key];
  if (v is num) return v.toDouble();
  return double.tryParse('${v ?? ''}') ?? 0;
}

Future<void> setBuyerLimit(String key, double v) {
  return prefDoc.commit(() {
    final Object? cur = prefDoc.data['buyerLimit'];
    final Map<String, dynamic> m = cur is Map ? Map<String, dynamic>.from(cur) : <String, dynamic>{};
    if (v > 0) {
      m[key] = v;
    } else {
      m.remove(key);
    }
    prefDoc.data['buyerLimit'] = m;
  });
}

Future<void> removeSale(String id) {
  return saleDoc.commit(() {
    saleDoc.list('items').removeWhere((Map<String, dynamic> m) => '${m['id']}' == id);
  });
}

class BuyerAcct {
  final String key;
  final String label;
  double sales = 0;
  double recv = 0;
  double open = 0;
  double kg = 0;
  int bills = 0;
  DateTime? last;
  BuyerAcct(this.key, this.label);

  /// Positive: the buyer owes us.
  double get balance => sales + open - recv;
}

Map<String, BuyerAcct> buyerAccts() {
  final Map<String, BuyerAcct> m = <String, BuyerAcct>{};
  for (final SaleItem s in saleItems()) {
    if (s.key.isEmpty) continue;
    final BuyerAcct a = m.putIfAbsent(s.key, () => BuyerAcct(s.key, s.buyer));
    if (s.kind == 'sale') {
      a.sales += s.amt;
      a.kg += s.kg;
      a.bills++;
    } else if (s.kind == 'recv') {
      a.recv += s.amt;
    } else {
      a.open += s.amt;
    }
    final DateTime? l = a.last;
    if (l == null || s.date.isAfter(l)) a.last = s.date;
  }
  return m;
}

// ------------------------------------------------------------ buyer phones
/// Mobile number noted for a buyer ('' when none).
String buyerPhone(String key) {
  final Object? m = saleDoc.data['phones'];
  if (m is Map && m[key] != null) return '${m[key]}';
  return '';
}

Future<void> setBuyerPhone(String key, String phone) {
  return saleDoc.commit(() {
    final Map<String, dynamic> m = saleDoc.map('phones');
    final String d = phone.replaceAll(RegExp(r'[^0-9]'), '');
    if (d.isEmpty) {
      m.remove(key);
    } else {
      m[key] = d.length > 10 ? d.substring(d.length - 10) : d;
    }
  });
}

// ------------------------------------------------------------------- aging
/// What one buyer still owes, split by how old the unpaid bills are.
/// Money received is set against the oldest bills first.
class AgedBuyer {
  final String key;
  final String label;
  /// 0-15, 16-30, 31-60 and over 60 days.
  final List<double> bucket = <double>[0, 0, 0, 0];
  double credit = 0; // money received beyond all bills (advance)
  DateTime? oldest;
  AgedBuyer(this.key, this.label);

  double get due => bucket[0] + bucket[1] + bucket[2] + bucket[3];
  int get oldDays => oldest == null ? 0 : dayOf(DateTime.now()).difference(oldest!).inDays;
}

int agingBucket(int days) => days <= 15 ? 0 : (days <= 30 ? 1 : (days <= 60 ? 2 : 3));

List<AgedBuyer> agedBuyers() {
  final Map<String, List<SaleItem>> by = <String, List<SaleItem>>{};
  for (final SaleItem s in saleItems()) {
    if (s.key.isEmpty) continue;
    by.putIfAbsent(s.key, () => <SaleItem>[]).add(s);
  }
  final DateTime today = dayOf(DateTime.now());
  final List<AgedBuyer> out = <AgedBuyer>[];
  by.forEach((String key, List<SaleItem> l) {
    l.sort((SaleItem a, SaleItem b) {
      final int c = a.date.compareTo(b.date);
      return c != 0 ? c : a.at.compareTo(b.at);
    });
    final List<double> amts = <double>[];
    final List<DateTime> dates = <DateTime>[];
    double credit = 0;
    for (final SaleItem s in l) {
      final double v = s.effect;
      if (v > 0) {
        amts.add(v);
        dates.add(s.date);
      } else if (v < 0) {
        credit += -v;
      }
    }
    for (int i = 0; i < amts.length && credit > 0; i++) {
      final double use = credit < amts[i] ? credit : amts[i];
      amts[i] -= use;
      credit -= use;
    }
    final AgedBuyer a = AgedBuyer(key, l.last.buyer);
    a.credit = credit;
    for (int i = 0; i < amts.length; i++) {
      if (amts[i] <= 0.5) continue;
      a.bucket[agingBucket(today.difference(dates[i]).inDays)] += amts[i];
      final DateTime? o = a.oldest;
      if (o == null || dates[i].isBefore(o)) a.oldest = dates[i];
    }
    out.add(a);
  });
  return out;
}

// -------------------------------------------------------------- processing
class ProcOut {
  final String grade;
  final double kg;
  final int bags;
  const ProcOut(this.grade, this.kg, this.bags);
}

class ProcBatch {
  final String id;
  final DateTime date;
  final String material;
  final double inKg;
  final List<ProcOut> outs;
  final String note;
  final DateTime at;
  const ProcBatch(this.id, this.date, this.material, this.inKg, this.outs, this.note, this.at);

  double get outKg {
    double t = 0;
    for (final ProcOut o in outs) {
      t += o.kg;
    }
    return t;
  }

  /// What went missing (waste, moisture, dust).
  double get loss => inKg - outKg;
  double get lossPct => inKg > 0 ? loss / inKg * 100 : 0;
}

List<ProcBatch> procBatches() {
  final List<ProcBatch> out = <ProcBatch>[];
  for (final Map<String, dynamic> m in procDoc.list('items')) {
    final DateTime? d = DateTime.tryParse('${m['date'] ?? ''}');
    if (d == null) continue;
    final List<ProcOut> outs = <ProcOut>[];
    final Object? raw = m['outs'];
    if (raw is List) {
      for (final Object? e in raw) {
        if (e is Map) {
          outs.add(ProcOut('${e['g'] ?? ''}', dbl(e['kg']), dbl(e['bags']).round()));
        }
      }
    }
    out.add(ProcBatch(
      '${m['id'] ?? ''}',
      dayOf(d),
      '${m['material'] ?? ''}',
      dbl(m['in']),
      outs,
      '${m['note'] ?? ''}',
      DateTime.tryParse('${m['at'] ?? ''}') ?? d,
    ));
  }
  out.sort((ProcBatch a, ProcBatch b) {
    final int c = b.date.compareTo(a.date);
    return c != 0 ? c : b.at.compareTo(a.at);
  });
  return out;
}

Future<void> addProc({
  required DateTime date,
  required String material,
  required double inKg,
  required List<ProcOut> outs,
  String note = '',
}) {
  return procDoc.commit(() {
    final List<Map<String, dynamic>> l = procDoc.list('items');
    l.add(<String, dynamic>{
      'id': '${DateTime.now().microsecondsSinceEpoch}',
      'date': dayKey(date),
      'material': material,
      'in': inKg,
      'outs': <Map<String, dynamic>>[
        for (final ProcOut o in outs) <String, dynamic>{'g': o.grade, 'kg': o.kg, 'bags': o.bags},
      ],
      'note': note.trim(),
      'at': DateTime.now().toIso8601String(),
    });
  });
}

Future<void> removeProc(String id) {
  return procDoc.commit(() {
    procDoc.list('items').removeWhere((Map<String, dynamic> m) => '${m['id']}' == id);
  });
}

/// Grade names seen before, then the usual ones.
List<String> knownGrades() {
  final List<String> out = <String>[];
  final Set<String> seen = <String>{};
  void add(String g) {
    final String t = g.trim();
    if (t.isEmpty || !seen.add(_k(t))) return;
    out.add(t);
  }

  for (final ProcBatch b in procBatches()) {
    for (final ProcOut o in b.outs) {
      add(o.grade);
    }
  }
  for (final SaleItem s in saleItems()) {
    if (s.isSale && s.src == 'out') add(s.item);
  }
  for (final List<String> g in kGradeDefaults) {
    add(bi(g[0], g[1]));
  }
  return out;
}

// ------------------------------------------------------------------- stock
class StockLine {
  final String key; // raw|code  or  out|grade
  final String label;
  final bool raw;
  double open = 0;
  double got = 0;
  double used = 0;
  double sold = 0;
  StockLine(this.key, this.label, this.raw);

  double get left => open + got - used - sold;
}

DateTime stockFrom() {
  final Object? v = prefDoc.data['stockFrom'];
  final DateTime? d = v == null ? null : DateTime.tryParse('$v');
  if (d != null) return dayOf(d);
  final DateTime n = DateTime.now();
  return DateTime(n.year, n.month, 1);
}

bool stockFromSet() => prefDoc.data['stockFrom'] != null;

Future<void> setStockFrom(DateTime d) {
  return prefDoc.commit(() {
    prefDoc.data['stockFrom'] = dayKey(d);
  });
}

String stockKey(bool raw, String item) => '${raw ? 'raw' : 'out'}|${_k(item)}';

double stockOpenOf(String key) {
  final Object? m = prefDoc.data['stockOpen'];
  if (m is Map) {
    final Object? v = m[key];
    if (v is num) return v.toDouble();
    if (v is String) return double.tryParse(v) ?? 0;
  }
  return 0;
}

Future<void> setStockOpen(String key, double kg, {String label = ''}) {
  return prefDoc.commit(() {
    final Map<String, dynamic> m = prefDoc.map('stockOpen');
    if (kg == 0) {
      m.remove(key);
    } else {
      m[key] = kg;
    }
    final Map<String, dynamic> names = prefDoc.map('stockNames');
    if (label.isNotEmpty && kg != 0) names[key] = label;
  });
}

String _nameOfKey(String key) {
  final Object? n = prefDoc.data['stockNames'];
  if (n is Map && n[key] != null) return '${n[key]}';
  final int i = key.indexOf('|');
  return i < 0 ? key : key.substring(i + 1);
}

/// Stock worked out as: opening + received − processed − sold, counted from
/// [stockFrom]. Raw material comes from the weighbridge; finished grades come
/// from the processing entries.
List<StockLine> stockRows() {
  final DateTime from = stockFrom();
  final Map<String, StockLine> m = <String, StockLine>{};
  StockLine row(String key, String label, bool raw) => m.putIfAbsent(key, () => StockLine(key, label, raw));

  for (final Trip t in live.trips) {
    if (t.chits.isEmpty || t.at.isBefore(from)) continue;
    final String code = t.commodity.trim();
    if (code.isEmpty) continue;
    row(stockKey(true, code), code, true).got += t.kanta != null ? t.kantaKg : t.chitKg;
  }
  for (final ProcBatch b in procBatches()) {
    if (b.date.isBefore(from)) continue;
    final String mat = b.material.trim();
    if (mat.isNotEmpty) row(stockKey(true, mat), mat, true).used += b.inKg;
    for (final ProcOut o in b.outs) {
      final String g = o.grade.trim();
      if (g.isEmpty) continue;
      row(stockKey(false, g), g, false).got += o.kg;
    }
  }
  for (final SaleItem s in saleItems()) {
    if (!s.isSale || s.date.isBefore(from)) continue;
    final String it = s.item.trim();
    if (it.isEmpty) continue;
    final bool raw = s.src == 'raw';
    row(stockKey(raw, it), it, raw).sold += s.kg;
  }
  final Object? op = prefDoc.data['stockOpen'];
  if (op is Map) {
    for (final Object? k in op.keys) {
      final String key = '$k';
      if (!key.startsWith('raw|') && !key.startsWith('out|')) continue;
      row(key, _nameOfKey(key), key.startsWith('raw|'));
    }
  }
  for (final StockLine r in m.values) {
    r.open = stockOpenOf(r.key);
  }
  final List<StockLine> l = m.values.toList();
  l.sort((StockLine a, StockLine b) {
    if (a.raw != b.raw) return a.raw ? -1 : 1;
    return b.left.compareTo(a.left);
  });
  return l;
}

/// Stock of one item right now, null when the item is not tracked yet.
double? stockLeftOf(bool raw, String item) {
  final String key = stockKey(raw, item);
  for (final StockLine r in stockRows()) {
    if (r.key == key) return r.left;
  }
  return null;
}
