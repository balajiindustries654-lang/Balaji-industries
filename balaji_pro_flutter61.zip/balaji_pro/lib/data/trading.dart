import 'gst.dart' show r2;
import 'insights.dart' show dayKey;
import 'live_models.dart' show dbl, nameKey, dayOf;
import 'owner_docs.dart';

// ======================================================================
// Trading / mill: a truck that goes straight from the seller to the mill.
//  - bought on the weight at loading (or on the mill weight), sold on the mill weight
//  - everything of one truck in one record: weights, rates, expenses, GST bill, money received
//  - one shared document `flutter_trades`: { items: [...] }
// ======================================================================

final SyncDoc tradeDoc = SyncDoc('flutter_trades');

class DealRecv {
  final String id;
  final DateTime date;
  final double amt;
  final String mode;
  final String note;
  const DealRecv(this.id, this.date, this.amt, this.mode, this.note);
}

class MillDeal {
  final String id;
  final DateTime date;
  final String vehicle;
  final String commodity; // Magfadi | Aeranda ...
  final String item; // printed name, e.g. Groundnut kernels
  final String seller;
  final String mill;
  final double loadKg;
  final double millKg; // 0 = the mill weight is not in yet
  final double buyRate; // Rs per 20 KG
  final double sellRate; // Rs per 20 KG
  final String buyOn; // load | mill
  final double freight;
  final double labour;
  final double commission;
  final double other;
  final String billNo; // GST bill number
  final String note;
  final List<DealRecv> recv;
  final DateTime at;
  const MillDeal({
    required this.id,
    required this.date,
    required this.vehicle,
    required this.commodity,
    required this.item,
    required this.seller,
    required this.mill,
    required this.loadKg,
    required this.millKg,
    required this.buyRate,
    required this.sellRate,
    required this.buyOn,
    required this.freight,
    required this.labour,
    required this.commission,
    required this.other,
    required this.billNo,
    required this.note,
    required this.recv,
    required this.at,
  });

  bool get weighed => millKg > 0;
  bool get billed => billNo.trim().isNotEmpty;
}

/// What a deal comes to. [billTotal] = value of the linked GST bill (with GST), when there is one.
class DealCalc {
  final double buyAmt;
  final double sellAmt;
  final double expenses;
  final double profit;
  final double shortKg;
  final double shortPct;
  final double received;
  final double receivable;
  final double due;
  final bool hasSell;
  const DealCalc(this.buyAmt, this.sellAmt, this.expenses, this.profit, this.shortKg, this.shortPct, this.received, this.receivable, this.due, this.hasSell);

  /// Profit for every 100 KG sold (0 when nothing sold yet).
  double perQtl(double kg) => kg > 0 ? profit / kg * 100 : 0;
}

DealCalc calcDeal(MillDeal d, {double? billTotal}) {
  final double shortKg = d.weighed ? d.loadKg - d.millKg : 0;
  final double shortPct = d.weighed && d.loadKg > 0 ? shortKg / d.loadKg * 100 : 0;
  final double buyKg = (d.buyOn == 'mill' && d.weighed) ? d.millKg : d.loadKg;
  final double buyAmt = r2(buyKg / 20 * d.buyRate);
  final double sellKg = d.weighed ? d.millKg : d.loadKg;
  final double sellAmt = r2(sellKg / 20 * d.sellRate);
  final double exp = d.freight + d.labour + d.commission + d.other;
  double rec = 0;
  for (final DealRecv r in d.recv) {
    rec += r.amt;
  }
  final bool hasSell = d.sellRate > 0;
  final double receivable = billTotal ?? (hasSell ? sellAmt : 0);
  return DealCalc(buyAmt, sellAmt, exp, hasSell ? sellAmt - buyAmt - exp : 0, shortKg, shortPct, rec, receivable, receivable - rec, hasSell);
}

/// loaded | weighed | billed | paid
String dealStatus(MillDeal d, DealCalc c) {
  if (d.billed || c.hasSell) {
    if (c.receivable > 0 && c.due <= 0.5 && c.received > 0) return 'paid';
  }
  if (d.billed) return 'billed';
  if (d.weighed) return 'weighed';
  return 'loaded';
}

List<MillDeal> millDeals() {
  final List<MillDeal> out = <MillDeal>[];
  for (final Map<String, dynamic> m in tradeDoc.list('items')) {
    final DateTime? d = DateTime.tryParse('${m['date'] ?? ''}');
    if (d == null) continue;
    final List<DealRecv> rec = <DealRecv>[];
    final Object? raw = m['recv'];
    if (raw is List) {
      for (final Object? e in raw) {
        if (e is Map) {
          final DateTime? rd = DateTime.tryParse('${e['date'] ?? ''}');
          if (rd == null) continue;
          rec.add(DealRecv('${e['id'] ?? ''}', dayOf(rd), dbl(e['amt']), '${e['mode'] ?? 'bank'}', '${e['note'] ?? ''}'));
        }
      }
    }
    out.add(MillDeal(
      id: '${m['id'] ?? ''}',
      date: dayOf(d),
      vehicle: '${m['vehicle'] ?? ''}',
      commodity: '${m['commodity'] ?? ''}',
      item: '${m['item'] ?? ''}',
      seller: '${m['seller'] ?? ''}',
      mill: '${m['mill'] ?? ''}',
      loadKg: dbl(m['loadKg']),
      millKg: dbl(m['millKg']),
      buyRate: dbl(m['buyRate']),
      sellRate: dbl(m['sellRate']),
      buyOn: '${m['buyOn'] ?? 'load'}',
      freight: dbl(m['freight']),
      labour: dbl(m['labour']),
      commission: dbl(m['commission']),
      other: dbl(m['other']),
      billNo: '${m['bill'] ?? ''}',
      note: '${m['note'] ?? ''}',
      recv: rec,
      at: DateTime.tryParse('${m['at'] ?? ''}') ?? d,
    ));
  }
  out.sort((MillDeal a, MillDeal b) {
    final int c = b.date.compareTo(a.date);
    return c != 0 ? c : b.at.compareTo(a.at);
  });
  return out;
}

Map<String, dynamic> _dealMap(MillDeal d) => <String, dynamic>{
      'id': d.id,
      'date': dayKey(d.date),
      'vehicle': d.vehicle.trim(),
      'commodity': d.commodity,
      'item': d.item.trim(),
      'seller': d.seller.trim(),
      'mill': d.mill.trim(),
      'loadKg': d.loadKg,
      'millKg': d.millKg,
      'buyRate': d.buyRate,
      'sellRate': d.sellRate,
      'buyOn': d.buyOn,
      'freight': d.freight,
      'labour': d.labour,
      'commission': d.commission,
      'other': d.other,
      'bill': d.billNo.trim(),
      'note': d.note.trim(),
      'recv': <Map<String, dynamic>>[
        for (final DealRecv r in d.recv) <String, dynamic>{'id': r.id, 'date': dayKey(r.date), 'amt': r.amt, 'mode': r.mode, 'note': r.note}
      ],
      'at': d.at.toIso8601String(),
    };

/// Adds a new deal or replaces the one with the same id.
Future<void> saveDeal(MillDeal d) {
  return tradeDoc.commit(() {
    final List<Map<String, dynamic>> l = tradeDoc.list('items');
    final int i = l.indexWhere((Map<String, dynamic> m) => '${m['id']}' == d.id);
    if (i >= 0) {
      l[i] = _dealMap(d);
    } else {
      l.add(_dealMap(d));
    }
  });
}

String newDealId() => '${DateTime.now().microsecondsSinceEpoch}';

Future<void> removeDeal(String id) {
  return tradeDoc.commit(() {
    tradeDoc.list('items').removeWhere((Map<String, dynamic> m) => '${m['id']}' == id);
  });
}

/// Small changes that do not need the whole form.
Future<void> patchDeal(String id, Map<String, dynamic> patch) {
  return tradeDoc.commit(() {
    for (final Map<String, dynamic> m in tradeDoc.list('items')) {
      if ('${m['id']}' == id) m.addAll(patch);
    }
  });
}

Future<void> addDealRecv(String id, {required DateTime date, required double amt, required String mode, String note = '', String recvId = ''}) {
  return tradeDoc.commit(() {
    for (final Map<String, dynamic> m in tradeDoc.list('items')) {
      if ('${m['id']}' != id) continue;
      final Object? raw = m['recv'];
      final List<Object?> l = raw is List ? List<Object?>.from(raw) : <Object?>[];
      l.add(<String, dynamic>{'id': recvId.isEmpty ? '${DateTime.now().microsecondsSinceEpoch}' : recvId, 'date': dayKey(date), 'amt': amt, 'mode': mode, 'note': note.trim()});
      m['recv'] = l;
    }
  });
}

Future<void> removeDealRecv(String dealId, String recvId) {
  return tradeDoc.commit(() {
    for (final Map<String, dynamic> m in tradeDoc.list('items')) {
      if ('${m['id']}' != dealId) continue;
      final Object? raw = m['recv'];
      if (raw is List) {
        m['recv'] = raw.where((Object? e) => !(e is Map && '${e['id']}' == recvId)).toList();
      }
    }
  });
}

// ------------------------------------------------------------- mill ledger
class MillAcct {
  final String key;
  final String label;
  int deals = 0;
  double kg = 0;
  double billed = 0;
  double received = 0;
  double profit = 0;
  DateTime? last;
  MillAcct(this.key, this.label);
  double get due => billed - received;
}

/// Per mill: what was sent, what it comes to and what is still to be received.
Map<String, MillAcct> millAccts(List<MillDeal> deals, Map<String, double> billTotals) {
  final Map<String, MillAcct> m = <String, MillAcct>{};
  for (final MillDeal d in deals) {
    final String k = nameKey(d.mill);
    if (k.isEmpty) continue;
    final MillAcct a = m.putIfAbsent(k, () => MillAcct(k, d.mill));
    final DealCalc c = calcDeal(d, billTotal: d.billed ? billTotals[d.billNo.trim()] : null);
    a.deals++;
    a.kg += d.weighed ? d.millKg : d.loadKg;
    a.billed += c.receivable;
    a.received += c.received;
    a.profit += c.profit;
    final DateTime? l = a.last;
    if (l == null || d.date.isAfter(l)) a.last = d.date;
  }
  return m;
}
