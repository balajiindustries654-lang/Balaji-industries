import 'dart:async';
import '../core/app_state.dart';
import '../core/fmt.dart';
import '../core/i18n.dart';
import 'engine.dart' show Trip;
import 'insights.dart' show dayKey;
import 'live_models.dart' show Chit, Kanta, dbl;
import 'live_store.dart';
import 'owner_docs.dart';

// ======================================================================
// Daily debit-note check
//  - a truck weighed less at the weighbridge than the chit says: the farmer should get a debit note
//  - this list shows those trucks, what the short weight comes to, and whether a debit note is already
//    in Tally (see debit_screens.dart) or was marked done / skipped by the owner
//  - one shared document `flutter_dnote`: { cfg: {...}, marks: { kantaId: {s, at, note} } }
// ======================================================================

final SyncDoc debitDoc = SyncDoc('flutter_dnote');

class DebitCfg {
  final int days; // look back this many days
  final double minAmt; // Tally debit notes at or above this amount are looked at closely
  final double minKg; // short weight below this is let go
  final int basis; // 0 = the whole short weight, 1 = only what is more than the allowed difference
  final bool auto; // check once a day when the owner opens the app
  final String last; // day of the last automatic check
  const DebitCfg({this.days = 30, this.minAmt = 25000, this.minKg = 0, this.basis = 0, this.auto = true, this.last = ''});
}

DebitCfg debitCfg() {
  final Map<String, dynamic> m = debitDoc.map('cfg');
  return DebitCfg(
    days: dbl(m['days'], 30).round().clamp(1, 365).toInt(),
    minAmt: dbl(m['minAmt'], 25000),
    minKg: dbl(m['minKg'], 0),
    basis: dbl(m['basis'], 0).round() == 1 ? 1 : 0,
    auto: m['auto'] != false,
    last: '${m['last'] ?? ''}',
  );
}

Future<void> saveDebitCfg(DebitCfg c) {
  return debitDoc.commit(() {
    final Map<String, dynamic> m = debitDoc.map('cfg');
    m['days'] = c.days;
    m['minAmt'] = c.minAmt;
    m['minKg'] = c.minKg;
    m['basis'] = c.basis;
    m['auto'] = c.auto;
    m['last'] = c.last;
  });
}

class GhatMark {
  final String state; // done | skip
  final String note;
  final DateTime at;
  const GhatMark(this.state, this.note, this.at);
}

Map<String, GhatMark> ghatMarks() {
  final Map<String, GhatMark> out = <String, GhatMark>{};
  final Map<String, dynamic> m = debitDoc.map('marks');
  m.forEach((String k, dynamic v) {
    if (v is Map) {
      out[k] = GhatMark('${v['s'] ?? ''}', '${v['note'] ?? ''}', DateTime.tryParse('${v['at'] ?? ''}') ?? DateTime.now());
    }
  });
  return out;
}

Future<void> markGhat(String id, String state, {String note = ''}) {
  return debitDoc.commit(() {
    debitDoc.map('marks')[id] = <String, dynamic>{'s': state, 'note': note.trim(), 'at': DateTime.now().toIso8601String()};
  });
}

Future<void> clearGhat(String id) {
  return debitDoc.commit(() {
    debitDoc.map('marks').remove(id);
  });
}

/// One farmer's part of a truck's short weight.
class GhatShare {
  final String farmer;
  final String commodity;
  final double chitKg;
  final double shortKg;
  final double rate; // Rs per 20 KG, 0 = no rate set for that day
  const GhatShare(this.farmer, this.commodity, this.chitKg, this.shortKg, this.rate);
  double get value => rate > 0 ? shortKg / 20 * rate : 0;
}

class GhatRow {
  final Trip trip;
  final String id; // the weighbridge entry
  final double shortKg; // chit weight - weighbridge weight
  final double debitKg; // what the debit note is made for (by the chosen basis)
  final List<GhatShare> shares;
  final GhatMark? mark;
  const GhatRow(this.trip, this.id, this.shortKg, this.debitKg, this.shares, this.mark);

  double get value {
    double v = 0;
    for (final GhatShare s in shares) {
      v += s.value;
    }
    return v;
  }

  bool get rateMissing => shares.any((GhatShare s) => s.rate <= 0);
}

/// The trucks that weighed less than their chits (more than the allowed difference), newest first.
List<GhatRow> ghatRows(DebitCfg cfg, {DateTime? now}) {
  final DateTime n = now ?? DateTime.now();
  final DateTime from = DateTime(n.year, n.month, n.day).subtract(Duration(days: cfg.days));
  final Map<String, GhatMark> marks = ghatMarks();
  final List<GhatRow> out = <GhatRow>[];
  for (final Trip t in live.trips) {
    final Kanta? k = t.kanta;
    if (k == null || t.chits.isEmpty || t.at.isBefore(from)) continue;
    if (t.chitKg <= 0 || t.kantaKg <= 0) continue;
    final double sh = t.chitKg - t.kantaKg;
    if (sh <= 0 || sh <= t.tol) continue; // inside the allowed difference (or more weight than the chit)
    final double dk = cfg.basis == 1 ? sh - t.tol : sh;
    if (dk <= 0 || dk < cfg.minKg) continue;
    final List<GhatShare> shares = <GhatShare>[];
    for (final Chit c in t.chits) {
      final double part = c.cmpKg / t.chitKg * dk;
      final double? r = rateFor(c.commodity.trim(), c.at);
      shares.add(GhatShare(c.farmer, c.commodity, c.cmpKg, part, r ?? 0));
    }
    out.add(GhatRow(t, k.id, sh, dk, shares, marks[k.id]));
  }
  return out;
}

/// How many trucks still wait for a debit note (not marked, not found in Tally is checked by the screen).
int ghatUnmarked(DebitCfg cfg) => ghatRows(cfg).where((GhatRow r) => r.mark == null).length;

/// Text for WhatsApp / a note for the accountant.
String ghatText(GhatRow r) {
  final StringBuffer b = StringBuffer();
  b.writeln('${bi('ડેબિટ નોટ - ઘટ', 'Debit note - short weight')} · ${r.trip.vehicle} · ${dayKey(r.trip.at)}');
  b.writeln('${bi('ચિઠ્ઠી વજન', 'Chit weight')}: ${r.trip.chitKg.toStringAsFixed(0)} KG');
  b.writeln('${bi('કાંટા વજન', 'Weighbridge')}: ${r.trip.kantaKg.toStringAsFixed(0)} KG');
  b.writeln('${bi('ઘટ', 'Short')}: ${r.shortKg.toStringAsFixed(0)} KG');
  for (final GhatShare s in r.shares) {
    b.writeln('• ${s.farmer.isEmpty ? '-' : s.farmer}: ${s.shortKg.toStringAsFixed(1)} KG${s.rate > 0 ? ' × ₹${s.rate.toStringAsFixed(s.rate == s.rate.roundToDouble() ? 0 : 2)}/20 = ${inr(s.value, dec: 2)}' : ''}');
  }
  if (r.value > 0) b.writeln('${bi('કુલ', 'Total')}: ${inr(r.value, dec: 2)}');
  return b.toString().trim();
}

Timer? _nudge;

/// Once a day (when the app is open and the owner is signed in) the trucks that wait for a debit note are counted
/// and the owner is told. Started once from main().
void debitStartNudge() {
  _nudge?.cancel();
  _nudge = Timer.periodic(const Duration(minutes: 20), (Timer _) => debitNudgeOnce());
  Timer(const Duration(seconds: 45), debitNudgeOnce);
}

Future<void> debitNudgeOnce() async {
  try {
    if (!live.signedIn || live.loadedAt == null || !live.isAdmin) return;
    await debitDoc.ensure();
    final DebitCfg c = debitCfg();
    final String today = dayKey(DateTime.now());
    if (!c.auto || c.last == today) return;
    final int n = ghatUnmarked(c);
    await saveDebitCfg(DebitCfg(days: c.days, minAmt: c.minAmt, minKg: c.minKg, basis: c.basis, auto: c.auto, last: today));
    if (n > 0) app.toast('$n ${bi('ગાડીમાં ઘટ છે - ડેબિટ નોટ તપાસો', 'trucks are short - check the debit notes')}');
  } catch (_) {}
}
