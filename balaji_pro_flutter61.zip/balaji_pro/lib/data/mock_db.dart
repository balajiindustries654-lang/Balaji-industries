import 'dart:math' as math;
import '../core/fmt.dart';
import '../core/i18n.dart';
import 'models.dart';

const List<String> _farmerNames = <String>[
  'રમેશભાઈ પટેલ', 'જયંતીભાઈ સોલંકી', 'મુકેશભાઈ વાઘેલા', 'હસમુખભાઈ ધામેલિયા', 'દિનેશભાઈ કાકડિયા',
  'ભરતભાઈ રાદડિયા', 'વિપુલભાઈ સાવલિયા', 'અશ્વિનભાઈ ગજેરા', 'કિશોરભાઈ વાડોદરિયા', 'નરેશભાઈ ભુવા',
  'પ્રવીણભાઈ ઘેટિયા', 'મનસુખભાઈ સુતરિયા', 'ધીરજભાઈ ચોવટિયા', 'બાબુભાઈ માકડિયા', 'રાજેશભાઈ કોરાટ',
  'સંજયભાઈ વેકરિયા', 'અરવિંદભાઈ ડોબરિયા', 'ગોવિંદભાઈ તળાવિયા', 'વલ્લભભાઈ રૂપારેલિયા', 'હિતેશભાઈ કથીરિયા',
  'જીતેન્દ્રભાઈ સખિયા', 'કનુભાઈ પાનસુરિયા', 'લાલજીભાઈ મોવલિયા', 'ચંદુભાઈ ગોધાણી', 'પરેશભાઈ વઘાસિયા',
  'સુરેશભાઈ કોટડિયા', 'નટુભાઈ ભાલોડિયા', 'ભીખાભાઈ રામાણી', 'ઘનશ્યામભાઈ દુધાત', 'મહેશભાઈ ઠુમ્મર',
  'ભાવેશભાઈ ગોંડલિયા', 'યોગેશભાઈ લીંબાસિયા', 'અતુલભાઈ જાદવ', 'વિજયભાઈ પરમાર', 'અજયભાઈ ચાવડા',
  'કાળુભાઈ ડાંગર', 'હમીરભાઈ ગઢવી', 'રણછોડભાઈ ખુંટ', 'મગનભાઈ વિરાણી', 'દેવજીભાઈ સાપરિયા',
];

const List<String> _villages = <String>[
  'ગોંડલ', 'જેતપુર', 'ધોરાજી', 'ઉપલેટા', 'કોટડા સાંગાણી', 'જામકંડોરણા', 'વીરપુર',
  'જસદણ', 'વિંછીયા', 'બાબરા', 'અમરેલી', 'સાવરકુંડલા', 'લીલીયા', 'રાજુલા',
];

const List<String> _brokerNames = <String>[
  'ચંપકભાઈ દલાલ', 'પોપટભાઈ દલાલ', 'જગદીશભાઈ દલાલ', 'વિનુભાઈ દલાલ',
  'રમણિકભાઈ દલાલ', 'હરેશભાઈ દલાલ', 'કૌશિકભાઈ દલાલ', 'સુનિલભાઈ દલાલ',
];

const List<String> _buyerNames = <String>[
  'શ્રી ગણેશ ઓઇલ મિલ', 'ખોડિયાર ટ્રેડર્સ', 'અંબિકા ઓઇલ મિલ', 'જય સોમનાથ એગ્રો',
  'સદગુરુ એક્સપોર્ટ', 'મારુતિ ટ્રેડિંગ', 'ગોકુલ પ્રોટીન્સ', 'રાધે ઓઇલ મિલ',
  'વેલનાથ એગ્રો', 'નવકાર ટ્રેડર્સ', 'સાંઈ કૃપા ઓઇલ', 'પટેલ બ્રધર્સ ટ્રેડિંગ',
];

const List<String> kVehicles = <String>[
  'GJ-03-AB-4521', 'GJ-11-TT-0987', 'GJ-03-BX-7712', 'GJ-01-DV-3300',
  'GJ-03-CK-1209', 'GJ-14-AX-5566', 'GJ-03-BT-8841', 'GJ-10-X-2290',
];

const List<double> _gradeAdj = <double>[60, 0, 110];
const List<String> _directExp = <String>['Hamali', 'Transport Charges', 'Weighing Charges'];
const List<String> _indirectExp = <String>[
  'Salary', 'Electricity', 'Office Rent', 'Accountant Fees', 'Bank Charges', 'Discount Allowed',
];

const List<String> kGroupOrder = <String>[
  'Capital Account', 'Sundry Creditors', 'Duties & Taxes', 'Cash-in-Hand', 'Bank Accounts',
  'Sundry Debtors', 'Stock-in-Hand', 'Purchase Accounts', 'Direct Expenses', 'Sales Accounts',
  'Indirect Expenses',
];

class MockDb {
  static final MockDb I = MockDb._();
  MockDb._() {
    _build();
  }

  final DateTime today = dateOnly(DateTime.now());
  final math.Random _r = math.Random(11);

  final List<Party> farmers = <Party>[];
  final List<Party> brokers = <Party>[];
  final List<Party> buyers = <Party>[];
  final List<Entry> entries = <Entry>[]; // newest first
  final List<Voucher> vouchers = <Voucher>[]; // newest first
  final List<LedgerAcc> ledgers = <LedgerAcc>[];
  final List<StockRow> stock = <StockRow>[];
  final List<double> rates = <double>[1215, 1155, 1265]; // today's rate / 20 kg per grade

  int _vid = 0;
  int _entryNo = 1000;
  final Map<String, int> _cnt = <String, int>{};
  final Set<String> _farmerSet = <String>{};

  // ------------------------------------------------------------------ build
  void _build() {
    for (int i = 0; i < _farmerNames.length; i++) {
      farmers.add(Party(100 + i, _farmerNames[i], 'farmer', _villages[i % _villages.length], _phone(), 0, 0));
      _farmerSet.add(_farmerNames[i]);
    }
    for (int i = 0; i < _brokerNames.length; i++) {
      brokers.add(Party(200 + i, _brokerNames[i], 'broker', _villages[(i * 3) % _villages.length], _phone(), 0, 0));
    }
    for (int i = 0; i < _buyerNames.length; i++) {
      final double op = i % 3 == 0 ? 100000.0 * (1 + i % 4) : 0.0;
      buyers.add(Party(300 + i, _buyerNames[i], 'buyer', bi('મોરબી', 'Morbi'), _phone(), 1500000.0 + 500000.0 * (i % 4), op));
    }
    _genEntries();
    _genVouchers();
    _buildLedgers();
    _buildStock();
  }

  String _phone() => '98${100 + _r.nextInt(900)} ${10000 + _r.nextInt(90000)}';

  double _baseRate(int back, int g) => 1150.0 + 45.0 * math.sin(back / 8.0) + _gradeAdj[g];

  int _pickGrade() {
    final int x = _r.nextInt(100);
    return x < 50 ? 0 : (x < 85 ? 1 : 2);
  }

  void _genEntries() {
    final List<Entry> list = <Entry>[];
    for (int back = 80; back >= 0; back--) {
      final DateTime d = today.subtract(Duration(days: back));
      if (d.weekday == DateTime.sunday && _r.nextInt(4) != 0) continue;
      final int n = back == 0 ? 5 : 3 + _r.nextInt(7);
      for (int i = 0; i < n; i++) {
        final Party f = farmers[_r.nextInt(farmers.length)];
        final int g = _pickGrade();
        final int bags = 30 + _r.nextInt(110);
        final double gross = bags * (34.0 + _r.nextInt(5)) + _r.nextInt(60);
        final double hava = (gross * (0.4 + _r.nextDouble() * 2.0) / 100).roundToDouble();
        final double rate = (_baseRate(back, g) + _r.nextInt(25)).roundToDouble();
        final double amount = ((gross - hava) / 20 * rate).roundToDouble();
        final int roll = _r.nextInt(100);
        double paid;
        if (back > 12) {
          paid = roll < 90 ? amount : (roll < 96 ? (amount * 0.6).roundToDouble() : 0.0);
        } else if (back > 3) {
          paid = roll < 55 ? amount : (roll < 80 ? (amount * 0.5).roundToDouble() : 0.0);
        } else {
          paid = roll < 35 ? amount : (roll < 55 ? (amount * 0.4).roundToDouble() : 0.0);
        }
        final int m = _r.nextInt(100);
        _entryNo++;
        list.add(Entry(
          no: _entryNo,
          dt: DateTime(d.year, d.month, d.day, 8 + (i * 9) ~/ n, _r.nextInt(60)),
          farmer: f,
          broker: _r.nextInt(100) < 55 ? brokers[_r.nextInt(brokers.length)] : null,
          vehicle: kVehicles[_r.nextInt(kVehicles.length)],
          village: f.village,
          g: g,
          godown: _r.nextInt(3),
          bags: bags,
          gross: gross,
          hava: hava,
          rate: rate,
          amount: amount,
          paid: paid,
          mode: m < 70 ? 'cash' : (m < 90 ? 'bank' : 'upi'),
        ));
      }
    }
    list.sort((Entry a, Entry b) => b.dt.compareTo(a.dt));
    entries.addAll(list);
  }

  void _v(Firm f, DateTime date, String type, String party, String dr, String cr, double amount,
      {double gst = 0, String narration = '', String? ref, bool cash = false, int grade = -1, double kg = 0}) {
    final String key = '${f.index}$type';
    final int c = (_cnt[key] ?? 0) + 1;
    _cnt[key] = c;
    final String pre = (<String, String>{
          'Sales': 'S', 'Purchase': 'P', 'Receipt': 'R', 'Payment': 'PV', 'Journal': 'J', 'Contra': 'C',
        })[type] ??
        'V';
    vouchers.add(Voucher(
      id: ++_vid,
      firm: f,
      date: date,
      type: type,
      no: '$pre-${c.toString().padLeft(4, '0')}',
      party: party,
      dr: dr,
      cr: cr,
      amount: amount,
      gst: gst,
      narration: narration,
      ref: ref,
      cash: cash,
      grade: grade,
      kg: kg,
    ));
  }

  void _genVouchers() {
    // ---- Balaji New (kacha): purchases + cash/bank payments ----
    final List<Entry> asc = entries.reversed.toList();
    final Map<int, double> cashByDay = <int, double>{};
    final Map<int, double> kgByDay = <int, double>{};
    for (final Entry e in asc) {
      final int back = today.difference(dateOnly(e.dt)).inDays;
      _v(Firm.balaji, e.dt, 'Purchase', e.farmer.name, 'Purchase A/c', e.farmer.name, e.amount,
          narration: 'ચિઠ્ઠી #${e.no} · ${e.vehicle}', ref: '#${e.no}', grade: e.g, kg: e.net);
      kgByDay[back] = (kgByDay[back] ?? 0) + e.net;
      if (e.paid > 0) {
        final bool cashPay = e.mode == 'cash';
        _v(Firm.balaji, e.dt.add(const Duration(minutes: 20)), 'Payment', e.farmer.name, e.farmer.name,
            cashPay ? 'Cash' : 'SBI Current A/c', e.paid,
            cash: cashPay, narration: 'ચિઠ્ઠી #${e.no} ચૂકવણી', ref: '#${e.no}');
        if (cashPay) cashByDay[back] = (cashByDay[back] ?? 0) + e.paid;
      }
    }
    // ---- daily Balaji sales, receipts, expenses, cash withdrawals ----
    for (int back = 80; back >= 0; back--) {
      final DateTime d = today.subtract(Duration(days: back));
      final DateTime at = DateTime(d.year, d.month, d.day, 17, 30);
      final double dayKg = kgByDay[back] ?? 0;
      if (dayKg > 0 && d.weekday != DateTime.sunday) {
        final Party b = buyers[_r.nextInt(buyers.length)];
        final int g = _pickGrade();
        final double kg = ((dayKg * (0.95 + _r.nextDouble() * 0.2)) / 50).round() * 50.0;
        final double rate = _baseRate(back, g) + 55;
        final double amt = (kg / 20 * rate).roundToDouble();
        _v(Firm.balaji, at, 'Sales', b.name, b.name, 'Sales A/c', amt,
            narration: 'વેચાણ ${gradeName(g, shortName: true)} · ${grp(kg)} KG', grade: g, kg: kg);
        final int lag = 3 + _r.nextInt(25);
        final DateTime rd = at.add(Duration(days: lag));
        if (!rd.isAfter(DateTime.now()) && _r.nextInt(100) < 88) {
          final bool full = _r.nextInt(100) < 70;
          _v(Firm.balaji, rd, 'Receipt', b.name, 'SBI Current A/c', b.name, full ? amt : (amt * 0.7).roundToDouble(),
              narration: 'RTGS / NEFT');
        }
        if (_r.nextInt(14) == 0) {
          _v(Firm.balaji, at, 'Journal', b.name, 'Discount Allowed', b.name, (amt * 0.004).roundToDouble(),
              narration: 'કટૌતી / discount');
        }
      }
      if (d.weekday != DateTime.sunday) {
        _v(Firm.balaji, at, 'Payment', 'Hamali', 'Hamali', 'Cash', 1200.0 + _r.nextInt(18) * 100, cash: true, narration: 'હમાલી');
        if (back % 3 == 0) {
          _v(Firm.balaji, at, 'Payment', 'Transport Charges', 'Transport Charges', 'Cash', 2500.0 + _r.nextInt(65) * 100,
              cash: true, narration: 'ભાડું');
        }
        if (back % 7 == 0) {
          _v(Firm.balaji, at, 'Payment', 'Weighing Charges', 'Weighing Charges', 'Cash', 800.0, cash: true, narration: 'કાંટો');
        }
        final double cp = cashByDay[back] ?? 0;
        if (cp > 0) {
          final double w = ((cp + 6000) / 50000).ceil() * 50000.0;
          _v(Firm.balaji, d.add(const Duration(hours: 8)), 'Contra', 'Cash', 'Cash', 'SBI Current A/c', w,
              narration: 'બેંક માંથી રોકડ ઉપાડ');
        }
      }
      if (d.day == 1) {
        _v(Firm.balaji, at, 'Payment', 'Salary', 'Salary', 'SBI Current A/c', 85000, narration: 'પગાર');
        _v(Firm.balaji, at, 'Payment', 'Electricity', 'Electricity', 'SBI Current A/c', 18000.0 + _r.nextInt(60) * 100,
            narration: 'લાઇટ બિલ');
      }
    }
    // ---- paka firms: sales (GST) + receipts + monthly expenses ----
    for (final Firm f in <Firm>[Firm.patel, Firm.shreenathji]) {
      final int step = f == Firm.patel ? 2 : 3;
      for (int back = 80; back >= 0; back -= step) {
        final DateTime d = today.subtract(Duration(days: back));
        final DateTime at = DateTime(d.year, d.month, d.day, 16, 10);
        final Party b = buyers[_r.nextInt(buyers.length)];
        final int g = _pickGrade();
        final double kg = (12000 + _r.nextInt(14000)).toDouble();
        final double rate = _baseRate(back, g) + 85;
        final double amt = (kg / 20 * rate).roundToDouble();
        final double gst = (amt * 0.05).roundToDouble();
        _v(f, at, 'Sales', b.name, b.name, 'Sales A/c', amt,
            gst: gst, narration: 'GST ઇનવોઇસ · ${gradeName(g, shortName: true)}', grade: g, kg: kg);
        final DateTime rd = at.add(Duration(days: 4 + _r.nextInt(22)));
        if (!rd.isAfter(DateTime.now()) && _r.nextInt(100) < 85) {
          _v(f, rd, 'Receipt', b.name, 'HDFC Current A/c', b.name, amt + gst, narration: 'NEFT');
        }
        if (d.day <= step && d.weekday != DateTime.sunday) {
          _v(f, at, 'Payment', 'Office Rent', 'Office Rent', 'HDFC Current A/c', 15000, narration: 'ઓફિસ ભાડું');
          _v(f, at, 'Payment', 'Accountant Fees', 'Accountant Fees', 'HDFC Current A/c', 8000, narration: 'CA ફી');
        }
        if (back % 15 == 0) {
          _v(f, at, 'Payment', 'Bank Charges', 'Bank Charges', 'HDFC Current A/c', 450.0 + _r.nextInt(300),
              narration: 'બેંક ચાર્જ');
        }
        if (back % 20 == 0) {
          _v(f, at, 'Contra', 'Cash', 'Cash', 'HDFC Current A/c', 50000, narration: 'રોકડ ઉપાડ');
        }
      }
    }
    vouchers.sort((Voucher a, Voucher b) {
      final int c = b.date.compareTo(a.date);
      return c != 0 ? c : b.id.compareTo(a.id);
    });
  }

  String _groupOf(String name) {
    if (name == 'Cash') return 'Cash-in-Hand';
    if (name.endsWith('Current A/c')) return 'Bank Accounts';
    if (name == 'Sales A/c') return 'Sales Accounts';
    if (name == 'Purchase A/c') return 'Purchase Accounts';
    if (name == 'GST Output') return 'Duties & Taxes';
    if (name == 'Capital A/c') return 'Capital Account';
    if (_directExp.contains(name)) return 'Direct Expenses';
    if (_indirectExp.contains(name)) return 'Indirect Expenses';
    if (_farmerSet.contains(name)) return 'Sundry Creditors';
    return 'Sundry Debtors';
  }

  void _buildLedgers() {
    final Map<String, LedgerAcc> m = <String, LedgerAcc>{};
    LedgerAcc acc(Firm f, String name) {
      return m.putIfAbsent('${f.index}|$name', () => LedgerAcc(f, name, _groupOf(name)));
    }

    // opening balances
    acc(Firm.balaji, 'Cash').opening = 500000;
    acc(Firm.balaji, 'SBI Current A/c').opening = 25000000;
    acc(Firm.patel, 'Cash').opening = 50000;
    acc(Firm.patel, 'HDFC Current A/c').opening = 6000000;
    acc(Firm.shreenathji, 'Cash').opening = 50000;
    acc(Firm.shreenathji, 'HDFC Current A/c').opening = 5000000;
    for (final Party b in buyers) {
      if (b.opening != 0) acc(Firm.balaji, b.name).opening = b.opening;
    }
    for (final Voucher v in vouchers) {
      if (v.type == 'Sales') {
        acc(v.firm, v.dr).dr += v.amount + v.gst;
        acc(v.firm, v.cr).cr += v.amount;
        if (v.gst > 0) acc(v.firm, 'GST Output').cr += v.gst;
      } else {
        acc(v.firm, v.dr).dr += v.amount;
        acc(v.firm, v.cr).cr += v.amount;
      }
    }
    for (final Firm f in Firm.values) {
      double sum = 0;
      for (final LedgerAcc a in m.values) {
        if (a.firm == f) sum += a.opening;
      }
      acc(f, 'Capital A/c').opening = -sum;
    }
    ledgers.addAll(m.values);
    ledgers.sort((LedgerAcc a, LedgerAcc b) {
      final int c = a.firm.index.compareTo(b.firm.index);
      if (c != 0) return c;
      final int ga = kGroupOrder.indexOf(a.group);
      final int gb = kGroupOrder.indexOf(b.group);
      if (ga != gb) return ga.compareTo(gb);
      return a.name.compareTo(b.name);
    });
  }

  void _buildStock() {
    const List<double> openingKg = <double>[150000, 90000, 40000];
    final List<List<double>> pur = <List<double>>[
      <double>[0, 0, 0], <double>[0, 0, 0], <double>[0, 0, 0],
    ];
    final List<double> rateSum = <double>[0, 0, 0];
    final List<double> rateKg = <double>[0, 0, 0];
    for (final Entry e in entries) {
      pur[e.godown][e.g] += e.net;
      rateSum[e.g] += e.rate * e.net;
      rateKg[e.g] += e.net;
    }
    final List<double> sold = <double>[0, 0, 0];
    for (final Voucher v in vouchers) {
      if (v.firm == Firm.balaji && v.type == 'Sales' && v.grade >= 0) sold[v.grade] += v.kg;
    }
    for (int g = 0; g < 3; g++) {
      final double avg = rateKg[g] > 0 ? rateSum[g] / rateKg[g] : rates[g];
      double total = openingKg[g] + pur[0][g] + pur[1][g] + pur[2][g] - sold[g];
      if (total < 20000) total = 20000;
      double weightSum = 0;
      final List<double> w = <double>[0, 0, 0];
      for (int gd = 0; gd < 3; gd++) {
        w[gd] = openingKg[g] / 3 + pur[gd][g];
        weightSum += w[gd];
      }
      for (int gd = 0; gd < 3; gd++) {
        stock.add(StockRow(gd, g, (total * w[gd] / weightSum).roundToDouble(), avg.roundToDouble()));
      }
    }
  }

  // --------------------------------------------------------------- queries
  int get nextEntryNo => ++_entryNo;

  void addEntry(Entry e) {
    entries.insert(0, e);
  }

  List<Entry> entriesInDays(int days) {
    return entries.where((Entry e) => today.difference(dateOnly(e.dt)).inDays < days).toList();
  }

  List<Entry> entriesOn(DateTime d) => entries.where((Entry e) => sameDay(e.dt, d)).toList();

  List<Voucher> vouchersIn({Firm? firm, int days = 100000, String? type}) {
    return vouchers.where((Voucher v) {
      if (firm != null && v.firm != firm) return false;
      if (type != null && v.type != type) return false;
      return today.difference(dateOnly(v.date)).inDays < days;
    }).toList();
  }

  List<LedgerAcc> ledgersOf(Firm? firm) {
    if (firm == null) return ledgers;
    return ledgers.where((LedgerAcc l) => l.firm == firm).toList();
  }

  double sumGroup(Firm? firm, String group) {
    double s = 0;
    for (final LedgerAcc l in ledgersOf(firm)) {
      if (l.group == group) s += l.closing;
    }
    return s;
  }

  double cashBalance(Firm? firm) => sumGroup(firm, 'Cash-in-Hand');
  double bankBalance(Firm? firm) => sumGroup(firm, 'Bank Accounts');

  double receivable(Firm? firm) {
    double s = 0;
    for (final LedgerAcc l in ledgersOf(firm)) {
      if (l.group == 'Sundry Debtors' && l.closing > 0) s += l.closing;
    }
    return s;
  }

  double payable(Firm? firm) {
    double s = 0;
    for (final LedgerAcc l in ledgersOf(firm)) {
      if (l.group == 'Sundry Creditors' && l.closing < 0) s -= l.closing;
    }
    return s;
  }

  double stockValue(Firm? firm) {
    if (firm != null && firm != Firm.balaji) return 0;
    double s = 0;
    for (final StockRow r in stock) {
      s += r.value;
    }
    return s;
  }

  double stockKg(Firm? firm) {
    if (firm != null && firm != Firm.balaji) return 0;
    double s = 0;
    for (final StockRow r in stock) {
      s += r.kg;
    }
    return s;
  }

  /// Net profit (with closing stock) for a firm or all firms.
  double netProfit(Firm? firm, {int days = 100000}) {
    double sales = 0, purchase = 0, direct = 0, indirect = 0;
    for (final Voucher v in vouchersIn(firm: firm, days: days)) {
      if (v.type == 'Sales') sales += v.amount;
      if (v.type == 'Purchase') purchase += v.amount;
      if (_directExp.contains(v.dr) && v.type == 'Payment') direct += v.amount;
      if (_indirectExp.contains(v.dr) && v.type != 'Sales') indirect += v.amount;
    }
    final double stockAdj = days >= 100000 ? stockValue(firm) : 0;
    return sales + stockAdj - purchase - direct - indirect;
  }

  Party? farmerByName(String n) {
    for (final Party p in farmers) {
      if (p.name == n) return p;
    }
    return null;
  }

  Party? partyByName(String n) {
    for (final Party p in farmers) {
      if (p.name == n) return p;
    }
    for (final Party p in buyers) {
      if (p.name == n) return p;
    }
    for (final Party p in brokers) {
      if (p.name == n) return p;
    }
    return null;
  }

  List<Entry> entriesOfFarmer(Party p) => entries.where((Entry e) => e.farmer.id == p.id).toList();

  double farmerDue(Party p) {
    double s = 0;
    for (final Entry e in entries) {
      if (e.farmer.id == p.id) s += e.due;
    }
    return s;
  }

  /// Net receivable of a buyer over all three companies (+ => they owe us).
  double buyerBalance(Party p) {
    double s = 0;
    for (final LedgerAcc l in ledgers) {
      if (l.name == p.name) s += l.closing;
    }
    return s;
  }

  DateTime? lastVoucherOf(String name, String type) {
    for (final Voucher v in vouchers) {
      if (v.party == name && v.type == type) return v.date;
    }
    return null;
  }

  /// FIFO ageing of what buyers still owe us across all firms.
  Map<String, AgeBuckets> receivableAging() {
    final Map<String, AgeBuckets> out = <String, AgeBuckets>{};
    for (final Party b in buyers) {
      final List<List<Object>> sales = <List<Object>>[]; // [date, amount]
      double received = 0;
      if (b.opening > 0) sales.add(<Object>[today.subtract(const Duration(days: 120)), b.opening]);
      final List<Voucher> mine = vouchers.where((Voucher v) => v.party == b.name).toList().reversed.toList();
      for (final Voucher v in mine) {
        if (v.type == 'Sales') sales.add(<Object>[v.date, v.total]);
        if (v.type == 'Receipt' || v.type == 'Journal') received += v.amount;
      }
      final AgeBuckets ab = AgeBuckets();
      for (final List<Object> s in sales) {
        double amt = s[1] as double;
        if (received >= amt) {
          received -= amt;
          continue;
        }
        amt -= received;
        received = 0;
        ab.add(today.difference(dateOnly(s[0] as DateTime)).inDays, amt);
      }
      if (ab.total > 1) out[b.name] = ab;
    }
    return out;
  }

  AgeBuckets payableAging() {
    final AgeBuckets ab = AgeBuckets();
    for (final Entry e in entries) {
      if (e.due > 0.5) ab.add(today.difference(dateOnly(e.dt)).inDays, e.due);
    }
    return ab;
  }

  List<AlertItem> alerts() {
    final List<AlertItem> a = <AlertItem>[];
    final Map<String, AgeBuckets> ag = receivableAging();
    int old = 0;
    double oldAmt = 0;
    ag.forEach((String k, AgeBuckets v) {
      final double x = v.b1 + v.b2 + v.b3;
      if (x > 100000) {
        old++;
        oldAmt += x;
      }
    });
    if (old > 0) {
      a.add(AlertItem('rose', 'clock', bi('$old ખરીદદારનું 30+ દિવસ જૂનું બાકી', '$old buyers overdue 30+ days'),
          bi('કુલ ${inrC(oldAmt)} વસૂલવાના', 'Total ${inrC(oldAmt)} to collect'), 'aging'));
    }
    final double due = payable(null);
    int dueFarmers = 0;
    for (final Party f in farmers) {
      if (farmerDue(f) > 50000) dueFarmers++;
    }
    if (dueFarmers > 0) {
      a.add(AlertItem('amber', 'users', bi('$dueFarmers ખેડૂતને ચૂકવણી બાકી', '$dueFarmers farmers pending payment'),
          bi('કુલ ${inrC(due)} દેવું', 'Total ${inrC(due)} payable'), 'payables'));
    }
    final double cash = cashBalance(Firm.balaji);
    if (cash < 300000) {
      a.add(AlertItem('amber', 'wallet', bi('રોકડ ઓછી: ${inrC(cash)}', 'Low cash: ${inrC(cash)}'),
          bi('બેંકમાંથી ઉપાડ વિચારો', 'Consider a bank withdrawal'), 'cash_book'));
    }
    for (final Party b in buyers) {
      final double bal = buyerBalance(b);
      if (b.creditLimit > 0 && bal > b.creditLimit) {
        a.add(AlertItem('rose', 'warn', bi('${b.name}: ક્રેડિટ લિમિટ પાર', '${b.name}: credit limit exceeded'),
            bi('બાકી ${inrC(bal)} · લિમિટ ${inrC(b.creditLimit)}', 'Due ${inrC(bal)} · limit ${inrC(b.creditLimit)}'),
            'credit_limit'));
        break;
      }
    }
    final double kg = stockKg(null);
    if (kg < 200000) {
      a.add(AlertItem('blue', 'box', bi('સ્ટોક ઓછો: ${tons(kg)}', 'Low stock: ${tons(kg)}'),
          bi('રીઓર્ડર વિચારો', 'Consider reordering'), 'reorder'));
    }
    final int todayN = entriesOn(today).length;
    a.add(AlertItem('green', 'check', bi('આજે $todayN એન્ટ્રી નોંધાઈ', '$todayN entries recorded today'),
        bi('દિવસ બંધ કરતા પહેલાં હિસાબ તપાસો', 'Review before closing the day'), 'day_close'));
    return a;
  }
}
