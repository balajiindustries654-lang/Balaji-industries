import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'live_store.dart';

/// A small JSON document the owner keeps in the shared `app_settings` table
/// (so every phone / PC of the owner sees the same) and also on the phone
/// (so it works without internet and is pushed later).
class SyncDoc extends ChangeNotifier {
  final String key;
  Map<String, dynamic> data = <String, dynamic>{};
  bool _loaded = false;
  bool _dirty = false;
  bool _busy = false;

  SyncDoc(this.key);

  bool get loaded => _loaded;

  /// Reads the phone copy once, then refreshes from the server.
  Future<void> ensure() async {
    if (_loaded) return;
    _loaded = true;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      final String raw = p.getString('doc_$key') ?? '';
      _dirty = p.getBool('dirty_$key') ?? false;
      if (raw.isNotEmpty) {
        final Object? j = jsonDecode(raw);
        if (j is Map) data = Map<String, dynamic>.from(j);
      }
    } catch (_) {}
    notifyListeners();
    await pull();
  }

  Future<void> pull() async {
    if (!live.isAdmin) return;
    final int ver0 = _ver;
    try {
      if (_dirty) {
        await _push();
        return;
      }
      final List<Map<String, dynamic>> rows = await live.supa.select(
        'app_settings',
        <String, String>{'select': '*', 'key': 'eq.$key'},
        limit: 1,
      );
      // an entry was made on this device while the answer was on its way: the answer is older, keep ours
      if (_ver != ver0 || _dirty) return;
      if (rows.isNotEmpty) {
        final Object? v = rows.first['value'];
        if (v is Map) {
          data = Map<String, dynamic>.from(v);
          await _store();
          notifyListeners();
        }
      }
    } catch (_) {
      // no internet or an odd answer: the copy on this device stays in use
    }
  }

  /// Call after changing [data].
  Future<void> save() async {
    _ver++;
    _dirty = true;
    await _store();
    notifyListeners();
    // the entry is already safe on this device; a slow upload goes on in the background instead of holding the Save button
    await _push().timeout(const Duration(seconds: 6), onTimeout: () {});
  }

  /// Reads the newest copy from the server first, applies [change] and saves,
  /// so two phones adding entries at the same time do not lose each other's.
  /// The read waits at most a few seconds: with a slow or lost internet the entry is saved on this device at once
  /// and goes to the server later.
  Future<void> commit(void Function() change) async {
    try {
      // already known to be offline: do not make the person wait for a server that will not answer
      await pull().timeout(live.offline ? const Duration(milliseconds: 700) : const Duration(seconds: 5));
    } catch (_) {}
    change();
    await save();
  }

  /// Counts the saves made on this device (an older answer from the server must not replace newer entries).
  int _ver = 0;

  Future<void> _push() async {
    if (_busy) return;
    _busy = true;
    try {
      // an entry added while the upload was running is sent in another round
      for (int round = 0; round < 3; round++) {
        final int sent = _ver;
        await live.supa.upsert('app_settings', <String, dynamic>{'key': key, 'value': data}, 'key');
        if (_ver == sent) {
          _dirty = false;
          break;
        }
      }
    } catch (_) {
      // any failure (no internet, a refused certificate ...) keeps the change safe on this device and retries later
      _dirty = true;
    } finally {
      _busy = false;
    }
    await _store();
  }

  Future<void> _store() async {
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setString('doc_$key', jsonEncode(data));
      await p.setBool('dirty_$key', _dirty);
    } catch (_) {}
  }

  // ---------------------------------------------------------------- helpers
  /// data[k] as a map (created when missing).
  Map<String, dynamic> map(String k) {
    final Object? v = data[k];
    if (v is Map<String, dynamic>) return v;
    final Map<String, dynamic> n = v is Map ? Map<String, dynamic>.from(v) : <String, dynamic>{};
    data[k] = n;
    return n;
  }

  /// data[k] as a list of maps (created when missing).
  List<Map<String, dynamic>> list(String k) {
    final Object? v = data[k];
    final List<Map<String, dynamic>> out = <Map<String, dynamic>>[];
    if (v is List) {
      for (final Object? e in v) {
        if (e is Map) out.add(Map<String, dynamic>.from(e));
      }
    }
    data[k] = out;
    return out;
  }

  double num0(String k, double d) {
    final Object? v = data[k];
    if (v is num) return v.toDouble();
    if (v is String) return double.tryParse(v) ?? d;
    return d;
  }
}

/// Rates per 20 kg: { material: { 'yyyy-mm-dd': rate } }
final SyncDoc rateDoc = SyncDoc('flutter_rates');

/// Follow-ups / to-do list: { items: [ {id, text, due, done, ref, at} ] }
final SyncDoc todoDoc = SyncDoc('flutter_todos');

/// Notes about farmers / vehicles / ...: { n: { partyId: {t, at} } }
final SyncDoc noteDoc = SyncDoc('flutter_notes');

/// Owner choices: target, load limit, night window, opening stock ...
final SyncDoc prefDoc = SyncDoc('flutter_prefs');

/// Payments / advances to farmers: { items: [ {id, key, label, date, amt, kind, mode, note, at} ] }
final SyncDoc payDoc = SyncDoc('flutter_pay');

/// Expenses and cash received: { items: [ {id, date, amt, cat, note, kind, mode, at} ] }
final SyncDoc expDoc = SyncDoc('flutter_exp');

/// Vehicles expected to come: { items: [ {id, vehicle, party, material, kg, date, note, done, at} ] }
final SyncDoc bookDoc = SyncDoc('flutter_book');

String _dk(DateTime d) => '${d.year}-${d.month < 10 ? '0' : ''}${d.month}-${d.day < 10 ? '0' : ''}${d.day}';

/// Rate (Rs per 20 kg) of [material] on [day]: the latest one set on or before it.
double? rateFor(String material, DateTime day) {
  final Object? all = rateDoc.data['rates'];
  if (all is! Map) return null;
  final Object? one = all[material];
  if (one is! Map) return null;
  final String lim = _dk(day);
  String best = '';
  double? val;
  for (final MapEntry<dynamic, dynamic> e in one.entries) {
    final String k = '${e.key}';
    if (k.compareTo(lim) <= 0 && k.compareTo(best) > 0) {
      final Object? v = e.value;
      final double? d = v is num ? v.toDouble() : double.tryParse('$v');
      if (d != null) {
        best = k;
        val = d;
      }
    }
  }
  return val;
}

/// All rates of one material, newest first: [ [yyyy-mm-dd, rate], ... ].
List<MapEntry<String, double>> ratesOfMaterial(String material) {
  final List<MapEntry<String, double>> out = <MapEntry<String, double>>[];
  final Object? all = rateDoc.data['rates'];
  if (all is Map) {
    final Object? one = all[material];
    if (one is Map) {
      for (final MapEntry<dynamic, dynamic> e in one.entries) {
        final Object? v = e.value;
        final double? d = v is num ? v.toDouble() : double.tryParse('$v');
        if (d != null) out.add(MapEntry<String, double>('${e.key}', d));
      }
    }
  }
  out.sort((MapEntry<String, double> a, MapEntry<String, double> b) => b.key.compareTo(a.key));
  return out;
}

Future<void> setRate(String material, DateTime day, double? rate) {
  final Map<String, dynamic> all = rateDoc.map('rates');
  Map<String, dynamic> one;
  final Object? cur = all[material];
  if (cur is Map<String, dynamic>) {
    one = cur;
  } else {
    one = cur is Map ? Map<String, dynamic>.from(cur) : <String, dynamic>{};
    all[material] = one;
  }
  if (rate == null) {
    one.remove(_dk(day));
  } else {
    one[_dk(day)] = rate;
  }
  return rateDoc.save();
}

/// Free-text note of a party (id = PartyRef.id), '' when none.
String noteOf(String partyId) {
  final Object? n = noteDoc.data['n'];
  if (n is! Map) return '';
  final Object? e = n[partyId];
  if (e is Map) return '${e['t'] ?? ''}';
  return '';
}

Future<void> setNote(String partyId, String text, {String label = ''}) {
  final Map<String, dynamic> n = noteDoc.map('n');
  if (text.trim().isEmpty) {
    n.remove(partyId);
  } else {
    n[partyId] = <String, dynamic>{'t': text.trim(), 'l': label, 'at': DateTime.now().toIso8601String()};
  }
  return noteDoc.save();
}

/// Open and overdue follow-ups: [open, overdue].
List<int> followupCounts() {
  int open = 0;
  int overdue = 0;
  final String today = _dk(DateTime.now());
  for (final Map<String, dynamic> it in todoDoc.list('items')) {
    if (it['done'] == true) continue;
    open++;
    final String due = '${it['due'] ?? ''}';
    if (due.isNotEmpty && due.compareTo(today) < 0) overdue++;
  }
  return <int>[open, overdue];
}

/// Daily target in KG (0 = none).
double dailyTarget() => prefDoc.num0('target', 0);

/// A kanta load above this many KG is flagged as heavy.
double bigLoadKg() => prefDoc.num0('bigLoad', 30000);

/// Night window (hours, 24h clock) in which entries look odd.
int nightFrom() => prefDoc.num0('nightFrom', 22).round();
int nightTo() => prefDoc.num0('nightTo', 5).round();

/// Gap (minutes) between two weighbridge entries that counts as "idle".
int idleMinutes() => prefDoc.num0('idleMin', 30).round();
