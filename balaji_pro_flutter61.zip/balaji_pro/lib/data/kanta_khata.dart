import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'kanta_log.dart';
import 'kanta_slip.dart';
import 'live_models.dart' show nameKey, vehicleKey;
import 'live_store.dart';

// ======================================================================
// Weighbridge KHATA: one account per name for the weighing charges.
//   debit  = the charges of the weighings that were NOT paid in cash at the weighing ("baki")
//   credit = "Jama" - money received later (written in the Kanta app or on the owner's phone)
//   baki   = debit - credit
// The account of a weighing is found by NAME; a weighing without a name goes to the account of its MOBILE number (or to the
// name that this mobile number had before); one without a mobile goes to the VEHICLE number.
//
// Where it lives:
//   laptop (Balaji Kanta)  builds the accounts from its slip history (KantaHistory) and pushes them to the server
//   everybody              writes Jama into the same list (merged by id, so two devices never lose each other's entry)
//   server                 table kanta_live, row id = 'khata'  (inside = accounts, recent = Jama list) - the SQL of remote weighing
//                          already made this table, nothing new to run.
// ======================================================================

const String kKhataRow = 'khata';

double _num(Object? v) => v is num ? v.toDouble() : (double.tryParse('${v ?? ''}') ?? 0);

/// The 10 digits of an Indian mobile number ('' when it is not one).
String mobile10(String s) {
  final String d = s.replaceAll(RegExp(r'[^0-9]'), '');
  if (d.length < 10) return '';
  return d.substring(d.length - 10);
}

/// One weighing with a charge (a line in the statement of an account).
class KhataLine {
  final DateTime at;
  final String rst;
  final String vehicle;
  final double charge;
  final bool paid;
  const KhataLine(this.at, this.rst, this.vehicle, this.charge, this.paid);

  List<Object> toJson() => <Object>[at.millisecondsSinceEpoch, rst, vehicle, charge, paid ? 1 : 0];

  static KhataLine? fromJson(Object? j) {
    if (j is! List || j.length < 5) return null;
    return KhataLine(DateTime.fromMillisecondsSinceEpoch(_num(j[0]).toInt()), '${j[1]}', '${j[2]}', _num(j[3]), _num(j[4]) == 1);
  }
}

/// Money received (cr) or an opening balance / extra amount to pay (dr), written by hand.
class KhataPay {
  final String id;
  final String key;
  final String name;
  final String mobile;
  final String kind; // 'cr' jama | 'dr' baki nakhi
  final double amount;
  final DateTime at;
  final String note;
  final String by;
  bool deleted;
  KhataPay({required this.id, required this.key, required this.name, required this.mobile, required this.kind, required this.amount, required this.at, this.note = '', this.by = '', this.deleted = false});

  bool get isCredit => kind != 'dr';

  Map<String, Object> toJson() => <String, Object>{
        'i': id,
        'k': key,
        'n': name,
        'm': mobile,
        't': kind,
        'a': amount,
        'd': at.millisecondsSinceEpoch,
        if (note.isNotEmpty) 'o': note,
        if (by.isNotEmpty) 'b': by,
        if (deleted) 'x': 1,
      };

  static KhataPay? fromJson(Object? j) {
    if (j is! Map) return null;
    final String id = '${j['i'] ?? ''}';
    if (id.isEmpty) return null;
    return KhataPay(
      id: id,
      key: '${j['k'] ?? ''}',
      name: '${j['n'] ?? ''}',
      mobile: '${j['m'] ?? ''}',
      kind: '${j['t'] ?? 'cr'}' == 'dr' ? 'dr' : 'cr',
      amount: _num(j['a']),
      at: DateTime.fromMillisecondsSinceEpoch(_num(j['d']).toInt()),
      note: '${j['o'] ?? ''}',
      by: '${j['b'] ?? ''}',
      deleted: j['x'] == 1 || j['x'] == true,
    );
  }
}

/// The account of one name (or mobile number / vehicle number).
class KhataAcc {
  final String key;
  String name;
  String mobile;
  String vehicle;

  /// Weighings with a charge, and how many of them were paid in cash at the weighing.
  int count = 0;
  int paidCount = 0;

  /// Charges not paid at the weighing (the debit), charges paid in cash at the weighing (for information).
  double unpaid = 0;
  double paidNow = 0;

  /// Money received later / opening amounts written by hand.
  double jama = 0;
  double dr = 0;
  DateTime? last;
  final List<KhataLine> lines = <KhataLine>[];
  final List<KhataPay> pays = <KhataPay>[];

  KhataAcc(this.key, {this.name = '', this.mobile = '', this.vehicle = ''});

  double get baki => unpaid + dr - jama;

  /// The name; without a name the mobile number; without that the vehicle number.
  String get label => name.isNotEmpty ? name : (mobile.isNotEmpty ? mobile : vehicle);

  Map<String, Object> toJson({bool withLines = false}) => <String, Object>{
        'k': key,
        'n': name,
        'm': mobile,
        'v': vehicle,
        'c': count,
        'pc': paidCount,
        'u': unpaid,
        'p': paidNow,
        'j': jama,
        'r': dr,
        if (last != null) 'l': last!.millisecondsSinceEpoch,
        if (withLines && lines.isNotEmpty) 'e': <Object>[for (final KhataLine l in lines.take(20)) l.toJson()],
      };

  static KhataAcc? fromJson(Object? j) {
    if (j is! Map) return null;
    final String k = '${j['k'] ?? ''}';
    if (k.isEmpty) return null;
    final KhataAcc a = KhataAcc(k, name: '${j['n'] ?? ''}', mobile: '${j['m'] ?? ''}', vehicle: '${j['v'] ?? ''}');
    a.count = _num(j['c']).toInt();
    a.paidCount = _num(j['pc']).toInt();
    a.unpaid = _num(j['u']);
    a.paidNow = _num(j['p']);
    a.jama = _num(j['j']);
    a.dr = _num(j['r']);
    final num? l = j['l'] is num ? j['l'] as num : null;
    if (l != null) a.last = DateTime.fromMillisecondsSinceEpoch(l.toInt());
    final Object? e = j['e'];
    if (e is List) {
      for (final Object? x in e) {
        final KhataLine? ln = KhataLine.fromJson(x);
        if (ln != null) a.lines.add(ln);
      }
    }
    return a;
  }
}

/// The account key of a weighing: by name, else by mobile (the name this mobile had before wins), else by vehicle. '' = none.
String khataKey(String name, String mobile, String vehicle, Map<String, String> mobileName) {
  final String n = nameKey(name);
  if (n.isNotEmpty) return 'n:$n';
  final String m = mobile10(mobile);
  if (m.isNotEmpty) {
    final String? known = mobileName[m];
    if (known != null && known.isNotEmpty) return 'n:${nameKey(known)}';
    return 'm:$m';
  }
  final String v = vehicleKey(vehicle);
  if (v.isNotEmpty) return 'v:$v';
  return '';
}

/// Builds the accounts from the slips (newest first) and the Jama list. Only slips from [from] on are counted.
List<KhataAcc> buildKhata(List<SlipRec> slips, List<KhataPay> pays, DateTime from) {
  // which name did a mobile number have (the newest slip with both wins)
  final Map<String, String> mobileName = <String, String>{};
  for (final SlipRec r in slips) {
    if (r.undone) continue;
    final String m = mobile10(r.mobile);
    if (m.isEmpty || r.party.trim().isEmpty || mobileName.containsKey(m)) continue;
    mobileName[m] = r.party.trim();
  }
  final Map<String, KhataAcc> by = <String, KhataAcc>{};
  KhataAcc acc(String key, String name, String mobile, String vehicle) {
    final KhataAcc a = by.putIfAbsent(key, () => KhataAcc(key));
    if (a.name.isEmpty && name.trim().isNotEmpty) a.name = name.trim().toUpperCase();
    if (a.mobile.isEmpty && mobile10(mobile).isNotEmpty) a.mobile = mobile10(mobile);
    if (a.vehicle.isEmpty && vehicle.trim().isNotEmpty) a.vehicle = vehicle.trim().toUpperCase();
    return a;
  }

  for (final SlipRec r in slips) {
    if (r.undone || r.charges <= 0 || r.at.isBefore(from)) continue;
    final String key = khataKey(r.party, r.mobile, r.vehicle, mobileName);
    if (key.isEmpty) continue;
    // the name of the account: the party of the slip, or the name this mobile had
    final String nm = r.party.trim().isNotEmpty ? r.party : (mobileName[mobile10(r.mobile)] ?? '');
    final KhataAcc a = acc(key, nm, r.mobile, r.vehicle);
    a.count++;
    if (r.paid) {
      a.paidCount++;
      a.paidNow += r.charges;
    } else {
      a.unpaid += r.charges;
    }
    if (a.last == null || r.at.isAfter(a.last!)) a.last = r.at;
    a.lines.add(KhataLine(r.at, r.rst, r.vehicle, r.charges, r.paid));
  }
  for (final KhataPay p in pays) {
    if (p.deleted) continue;
    final KhataAcc a = acc(p.key, p.name, p.mobile, '');
    a.pays.add(p);
    if (p.isCredit) {
      a.jama += p.amount;
    } else {
      a.dr += p.amount;
    }
    if (a.last == null || p.at.isAfter(a.last!)) a.last = p.at;
  }
  for (final KhataAcc a in by.values) {
    a.lines.sort((KhataLine x, KhataLine y) => y.at.compareTo(x.at));
    a.pays.sort((KhataPay x, KhataPay y) => y.at.compareTo(x.at));
  }
  final List<KhataAcc> out = by.values.toList();
  sortKhata(out);
  return out;
}

/// The biggest baki first, then the one used last.
void sortKhata(List<KhataAcc> l) {
  l.sort((KhataAcc a, KhataAcc b) {
    final int c = b.baki.compareTo(a.baki);
    if (c != 0) return c;
    final DateTime ta = a.last ?? DateTime.fromMillisecondsSinceEpoch(0);
    final DateTime tb = b.last ?? DateTime.fromMillisecondsSinceEpoch(0);
    return tb.compareTo(ta);
  });
}

/// Union of two Jama lists by id (a deleted mark wins). [changed]: the result differs from [other].
List<KhataPay> mergePays(List<KhataPay> mine, List<KhataPay> other) {
  final Map<String, KhataPay> m = <String, KhataPay>{};
  for (final KhataPay p in other) {
    m[p.id] = p;
  }
  for (final KhataPay p in mine) {
    final KhataPay? o = m[p.id];
    if (o == null) {
      m[p.id] = p;
    } else if (p.deleted && !o.deleted) {
      m[p.id] = p;
    }
  }
  final List<KhataPay> out = m.values.toList()..sort((KhataPay a, KhataPay b) => a.at.compareTo(b.at));
  return out;
}

String _payFp(List<KhataPay> l) {
  final List<String> s = <String>[for (final KhataPay p in l) '${p.id}${p.deleted ? 'x' : ''}']..sort();
  return s.join(',');
}

// ----------------------------------------------------------------------------------------------- the server row

abstract class KhataApi {
  /// The row 'khata' of kanta_live (null when there is none yet).
  Future<Map<String, dynamic>?> getRow();

  /// Writes only the given columns.
  Future<void> putRow(Map<String, dynamic> cols);
}

class SupaKhataApi implements KhataApi {
  @override
  Future<Map<String, dynamic>?> getRow() async {
    final List<Map<String, dynamic>> r = await live.supa.select('kanta_live', <String, String>{'select': '*', 'id': 'eq.$kKhataRow'}, limit: 1);
    return r.isEmpty ? null : r.first;
  }

  @override
  Future<void> putRow(Map<String, dynamic> cols) async {
    await live.supa.upsert('kanta_live', <String, dynamic>{'id': kKhataRow, ...cols}, 'id');
  }
}

class KantaKhata extends ChangeNotifier {
  KantaKhata([KhataApi? api]) : api = api ?? SupaKhataApi();

  KhataApi api;

  /// The weighbridge laptop builds the accounts itself (from KantaHistory) and pushes them; a phone only reads them.
  bool host = false;

  /// Is the user signed in and online (replaced in tests).
  bool Function() canSync = () => live.signedIn && !live.offline;

  /// Who is writing (shown with every Jama).
  String Function() whoAmI = () => live.me?.name ?? '';

  /// Slips are counted from this moment on (the first run sets it to this morning; Settings can move it back).
  DateTime from = DateTime.now();
  bool _fromSet = false;

  List<KhataPay> pays = <KhataPay>[];
  List<KhataAcc> accs = <KhataAcc>[];
  DateTime? remoteAt;
  String error = '';
  bool busy = false;
  bool _again = false;
  bool _loaded = false;
  bool _dirtyAccs = true;
  String _lastAccsSent = '';
  Timer? _deb;

  Future<void> load() async {
    if (_loaded) return;
    _loaded = true;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      final int f = p.getInt('kk_from') ?? 0;
      if (f > 0) {
        from = DateTime.fromMillisecondsSinceEpoch(f);
        _fromSet = true;
      }
      final String raw = p.getString('kk_pay') ?? '';
      if (raw.isNotEmpty) {
        final Object? j = jsonDecode(raw);
        if (j is List) {
          pays = <KhataPay>[for (final Object? e in j) if (KhataPay.fromJson(e) != null) KhataPay.fromJson(e)!];
        }
      }
      if (!host) {
        final String a = p.getString('kk_accs') ?? '';
        if (a.isNotEmpty) {
          final Object? j = jsonDecode(a);
          if (j is Map) {
            accs = _accsFrom(j['a']);
            final num? at = j['at'] is num ? j['at'] as num : null;
            if (at != null) remoteAt = DateTime.fromMillisecondsSinceEpoch(at.toInt());
          }
        }
      }
    } catch (_) {}
    if (host && !_fromSet) {
      final DateTime n = DateTime.now();
      from = DateTime(n.year, n.month, n.day);
      _fromSet = true;
      await _saveFrom();
    }
    rebuild();
  }

  Future<void> _saveFrom() async {
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setInt('kk_from', from.millisecondsSinceEpoch);
    } catch (_) {}
  }

  Future<void> _savePays() async {
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setString('kk_pay', jsonEncode(<Object>[for (final KhataPay x in pays) x.toJson()]));
    } catch (_) {}
  }

  Future<void> _saveAccs() async {
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setString('kk_accs', jsonEncode(<String, Object>{'a': <Object>[for (final KhataAcc a in accs) a.toJson(withLines: true)], 'at': (remoteAt ?? DateTime.now()).millisecondsSinceEpoch}));
    } catch (_) {}
  }

  /// "Count the charges from this day" (the Settings of the Kanta app).
  Future<void> setFrom(DateTime d) async {
    from = DateTime(d.year, d.month, d.day);
    _fromSet = true;
    await _saveFrom();
    _dirtyAccs = true;
    rebuild();
    schedulePush();
  }

  static List<KhataAcc> _accsFrom(Object? j) {
    final List<KhataAcc> out = <KhataAcc>[];
    if (j is List) {
      for (final Object? e in j) {
        final KhataAcc? a = KhataAcc.fromJson(e);
        if (a != null) out.add(a);
      }
    }
    sortKhata(out);
    return out;
  }

  /// The laptop: accounts from the slip history + the Jama list. A phone: the Jama list is applied to the accounts it pulled.
  void rebuild() {
    if (host) {
      accs = buildKhata(KantaHistory.items, pays, from);
      _dirtyAccs = true;
    } else {
      // charges come from the laptop; the Jama of this phone that the laptop has not seen yet is added on top
      for (final KhataAcc a in accs) {
        a.jama = 0;
        a.dr = 0;
        a.pays.clear();
      }
      final Map<String, KhataAcc> by = <String, KhataAcc>{for (final KhataAcc a in accs) a.key: a};
      for (final KhataPay p in pays) {
        if (p.deleted) continue;
        final KhataAcc a = by.putIfAbsent(p.key, () {
          final KhataAcc n = KhataAcc(p.key, name: p.name, mobile: p.mobile);
          accs.add(n);
          return n;
        });
        a.pays.add(p);
        if (p.isCredit) {
          a.jama += p.amount;
        } else {
          a.dr += p.amount;
        }
        if (a.last == null || p.at.isAfter(a.last!)) a.last = p.at;
      }
      for (final KhataAcc a in accs) {
        a.pays.sort((KhataPay x, KhataPay y) => y.at.compareTo(x.at));
      }
      sortKhata(accs);
    }
    notifyListeners();
  }

  /// The account of a name / mobile / vehicle typed in a form (null: none, or nothing is owed).
  KhataAcc? find({String name = '', String mobile = '', String vehicle = ''}) {
    final String n = nameKey(name);
    final String m = mobile10(mobile);
    final String v = vehicleKey(vehicle);
    if (n.isNotEmpty) {
      for (final KhataAcc a in accs) {
        if (a.key == 'n:$n') return a;
      }
    }
    if (m.isNotEmpty) {
      for (final KhataAcc a in accs) {
        if (a.mobile == m) return a;
      }
      for (final KhataAcc a in accs) {
        if (a.key == 'm:$m') return a;
      }
    }
    if (n.isEmpty && v.isNotEmpty) {
      for (final KhataAcc a in accs) {
        if (a.key == 'v:$v') return a;
      }
    }
    return null;
  }

  /// What is owed by this name / mobile / vehicle (0 when nothing).
  double bakiOf({String name = '', String mobile = '', String vehicle = ''}) {
    final KhataAcc? a = find(name: name, mobile: mobile, vehicle: vehicle);
    return a == null || a.baki < 0.5 ? 0 : a.baki;
  }

  double get totalBaki {
    double t = 0;
    for (final KhataAcc a in accs) {
      if (a.baki > 0) t += a.baki;
    }
    return t;
  }

  int get owingCount => accs.where((KhataAcc a) => a.baki >= 0.5).length;

  /// Writes a Jama (money received, kind 'cr') or an opening amount (kind 'dr') on an account. Returns '' or the reason.
  Future<String> addPay({required String key, required String name, String mobile = '', required double amount, String kind = 'cr', String note = '', DateTime? at}) async {
    if (key.isEmpty) return 'key';
    if (amount <= 0) return 'amount';
    final KhataPay p = KhataPay(id: '${DateTime.now().microsecondsSinceEpoch}${(amount * 100).round()}', key: key, name: name, mobile: mobile10(mobile), kind: kind == 'dr' ? 'dr' : 'cr', amount: amount, at: at ?? DateTime.now(), note: note.trim(), by: whoAmI());
    pays = mergePays(<KhataPay>[p], pays);
    await _savePays();
    rebuild();
    unawaited(sync());
    return '';
  }

  /// Takes a Jama back (it stays in the list as deleted, so the other devices delete it too).
  Future<void> removePay(String id) async {
    for (final KhataPay p in pays) {
      if (p.id == id) p.deleted = true;
    }
    await _savePays();
    rebuild();
    unawaited(sync());
  }

  /// The accounts changed on the laptop: push them in a few seconds.
  void schedulePush() {
    _deb?.cancel();
    _deb = Timer(const Duration(seconds: 4), () => unawaited(sync()));
  }

  /// Pulls the Jama list (and, on a phone, the accounts) from the server; the laptop pushes its accounts, everybody pushes new Jama.
  Future<void> sync() async {
    if (!canSync()) return;
    if (busy) {
      // a round is running: run once more when it ends (something new may have been written meanwhile)
      _again = true;
      return;
    }
    busy = true;
    _again = false;
    try {
      final Map<String, dynamic>? row = await api.getRow();
      bool changedPays = false;
      if (row != null) {
        final Object? rp = row['recent'];
        final List<KhataPay> theirs = <KhataPay>[if (rp is List) for (final Object? e in rp) if (KhataPay.fromJson(e) != null) KhataPay.fromJson(e)!];
        final List<KhataPay> merged = mergePays(pays, theirs);
        if (_payFp(merged) != _payFp(pays)) {
          pays = merged;
          changedPays = true;
          await _savePays();
        }
        // the server lacks something that this device has: push the union
        if (_payFp(merged) != _payFp(theirs)) {
          await api.putRow(<String, dynamic>{'recent': <Object>[for (final KhataPay x in merged) x.toJson()]});
        }
        if (!host) {
          final Object? ra = row['inside'];
          if (ra is List) {
            accs = _accsFrom(ra);
            final DateTime? up = DateTime.tryParse('${row['updated_at'] ?? ''}')?.toLocal();
            remoteAt = up ?? DateTime.now();
            await _saveAccs();
            changedPays = true;
          }
        }
      } else if (pays.isNotEmpty) {
        await api.putRow(<String, dynamic>{'recent': <Object>[for (final KhataPay x in pays) x.toJson()]});
      }
      if (changedPays) rebuild();
      if (host) {
        final String json = jsonEncode(<Object>[for (final KhataAcc a in accs) a.toJson(withLines: a.baki >= 0.5)]);
        if (_dirtyAccs || json != _lastAccsSent) {
          await api.putRow(<String, dynamic>{'inside': jsonDecode(json), 'operator_name': whoAmI(), 'beat': DateTime.now().millisecondsSinceEpoch});
          _lastAccsSent = json;
          _dirtyAccs = false;
        }
      }
      error = '';
    } catch (e) {
      error = '$e';
    } finally {
      busy = false;
      notifyListeners();
    }
    if (_again) {
      _again = false;
      await sync();
    }
  }
}

final KantaKhata kantaKhata = KantaKhata();
