import 'engine.dart' show Dim;
import 'gst.dart' show gstBillTotals;
import 'insights.dart' show dayKey, directoryOf, PartySummary;
import 'live_models.dart' show dbl, nameKey, dayOf;
import 'money.dart';
import 'owner_docs.dart';
import 'trade.dart';
import 'trading.dart';

// ======================================================================
// Bank / UPI auto-match
//  - the owner pastes the bank statement (CSV / Excel copy) or the bank SMS
//  - every line is read, matched with what is already in the books (paid to a farmer,
//    money received from a buyer / mill) and, when sure, posted to the right account
//  - one shared document `flutter_bank`: { lines: [...], alias: { signature: party }, banks: [...] }
// ======================================================================

final SyncDoc bankDoc = SyncDoc('flutter_bank');

/// A line read from a statement, not saved yet.
class BankDraft {
  final DateTime date;
  final String desc;
  final double amt;
  final String dir; // dr (money out) | cr (money in)
  final String ref;
  const BankDraft(this.date, this.desc, this.amt, this.dir, this.ref);

  String get key => '${dayKey(date)}|${amt.toStringAsFixed(2)}|$dir|${ref.isNotEmpty ? ref : _short(desc)}';
}

String _short(String s) {
  final String t = s.toLowerCase().replaceAll(RegExp(r'\s+'), ' ').trim();
  return t.length > 40 ? t.substring(0, 40) : t;
}

class BankLine {
  final String id;
  final DateTime date;
  final String desc;
  final double amt;
  final String dir;
  final String ref;
  final String bank;
  final String state; // new | done | ignored
  final String kind; // pay | recv | exp | in | deal | exists | ignore
  final String link; // id of the entry it was posted to / matched with
  final String party;
  final String pkey;
  final DateTime at;
  const BankLine({
    required this.id,
    required this.date,
    required this.desc,
    required this.amt,
    required this.dir,
    required this.ref,
    required this.bank,
    required this.state,
    required this.kind,
    required this.link,
    required this.party,
    required this.pkey,
    required this.at,
  });

  bool get isDr => dir == 'dr';
  bool get isNew => state == 'new';
  String get key => BankDraft(date, desc, amt, dir, ref).key;
}

List<BankLine> bankLines() {
  final List<BankLine> out = <BankLine>[];
  for (final Map<String, dynamic> m in bankDoc.list('lines')) {
    final DateTime? d = DateTime.tryParse('${m['date'] ?? ''}');
    if (d == null) continue;
    out.add(BankLine(
      id: '${m['id'] ?? ''}',
      date: dayOf(d),
      desc: '${m['desc'] ?? ''}',
      amt: dbl(m['amt']),
      dir: '${m['dir'] ?? 'dr'}',
      ref: '${m['ref'] ?? ''}',
      bank: '${m['bank'] ?? ''}',
      state: '${m['state'] ?? 'new'}',
      kind: '${m['kind'] ?? ''}',
      link: '${m['link'] ?? ''}',
      party: '${m['party'] ?? ''}',
      pkey: '${m['pkey'] ?? ''}',
      at: DateTime.tryParse('${m['at'] ?? ''}') ?? d,
    ));
  }
  out.sort((BankLine a, BankLine b) {
    final int c = b.date.compareTo(a.date);
    return c != 0 ? c : b.at.compareTo(a.at);
  });
  return out;
}

List<String> bankNames() {
  final Object? v = bankDoc.data['banks'];
  final List<String> out = <String>[];
  if (v is List) {
    for (final Object? e in v) {
      final String s = '$e'.trim();
      if (s.isNotEmpty && !out.contains(s)) out.add(s);
    }
  }
  return out;
}

/// The drafts that are not saved yet. The same line twice in one statement is kept twice,
/// but a statement pasted again (or an overlapping one) adds nothing.
List<BankDraft> freshBankDrafts(List<BankDraft> drafts, Iterable<String> haveKeys) {
  final Map<String, int> have = <String, int>{};
  for (final String k in haveKeys) {
    have[k] = (have[k] ?? 0) + 1;
  }
  final Map<String, int> seen = <String, int>{};
  final List<BankDraft> out = <BankDraft>[];
  for (final BankDraft d in drafts) {
    final String k = d.key;
    final int c = (seen[k] ?? 0) + 1;
    seen[k] = c;
    if (c > (have[k] ?? 0)) out.add(d);
  }
  return out;
}

/// Saves new lines (the ones already saved are skipped). Returns how many were added.
Future<int> addBankLines(List<BankDraft> drafts, String bank) async {
  int added = 0;
  await bankDoc.commit(() {
    final List<Map<String, dynamic>> l = bankDoc.list('lines');
    final List<String> keys = <String>[];
    for (final Map<String, dynamic> m in l) {
      final DateTime? d = DateTime.tryParse('${m['date'] ?? ''}');
      if (d == null) continue;
      keys.add(BankDraft(dayOf(d), '${m['desc'] ?? ''}', dbl(m['amt']), '${m['dir'] ?? 'dr'}', '${m['ref'] ?? ''}').key);
    }
    final String stamp = '${DateTime.now().microsecondsSinceEpoch}';
    int n = 0;
    for (final BankDraft d in freshBankDrafts(drafts, keys)) {
      n++;
      l.add(<String, dynamic>{
        'id': '$stamp$n',
        'date': dayKey(d.date),
        'desc': d.desc,
        'amt': d.amt,
        'dir': d.dir,
        'ref': d.ref,
        'bank': bank,
        'state': 'new',
        'kind': '',
        'link': '',
        'party': '',
        'pkey': '',
        'at': DateTime.now().toIso8601String(),
      });
    }
    added = n;
    if (bank.isNotEmpty) {
      final List<String> names = bankNames();
      if (!names.contains(bank)) {
        names.add(bank);
        bankDoc.data['banks'] = names;
      }
    }
  });
  return added;
}

Future<void> patchBank(String id, Map<String, dynamic> patch) {
  return bankDoc.commit(() {
    for (final Map<String, dynamic> m in bankDoc.list('lines')) {
      if ('${m['id']}' == id) m.addAll(patch);
    }
  });
}

Future<void> removeBankLine(String id) {
  return bankDoc.commit(() {
    bankDoc.list('lines').removeWhere((Map<String, dynamic> m) => '${m['id']}' == id);
  });
}

// ----------------------------------------------------------------- parsing
const Map<String, int> _mon = <String, int>{
  'jan': 1,
  'feb': 2,
  'mar': 3,
  'apr': 4,
  'may': 5,
  'jun': 6,
  'jul': 7,
  'aug': 8,
  'sep': 9,
  'oct': 10,
  'nov': 11,
  'dec': 12,
};

DateTime? _mk(int y, int mo, int d) {
  final int yy = y < 100 ? 2000 + y : y;
  if (mo < 1 || mo > 12 || d < 1 || d > 31) return null;
  return DateTime(yy, mo, d);
}

/// 12/10/2026, 12-10-26, 12 Oct 2026, 12-Oct-26, 2026-10-12 ... (day first, as in India).
DateTime? parseBankDate(String raw) {
  final String s = raw.trim();
  if (s.isEmpty) return null;
  RegExpMatch? m = RegExp(r'(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})').firstMatch(s);
  if (m != null) return _mk(int.parse(m[1]!), int.parse(m[2]!), int.parse(m[3]!));
  m = RegExp(r'(\d{1,2})[-/. ]([A-Za-z]{3,9})[-/., ]+(\d{2,4})').firstMatch(s);
  if (m != null) {
    final int? mo = _mon[m[2]!.toLowerCase().substring(0, 3)];
    if (mo != null) return _mk(int.parse(m[3]!), mo, int.parse(m[1]!));
  }
  m = RegExp(r'(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})').firstMatch(s);
  if (m != null) return _mk(int.parse(m[3]!), int.parse(m[2]!), int.parse(m[1]!));
  return null;
}

double? _num(String s) {
  String t = s.trim().replaceAll(RegExp(r'[₹,\s]'), '');
  t = t.replaceAll(RegExp(r'(dr|cr)\.?$', caseSensitive: false), '');
  if (t.isEmpty || t == '-') return null;
  bool neg = false;
  if (t.startsWith('(') && t.endsWith(')')) {
    neg = true;
    t = t.substring(1, t.length - 1);
  }
  final double? v = double.tryParse(t);
  if (v == null) return null;
  return neg ? -v : v;
}

List<String> csvSplit(String line, String delim) {
  if (delim == '\t') return line.split('\t').map((String c) => c.trim()).toList();
  final List<String> out = <String>[];
  final StringBuffer cur = StringBuffer();
  bool q = false;
  for (int i = 0; i < line.length; i++) {
    final String ch = line[i];
    if (ch == '"') {
      if (q && i + 1 < line.length && line[i + 1] == '"') {
        cur.write('"');
        i++;
      } else {
        q = !q;
      }
    } else if (ch == delim && !q) {
      out.add(cur.toString().trim());
      cur.clear();
    } else {
      cur.write(ch);
    }
  }
  out.add(cur.toString().trim());
  return out;
}

String csvDelim(List<String> lines) {
  int tab = 0;
  int com = 0;
  int semi = 0;
  int pipe = 0;
  for (final String l in lines.take(12)) {
    tab += '\t'.allMatches(l).length;
    com += ','.allMatches(l).length;
    semi += ';'.allMatches(l).length;
    pipe += '|'.allMatches(l).length;
  }
  if (tab > 0 && tab >= com) return '\t';
  if (semi > com && semi >= pipe) return ';';
  if (pipe > com) return '|';
  return ',';
}

class _Cols {
  int date = -1;
  int desc = -1;
  int ref = -1;
  int dr = -1;
  int cr = -1;
  int amt = -1;
  int type = -1;
}

_Cols? _header(List<String> cells) {
  final _Cols c = _Cols();
  int valueDate = -1;
  for (int i = 0; i < cells.length; i++) {
    final String h = cells[i].toLowerCase().trim();
    final String h2 = h.replaceAll(RegExp(r'[\s_]+'), '');
    if (h.isEmpty) continue;
    final bool outW = h.contains('withdraw') || h.contains('debit');
    final bool inW = h.contains('deposit') || h.contains('credit');
    if (h.contains('date') || h == 'dt' || h.endsWith(' dt')) {
      if (h.contains('value')) {
        valueDate = i;
      } else if (c.date < 0) {
        c.date = i;
      }
    } else if (c.desc < 0 && (h.contains('narration') || h.contains('description') || h.contains('particular') || h.contains('remark') || h.contains('detail'))) {
      c.desc = i;
    } else if (c.ref < 0 && (h.contains('chq') || h.contains('cheque') || h.contains('ref') || h.contains('utr'))) {
      c.ref = i;
    } else if (h.contains('balance') || h == 'bal' || h == 'closing') {
      continue;
    } else if (outW && inW) {
      if (c.amt < 0) c.amt = i;
    } else if (h2.contains('dr/cr') || h2.contains('cr/dr') || h == 'type' || h.contains('txn type') || h.contains('transaction type')) {
      if (c.type < 0) c.type = i;
    } else if (c.dr < 0 && (outW || h == 'dr' || h.startsWith('dr ') || h.startsWith('dr.'))) {
      c.dr = i;
    } else if (c.cr < 0 && (inW || h == 'cr' || h.startsWith('cr ') || h.startsWith('cr.'))) {
      c.cr = i;
    } else if (c.amt < 0 && h.contains('amount')) {
      c.amt = i;
    }
  }
  if (c.date < 0) c.date = valueDate;
  if (c.date >= 0 && c.desc >= 0 && (c.dr >= 0 || c.cr >= 0 || c.amt >= 0)) return c;
  return null;
}

final RegExp _refRe = RegExp(r'(?:upi\s*ref(?:erence)?(?:\s*no)?|ref(?:erence)?\s*(?:no|number)?|utr(?:\s*no)?|rrn|txn\s*id|imps\s*ref)[\s:.\-]*([A-Za-z0-9]{8,})', caseSensitive: false);
final RegExp _longNumRe = RegExp(r'\b(\d{12,})\b');

String _refOf(String desc) {
  final RegExpMatch? m = _refRe.firstMatch(desc);
  if (m != null) return m[1]!;
  final RegExpMatch? n = _longNumRe.firstMatch(desc);
  return n == null ? '' : n[1]!;
}

BankDraft? _sms(String block, DateTime fallback) {
  final String t = block.replaceAll(RegExp(r'\s+'), ' ').trim();
  if (t.isEmpty) return null;
  final RegExpMatch? am = RegExp(r'(?:rs\.?|inr|₹)\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)', caseSensitive: false).firstMatch(t);
  if (am == null) return null;
  final double? amt = _num(am[1]!);
  if (amt == null || amt <= 0) return null;
  final String low = t.toLowerCase();
  final int di = RegExp(r'debited|withdrawn|\bsent\b|\bpaid\b|purchase|spent|transferred to|\bdr\b|\bdr\.').firstMatch(low)?.start ?? -1;
  final int ci = RegExp(r'credited|received|deposited|\bcredit\b|\bcr\b|\bcr\.').firstMatch(low)?.start ?? -1;
  String dir;
  if (di < 0 && ci < 0) {
    return null;
  } else if (di < 0) {
    dir = 'cr';
  } else if (ci < 0) {
    dir = 'dr';
  } else {
    dir = di < ci ? 'dr' : 'cr';
  }
  final DateTime d = parseBankDate(t) ?? fallback;
  return BankDraft(d, t.length > 220 ? t.substring(0, 220) : t, amt, dir, _refOf(t));
}

/// Reads a pasted statement (CSV / tab separated copy from Excel) or a set of bank SMS.
List<BankDraft> parseBankText(String text) {
  final List<String> lines = text.replaceAll('\r\n', '\n').replaceAll('\r', '\n').split('\n').where((String l) => l.trim().isNotEmpty).toList();
  if (lines.isEmpty) return <BankDraft>[];
  final String delim = csvDelim(lines);
  int h = -1;
  _Cols? cols;
  for (int i = 0; i < lines.length && i < 60; i++) {
    final _Cols? c = _header(csvSplit(lines[i], delim));
    if (c != null) {
      h = i;
      cols = c;
      break;
    }
  }
  final List<BankDraft> out = <BankDraft>[];
  if (h >= 0 && cols != null) {
    final _Cols c = cols;
    for (int i = h + 1; i < lines.length; i++) {
      final List<String> cells = csvSplit(lines[i], delim);
      String get(int k) => k >= 0 && k < cells.length ? cells[k] : '';
      final DateTime? d = parseBankDate(get(c.date));
      if (d == null) continue;
      final double? dr = c.dr >= 0 ? _num(get(c.dr)) : null;
      final double? cr = c.cr >= 0 ? _num(get(c.cr)) : null;
      double amt = 0;
      String dir = '';
      if (dr != null && dr.abs() > 0.004) {
        amt = dr.abs();
        dir = 'dr';
      } else if (cr != null && cr.abs() > 0.004) {
        amt = cr.abs();
        dir = 'cr';
      } else if (c.amt >= 0) {
        final double? a = _num(get(c.amt));
        if (a == null || a == 0) continue;
        final String t = (c.type >= 0 ? get(c.type) : get(c.amt)).toLowerCase();
        if (t.contains('cr')) {
          dir = 'cr';
        } else if (t.contains('dr')) {
          dir = 'dr';
        } else {
          dir = a < 0 ? 'dr' : 'cr';
        }
        amt = a.abs();
      } else {
        continue;
      }
      final String desc = get(c.desc).replaceAll(RegExp(r'\s+'), ' ').trim();
      String ref = c.ref >= 0 ? get(c.ref).trim() : '';
      if (ref.isEmpty || RegExp(r'^0+$').hasMatch(ref)) ref = _refOf(desc);
      out.add(BankDraft(d, desc, amt, dir, ref));
    }
    return out;
  }
  // free text: bank SMS, one per paragraph (or one per line)
  List<String> blocks = text.replaceAll('\r\n', '\n').split(RegExp(r'\n\s*\n')).map((String b) => b.trim()).where((String b) => b.isNotEmpty).toList();
  if (blocks.length == 1 && lines.length > 1) blocks = lines;
  final DateTime today = dayOf(DateTime.now());
  for (final String b in blocks) {
    final BankDraft? d = _sms(b, today);
    if (d != null) out.add(d);
  }
  return out;
}

// --------------------------------------------------------------- matching
class PartyOpt {
  final String key;
  final String label;
  final String type; // farmer | buyer | mill
  PartyOpt(this.key, this.label, this.type);

  late final List<String> toks = bankTokens(label);
}

class BankMatch {
  final String kind; // exists | pay | recv | exp | deal
  final String partyKey;
  final String partyLabel;
  final String partyType;
  final String linkId; // for exists: the entry already in the books
  final String linkKind; // pay | recv | exp | deal (what the existing entry is)
  final bool sure;
  final String why;
  final List<PartyOpt> options;
  const BankMatch(this.kind, {this.partyKey = '', this.partyLabel = '', this.partyType = '', this.linkId = '', this.linkKind = '', this.sure = false, this.why = '', this.options = const <PartyOpt>[]});

  bool get hasParty => partyKey.isNotEmpty;

  BankMatch unsure() => BankMatch(kind, partyKey: partyKey, partyLabel: partyLabel, partyType: partyType, linkId: linkId, linkKind: linkKind, why: why, options: options);
}

final Set<String> _stop = <String>{
  'upi', 'neft', 'imps', 'rtgs', 'payment', 'from', 'phone', 'to', 'by', 'bank', 'transfer', 'trf', 'ref', 'paid', 'via', 'ltd', 'pvt', 'the', 'and', 'for', 'dr', 'cr', 'debited', 'credited', 'account', 'acct', 'vpa', 'cash', 'chq', 'cheque', 'hdfc', 'sbi', 'icici', 'axis', 'kotak', 'bob', 'pnb', 'idfc', 'yes', 'sbin', 'okaxis', 'oksbi', 'okhdfcbank', 'okicici', 'ybl', 'paytm', 'gpay', 'phonepe', 'amazon', 'info', 'inr', 'rs', 'txn', 'mob', 'sent', 'received', 'dear', 'customer', 'your', 'with', 'avl', 'bal', 'available', 'balance', 'xxxx', 'online', 'mobile', 'banking', 'p2a', 'p2m', 'utr', 'rrn',
};

/// Words of a bank narration that can be a part of a name.
List<String> bankTokens(String s) {
  final String t = s.toLowerCase().replaceAll(RegExp(r'[^a-z0-9઀-૿]+'), ' ');
  final List<String> out = <String>[];
  for (final String w in t.split(' ')) {
    if (w.length < 3 || _stop.contains(w) || RegExp(r'^[0-9]+$').hasMatch(w)) continue;
    out.add(w);
  }
  return out;
}

/// Same party seen again: a UPI id when there is one, otherwise the first words of the narration.
String bankSig(String desc) {
  final RegExpMatch? v = RegExp(r'[a-z0-9._\-]{2,}@[a-z]{2,}', caseSensitive: false).firstMatch(desc);
  if (v != null) return 'vpa:${v[0]!.toLowerCase()}';
  final List<String> t = bankTokens(desc);
  if (t.isEmpty) return '';
  return 'nm:${t.take(3).join(' ')}';
}

int _hits(List<String> party, Set<String> desc) {
  int n = 0;
  for (final String x in party) {
    if (desc.contains(x)) {
      n++;
      continue;
    }
    for (final String y in desc) {
      if (x.length >= 5 && y.length >= 5 && (y.startsWith(x) || x.startsWith(y))) {
        n++;
        break;
      }
    }
  }
  return n;
}

class _Cand {
  final PartyOpt opt;
  final int hits;
  final int len;
  const _Cand(this.opt, this.hits, this.len);
}

/// Everything the matcher looks at, read once per screen build.
class BankCtx {
  final List<PayItem> pays;
  final List<SaleItem> sales;
  final List<ExpItem> exps;
  final List<MillDeal> deals;
  final Set<String> used; // ids already taken by a bank line
  final List<PartyOpt> farmers;
  final List<PartyOpt> buyers;
  final Map<String, dynamic> alias;
  final Map<String, double> bills;
  BankCtx(this.pays, this.sales, this.exps, this.deals, this.used, this.farmers, this.buyers, this.alias, this.bills);

  PartyOpt? farmerByKey(String k) {
    for (final PartyOpt p in farmers) {
      if (p.key == k) return p;
    }
    return null;
  }

  PartyOpt? buyerByKey(String k) {
    for (final PartyOpt p in buyers) {
      if (p.key == k) return p;
    }
    return null;
  }

  /// Open trucks of a mill (money still to be received), newest first.
  List<MillDeal> openDealsOf(String millKey) {
    final List<MillDeal> out = <MillDeal>[];
    for (final MillDeal d in deals) {
      if (nameKey(d.mill) != millKey) continue;
      final DealCalc c = calcDeal(d, billTotal: d.billed ? bills[d.billNo.trim()] : null);
      if (c.due > 0.5 && (c.hasSell || c.receivable > 0)) out.add(d);
    }
    return out;
  }
}

BankCtx buildBankCtx(List<BankLine> lines) {
  final Set<String> used = <String>{};
  for (final BankLine l in lines) {
    if (l.state == 'done' && l.link.isNotEmpty) used.add(l.link);
  }
  final Map<String, PartyOpt> f = <String, PartyOpt>{};
  for (final PartySummary s in directoryOf(Dim.farmer)) {
    f[s.ref.key] = PartyOpt(s.ref.key, s.ref.label, 'farmer');
  }
  for (final FarmerAcct a in farmerAccts().values) {
    f.putIfAbsent(a.key, () => PartyOpt(a.key, a.label, 'farmer'));
  }
  final List<MillDeal> deals = millDeals();
  final Map<String, PartyOpt> b = <String, PartyOpt>{};
  for (final BuyerAcct a in buyerAccts().values) {
    b[a.key] = PartyOpt(a.key, a.label, 'buyer');
  }
  for (final MillDeal d in deals) {
    final String k = nameKey(d.mill);
    if (k.isNotEmpty) b.putIfAbsent(k, () => PartyOpt(k, d.mill, 'mill'));
  }
  final Object? al = bankDoc.data['alias'];
  return BankCtx(payItems(), saleItems(), expItems(), deals, used, f.values.toList(), b.values.toList(), al is Map ? Map<String, dynamic>.from(al) : <String, dynamic>{}, gstBillTotals());
}

int _dd(DateTime a, DateTime b) => a.difference(b).inDays.abs();

bool _chargeLike(String desc) => RegExp(r'charge|chrg|sms alert|service fee|gst on|min bal|maint|annual fee|folio', caseSensitive: false).hasMatch(desc);

/// Looks for the same money in the books, then for the party named in the narration.
BankMatch matchBankLine(BankLine l, BankCtx x) {
  if (l.isDr) {
    PayItem? best;
    for (final PayItem p in x.pays) {
      if (p.kind != 'pay' && p.kind != 'adv') continue;
      if (p.mode == 'cash' || x.used.contains(p.id)) continue;
      if ((p.amt - l.amt).abs() >= 0.5 || _dd(p.date, l.date) > 3) continue;
      if (best == null || _dd(p.date, l.date) < _dd(best.date, l.date)) best = p;
    }
    if (best != null) {
      return BankMatch('exists', partyKey: best.key, partyLabel: best.label, partyType: 'farmer', linkId: best.id, linkKind: 'pay', sure: true, why: best.label);
    }
    for (final ExpItem e in x.exps) {
      if (e.isIn || e.mode == 'cash' || x.used.contains(e.id)) continue;
      if ((e.amt - l.amt).abs() < 0.5 && _dd(e.date, l.date) <= 3) {
        return BankMatch('exists', partyLabel: e.note.isEmpty ? e.cat : e.note, linkId: e.id, linkKind: 'exp', sure: true, why: e.cat);
      }
    }
    if (_chargeLike(l.desc) && l.amt < 2000) return const BankMatch('exp', why: 'bank charges', sure: true);
    return _byName(l, x.farmers, x.alias, 'pay');
  }
  for (final SaleItem s in x.sales) {
    if (s.kind != 'recv' || s.mode == 'cash' || x.used.contains(s.id)) continue;
    if ((s.amt - l.amt).abs() < 0.5 && _dd(s.date, l.date) <= 3) {
      return BankMatch('exists', partyKey: s.key, partyLabel: s.buyer, partyType: 'buyer', linkId: s.id, linkKind: 'recv', sure: true, why: s.buyer);
    }
  }
  for (final MillDeal d in x.deals) {
    for (final DealRecv r in d.recv) {
      if (r.mode == 'cash' || x.used.contains(r.id)) continue;
      if ((r.amt - l.amt).abs() < 0.5 && _dd(r.date, l.date) <= 3) {
        return BankMatch('exists', partyKey: d.id, partyLabel: d.mill, partyType: 'mill', linkId: r.id, linkKind: 'deal', sure: true, why: d.mill);
      }
    }
  }
  final BankMatch m = _byName(l, x.buyers, x.alias, 'recv');
  if (m.hasParty && m.partyType == 'mill') {
    // a mill whose truck is waiting for this much money
    final List<MillDeal> open = x.openDealsOf(m.partyKey);
    MillDeal? exact;
    for (final MillDeal d in open) {
      final DealCalc c = calcDeal(d, billTotal: d.billed ? x.bills[d.billNo.trim()] : null);
      if ((c.due - l.amt).abs() < 1) {
        exact = d;
        break;
      }
    }
    if (exact != null) return BankMatch('deal', partyKey: exact.id, partyLabel: exact.mill, partyType: 'mill', sure: m.sure, why: '${exact.vehicle} · ${m.why}', options: m.options);
    if (open.isNotEmpty) return BankMatch('deal', partyKey: open.last.id, partyLabel: open.last.mill, partyType: 'mill', why: open.last.vehicle, options: m.options);
    return m.unsure();
  }
  return m;
}

BankMatch _byName(BankLine l, List<PartyOpt> parties, Map<String, dynamic> alias, String kind) {
  final String sig = bankSig(l.desc);
  if (sig.isNotEmpty && alias[sig] is Map) {
    final Map<dynamic, dynamic> a = alias[sig] as Map<dynamic, dynamic>;
    final String k = '${a['key'] ?? ''}';
    for (final PartyOpt p in parties) {
      if (p.key == k) return BankMatch(kind, partyKey: p.key, partyLabel: p.label, partyType: p.type, sure: true, why: 'learned');
    }
  }
  final Set<String> ds = bankTokens(l.desc).toSet();
  final List<_Cand> cands = <_Cand>[];
  for (final PartyOpt p in parties) {
    if (p.toks.isEmpty) continue;
    final int h = _hits(p.toks, ds);
    if (h > 0) cands.add(_Cand(p, h, p.toks.length));
  }
  if (cands.isEmpty) return BankMatch(kind);
  cands.sort((_Cand a, _Cand b) {
    final int c = b.hits.compareTo(a.hits);
    return c != 0 ? c : (b.hits / b.len).compareTo(a.hits / a.len);
  });
  final _Cand top = cands.first;
  final bool alone = cands.length == 1 || cands[1].hits < top.hits;
  final bool all = top.hits == top.len;
  final bool sure = alone && all && (top.hits >= 2 || top.opt.toks.first.length >= 6);
  return BankMatch(kind, partyKey: top.opt.key, partyLabel: top.opt.label, partyType: top.opt.type, sure: sure, why: top.opt.toks.join(' '), options: <PartyOpt>[for (final _Cand c in cands.take(5)) c.opt]);
}

/// Matches every line still to be checked. The oldest line takes an entry of the books first,
/// so two equal payments are not both linked to one entry.
Map<String, BankMatch> matchAllBank(List<BankLine> lines, BankCtx x) {
  final Map<String, BankMatch> out = <String, BankMatch>{};
  final List<BankLine> l = lines.where((BankLine e) => e.isNew).toList()..sort((BankLine a, BankLine b) => a.date.compareTo(b.date));
  for (final BankLine b in l) {
    final BankMatch m = matchBankLine(b, x);
    if (m.kind == 'exists' && m.linkId.isNotEmpty) x.used.add(m.linkId);
    out[b.id] = m;
  }
  return out;
}

// ----------------------------------------------------------------- posting
String _mode(BankLine l) {
  final String d = l.desc.toLowerCase();
  if (d.contains('upi') || d.contains('@')) return 'upi';
  if (d.contains('chq') || d.contains('cheque')) return 'cheque';
  return 'bank';
}

String _note(BankLine l) => 'Bank${l.ref.isEmpty ? '' : ' ${l.ref}'}';

/// One thing to do with one bank line.
class BankPost {
  final BankLine line;
  final String kind; // pay | adv | recv | deal | exp | exists
  final PartyOpt? party; // pay / adv / recv
  final String dealId; // deal
  final String label; // deal: mill name, exp: category, exists: party
  final String cat; // exp
  final String note; // exp
  final String linkId; // exists
  final String linkKind; // exists
  const BankPost(this.line, this.kind, {this.party, this.dealId = '', this.label = '', this.cat = 'other', this.note = '', this.linkId = '', this.linkKind = ''});
}

/// The posting that a match suggests (null when the match names no one).
BankPost? bankSuggestPost(BankLine l, BankMatch m) {
  if (m.kind == 'exists') return BankPost(l, 'exists', label: m.partyLabel, linkId: m.linkId, linkKind: m.linkKind);
  if (m.kind == 'exp') return BankPost(l, 'exp', cat: 'other', note: 'Bank charges ${_note(l)}');
  if (!m.hasParty) return null;
  if (m.kind == 'pay') return BankPost(l, 'pay', party: PartyOpt(m.partyKey, m.partyLabel, 'farmer'));
  if (m.kind == 'deal') return BankPost(l, 'deal', dealId: m.partyKey, label: m.partyLabel);
  if (m.kind == 'recv' && m.partyType != 'mill') return BankPost(l, 'recv', party: PartyOpt(m.partyKey, m.partyLabel, 'buyer'));
  return null;
}

/// The posting for a sure match (null when the line needs a look by the owner).
BankPost? bankAutoPost(BankLine l, BankMatch m) => m.sure ? bankSuggestPost(l, m) : null;

/// Writes all the postings: one save for each book (not one for each line).
Future<void> bankPostAll(List<BankPost> posts) async {
  if (posts.isEmpty) return;
  final String stamp = '${DateTime.now().microsecondsSinceEpoch}';
  final String nowIso = DateTime.now().toIso8601String();
  final Map<String, String> ids = <String, String>{};
  int n = 0;
  for (final BankPost p in posts) {
    n++;
    ids[p.line.id] = '$stamp$n';
  }
  final List<BankPost> pays = posts.where((BankPost p) => p.kind == 'pay' || p.kind == 'adv').toList();
  if (pays.isNotEmpty) {
    await payDoc.commit(() {
      final List<Map<String, dynamic>> l = payDoc.list('items');
      for (final BankPost p in pays) {
        final PartyOpt? q = p.party;
        if (q == null) continue;
        l.add(<String, dynamic>{'id': ids[p.line.id], 'key': q.key, 'label': q.label, 'date': dayKey(p.line.date), 'amt': p.line.amt, 'kind': p.kind, 'mode': _mode(p.line), 'note': _note(p.line), 'at': nowIso});
      }
    });
  }
  final List<BankPost> recvs = posts.where((BankPost p) => p.kind == 'recv').toList();
  if (recvs.isNotEmpty) {
    await saleDoc.commit(() {
      final List<Map<String, dynamic>> l = saleDoc.list('items');
      for (final BankPost p in recvs) {
        final PartyOpt? q = p.party;
        if (q == null) continue;
        l.add(<String, dynamic>{'id': ids[p.line.id], 'date': dayKey(p.line.date), 'buyer': q.label, 'key': q.key, 'kind': 'recv', 'src': '', 'item': '', 'kg': 0, 'bags': 0, 'rate': 0, 'amt': p.line.amt, 'vehicle': '', 'bill': '', 'mode': _mode(p.line), 'note': _note(p.line), 'at': nowIso});
      }
    });
  }
  final List<BankPost> exps = posts.where((BankPost p) => p.kind == 'exp').toList();
  if (exps.isNotEmpty) {
    await expDoc.commit(() {
      final List<Map<String, dynamic>> l = expDoc.list('items');
      for (final BankPost p in exps) {
        l.add(<String, dynamic>{'id': ids[p.line.id], 'date': dayKey(p.line.date), 'amt': p.line.amt, 'cat': p.cat, 'note': p.note.isEmpty ? _note(p.line) : p.note, 'kind': p.line.isDr ? 'out' : 'in', 'mode': _mode(p.line), 'at': nowIso});
      }
    });
  }
  final List<BankPost> deals = posts.where((BankPost p) => p.kind == 'deal').toList();
  if (deals.isNotEmpty) {
    await tradeDoc.commit(() {
      for (final Map<String, dynamic> m in tradeDoc.list('items')) {
        for (final BankPost p in deals) {
          if ('${m['id']}' != p.dealId) continue;
          final Object? raw = m['recv'];
          final List<Object?> r = raw is List ? List<Object?>.from(raw) : <Object?>[];
          r.add(<String, dynamic>{'id': ids[p.line.id], 'date': dayKey(p.line.date), 'amt': p.line.amt, 'mode': _mode(p.line), 'note': _note(p.line)});
          m['recv'] = r;
        }
      }
    });
  }
  await bankDoc.commit(() {
    final Map<String, dynamic> alias = bankDoc.map('alias');
    for (final Map<String, dynamic> m in bankDoc.list('lines')) {
      BankPost? hit;
      for (final BankPost x in posts) {
        if (x.line.id == '${m['id']}') hit = x;
      }
      if (hit == null) continue;
      final BankPost p = hit;
      m['state'] = 'done';
      if (p.kind == 'exists') {
        m['kind'] = 'exists';
        m['link'] = p.linkId;
        m['party'] = p.label;
        m['pkey'] = p.linkKind;
        continue;
      }
      m['link'] = ids[p.line.id];
      if (p.kind == 'pay' || p.kind == 'adv') {
        m['kind'] = 'pay';
        m['party'] = p.party?.label ?? '';
        m['pkey'] = p.party?.key ?? '';
      } else if (p.kind == 'recv') {
        m['kind'] = 'recv';
        m['party'] = p.party?.label ?? '';
        m['pkey'] = p.party?.key ?? '';
      } else if (p.kind == 'deal') {
        m['kind'] = 'deal';
        m['party'] = p.label;
        m['pkey'] = p.dealId;
      } else {
        m['kind'] = p.line.isDr ? 'exp' : 'in';
        m['party'] = p.cat;
        m['pkey'] = '';
      }
      final String sig = bankSig(p.line.desc);
      final PartyOpt? q = p.kind == 'deal' ? PartyOpt(nameKey(p.label), p.label, 'mill') : p.party;
      if (sig.isNotEmpty && q != null) alias[sig] = <String, dynamic>{'t': q.type, 'key': q.key, 'label': q.label};
    }
  });
}

Future<void> bankIgnore(BankLine l) => patchBank(l.id, <String, dynamic>{'state': 'ignored', 'kind': 'ignore', 'link': '', 'party': '', 'pkey': ''});

/// Back to "to check" (an ignored line).
Future<void> bankRestore(BankLine l) => patchBank(l.id, <String, dynamic>{'state': 'new', 'kind': '', 'link': '', 'party': '', 'pkey': ''});

/// Takes back a posting (removes what was added) and puts the line back to "to check".
Future<void> bankUndo(BankLine l) async {
  if (l.kind == 'pay') {
    await removePayItem(l.link);
  } else if (l.kind == 'recv') {
    await removeSale(l.link);
  } else if (l.kind == 'exp' || l.kind == 'in') {
    await removeExpItem(l.link);
  } else if (l.kind == 'deal') {
    await removeDealRecv(l.pkey, l.link);
  }
  await bankRestore(l);
}
