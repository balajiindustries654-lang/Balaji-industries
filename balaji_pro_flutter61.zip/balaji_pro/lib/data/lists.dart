/// Fixed pick-lists copied from the web app so values stay identical.
const List<String> kBrokers = <String>[
  'Nitin Gandhi Mandvi',
  'Chintan Chhaya Trader',
  'Satara',
  'Bhavesh Ramjiyani',
  'Jignesh Pokar'
];

const List<String> kVillages = <String>[
  'માંડવી (Mandvi)',
  'અબડા (Abada)',
  'અસંબિયા મોટા (Asambiya Mota)',
  'અસંબિયા નાના (Asambiya Nana)',
  'આણંદપર (Anandpar)',
  'ઉમરાપર (Umarapar)',
  'ગોડસરા (Godsara)',
  'ગઢસીસા (Gadhsisa)',
  'ગાંધવી (Gandhvi)',
  'ગોધરા (Godhra)',
  'ગુણોદા (Gunoda)',
  'ગોકુલપર (Gokulpar)',
  'ચાસરા (Chasra)',
  'તોફિયા (Tofiya)',
  'તલવાણા (Talvana)',
  'નાગલપર મોટી (Nagalpar Moti)',
  'નાગલપર નાની (Nagalpar Nani)',
  'નાગરેચા (Nagarecha)',
  'નાની રાયણ (Nani Rayan)',
  'મોટી રાયણ (Moti Rayan)',
  'પોરિસરા (Porisara)',
  'પિપરિ (Pipari)',
  'બિદડા (Bidada)',
  'બાયઠ (Bayath)',
  'બગડા (Bagda)',
  'ભાડા (Bhada)',
  'ભોજાય (Bhojay)',
  'ભાડિયા (Bhadiya)',
  'ભારાપર (Bharapar)',
  'મસ્કા (Maska)',
  'માંડવી ગામ (Mandvi Gam)',
  'માંજલ (Manjal)',
  'મોડકુબા (Modkuba)',
  'મોટી મઉ (Moti Mau)',
  'નાની મઉ (Nani Mau)',
  'મોટી ખાખર (Moti Khakhar)',
  'નાની ખાખર (Nani Khakhar)',
  'રતેડિયા (Ratediya)',
  'રતનપર (Ratanpar)',
  'રાપર ગઢવાળી (Rapar Gadhvali)',
  'રામપર વેકરા (Rampar Vekra)',
  'રૂકમાવતી (Rukmavati)',
  'લાયજા મોટા (Layja Mota)',
  'લાયજા નાના (Layja Nana)',
  'લુડવા (Ludva)',
  'લુહારપર (Luharpar)',
  'વિજયાસર (Vijayasar)',
  'વિંઝાણ (Vinzan)',
  'વેકરા (Vekra)',
  'શિરાચા (Shiracha)',
  'શીવા (Shirva)',
  'સાભરાઈ (Sabharai)',
  'શેરડી (Sherdi)',
  'હેડતા (Hedta)'
];

const List<String> kVehicles = <String>[
  'GJ12CT5828',
  'GJ12CT7996',
  'GJ12CV6533',
  'GJ12CT6533',
  'GJ03W8824',
  'GJ13V6515',
  'GJ08AU0854',
  'GJ12AT6598',
  'GJ12BX4089',
  'GJ09AV6063'
];

/// Dana (kernel size / grade) of a maal entry: value stored in the database, Gujarati label, English label
const List<List<String>> kDana = <List<String>>[
  <String>['50-60', '50-60', '50-60'],
  <String>['60-70', '60-70', '60-70'],
  <String>['70-80', '70-80', '70-80'],
  <String>['80-90', '80-90', '80-90'],
  <String>['90-100', '90-100', '90-100'],
  <String>['Fadiya', 'ફાડિયા', 'Fadiya (split)'],
  <String>['Damage', 'ડેમેજ', 'Damage'],
];

/// Label of a stored dana value (unknown values are shown as they are).
String danaLabel(String v, {bool gu = true}) {
  for (final List<String> d in kDana) {
    if (d[0] == v) return gu ? d[1] : d[2];
  }
  return v;
}

/// value stored in the database, Gujarati label, English label
const List<List<String>> kCommodities = <List<String>>[
  <String>['Magfadi', 'મગફળી', 'Groundnut'],
  <String>['Aeranda', 'એરંડા', 'Castor'],
  <String>['Gau', 'ઘઉં', 'Wheat'],
  <String>['Govar', 'ગવાર', 'Guar'],
  <String>['Other', 'બીજું', 'Other'],
];
