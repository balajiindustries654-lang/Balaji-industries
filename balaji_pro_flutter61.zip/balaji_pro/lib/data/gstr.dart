import '../core/i18n.dart';
import 'gst.dart';
import 'insights.dart';

// ======================================================================
// GSTR-1 (outward supplies) summary, worked out from the GST bills of `flutter_gst`
//   Table 4  B2B invoices (receiver has a GSTIN)
//   Table 5  B2C (Large): inter-state, no GSTIN, invoice value above the limit
//   Table 7  B2C (Small): everything else to buyers without a GSTIN - place of supply and rate wise
//   Table 8  Nil rated, exempted (bill of supply and 0% lines)
//   Table 12 HSN summary
//   Table 13 Documents issued
//   Credit / debit notes (9B) and advances (11) are not kept in the app yet.
// The numbers are a working summary for the owner and the CA - the return itself is filed on the GST portal.
// ======================================================================

/// Inter-state B2C invoices above this value are reported invoice-wise (B2C Large). Confirm the limit with the CA.
const double kB2clLimit = 100000;

/// One invoice inside one table of the return.
class GrInv {
  final GstInv inv;
  double taxable = 0;
  double igst = 0;
  double cgst = 0;
  double sgst = 0;
  double value = 0;
  final Set<double> rates = <double>{};
  GrInv(this.inv);

  double get tax => igst + cgst + sgst;
}

/// B2C (Small): one line per place of supply and rate.
class GrPos {
  final String place;
  final double rate;
  double taxable = 0;
  double igst = 0;
  double cgst = 0;
  double sgst = 0;
  final Set<String> ids = <String>{};
  GrPos(this.place, this.rate);

  double get tax => igst + cgst + sgst;
}

/// Table 8: A inter-state to registered, B intra-state to registered, C inter-state to unregistered, D intra-state to unregistered.
class GrNil {
  final String code;
  final String name;
  double nil = 0; // 0% lines of tax invoices
  double exempt = 0; // bills of supply
  final Set<String> ids = <String>{};
  GrNil(this.code, this.name);

  double get total => nil + exempt;
}

class GrHsn {
  final String hsn;
  final String unit;
  final double rate;
  String desc;
  double qty = 0;
  double taxable = 0;
  double igst = 0;
  double cgst = 0;
  double sgst = 0;
  GrHsn(this.hsn, this.unit, this.rate, this.desc);

  double get tax => igst + cgst + sgst;
  double get value => taxable + tax;
}

class GrDocs {
  final String firm;
  final String fy;
  String from = '';
  String to = '';
  int total = 0;
  int cancelled = 0;
  GrDocs(this.firm, this.fy);

  int get net => total - cancelled;
}

/// Totals of one table.
class GrTot {
  int vouchers = 0;
  double taxable = 0;
  double igst = 0;
  double cgst = 0;
  double sgst = 0;
  double value = 0;
  double get tax => igst + cgst + sgst;
}

class Gstr1 {
  final Period period;
  final List<GrInv> b2b;
  final List<GrInv> b2cl;
  final List<GrPos> b2cs;
  final List<GrNil> nil;
  final List<GrHsn> hsn;
  final List<GrDocs> docs;
  final List<String> warnings;
  final int b2csVouchers;
  final double b2csValue;
  final int bills; // bills that are not cancelled
  const Gstr1(this.period, this.b2b, this.b2cl, this.b2cs, this.nil, this.hsn, this.docs, this.warnings, this.b2csVouchers, this.b2csValue, this.bills);

  GrTot get tB2b => _invTot(b2b);

  GrTot get tB2cl => _invTot(b2cl);

  GrTot get tB2cs {
    final GrTot t = GrTot()
      ..vouchers = b2csVouchers
      ..value = b2csValue;
    for (final GrPos p in b2cs) {
      t.taxable += p.taxable;
      t.igst += p.igst;
      t.cgst += p.cgst;
      t.sgst += p.sgst;
    }
    return t;
  }

  GrTot get tNil {
    final GrTot t = GrTot();
    final Set<String> ids = <String>{};
    for (final GrNil n in nil) {
      t.taxable += n.total;
      t.value += n.total;
      ids.addAll(n.ids);
    }
    t.vouchers = ids.length;
    return t;
  }

  GrTot get tHsn {
    final GrTot t = GrTot();
    for (final GrHsn h in hsn) {
      t.taxable += h.taxable;
      t.igst += h.igst;
      t.cgst += h.cgst;
      t.sgst += h.sgst;
      t.value += h.value;
    }
    return t;
  }

  /// Tax payable on the outward supplies of tables 4, 5 and 7.
  GrTot get tTax {
    final GrTot a = tB2b;
    final GrTot b = tB2cl;
    final GrTot c = tB2cs;
    final GrTot t = GrTot();
    t.vouchers = a.vouchers + b.vouchers + c.vouchers;
    t.taxable = a.taxable + b.taxable + c.taxable;
    t.igst = a.igst + b.igst + c.igst;
    t.cgst = a.cgst + b.cgst + c.cgst;
    t.sgst = a.sgst + b.sgst + c.sgst;
    t.value = a.value + b.value + c.value;
    return t;
  }

  static GrTot _invTot(List<GrInv> l) {
    final GrTot t = GrTot()..vouchers = l.length;
    for (final GrInv g in l) {
      t.taxable += g.taxable;
      t.igst += g.igst;
      t.cgst += g.cgst;
      t.sgst += g.sgst;
      t.value += g.value;
    }
    return t;
  }
}

/// UQC text of the unit a line is written in.
String gstUqc(String unit) {
  switch (unit.toUpperCase()) {
    case 'KG':
    case 'KGS':
      return 'KGS-KILOGRAMS';
    case 'QTL':
      return 'QTL-QUINTAL';
    case 'NOS':
    case 'NO':
      return 'NOS-NUMBERS';
    case 'MT':
      return 'MTS-METRIC TON';
  }
  return unit.toUpperCase();
}

Gstr1 gstr1(Period p, {String firm = ''}) {
  final List<GstInv> all = gstInvoices().where((GstInv i) => p.has(i.date) && (firm.isEmpty || i.firm == firm)).toList();
  all.sort((GstInv a, GstInv b) {
    final int c = a.date.compareTo(b.date);
    return c != 0 ? c : a.at.compareTo(b.at);
  });

  final List<GrInv> b2b = <GrInv>[];
  final List<GrInv> b2cl = <GrInv>[];
  final Map<String, GrPos> pos = <String, GrPos>{};
  final Set<String> posIds = <String>{};
  double posValue = 0;
  final Map<String, GrNil> nil = <String, GrNil>{
    'A': GrNil('8A', bi('આંતર-રાજ્ય · GSTIN વાળા ખરીદનારને', 'Inter-State supplies to registered persons')),
    'B': GrNil('8B', bi('રાજ્યની અંદર · GSTIN વાળા ખરીદનારને', 'Intra-State supplies to registered persons')),
    'C': GrNil('8C', bi('આંતર-રાજ્ય · GSTIN વગરના ખરીદનારને', 'Inter-State supplies to unregistered persons')),
    'D': GrNil('8D', bi('રાજ્યની અંદર · GSTIN વગરના ખરીદનારને', 'Intra-State supplies to unregistered persons')),
  };
  final Map<String, GrHsn> hsn = <String, GrHsn>{};
  final Map<String, GrDocs> docs = <String, GrDocs>{};
  final List<String> warn = <String>[];
  int bills = 0;

  // firms that have no GSTIN
  final Set<String> seenFirm = <String>{};
  for (final GstInv i in all) {
    if (!seenFirm.add(i.firm)) continue;
    final GstFirm f = gstFirmOf(i.firm);
    if (!f.ready) warn.add('${f.name}: ${bi('પેઢીનો GSTIN ભર્યો નથી', 'the GSTIN of the firm is not entered')}');
  }

  for (final GstInv i in all) {
    final String fy = gstFy(i.date);
    final GrDocs d = docs.putIfAbsent('${i.firm}|$fy', () => GrDocs(gstFirmOf(i.firm).name, fy));
    if (d.from.isEmpty) d.from = i.no;
    d.to = i.no;
    d.total++;
    if (i.cancelled) {
      d.cancelled++;
      continue;
    }
    bills++;

    final GstCalc c = i.calc;
    final bool reg = i.b2b;
    final String firmState = gstFirmOf(i.firm).state;
    final String place = i.place.isNotEmpty ? i.place : (i.state.isNotEmpty ? i.state : firmState);

    // checks
    if (i.isTax) {
      if (reg && !gstinOk(i.gstin)) warn.add('${i.no}: ${bi('ખરીદનારનો GSTIN ખોટો લાગે છે', 'the buyer GSTIN looks wrong')} (${gstinClean(i.gstin)})');
      if (i.place.isEmpty) warn.add('${i.no}: ${bi('પ્લેસ ઑફ સપ્લાય ભર્યું નથી', 'place of supply is not entered')}');
      if (i.place.isNotEmpty && ((i.place != firmState) != i.inter)) {
        warn.add('${i.no}: ${bi('પ્લેસ ઑફ સપ્લાય અને IGST / CGST+SGST મેળ ખાતા નથી', 'place of supply does not match IGST / CGST+SGST')}');
      }
      for (final GstLine l in i.lines) {
        if (l.hsn.trim().isEmpty) {
          warn.add('${i.no}: ${bi('HSN ભર્યો નથી', 'HSN is missing')} (${l.desc})');
          break;
        }
      }
    }

    // HSN summary (every bill that is not cancelled)
    for (final GstLine l in i.lines) {
      final double a = l.amount;
      double cg = 0;
      double sg = 0;
      double ig = 0;
      final double rate = i.isTax ? l.gst : 0;
      if (i.isTax && l.gst > 0) {
        if (i.inter) {
          ig = r2(a * l.gst / 100);
        } else {
          cg = r2(a * l.gst / 200);
          sg = cg;
        }
      }
      final GrHsn h = hsn.putIfAbsent('${l.hsn}|${l.unit.toUpperCase()}|$rate', () => GrHsn(l.hsn, l.unit, rate, l.desc));
      h.qty += l.qty;
      h.taxable += a;
      h.igst += ig;
      h.cgst += cg;
      h.sgst += sg;
    }

    // tables 4, 5, 7 take the lines that carry tax, table 8 the rest
    double nilAmt = 0;
    double taxable = 0;
    double igst = 0;
    double cgst = 0;
    double sgst = 0;
    final Set<double> rates = <double>{};
    final Map<double, List<double>> byRate = <double, List<double>>{};
    for (final GstHsnRow r in c.hsn) {
      if (!i.isTax || r.rate <= 0) {
        nilAmt += r.taxable;
        continue;
      }
      taxable += r.taxable;
      igst += r.igst;
      cgst += r.cgst;
      sgst += r.sgst;
      rates.add(r.rate);
      final List<double> br = byRate.putIfAbsent(r.rate, () => <double>[0, 0, 0, 0]);
      br[0] += r.taxable;
      br[1] += r.igst;
      br[2] += r.cgst;
      br[3] += r.sgst;
    }

    if (nilAmt.abs() >= 0.005) {
      final GrNil n = nil[reg ? (i.inter ? 'A' : 'B') : (i.inter ? 'C' : 'D')]!;
      if (i.isTax) {
        n.nil += nilAmt;
      } else {
        n.exempt += nilAmt;
      }
      n.ids.add(i.id);
    }

    if (taxable.abs() < 0.005) continue;
    final bool whole = nilAmt.abs() < 0.005;
    final double value = r2(taxable + igst + cgst + sgst + (whole ? c.round : 0));
    if (reg) {
      final GrInv g = GrInv(i)
        ..taxable = r2(taxable)
        ..igst = r2(igst)
        ..cgst = r2(cgst)
        ..sgst = r2(sgst)
        ..value = value;
      g.rates.addAll(rates);
      b2b.add(g);
    } else if (i.inter && c.total > kB2clLimit) {
      final GrInv g = GrInv(i)
        ..taxable = r2(taxable)
        ..igst = r2(igst)
        ..cgst = r2(cgst)
        ..sgst = r2(sgst)
        ..value = value;
      g.rates.addAll(rates);
      b2cl.add(g);
    } else {
      posIds.add(i.id);
      posValue += value;
      byRate.forEach((double rate, List<double> v) {
        final GrPos s = pos.putIfAbsent('$place|$rate', () => GrPos(place, rate));
        s.taxable += v[0];
        s.igst += v[1];
        s.cgst += v[2];
        s.sgst += v[3];
        s.ids.add(i.id);
      });
    }
  }

  final List<GrPos> posList = pos.values.toList()
    ..sort((GrPos a, GrPos b) {
      final int c = a.place.compareTo(b.place);
      return c != 0 ? c : a.rate.compareTo(b.rate);
    });
  final List<GrHsn> hsnList = hsn.values.toList()
    ..sort((GrHsn a, GrHsn b) {
      final int c = a.hsn.compareTo(b.hsn);
      return c != 0 ? c : a.rate.compareTo(b.rate);
    });
  final List<GrNil> nilList = nil.values.where((GrNil n) => n.ids.isNotEmpty).toList();
  return Gstr1(p, b2b, b2cl, posList, nilList, hsnList, docs.values.toList(), warn, posIds.length, r2(posValue), bills);
}

/// "Intra-State"-style text of a place of supply.
String gstPlaceText(String code) => code.isEmpty ? '-' : gstStateText(code);
