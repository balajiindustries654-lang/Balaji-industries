import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/app_state.dart';
import '../core/i18n.dart';
import 'engine.dart';
import 'live_models.dart';
import 'offline.dart';
import 'supa.dart';

const String kBucket = 'Way bridge slips';

/// An entry written on the phone that is not yet on the server (no internet).
class PendingItem {
  final String id;
  final String kind; // chit | kanta | maal
  final Map<String, dynamic> row;
  String? photo;
  final String queuedAt;
  int tries;
  String err;

  PendingItem({
    required this.id,
    required this.kind,
    required this.row,
    required this.photo,
    required this.queuedAt,
    this.tries = 0,
    this.err = '',
  });

  factory PendingItem.fromJson(Map<String, dynamic> j) {
    final Object? r = j['row'];
    return PendingItem(
      id: str(j['id']),
      kind: str(j['kind']),
      row: r is Map ? Map<String, dynamic>.from(r) : <String, dynamic>{},
      photo: j['photo'] == null ? null : str(j['photo']),
      queuedAt: str(j['queuedAt']),
      tries: dbl(j['tries']).round(),
      err: str(j['err']),
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'kind': kind,
        'row': row,
        'photo': photo,
        'queuedAt': queuedAt,
        'tries': tries,
        'err': err,
      };

  String get title {
    if (kind == 'chit') return '${str(row['farmer_name'])} · ${str(row['vehicle_number'])}';
    if (kind == 'kanta') return 'RST ${str(row['rst_no'])} · ${str(row['vehicle_number'])}';
    return '${str(row['vehicle_number'])} · ${str(row['material_type'])}';
  }
}

class SaveResult {
  final bool ok;
  final bool queued;
  final String error;

  /// A weighbridge entry: the RST number it was saved with ('' = not known / not changed). It differs from the one asked for
  /// when that number was already taken on the server - the entry then got the next free one.
  final String rst;
  const SaveResult(this.ok, this.queued, this.error, {this.rst = ''});
}

class _Life with WidgetsBindingObserver {
  final LiveStore s;
  DateTime? _paused;
  _Life(this.s);

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _paused = DateTime.now();
      s._touch();
    } else if (state == AppLifecycleState.resumed) {
      final DateTime? p = _paused;
      _paused = null;
      // the PIN is asked only when the app was away for longer than the time chosen in Settings > PIN lock (default 15 minutes)
      if (p != null && app.pinOn && DateTime.now().difference(p).inSeconds > app.lockAfterSec) app.lock();
      s._touch();
      s.refresh();
    }
  }
}

/// All real data of the business, loaded from Supabase.
class LiveStore extends ChangeNotifier {
  Supa supa = Supa(); // not final: tests put a fake server here

  /// true: the weighbridge laptop (Balaji Kanta) writes the Google Sheet row of an entry itself, at the moment of the weighing
  /// (see kanta_sheet.dart) - so a saved entry does not write it a second time.
  bool kantaSheetHandled = false;

  /// Told about every weighbridge entry whose RST number had to change (the laptop writes it to its files).
  void Function(String note)? onKantaNote;
  SharedPreferences? _prefs;
  Timer? _timer;
  bool _flushing = false;

  bool booting = true;
  bool signedIn = false;
  bool loading = false;
  bool offline = false;
  String error = '';
  String lastMobile = '';
  Profile? me;

  // ---- offline copies (see offline.dart)
  List<Map<String, dynamic>> _profilesRaw = <Map<String, dynamic>>[];
  Map<String, dynamic>? _cfgRaw;

  /// Logged in without internet (offline login): there is no server session yet, so the password is asked again
  /// once the internet is back (banner on top). Until then new entries wait in the queue.
  bool get needsReauth => signedIn && me != null && supa.access == null && supa.refresh == null;

  List<Chit> chits = <Chit>[];
  List<Kanta> kantas = <Kanta>[];
  List<MaalRow> maals = <MaalRow>[];
  // entries with an impossible weight / bag count (typing mistakes) - kept out of every total
  List<Chit> badChits = <Chit>[];
  List<Kanta> badKantas = <Kanta>[];
  List<MaalRow> badMaals = <MaalRow>[];
  Map<String, String> names = <String, String>{};
  List<Profile> profiles = <Profile>[];
  MatchCfg cfg = MatchCfg();
  int days = 45;
  DateTime? loadedAt;

  List<Trip> trips = <Trip>[];
  List<Finding> findings = <Finding>[];
  Map<Chit, Trip> chitTrip = <Chit, Trip>{};
  Map<Kanta, Trip> kantaTrip = <Kanta, Trip>{};
  List<PendingItem> pending = <PendingItem>[];

  // ---- choices of the owner (kept on the phone and shared between his devices)
  Map<String, String> reviewed = <String, String>{}; // finding key -> time checked
  Map<String, String> closedDays = <String, String>{}; // yyyy-mm-dd -> who|time
  Map<String, String> pins = <String, String>{}; // party id -> name
  int refreshSec = 75;
  bool _dirtyReviewed = false;
  bool _dirtyClosed = false;

  // ---- new entries made by other people since the owner last looked
  final Set<String> fresh = <String>{};
  Set<String> _known = <String>{};
  bool _seeded = false;

  bool get isAdmin => me != null && me!.isAdmin;
  String get uid => supa.uid;
  bool isReviewed(Finding f) => reviewed.containsKey(findingKey(f));

  /// Findings that nobody has marked as checked yet.
  List<Finding> get openFindings => findings.where((Finding f) => !isReviewed(f)).toList();

  int get problemCount {
    int n = 0;
    for (final Finding f in findings) {
      if (f.sev >= 2 && !isReviewed(f)) n++;
    }
    return n;
  }

  // ------------------------------------------------------------------ boot
  Future<void> boot() async {
    supa.onExpired = _expired;
    supa.onSession = _saveSession;
    WidgetsBinding.instance.addObserver(_Life(this));
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      _prefs = p;
      lastMobile = p.getString('mobile') ?? '';
      days = p.getInt('days') ?? 45;
      refreshSec = p.getInt('refreshSec') ?? 75;
      _loadChoices(p);
      final String pin = p.getString('pin') ?? '';
      app.onPinChanged = (String v) {
        final SharedPreferences? q = _prefs;
        if (q == null) return;
        if (v.length == 4) {
          q.setString('pin', v);
        } else {
          q.remove('pin');
        }
      };
      app.lockAfterSec = p.getInt('pinGrace') ?? 900;
      app.onLockAfterChanged = (int v) {
        final SharedPreferences? q = _prefs;
        if (q != null) q.setInt('pinGrace', v);
      };
      if (pin.length == 4) {
        app.pin = pin;
        app.pinOn = true;
        // opened fresh: the PIN is asked only when the app was really away for a while (not after every Back)
        final int last = p.getInt('lastActive') ?? 0;
        final int away = last == 0 ? 1 << 30 : (DateTime.now().millisecondsSinceEpoch - last) ~/ 1000;
        app.locked = away > app.lockAfterSec || away < 0;
      }
      _loadPending();
      final String rt = p.getString('rt') ?? '';
      final String meJson = p.getString('me') ?? '';
      if (rt.isNotEmpty && meJson.isNotEmpty) {
        Profile? cached;
        try {
          cached = Profile.fromJson(Map<String, dynamic>.from(jsonDecode(meJson) as Map<dynamic, dynamic>));
        } catch (_) {}
        if (cached != null) {
          bool ok = false;
          bool net = false;
          try {
            // a very slow / dead connection must not keep the splash screen for long: carry on offline
            ok = await supa.restore(rt).timeout(const Duration(seconds: 8));
          } on SupaError catch (e) {
            net = e.network;
          } on TimeoutException {
            net = true;
          }
          if (ok || net) {
            me = cached;
            supa.uid = cached.id;
            signedIn = true;
            offline = !ok;
            await _loadCache();
            _startTimer();
          }
        }
      }
    } catch (e) {
      error = '$e';
    }
    booting = false;
    notifyListeners();
    if (signedIn) refresh();
  }

  void _saveSession() {
    final SharedPreferences? p = _prefs;
    final String? rt = supa.refresh;
    if (p != null && rt != null) p.setString('rt', rt);
  }

  void _expired() {
    final String m = lastMobile;
    // the server refused the saved login: no offline login with it any more
    Future<void>.microtask(() async {
      if (m.isNotEmpty) await OfflineStore.dropCred(m);
      await logout(keepPending: true);
    });
  }

  /// Remembers when the app was last in use (for the PIN grace time after a fresh start).
  void _touch() {
    final SharedPreferences? p = _prefs;
    if (p != null) p.setInt('lastActive', DateTime.now().millisecondsSinceEpoch);
  }

  void _startTimer() {
    _timer?.cancel();
    if (refreshSec <= 0) return;
    _timer = Timer.periodic(Duration(seconds: refreshSec), (Timer t) {
      if (signedIn) {
        _touch();
        refresh();
      }
    });
  }

  Future<void> setRefreshSec(int sec) async {
    refreshSec = sec;
    final SharedPreferences? p = _prefs;
    if (p != null) await p.setInt('refreshSec', sec);
    if (signedIn) _startTimer();
    notifyListeners();
  }

  // ----------------------------------------------------------------- login
  /// Returns an error text, or null when signed in.
  Future<String?> login(String mobile, String pass) async {
    try {
      await supa.signIn(mobile, pass);
      final List<Map<String, dynamic>> rows =
          await supa.select('user_profiles', <String, String>{'select': '*', 'id': 'eq.${supa.uid}'}, limit: 1);
      if (rows.isEmpty) {
        supa.clear();
        return 'પ્રોફાઇલ મળી નથી - એડમિનનો સંપર્ક કરો';
      }
      final Profile pr = Profile.fromJson(rows.first);
      me = pr;
      final SharedPreferences? p = _prefs;
      if (p != null) {
        await p.setString('mobile', digitsOf(mobile));
        await p.setString('me', jsonEncode(rows.first));
        _saveSession();
      }
      lastMobile = digitsOf(mobile);
      // so that the same person can log in again later without internet
      unawaited(OfflineStore.saveCred(mobile, pass, supa.uid, rows.first));
      await _loadCache();
      signedIn = true;
      offline = false;
      error = '';
      app.locked = false;
      _seeded = false;
      _startTimer();
      notifyListeners();
      if (pr.approved && !pr.isFarmer) refresh();
      return null;
    } on SupaError catch (e) {
      supa.clear();
      me = null;
      if (e.network || e.status >= 500) return _loginOffline(mobile, pass);
      return e.message;
    }
  }

  /// No internet: log in with the hash saved at the last online login of this device.
  Future<String?> _loginOffline(String mobile, String pass) async {
    final OfflineLogin r = await OfflineStore.checkCred(mobile, pass);
    if (!r.hasCred) {
      return bi('ઇન્ટરનેટ નથી. આ ફોન / PC પર પહેલા એક વાર ઇન્ટરનેટ સાથે લૉગિન કરવું પડશે - પછી ઑફલાઇન લૉગિન ચાલશે.',
          'No internet. Log in once with internet on this device - after that offline login works.');
    }
    if (r.locked) return bi('ઘણી ખોટી કોશિશ - એક મિનિટ પછી ફરી કરો', 'Too many wrong tries - try again after a minute');
    if (!r.ok || r.uid.isEmpty || r.profile.isEmpty) return bi('મોબાઇલ અથવા પાસવર્ડ ખોટો છે', 'Wrong mobile or password');
    final Profile pr = Profile.fromJson(r.profile);
    me = pr;
    supa.uid = r.uid;
    final SharedPreferences? p = _prefs;
    if (p != null) {
      await p.setString('mobile', digitsOf(mobile));
      await p.setString('me', jsonEncode(r.profile));
    }
    lastMobile = digitsOf(mobile);
    await _loadCache();
    signedIn = true;
    offline = true;
    error = '';
    app.locked = false;
    _seeded = false;
    _startTimer();
    notifyListeners();
    app.toast(bi('ઑફલાઇન લૉગિન થયું - જૂનો ડેટા દેખાય છે', 'Offline login - showing the saved data'));
    return null;
  }

  /// After an offline login: asks the server for a real session with the password (internet must be back).
  Future<String?> reauth(String pass) async {
    try {
      await supa.signIn(lastMobile, pass);
      final Profile? pr = me;
      if (pr != null && supa.uid != pr.id) {
        await logout(keepPending: true);
        return bi('આ બીજા વ્યક્તિનું ખાતું છે', 'This is another person\'s account');
      }
      _saveSession();
      offline = false;
      error = '';
      notifyListeners();
      unawaited(refresh());
      return null;
    } on SupaError catch (e) {
      return e.message;
    }
  }

  /// Deletes the saved data copies and saved offline logins of this device.
  Future<void> clearOffline() async {
    await OfflineStore.clearAll();
    notifyListeners();
  }

  /// Re-reads the profile (after the admin approved the account).
  Future<void> recheck() async {
    try {
      final List<Map<String, dynamic>> rows =
          await supa.select('user_profiles', <String, String>{'select': '*', 'id': 'eq.${supa.uid}'}, limit: 1);
      if (rows.isNotEmpty) {
        me = Profile.fromJson(rows.first);
        final SharedPreferences? p = _prefs;
        if (p != null) await p.setString('me', jsonEncode(rows.first));
      }
    } on SupaError catch (_) {}
    notifyListeners();
    final Profile? pr = me;
    if (pr != null && pr.approved && !pr.isFarmer) refresh();
  }

  Future<void> logout({bool keepPending = true}) async {
    _timer?.cancel();
    final SharedPreferences? p = _prefs;
    if (p != null) {
      await p.remove('rt');
      await p.remove('me');
    }
    supa.clear();
    signedIn = false;
    _seeded = false;
    fresh.clear();
    me = null;
    chits = <Chit>[];
    kantas = <Kanta>[];
    maals = <MaalRow>[];
    badChits = <Chit>[];
    badKantas = <Kanta>[];
    badMaals = <MaalRow>[];
    trips = <Trip>[];
    findings = <Finding>[];
    profiles = <Profile>[];
    names = <String, String>{};
    if (!keepPending) {
      pending = <PendingItem>[];
      _savePending();
    }
    notifyListeners();
  }

  // ------------------------------------------------------------------ load
  Future<void> refresh() async {
    final Profile? pr = me;
    if (!signedIn || loading || pr == null || !pr.approved || pr.isFarmer) return;
    loading = true;
    error = '';
    notifyListeners();
    try {
      if (supa.access == null) {
        final bool ok = await supa.refreshSession();
        if (!ok && supa.refresh == null) {
          loading = false;
          notifyListeners();
          return;
        }
      }
      await flush();
      final DateTime since = DateTime.now().subtract(Duration(days: days));
      final Map<String, String> base = <String, String>{
        'select': '*',
        'order': 'created_at.desc',
        'created_at': 'gte.${since.toUtc().toIso8601String()}',
      };
      if (!pr.isAdmin) base['created_by'] = 'eq.${supa.uid}';
      final List<List<Map<String, dynamic>>> res = await Future.wait<List<Map<String, dynamic>>>(<Future<List<Map<String, dynamic>>>>[
        supa.selectAll('chiththis', base),
        supa.selectAll('waybridge_entries', base),
        supa.selectAll('maal_entries', base),
      ]);
      _setEntries(res[0], res[1], res[2]);

      if (pr.isAdmin) {
        try {
          final List<Map<String, dynamic>> ps = await supa.selectAll(
              'user_profiles', <String, String>{'select': 'id,full_name,mobile,role,approved'}, maxRows: 5000);
          _setProfiles(ps);
        } on SupaError catch (_) {}
        try {
          final List<Map<String, dynamic>> st = await supa.select(
              'app_settings', <String, String>{'select': '*', 'key': 'in.(flutter_match,flutter_reviewed,flutter_closed)'},
              limit: 10);
          for (final Map<String, dynamic> row in st) {
            final String k = str(row['key']);
            final Object? v = row['value'];
            if (v is! Map) continue;
            if (k == 'flutter_match') {
              _cfgRaw = Map<String, dynamic>.from(v);
              cfg = MatchCfg.fromJson(_cfgRaw!);
            } else if (k == 'flutter_reviewed' && !_dirtyReviewed) {
              reviewed = <String, String>{for (final MapEntry<dynamic, dynamic> e in v.entries) '${e.key}': '${e.value}'};
              _saveChoices();
            } else if (k == 'flutter_closed' && !_dirtyClosed) {
              closedDays = <String, String>{for (final MapEntry<dynamic, dynamic> e in v.entries) '${e.key}': '${e.value}'};
              _saveChoices();
            }
          }
          if (_dirtyReviewed) unawaited(_pushReviewed());
          if (_dirtyClosed) unawaited(_pushClosed());
        } on SupaError catch (_) {}
      } else {
        names = <String, String>{pr.id: pr.name};
      }
      loadedAt = DateTime.now();
      offline = false;
      _derive();
      _detectNew();
      _saveCache(res[0], res[1], res[2]);
    } on SupaError catch (e) {
      if (e.network) {
        offline = true;
      } else {
        error = e.message;
      }
    } catch (e) {
      error = '$e';
    }
    loading = false;
    notifyListeners();
  }

  void _setEntries(List<Map<String, dynamic>> c, List<Map<String, dynamic>> k, List<Map<String, dynamic>> m) {
    final List<Chit> allChits = c.map(Chit.fromJson).toList();
    final List<Kanta> allKantas = k.map(Kanta.fromJson).toList();
    final List<MaalRow> allMaals = m.map(MaalRow.fromJson).toList();
    chits = allChits.where((Chit x) => !x.insane).toList();
    kantas = allKantas.where((Kanta x) => !x.insane).toList();
    maals = allMaals.where((MaalRow x) => !x.insane).toList();
    badChits = allChits.where((Chit x) => x.insane).toList();
    badKantas = allKantas.where((Kanta x) => x.insane).toList();
    badMaals = allMaals.where((MaalRow x) => x.insane).toList();
  }

  void _setProfiles(List<Map<String, dynamic>> ps) {
    _profilesRaw = ps;
    profiles = ps.map(Profile.fromJson).toList();
    final Map<String, String> nm = <String, String>{};
    for (final Profile x in profiles) {
      nm[x.id] = x.name.isNotEmpty ? x.name : x.mobile;
    }
    names = nm;
  }

  // ---------------------------------------------------------- offline copy
  String get _cacheKey => '${supa.uid}_live';

  /// Puts the last saved copy of the data on the screen (works without internet, and shows data at once at start).
  Future<void> _loadCache() async {
    if (supa.uid.isEmpty) return;
    try {
      final Object? j = await OfflineStore.read(_cacheKey);
      if (j is! Map) return;
      List<Map<String, dynamic>> rows(String key) {
        final Object? v = j[key];
        final List<Map<String, dynamic>> out = <Map<String, dynamic>>[];
        if (v is List) {
          for (final Object? e in v) {
            if (e is Map) out.add(Map<String, dynamic>.from(e));
          }
        }
        return out;
      }

      _setEntries(rows('chits'), rows('kantas'), rows('maals'));
      final Profile? pr = me;
      final List<Map<String, dynamic>> ps = rows('profiles');
      if (ps.isNotEmpty) {
        _setProfiles(ps);
      } else if (pr != null) {
        names = <String, String>{pr.id: pr.name};
      }
      final Object? c = j['cfg'];
      if (c is Map) {
        _cfgRaw = Map<String, dynamic>.from(c);
        cfg = MatchCfg.fromJson(_cfgRaw!);
      }
      final DateTime? at = DateTime.tryParse(str(j['at']));
      if (at != null) loadedAt = at.toLocal();
      _derive();
    } catch (_) {}
  }

  void _saveCache(List<Map<String, dynamic>> c, List<Map<String, dynamic>> k, List<Map<String, dynamic>> m) {
    if (supa.uid.isEmpty) return;
    unawaited(OfflineStore.write(_cacheKey, <String, dynamic>{
      'at': DateTime.now().toUtc().toIso8601String(),
      'days': days,
      'chits': c,
      'kantas': k,
      'maals': m,
      'profiles': _profilesRaw,
      'cfg': _cfgRaw,
    }));
  }

  void _derive() {
    final DateTime now = DateTime.now();
    if (isAdmin) {
      trips = buildTrips(chits, kantas, cfg, now);
      findings = runAudit(chits: chits, kantas: kantas, maals: maals, trips: trips, cfg: cfg, names: names, now: now);
      final Map<Chit, Trip> ct = <Chit, Trip>{};
      final Map<Kanta, Trip> kt = <Kanta, Trip>{};
      for (final Trip t in trips) {
        for (final Chit c in t.chits) {
          ct[c] = t;
        }
        final Kanta? k = t.kanta;
        if (k != null) kt[k] = t;
      }
      chitTrip = ct;
      kantaTrip = kt;
    } else {
      trips = <Trip>[];
      findings = <Finding>[];
      chitTrip = <Chit, Trip>{};
      kantaTrip = <Kanta, Trip>{};
    }
  }

  /// How many entries were kept out of the totals for an impossible weight.
  int get badCount => badChits.length + badKantas.length + badMaals.length;

  /// Deletes one wrong entry (owner only). 'chit' | 'kanta' | 'maal'. Returns
  /// an empty string when done, otherwise the reason it failed.
  Future<String> deleteEntry(String kind, String id) async {
    final String table = kind == 'chit' ? 'chiththis' : (kind == 'kanta' ? 'waybridge_entries' : 'maal_entries');
    try {
      final List<Map<String, dynamic>> gone = await supa.delete(table, <String, String>{'id': 'eq.$id'});
      if (gone.isEmpty) return bi('કાઢવાની પરવાનગી નથી', 'No permission to delete');
      badChits = badChits.where((Chit c) => c.id != id).toList();
      badKantas = badKantas.where((Kanta k) => k.id != id).toList();
      badMaals = badMaals.where((MaalRow m) => m.id != id).toList();
      chits = chits.where((Chit c) => c.id != id).toList();
      kantas = kantas.where((Kanta k) => k.id != id).toList();
      maals = maals.where((MaalRow m) => m.id != id).toList();
      _derive();
      notifyListeners();
      return '';
    } on SupaError catch (e) {
      return e.message;
    }
  }

  void rederive() {
    _derive();
    notifyListeners();
  }

  Future<void> setDays(int d) async {
    days = d;
    _seeded = false;
    final SharedPreferences? p = _prefs;
    if (p != null) await p.setInt('days', d);
    notifyListeners();
    await refresh();
  }

  // ------------------------------------------------------- owner's choices
  void _loadChoices(SharedPreferences p) {
    Map<String, String> readMap(String key) {
      final String raw = p.getString(key) ?? '';
      if (raw.isEmpty) return <String, String>{};
      try {
        final Object? j = jsonDecode(raw);
        if (j is Map) return <String, String>{for (final MapEntry<dynamic, dynamic> e in j.entries) '${e.key}': '${e.value}'};
      } catch (_) {}
      return <String, String>{};
    }

    reviewed = readMap('reviewed');
    closedDays = readMap('closedDays');
    pins = readMap('pins');
    _dirtyReviewed = p.getBool('dirtyReviewed') ?? false;
    _dirtyClosed = p.getBool('dirtyClosed') ?? false;
  }

  void _saveChoices() {
    final SharedPreferences? p = _prefs;
    if (p == null) return;
    p.setString('reviewed', jsonEncode(reviewed));
    p.setString('closedDays', jsonEncode(closedDays));
    p.setString('pins', jsonEncode(pins));
    p.setBool('dirtyReviewed', _dirtyReviewed);
    p.setBool('dirtyClosed', _dirtyClosed);
  }

  Future<void> _pushReviewed() async {
    // keep the shared list small: forget what was checked more than 90 days ago
    final DateTime lim = DateTime.now().subtract(const Duration(days: 90));
    reviewed.removeWhere((String k, String v) {
      final DateTime? t = DateTime.tryParse(v);
      return t != null && t.isBefore(lim);
    });
    try {
      await supa.upsert('app_settings', <String, dynamic>{'key': 'flutter_reviewed', 'value': reviewed}, 'key');
      _dirtyReviewed = false;
    } on SupaError catch (_) {
      _dirtyReviewed = true;
    }
    _saveChoices();
  }

  Future<void> _pushClosed() async {
    try {
      await supa.upsert('app_settings', <String, dynamic>{'key': 'flutter_closed', 'value': closedDays}, 'key');
      _dirtyClosed = false;
    } on SupaError catch (_) {
      _dirtyClosed = true;
    }
    _saveChoices();
  }

  /// Mark findings as checked (or bring them back).
  void setReviewed(Iterable<Finding> fs, bool v) {
    final String now = DateTime.now().toIso8601String();
    for (final Finding f in fs) {
      if (v) {
        reviewed[findingKey(f)] = now;
      } else {
        reviewed.remove(findingKey(f));
      }
    }
    _dirtyReviewed = true;
    _saveChoices();
    notifyListeners();
    unawaited(_pushReviewed());
  }

  bool isClosed(DateTime d) => closedDays.containsKey(_dk(d));

  String closedInfo(DateTime d) => closedDays[_dk(d)] ?? '';

  String _dk(DateTime d) => '${d.year}-${d.month < 10 ? '0' : ''}${d.month}-${d.day < 10 ? '0' : ''}${d.day}';

  void closeDay(DateTime d, bool close) {
    if (close) {
      closedDays[_dk(d)] = '${me?.name ?? ''}|${DateTime.now().toIso8601String()}';
    } else {
      closedDays.remove(_dk(d));
    }
    _dirtyClosed = true;
    _saveChoices();
    notifyListeners();
    unawaited(_pushClosed());
  }

  bool isPinned(String id) => pins.containsKey(id);

  void togglePinned(String id, String label) {
    if (pins.containsKey(id)) {
      pins.remove(id);
    } else {
      pins[id] = label;
    }
    _saveChoices();
    notifyListeners();
  }

  // ------------------------------------------------------ new entry alerts
  void _detectNew() {
    final Set<String> ids = <String>{
      for (final Chit c in chits) 'c${c.id}',
      for (final Kanta k in kantas) 'k${k.id}',
      for (final MaalRow m in maals) 'm${m.id}',
    };
    if (_seeded && isAdmin) {
      int nc = 0;
      int nk = 0;
      int nm = 0;
      for (final Chit c in chits) {
        final String k = 'c${c.id}';
        if (!_known.contains(k) && c.by != uid) {
          fresh.add(k);
          nc++;
        }
      }
      for (final Kanta c in kantas) {
        final String k = 'k${c.id}';
        if (!_known.contains(k) && c.by != uid) {
          fresh.add(k);
          nk++;
        }
      }
      for (final MaalRow c in maals) {
        final String k = 'm${c.id}';
        if (!_known.contains(k) && c.by != uid) {
          fresh.add(k);
          nm++;
        }
      }
      if (nc + nk + nm > 0) {
        final List<String> parts = <String>[];
        if (nc > 0) parts.add(bi('$nc ચિઠ્ઠી', '$nc chits'));
        if (nk > 0) parts.add(bi('$nk કાંટો', '$nk kanta'));
        if (nm > 0) parts.add(bi('$nm માલ', '$nm maal'));
        app.toast('${bi('નવું આવ્યું', 'New')}: ${parts.join(' · ')}');
      }
    }
    _known = ids;
    _seeded = true;
  }

  /// The owner has looked at the new entries.
  void markSeen() {
    if (fresh.isEmpty) return;
    fresh.clear();
    notifyListeners();
  }

  Future<String?> saveCfg(MatchCfg c) async {
    try {
      await supa.upsert('app_settings', <String, dynamic>{'key': 'flutter_match', 'value': c.toJson()}, 'key');
      cfg = c;
      _derive();
      notifyListeners();
      return null;
    } on SupaError catch (e) {
      return e.message;
    }
  }

  Future<List<Map<String, dynamic>>> loadHistory() {
    return supa.select('balaji_entry_history', <String, String>{'select': '*', 'order': 'changed_at.desc'}, limit: 200);
  }

  Future<String?> restoreHistory(String historyId) async {
    try {
      await supa.rpc('balaji_restore_entry', <String, dynamic>{'p_history_id': int.tryParse(historyId) ?? historyId});
      await refresh();
      return null;
    } on SupaError catch (e) {
      return e.message;
    }
  }

  // ---------------------------------------------------------------- saving
  Future<SaveResult> submit(String kind, Map<String, dynamic> row, {String? photoPath}) async {
    final PendingItem it = PendingItem(
      id: '${DateTime.now().microsecondsSinceEpoch}',
      kind: kind,
      row: row,
      photo: photoPath,
      queuedAt: DateTime.now().toUtc().toIso8601String(),
    );
    if (needsReauth) {
      // offline login: no server session yet - keep the entry safely in the queue
      pending.add(it);
      _savePending();
      notifyListeners();
      return const SaveResult(true, true, '');
    }
    if (kind == 'kanta' && offline) {
      // the weighbridge laptop without internet: the entry waits on the laptop at once (no waiting for a dead connection)
      // and goes by itself when the internet is back (the next refresh sends the waiting entries)
      pending.add(it);
      _savePending();
      notifyListeners();
      return const SaveResult(true, true, '');
    }
    try {
      final Map<String, dynamic> saved = await _push(it, delayed: false);
      _addLocal(kind, saved);
      return SaveResult(true, false, '', rst: kind == 'kanta' ? '${saved['rst_no'] ?? ''}'.trim() : '');
    } on SupaError catch (e) {
      if (e.network) {
        pending.add(it);
        _savePending();
        notifyListeners();
        return const SaveResult(true, true, '');
      }
      return SaveResult(false, false, e.message);
    } catch (e) {
      return SaveResult(false, false, '$e');
    }
  }

  String _table(String kind) => kind == 'chit' ? 'chiththis' : (kind == 'kanta' ? 'waybridge_entries' : 'maal_entries');
  String _photoField(String kind) => kind == 'chit' ? 'chiththi_photo_url' : 'slip_url';
  String _folder(String kind) => kind == 'chit' ? 'chiththis' : (kind == 'kanta' ? 'waybridge' : 'maal_entries');

  Future<Map<String, dynamic>> _push(PendingItem it, {required bool delayed}) async {
    final String pf = _photoField(it.kind);
    final String? path = it.photo;
    if (path != null && path.isNotEmpty) {
      final File f = File(path);
      if (await f.exists()) {
        final List<int> bytes = await f.readAsBytes();
        final String name = '${DateTime.now().millisecondsSinceEpoch}_slip.jpg';
        final String url = await supa.uploadPhoto(kBucket, '${supa.uid}/${_folder(it.kind)}/$name', bytes);
        it.row[pf] = url;
      }
      it.photo = null;
    }
    final Map<String, dynamic> row = Map<String, dynamic>.from(it.row);
    row['created_by'] = supa.uid;
    if (delayed) row['created_at'] = it.queuedAt;
    Map<String, dynamic> saved;
    try {
      saved = await _insertDana(it.kind, row);
    } on SupaError catch (e) {
      if (e.code == '23505' && it.kind == 'kanta') {
        // the RST number is taken: the same entry saved before (the answer got lost) or somebody else's - then the next free number
        final Map<String, dynamic>? fixed = await _kantaDup(it, row);
        if (fixed != null) return fixed;
      }
      if (e.code == '23505' && delayed) {
        // already on the server (a retry after a lost reply)
        return <String, dynamic>{...row, 'id': 'dup${it.id}', 'created_at': row['created_at'] ?? DateTime.now().toUtc().toIso8601String()};
      }
      rethrow;
    }
    _afterSaved(it.kind, saved);
    return saved;
  }

  /// Set when the server has no `dana` column yet (run sql/supabase-maal-dana.sql in Supabase): the entry is saved without the dana.
  bool danaColumnMissing = false;

  /// Inserts the row. A maal entry with a dana is never lost when the `dana` column does not exist on the server yet:
  /// it is saved without the dana (and [danaColumnMissing] tells the screens to warn).
  Future<Map<String, dynamic>> _insertDana(String kind, Map<String, dynamic> row) async {
    try {
      return await supa.insert(_table(kind), row);
    } on SupaError catch (e) {
      final String m = '${e.message} ${e.code}'.toLowerCase();
      if (kind == 'maal' && row.containsKey('dana') && m.contains('dana') && (m.contains('column') || m.contains('pgrst204') || m.contains('42703'))) {
        danaColumnMissing = true;
        final Map<String, dynamic> plain = Map<String, dynamic>.from(row)..remove('dana');
        final Map<String, dynamic> saved = await supa.insert(_table(kind), plain);
        notifyListeners();
        return saved;
      }
      rethrow;
    }
  }

  /// The first RST number from [from] on that is not used on the server (asks 50 numbers at a time). Throws when the server cannot be asked.
  Future<int> firstFreeRst(int from) async {
    int n = from < 1 ? 1 : from;
    for (int round = 0; round < 40; round++) {
      final List<String> cand = <String>[for (int i = 0; i < 50; i++) '${n + i}'];
      final List<Map<String, dynamic>> rows = await supa.select('waybridge_entries', <String, String>{'select': 'rst_no', 'rst_no': 'in.(${cand.join(',')})'}, limit: 60).timeout(const Duration(seconds: 8));
      final Set<String> taken = <String>{for (final Map<String, dynamic> r in rows) '${r['rst_no'] ?? ''}'.trim()};
      for (final String c in cand) {
        if (!taken.contains(c)) return int.parse(c);
      }
      n += 50;
    }
    return n;
  }

  /// A weighbridge entry hit "duplicate key" on its RST number. Returns the saved row when it could be settled, null when not
  /// (the original error then goes on):
  ///  * the number belongs to the very same entry (same vehicle, same net) - it was saved before and only the answer got lost: nothing more to do;
  ///  * it belongs to another entry (the owner's phone / another laptop / an old test entry has that number): the entry is saved with the
  ///    next free number. The operator does not see an error; the slip is made with the number it finally got.
  Future<Map<String, dynamic>?> _kantaDup(PendingItem it, Map<String, dynamic> row) async {
    final String rst = '${row['rst_no'] ?? ''}'.trim();
    if (rst.isEmpty) return null;
    try {
      final List<Map<String, dynamic>> ex = await supa.select('waybridge_entries', <String, String>{'select': 'id,rst_no,vehicle_number,net_weight_kg,created_at', 'rst_no': 'eq.$rst'}, limit: 5).timeout(const Duration(seconds: 8));
      final double net = dbl(row['net_weight_kg']);
      for (final Map<String, dynamic> r in ex) {
        if (vehicleKey(str(r['vehicle_number'])) == vehicleKey(str(row['vehicle_number'])) && (dbl(r['net_weight_kg']) - net).abs() < 1) {
          return <String, dynamic>{...row, ...r};
        }
      }
      int from = (int.tryParse(rst) ?? 0) + 1;
      for (int attempt = 0; attempt < 4; attempt++) {
        final int n = await firstFreeRst(from);
        final Map<String, dynamic> r2 = Map<String, dynamic>.from(row)..['rst_no'] = '$n';
        try {
          final Map<String, dynamic> saved = await supa.insert(_table(it.kind), r2);
          it.row['rst_no'] = '$n';
          final String note = 'RST $rst was already used on the server - ${str(row['vehicle_number'])} was saved as RST $n';
          try {
            onKantaNote?.call(note);
          } catch (_) {}
          _afterSaved(it.kind, saved);
          return saved;
        } on SupaError catch (e2) {
          if (e2.code != '23505') return null;
          from = n + 1;
        }
      }
    } catch (_) {}
    return null;
  }

  void _afterSaved(String kind, Map<String, dynamic> r) {
    if (kind == 'chit') {
      final String farmer = str(r['farmer_name']);
      final String veh = str(r['vehicle_number']);
      final double net = dbl(r['weight_kg']);
      unawaited(supa.notifyAdmin('majur', 'નવી Majur Chiththi', '$farmer | $veh | ${net.toStringAsFixed(2)} KG | Chiththi ${str(r['chiththi_number'])}'));
      unawaited(supa.sheet(<String, dynamic>{
        'type': 'Majur Chiththi',
        'chiththi_number': r['chiththi_number'],
        'vehicle_number': r['vehicle_number'],
        'farmer_name': r['farmer_name'],
        'mobile': r['farmer_mobile'] ?? '',
        'village': r['village_name'],
        'material': r['commodity_type'],
        'gross_weight': r['gross_weight_kg'],
        'bardan_kg': r['bardan_kg'],
        'kardo_kg': r['kardo_kg'],
        'net_weight': r['weight_kg'],
        'broker_name': r['broker_name'] ?? '',
        'photo_url': r['chiththi_photo_url'],
      }));
    } else if (kind == 'kanta') {
      final String veh = str(r['vehicle_number']);
      final String w = r['net_weight_kg'] == null ? '-' : '${r['net_weight_kg']} KG';
      unawaited(supa.notifyAdmin('waybridge', 'નવી Waybridge Entry', '${veh.isEmpty ? '-' : veh} | $w | RST ${str(r['rst_no'])}'));
      // the whole entry goes to the Google Sheet (same row as the Balaji Industries app writes, plus gross / tare / party / goods /
      // town / charges and the date and time of the weighing - taken from the entry itself, so a late-sent entry keeps its own time)
      final DateTime at = (parseTs(r['created_at']) ?? DateTime.now()).toLocal();
      String two(int n) => n < 10 ? '0$n' : '$n';
      String pick(Object? a, Object? b) => str(a).isNotEmpty ? str(a) : str(b);
      if (!kantaSheetHandled) unawaited(supa.sheet(<String, dynamic>{
        'type': 'Waybridge',
        'name': pick(r['name'], r['party_name']),
        'mobile': pick(r['mobile'], r['party_mobile']),
        'rst_no': r['rst_no'] ?? '',
        'vehicle_number': r['vehicle_number'] ?? '',
        'net_weight': r['net_weight_kg'] ?? '',
        'slip_url': r['slip_url'] ?? '',
        'gross_weight': r['gross_kg'] ?? '',
        'tare_weight': r['tare_kg'] ?? '',
        'party': str(r['party_name']),
        'material': str(r['material']),
        'city': str(r['city']),
        'charges': r['charges_rs'] ?? '',
        'date': '${two(at.day)}-${two(at.month)}-${at.year}',
        'time': '${two(at.hour)}:${two(at.minute)}',
      }));
    } else {
      unawaited(supa.notifyAdmin('maal', 'નવી Maal Entry', '${str(r['vehicle_number'])} | ${str(r['material_type'])} | ${str(r['bags'])} bags'));
      unawaited(supa.sheet(<String, dynamic>{
        'type': 'Maal Entry',
        'entry_type': r['entry_type'],
        'date': r['entry_date'],
        'vehicle_number': r['vehicle_number'],
        'owner_name': r['owner_name'] ?? '',
        'material': r['material_type'],
        'bags': r['bags'],
        'slip_url': r['slip_url'],
      }));
    }
  }

  void _addLocal(String kind, Map<String, dynamic> saved) {
    if (kind == 'chit') {
      chits = <Chit>[Chit.fromJson(saved), ...chits];
    } else if (kind == 'kanta') {
      kantas = <Kanta>[Kanta.fromJson(saved), ...kantas];
    } else {
      maals = <MaalRow>[MaalRow.fromJson(saved), ...maals];
    }
    _derive();
    notifyListeners();
  }

  // ---------------------------------------------------------- offline queue
  void _loadPending() {
    final List<String> l = _prefs?.getStringList('pending') ?? <String>[];
    final List<PendingItem> out = <PendingItem>[];
    for (final String s in l) {
      try {
        out.add(PendingItem.fromJson(Map<String, dynamic>.from(jsonDecode(s) as Map<dynamic, dynamic>)));
      } catch (_) {}
    }
    pending = out;
  }

  void _savePending() {
    final SharedPreferences? p = _prefs;
    if (p == null) return;
    p.setStringList('pending', pending.map((PendingItem x) => jsonEncode(x.toJson())).toList());
  }

  Future<void> flush() async {
    if (!signedIn || _flushing || pending.isEmpty || needsReauth) return;
    _flushing = true;
    try {
      for (final PendingItem it in List<PendingItem>.from(pending)) {
        try {
          await _push(it, delayed: true);
          pending.remove(it);
        } on SupaError catch (e) {
          if (e.network) break;
          it.err = e.message;
          it.tries++;
        }
      }
    } finally {
      _flushing = false;
      _savePending();
      notifyListeners();
    }
  }

  void dropPending(PendingItem it) {
    pending.remove(it);
    _savePending();
    notifyListeners();
  }
}

/// The one global store (like `app` for the UI state).
final LiveStore live = LiveStore();
