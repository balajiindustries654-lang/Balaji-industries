import 'live_models.dart';
import 'lists.dart';

/// What a slip scan found, ready to be poured into one of the entry forms.
class ScanPrefill {
  /// chit | kanta | maal
  final String kind;

  /// Normalised values. chit: no, village, vehicle, farmer, broker, mobile,
  /// gross, bardan, kardo, commodity. kanta: rst, vehicle, kg, name, mobile.
  /// maal: type, vehicle, bags, material, date, owner.
  final Map<String, String> f;
  final String? photo;
  final List<String> warnings;
  final List<String> bagWeights;
  final int bagCount;
  final String writtenTotal;
  final double? calcTotal;
  final bool verified;
  final String checkStatus;
  final String text;

  /// false when the values come from a quick check, not from a photo.
  final bool scanned;

  const ScanPrefill({
    required this.kind,
    required this.f,
    this.photo,
    this.warnings = const <String>[],
    this.bagWeights = const <String>[],
    this.bagCount = 0,
    this.writtenTotal = '',
    this.calcTotal,
    this.verified = false,
    this.checkStatus = '',
    this.text = '',
    this.scanned = true,
  });

  String v(String k) => f[k] ?? '';

  /// Number of form fields that were actually read.
  int get filled => f.values.where((String x) => x.trim().isNotEmpty).length;

  static String serverKind(String kind) {
    if (kind == 'kanta') return 'waybridge';
    if (kind == 'maal') return 'maal_entry';
    return 'worker';
  }

  /// Builds a prefill from the raw `scan-entry` reply.
  factory ScanPrefill.fromReply(String kind, Map<String, dynamic> j, String? photo) {
    final Object? fo = j['fields'];
    final Map<String, dynamic> raw = fo is Map ? Map<String, dynamic>.from(fo) : <String, dynamic>{};
    String g(String k) => str(raw[k]);
    final Map<String, String> f = <String, String>{};
    if (kind == 'chit') {
      f['no'] = g('chiththi_number');
      f['village'] = matchOption(g('village_name'), kVillages);
      f['vehicle'] = g('vehicle_number');
      f['farmer'] = g('farmer_name');
      f['broker'] = matchOption(g('broker_name'), kBrokers);
      f['mobile'] = g('farmer_mobile');
      f['gross'] = g('farmer_weight');
      f['bardan'] = g('bardan_kg');
      f['kardo'] = g('kardo_kg');
      f['commodity'] = commodityCode(g('commodity_type'));
    } else if (kind == 'kanta') {
      f['rst'] = g('wb_rst');
      f['vehicle'] = g('wb_vehicle');
      f['kg'] = g('wb_weight');
      f['name'] = g('wb_name');
      f['mobile'] = g('wb_mobile');
    } else {
      final String et = g('me_entry_type').toLowerCase();
      f['type'] = et.contains('unload') ? 'unloading' : (et.contains('load') ? 'loading' : '');
      f['vehicle'] = g('me_vehicle');
      f['bags'] = g('me_bags');
      f['material'] = commodityCode(g('me_material'));
      f['date'] = g('me_date');
      f['owner'] = g('me_owner');
    }
    final List<String> warn = <String>[];
    final Object? wo = j['warnings'];
    if (wo is List) {
      for (final Object? w in wo) {
        final String t = str(w);
        if (t.isNotEmpty) warn.add(t);
      }
    }
    final List<String> bags = <String>[];
    final Object? bo = j['weights'];
    if (bo is List) {
      for (final Object? w in bo) {
        if (w is Map) {
          bags.add(str(w['value']));
        } else {
          bags.add(str(w));
        }
      }
    }
    int bc = bags.length;
    String written = '';
    double? calc;
    bool ver = false;
    final Object? so = j['weight_summary'];
    if (so is Map) {
      bc = dbl(so['bag_count']).round();
      written = str(so['written_total']);
      calc = dblN(so['calculated_total']);
      ver = so['verified'] == true;
    }
    String st = '';
    final Object? co = j['bag_check'];
    if (co is Map) st = str(co['status']);
    return ScanPrefill(
      kind: kind,
      f: f,
      photo: photo,
      warnings: warn,
      bagWeights: bags,
      bagCount: bc,
      writtenTotal: written,
      calcTotal: calc,
      verified: ver,
      checkStatus: st,
      text: str(j['text']),
    );
  }
}

/// Database code of a material (Magfadi / Aeranda / ...), '' when unknown.
String commodityCode(String v) {
  final String t = v.trim().toLowerCase();
  if (t.isEmpty) return '';
  for (final List<String> c in kCommodities) {
    if (c[0].toLowerCase() == t || c[1] == v.trim() || c[2].toLowerCase() == t) return c[0];
  }
  if (t.contains('magf') || t.contains('groundnut') || t.contains('mungf') || v.contains('મગફળી') || v.contains('સીંગ')) return 'Magfadi';
  if (t.contains('aer') || t.contains('castor') || v.contains('એરંડા')) return 'Aeranda';
  if (t.contains('gau') || t.contains('wheat') || v.contains('ઘઉં')) return 'Gau';
  if (t.contains('govar') || t.contains('guar') || v.contains('ગવાર')) return 'Govar';
  return '';
}

/// Picks the list entry that best matches a scanned word, so that "માંડવી"
/// becomes the exact list value "માંડવી (Mandvi)". Returns [v] when nothing fits.
String matchOption(String v, List<String> options) {
  final String t = v.trim();
  if (t.isEmpty) return '';
  final String lo = t.toLowerCase();
  for (final String o in options) {
    if (o.toLowerCase() == lo) return o;
  }
  for (final String o in options) {
    final String ol = o.toLowerCase();
    final int p = ol.indexOf('(');
    final String gu = (p > 0 ? ol.substring(0, p) : ol).trim();
    final String en = p > 0 ? ol.substring(p + 1).replaceAll(')', '').trim() : '';
    if (gu == lo || (en.isNotEmpty && en == lo)) return o;
  }
  for (final String o in options) {
    final String ol = o.toLowerCase();
    if (lo.length >= 3 && (ol.startsWith(lo) || ol.contains('$lo '))) return o;
  }
  return t;
}

/// "18250.000" -> "18250", "40.50" -> "40.5".
String cleanNum(String s) {
  final String t = s.trim();
  if (t.isEmpty) return '';
  final double? d = double.tryParse(t.replaceAll(',', ''));
  if (d == null) return t;
  if (d == d.roundToDouble()) return d.round().toString();
  String r = d.toStringAsFixed(3);
  while (r.endsWith('0')) {
    r = r.substring(0, r.length - 1);
  }
  return r;
}
