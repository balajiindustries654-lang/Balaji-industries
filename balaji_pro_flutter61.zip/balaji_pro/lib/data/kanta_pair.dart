import 'serial_decode.dart' show SettledWeight;

// ======================================================================
// Weights from the weighbridge cable -> which vehicle is it?
//  - the cable only carries the weight, not the vehicle number
//  - a vehicle that is waiting for the weighbridge has chits, so its net weight is about known (chit weight +- tolerance)
//  - gross (loaded, first) minus tare (empty, later) must give that net weight: if exactly one pair of weights and
//    exactly one waiting vehicle fit each other, it is that vehicle
//  - anything that is not clear-cut (two vehicles fit, two pairs fit) is left for the person
//  - pure Dart (no Flutter, no network): the rules can be tested alone
// ======================================================================

/// A vehicle that has chits but no weighbridge entry yet.
class PairTrip {
  final String key;
  final String vehicle;
  final double chitKg;

  /// Allowed difference between the chit weight and the weighbridge net weight (kg).
  final double tol;
  final DateTime chitAt;
  const PairTrip(this.key, this.vehicle, this.chitKg, this.tol, this.chitAt);
}

/// One clear-cut fit: these two weights are the loaded and the empty weight of this vehicle.
class AutoPair {
  final SettledWeight gross;
  final SettledWeight tare;
  final PairTrip trip;
  const AutoPair(this.gross, this.tare, this.trip);

  double get net => gross.kg - tare.kg;

  /// Weighbridge net minus chit weight.
  double get diff => net - trip.chitKg;
}

/// Longest time between the loaded and the empty weighing of one vehicle.
const int kPairMaxGapMin = 8 * 60;

/// Weights older than this are not looked at.
const int kPairMaxAgeMin = 14 * 60;

/// A net weight below this is not a load.
const double kPairMinNet = 500;

/// The loaded weighing may be this much earlier than the chit (clocks, order of work).
const int kPairChitSlackMin = 3 * 60;

/// All clear-cut fits among the weights that are not used yet. Weights: any order.
List<AutoPair> autoPairs(List<SettledWeight> weights, List<PairTrip> trips, DateTime now) {
  final List<SettledWeight> pool = <SettledWeight>[
    for (final SettledWeight w in weights)
      if (!w.used && now.difference(w.at).inMinutes <= kPairMaxAgeMin) w,
  ];
  pool.sort((SettledWeight a, SettledWeight b) => a.at.compareTo(b.at));
  final List<(int, int, int)> hits = <(int, int, int)>[]; // pool index gross, pool index tare, trip index
  for (int i = 0; i < pool.length; i++) {
    final SettledWeight g = pool[i];
    for (int j = i + 1; j < pool.length; j++) {
      final SettledWeight t = pool[j];
      if (t.kg >= g.kg) continue; // the loaded weight is the bigger one and comes first
      if (g.stay != 0 && g.stay == t.stay) continue; // same stay on the platform
      final int gap = t.at.difference(g.at).inMinutes;
      if (gap < 1 || gap > kPairMaxGapMin) continue;
      final double net = g.kg - t.kg;
      if (net < kPairMinNet) continue;
      for (int k = 0; k < trips.length; k++) {
        final PairTrip p = trips[k];
        if (p.chitKg <= 0) continue;
        if ((net - p.chitKg).abs() > p.tol) continue;
        if (g.at.isBefore(p.chitAt.subtract(const Duration(minutes: kPairChitSlackMin)))) continue;
        hits.add((i, j, k));
      }
    }
  }
  final Map<int, int> byTrip = <int, int>{};
  final Map<int, int> byWeight = <int, int>{};
  for (final (int, int, int) h in hits) {
    byTrip[h.$3] = (byTrip[h.$3] ?? 0) + 1;
    byWeight[h.$1] = (byWeight[h.$1] ?? 0) + 1;
    byWeight[h.$2] = (byWeight[h.$2] ?? 0) + 1;
  }
  final List<AutoPair> out = <AutoPair>[];
  for (final (int, int, int) h in hits) {
    if (byTrip[h.$3] != 1 || byWeight[h.$1] != 1 || byWeight[h.$2] != 1) continue;
    out.add(AutoPair(pool[h.$1], pool[h.$2], trips[h.$3]));
  }
  return out;
}
