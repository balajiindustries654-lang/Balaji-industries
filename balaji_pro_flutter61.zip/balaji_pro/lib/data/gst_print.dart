import '../core/fmt.dart';
import 'gst.dart';

// ======================================================================
// Printable / shareable forms of a GST bill (always English - it is a legal paper)
// ======================================================================

String _e(String s) => s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');

String _m(double v) => grp(v, dec: 2);

String _q(double v) => v == v.roundToDouble() ? grp(v) : grp(v, dec: 2);

String _per(String basis) {
  switch (basis) {
    case 'mann':
      return '20 KG';
    case 'qtl':
      return 'Qtl';
    case 'nos':
      return 'Nos';
  }
  return 'KG';
}

String _nl(String s) => _e(s).replaceAll('\n', '<br>');

/// A4 page of the bill. It opens in the browser and asks to print (Save as PDF works too).
String gstHtml(GstInv i, GstFirm f) {
  final GstCalc c = i.calc;
  final bool tax = i.isTax;
  final String title = tax ? 'TAX INVOICE' : 'BILL OF SUPPLY';
  final StringBuffer b = StringBuffer();
  b.write('<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">');
  b.write('<title>${_e(title)} ${_e(i.no)}</title><style>');
  b.write('@page{size:A4;margin:10mm}*{box-sizing:border-box}');
  b.write('body{font-family:Arial,"Noto Sans Gujarati","Nirmala UI",sans-serif;font-size:12px;color:#111;margin:0;padding:12px;background:#fff}');
  b.write('.pg{max-width:780px;margin:0 auto;border:1.5px solid #000}');
  b.write('table{width:100%;border-collapse:collapse}td,th{border:1px solid #000;padding:4px 6px;vertical-align:top}');
  b.write('.nb td,.nb th{border:none}.r{text-align:right}.c{text-align:center}.b{font-weight:700}.big{font-size:17px}.sm{font-size:11px}');
  b.write('.t{background:#eee;text-align:center;font-weight:700;letter-spacing:1px;padding:6px;border-bottom:1px solid #000}');
  b.write('.bar{max-width:780px;margin:0 auto 10px;text-align:right}.bar button{font-size:14px;padding:8px 16px;cursor:pointer}');
  b.write('@media print{.bar{display:none}body{padding:0}.pg{border-width:1px}}');
  b.write('</style></head><body>');
  b.write('<div class="bar"><button onclick="window.print()">Print / Save as PDF</button></div>');
  b.write('<div class="pg"><div class="t">${_e(title)}${i.cancelled ? ' &nbsp;(CANCELLED)' : ''}</div>');

  // seller + invoice details
  b.write('<table><tr><td style="width:55%" rowspan="3"><div class="b big">${_e(f.name)}</div>');
  if (f.addr.trim().isNotEmpty) b.write('<div>${_nl(f.addr.trim())}</div>');
  if (f.gstin.trim().isNotEmpty) b.write('<div>GSTIN/UIN: <b>${_e(gstinClean(f.gstin))}</b></div>');
  b.write('<div>State: ${_e(gstStateText(f.state))}</div>');
  if (f.phone.trim().isNotEmpty) b.write('<div>Phone: ${_e(f.phone)}</div>');
  if (f.email.trim().isNotEmpty) b.write('<div>E-mail: ${_e(f.email)}</div>');
  b.write('</td><td>Invoice No.<br><b>${_e(i.no)}</b></td><td>Dated<br><b>${_e(dmy(i.date))}</b></td></tr>');
  b.write('<tr><td>Vehicle No.<br><b>${_e(i.vehicle.isEmpty ? '-' : i.vehicle)}</b></td><td>E-way Bill No.<br><b>${_e(i.ewb.isEmpty ? '-' : i.ewb)}</b></td></tr>');
  b.write('<tr><td>Place of Supply<br><b>${_e(gstStateText(i.place))}</b></td><td>Reverse Charge<br><b>${i.rcm ? 'Yes' : 'No'}</b></td></tr></table>');

  // buyer
  b.write('<table><tr><td style="width:55%"><div class="sm">Buyer (Bill to)</div><div class="b big">${_e(i.party)}</div>');
  if (i.addr.trim().isNotEmpty) b.write('<div>${_nl(i.addr.trim())}</div>');
  if (i.gstin.trim().isNotEmpty) b.write('<div>GSTIN/UIN: <b>${_e(gstinClean(i.gstin))}</b></div>');
  if (i.state.isNotEmpty) b.write('<div>State: ${_e(gstStateText(i.state))}</div>');
  if (i.phone.isNotEmpty) b.write('<div>Phone: ${_e(i.phone)}</div>');
  b.write('</td><td><div class="sm">Note</div><div>${i.note.trim().isEmpty ? '&nbsp;' : _nl(i.note.trim())}</div></td></tr></table>');

  // items
  b.write('<table><tr class="c b"><th style="width:4%">Sl</th><th>Description of Goods</th><th style="width:9%">HSN/SAC</th><th style="width:13%">Quantity</th><th style="width:13%">Rate</th><th style="width:7%">GST %</th><th style="width:15%">Amount (₹)</th></tr>');
  int n = 0;
  for (final GstLine l in i.lines) {
    n++;
    b.write('<tr><td class="c">$n</td><td><b>${_e(l.desc)}</b></td><td class="c">${_e(l.hsn)}</td><td class="r">${_q(l.qty)} ${_e(l.unit)}</td>');
    b.write('<td class="r">${_m(l.rate)} / ${_per(l.basis)}</td><td class="c">${tax ? _q(l.gst) : '-'}</td><td class="r">${_m(l.amount)}</td></tr>');
  }
  b.write('<tr><td colspan="6" class="r b">Taxable value</td><td class="r b">${_m(c.taxable)}</td></tr>');
  if (tax) {
    if (c.cgst > 0) b.write('<tr><td colspan="6" class="r">Output CGST</td><td class="r">${_m(c.cgst)}</td></tr>');
    if (c.sgst > 0) b.write('<tr><td colspan="6" class="r">Output SGST</td><td class="r">${_m(c.sgst)}</td></tr>');
    if (c.igst > 0) b.write('<tr><td colspan="6" class="r">Output IGST</td><td class="r">${_m(c.igst)}</td></tr>');
  }
  if (c.round.abs() >= 0.005) b.write('<tr><td colspan="6" class="r">Round off</td><td class="r">${c.round < 0 ? '(-)' : ''}${_m(c.round.abs())}</td></tr>');
  b.write('<tr><td colspan="6" class="r b big">Total</td><td class="r b big">₹ ${_m(c.total)}</td></tr></table>');

  b.write('<table><tr><td><div class="sm">Amount Chargeable (in words)</div><div class="b">${_e(rupeesInWords(c.total))}</div></td></tr></table>');

  // HSN summary
  if (tax) {
    b.write('<table><tr class="c b"><th rowspan="2">HSN/SAC</th><th rowspan="2">Taxable Value</th>');
    if (i.inter) {
      b.write('<th colspan="2">Integrated Tax</th>');
    } else {
      b.write('<th colspan="2">Central Tax</th><th colspan="2">State Tax</th>');
    }
    b.write('<th rowspan="2">Total Tax Amount</th></tr><tr class="c b">');
    if (i.inter) {
      b.write('<th>Rate</th><th>Amount</th>');
    } else {
      b.write('<th>Rate</th><th>Amount</th><th>Rate</th><th>Amount</th>');
    }
    b.write('</tr>');
    for (final GstHsnRow h in c.hsn) {
      b.write('<tr><td>${_e(h.hsn)}</td><td class="r">${_m(h.taxable)}</td>');
      if (i.inter) {
        b.write('<td class="r">${_q(h.rate)}%</td><td class="r">${_m(h.igst)}</td>');
      } else {
        b.write('<td class="r">${_q(h.rate / 2)}%</td><td class="r">${_m(h.cgst)}</td><td class="r">${_q(h.rate / 2)}%</td><td class="r">${_m(h.sgst)}</td>');
      }
      b.write('<td class="r">${_m(h.tax)}</td></tr>');
    }
    b.write('<tr class="b"><td class="r">Total</td><td class="r">${_m(c.taxable)}</td>');
    if (i.inter) {
      b.write('<td></td><td class="r">${_m(c.igst)}</td>');
    } else {
      b.write('<td></td><td class="r">${_m(c.cgst)}</td><td></td><td class="r">${_m(c.sgst)}</td>');
    }
    b.write('<td class="r">${_m(c.tax)}</td></tr></table>');
    b.write('<table><tr><td><div class="sm">Tax Amount (in words)</div><div class="b">${_e(rupeesInWords(c.tax))}</div></td></tr></table>');
  }

  // bank + signature
  b.write('<table><tr><td style="width:55%">');
  if (f.acc.trim().isNotEmpty || f.upi.trim().isNotEmpty) {
    b.write('<div class="b">Company\'s Bank Details</div>');
    if (f.bank.trim().isNotEmpty) b.write('<div>Bank: ${_e(f.bank)}</div>');
    if (f.acc.trim().isNotEmpty) b.write('<div>A/c No.: <b>${_e(f.acc)}</b></div>');
    if (f.ifsc.trim().isNotEmpty) b.write('<div>IFSC: <b>${_e(f.ifsc)}</b></div>');
    if (f.upi.trim().isNotEmpty) b.write('<div>UPI: ${_e(f.upi)}</div>');
  } else {
    b.write('&nbsp;');
  }
  b.write('<div style="margin-top:8px" class="sm"><b>Declaration</b><br>${_nl(f.terms.trim().isEmpty ? 'We declare that this invoice shows the actual price of the goods described and that all particulars are true and correct.' : f.terms.trim())}</div>');
  b.write('</td><td class="r"><div>for <b>${_e(f.name)}</b></div><div style="height:60px"></div><div>Authorised Signatory</div></td></tr></table>');
  b.write('<div class="c sm" style="padding:4px;border-top:1px solid #000">This is a Computer Generated Invoice</div></div>');
  b.write('<script>window.onload=function(){setTimeout(function(){window.print()},500)}</script></body></html>');
  return b.toString();
}

/// Short plain text of the bill (WhatsApp / SMS / copy).
String gstText(GstInv i, GstFirm f) {
  final GstCalc c = i.calc;
  final StringBuffer b = StringBuffer();
  b.writeln('*${f.name}*');
  if (f.gstin.trim().isNotEmpty) b.writeln('GSTIN: ${gstinClean(f.gstin)}');
  b.writeln('${i.isTax ? 'Tax Invoice' : 'Bill of Supply'} ${i.no}${i.cancelled ? ' (CANCELLED)' : ''}');
  b.writeln('Date: ${dmy(i.date)}');
  b.writeln('To: ${i.party}${i.gstin.trim().isEmpty ? '' : ' (GSTIN ${gstinClean(i.gstin)})'}');
  if (i.vehicle.isNotEmpty) b.writeln('Vehicle: ${i.vehicle}');
  b.writeln('');
  int n = 0;
  for (final GstLine l in i.lines) {
    n++;
    b.writeln('$n) ${l.desc}${l.hsn.isEmpty ? '' : ' (HSN ${l.hsn})'}');
    b.writeln('   ${_q(l.qty)} ${l.unit} x ₹${_m(l.rate)} / ${_per(l.basis)} = ₹${_m(l.amount)}${i.isTax ? ' + GST ${_q(l.gst)}%' : ''}');
  }
  b.writeln('');
  b.writeln('Taxable: ₹${_m(c.taxable)}');
  if (i.isTax) {
    if (c.cgst > 0) b.writeln('CGST: ₹${_m(c.cgst)}');
    if (c.sgst > 0) b.writeln('SGST: ₹${_m(c.sgst)}');
    if (c.igst > 0) b.writeln('IGST: ₹${_m(c.igst)}');
  }
  if (c.round.abs() >= 0.005) b.writeln('Round off: ${c.round < 0 ? '-' : ''}₹${_m(c.round.abs())}');
  b.writeln('*Total: ₹${_m(c.total)}*');
  b.writeln(rupeesInWords(c.total));
  if (f.acc.trim().isNotEmpty) {
    b.writeln('');
    b.writeln('Bank: ${f.bank} · A/c ${f.acc}${f.ifsc.trim().isEmpty ? '' : ' · IFSC ${f.ifsc}'}');
  }
  if (f.upi.trim().isNotEmpty) b.writeln('UPI: ${f.upi}');
  return b.toString().trim();
}

/// One line per bill, ready for the CA (Excel opens it).
String gstCsv(List<GstInv> list) {
  final StringBuffer b = StringBuffer('Invoice No,Date,Firm,Type,Party,GSTIN,Place of supply,Taxable value,CGST,SGST,IGST,Round off,Invoice value,Status\n');
  for (final GstInv i in list) {
    final GstCalc c = i.calc;
    final List<String> cells = <String>[
      i.no,
      dayText(i.date),
      i.firm,
      i.isTax ? 'Tax Invoice' : 'Bill of Supply',
      i.party,
      gstinClean(i.gstin),
      gstStateText(i.place),
      c.taxable.toStringAsFixed(2),
      c.cgst.toStringAsFixed(2),
      c.sgst.toStringAsFixed(2),
      c.igst.toStringAsFixed(2),
      c.round.toStringAsFixed(2),
      c.total.toStringAsFixed(2),
      i.cancelled ? 'Cancelled' : 'OK',
    ];
    b.writeln(cells.map(csvCell).join(','));
  }
  return b.toString();
}

String dayText(DateTime d) => '${d.year}-${pad2(d.month)}-${pad2(d.day)}';
