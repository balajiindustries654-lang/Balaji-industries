import 'package:flutter/material.dart';
import '../core/i18n.dart';

/// The three Tally companies. Purchases are ONLY taken in [Firm.balaji]
/// (kacha). The two GST firms (paka) carry sales/receipts/payments only.
enum Firm { balaji, patel, shreenathji }

const List<String> _firmTitles = <String>['Balaji New', 'Patel Enterprises', 'Shreenathji Enterprises'];
const List<String> _firmShort = <String>['Balaji', 'Patel', 'Shreenathji'];
const List<String> _firmTone = <String>['teal', 'violet', 'amber'];

extension FirmX on Firm {
  String get title => _firmTitles[index];
  String get short => _firmShort[index];
  String get tone => _firmTone[index];
  bool get paka => this != Firm.balaji;
  String get kindLabel => paka ? bi('પાકું · GST', 'Paka · GST') : bi('કાચું', 'Kacha');
  Color get color {
    if (this == Firm.balaji) return const Color(0xFF087F83);
    if (this == Firm.patel) return const Color(0xFF6C4FC9);
    return const Color(0xFFE8A33D);
  }
}

String gradeName(int g, {bool shortName = false}) {
  if (shortName) {
    return <String>[bi('જાડી', 'Bold'), bi('ઝીણી', 'Java'), bi('દાણા', 'Kernel')][g];
  }
  return <String>[bi('જાડી (Bold)', 'Bold'), bi('ઝીણી (Java)', 'Java'), bi('દાણા (Kernel)', 'Kernel')][g];
}

String godownName(int g) => bi('ગોડાઉન ${g + 1}', 'Godown ${g + 1}');

class Party {
  final int id;
  final String name;
  final String kind; // farmer | broker | buyer
  final String village;
  final String phone;
  final double creditLimit;
  final double opening; // + => they owe us (Dr), - => we owe them (Cr)
  const Party(this.id, this.name, this.kind, this.village, this.phone, this.creditLimit, this.opening);
}

class Entry {
  final int no;
  final DateTime dt;
  final Party farmer;
  final Party? broker;
  final String vehicle;
  final String village;
  final int g; // grade index
  final int godown;
  final int bags;
  final double gross;
  final double hava;
  final double rate; // per 20 kg (1 mann)
  final double amount;
  final double paid;
  final String mode; // cash | bank | upi
  const Entry({
    required this.no,
    required this.dt,
    required this.farmer,
    required this.broker,
    required this.vehicle,
    required this.village,
    required this.g,
    required this.godown,
    required this.bags,
    required this.gross,
    required this.hava,
    required this.rate,
    required this.amount,
    required this.paid,
    required this.mode,
  });

  double get net => gross - hava;
  double get mann => net / 20;
  double get due => amount - paid;
  String get grade => gradeName(g);
  String get status => due <= 0.5 ? 'paid' : (paid <= 0.5 ? 'due' : 'part');
  double get commission => broker == null ? 0 : (net / 20 * 2).roundToDouble(); // ₹2 per mann
}

class Voucher {
  final int id;
  final Firm firm;
  final DateTime date;
  final String type; // Sales | Purchase | Receipt | Payment | Journal | Contra
  final String no;
  final String party; // main particulars
  final String dr;
  final String cr;
  final double amount;
  final double gst;
  final String narration;
  final String? ref;
  final bool cash;
  final int grade; // -1 when not a stock voucher
  final double kg;
  const Voucher({
    required this.id,
    required this.firm,
    required this.date,
    required this.type,
    required this.no,
    required this.party,
    required this.dr,
    required this.cr,
    required this.amount,
    this.gst = 0,
    this.narration = '',
    this.ref,
    this.cash = false,
    this.grade = -1,
    this.kg = 0,
  });

  double get total => amount + gst;
}

class LedgerAcc {
  final Firm firm;
  final String name;
  final String group;
  double opening = 0; // + Dr / - Cr
  double dr = 0;
  double cr = 0;
  LedgerAcc(this.firm, this.name, this.group);
  double get closing => opening + dr - cr;
}

class StockRow {
  final int godown;
  final int g;
  final double kg;
  final double rate; // per 20 kg
  const StockRow(this.godown, this.g, this.kg, this.rate);
  double get bags => kg / 35;
  double get value => kg / 20 * rate;
}

class AlertItem {
  final String tone; // rose | amber | blue | green
  final String icon;
  final String title;
  final String sub;
  final String route;
  final Object? arg;
  const AlertItem(this.tone, this.icon, this.title, this.sub, this.route, [this.arg]);
}

class AgeBuckets {
  double b0 = 0; // 0-30
  double b1 = 0; // 31-60
  double b2 = 0; // 61-90
  double b3 = 0; // 90+
  double get total => b0 + b1 + b2 + b3;
  void add(int days, double amt) {
    if (days <= 30) {
      b0 += amt;
    } else if (days <= 60) {
      b1 += amt;
    } else if (days <= 90) {
      b2 += amt;
    } else {
      b3 += amt;
    }
  }
}
