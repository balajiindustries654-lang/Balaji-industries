import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../widgets/printer.dart' show openFileOnPc;
import 'bank.dart';
import 'contra.dart';
import 'debit.dart';
import 'gst.dart';
import 'live_store.dart';
import 'offline.dart';
import 'owner_docs.dart';
import 'trade.dart';
import 'trading.dart';

// ======================================================================
// Laptop copy
//   Everything the owner enters is saved on the online server (Supabase) AND on the device (the app's own
//   offline copy). On the laptop there is also a plain file the owner can see and copy:
//     Documents\Balaji Pro Backup\balaji-backup-YYYY-MM-DD.json
//   It is written by itself a short while after every change (one file per day, all of them in that one folder
//   and none deleted by itself, like TallyPrime) and can be written by hand from the Backup screen.
//   A copy can be restored from the same screen.
// ======================================================================

String _encodeJob(Object? o) => jsonEncode(o);
Object? _decodeJob(String s) => jsonDecode(s);

class BackupFile {
  final String name;
  final String path;
  final int bytes;
  final DateTime at;
  const BackupFile(this.name, this.path, this.bytes, this.at);
}

class LaptopBackup {
  /// Goes up after every finished backup / change of the setting, so screens can redraw.
  static final ValueNotifier<int> tick = ValueNotifier<int>(0);
  static DateTime? lastAt;
  static String lastPath = '';
  static int lastBytes = 0;
  static String lastError = '';
  static bool running = false;
  static bool auto = true;
  static int keepDays = 0; // 0 = keep all copies, like Tally
  static String customDir = '';
  static bool _started = false;
  static Timer? _timer;
  static int _lastHash = 0;
  static int _lastLen = 0;
  static Directory? _dir;

  /// The file copy is for the Windows / Linux / Mac app. The phone keeps the server copy and its own offline copy.
  static bool get supported => Platform.isWindows || Platform.isLinux || Platform.isMacOS;

  /// Every shared document of the owner.
  static List<SyncDoc> docs() => <SyncDoc>[prefDoc, rateDoc, payDoc, expDoc, saleDoc, procDoc, bookDoc, todoDoc, noteDoc, gstDoc, tradeDoc, bankDoc, debitDoc, contraDoc];

  static Future<void> start() async {
    if (_started || !supported) return;
    _started = true;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      auto = p.getBool('lb_auto') ?? true;
      keepDays = p.getInt('lb_keep') ?? 0;
      customDir = p.getString('lb_dir') ?? '';
    } catch (_) {}
    live.addListener(_touch);
    for (final SyncDoc d in docs()) {
      d.addListener(_touch);
    }
    _touch();
  }

  static void _touch() {
    if (!auto || !supported) return;
    _timer?.cancel();
    _timer = Timer(const Duration(seconds: 40), () {
      unawaited(backupNow());
    });
  }

  static Future<void> setAuto(bool v) async {
    auto = v;
    tick.value++;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setBool('lb_auto', v);
    } catch (_) {}
    if (v) _touch();
  }

  static Future<Directory?> folder() async {
    if (_dir != null) return _dir;
    try {
      Directory d;
      if (customDir.trim().isNotEmpty) {
        d = Directory(customDir.trim());
      } else {
        final Directory base = await getApplicationDocumentsDirectory();
        d = Directory('${base.path}${Platform.pathSeparator}Balaji Pro Backup');
      }
      if (!await d.exists()) await d.create(recursive: true);
      _dir = d;
      return d;
    } catch (e) {
      lastError = '$e';
      return null;
    }
  }

  /// A folder chosen by the owner (e.g. D:\Balaji Data). Empty = Documents\Balaji Pro Backup. Returns false when the folder cannot be used.
  static Future<bool> setFolder(String path) async {
    final String old = customDir;
    final Directory? oldDir = _dir;
    customDir = path.trim();
    _dir = null;
    final Directory? d = await folder();
    if (d == null) {
      customDir = old;
      _dir = oldDir;
      return false;
    }
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setString('lb_dir', customDir);
    } catch (_) {}
    _lastHash = 0;
    lastAt = null;
    lastPath = '';
    tick.value++;
    _touch();
    return true;
  }

  static String _base(String p) {
    final int i = p.lastIndexOf(Platform.pathSeparator);
    return i < 0 ? p : p.substring(i + 1);
  }

  static String _stamp(DateTime n) => '${n.year}-${n.month < 10 ? '0' : ''}${n.month}-${n.day < 10 ? '0' : ''}${n.day}';

  static String _stampFull(DateTime n) {
    String two(int v) => v < 10 ? '0$v' : '$v';
    return '${_stamp(n)}-${two(n.hour)}${two(n.minute)}${two(n.second)}';
  }

  /// Writes the copy now. [tag] 'before-restore' makes a separate safety file. Returns the file path (null when nothing was written).
  static Future<String?> backupNow({String tag = ''}) async {
    if (!supported || !live.isAdmin || running) return null;
    if (live.loadedAt == null && tag.isEmpty) return null;
    running = true;
    lastError = '';
    try {
      final Directory? d = await folder();
      if (d == null) return null;
      for (final SyncDoc x in docs()) {
        try {
          await x.ensure();
        } catch (_) {}
      }
      Object? entries;
      try {
        entries = await OfflineStore.read('${live.uid}_live');
      } catch (_) {}
      final Map<String, dynamic> out = <String, dynamic>{
        'app': 'Balaji Pro',
        'company': 'Balaji Industries',
        'docs': <String, dynamic>{for (final SyncDoc x in docs()) x.key: x.data},
        'entries': entries,
      };
      final String body = await compute(_encodeJob, out);
      final DateTime now = DateTime.now();
      final int h = body.hashCode;
      if (tag.isEmpty && h == _lastHash && body.length == _lastLen && lastAt != null) {
        return lastPath; // nothing changed since the last copy
      }
      // the time is added at the end by hand, so it does not count as a change
      final String text = '${body.substring(0, body.length - 1)},"at":"${now.toIso8601String()}"}';
      final String name = tag.isEmpty ? 'balaji-backup-${_stamp(now)}.json' : '$tag-${_stampFull(now)}.json';
      final File f = File('${d.path}${Platform.pathSeparator}$name');
      if (tag.isEmpty && await f.exists()) {
        final int old = await f.length();
        if (old > 4000 && text.length < old * 0.5) {
          lastError = 'skipped: the new copy is much smaller than today\'s copy';
          return null;
        }
      }
      final File tmp = File('${f.path}.tmp');
      await tmp.writeAsString(text, flush: true);
      if (await f.exists()) await f.delete();
      await tmp.rename(f.path);
      if (tag.isEmpty) {
        _lastHash = h;
        _lastLen = body.length;
        lastAt = now;
        lastPath = f.path;
        lastBytes = text.length;
      }
      await _prune(d);
      return f.path;
    } catch (e) {
      lastError = '$e';
      return null;
    } finally {
      running = false;
      tick.value++;
    }
  }

  /// Like TallyPrime, every copy stays in the one folder and nothing is deleted by itself ([keepDays] = 0).
  /// The owner may ask to keep only the last 30 / 90 / 365 days.
  static Future<void> _prune(Directory d) async {
    if (keepDays <= 0) return;
    final DateTime limit = DateTime.now().subtract(Duration(days: keepDays));
    final String limitName = 'balaji-backup-${_stamp(limit)}.json';
    await for (final FileSystemEntity e in d.list()) {
      if (e is! File) continue;
      final String n = _base(e.path);
      if (n.startsWith('balaji-backup-') && n.endsWith('.json') && n.compareTo(limitName) < 0) {
        try {
          await e.delete();
        } catch (_) {}
      }
    }
  }

  /// Keep every copy of the last [days] days (0 = keep all, nothing is deleted).
  static Future<void> setKeepDays(int days) async {
    keepDays = days;
    tick.value++;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setInt('lb_keep', days);
    } catch (_) {}
    final Directory? d = await folder();
    if (d != null) await _prune(d);
  }

  /// The copies on the laptop, newest first.
  static Future<List<BackupFile>> files() async {
    final List<BackupFile> out = <BackupFile>[];
    final Directory? d = await folder();
    if (d == null) return out;
    try {
      await for (final FileSystemEntity e in d.list()) {
        if (e is! File) continue;
        final String n = _base(e.path);
        if (!n.endsWith('.json')) continue;
        final FileStat st = await e.stat();
        out.add(BackupFile(n, e.path, st.size, st.modified));
      }
    } catch (_) {}
    out.sort((BackupFile a, BackupFile b) => b.at.compareTo(a.at));
    return out;
  }

  /// Puts the documents of a copy back (and so also on the online server). A safety copy of the present data is written first.
  /// Returns how many documents were restored.
  static Future<int> restore(String path) async {
    final File f = File(path.trim());
    if (!await f.exists()) throw const FormatException('File not found');
    final String text = await f.readAsString();
    final Object? j = await compute(_decodeJob, text);
    if (j is! Map || j['docs'] is! Map) throw const FormatException('This is not a Balaji Pro copy');
    await backupNow(tag: 'before-restore');
    final Map<dynamic, dynamic> m = j['docs'] as Map<dynamic, dynamic>;
    int n = 0;
    for (final SyncDoc d in docs()) {
      final Object? v = m[d.key];
      if (v is! Map) continue;
      d.data = Map<String, dynamic>.from(v);
      await d.save();
      n++;
    }
    _lastHash = 0;
    tick.value++;
    return n;
  }

  static Future<bool> openFolder() async {
    final Directory? d = await folder();
    if (d == null) return false;
    return openFileOnPc(d.path);
  }
}

/// Called once at start: from then on the laptop copy follows every change.
void laptopBackupStart() {
  unawaited(LaptopBackup.start());
}
