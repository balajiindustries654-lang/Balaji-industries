import '../core/fmt.dart';
import '../core/i18n.dart';
import 'insights.dart' show dayKey;
import 'live_models.dart' show dbl, nameKey, dayOf;
import 'owner_docs.dart';
import 'trade.dart' show addSale, saleDoc;

// ======================================================================
// GST bills (tax invoice / bill of supply)
//  - one shared document `flutter_gst`: { firms: [...], inv: [...], seq: { "firm|26-27": last number } }
//  - the numbers are counted per firm and per financial year, so two phones never give the same number
// ======================================================================

final SyncDoc gstDoc = SyncDoc('flutter_gst');

double r2(double v) => (v * 100).roundToDouble() / 100;

/// GST state codes: code, name.
const List<List<String>> kGstStates = <List<String>>[
  <String>['01', 'Jammu & Kashmir'],
  <String>['02', 'Himachal Pradesh'],
  <String>['03', 'Punjab'],
  <String>['04', 'Chandigarh'],
  <String>['05', 'Uttarakhand'],
  <String>['06', 'Haryana'],
  <String>['07', 'Delhi'],
  <String>['08', 'Rajasthan'],
  <String>['09', 'Uttar Pradesh'],
  <String>['10', 'Bihar'],
  <String>['11', 'Sikkim'],
  <String>['12', 'Arunachal Pradesh'],
  <String>['13', 'Nagaland'],
  <String>['14', 'Manipur'],
  <String>['15', 'Mizoram'],
  <String>['16', 'Tripura'],
  <String>['17', 'Meghalaya'],
  <String>['18', 'Assam'],
  <String>['19', 'West Bengal'],
  <String>['20', 'Jharkhand'],
  <String>['21', 'Odisha'],
  <String>['22', 'Chhattisgarh'],
  <String>['23', 'Madhya Pradesh'],
  <String>['24', 'Gujarat'],
  <String>['26', 'Dadra & Nagar Haveli and Daman & Diu'],
  <String>['27', 'Maharashtra'],
  <String>['29', 'Karnataka'],
  <String>['30', 'Goa'],
  <String>['32', 'Kerala'],
  <String>['33', 'Tamil Nadu'],
  <String>['34', 'Puducherry'],
  <String>['36', 'Telangana'],
  <String>['37', 'Andhra Pradesh'],
  <String>['38', 'Ladakh'],
];

String gstStateName(String code) {
  for (final List<String> s in kGstStates) {
    if (s[0] == code) return s[1];
  }
  return '';
}

/// "24 Gujarat" for a state code ('' when unknown).
String gstStateText(String code) {
  final String n = gstStateName(code);
  return n.isEmpty ? code : '$code - $n';
}

final RegExp _gstinRe = RegExp(r'^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$');

String gstinClean(String s) => s.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');

/// The GSTIN has the right shape and its last (check) character is correct.
bool gstinOk(String raw) {
  final String g = gstinClean(raw);
  if (!_gstinRe.hasMatch(g)) return false;
  const String cs = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  int sum = 0;
  for (int i = 0; i < 14; i++) {
    final int v = cs.indexOf(g[i]);
    if (v < 0) return false;
    final int p = v * (i % 2 == 0 ? 1 : 2);
    sum += p ~/ 36 + p % 36;
  }
  final int chk = (36 - sum % 36) % 36;
  return cs[chk] == g[14];
}

/// First two digits of a GSTIN = the state code ('' when not a GSTIN).
String gstinState(String raw) {
  final String g = gstinClean(raw);
  if (g.length < 2) return '';
  final String c = g.substring(0, 2);
  return gstStateName(c).isEmpty ? '' : c;
}

/// 26-27 for any day from 1 Apr 2026 to 31 Mar 2027.
String gstFy(DateTime d) {
  final int y = d.month >= 4 ? d.year : d.year - 1;
  return '${pad2(y % 100)}-${pad2((y + 1) % 100)}';
}

// ------------------------------------------------------------------- firms
class GstFirm {
  final String id;
  String name;
  String gstin;
  String addr;
  String state; // 2 digit code
  String phone;
  String email;
  String bank; // bank name and branch
  String acc;
  String ifsc;
  String upi;
  String prefix; // invoice number starts with this, e.g. BI/
  String terms;
  GstFirm(
    this.id, {
    this.name = '',
    this.gstin = '',
    this.addr = '',
    this.state = '24',
    this.phone = '',
    this.email = '',
    this.bank = '',
    this.acc = '',
    this.ifsc = '',
    this.upi = '',
    this.prefix = '',
    this.terms = '',
  });

  factory GstFirm.fromMap(Map<String, dynamic> m) {
    String s(String k) => '${m[k] ?? ''}';
    return GstFirm(
      s('id'),
      name: s('name'),
      gstin: s('gstin'),
      addr: s('addr'),
      state: s('state').isEmpty ? '24' : s('state'),
      phone: s('phone'),
      email: s('email'),
      bank: s('bank'),
      acc: s('acc'),
      ifsc: s('ifsc'),
      upi: s('upi'),
      prefix: s('prefix'),
      terms: s('terms'),
    );
  }

  Map<String, dynamic> toMap() => <String, dynamic>{
        'id': id,
        'name': name,
        'gstin': gstin,
        'addr': addr,
        'state': state,
        'phone': phone,
        'email': email,
        'bank': bank,
        'acc': acc,
        'ifsc': ifsc,
        'upi': upi,
        'prefix': prefix,
        'terms': terms,
      };

  bool get ready => gstinClean(gstin).isNotEmpty;
}

List<GstFirm> _seedFirms() => <GstFirm>[
      GstFirm('balaji', name: 'Balaji Industries', prefix: 'BI/'),
      GstFirm('patel', name: 'Patel Enterprises', prefix: 'PE/'),
      GstFirm('shreenathji', name: 'Shreenathji Enterprises', prefix: 'SE/'),
    ];

List<GstFirm> gstFirms() {
  final List<GstFirm> out = <GstFirm>[];
  for (final Map<String, dynamic> m in gstDoc.list('firms')) {
    out.add(GstFirm.fromMap(m));
  }
  if (out.isEmpty) out.addAll(_seedFirms());
  return out;
}

GstFirm gstFirmOf(String id) {
  for (final GstFirm f in gstFirms()) {
    if (f.id == id) return f;
  }
  final List<GstFirm> all = gstFirms();
  return all.isEmpty ? GstFirm(id, name: id) : all.first;
}

Future<void> saveGstFirm(GstFirm f) {
  return gstDoc.commit(() {
    final List<Map<String, dynamic>> l = gstDoc.list('firms');
    if (l.isEmpty) {
      for (final GstFirm s in _seedFirms()) {
        l.add(s.toMap());
      }
    }
    final int i = l.indexWhere((Map<String, dynamic> m) => '${m['id']}' == f.id);
    if (i >= 0) {
      l[i] = f.toMap();
    } else {
      l.add(f.toMap());
    }
  });
}

// ------------------------------------------------------------------- lines
/// How the rate of a line is counted: code, Gujarati, English.
const List<List<String>> kGstBasis = <List<String>>[
  <String>['mann', '₹ / 20 KG', '₹ / 20 KG'],
  <String>['kg', '₹ / KG', '₹ / KG'],
  <String>['qtl', '₹ / ક્વિન્ટલ', '₹ / Quintal'],
  <String>['nos', '₹ / નંગ', '₹ / unit'],
];

String gstBasisLabel(String code) {
  for (final List<String> b in kGstBasis) {
    if (b[0] == code) return bi(b[1], b[2]);
  }
  return code;
}

double gstDivisor(String basis) => basis == 'mann' ? 20 : (basis == 'qtl' ? 100 : 1);

/// Items offered as one tap: Gujarati name, English name (printed), HSN, GST %, rate basis, unit.
/// The GST % is only a starting point - the owner confirms the rate with the CA.
const List<List<String>> kGstPresets = <List<String>>[
  <String>['મગફળી દાણા', 'Groundnut kernels', '1202', '5', 'mann', 'KG'],
  <String>['મગફળી (ફોતરાં સાથે)', 'Groundnut in shell', '1202', '5', 'mann', 'KG'],
  <String>['સીંગતેલ', 'Groundnut oil', '1508', '5', 'kg', 'KG'],
  <String>['મગફળી ખોળ', 'Groundnut oil cake', '2305', '0', 'qtl', 'KG'],
  <String>['એરંડા', 'Castor seed', '1207', '5', 'mann', 'KG'],
  <String>['ભાડું / સેવા', 'Freight / service', '9965', '5', 'nos', 'Nos'],
];

class GstLine {
  String desc;
  String hsn;
  double qty;
  String unit;
  double rate;
  String basis;
  double gst;
  GstLine({this.desc = '', this.hsn = '', this.qty = 0, this.unit = 'KG', this.rate = 0, this.basis = 'mann', this.gst = 5});

  /// Taxable value of the line.
  double get amount => r2(qty * rate / gstDivisor(basis));

  factory GstLine.fromMap(Map<String, dynamic> m) {
    return GstLine(
      desc: '${m['d'] ?? ''}',
      hsn: '${m['h'] ?? ''}',
      qty: dbl(m['q']),
      unit: '${m['u'] ?? 'KG'}',
      rate: dbl(m['r']),
      basis: '${m['b'] ?? 'mann'}',
      gst: dbl(m['g']),
    );
  }

  Map<String, dynamic> toMap() => <String, dynamic>{'d': desc.trim(), 'h': hsn.trim(), 'q': qty, 'u': unit, 'r': rate, 'b': basis, 'g': gst};
}

class GstHsnRow {
  final String hsn;
  final double rate;
  double taxable = 0;
  double cgst = 0;
  double sgst = 0;
  double igst = 0;
  GstHsnRow(this.hsn, this.rate);
  double get tax => cgst + sgst + igst;
}

class GstCalc {
  final double taxable;
  final double cgst;
  final double sgst;
  final double igst;
  final double round; // added to reach a whole rupee
  final double total;
  final List<GstHsnRow> hsn;
  const GstCalc(this.taxable, this.cgst, this.sgst, this.igst, this.round, this.total, this.hsn);
  double get tax => cgst + sgst + igst;
}

/// Tax of all lines. [inter] = the goods go to another state (IGST instead of CGST + SGST), [tax] false = bill of supply.
GstCalc calcGst(List<GstLine> lines, {required bool inter, required bool tax}) {
  double taxable = 0;
  double cg = 0;
  double sg = 0;
  double ig = 0;
  final Map<String, GstHsnRow> m = <String, GstHsnRow>{};
  for (final GstLine l in lines) {
    final double a = l.amount;
    taxable += a;
    double c = 0;
    double s = 0;
    double i = 0;
    if (tax && l.gst > 0) {
      if (inter) {
        i = r2(a * l.gst / 100);
      } else {
        c = r2(a * l.gst / 200);
        s = c;
      }
    }
    cg += c;
    sg += s;
    ig += i;
    final GstHsnRow r = m.putIfAbsent('${l.hsn}|${tax ? l.gst : 0}', () => GstHsnRow(l.hsn, tax ? l.gst : 0));
    r.taxable += a;
    r.cgst += c;
    r.sgst += s;
    r.igst += i;
  }
  final double raw = r2(taxable + cg + sg + ig);
  final double total = raw.roundToDouble();
  return GstCalc(r2(taxable), r2(cg), r2(sg), r2(ig), r2(total - raw), total, m.values.toList());
}

// ---------------------------------------------------------------- invoices
class GstInv {
  final String id;
  final String firm;
  final String no;
  final DateTime date;
  final String kind; // tax | bos (bill of supply, no tax)
  final String party;
  final String gstin;
  final String addr;
  final String state; // buyer state code
  final String phone;
  final String place; // place of supply (state code)
  final bool inter;
  final String vehicle;
  final String ewb;
  final String note;
  final bool rcm;
  final List<GstLine> lines;
  final String status; // ok | cancel
  final DateTime at;
  GstInv({
    required this.id,
    required this.firm,
    required this.no,
    required this.date,
    required this.kind,
    required this.party,
    required this.gstin,
    required this.addr,
    required this.state,
    required this.phone,
    required this.place,
    required this.inter,
    required this.vehicle,
    required this.ewb,
    required this.note,
    required this.rcm,
    required this.lines,
    required this.status,
    required this.at,
  });

  late final GstCalc calc = calcGst(lines, inter: inter, tax: kind == 'tax');

  bool get cancelled => status == 'cancel';
  bool get isTax => kind == 'tax';
  bool get b2b => gstinClean(gstin).isNotEmpty;

  /// Total quantity of the lines counted in KG-like units.
  double get qty {
    double q = 0;
    for (final GstLine l in lines) {
      q += l.qty;
    }
    return q;
  }

  String get firstDesc => lines.isEmpty ? '' : lines.first.desc;
}

List<GstInv> gstInvoices() {
  final List<GstInv> out = <GstInv>[];
  for (final Map<String, dynamic> m in gstDoc.list('inv')) {
    final DateTime? d = DateTime.tryParse('${m['date'] ?? ''}');
    if (d == null) continue;
    final List<GstLine> lines = <GstLine>[];
    final Object? raw = m['lines'];
    if (raw is List) {
      for (final Object? e in raw) {
        if (e is Map) lines.add(GstLine.fromMap(Map<String, dynamic>.from(e)));
      }
    }
    out.add(GstInv(
      id: '${m['id'] ?? ''}',
      firm: '${m['firm'] ?? ''}',
      no: '${m['no'] ?? ''}',
      date: dayOf(d),
      kind: '${m['kind'] ?? 'tax'}',
      party: '${m['party'] ?? ''}',
      gstin: '${m['gstin'] ?? ''}',
      addr: '${m['addr'] ?? ''}',
      state: '${m['state'] ?? ''}',
      phone: '${m['phone'] ?? ''}',
      place: '${m['place'] ?? ''}',
      inter: m['inter'] == true,
      vehicle: '${m['vehicle'] ?? ''}',
      ewb: '${m['ewb'] ?? ''}',
      note: '${m['note'] ?? ''}',
      rcm: m['rcm'] == true,
      lines: lines,
      status: '${m['status'] ?? 'ok'}',
      at: DateTime.tryParse('${m['at'] ?? ''}') ?? d,
    ));
  }
  out.sort((GstInv a, GstInv b) {
    final int c = b.date.compareTo(a.date);
    return c != 0 ? c : b.at.compareTo(a.at);
  });
  return out;
}

/// The next number a firm will get on [date] (shown on the form; the real number is taken when saving).
String gstNextNo(GstFirm f, DateTime date) {
  final Object? seq = gstDoc.data['seq'];
  final String fy = gstFy(date);
  int n = 0;
  if (seq is Map) n = dbl(seq['${f.id}|$fy']).round();
  return _fmtNo(f.prefix, fy, n + 1);
}

String _fmtNo(String prefix, String fy, int n) => '$prefix$fy/${n < 10 ? '00' : (n < 100 ? '0' : '')}$n';

/// Saves a bill and returns its number. [toKhata] also writes it as a sale in the buyer ledger.
Future<String> addGstInvoice({
  required GstFirm firm,
  required DateTime date,
  required String kind,
  required String party,
  String gstin = '',
  String addr = '',
  String state = '',
  String phone = '',
  required String place,
  required bool inter,
  String vehicle = '',
  String ewb = '',
  String note = '',
  bool rcm = false,
  required List<GstLine> lines,
  String noOverride = '',
  bool toKhata = false,
}) async {
  String no = '';
  final String id = '${DateTime.now().microsecondsSinceEpoch}';
  await gstDoc.commit(() {
    final String fy = gstFy(date);
    final Map<String, dynamic> seq = gstDoc.map('seq');
    final String sk = '${firm.id}|$fy';
    if (noOverride.trim().isNotEmpty) {
      no = noOverride.trim();
    } else {
      final int n = dbl(seq[sk]).round() + 1;
      seq[sk] = n;
      no = _fmtNo(firm.prefix, fy, n);
    }
    final List<Map<String, dynamic>> l = gstDoc.list('inv');
    l.add(<String, dynamic>{
      'id': id,
      'firm': firm.id,
      'no': no,
      'date': dayKey(date),
      'kind': kind,
      'party': party.trim(),
      'gstin': gstinClean(gstin),
      'addr': addr.trim(),
      'state': state,
      'phone': phone.replaceAll(RegExp(r'[^0-9]'), ''),
      'place': place,
      'inter': inter,
      'vehicle': vehicle.trim(),
      'ewb': ewb.trim(),
      'note': note.trim(),
      'rcm': rcm,
      'lines': <Map<String, dynamic>>[for (final GstLine x in lines) x.toMap()],
      'status': 'ok',
      'at': DateTime.now().toIso8601String(),
    });
  });
  if (toKhata) {
    final GstCalc c = calcGst(lines, inter: inter, tax: kind == 'tax');
    double kg = 0;
    for (final GstLine x in lines) {
      if (x.unit.toUpperCase() == 'KG') kg += x.qty;
    }
    // item stays empty so the stock is not touched by the bill (the sale entry is for the buyer ledger only)
    await addSale(
      buyer: party,
      kind: 'sale',
      date: date,
      amt: c.total,
      kg: kg,
      vehicle: vehicle,
      bill: no,
      note: 'GST ${lines.isEmpty ? '' : lines.first.desc}',
    );
  }
  return no;
}

Future<void> cancelGstInvoice(GstInv i) async {
  await gstDoc.commit(() {
    for (final Map<String, dynamic> m in gstDoc.list('inv')) {
      if ('${m['id']}' == i.id) m['status'] = 'cancel';
    }
  });
  await _dropLinkedSale(i);
}

Future<void> removeGstInvoice(GstInv i) async {
  await gstDoc.commit(() {
    gstDoc.list('inv').removeWhere((Map<String, dynamic> m) => '${m['id']}' == i.id);
  });
  await _dropLinkedSale(i);
}

Future<void> _dropLinkedSale(GstInv i) {
  return saleDoc.commit(() {
    final String k = nameKey(i.party);
    saleDoc.list('items').removeWhere((Map<String, dynamic> m) => '${m['kind']}' == 'sale' && '${m['bill']}' == i.no && nameKey('${m['buyer']}') == k);
  });
}

/// Buyers used on earlier bills (newest first) - so the address and GSTIN need not be typed again.
class GstParty {
  final String name;
  final String gstin;
  final String addr;
  final String state;
  final String phone;
  const GstParty(this.name, this.gstin, this.addr, this.state, this.phone);
}

List<GstParty> gstParties() {
  final Map<String, GstParty> m = <String, GstParty>{};
  for (final GstInv i in gstInvoices()) {
    final String k = nameKey(i.party);
    if (k.isEmpty || m.containsKey(k)) continue;
    m[k] = GstParty(i.party, i.gstin, i.addr, i.state, i.phone);
  }
  return m.values.toList();
}

// ---------------------------------------------------------- amount in words
const List<String> _ones = <String>[
  '',
  'One',
  'Two',
  'Three',
  'Four',
  'Five',
  'Six',
  'Seven',
  'Eight',
  'Nine',
  'Ten',
  'Eleven',
  'Twelve',
  'Thirteen',
  'Fourteen',
  'Fifteen',
  'Sixteen',
  'Seventeen',
  'Eighteen',
  'Nineteen',
];

const List<String> _tens = <String>['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

String _two(int n) => n < 20 ? _ones[n] : '${_tens[n ~/ 10]}${n % 10 == 0 ? '' : ' ${_ones[n % 10]}'}';

String _three(int n) {
  if (n >= 100) return '${_ones[n ~/ 100]} Hundred${n % 100 == 0 ? '' : ' ${_two(n % 100)}'}';
  return _two(n);
}

String _wordsInt(int n) {
  if (n == 0) return 'Zero';
  final List<String> p = <String>[];
  final int cr = n ~/ 10000000;
  final int lk = (n ~/ 100000) % 100;
  final int th = (n ~/ 1000) % 100;
  final int rest = n % 1000;
  if (cr > 0) p.add('${_three(cr)} Crore');
  if (lk > 0) p.add('${_two(lk)} Lakh');
  if (th > 0) p.add('${_two(th)} Thousand');
  if (rest > 0) p.add(_three(rest));
  return p.join(' ');
}

/// 12500.5 -> "Indian Rupees Twelve Thousand Five Hundred and Fifty Paise Only"
String rupeesInWords(double v) {
  final double a = v.abs();
  final int rs = a.floor();
  final int ps = ((a - rs) * 100).round();
  final int rs2 = ps >= 100 ? rs + 1 : rs;
  final int ps2 = ps >= 100 ? 0 : ps;
  final StringBuffer b = StringBuffer('Indian Rupees ${_wordsInt(rs2)}');
  if (ps2 > 0) b.write(' and ${_two(ps2)} Paise');
  b.write(' Only');
  return b.toString();
}

/// Bill number -> total with GST, for the bills that are not cancelled.
Map<String, double> gstBillTotals() {
  final Map<String, double> m = <String, double>{};
  for (final GstInv i in gstInvoices()) {
    if (!i.cancelled) m[i.no] = i.calc.total;
  }
  return m;
}
