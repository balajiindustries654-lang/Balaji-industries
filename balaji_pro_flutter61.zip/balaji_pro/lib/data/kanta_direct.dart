import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart' show kIsWeb;

// ======================================================================
// Direct ("RAW") printing of a slip to a dot-matrix printer on the Windows laptop (Epson LX-310 and friends).
//
// The normal way (the browser's print window) sends a PICTURE of the page through the Windows driver: slow on a 9-pin printer,
// grey letters, and a whole 11-inch page is pushed out for a 3-inch slip. Here the plain TEXT goes to the printer with a few
// ESC/P codes (start, page length, wide heading, form feed): it prints at full speed with the printer's own font, and
// every slip ends exactly at the same place of the continuous paper.
//
// How: a small PowerShell script (made here, nothing to install) opens the printer queue with the datatype RAW and writes the bytes.
// Nothing in this file touches the app's data. When it fails the caller prints through the browser instead.
// ======================================================================

/// One printer queue of Windows.
class WinPrinter {
  final String name;
  final bool isDefault;
  final String port;
  const WinPrinter(this.name, this.isDefault, this.port);
}

/// Keeps printable ASCII only (a dot-matrix printer has no Gujarati letters): anything else becomes '?'.
String asciiOnly(String s) {
  final StringBuffer b = StringBuffer();
  for (final int c in s.runes) {
    if (c == 0x20AC || c == 0x20B9) {
      b.write('Rs');
    } else if (c >= 32 && c <= 126) {
      b.writeCharCode(c);
    } else if (c == 9) {
      b.write(' ');
    } else {
      b.write('?');
    }
  }
  return b.toString();
}

/// The bytes for the printer: ESC/P text of a slip.
///  [pageLines] 0 = the printer's own page length; otherwise the page is that many lines (1 line = 1/6 inch; 18 = 3 inch,
///  33 = 5.5 inch) and every slip ends with a form feed to the top of the next page.
///  [bold] = double-strike (darker, good for carbon copies).
///  The first line (the heading) is printed double width.
Uint8List escpBytes(String text, {int pageLines = 0, bool bold = false, bool wideHeading = true, int width = 46}) {
  final List<int> o = <int>[];
  void esc(List<int> codes) {
    o.add(0x1B);
    o.addAll(codes);
  }

  // \u0001 / \u0002 in a line switch the big (double width) letters on / off - the Matrix slip prints the weights that way
  void line(String s) {
    final StringBuffer seg = StringBuffer();
    void flush() {
      if (seg.isNotEmpty) o.addAll(ascii.encode(asciiOnly(seg.toString())));
      seg.clear();
    }

    for (final int c in s.runes) {
      if (c == 1 || c == 2) {
        flush();
        esc(<int>[0x57, c == 1 ? 1 : 0]); // ESC W n  double width on / off
      } else {
        seg.writeCharCode(c);
      }
    }
    flush();
    o.addAll(<int>[0x0D, 0x0A]);
  }

  esc(<int>[0x40]); // ESC @  reset
  esc(<int>[0x50]); // ESC P  10 characters per inch (46 characters = 4.6 inch)
  if (pageLines > 0) esc(<int>[0x43, pageLines.clamp(1, 127)]); // ESC C n  page length in lines
  if (bold) esc(<int>[0x45]); // ESC E  emphasized
  final List<String> lines = const LineSplitter().convert(text);
  for (int i = 0; i < lines.length; i++) {
    final String s = lines[i];
    if (i == 0 && wideHeading && s.trim().isNotEmpty && s.trim().length * 2 <= width) {
      final String h = asciiOnly(s.trim());
      final int pad = (width - h.length * 2) ~/ 2;
      o.addAll(ascii.encode(' ' * pad));
      esc(<int>[0x57, 1]); // ESC W 1  double width on
      o.addAll(ascii.encode(h));
      esc(<int>[0x57, 0]); // ESC W 0  off
      o.addAll(<int>[0x0D, 0x0A]);
    } else {
      line(s);
    }
  }
  if (bold) esc(<int>[0x46]); // ESC F  emphasized off
  o.add(0x0C); // form feed: to the top of the next slip
  return Uint8List.fromList(o);
}

/// The C# helper inside the PowerShell script (opens the queue as RAW and writes the bytes).
const String _csharp = r'''
using System;
using System.Runtime.InteropServices;
public class BalajiRawPrn {
  [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
  public class DOCINFOW {
    [MarshalAs(UnmanagedType.LPWStr)] public string pDocName;
    [MarshalAs(UnmanagedType.LPWStr)] public string pOutputFile;
    [MarshalAs(UnmanagedType.LPWStr)] public string pDataType;
  }
  [DllImport("winspool.drv", EntryPoint = "OpenPrinterW", SetLastError = true, CharSet = CharSet.Unicode, ExactSpelling = true)]
  public static extern bool OpenPrinter(string szPrinter, out IntPtr hPrinter, IntPtr pd);
  [DllImport("winspool.drv", EntryPoint = "ClosePrinter", SetLastError = true, ExactSpelling = true)]
  public static extern bool ClosePrinter(IntPtr hPrinter);
  [DllImport("winspool.drv", EntryPoint = "StartDocPrinterW", SetLastError = true, CharSet = CharSet.Unicode, ExactSpelling = true)]
  public static extern bool StartDocPrinter(IntPtr hPrinter, int level, [In, MarshalAs(UnmanagedType.LPStruct)] DOCINFOW di);
  [DllImport("winspool.drv", EntryPoint = "EndDocPrinter", SetLastError = true, ExactSpelling = true)]
  public static extern bool EndDocPrinter(IntPtr hPrinter);
  [DllImport("winspool.drv", EntryPoint = "StartPagePrinter", SetLastError = true, ExactSpelling = true)]
  public static extern bool StartPagePrinter(IntPtr hPrinter);
  [DllImport("winspool.drv", EntryPoint = "EndPagePrinter", SetLastError = true, ExactSpelling = true)]
  public static extern bool EndPagePrinter(IntPtr hPrinter);
  [DllImport("winspool.drv", EntryPoint = "WritePrinter", SetLastError = true, ExactSpelling = true)]
  public static extern bool WritePrinter(IntPtr hPrinter, IntPtr pBytes, int dwCount, out int dwWritten);

  public static string Send(string printer, byte[] data) {
    IntPtr h;
    if (!OpenPrinter(printer, out h, IntPtr.Zero)) {
      return "The printer '" + printer + "' could not be opened (Windows error " + Marshal.GetLastWin32Error() + ")";
    }
    string err = "";
    DOCINFOW di = new DOCINFOW();
    di.pDocName = "Balaji Kanta slip";
    di.pDataType = "RAW";
    if (StartDocPrinter(h, 1, di)) {
      if (StartPagePrinter(h)) {
        IntPtr p = Marshal.AllocCoTaskMem(data.Length);
        Marshal.Copy(data, 0, p, data.Length);
        int written = 0;
        if (!WritePrinter(h, p, data.Length, out written) || written != data.Length) {
          err = "Sending to the printer failed (Windows error " + Marshal.GetLastWin32Error() + ")";
        }
        Marshal.FreeCoTaskMem(p);
        EndPagePrinter(h);
      } else {
        err = "StartPage failed (Windows error " + Marshal.GetLastWin32Error() + ")";
      }
      EndDocPrinter(h);
    } else {
      err = "StartDoc failed (Windows error " + Marshal.GetLastWin32Error() + ")";
    }
    ClosePrinter(h);
    return err;
  }
}

// Writes straight to an Epson printer on USB through the "USB Printing Support" device that Windows makes for every USB printer -
// this works even when no Epson driver (and so no printer queue) is installed on the laptop.
public class BalajiUsbPrn {
  [StructLayout(LayoutKind.Sequential)]
  struct SPDID { public int cbSize; public Guid Guid; public int Flags; public IntPtr Reserved; }
  [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode, EntryPoint = "SetupDiGetClassDevsW")]
  static extern IntPtr SetupDiGetClassDevs(ref Guid g, IntPtr e, IntPtr h, int flags);
  [DllImport("setupapi.dll", SetLastError = true)]
  static extern bool SetupDiEnumDeviceInterfaces(IntPtr set, IntPtr info, ref Guid g, int idx, ref SPDID d);
  [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode, EntryPoint = "SetupDiGetDeviceInterfaceDetailW")]
  static extern bool SetupDiGetDeviceInterfaceDetail(IntPtr set, ref SPDID d, IntPtr detail, int size, out int req, IntPtr info);
  [DllImport("setupapi.dll")]
  static extern bool SetupDiDestroyDeviceInfoList(IntPtr set);
  [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode, EntryPoint = "CreateFileW")]
  static extern Microsoft.Win32.SafeHandles.SafeFileHandle CreateFile(string n, uint access, uint share, IntPtr sec, uint disp, uint flags, IntPtr t);
  [DllImport("kernel32.dll", SetLastError = true)]
  static extern bool WriteFile(Microsoft.Win32.SafeHandles.SafeFileHandle h, byte[] b, int n, out int written, IntPtr ov);

  public static string[] Paths() {
    Guid g = new Guid("28d78fad-5a12-11d1-ae5b-0000f803a8c2");
    System.Collections.ArrayList l = new System.Collections.ArrayList();
    IntPtr set = SetupDiGetClassDevs(ref g, IntPtr.Zero, IntPtr.Zero, 0x12);
    if (set == (IntPtr)(-1)) return new string[0];
    try {
      for (int i = 0; i < 16; i++) {
        SPDID d = new SPDID();
        d.cbSize = Marshal.SizeOf(typeof(SPDID));
        if (!SetupDiEnumDeviceInterfaces(set, IntPtr.Zero, ref g, i, ref d)) break;
        int req;
        SetupDiGetDeviceInterfaceDetail(set, ref d, IntPtr.Zero, 0, out req, IntPtr.Zero);
        if (req <= 0) continue;
        IntPtr buf = Marshal.AllocHGlobal(req);
        try {
          Marshal.WriteInt32(buf, IntPtr.Size == 8 ? 8 : 6);
          if (SetupDiGetDeviceInterfaceDetail(set, ref d, buf, req, out req, IntPtr.Zero)) {
            l.Add(Marshal.PtrToStringUni((IntPtr)((long)buf + 4)));
          }
        } finally { Marshal.FreeHGlobal(buf); }
      }
    } finally { SetupDiDestroyDeviceInfoList(set); }
    return (string[])l.ToArray(typeof(string));
  }

  // the first Epson (USB vendor 04B8) printer, or ""
  public static string Epson() {
    foreach (string p in Paths()) {
      if (p != null && p.ToLower().Contains("vid_04b8")) return p;
    }
    return "";
  }

  // "" = printed, NOUSB = no Epson on USB, anything else = the reason
  public static string Send(byte[] data) {
    string pick = Epson();
    if (pick == "") return "NOUSB";
    Microsoft.Win32.SafeHandles.SafeFileHandle h = CreateFile(pick, 0x40000000, 3, IntPtr.Zero, 3, 0, IntPtr.Zero);
    if (h.IsInvalid) return "The USB printer could not be opened (Windows error " + Marshal.GetLastWin32Error() + ")";
    try {
      int pos = 0;
      while (pos < data.Length) {
        int n = Math.Min(4096, data.Length - pos);
        byte[] chunk = new byte[n];
        Array.Copy(data, pos, chunk, 0, n);
        int w = 0;
        if (!WriteFile(h, chunk, n, out w, IntPtr.Zero) || w <= 0) return "Sending to the USB printer failed (Windows error " + Marshal.GetLastWin32Error() + ")";
        pos += w;
      }
      return "";
    } finally { h.Close(); }
  }
}
''';

/// The PowerShell script that prints a file of bytes (public for tests). Prints "OK:<printer>" or "ERR:<reason>".
/// It finds the printer by itself: the one named in -Printer, any queue called LX-310 / EPSON, then an Epson on USB (no driver needed),
/// and only when nothing like that exists the Windows default printer (if it is a real one, not a PDF / XPS maker).
String printScript() => '''
param([string]\$Printer, [string]\$DataFile)
\$ErrorActionPreference = 'Stop'
try {
  Add-Type -TypeDefinition @'
$_csharp
'@
  \$bytes = [System.IO.File]::ReadAllBytes(\$DataFile)
  \$errs = New-Object System.Collections.ArrayList
  \$names = New-Object System.Collections.ArrayList
  \$all = @()
  try { \$all = @(Get-CimInstance -ClassName Win32_Printer) } catch { }
  if (-not [string]::IsNullOrEmpty(\$Printer)) { [void]\$names.Add(\$Printer) }
  foreach (\$q in \$all) {
    if ((\$q.Name -match 'LX[- ]?310|EPSON|ESC/P') -and -not \$names.Contains(\$q.Name)) { [void]\$names.Add(\$q.Name) }
  }
  foreach (\$n in \$names) {
    \$r = [BalajiRawPrn]::Send(\$n, \$bytes)
    if (\$r -eq '') { Write-Output ('OK:' + \$n); exit 0 }
    [void]\$errs.Add(\$r)
  }
  \$u = [BalajiUsbPrn]::Send(\$bytes)
  if (\$u -eq '') { Write-Output 'OK:Epson (USB, direct)'; exit 0 }
  if (\$u -ne 'NOUSB') { [void]\$errs.Add(\$u) }
  if (\$names.Count -eq 0) {
    foreach (\$q in \$all) {
      if (\$q.Default -and (\$q.Name -notmatch 'PDF|XPS|OneNote|Fax|Microsoft|Send To')) {
        \$r = [BalajiRawPrn]::Send(\$q.Name, \$bytes)
        if (\$r -eq '') { Write-Output ('OK:' + \$q.Name); exit 0 }
        [void]\$errs.Add(\$r)
      }
    }
  }
  if (\$errs.Count -eq 0) { Write-Output 'ERR:NOPRINTER'; exit 3 }
  Write-Output ('ERR:' + (\$errs -join ' | '))
  exit 2
} catch {
  Write-Output ('ERR:' + \$_.Exception.Message)
  exit 1
}
''';

/// Looks whether an Epson printer is on USB (prints "USB:1" or "USB:0").
String usbScript() => '''
\$ErrorActionPreference = 'Stop'
try {
  Add-Type -TypeDefinition @'
$_csharp
'@
  if ([BalajiUsbPrn]::Epson() -ne '') { Write-Output 'USB:1' } else { Write-Output 'USB:0' }
} catch {
  Write-Output 'USB:0'
}
''';

const String _listScript = r'''
Get-CimInstance -ClassName Win32_Printer | ForEach-Object { Write-Output ($_.Name + '|' + $_.Default + '|' + $_.PortName) }
''';

/// Direct printing on the Windows laptop.
class DirectPrint {
  /// The name of the PowerShell program (tests replace it).
  static String shell = 'powershell';

  /// Runs a program (tests replace it).
  static Future<ProcessResult> Function(String exe, List<String> args) runner = (String exe, List<String> args) => Process.run(exe, args);

  /// Pretend to be on Windows (tests).
  static bool forTest = false;

  static bool get supported => forTest || (!kIsWeb && Platform.isWindows);

  static Directory _tmp() => Directory.systemTemp;

  /// The printer queues of Windows (empty when none / not Windows).
  static Future<List<WinPrinter>> printers() async {
    if (!supported) return const <WinPrinter>[];
    try {
      final ProcessResult r = await runner(shell, <String>['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', _listScript]).timeout(const Duration(seconds: 20));
      final List<WinPrinter> out = <WinPrinter>[];
      for (final String l in const LineSplitter().convert('${r.stdout}')) {
        final List<String> p = l.trim().split('|');
        if (p.length < 2 || p[0].trim().isEmpty) continue;
        out.add(WinPrinter(p[0].trim(), p[1].trim().toLowerCase() == 'true', p.length > 2 ? p[2].trim() : ''));
      }
      return out;
    } catch (_) {
      return const <WinPrinter>[];
    }
  }

  /// Is an Epson printer plugged in on USB (it can be used even without a Windows driver)?
  static Future<bool> usbEpson() async {
    if (!supported) return false;
    final String stamp = '${DateTime.now().microsecondsSinceEpoch}';
    final File ps = File('${_tmp().path}${Platform.pathSeparator}balaji-kanta-usb-$stamp.ps1');
    try {
      await ps.writeAsString('\uFEFF${usbScript()}', flush: true);
      final ProcessResult r = await runner(shell, <String>['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', ps.path]).timeout(const Duration(seconds: 25));
      return '${r.stdout}'.contains('USB:1');
    } catch (_) {
      return false;
    } finally {
      try {
        if (await ps.exists()) await ps.delete();
      } catch (_) {}
    }
  }

  /// Sends the bytes to the printer ([printer] empty = find it by itself). Returns '' when done, otherwise the reason.
  static Future<String> send(Uint8List data, {String printer = ''}) async {
    if (!supported) return 'Direct printing works only on the Windows laptop';
    final String stamp = '${DateTime.now().microsecondsSinceEpoch}';
    final File bin = File('${_tmp().path}${Platform.pathSeparator}balaji-kanta-$stamp.bin');
    final File ps = File('${_tmp().path}${Platform.pathSeparator}balaji-kanta-$stamp.ps1');
    try {
      await bin.writeAsBytes(data, flush: true);
      // a script file (not -Command): the C# text has quotes and line breaks
      await ps.writeAsString('﻿${printScript()}', flush: true);
      final ProcessResult r = await runner(shell, <String>['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', ps.path, if (printer.trim().isNotEmpty) ...<String>['-Printer', printer.trim()], '-DataFile', bin.path]).timeout(const Duration(seconds: 40));
      final String out = '${r.stdout}'.trim();
      for (final String l in const LineSplitter().convert(out)) {
        if (l.startsWith('OK:')) return '';
        if (l.startsWith('ERR:')) return l.substring(4).trim();
      }
      final String e = '${r.stderr}'.replaceAll(RegExp(r'\s+'), ' ').trim();
      return e.isEmpty ? 'The printer did not answer (PowerShell code ${r.exitCode})' : e;
    } on TimeoutException {
      return 'The printer did not answer in time';
    } catch (e) {
      return '$e';
    } finally {
      try {
        if (await bin.exists()) await bin.delete();
        if (await ps.exists()) await ps.delete();
      } catch (_) {}
    }
  }
}
