import 'dart:async';
import 'contra.dart';
import 'live_store.dart';
import 'owner_docs.dart';
import 'trade.dart';

// ======================================================================
// Voucher numbers (like TallyPrime: every voucher type has its own running number)
//   PAY payment to a farmer (and advance)   RCT money received (from a farmer or a buyer)
//   SAL sale                                JRN journal / old balance
//   EXP expense                             INC income / money received
//   CNT credit note (sales return)          DNT debit note (purchase return)
// The number is written into the entry ('no') when the entry is made. Older entries that have none are
// numbered once, oldest first, by [ensureVoucherNumbers].
// ======================================================================

/// Voucher type of a payment-document entry. An 'open' entry with journal type 'dn' is a Debit Note (purchase return).
String payCode(String kind, {String jt = ''}) => kind == 'recv' ? 'RCT' : (kind == 'open' ? (jt == 'dn' ? 'DNT' : 'JRN') : 'PAY');

/// Voucher type of a sale-document entry. An 'open' entry with journal type 'cn' is a Credit Note (sales return).
String saleCode(String kind, {String jt = ''}) => kind == 'sale' ? 'SAL' : (kind == 'recv' ? 'RCT' : (jt == 'cn' ? 'CNT' : 'JRN'));

String expCode(String kind) => kind == 'in' ? 'INC' : 'EXP';

int vnoOf(Object? v) {
  if (v is num) return v.round();
  return int.tryParse('${v ?? ''}') ?? 0;
}

Iterable<Map<dynamic, dynamic>> _maps(SyncDoc d) sync* {
  final Object? v = d.data['items'];
  if (v is List) {
    for (final Object? e in v) {
      if (e is Map) yield e;
    }
  }
}

/// Highest number used so far for a voucher type.
int maxVoucherNo(String code) {
  int best = 0;
  for (final Map<dynamic, dynamic> m in _maps(payDoc)) {
    if (payCode('${m['kind'] ?? 'pay'}', jt: '${m['jt'] ?? ''}') != code) continue;
    final int n = vnoOf(m['no']);
    if (n > best) best = n;
  }
  for (final Map<dynamic, dynamic> m in _maps(saleDoc)) {
    if (saleCode('${m['kind'] ?? 'sale'}', jt: '${m['jt'] ?? ''}') != code) continue;
    final int n = vnoOf(m['no']);
    if (n > best) best = n;
  }
  for (final Map<dynamic, dynamic> m in _maps(expDoc)) {
    if (expCode('${m['kind'] ?? 'out'}') != code) continue;
    final int n = vnoOf(m['no']);
    if (n > best) best = n;
  }
  return best;
}

/// The number the next voucher of this type gets.
int nextVoucherNo(String code) => maxVoucherNo(code) + 1;

bool _anyUnnumbered() {
  for (final Map<dynamic, dynamic> m in _maps(payDoc)) {
    if (vnoOf(m['no']) <= 0) return true;
  }
  for (final Map<dynamic, dynamic> m in _maps(saleDoc)) {
    if (vnoOf(m['no']) <= 0) return true;
  }
  for (final Map<dynamic, dynamic> m in _maps(expDoc)) {
    if (vnoOf(m['no']) <= 0) return true;
  }
  return false;
}

/// True when some entry still has no voucher number.
bool voucherNumbersPending() => _anyUnnumbered();

bool _stamping = false;

Future<void> _stampDoc(SyncDoc d, String Function(Map<String, dynamic>) codeOf) async {
  bool need = false;
  for (final Map<dynamic, dynamic> m in _maps(d)) {
    if (vnoOf(m['no']) <= 0) {
      need = true;
      break;
    }
  }
  if (!need) return;
  await d.commit(() {
    final List<Map<String, dynamic>> items = d.list('items');
    final List<Map<String, dynamic>> todo = <Map<String, dynamic>>[
      for (final Map<String, dynamic> m in items)
        if (vnoOf(m['no']) <= 0) m,
    ];
    String keyOf(Map<String, dynamic> m) => '${m['at'] ?? m['date'] ?? ''}|${m['id'] ?? ''}';
    todo.sort((Map<String, dynamic> a, Map<String, dynamic> b) => keyOf(a).compareTo(keyOf(b)));
    final Map<String, int> top = <String, int>{};
    for (final Map<String, dynamic> m in todo) {
      final String c = codeOf(m);
      final int n = (top[c] ?? maxVoucherNo(c)) + 1;
      top[c] = n;
      m['no'] = n;
    }
  });
}

/// Numbers every older entry that has no voucher number yet (once; owner only).
Future<void> ensureVoucherNumbers() async {
  if (_stamping || !live.isAdmin) return;
  _stamping = true;
  try {
    for (final SyncDoc d in <SyncDoc>[payDoc, saleDoc, expDoc, contraDoc]) {
      await d.ensure();
    }
    if (!_anyUnnumbered()) return;
    await _stampDoc(payDoc, (Map<String, dynamic> m) => payCode('${m['kind'] ?? 'pay'}', jt: '${m['jt'] ?? ''}'));
    await _stampDoc(saleDoc, (Map<String, dynamic> m) => saleCode('${m['kind'] ?? 'sale'}', jt: '${m['jt'] ?? ''}'));
    await _stampDoc(expDoc, (Map<String, dynamic> m) => expCode('${m['kind'] ?? 'out'}'));
  } catch (_) {
    // numbering is only a label - it is tried again next time
  } finally {
    _stamping = false;
  }
}

bool _numStarted = false;
Timer? _numTimer;

/// Called once at start: a few seconds after the owner's data is loaded (and after every change) the old entries get their numbers.
void voucherNumberingStart() {
  if (_numStarted) return;
  _numStarted = true;
  void kick() {
    if (!live.isAdmin) return;
    if (_numTimer?.isActive ?? false) return;
    _numTimer = Timer(const Duration(seconds: 6), () {
      unawaited(ensureVoucherNumbers());
    });
  }

  live.addListener(kick);
  kick();
}
