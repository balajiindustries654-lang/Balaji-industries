import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'kanta_log.dart';
import 'kanta_slip.dart';
import 'kanta_usb.dart';
import 'live_store.dart';
import 'slip_png.dart';
import 'supa.dart' show SupaError;

// ======================================================================
// Slips that go out on WhatsApp by themselves (WhatsApp Business Platform, through the Supabase function `send-whatsapp`).
// Nobody presses anything per vehicle: the second weight makes a job, this queue sends it, and sends it again later when the internet
// is down. The queue is kept on the laptop, so a restart loses nothing. Every result is written to kanta-wa-YYYY-MM.csv.
// ======================================================================

/// One person a slip goes to: the 10 digit number and whether it is the fixed number of the mill.
class SlipTo {
  final String number;
  final bool mill;
  const SlipTo(this.number, this.mill);
}

/// Everybody a finished slip goes to on WhatsApp, in this order:
///  1. the number written at the weighing - or, for a mill vehicle without one, the farmer's number on the chit;
///  2. MILL vehicles only: the fixed mill number(s) of the settings (written once).
/// A road vehicle goes to the number written at the weighing and to nobody else. The same number is never listed twice.
List<SlipTo> slipRecipients(SlipRec r) {
  final List<SlipTo> out = <SlipTo>[];
  final List<String> mill = r.outside ? const <String>[] : KantaLog.millNumbers;
  void add(String n, bool isMill) {
    if (n.isEmpty) return;
    if (out.any((SlipTo t) => t.number == n)) return;
    out.add(SlipTo(n, isMill));
  }

  List<String> typed = KantaLog.parseNumbers(r.mobile);
  if (typed.isEmpty && !r.outside) {
    try {
      typed = KantaLog.parseNumbers(kantaUsb.mobileProvider(r.vehicle));
    } catch (_) {}
  }
  for (final String n in typed) {
    add(n, mill.contains(n));
  }
  for (final String n in mill) {
    add(n, true);
  }
  return out;
}

/// One slip waiting to go out / already gone.
class WaJob {
  final String rst;
  final String vehicle;
  final String to;
  final Map<String, String> vars;
  final int at;

  /// The slip as the printer gets it (see slipEpson) - drawn as a picture when the job is sent; empty: plain writing only.
  final String pic;
  final int picWidth;

  /// wait | sent | failed
  String state;
  int tries;
  int next;
  int doneAt;
  String id;
  String err;

  /// What was sent: 'pic' (the picture), 'text' (plain writing) or '' (not sent yet / old job).
  String how;

  WaJob({required this.rst, required this.vehicle, required this.to, required this.vars, required this.at, this.pic = '', this.picWidth = 46, this.state = 'wait', this.tries = 0, this.next = 0, this.doneAt = 0, this.id = '', this.err = '', this.how = ''});

  Map<String, Object> toJson() => <String, Object>{'rst': rst, 'v': vehicle, 'to': to, 'vars': vars, 'at': at, 'pc': pic, 'pw': picWidth, 's': state, 'n': tries, 'x': next, 'd': doneAt, 'id': id, 'e': err, 'h': how};

  static WaJob? fromJson(Object? j) {
    if (j is! Map) return null;
    try {
      final Map<String, String> vars = <String, String>{};
      final Object? v = j['vars'];
      if (v is Map) v.forEach((Object? k, Object? x) => vars['$k'] = '$x');
      return WaJob(
        rst: '${j['rst'] ?? ''}',
        vehicle: '${j['v'] ?? ''}',
        to: '${j['to'] ?? ''}',
        vars: vars,
        at: (j['at'] as num).toInt(),
        pic: '${j['pc'] ?? ''}',
        picWidth: (j['pw'] as num?)?.toInt() ?? 46,
        state: '${j['s'] ?? 'wait'}',
        tries: (j['n'] as num?)?.toInt() ?? 0,
        next: (j['x'] as num?)?.toInt() ?? 0,
        doneAt: (j['d'] as num?)?.toInt() ?? 0,
        id: '${j['id'] ?? ''}',
        err: '${j['e'] ?? ''}',
        how: '${j['h'] ?? ''}',
      );
    } catch (_) {
      return null;
    }
  }
}

class KantaWa {
  /// Goes up whenever a job or the state changes (screens listen).
  static final ValueNotifier<int> tick = ValueNotifier<int>(0);

  /// Newest first, at most [keep] jobs.
  static final List<WaJob> jobs = <WaJob>[];
  static const int keep = 300;

  /// Not empty: the last answer said the set-up is wrong (token, template ...). New slips then open the chat instead, until a test passes.
  static String setupError = '';

  /// From the last successful test: the WhatsApp number and name that send the slips.
  static String number = '';
  static String name = '';
  static bool tested = false;

  /// How a job is sent. The default calls the Supabase function; tests replace it.
  static Future<Map<String, dynamic>> Function(Map<String, dynamic> body) sender = _liveSend;
  static DateTime Function() clock = DateTime.now;

  /// Waits before the next try after the 1st, 2nd ... failed try (the last one repeats). Tests shorten them.
  static List<Duration> backoff = const <Duration>[Duration(seconds: 30), Duration(minutes: 2), Duration(minutes: 10), Duration(minutes: 30), Duration(hours: 2)];

  /// A slip that could not be sent for this long is given up (the entry shows "failed" and the operator can use the chat).
  static Duration giveUp = const Duration(hours: 24);

  static Timer? _timer;
  static bool _busy = false;
  static bool _loaded = false;

  static Future<Map<String, dynamic>> _liveSend(Map<String, dynamic> body) => live.supa.sendWhatsApp(body);

  /// Automatic sending is on, the set-up was tested once and nothing is known to be wrong.
  static bool get ready => KantaLog.waApi && tested && setupError.isEmpty;

  static int get waiting => jobs.where((WaJob j) => j.state == 'wait').length;
  static int get failed => jobs.where((WaJob j) => j.state == 'failed').length;
  static int get sentToday {
    final DateTime n = clock();
    final int from = DateTime(n.year, n.month, n.day).millisecondsSinceEpoch;
    return jobs.where((WaJob j) => j.state == 'sent' && j.doneAt >= from).length;
  }

  /// The newest job of this slip (a slip can go to several numbers: see [jobsOf]).
  static WaJob? jobOf(String rst) {
    for (final WaJob j in jobs) {
      if (j.rst == rst) return j;
    }
    return null;
  }

  /// Every job of this slip - one per number it goes to.
  static List<WaJob> jobsOf(String rst) => jobs.where((WaJob j) => j.rst == rst).toList();

  static Future<void> load() async {
    if (_loaded) return;
    _loaded = true;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      final String? raw = p.getString('kwa_jobs');
      if (raw != null) {
        final Object? j = jsonDecode(raw);
        if (j is List) {
          for (final Object? e in j) {
            final WaJob? x = WaJob.fromJson(e);
            if (x != null) jobs.add(x);
          }
        }
      }
      tested = p.getBool('kwa_ok') ?? false;
      number = p.getString('kwa_no') ?? '';
      name = p.getString('kwa_nm') ?? '';
    } catch (_) {}
    tick.value++;
    if (waiting > 0) _arm();
  }

  static Future<void> _save() async {
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setString('kwa_jobs', jsonEncode(jobs.map((WaJob j) => j.toJson()).toList()));
    } catch (_) {}
  }

  static Future<void> _saveTest() async {
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setBool('kwa_ok', tested);
      await p.setString('kwa_no', number);
      await p.setString('kwa_nm', name);
    } catch (_) {}
  }

  /// Puts the slip of [r] into the queue (to the 10 digit [phone]) and starts sending. Does nothing a second time for the same slip and number.
  /// The same slip can be queued for several numbers (the driver and the mill): each is its own job.
  static Future<WaJob> submit(SlipRec r, String phone) async {
    await load();
    final String d = phone.replaceAll(RegExp(r'[^0-9]'), '');
    final String to = d.length >= 10 ? d.substring(d.length - 10) : d;
    WaJob? old;
    for (final WaJob x in jobs) {
      if (x.rst == r.rst && x.to == to) {
        old = x;
        break;
      }
    }
    if (old != null && old.state != 'failed') return old;
    final WaJob j = WaJob(
      rst: r.rst,
      vehicle: r.vehicle,
      to: to,
      vars: slipVars(r, style: KantaLog.style),
      at: clock().millisecondsSinceEpoch,
      pic: KantaLog.waPicture ? slipEpson(r, style: KantaLog.style) : '',
      picWidth: slipWidth(KantaLog.style),
    );
    jobs.removeWhere((WaJob x) => x.rst == r.rst && x.to == to);
    jobs.insert(0, j);
    while (jobs.length > keep) {
      jobs.removeLast();
    }
    tick.value++;
    await _save();
    unawaited(pump());
    return j;
  }

  /// Queues the slip for everybody it goes to ([slipRecipients]: the number written at the weighing and - mill vehicles - the fixed mill number).
  static Future<List<WaJob>> submitAll(SlipRec r) async {
    final List<WaJob> out = <WaJob>[];
    for (final SlipTo t in slipRecipients(r)) {
      out.add(await submit(r, t.number));
    }
    return out;
  }

  /// Tries again now: a failed slip goes back into the queue.
  static Future<void> again(WaJob j) async {
    if (j.state == 'sent') return;
    j.state = 'wait';
    j.tries = 0;
    j.next = 0;
    j.err = '';
    tick.value++;
    await _save();
    unawaited(pump());
  }

  static void _arm() {
    _timer ??= Timer.periodic(const Duration(seconds: 15), (Timer t) {
      if (waiting == 0) {
        t.cancel();
        _timer = null;
        return;
      }
      unawaited(pump());
    });
  }

  /// Sends every slip that is due, one after the other.
  static Future<void> pump() async {
    if (_busy) return;
    _busy = true;
    try {
      bool more = true;
      while (more) {
        more = false;
        final int now = clock().millisecondsSinceEpoch;
        // oldest first, so the slips go out in the order of the weighings
        final List<WaJob> due = jobs.where((WaJob j) => j.state == 'wait' && j.next <= now).toList()..sort((WaJob a, WaJob b) => a.at.compareTo(b.at));
        if (due.isEmpty) break;
        final WaJob j = due.first;
        await _try(j);
        more = true;
      }
    } finally {
      _busy = false;
      if (waiting > 0) _arm();
      tick.value++;
    }
  }

  static Future<void> _try(WaJob j) async {
    j.tries++;
    String kind = 'retry';
    String err = '';
    String id = '';
    String how = 'text';
    try {
      final Map<String, dynamic> body = <String, dynamic>{'to': j.to, 'vars': j.vars};
      // the picture of the slip (what the printer prints) - drawn now, so the queue only keeps the small text
      if (j.pic.isNotEmpty && KantaLog.waPicture) body['image'] = base64Encode(slipPng(j.pic, width: j.picWidth));
      final Map<String, dynamic> a = await sender(body);
      if (a['ok'] == true) {
        id = '${a['id'] ?? ''}';
        // only the answer of the new function says 'pic' (an older function ignores the picture and sends the writing)
        if (body.containsKey('image') && a['how'] == 'pic') how = 'pic';
      } else {
        kind = '${a['kind'] ?? 'retry'}';
        err = '${a['error'] ?? 'WhatsApp error'}';
      }
    } on SupaError catch (e) {
      err = e.message;
      // function missing / not allowed: nothing to wait for
      if (e.status == 404 || e.status == 403) kind = 'setup';
    } catch (e) {
      err = '$e';
    }
    final DateTime now = clock();
    if (id.isNotEmpty || (err.isEmpty && kind == 'retry')) {
      j.state = 'sent';
      j.id = id;
      j.how = how;
      j.err = '';
      j.doneAt = now.millisecondsSinceEpoch;
      if (setupError.isNotEmpty) setupError = '';
      await _log(j, how == 'pic' ? 'SENT (PICTURE)' : 'SENT');
    } else if (kind == 'number') {
      j.state = 'failed';
      j.err = err;
      j.doneAt = now.millisecondsSinceEpoch;
      await _log(j, 'NUMBER PROBLEM');
    } else if (kind == 'setup') {
      j.state = 'failed';
      j.err = err;
      j.doneAt = now.millisecondsSinceEpoch;
      setupError = err;
      await _log(j, 'SET-UP PROBLEM');
      // the others would fail the same way: stop trying, they wait for "Send again" after the set-up is fixed
      for (final WaJob o in jobs.where((WaJob x) => x.state == 'wait').toList()) {
        o.state = 'failed';
        o.err = err;
        o.doneAt = now.millisecondsSinceEpoch;
        await _log(o, 'SET-UP PROBLEM');
      }
    } else {
      j.err = err;
      if (now.millisecondsSinceEpoch - j.at > giveUp.inMilliseconds) {
        j.state = 'failed';
        j.doneAt = now.millisecondsSinceEpoch;
        await _log(j, 'GAVE UP');
      } else {
        final Duration w = backoff[(j.tries - 1).clamp(0, backoff.length - 1).toInt()];
        j.next = now.add(w).millisecondsSinceEpoch;
      }
    }
    tick.value++;
    await _save();
  }

  static Future<void> _log(WaJob j, String status) async {
    final DateTime at = clock();
    String two(int n) => n < 10 ? '0$n' : '$n';
    await KantaLog.appendFile(
      'kanta-wa',
      at,
      'Date,Time,RST,Vehicle,To,Status,Tries,Message id,Note',
      '${at.year}-${two(at.month)}-${two(at.day)},${two(at.hour)}:${two(at.minute)},${KantaLog.csv(j.rst)},${KantaLog.csv(j.vehicle)},${KantaLog.csv('91${j.to}')},$status,${j.tries},${KantaLog.csv(j.id)},${KantaLog.csv(j.err)}',
    );
  }

  /// Checks the server set-up without sending anything. Returns '' when everything is fine, else what is wrong.
  static Future<String> test() async {
    try {
      final Map<String, dynamic> a = await sender(<String, dynamic>{'test': true});
      if (a['ok'] == true) {
        tested = true;
        setupError = '';
        number = '${a['number'] ?? ''}';
        name = '${a['name'] ?? ''}';
        await _saveTest();
        tick.value++;
        unawaited(pump());
        return '';
      }
      final String e = '${a['error'] ?? 'WhatsApp error'}';
      tested = false;
      setupError = e;
      await _saveTest();
      tick.value++;
      return e;
    } on SupaError catch (e) {
      tick.value++;
      return e.status == 404 ? 'send-whatsapp is not deployed in Supabase yet' : e.message;
    } catch (e) {
      tick.value++;
      return '$e';
    }
  }

  /// For tests: forget everything in memory.
  static void reset() {
    _timer?.cancel();
    _timer = null;
    _busy = false;
    _loaded = false;
    jobs.clear();
    setupError = '';
    number = '';
    name = '';
    tested = false;
  }
}
