import 'dart:math' as math;
import '../core/fmt.dart';
import '../core/i18n.dart';
import 'engine.dart';
import 'live_models.dart';
import 'live_store.dart';

/// Number crunching on the real data (no UI). Every screen of the
/// insight / operations / tools groups reads from here.

DateTime addDays(DateTime d, int n) => DateTime(d.year, d.month, d.day + n);

int daysBetween(DateTime a, DateTime b) {
  return DateTime.utc(b.year, b.month, b.day).difference(DateTime.utc(a.year, a.month, a.day)).inDays;
}

double c01(double v) => v < 0 ? 0.0 : (v > 1 ? 1.0 : v);

String dayKey(DateTime d) => '${d.year}-${pad2(d.month)}-${pad2(d.day)}';

// ===================================================================== period
class Period {
  final DateTime from; // inclusive
  final DateTime to; // exclusive
  const Period(this.from, this.to);

  bool has(DateTime d) => !d.isBefore(from) && d.isBefore(to);
  int get days => math.max(1, daysBetween(from, to));
  Period get previous => Period(addDays(from, -days), from);
  DateTime get lastDay => addDays(to, -1);
  String get label => days <= 1 ? dmy(from) : '${dm(from)} - ${dmy(lastDay)}';
}

/// A date range chosen with the chips of a RangeBar.
class RangeSel {
  int preset; // 0 today, 1 yesterday, 2 7 days, 3 30 days, 4 this month, 5 last month, 6 custom
  DateTime? cFrom;
  DateTime? cTo;
  RangeSel([this.preset = 2]);

  static List<String> labels() => <String>[
        bi('આજે', 'Today'),
        bi('ગઈકાલે', 'Yesterday'),
        bi('7 દિવસ', '7 days'),
        bi('30 દિવસ', '30 days'),
        bi('આ મહિનો', 'This month'),
        bi('ગયો મહિનો', 'Last month'),
        bi('પીરિયડ…', 'Period…'),
      ];

  Period get period {
    final DateTime t = dayOf(DateTime.now());
    switch (preset) {
      case 0:
        return Period(t, addDays(t, 1));
      case 1:
        return Period(addDays(t, -1), t);
      case 2:
        return Period(addDays(t, -6), addDays(t, 1));
      case 3:
        return Period(addDays(t, -29), addDays(t, 1));
      case 4:
        return Period(DateTime(t.year, t.month, 1), addDays(t, 1));
      case 5:
        return Period(DateTime(t.year, t.month - 1, 1), DateTime(t.year, t.month, 1));
      default:
        final DateTime a = cFrom ?? addDays(t, -6);
        final DateTime b = cTo ?? t;
        return Period(dayOf(a), addDays(dayOf(b), 1));
    }
  }

  RangeSel copy() {
    final RangeSel r = RangeSel(preset);
    r.cFrom = cFrom;
    r.cTo = cTo;
    return r;
  }
}

// ======================================================================= stats
class Stats {
  int chits = 0;
  int kantas = 0;
  int trips = 0;
  int compared = 0;
  int okTrips = 0;
  int diffTrips = 0;
  int noKanta = 0;
  int noChit = 0;
  int problems = 0;
  int bagsIn = 0;
  int bagsOut = 0;
  double chitKg = 0;
  double kantaKg = 0;
  double mChit = 0;
  double mKanta = 0;

  double get ghat => mKanta - mChit;
  double get ghatPct => mChit > 0 ? ghat / mChit * 100 : 0;
  double get avgLoad => trips > 0 ? kantaKg / trips : 0;
}

Stats statsFor(Period p) {
  final Stats s = Stats();
  for (final Chit c in live.chits) {
    if (!p.has(c.at)) continue;
    s.chits++;
    s.chitKg += c.cmpKg;
  }
  for (final Kanta k in live.kantas) {
    if (!p.has(k.at)) continue;
    s.kantas++;
    s.kantaKg += k.kg;
  }
  for (final Trip t in live.trips) {
    if (!p.has(t.at)) continue;
    s.trips++;
    if (t.state == TripState.ok) s.okTrips++;
    if (t.state == TripState.diff) s.diffTrips++;
    if (t.state == TripState.noKanta) s.noKanta++;
    if (t.state == TripState.noChit) s.noChit++;
    if (t.both && t.chitKg > 0 && t.kantaKg > 0) {
      s.compared++;
      s.mChit += t.chitKg;
      s.mKanta += t.kantaKg;
    }
  }
  for (final MaalRow m in live.maals) {
    if (!p.has(m.date)) continue;
    if (m.loading) {
      s.bagsOut += m.bags;
    } else {
      s.bagsIn += m.bags;
    }
  }
  for (final Finding f in live.findings) {
    if (f.sev >= 2 && p.has(f.at) && f.rule != Rule.pattern && !live.isReviewed(f)) s.problems++;
  }
  return s;
}

/// "+12.5%" and whether it went up.
class Delta {
  final String text;
  final bool up;
  final bool flat;
  const Delta(this.text, this.up, this.flat);
}

Delta? deltaOf(double cur, double prev) {
  if (prev.abs() < 0.0001) {
    if (cur.abs() < 0.0001) return null;
    return const Delta('new', true, false);
  }
  final double d = (cur - prev) / prev.abs() * 100;
  if (d.abs() < 0.05) return const Delta('0%', true, true);
  return Delta('${d > 0 ? '+' : '-'}${d.abs().toStringAsFixed(d.abs() < 10 ? 1 : 0)}%', d > 0, false);
}

// ================================================================ daily series
class DayPoint {
  final DateTime day;
  double chitKg = 0;
  double kantaKg = 0;
  double mChit = 0;
  double mKanta = 0;
  int chits = 0;
  int kantas = 0;
  int trips = 0;
  int bad = 0;
  DayPoint(this.day);

  double get ghat => mKanta - mChit;
  double get ghatPct => mChit > 0 ? ghat / mChit * 100 : 0;
}

List<DayPoint> dailySeries(Period p) {
  final int n = p.days;
  final List<DayPoint> out = <DayPoint>[for (int i = 0; i < n; i++) DayPoint(addDays(p.from, i))];
  int idx(DateTime d) => daysBetween(p.from, d);
  for (final Chit c in live.chits) {
    if (!p.has(c.at)) continue;
    final DayPoint d = out[idx(c.at)];
    d.chitKg += c.cmpKg;
    d.chits++;
  }
  for (final Kanta k in live.kantas) {
    if (!p.has(k.at)) continue;
    final DayPoint d = out[idx(k.at)];
    d.kantaKg += k.kg;
    d.kantas++;
  }
  for (final Trip t in live.trips) {
    if (!p.has(t.at)) continue;
    final DayPoint d = out[idx(t.at)];
    d.trips++;
    if (t.problem) d.bad++;
    if (t.both && t.chitKg > 0 && t.kantaKg > 0) {
      d.mChit += t.chitKg;
      d.mKanta += t.kantaKg;
    }
  }
  return out;
}

class WeekPoint {
  final DateTime start;
  double chitKg = 0;
  double kantaKg = 0;
  double mChit = 0;
  double mKanta = 0;
  int trips = 0;
  int bad = 0;
  WeekPoint(this.start);

  double get ghat => mKanta - mChit;
  double get ghatPct => mChit > 0 ? ghat / mChit * 100 : 0;
}

List<WeekPoint> weeklyOf(List<DayPoint> days) {
  final Map<String, WeekPoint> m = <String, WeekPoint>{};
  final List<WeekPoint> out = <WeekPoint>[];
  for (final DayPoint d in days) {
    final DateTime ws = addDays(d.day, -(d.day.weekday - 1));
    final String k = dayKey(ws);
    WeekPoint? w = m[k];
    if (w == null) {
      w = WeekPoint(ws);
      m[k] = w;
      out.add(w);
    }
    w.chitKg += d.chitKg;
    w.kantaKg += d.kantaKg;
    w.mChit += d.mChit;
    w.mKanta += d.mKanta;
    w.trips += d.trips;
    w.bad += d.bad;
  }
  return out;
}

// ================================================================ commodity
class KV {
  final String label;
  final double v;
  final int n;
  const KV(this.label, this.v, this.n);
}

List<KV> commoditySplit(Period p) {
  final Map<String, double> kg = <String, double>{};
  final Map<String, int> cnt = <String, int>{};
  final Map<String, String> lab = <String, String>{};
  for (final Chit c in live.chits) {
    if (!p.has(c.at)) continue;
    final String k = nameKey(c.commodity);
    final String key = k.isEmpty ? '-' : k;
    kg[key] = (kg[key] ?? 0) + c.cmpKg;
    cnt[key] = (cnt[key] ?? 0) + 1;
    lab.putIfAbsent(key, () => c.commodity.isEmpty ? '—' : c.commodity);
  }
  final List<KV> out = <KV>[for (final String k in kg.keys) KV(lab[k] ?? k, kg[k] ?? 0, cnt[k] ?? 0)];
  out.sort((KV a, KV b) => b.v.compareTo(a.v));
  return out;
}

List<GroupRow> topBy(Dim dim, Period p) {
  final List<Trip> ts = live.trips.where((Trip t) => p.has(t.at)).toList();
  final List<GroupRow> rows = groupBy(ts, dim, live.names).where((GroupRow r) => r.key != '-' && r.chits > 0).toList();
  rows.sort((GroupRow a, GroupRow b) => b.kg.compareTo(a.kg));
  return rows;
}

// ==================================================================== hourly
class Hourly {
  final List<List<double>> grid = <List<double>>[for (int i = 0; i < 7; i++) List<double>.filled(24, 0)];
  final List<double> byHour = List<double>.filled(24, 0);
  final List<double> byWeekday = List<double>.filled(7, 0);
  double total = 0;
  int peakHour = 0;
  int peakDay = 0;
}

/// metric: 0 weighbridge entries, 1 chits, 2 weighbridge KG
Hourly hourlyOf(Period p, int metric) {
  final Hourly h = Hourly();
  void add(DateTime at, double v) {
    final int wd = at.weekday - 1;
    h.grid[wd][at.hour] += v;
    h.byHour[at.hour] += v;
    h.byWeekday[wd] += v;
    h.total += v;
  }

  if (metric == 1) {
    for (final Chit c in live.chits) {
      if (p.has(c.at)) add(c.at, 1);
    }
  } else {
    for (final Kanta k in live.kantas) {
      if (p.has(k.at)) add(k.at, metric == 2 ? k.kg : 1);
    }
  }
  for (int i = 1; i < 24; i++) {
    if (h.byHour[i] > h.byHour[h.peakHour]) h.peakHour = i;
  }
  for (int i = 1; i < 7; i++) {
    if (h.byWeekday[i] > h.byWeekday[h.peakDay]) h.peakDay = i;
  }
  return h;
}

// ================================================================= turnaround
class Turn {
  final Trip trip;
  final double hours;
  const Turn(this.trip, this.hours);
}

/// Hours between the last chit of a load and the weighbridge entry.
List<Turn> turnaround(Period p) {
  final List<Turn> out = <Turn>[];
  for (final Trip t in live.trips) {
    if (!p.has(t.at) || !t.both) continue;
    final double h = t.kanta!.at.difference(t.chits.last.at).inMinutes / 60.0;
    if (h >= 0) out.add(Turn(t, h));
  }
  return out;
}

double median(List<double> l) {
  if (l.isEmpty) return 0;
  final List<double> s = List<double>.from(l)..sort();
  final int m = s.length ~/ 2;
  return s.length.isOdd ? s[m] : (s[m - 1] + s[m]) / 2;
}

String hoursText(double h) {
  if (h < 1) return '${(h * 60).round()} ${bi('મિનિટ', 'min')}';
  if (h < 48) return '${h.toStringAsFixed(1)} ${bi('કલાક', 'h')}';
  return '${(h / 24).toStringAsFixed(1)} ${bi('દિવસ', 'd')}';
}

// ================================================================ dim helpers
String dimKey(Dim d, Chit c) {
  switch (d) {
    case Dim.vehicle:
      return c.vkey;
    case Dim.farmer:
      return nameKey(c.farmer);
    case Dim.village:
      return nameKey(c.village);
    case Dim.broker:
      return nameKey(c.broker);
    case Dim.majur:
      return c.by;
    case Dim.commodity:
      return nameKey(c.commodity);
    case Dim.day:
      return dayKey(c.at);
  }
}

String dimLabel(Dim d, Chit c) {
  switch (d) {
    case Dim.vehicle:
      return c.vehicle;
    case Dim.farmer:
      return c.farmer;
    case Dim.village:
      return c.village;
    case Dim.broker:
      return c.broker;
    case Dim.majur:
      return majurName(live.names, c.by);
    case Dim.commodity:
      return c.commodity;
    case Dim.day:
      return dm(c.at);
  }
}

String dimName(Dim d) {
  switch (d) {
    case Dim.vehicle:
      return bi('ગાડી', 'Vehicle');
    case Dim.farmer:
      return bi('ખેડૂત', 'Farmer');
    case Dim.village:
      return bi('ગામ', 'Village');
    case Dim.broker:
      return bi('દલાલ', 'Broker');
    case Dim.majur:
      return bi('મજૂર', 'Labour');
    case Dim.commodity:
      return bi('માલ', 'Material');
    case Dim.day:
      return bi('દિવસ', 'Day');
  }
}

String dimIcon(Dim d) {
  switch (d) {
    case Dim.vehicle:
      return 'truck';
    case Dim.farmer:
      return 'agri';
    case Dim.village:
      return 'place';
    case Dim.broker:
      return 'handshake';
    case Dim.majur:
      return 'users';
    case Dim.commodity:
      return 'grain';
    case Dim.day:
      return 'cal';
  }
}

// ======================================================================= risk
class Risk {
  final Dim dim;
  final String key;
  final String label;
  int trips = 0;
  int compared = 0;
  int diffTrips = 0;
  int noKanta = 0;
  int chits = 0;
  int noPhoto = 0;
  int round = 0;
  double kg = 0;
  double mChit = 0;
  double mKanta = 0;
  int score = 0;
  final List<String> why = <String>[];
  Risk(this.dim, this.key, this.label);

  /// Positive = the weighbridge shows less than the chits.
  double get lossPct => mChit > 0 ? (mChit - mKanta) / mChit * 100 : 0;
  String get band => score >= 50 ? 'rose' : (score >= 25 ? 'amber' : 'green');
}

List<Risk> riskOf(Dim dim, Period p, {int minTrips = 3}) {
  final Map<String, Risk> m = <String, Risk>{};
  for (final Trip t in live.trips) {
    if (!p.has(t.at)) continue;
    final Set<String> seen = <String>{};
    if (t.chits.isEmpty) {
      if (dim == Dim.vehicle && t.vk.isNotEmpty) {
        final Risk r = m.putIfAbsent(t.vk, () => Risk(dim, t.vk, t.vehicle));
        r.trips++;
      }
      continue;
    }
    for (final Chit c in t.chits) {
      final String key = dimKey(dim, c);
      if (key.isEmpty) continue;
      final Risk r = m.putIfAbsent(key, () => Risk(dim, key, dimLabel(dim, c)));
      r.chits++;
      r.kg += c.cmpKg;
      if (c.photo.isEmpty) r.noPhoto++;
      if (c.gross > 0 && c.gross % 50 == 0) r.round++;
      if (t.both && t.chitKg > 0 && t.kantaKg > 0) {
        r.mChit += c.cmpKg;
        r.mKanta += t.kantaKg * c.cmpKg / t.chitKg;
      }
      if (seen.add(key)) {
        r.trips++;
        if (t.state == TripState.diff) r.diffTrips++;
        if (t.state == TripState.noKanta) r.noKanta++;
        if (t.both && t.chitKg > 0 && t.kantaKg > 0) r.compared++;
      }
    }
  }
  final double lim = live.cfg.pct <= 0 ? 0.5 : live.cfg.pct;
  final List<Risk> out = <Risk>[];
  for (final Risk r in m.values) {
    if (r.trips < minTrips) continue;
    final double loss = r.lossPct;
    final double lossPts = loss > 0 ? c01(loss / (lim * 3)) * 40 : 0;
    final double diffPts = c01(r.diffTrips / r.trips / 0.5) * 25;
    final double nkPts = c01(r.noKanta / r.trips / 0.3) * 15;
    final double photoPts = r.chits > 0 ? c01(r.noPhoto / r.chits / 0.5) * 10 : 0;
    final double roundShare = r.chits > 0 ? r.round / r.chits : 0;
    final double roundPts = dim == Dim.majur ? c01((roundShare - 0.3) / 0.5) * 10 : 0;
    r.score = (lossPts + diffPts + nkPts + photoPts + roundPts).round().clamp(0, 100).toInt();
    if (loss > lim) r.why.add(bi('સરેરાશ ઘટ ${loss.toStringAsFixed(2)}%', 'average loss ${loss.toStringAsFixed(2)}%'));
    if (r.diffTrips > 0) r.why.add(bi('${r.diffTrips} ગાડીમાં ફરક', '${r.diffTrips} trips differ'));
    if (r.noKanta > 0) r.why.add(bi('${r.noKanta} ગાડી કાંટા વગર', '${r.noKanta} trips without kanta'));
    if (r.noPhoto > 0 && photoPts >= 3) r.why.add(bi('${r.noPhoto} ચિઠ્ઠી ફોટા વગર', '${r.noPhoto} chits without photo'));
    if (roundPts >= 3) r.why.add(bi('ગોળ વજન ${(roundShare * 100).round()}%', 'round weights ${(roundShare * 100).round()}%'));
    out.add(r);
  }
  out.sort((Risk a, Risk b) {
    final int s = b.score.compareTo(a.score);
    if (s != 0) return s;
    return b.kg.compareTo(a.kg);
  });
  return out;
}

// ================================================================== parties
class PartyRef {
  final Dim dim;
  final String key;
  final String label;
  const PartyRef(this.dim, this.key, this.label);

  String get id => '${dim.index}|$key';

  @override
  bool operator ==(Object other) => other is PartyRef && other.dim == dim && other.key == key;

  @override
  int get hashCode => Object.hash(dim, key);
}

class PartySummary {
  final PartyRef ref;
  int chits = 0;
  int kantas = 0;
  double kg = 0;
  DateTime last;
  PartySummary(this.ref, this.last);
}

List<PartySummary> directoryOf(Dim dim) {
  final Map<String, PartySummary> m = <String, PartySummary>{};
  for (final Chit c in live.chits) {
    final String key = dimKey(dim, c);
    if (key.isEmpty) continue;
    final PartySummary s = m.putIfAbsent(key, () => PartySummary(PartyRef(dim, key, dimLabel(dim, c)), c.at));
    s.chits++;
    s.kg += c.cmpKg;
    if (c.at.isAfter(s.last)) s.last = c.at;
  }
  if (dim == Dim.vehicle) {
    for (final Kanta k in live.kantas) {
      final String key = k.vkey;
      if (key.isEmpty) continue;
      final PartySummary s = m.putIfAbsent(key, () => PartySummary(PartyRef(dim, key, k.vehicle), k.at));
      s.kantas++;
      if (k.at.isAfter(s.last)) s.last = k.at;
    }
  }
  return m.values.toList();
}

class PartyData {
  final PartyRef ref;
  final List<Chit> chits = <Chit>[];
  final List<Kanta> kantas = <Kanta>[];
  final List<Trip> trips = <Trip>[];
  final Map<String, int> farmers = <String, int>{};
  final Map<String, int> villages = <String, int>{};
  final Map<String, int> brokers = <String, int>{};
  final Map<String, int> commodities = <String, int>{};
  final Map<String, int> vehicles = <String, int>{};
  final Map<String, int> majurs = <String, int>{};
  GroupRow? row;
  double kg = 0;
  double kantaKg = 0;
  DateTime? first;
  DateTime? last;
  List<double> daily = <double>[];
  PartyData(this.ref);
}

PartyData partyData(PartyRef r, {int trendDays = 30}) {
  final PartyData d = PartyData(r);
  void bump(Map<String, int> m, String k) {
    final String t = k.trim();
    if (t.isEmpty) return;
    m[t] = (m[t] ?? 0) + 1;
  }

  final Set<Trip> ts = <Trip>{};
  for (final Chit c in live.chits) {
    if (dimKey(r.dim, c) != r.key) continue;
    d.chits.add(c);
    d.kg += c.cmpKg;
    bump(d.farmers, c.farmer);
    bump(d.villages, c.village);
    bump(d.brokers, c.broker);
    bump(d.commodities, c.commodity);
    bump(d.vehicles, c.vehicle);
    bump(d.majurs, majurName(live.names, c.by));
    final Trip? t = live.chitTrip[c];
    if (t != null) ts.add(t);
    if (d.first == null || c.at.isBefore(d.first!)) d.first = c.at;
    if (d.last == null || c.at.isAfter(d.last!)) d.last = c.at;
  }
  if (r.dim == Dim.vehicle) {
    for (final Kanta k in live.kantas) {
      if (k.vkey != r.key) continue;
      d.kantas.add(k);
      d.kantaKg += k.kg;
      if (d.first == null || k.at.isBefore(d.first!)) d.first = k.at;
      if (d.last == null || k.at.isAfter(d.last!)) d.last = k.at;
    }
    for (final Trip t in live.trips) {
      if (t.vk == r.key) ts.add(t);
    }
  }
  d.chits.sort((Chit a, Chit b) => b.at.compareTo(a.at));
  d.kantas.sort((Kanta a, Kanta b) => b.at.compareTo(a.at));
  d.trips.addAll(ts);
  d.trips.sort((Trip a, Trip b) => b.at.compareTo(a.at));
  if (d.trips.isNotEmpty) {
    for (final GroupRow g in groupBy(d.trips, r.dim, live.names)) {
      if (g.key == r.key) {
        d.row = g;
        break;
      }
    }
  }
  final DateTime today = dayOf(DateTime.now());
  final DateTime from = addDays(today, -(trendDays - 1));
  final List<double> daily = List<double>.filled(trendDays, 0);
  for (final Chit c in d.chits) {
    if (c.at.isBefore(from)) continue;
    final int i = daysBetween(from, c.at);
    if (i >= 0 && i < trendDays) daily[i] += c.cmpKg;
  }
  if (r.dim == Dim.vehicle) {
    for (final Kanta k in d.kantas) {
      if (k.at.isBefore(from)) continue;
      final int i = daysBetween(from, k.at);
      if (i >= 0 && i < trendDays && d.chits.isEmpty) daily[i] += k.kg;
    }
  }
  d.daily = daily;
  return d;
}

List<MapEntry<String, int>> topCounts(Map<String, int> m, {int n = 6}) {
  final List<MapEntry<String, int>> l = m.entries.toList();
  l.sort((MapEntry<String, int> a, MapEntry<String, int> b) => b.value.compareTo(a.value));
  return l.take(n).toList();
}

// ======================================================================= CSV
String csvOf(List<String> header, List<List<Object?>> rows) {
  final StringBuffer b = StringBuffer();
  b.writeln(header.map(csvCell).join(','));
  for (final List<Object?> r in rows) {
    b.writeln(r.map(csvCell).join(','));
  }
  return b.toString();
}

String _d(DateTime d) => '${d.year}-${pad2(d.month)}-${pad2(d.day)}';
String _t(DateTime d) => '${pad2(d.hour)}:${pad2(d.minute)}';

List<String> chitHeader() => <String>['chit_no', 'date', 'time', 'farmer', 'mobile', 'village', 'broker', 'material', 'vehicle', 'gross_kg', 'bardan_kg', 'kardo_kg', 'net_kg', 'bags', 'entered_by'];

List<Object?> chitRow(Chit c) => <Object?>[c.no, _d(c.at), _t(c.at), c.farmer, c.mobile, c.village, c.broker, c.commodity, c.vehicle, c.gross, c.bardan, c.kardo, c.net, c.bags, majurName(live.names, c.by)];

List<String> kantaHeader() => <String>['rst', 'date', 'time', 'vehicle', 'kg', 'name', 'entered_by'];

List<Object?> kantaRow(Kanta k) => <Object?>[k.rst, _d(k.at), _t(k.at), k.vehicle, k.kg, k.name, majurName(live.names, k.by)];

List<String> maalHeader() => <String>['date', 'type', 'vehicle', 'material', 'dana', 'bags', 'owner', 'godown', 'entered_by'];

List<Object?> maalRow(MaalRow m) => <Object?>[_d(m.date), m.type, m.vehicle, m.material, m.dana, m.bags, m.owner, m.godown, majurName(live.names, m.by)];

List<String> tripHeader() => <String>['date', 'time', 'vehicle', 'status', 'farmers', 'villages', 'material', 'chit_kg', 'kanta_kg', 'diff_kg', 'diff_pct', 'rst'];

List<Object?> tripRow(Trip t) => <Object?>[
      _d(t.at),
      _t(t.at),
      t.vehicle,
      t.state.name,
      t.farmers,
      t.villages,
      t.commodity,
      t.chitKg.round(),
      t.kantaKg.round(),
      t.both ? t.diff.round() : '',
      t.both ? t.diffPct.toStringAsFixed(2) : '',
      t.kanta?.rst ?? '',
    ];

List<String> findingHeader() => <String>['severity', 'type', 'title', 'detail', 'date'];

List<Object?> findingRow(Finding f) => <Object?>[f.sev, ruleName(f.rule), f.title(), f.detail(), _d(f.at)];

// ===================================================================== report
String buildReport(Period p) {
  final Stats s = statsFor(p);
  final StringBuffer b = StringBuffer();
  b.writeln('BALAJI INDUSTRIES');
  b.writeln(p.days <= 1 ? '${dmy(p.from)} (${dayName(p.from)})' : '${dmy(p.from)} - ${dmy(p.lastDay)} (${p.days} ${bi('દિવસ', 'days')})');
  b.writeln('======================');
  b.writeln('${bi('ગાડી', 'Vehicles')}: ${s.trips}');
  b.writeln('${bi('ચિઠ્ઠી', 'Chits')}: ${s.chits} | ${grp(s.chitKg)} KG');
  b.writeln('${bi('કાંટો', 'Kanta')}: ${s.kantas} | ${grp(s.kantaKg)} KG');
  if (s.compared > 0) {
    b.writeln('${bi('ફરક (મેળ થયેલ ${s.compared} ગાડી)', 'Difference (${s.compared} matched trips)')}: ${sk(s.ghat)} KG (${s.ghatPct.toStringAsFixed(2)}%)');
  }
  b.writeln('${bi('માલ બેગ', 'Maal bags')}: ${bi('અંદર', 'in')} ${s.bagsIn} | ${bi('બહાર', 'out')} ${s.bagsOut}');
  final List<KV> cm = commoditySplit(p);
  if (cm.isNotEmpty) {
    b.writeln('');
    b.writeln(bi('માલ પ્રમાણે:', 'By material:'));
    for (final KV k in cm.take(6)) {
      b.writeln('• ${k.label}: ${grp(k.v)} KG (${k.n})');
    }
  }
  void top(String title, Dim d) {
    final List<GroupRow> l = topBy(d, p);
    if (l.isEmpty) return;
    b.writeln('');
    b.writeln(title);
    for (final GroupRow r in l.take(5)) {
      b.writeln('• ${r.label}: ${grp(r.kg)} KG');
    }
  }

  top(bi('ટોપ ખેડૂત:', 'Top farmers:'), Dim.farmer);
  top(bi('ટોપ ગામ:', 'Top villages:'), Dim.village);
  top(bi('ટોપ દલાલ:', 'Top brokers:'), Dim.broker);
  b.writeln('');
  b.writeln('${bi('તપાસ માંગે છે', 'Needs checking')}: ${s.problems}');
  b.writeln('${bi('ફરક વાળી ગાડી', 'Trips with difference')}: ${s.diffTrips} | ${bi('કાંટો બાકી', 'no kanta')}: ${s.noKanta} | ${bi('ચિઠ્ઠી નથી', 'no chit')}: ${s.noChit}');
  final List<Trip> bad = live.trips.where((Trip t) => p.has(t.at) && t.state == TripState.diff).toList();
  bad.sort((Trip a, Trip c) => c.diff.abs().compareTo(a.diff.abs()));
  if (bad.isNotEmpty) {
    b.writeln('');
    b.writeln(bi('સૌથી વધુ ફરક:', 'Biggest differences:'));
    for (final Trip t in bad.take(8)) {
      b.writeln('• ${dm(t.at)} ${t.vehicle} | ${t.farmers} | ${sk(t.diff)} KG (${t.diffPct.toStringAsFixed(2)}%)');
    }
  }
  return b.toString().trim();
}
