import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'bank.dart' show csvDelim, csvSplit, parseBankDate;
import 'insights.dart' show dayKey;
import 'live_models.dart';
import 'live_store.dart';
import 'matrix_slip.dart';
import 'xls_read.dart';

// ======================================================================
// Automatic weighbridge
//  - the weighbridge software on the kanta PC saves its slips in a CSV / TXT file
//  - this reads that file (a file, or the newest file of a folder), finds the columns by their names,
//    and sends every new weighing to the app as a weighbridge entry (same as typing it in the kanta form)
//  - it only sends what is not in the app yet (same RST number, or same vehicle + weight + day)
//  - the settings stay on that PC only (SharedPreferences), nothing is shared
// ======================================================================

bool get kantaFilesPossible => !kIsWeb && (Platform.isWindows || Platform.isLinux || Platform.isMacOS);

/// Which column holds what (-1 = no such column).
class KantaCols {
  int rst;
  int veh;
  int gross;
  int tare;
  int net;
  int date;
  int time;
  int name;
  int unit; // 0 = KG, 1 = tonne
  bool header; // the first line of the file holds the column names
  bool manual; // chosen by the owner (not guessed)
  KantaCols({this.rst = -1, this.veh = -1, this.gross = -1, this.tare = -1, this.net = -1, this.date = -1, this.time = -1, this.name = -1, this.unit = 0, this.header = true, this.manual = false});

  bool get usable => veh >= 0 && (net >= 0 || gross >= 0);

  Map<String, dynamic> toJson() => <String, dynamic>{'rst': rst, 'veh': veh, 'gross': gross, 'tare': tare, 'net': net, 'date': date, 'time': time, 'name': name, 'unit': unit, 'header': header, 'manual': manual};

  factory KantaCols.fromJson(Map<String, dynamic> j) {
    int i(Object? v) => dbl(v, -1).round();
    return KantaCols(rst: i(j['rst']), veh: i(j['veh']), gross: i(j['gross']), tare: i(j['tare']), net: i(j['net']), date: i(j['date']), time: i(j['time']), name: i(j['name']), unit: i(j['unit']) == 1 ? 1 : 0, header: j['header'] != false, manual: j['manual'] == true);
  }
}

class KantaRow {
  final String rst;
  final String vehicle;
  final String name;
  final double gross;
  final double tare;
  final double net;
  final DateTime? at;
  final bool hasTime;

  /// The second weight is still to come (the slip is not finished): never sent.
  final bool partial;

  /// Only from the Matrix terminal file / cable: material, city and the weighing charge of the slip.
  final String material;
  final String city;
  final double charge;
  const KantaRow(this.rst, this.vehicle, this.name, this.gross, this.tare, this.net, this.at, this.hasTime, {this.partial = false, this.material = '', this.city = '', this.charge = 0});

  factory KantaRow.fromSlip(WbSlip s) => KantaRow(s.rst, s.vehicle, s.party, s.gross, s.tare, s.net, s.at, s.hasTime, partial: s.partial, material: s.material, city: s.city, charge: s.charge);

  /// The weighbridge weight: net, or gross - tare, or gross.
  double get weight {
    if (net > 0) return net;
    if (gross > 0 && tare > 0 && gross > tare) return gross - tare;
    return gross;
  }

  bool get ok => !partial && vehicle.trim().isNotEmpty && weight > 0 && weight <= kMaxLoadKg;

  /// The same RST of another year is another slip, so the day is part of the key.
  String get key => rst.trim().isNotEmpty ? 'r:${_norm(rst)}${at == null ? '' : '|${dayKey(at!)}'}' : 'v:${vehicleKey(vehicle)}|${at == null ? '' : dayKey(at!)}|${weight.round()}';
}

String _norm(String s) {
  final String t = s.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
  return t.replaceFirst(RegExp(r'^0+(?=.)'), '');
}

class KantaScan {
  final List<List<String>> table;
  final int headerAt;
  final KantaCols cols;
  final int start;
  final List<KantaRow> rows;
  final bool needMap;

  /// The file was read as a weighbridge terminal report (Matrix style, no header line): [wb] has the details.
  final WbScan? wb;
  const KantaScan(this.table, this.headerAt, this.cols, this.start, this.rows, this.needMap, {this.wb});

  bool get matrix => wb != null;

  List<String> get head => headerAt >= 0 && headerAt < table.length ? table[headerAt] : (table.isEmpty ? <String>[] : table.first);
  int get width {
    int w = 0;
    for (final List<String> r in table.take(30)) {
      if (r.length > w) w = r.length;
    }
    return w;
  }
}

List<List<String>> kantaCells(String text) {
  final List<String> lines = text.replaceAll('\r\n', '\n').replaceAll('\r', '\n').split('\n').where((String l) => l.trim().isNotEmpty).toList();
  if (lines.isEmpty) return <List<String>>[];
  final String d = csvDelim(lines);
  return <List<String>>[for (final String l in lines) csvSplit(l, d)];
}

bool _has(String h, List<String> words) {
  for (final String w in words) {
    if (h.contains(w)) return true;
  }
  return false;
}

/// Guesses the columns from the names in a header row.
KantaCols kantaDetect(List<String> head) {
  final KantaCols c = KantaCols();
  for (int i = 0; i < head.length; i++) {
    final String h = head[i].toLowerCase().trim();
    if (h.isEmpty) continue;
    if (c.veh < 0 && _has(h, <String>['vehicle', 'veh', 'truck', 'lorry', 'gadi', 'vahan', 'car no', 'reg'])) {
      c.veh = i;
    } else if (c.net < 0 && _has(h, <String>['net'])) {
      c.net = i;
    } else if (c.gross < 0 && _has(h, <String>['gross', '1st', 'first', 'loaded', 'full wt'])) {
      c.gross = i;
    } else if (c.tare < 0 && _has(h, <String>['tare', '2nd', 'second', 'empty'])) {
      c.tare = i;
    } else if (c.net < 0 && (h == 'weight' || h == 'wt' || h.startsWith('weight') || h.startsWith('wt '))) {
      c.net = i;
    } else if (c.rst < 0 && _has(h, <String>['rst', 'slip', 'ticket', 'serial', 'sr no', 'sr.', 's.no', 'sno', 'token', 'tkt', 'receipt', 'weighment no', 'wt no'])) {
      c.rst = i;
    } else if (c.date < 0 && _has(h, <String>['date'])) {
      c.date = i;
    } else if (c.time < 0 && _has(h, <String>['time'])) {
      c.time = i;
    } else if (c.name < 0 && _has(h, <String>['party', 'name', 'customer', 'material', 'item', 'commodity', 'product', 'supplier'])) {
      c.name = i;
    }
  }
  return c;
}

/// The first line that looks like a column-name row.
int kantaHeaderAt(List<List<String>> t) {
  for (int i = 0; i < t.length && i < 15; i++) {
    final KantaCols c = kantaDetect(t[i]);
    if (c.usable) return i;
  }
  return -1;
}

double? _w(String s) {
  final String t = s.toLowerCase().replaceAll(RegExp(r'kgs?|tons?|mt|[\s,]'), '');
  if (t.isEmpty) return null;
  return double.tryParse(t);
}

DateTime? _stamp(String d, String t) {
  final DateTime? day = d.trim().isEmpty ? null : parseBankDate(d);
  final RegExpMatch? m = RegExp(r'(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(am|pm)?', caseSensitive: false).firstMatch(t.trim().isNotEmpty ? t : d);
  if (day == null) return null;
  if (m == null) return day;
  int h = int.parse(m[1]!);
  final String ap = (m[4] ?? '').toLowerCase();
  if (ap == 'pm' && h < 12) h += 12;
  if (ap == 'am' && h == 12) h = 0;
  return DateTime(day.year, day.month, day.day, h.clamp(0, 23).toInt(), int.parse(m[2]!).clamp(0, 59).toInt());
}

/// Reads a whole file (or pasted text).
KantaScan kantaScan(String text, KantaCols saved) => kantaScanTable(kantaCells(text), saved);

/// Reads the bytes of a file: CSV / TXT, or an Excel (.xlsx / .xls) file.
KantaScan kantaScanBytes(List<int> b, KantaCols saved) {
  List<List<String>> t;
  if (wbIsOldXls(b)) {
    // the old Excel file (.xls): read it directly; if it cannot be read the screen asks for CSV / XLSX
    try {
      t = wbXlsTable(b);
    } catch (_) {
      throw const FormatException('xls');
    }
    if (t.isEmpty) throw const FormatException('xls');
  } else {
    if (wbIsXlsx(b)) {
      t = wbXlsxTable(b);
    } else {
      final String txt = wbDecodeText(b);
      // a web page / Excel-2003 XML saved with the name ".xls" is read as a table too
      t = wbIsSheetXml(txt) ? wbSheetXmlTable(txt) : (wbIsHtmlTable(txt) ? wbHtmlTable(txt) : kantaCells(txt));
    }
  }
  return kantaScanTable(t, saved);
}

KantaScan kantaScanTable(List<List<String>> t, KantaCols saved) {
  if (t.isEmpty) return KantaScan(t, -1, saved, 0, <KantaRow>[], true);
  final int h = kantaHeaderAt(t);
  KantaCols c = saved;
  int start;
  if (saved.manual && saved.usable) {
    start = saved.header ? (h >= 0 ? h + 1 : 1) : 0;
  } else if (h >= 0) {
    c = kantaDetect(t[h]);
    c.unit = saved.unit;
    start = h + 1;
  } else {
    // no header line: the terminal's own report (Matrix) - every line is read by its shape
    final WbScan w = wbScan(t);
    if (w.looksRight) {
      final double mul = saved.unit == 1 ? 1000 : 1;
      return KantaScan(t, -1, saved, 0, <KantaRow>[for (final WbSlip x in w.slips) _scaled(KantaRow.fromSlip(x), mul)], false, wb: w);
    }
    return KantaScan(t, -1, saved, 0, <KantaRow>[], true);
  }
  final List<KantaRow> out = <KantaRow>[];
  for (int i = start; i < t.length; i++) {
    final List<String> r = t[i];
    String g(int k) => k >= 0 && k < r.length ? r[k].trim() : '';
    final double mul = c.unit == 1 ? 1000 : 1;
    final String dt = g(c.date);
    final String tm = g(c.time);
    final double gross = (_w(g(c.gross)) ?? 0) * mul;
    final double tare = (_w(g(c.tare)) ?? 0) * mul;
    double net = (_w(g(c.net)) ?? 0) * mul;
    final String veh = g(c.veh);
    if (veh.isEmpty && net <= 0 && gross <= 0) continue;
    // first weight only (tare still to come, or the net equal to the gross): not finished
    bool partial = false;
    if (c.gross >= 0 && c.tare >= 0) {
      if (gross > 0 && tare <= 0 && (net <= 0 || (net - gross).abs() < 0.5)) partial = true;
      if (gross <= 0 && tare > 0 && net <= 0) partial = true;
      if (partial) net = 0;
    }
    final DateTime? at = _stamp(dt, tm);
    final bool hasTime = at != null && (at.hour != 0 || at.minute != 0);
    out.add(KantaRow(g(c.rst), veh.toUpperCase().replaceAll(RegExp(r'[\s\-]'), ''), g(c.name), gross, tare, net, at, hasTime, partial: partial));
  }
  return KantaScan(t, h, c, start, out, !c.usable);
}

KantaRow _scaled(KantaRow r, double mul) => mul == 1 ? r : KantaRow(r.rst, r.vehicle, r.name, r.gross * mul, r.tare * mul, r.net * mul, r.at, r.hasTime, partial: r.partial, material: r.material, city: r.city, charge: r.charge);

/// Is this weighing already in the app (or waiting to be sent)?
bool kantaKnown(KantaRow r) {
  final String rn = _norm(r.rst);
  final String vk = vehicleKey(r.vehicle);
  for (final Kanta k in live.kantas) {
    if (rn.isEmpty || _norm(k.rst) != rn) continue;
    // the terminal may start its RST numbers again: the same RST counts only when it is the same vehicle or about the same days
    final DateTime? a = r.at;
    if (a == null || k.vkey == vk || k.at.difference(a).inDays.abs() <= 3) return true;
  }
  for (final PendingItem p in live.pending) {
    if (p.kind != 'kanta') continue;
    if (rn.isNotEmpty && _norm('${p.row['rst_no'] ?? ''}') == rn) return true;
  }
  if (vk.isEmpty) return false;
  for (final Kanta k in live.kantas) {
    if (k.vkey != vk || (k.kg - r.weight).abs() >= 1) continue;
    final DateTime? a = r.at;
    if (a == null || (a.year == k.at.year && a.month == k.at.month && a.day == k.at.day)) return true;
  }
  return false;
}

class KantaAutoService extends ChangeNotifier {
  KantaCols cols = KantaCols();
  String path = '';
  bool on = false;
  final Set<String> seen = <String>{};
  String msg = '';
  DateTime? lastRun;
  int sentTotal = 0;
  bool busy = false;
  bool _loaded = false;
  Timer? _t;

  Future<void> load() async {
    if (_loaded) return;
    _loaded = true;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      final String raw = p.getString('kauto') ?? '';
      if (raw.isNotEmpty) {
        final Object? j = jsonDecode(raw);
        if (j is Map) {
          final Map<String, dynamic> m = Map<String, dynamic>.from(j);
          path = '${m['path'] ?? ''}';
          on = m['on'] == true;
          final Object? c = m['cols'];
          if (c is Map) cols = KantaCols.fromJson(Map<String, dynamic>.from(c));
          final Object? s = m['seen'];
          if (s is List) seen.addAll(s.map((Object? e) => '$e'));
          sentTotal = dbl(m['sent']).round();
        }
      }
    } catch (_) {}
    arm();
    notifyListeners();
  }

  Future<void> save() async {
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      final List<String> s = seen.toList();
      final List<String> keep = s.length > 3000 ? s.sublist(s.length - 3000) : s;
      await p.setString('kauto', jsonEncode(<String, dynamic>{'path': path, 'on': on, 'cols': cols.toJson(), 'seen': keep, 'sent': sentTotal}));
    } catch (_) {}
    notifyListeners();
  }

  void arm() {
    _t?.cancel();
    _t = null;
    if (on && kantaFilesPossible && path.trim().isNotEmpty) {
      _t = Timer.periodic(const Duration(seconds: 45), (Timer _) => tick());
    }
  }

  /// The bytes of the file (or of the newest .csv / .txt / .xlsx / .xls file in the folder).
  Future<List<int>> readBytes() async {
    final String p = path.trim();
    if (p.isEmpty) throw 'no path';
    File? f;
    if (await FileSystemEntity.isDirectory(p)) {
      DateTime? best;
      await for (final FileSystemEntity e in Directory(p).list(followLinks: false)) {
        if (e is! File) continue;
        final String n = e.path.toLowerCase();
        final String base = n.split(RegExp(r'[\\/]')).last;
        if (base.startsWith('~\$')) continue;
        if (!(n.endsWith('.csv') || n.endsWith('.txt') || n.endsWith('.tsv') || n.endsWith('.xlsx') || n.endsWith('.xls'))) continue;
        final DateTime m = (await e.stat()).modified;
        if (best == null || m.isAfter(best)) {
          best = m;
          f = e;
        }
      }
    } else {
      f = File(p);
    }
    if (f == null || !await f.exists()) throw 'file not found';
    return f.readAsBytes();
  }

  /// The text of the file (kept for the old callers).
  Future<String> read() async => wbDecodeText(await readBytes());

  Future<KantaScan> scanFile() async => kantaScanBytes(await readBytes(), cols);

  /// Sends the rows to the app. Returns how many were saved.
  Future<int> send(List<KantaRow> rows) async {
    int n = 0;
    for (final KantaRow r in rows) {
      if (!r.ok) continue;
      final double w = r.weight;
      final Map<String, dynamic> row = <String, dynamic>{
        'rst_no': r.rst.trim(),
        'vehicle_number': r.vehicle.trim(),
        'total_weight_kg': w,
        'net_weight_kg': w,
      };
      final DateTime? a = r.at;
      if (a != null && (r.hasTime || a.isBefore(DateTime.now().subtract(const Duration(days: 1))))) {
        row['created_at'] = (r.hasTime ? a : DateTime(a.year, a.month, a.day, 12)).toUtc().toIso8601String();
      }
      final SaveResult res = await live.submit('kanta', row);
      if (res.ok) {
        n++;
        seen.add(r.key);
      } else {
        msg = res.error;
      }
    }
    sentTotal += n;
    await save();
    return n;
  }

  /// First time switched on: what is in the file now is not sent again later.
  Future<int> baseline() async {
    final KantaScan s = await scanFile();
    final DateTime recent = DateTime.now().subtract(const Duration(days: 2));
    int n = 0;
    for (final KantaRow r in s.rows) {
      final DateTime? a = r.at;
      if (a != null && a.isAfter(recent)) continue;
      if (seen.add(r.key)) n++;
    }
    await save();
    return n;
  }

  /// Looks at the file once and sends what is new.
  Future<void> tick() async {
    if (busy || !on) return;
    if (!live.signedIn || live.loadedAt == null) return;
    busy = true;
    try {
      final KantaScan s = await scanFile();
      lastRun = DateTime.now();
      if (s.needMap) {
        msg = 'columns?';
        return;
      }
      final DateTime recent = DateTime.now().subtract(const Duration(days: 2));
      final List<KantaRow> fresh = <KantaRow>[];
      for (final KantaRow r in s.rows) {
        if (!r.ok || seen.contains(r.key)) continue;
        final DateTime? a = r.at;
        if (a != null && a.isBefore(recent)) continue;
        if (kantaKnown(r)) {
          seen.add(r.key);
          continue;
        }
        fresh.add(r);
      }
      if (fresh.isNotEmpty) {
        final int n = await send(fresh);
        msg = n == fresh.length ? '' : msg;
      } else {
        await save();
      }
    } catch (e) {
      msg = '$e';
    } finally {
      busy = false;
      notifyListeners();
    }
  }
}

final KantaAutoService kantaAuto = KantaAutoService();
