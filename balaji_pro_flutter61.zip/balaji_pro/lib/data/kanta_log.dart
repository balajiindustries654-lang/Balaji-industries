import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'kanta_slip.dart';
import 'kanta_usb.dart';
import 'live_store.dart';

/// The Kanta app keeps its own plain copy of every entry on the laptop, in the folder  Documents\Balaji Kanta :
///   kanta-YYYY-MM.csv        one line per entry (opens in Excel; a taken-back entry gets one more line "CANCELLED")
///   kanta-first-YYYY-MM.csv  every first weight (vehicle, kg, time)
///   kanta-slips.jsonl        every finished slip, so it can be printed again whenever needed
/// Nothing in these files is ever rewritten or deleted by the app. The entry itself goes online too - the files are the
/// safety copy if the internet or the server fails.
class KantaLog {
  static String lastError = '';
  static String lastPath = '';
  static int count = 0;
  static Directory? _dir;

  // ---- settings of the operator's laptop (kept in the app's preferences)
  /// Print the slip by itself after every entry (on the Windows laptop it goes straight to the Epson - no print window).
  static bool autoPrint = false;

  /// true: plain monospaced slip for the Epson dot-matrix printer; false: boxed A5 page with Gujarati.
  static bool dotMatrix = true;

  /// How the slip looks: name, address, phone numbers, footer, which lines are shown (Settings > Printing).
  static SlipStyle style = const SlipStyle();

  /// First line of the slip (the name of the weighbridge).
  static String get heading => style.title;

  /// 0: print through the browser's print window (any printer); 1: "Epson direct" - plain text with ESC/P codes straight to
  /// the dot-matrix printer (fast, page ends at the slip; Windows laptop only, see kanta_direct.dart).
  static int printMode = 0;

  /// Direct printing failed (printer off, cable out): also open the browser's print window? Off by default - the operator
  /// does not want a second page, only a short message (the slip can be printed again from the entry).
  static bool browserFallback = false;

  /// The Windows printer for direct printing ('' = found by itself: Epson LX-310 / any Epson, also on USB with no driver).
  static String printerName = '';

  /// Direct printing: page length in lines (1 line = 1/6 inch; 18 = 3 in, 24 = 4 in, 33 = 5.5 in); 0 = the printer's own page length.
  static int pageLines = 0;

  /// Direct printing: darker print (double strike), good for carbon copies.
  static bool bold = false;

  /// WhatsApp after the second weight: 0 off, 1 mill vehicles only (default), 2 every vehicle. The chat of the number written at the
  /// weighing (or of the farmer's chit) opens with the slip already typed in - one press of Send. Entries weighed from a phone do not open it.
  static int waMode = 1;

  /// true: the slip is sent by itself through the WhatsApp Business Platform (Meta Cloud API, through the Supabase function
  /// send-whatsapp) - nobody presses anything per vehicle. false: the chat opens with the slip typed in (one press of Send).
  static bool waApi = false;

  /// true (default): the slip goes on WhatsApp as a PICTURE that looks like the print (needs the picture template, see WHATSAPP-SETUP.md;
  /// until it is approved the server sends the plain writing instead). false: always the plain writing.
  static bool waPicture = true;

  /// The fixed WhatsApp number(s) of the mill, written once (several: separated by a comma). Every slip of a MILL vehicle goes there too,
  /// besides the number written at the weighing. Slips of road vehicles never go there.
  static String waMill = '';

  /// The mill numbers as 10 digits each (no duplicates, wrong ones left out).
  static List<String> get millNumbers => parseNumbers(waMill);

  /// 10 digit mobile numbers out of a text ("98250 12345, +91 98765 43210"): separated by comma / semicolon / slash / new line.
  static List<String> parseNumbers(String text) {
    final List<String> out = <String>[];
    for (final String part in text.split(RegExp(r'[,;/|\n]+'))) {
      final String d = part.replaceAll(RegExp(r'[^0-9]'), '');
      if (d.length < 10) continue;
      final String n = d.substring(d.length - 10);
      if (!out.contains(n)) out.add(n);
    }
    return out;
  }

  /// true: the Matrix-terminal layout (a Home with big buttons, every job on its own screen, F1-F9); false: everything on one screen.
  static bool termUi = true;

  /// Calibration reminder (like "Cal Reminder" on the terminal): the day the scale was last calibrated (ms since 1970, 0 = never written),
  /// the months until the next one and a note.
  static int calLastMs = 0;
  static int calMonths = 6;
  static String calNote = '';

  /// The last choice at the charges box: true = charges taken in cash at the weighing, false = baki (goes to the khata of the name).
  static bool chargePaid = false;

  /// Goes up whenever the history or a setting changes, so screens can redraw.
  static final ValueNotifier<int> tick = ValueNotifier<int>(0);

  static bool get supported => !kIsWeb && (Platform.isWindows || Platform.isLinux || Platform.isMacOS);

  /// Loads the settings and the history, and starts writing a line for every entry made at the weighing station.
  static Future<void> start() async {
    // an entry whose RST number was already used on the server got another one: written to a file (the printed slip may show the old number)
    live.onKantaNote = (String n) {
      final DateTime t = DateTime.now();
      String two(int v) => v < 10 ? '0$v' : '$v';
      unawaited(appendFile('kanta-notes', t, 'Date,Time,Note', '${t.year}-${two(t.month)}-${two(t.day)},${two(t.hour)}:${two(t.minute)},${_q(n)}'));
    };
    kantaUsb.onEntryMade = (AutoMade m) => unawaited(_made(m));
    kantaUsb.onFirstTaken = (String v, double kg, DateTime at, bool outside) => unawaited(addFirst(v, kg, at, outside: outside));
    kantaUsb.onEntryUndone = (AutoMade m) => unawaited(_undone(m));
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      autoPrint = p.getBool('kl_autoprint') ?? false;
      dotMatrix = p.getBool('kl_dot') ?? true;
      final String h = (p.getString('kl_head') ?? '').trim();
      final String js = p.getString('kl_slip') ?? '';
      if (js.isNotEmpty) {
        try {
          style = SlipStyle.fromJson(jsonDecode(js));
        } catch (_) {}
      } else {
        // a laptop that has not set a layout: the slip of this weighbridge as the Matrix terminal printed it (a name written in an older version is kept)
        style = h.isNotEmpty && h != 'Balaji Industries' ? SlipStyle.shree.copyWith(title: h) : SlipStyle.shree;
      }
      waMill = p.getString('kl_wamill') ?? '';
      // 1.27: the Windows laptop prints straight to the Epson by itself - no second page (and auto print on after every save).
      // Done once; after that whatever the operator chooses stays.
      final bool win = !kIsWeb && Platform.isWindows;
      if (win && p.getBool('kl_direct127') != true) {
        await p.setInt('kl_pm', 1);
        await p.setBool('kl_autoprint', true);
        await p.setBool('kl_direct127', true);
        autoPrint = true;
      }
      printMode = p.getInt('kl_pm') ?? (win ? 1 : 0);
      browserFallback = p.getBool('kl_pbf') ?? false;
      printerName = p.getString('kl_pn') ?? '';
      pageLines = p.getInt('kl_pl') ?? 0;
      bold = p.getBool('kl_pb') ?? false;
      waMode = (p.getInt('kl_wa') ?? 1).clamp(0, 2).toInt();
      waApi = p.getBool('kl_waapi') ?? false;
      waPicture = p.getBool('kl_wapic') ?? true;
      termUi = p.getBool('kl_term') ?? true;
      chargePaid = p.getBool('kl_cpaid') ?? false;
      calLastMs = p.getInt('kl_cal') ?? 0;
      calMonths = (p.getInt('kl_calm') ?? 6).clamp(1, 36).toInt();
      calNote = p.getString('kl_caln') ?? '';
    } catch (_) {}
    await KantaHistory.load();
    tick.value++;
  }

  static Future<void> setChargePaid(bool v) async {
    chargePaid = v;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setBool('kl_cpaid', v);
    } catch (_) {}
  }

  static Future<void> setTermUi(bool v) async {
    termUi = v;
    tick.value++;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setBool('kl_term', v);
    } catch (_) {}
  }

  /// The calibration was done on [last] (null: forget it); the next one is due after [months].
  static Future<void> setCal(DateTime? last, int months, String note) async {
    calLastMs = last?.millisecondsSinceEpoch ?? 0;
    calMonths = months.clamp(1, 36).toInt();
    calNote = note.trim();
    tick.value++;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setInt('kl_cal', calLastMs);
      await p.setInt('kl_calm', calMonths);
      await p.setString('kl_caln', calNote);
    } catch (_) {}
  }

  /// When the next calibration is due (null: no date written).
  static DateTime? get calDue {
    if (calLastMs <= 0) return null;
    final DateTime l = DateTime.fromMillisecondsSinceEpoch(calLastMs);
    return DateTime(l.year, l.month + calMonths, l.day);
  }

  static Future<void> setAutoPrint(bool v) async {
    autoPrint = v;
    tick.value++;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setBool('kl_autoprint', v);
    } catch (_) {}
  }

  static Future<void> setDotMatrix(bool v) async {
    dotMatrix = v;
    tick.value++;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setBool('kl_dot', v);
    } catch (_) {}
  }

  static Future<void> setPrintMode(int v) async {
    printMode = v;
    tick.value++;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setInt('kl_pm', v);
    } catch (_) {}
  }

  static Future<void> setBrowserFallback(bool v) async {
    browserFallback = v;
    tick.value++;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setBool('kl_pbf', v);
    } catch (_) {}
  }

  static Future<void> setPrinterName(String v) async {
    printerName = v;
    tick.value++;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setString('kl_pn', v);
    } catch (_) {}
  }

  static Future<void> setPageLines(int v) async {
    pageLines = v;
    tick.value++;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setInt('kl_pl', v);
    } catch (_) {}
  }

  static Future<void> setWaApi(bool v) async {
    waApi = v;
    tick.value++;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setBool('kl_waapi', v);
    } catch (_) {}
  }

  static Future<void> setWaPicture(bool v) async {
    waPicture = v;
    tick.value++;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setBool('kl_wapic', v);
    } catch (_) {}
  }

  /// Appends one line to a file of this month in the Balaji Kanta folder (a new file gets [head] first). Never throws.
  static Future<void> appendFile(String prefix, DateTime at, String head, String row) async {
    if (!supported) return;
    try {
      await _append(prefix, at, head, row);
    } catch (e) {
      lastError = '$e';
    }
  }

  static String csv(String s) => _q(s);

  static Future<void> setWaMode(int v) async {
    waMode = v.clamp(0, 2).toInt();
    tick.value++;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setInt('kl_wa', waMode);
    } catch (_) {}
  }

  static Future<void> setBold(bool v) async {
    bold = v;
    tick.value++;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setBool('kl_pb', v);
    } catch (_) {}
  }

  static Future<void> setHeading(String v) => setStyle(style.copyWith(title: v.trim().isEmpty ? 'Balaji Industries' : v.trim()));

  /// Changes how the slip looks (kept on the laptop).
  static Future<void> setStyle(SlipStyle s) async {
    style = s.title.trim().isEmpty ? s.copyWith(title: 'Balaji Industries') : s;
    tick.value++;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setString('kl_head', style.title);
      await p.setString('kl_slip', jsonEncode(style.toJson()));
    } catch (_) {}
  }

  /// The fixed WhatsApp number(s) of the mill (text as written; '' = none).
  static Future<void> setWaMill(String v) async {
    waMill = v.trim();
    tick.value++;
    try {
      final SharedPreferences p = await SharedPreferences.getInstance();
      await p.setString('kl_wamill', waMill);
    } catch (_) {}
  }

  /// Called after an entry was made and written to the files (the Kanta app prints the slip here when "auto print" is on).
  static void Function(SlipRec r)? afterEntry;

  /// Called first of all, right after the second weight made an entry (the Google Sheet row is made here, see kanta_sheet.dart).
  static void Function(SlipRec r)? onSlipMade;

  static Future<void> _made(AutoMade m) async {
    final SlipRec r = kantaUsb.slipOf(m);
    try {
      onSlipMade?.call(r);
    } catch (_) {}
    await add(m);
    await KantaHistory.add(r);
    try {
      afterEntry?.call(r);
    } catch (_) {}
  }

  static Future<void> _undone(AutoMade m) async {
    try {
      final SlipRec? r = KantaHistory.markUndone(m.rst, m.vehicle);
      if (r != null) {
        await KantaHistory.appendUndo(m.rst, m.vehicle);
        if (m.outside) {
          await _append('kanta-outside', r.at, outsideHeader, outsideLine(m, status: 'CANCELLED (taken back)'));
        } else {
          await _append('kanta', r.at, header, line(m, r.party, status: 'CANCELLED (taken back)'));
        }
      }
    } catch (e) {
      lastError = '$e';
    }
  }

  static Future<Directory?> folder() async {
    if (_dir != null) return _dir;
    try {
      final Directory base = await getApplicationDocumentsDirectory();
      final Directory d = Directory('${base.path}${Platform.pathSeparator}Balaji Kanta');
      if (!await d.exists()) await d.create(recursive: true);
      _dir = d;
      return d;
    } catch (e) {
      lastError = '$e';
      return null;
    }
  }

  static String _q(String s) => '"${s.replaceAll('"', '""')}"';
  static String _qe(String s) => s.trim().isEmpty ? '' : _q(s.trim());
  static String _two(int n) => n < 10 ? '0$n' : '$n';
  static String _hm(DateTime d) => '${_two(d.hour)}:${_two(d.minute)}';

  /// One CSV line for an entry (without the line break).
  static String line(AutoMade m, String party, {String? status}) {
    final DateTime d = m.at;
    final String st = status ?? _okOf(m);
    return <String>[
      '${d.year}-${_two(d.month)}-${_two(d.day)}',
      _hm(d),
      _q(m.rst),
      _q(m.vehicle),
      _q(party),
      '${m.gross.round()}',
      _hm(m.wGross.at),
      '${m.tare.round()}',
      _hm(m.wTare.at),
      '${m.net.round()}',
      _q(st),
      _qe(m.mobile),
      _qe(m.material),
      _qe(m.city),
      _money(m.charges),
    ].join(',');
  }

  static String _money(double v) => v <= 0 ? '' : (v == v.roundToDouble() ? '${v.round()}' : v.toStringAsFixed(2));

  /// Status text of a normal entry; a remote-weighed one says who did it from the phone.
  static String _okOf(AutoMade m) => m.by.isEmpty ? 'OK' : 'OK · phone: ${m.by}';

  static const String header = 'Date,Time,RST,Vehicle,Party,Gross KG,Gross time,Tare KG,Tare time,Net KG,Status,Mobile,Material,City,Charges Rs';

  /// Vehicles from the road (laptop only): own file, own header (party / maal and charges).
  static const String outsideHeader = 'Date,Time,Slip No,Vehicle,Party / Maal,Gross KG,Gross time,Tare KG,Tare time,Net KG,Charges Rs,Status,Mobile,Material,City';

  static String outsideLine(AutoMade m, {String? status}) {
    final DateTime d = m.at;
    final String st = status ?? _okOf(m);
    return <String>[
      '${d.year}-${_two(d.month)}-${_two(d.day)}',
      _hm(d),
      _q(m.rst),
      _q(m.vehicle),
      _q(m.party),
      '${m.gross.round()}',
      _hm(m.wGross.at),
      '${m.tare.round()}',
      _hm(m.wTare.at),
      '${m.net.round()}',
      m.charges == m.charges.roundToDouble() ? '${m.charges.round()}' : m.charges.toStringAsFixed(2),
      _q(st),
      _qe(m.mobile),
      _qe(m.material),
      _qe(m.city),
    ].join(',');
  }

  /// Appends a line to a file of this month (header on a new file). Never deletes or rewrites anything.
  static Future<void> _append(String prefix, DateTime n, String head, String row) async {
    final Directory? d = await folder();
    if (d == null) return;
    final File f = File('${d.path}${Platform.pathSeparator}$prefix-${n.year}-${_two(n.month)}.csv');
    final bool fresh = !await f.exists() || await f.length() == 0;
    final IOSink w = f.openWrite(mode: FileMode.append, encoding: utf8);
    if (fresh) w.write('﻿$head\r\n');
    w.write('$row\r\n');
    await w.flush();
    await w.close();
    lastPath = f.path;
    lastError = '';
  }

  /// First weight of a vehicle (the second weight may come hours later).
  static Future<void> addFirst(String vehicle, double kg, DateTime at, {bool outside = false}) async {
    if (!supported) return;
    try {
      await _append('kanta-first', at, 'Date,Time,Vehicle,First weight KG,Type', '${at.year}-${_two(at.month)}-${_two(at.day)},${_hm(at)},${_q(vehicle)},${kg.round()},${outside ? 'ROAD' : 'MILL'}');
    } catch (e) {
      lastError = '$e';
    }
  }

  static Future<void> add(AutoMade m) async {
    if (!supported) return;
    try {
      if (m.outside) {
        await _append('kanta-outside', m.at, outsideHeader, outsideLine(m));
      } else {
        String party = m.party.trim(); // written at the weighing, else the farmer of the chit
        if (party.isEmpty) {
          try {
            party = kantaUsb.partyProvider(m.vehicle);
          } catch (_) {}
        }
        await _append('kanta', m.at, header, line(m, party));
      }
      count++;
    } catch (e) {
      lastError = '$e';
    }
  }
}

/// Every finished slip of this laptop, newest first (file kanta-slips.jsonl, only ever appended to).
class KantaHistory {
  static final List<SlipRec> items = <SlipRec>[];

  static String _key(String v) => v.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');

  /// The latest finished slip of a vehicle (to fill party / material / city / mobile again when it comes back); null if none.
  static SlipRec? lastOf(String vehicle) {
    final String k = _key(vehicle);
    if (k.length < 4) return null;
    for (final SlipRec r in items) {
      if (!r.undone && _key(r.vehicle) == k) return r;
    }
    return null;
  }

  /// Earlier values for a suggestion list: newest first, no repeats. [pick] chooses the text of a slip.
  static List<String> recent(String Function(SlipRec r) pick, {int max = 60}) {
    final List<String> out = <String>[];
    final Set<String> seen = <String>{};
    for (final SlipRec r in items) {
      final String t = pick(r).trim();
      if (t.isEmpty) continue;
      if (seen.add(t.toLowerCase())) {
        out.add(t);
        if (out.length >= max) break;
      }
    }
    return out;
  }

  static Future<File?> _file() async {
    final Directory? d = await KantaLog.folder();
    if (d == null) return null;
    return File('${d.path}${Platform.pathSeparator}kanta-slips.jsonl');
  }

  static Future<void> load() async {
    items.clear();
    if (!KantaLog.supported) return;
    try {
      final File? f = await _file();
      if (f == null || !await f.exists()) return;
      final List<String> lines = const LineSplitter().convert(await f.readAsString());
      final List<SlipRec> all = <SlipRec>[];
      for (final String l in lines) {
        if (l.trim().isEmpty) continue;
        try {
          final Object? j = jsonDecode(l);
          if (j is Map && j['undo'] != null) {
            final String rst = '${j['undo']}';
            final String v = '${j['v'] ?? ''}';
            for (final SlipRec r in all.reversed) {
              if (r.rst == rst && r.vehicle == v && !r.undone) {
                r.undone = true;
                break;
              }
            }
          } else {
            final SlipRec? r = SlipRec.fromJson(j);
            if (r != null) all.add(r);
          }
        } catch (_) {}
      }
      items.addAll(all.reversed);
    } catch (e) {
      KantaLog.lastError = '$e';
    }
    KantaLog.tick.value++;
  }

  static Future<void> add(SlipRec r) async {
    items.insert(0, r);
    KantaLog.tick.value++;
    if (!KantaLog.supported) return;
    try {
      final File? f = await _file();
      if (f == null) return;
      await f.writeAsString('${r.toLine()}\n', mode: FileMode.append, flush: true);
    } catch (e) {
      KantaLog.lastError = '$e';
    }
  }

  /// Marks the newest slip with this RST and vehicle as taken back (in memory). Returns it, or null.
  static SlipRec? markUndone(String rst, String vehicle) {
    for (final SlipRec r in items) {
      if (r.rst == rst && r.vehicle == vehicle && !r.undone) {
        r.undone = true;
        KantaLog.tick.value++;
        return r;
      }
    }
    return null;
  }

  static Future<void> appendUndo(String rst, String vehicle) async {
    if (!KantaLog.supported) return;
    try {
      final File? f = await _file();
      if (f == null) return;
      await f.writeAsString('${jsonEncode(<String, Object>{'undo': rst, 'v': vehicle})}\n', mode: FileMode.append, flush: true);
    } catch (e) {
      KantaLog.lastError = '$e';
    }
  }

  /// Slips that contain [q] in the RST, the vehicle or the party (letters and digits only, any case); all of them when [q] is empty.
  static List<SlipRec> search(String q, {DateTime? day}) {
    String k(String s) => s.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');
    final String key = k(q);
    return <SlipRec>[
      for (final SlipRec r in items)
        if ((day == null || (r.at.year == day.year && r.at.month == day.month && r.at.day == day.day)) && (key.isEmpty || k(r.rst).contains(key) || k(r.vehicle).contains(key) || k(r.party).contains(key) || k(r.material).contains(key) || k(r.city).contains(key) || k(r.mobile).contains(key))) r,
    ];
  }
}
