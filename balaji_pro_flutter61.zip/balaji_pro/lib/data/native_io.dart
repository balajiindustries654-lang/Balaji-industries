import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart' show kIsWeb;

// ======================================================================
// Things that need a phone plug-in: reading a file from a pen drive and the USB-to-RS232 cable.
//  - THIS file is the plain version (no plug-ins): it is what the laptop (Windows) build uses, and what every
//    other build falls back to.
//  - ci/native_io_android.dart has the same names with the real plug-ins (usb_serial, file_picker).
//    ci/build.sh copies it over this file for the Android build, and goes back to this one if that build fails.
//    So an unlucky plug-in can never stop the app from being built.
// ======================================================================

/// A file chosen by the owner.
class PickedFile {
  final String name;
  final Uint8List bytes;
  const PickedFile(this.name, this.bytes);
}

/// This build has the USB-to-RS232 plug-in.
const bool kUsbPlugin = false;

/// This build has the phone file chooser plug-in.
const bool kPickerPlugin = false;

/// A "choose file" button works in this build (phone plug-in, or the Windows open-file window).
bool get canPickFile => kPickerPlugin || (!kIsWeb && Platform.isWindows);

/// One USB serial adapter.
class UsbDev {
  final String id;
  final String label;
  final Object? raw;
  const UsbDev(this.id, this.label, [this.raw]);
}

/// An open serial connection.
abstract class UsbSession {
  Stream<Uint8List> get data;
  Future<void> write(List<int> bytes);
  Future<void> close();
}

// ---------------------------------------------------------------------- Windows COM ports (no plug-in)
// The laptop reads a COM port through PowerShell (System.IO.Ports.SerialPort): a small script opens the port and writes
// every byte it receives to its standard output, this app reads that. Nothing to install.

/// How to start a program (tests replace it).
Future<Process> Function(String exe, List<String> args) winSpawn = (String exe, List<String> args) => Process.start(exe, args);

/// Tests set this to use the Windows way on another system.
bool winSerialForTest = false;

bool get _winSerial => !kIsWeb && (Platform.isWindows || winSerialForTest);

/// The name of the PowerShell program (tests replace it).
String winShell = 'powershell';

final RegExp _comName = RegExp(r'^COM\d{1,3}$', caseSensitive: false);

const String _listScript = r'''
$names = [System.IO.Ports.SerialPort]::GetPortNames()
foreach ($n in $names) {
  $label = $n
  try {
    $w = Get-CimInstance Win32_PnPEntity -Filter ("Name like '%(" + $n + ")%'") | Select-Object -First 1
    if ($w) { $label = $w.Name }
  } catch {}
  Write-Output ($n + '|' + $label)
}
''';

/// Why the last COM reader stopped (the text PowerShell wrote: "Access to the port 'COM4' is denied", "The I/O operation has been
/// aborted ..."). Empty while it runs or when it said nothing. The app shows it when the cable drops, so the real cause is visible.
String winLastEnd = '';
int _winGen = 0; // the reader that is current (a reader that was replaced must not overwrite the reason)

String _cleanWinErr(String t) {
  String s = t.replaceAll('OPEN', ' ').replaceAll(RegExp(r'\s+'), ' ').trim();
  final int at = s.indexOf(' At line:');
  if (at > 0) s = s.substring(0, at).trim();
  return s.length > 180 ? s.substring(0, 180) : s;
}

/// The text of the PowerShell script that reads one COM port (public for tests).
/// [parentPid]: the app that started it. When that app is gone (closed, crashed, replaced by a new version) the script stops by itself -
/// otherwise it would stay alive, keep the COM port open and every later start of the app would get "Access to the port 'COM4' is denied".
String winReadScript(String port, int baud, int dataBits, int stopBits, int parity, {int parentPid = 0}) {
  final String par = parity == 1 ? 'Odd' : (parity == 2 ? 'Even' : 'None');
  final String stop = stopBits == 2 ? 'Two' : 'One';
  return "\$ErrorActionPreference = 'Stop'\n"
      "\$p = New-Object System.IO.Ports.SerialPort '$port', $baud, ([System.IO.Ports.Parity]::$par), $dataBits, ([System.IO.Ports.StopBits]::$stop)\n"
      "\$p.ReadTimeout = 300\n"
      "\$p.DtrEnable = \$true\n"
      "\$p.RtsEnable = \$true\n"
      "\$p.Open()\n"
      "\$o = [Console]::OpenStandardOutput()\n"
      "\$b = New-Object byte[] 4096\n"
      "[Console]::Error.WriteLine('OPEN')\n"
      "\$bad = 0\n"
      "\$pp = $parentPid\n"
      "\$k = 0\n"
      "while (\$true) {\n"
      "  \$n = 0\n"
      // a short hiccup of the cable / driver is waited out (20 errors in a row = about 2 s); a really pulled out cable ends the script
      "  try { \$n = \$p.Read(\$b, 0, \$b.Length); \$bad = 0 } catch [System.TimeoutException] { \$n = 0; \$bad = 0 } catch { \$bad++; if (\$bad -ge 20) { throw }; Start-Sleep -Milliseconds 100 }\n"
      "  if (\$n -gt 0) { \$o.Write(\$b, 0, \$n); \$o.Flush() }\n"
      // the app that started this script is gone: stop (the port is released)
      "  \$k++\n"
      "  if (\$pp -gt 0 -and (\$n -eq 0 -or \$k % 25 -eq 0)) { if (-not (Get-Process -Id \$pp -ErrorAction SilentlyContinue)) { break } }\n"
      "}\n"
      "try { \$p.Close() } catch {}\n";
}

/// The text of the PowerShell script that stops readers of [port] that were left behind: their app is gone (so nobody reads what they read,
/// and they keep the port closed for everyone else). Prints the number of the processes it stopped. (public for tests)
String winFreeScript(String port) {
  return "\$me = \$PID\n"
      "Get-CimInstance Win32_Process | Where-Object { \$_.ProcessId -ne \$me -and \$_.Name -eq 'powershell.exe' -and \$_.CommandLine -match 'IO\\.Ports\\.SerialPort .${port.toUpperCase()}.' } | ForEach-Object {\n"
      "  \$alive = Get-Process -Id \$_.ParentProcessId -ErrorAction SilentlyContinue\n"
      "  if (-not \$alive) { Stop-Process -Id \$_.ProcessId -Force -ErrorAction SilentlyContinue; Write-Output \$_.ProcessId }\n"
      "}\n";
}

class _WinSession implements UsbSession {
  final Process proc;
  final StreamController<Uint8List> ctl = StreamController<Uint8List>.broadcast();
  _WinSession(this.proc) {
    proc.stdout.listen((List<int> d) {
      if (!ctl.isClosed) ctl.add(Uint8List.fromList(d));
    }, onDone: () {
      if (!ctl.isClosed) ctl.close();
    }, onError: (Object e) {});
  }

  @override
  Stream<Uint8List> get data => ctl.stream;

  @override
  Future<void> write(List<int> bytes) async {}

  @override
  Future<void> close() async {
    try {
      proc.kill();
    } catch (_) {}
    if (!ctl.isClosed) await ctl.close();
  }
}

/// The USB serial adapters plugged in now (on the laptop: the COM ports).
Future<List<UsbDev>> usbDevices() async {
  if (!_winSerial) return <UsbDev>[];
  final ProcessResult r = await Process.run(winShell, <String>['-NoProfile', '-NonInteractive', '-Command', _listScript]);
  final List<UsbDev> out = <UsbDev>[];
  for (final String line in '${r.stdout}'.split(RegExp(r'[\r\n]+'))) {
    final int i = line.indexOf('|');
    if (i <= 0) continue;
    final String id = line.substring(0, i).trim().toUpperCase();
    if (!_comName.hasMatch(id)) continue;
    final String name = line.substring(i + 1).trim();
    out.add(UsbDev(id, name.isEmpty ? id : (name.toUpperCase().contains(id) ? name : '$name ($id)')));
  }
  out.sort((UsbDev a, UsbDev b) => (int.tryParse(a.id.substring(3)) ?? 0).compareTo(int.tryParse(b.id.substring(3)) ?? 0));
  return out;
}

/// The reader of the session that is open now (a new one replaces it: two readers of one port can never work).
_WinSession? _winCur;

/// Stops readers of [port] left behind by an app that is gone. Returns how many it stopped.
Future<int> winFreePort(String port) async {
  if (!_winSerial || !_comName.hasMatch(port)) return 0;
  try {
    final ProcessResult r = await Process.run(winShell, <String>['-NoProfile', '-NonInteractive', '-Command', winFreeScript(port)]).timeout(const Duration(seconds: 15));
    return RegExp(r'^\d+\s*$', multiLine: true).allMatches('${r.stdout}').length;
  } catch (_) {
    return 0;
  }
}

/// Opens the adapter. [parity]: 0 none, 1 odd, 2 even. Throws a readable text when it cannot.
/// "Access denied" is tried once more after readers that an earlier run of the app left behind were stopped.
Future<UsbSession> usbConnect(UsbDev d, {required int baud, int dataBits = 8, int stopBits = 1, int parity = 0}) async {
  if (!_winSerial) throw 'This build has no USB cable support';
  if (!_comName.hasMatch(d.id)) throw 'Not a COM port: ${d.id}';
  try {
    _winCur?.proc.kill();
  } catch (_) {}
  _winCur = null;
  try {
    return await _usbOpen(d, baud, dataBits, stopBits, parity);
  } catch (e) {
    final String t = '$e';
    if (!t.toLowerCase().contains('denied')) rethrow;
    final int freed = await winFreePort(d.id);
    if (freed > 0) {
      await Future<void>.delayed(const Duration(milliseconds: 700));
      return _usbOpen(d, baud, dataBits, stopBits, parity);
    }
    throw '$t  [${d.id} is used by another program - another Balaji Kanta window, or the terminal software. Close it, or restart the laptop.]';
  }
}

Future<UsbSession> _usbOpen(UsbDev d, int baud, int dataBits, int stopBits, int parity) async {
  final int gen = ++_winGen;
  winLastEnd = '';
  final Process p = await winSpawn(winShell, <String>['-NoProfile', '-NonInteractive', '-Command', winReadScript(d.id.toUpperCase(), baud, dataBits, stopBits, parity, parentPid: pid)]);
  final _WinSession s = _WinSession(p);
  final Completer<String> done = Completer<String>();
  final StringBuffer err = StringBuffer();
  final Completer<void> errEnd = Completer<void>();
  p.stderr.transform(const SystemEncoding().decoder).listen((String t) {
    err.write(t);
    if (!done.isCompleted && err.toString().contains('OPEN')) done.complete('');
    if (done.isCompleted && gen == _winGen) winLastEnd = _cleanWinErr(err.toString());
  }, onError: (Object e) {}, onDone: () {
    if (!errEnd.isCompleted) errEnd.complete();
  });
  unawaited(p.exitCode.then((int c) async {
    // the process can end before its last words (the reason) were read: wait for them
    await errEnd.future.timeout(const Duration(milliseconds: 800), onTimeout: () {});
    if (gen == _winGen && done.isCompleted && winLastEnd.isEmpty) winLastEnd = _cleanWinErr(err.toString());
    if (!done.isCompleted) {
      final String why = err.toString().replaceAll(RegExp(r'\s+'), ' ').trim();
      done.complete(why.isEmpty ? 'The COM port could not be opened (code $c)' : why);
    } else if (gen == _winGen && winLastEnd.isEmpty && c != 0) {
      winLastEnd = 'The COM reader stopped (code $c)';
    }
  }));
  final String res = await done.future.timeout(const Duration(seconds: 12), onTimeout: () => 'The COM port did not open (PowerShell too slow)');
  if (res.isNotEmpty) {
    await s.close();
    throw res;
  }
  _winCur = s;
  return s;
}

/// Lets the owner choose a file. Phone: the system file chooser (pen drive too). Laptop: the Windows open-file window.
Future<PickedFile?> pickFile() async {
  if (kIsWeb || !Platform.isWindows) return null;
  try {
    final ProcessResult r = await Process.run('powershell', <String>[
      '-NoProfile',
      '-STA',
      '-Command',
      r"Add-Type -AssemblyName System.Windows.Forms; $d = New-Object System.Windows.Forms.OpenFileDialog; $d.Title = 'Kanta report file'; $d.Filter = 'Kanta report (*.csv;*.txt;*.xlsx;*.xls)|*.csv;*.txt;*.xlsx;*.xls|All files (*.*)|*.*'; if ($d.ShowDialog() -eq 'OK') { Write-Output $d.FileName }",
    ]);
    final String p = '${r.stdout}'.trim();
    if (p.isEmpty) return null;
    final File f = File(p);
    if (!await f.exists()) return null;
    return PickedFile(p.split(RegExp(r'[\\/]')).last, await f.readAsBytes());
  } catch (_) {
    return null;
  }
}
